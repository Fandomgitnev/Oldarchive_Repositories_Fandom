@echo off
title FastWin10_11
goto main
:main
cls
echo zametka ne zabuti nastroiti region and time
echo back to main menu use 99 prees
echo.
echo                                            ================================
echo                                                 FastWin10_11
echo                                         ================================
echo.
echo                                         [1] Auto
echo                                         [2] only 11 auto
echo                                         [4] Drivers / Programs
echo                                         [5] Uneversall auto (question answer)
echo                                         [6] Del Mic EdgeX2 + webvie/Officialway
echo.
set /p ttt=".                             >>"
if "%ttt%" == "1" goto auto
if "%ttt%" == "2" goto asetwin11
if "%ttt%" == "4" goto drivers
if "%ttt%" == "5" goto thxwinclick
if "%ttt%" == "6" goto delmicrosoftof
) else (
goto main
)
:auto
cls
echo Hybernation off
powercfg.exe /h off
echo.
echo off2 smartscreen
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v ConfigureAppInstallControlEnabled /t REG_DWORD /d 0 /f
echo.
echo.
echo enable2 numloock
reg add "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
reg add "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
echo.
echo.
echo enable2 bar secons time
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowSecondsInSystemClock /t REG_DWORD /d 1 /f
echo.
echo.
echo dark no active
reg add "HKCU\Software\Microsoft\Windows\DWM" /v AccentColorInactive /t REG_DWORD /d 0xFF000000 /f
echo.
echo.
echo enable2 green box
reg add "HKCU\Control Panel\Colors" /v Hilight /t REG_SZ /d "15 252 3" /f
reg add "HKCU\Control Panel\Colors" /v HotTrackingColor /t REG_SZ /d "15 252 3" /f
echo.
echo.
echo Off2 Bing Search Highlights
Reg.exe add "HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer" /v NoSearchEverywhereLinkInStartMenu /t REG_DWORD /d 1 /f
Reg.exe add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d "1" /f
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsDynamicSearchBoxEnabled" /t REG_DWORD /d "0" /f 
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d "0" /f 
echo.
echo.
echo Disable Sticky Keys
reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /t REG_SZ /d "506" /f
echo.
echo.
echo off2 auto update drivers
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v SearchOrderConfig /t REG_DWORD /d 0 /f
echo.
echo.
echo off service edge update and TASK SCHEDULER and onedrive
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdate" /v Start /t REG_DWORD /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdatem" /v Start /t REG_DWORD /d 4 /f
schtasks /End /TN "MicrosoftEdgeUpdateTaskMachineCore"
schtasks /Change /TN "MicrosoftEdgeUpdateTaskMachineCore" /TR "" /ST 00:00
schtasks /Change /TN "MicrosoftEdgeUpdateTaskMachineCore" /Disable
schtasks /End /TN "MicrosoftEdgeUpdateTaskMachineUA"
schtasks /Change /TN "MicrosoftEdgeUpdateTaskMachineUA" /TR "" /ST 00:00
schtasks /Change /TN "MicrosoftEdgeUpdateTaskMachineUA" /Disable
echo.
echo.
echo.
echo            next auto set in win 11
echo            1 yes
echo            2 no (back main page)
echo            3 no exit
set /p Ar5=".>>"
if "%Ar5%"=="1" goto asetwin11 
if "%Ar5%"=="2" goto main
if "%Ar5%"=="3" exit
) else (
goto main
)
:asetwin11
cls
echo.
echo.
echo off2 win11 background application
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle /t REG_DWORD /d 0 /f
echo.
echo.
echo off2 win11 setting Map
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MapsBroker" /v Start /t REG_DWORD /d 4 /f
echo.
echo.
echo END
pause
goto main
:drivers
cls
echo.
echo.
echo.
echo.
echo                                               [1] Link DirectX
echo                                               [2] Link VCRedist
echo                                               [3] Intel
echo                                               [4] NVIDIA
echo                                               [5] AMD
echo                                               [6] Radeon Software Slimmer
echo                                               [7] NVCleanstal
echo                                               [8] Display Driver Uninstaller (ddu)
echo                                               [9] Driver Store Explorer
echo                                               [10] Device Clean UP
echo                                               [11] Snappy Driver Installer
echo                                               [12] open menu programs
set /p P1=".                >>"
if "%P1%"=="1" start https://www.techpowerup.com/download/directx-redistributable-runtime/
if "%P1%"=="2" start https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/
if "%P1%"=="3" start https://www.intel.com/content/www/us/en/download-center/home.html
if "%P1%"=="4" start https://www.nvidia.com/en-us/geforce/drivers/
if "%P1%"=="5" start https://www.amd.com/en/support/download/drivers.html
if "%P1%"=="6" start https://github.com/GSDragoon/RadeonSoftwareSlimmer
if "%P1%"=="7" start https://www.techpowerup.com/download/techpowerup-nvcleanstall/
if "%P1%"=="8" start https://www.wagnardsoft.com/
if "%P1%"=="9" start https://github.com/lostindark/DriverStoreExplorer
if "%P1%"=="10" start https://www.uwe-sieber.de/misc_tools_e.html
if "%P1%"=="11" start https://www.glenn.delahoy.com/snappy-driver-installer-origin/
if "%P1%"=="12" goto programs
if "%P1%"=="97" start https://www.nvidia.com/en-us/geforce/drivers/results/237786/
if "%P1%"=="98" start https://www.nvidia.com/en-us/drivers/details/237786/
if "%P1%"=="99" goto main
) else (
goto drivers
)
:programs
cls
echo all others in wtool
echo.
echo                    [1] 7zip
echo                   [2] context menu
echo                   [3] mpc-hc
echo                   [4] notepad++
echo                    [5] systeminformer
echo.
set /p P2P=".        >>"
if "%P2P%"=="1" start https://7-zip.org/download.html
if "%P2P%"=="2" start https://www.sordum.org/7615/easy-context-menu-v1-6/
if "%P2P%"=="3" start https://github.com/clsid2/mpc-hc/releases
if "%P2P%"=="4" start https://github.com/notepad-plus-plus/notepad-plus-plus/releases?page=3
if "%P2P%"=="5" start https://systeminformer.sourceforge.io/
if "%P2P%"=="99" goto drivers 
) else (
goto programs
)
:thxwinclick
cls
echo                  Delete Edge update files - Windows Update?
echo                             press [1] or 
echo                         [2] to skip
echo. 
set /p oneclick=".        >>"
if "%oneclick%"=="1" (
del /q /f /s "%SystemRoot%\SoftwareDistribution\Download\*.*"
rd /q /s "%SystemRoot%\SoftwareDistribution\Download\"
del /q /f /s "%SystemRoot%\SoftwareDistribution\Download"
del /q /f /s "%ProgramFiles(x86)%\Microsoft\EdgeUpdate\Download\*.*"
rd /q /s "%ProgramFiles(x86)%\Microsoft\EdgeUpdate\Download\"
goto thxwinclick1
) else (
goto thxwinclick1
)
:thxwinclick1
echo.
echo.
echo                  Clearing the Windows Store Cache?
echo                             press [1] or 
echo                         [2] to skip
echo.
set /p oneclick1=".        >>"
if "%oneclick1%"=="1" (
del /q /f /s "%userprofile%\AppData\Local\Packages\Microsoft.WindowsStore_8wekyb3d8bbwe\LocalCache\*.*"
rd /q /s "%userprofile%\AppData\Local\Packages\Microsoft.WindowsStore_8wekyb3d8bbwe\LocalCache\"
goto thxwinclick2
) else (
goto thxwinclick2
)
:thxwinclick2
echo.
echo.
echo                  Clearing the Explorer cache?
echo                             press [1] or 
echo                         [2] to skip
echo.
set /p oneclick2=".        >>"
if "%oneclick2%"=="1" (
pushd "%LocalAppData%\Microsoft\Windows\Explorer"
del /s /q /a:h "IconCache*" "thumbcache*"
del /s /q /f "IconCache*" "thumbcache*"
popd
pushd "%LocalAppData%"
if exist IconCache.db del /a /q IconCache.db
if exist IconCache.db-wal del /a /q IconCache.db-wal
del /s /q /a:h "IconCache*" "thumbcache*"
popd
goto thxwinclick3
) else (
goto thxwinclick3
)
:thxwinclick3
echo.
echo.
echo                    Cleaning WinSxS?
echo                             press [1] or 
echo                            [2] to skip
echo The last warning will not go further than the prompt. Go use it. Use the 1 key. Just press Enter or any other number.
echo Please don't use enter because it remembers the last number selected, so use 2
echo.
set /p oneclick3=".        >>"
if "%oneclick3%"=="1" (
Dism /online /Cleanup-Image /StartComponentCleanup /ResetBase
goto thxwinclick4
) else (
goto thxwinclick4
)
:thxwinclick4
echo.
echo.
echo                    Disabling Reserved Storage?
echo.
set /p oneclick4=".        >>"
if "%oneclick4%"=="1" (
Dism /Online /Set-ReservedStorageState /State:Disabled
goto thxwinclick5
) else (
goto thxwinclick5
)
:thxwinclick5
echo.
echo.
echo                    Disable GameDVR
echo.
set /p oneclick5=".        >>"
if "%oneclick5%"=="1" (
reg add "HKCR\System\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f
reg add "HKCR\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AppCaptureEnabled" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Policies\Microsoft\Windows\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Microsoft\PolicyManager\default\ApplicationManagement\AllowGameDVR" /v "Value" /t REG_DWORD /d 0 /f
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f
goto thxwinclick6
) else (
goto thxwinclick6
)
:thxwinclick6
echo.
echo                    Disable installation of drivers from the Update Center
echo.
set /p oneclick6=".        >>"
if "%oneclick6%"=="1" (
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d "1" /f
reg add "HKLM\Software\Policies\Microsoft\Windows\Device Metadata" /v "PreventDeviceMetadataFromNetwork" /t REG_DWORD /d "1" /f
reg add "HKLM\Software\Policies\Microsoft\Windows\DriverSearching" /v "SearchOrderConfig" /t REG_DWORD /d "0" /f
reg add "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" /v "ExcludeWUDriversInQualityUpdate" /t REG_DWORD /d "1" /f
goto thxwinclick7
) else (
goto thxwinclick7
)
:thxwinclick7
echo.
echo                    Updates paused until 07/07/77
echo.
set /p oneclick7=".        >>"
if "%oneclick7%"=="1" (
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesStartTime" /t REG_SZ /d 2024-09-13T00:00:00Z /f 
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseUpdatesExpiryTime" /t REG_SZ /d 2077-07-07T00:00:00Z /f 
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesStartTime" /t REG_SZ /d 2024-09-13T00:00:00Z /f 
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseFeatureUpdatesExpiryTime" /t REG_SZ /d 2077-07-07T00:00:00Z /f 
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesStartTime" /t REG_SZ /d 2024-09-13T00:00:00Z /f 
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v "PauseQualityUpdatesExpiryTime" /t REG_SZ /d 2077-07-07T00:00:00Z /f 
reg add "HKLM\Software\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v "PausedFeatureStatus" /t REG_DWORD /d 1 /f 
reg add "HKLM\Software\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v "PausedQualityStatus" /t REG_DWORD /d 1 /f 
reg add "HKLM\Software\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v "PausedQualityDate" /t REG_SZ /d "2077-07-07 13:00:00" /f 
reg add "HKLM\Software\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v "PausedFeatureDate" /t REG_SZ /d "2077-07-07 13:00:00" /f 
goto thxwinclick8
) else (
goto thxwinclick8
)
:thxwinclick8
echo.
echo                     Force quit programs when they freeze?
echo.
set /p oneclick8=".        >>"
if "%oneclick8%"=="1" (
reg add "HKCR\Control Panel\Desktop" /v "AutoEndTasks" /t REG_SZ /d 1 /f
goto thxwinclick9
) else (
goto thxwinclick9
)
:thxwinclick9
echo.
echo       Turn off notifications and recommendations? in (Personalization ">" Starst)
echo.
set /p oneclick9=".        >>"
if "%oneclick9%"=="1" (
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SubscribedContent-310093Enabled" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v "ScoobeSystemSettingEnabled" /t REG_DWORD /d 0 /f
goto thxwinclick10
) else (
goto thxwinclick10
)
:thxwinclick10
echo.
echo       Disabling recommendations in File Explorer?
echo.
set /p oneclick10=".        >>"
if "%oneclick10%"=="1" (
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowRecent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowFrequent" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowCloudFilesInQuickAccess" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v "ShowRecommendations" /t REG_DWORD /d 0 /f
goto thxwinclick11
) else (
goto thxwinclick11
)
:thxwinclick11
echo.
echo       Disabling other recommendations and offers?
echo.
set /p oneclick11=".        >>"
if "%oneclick11%"=="1" (
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "ContentDeliveryAllowed" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v "SystemPaneSuggestionsEnabled" /t REG_DWORD /d 0 /f
goto thxwinclick12
) else (
goto thxwinclick12
)
:thxwinclick12
echo.
echo       Removing Home from Explorer and Removing Gallery from Explorer?
echo.
set /p oneclick12=".        >>"
if "%oneclick12%"=="1" (
reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Explorer" /v "HubMode" /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Classes\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\Wow6432Node\CLSID\{f874310e-b6b7-47dc-bc84-b9e6b38f5903}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}" /v "System.IsPinnedToNameSpaceTree" /t REG_DWORD /d 0 /f
reg add "HKCU\Software\Classes\Wow6432Node\CLSID\{e88865ea-0e1c-4e20-9aa6-edcd0212c87c}" /v System.IsPinnedToNameSpaceTree /t REG_DWORD /d 0 /f
goto thxwinclick13
) else (
goto thxwinclick13
)
:thxwinclick13
echo.
echo        Hiding Recommended? (Maybe this is for the start button)
echo.
set /p oneclick13=".        >>"
if "%oneclick13%"=="1" (
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Start" /v "HideRecommendedSection" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Education" /v "IsEducationEnvironment" /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "HideRecommendedSection" /t REG_DWORD /d 1 /f
pause >nul
goto main
) else (
pause >nul
goto main
)


:delmicrosoftof
cls 
taskkill /f /im MicrosoftEdge.exe
taskkill /f /im MicrosoftEdgeUpdate.exe
echo Please go to the Edge or EdgeWebView version folder, open the "Installer" folder, Shift + right-click on "setup.exe", select "Copy as path", and paste the full path here.
start "" "C:\Program Files (x86)\Microsoft\Edge\Application"
set /p Delete=
start "" "C:\Program Files (x86)\Microsoft\EdgeWebView\Application"
set /p deleteW=
start "" %Delete% --uninstall --system-level --force-uninstall --msedge
start "" %deleteW% --uninstall --system-level --force-uninstall --msedgewebview
pause >nul 
goto main