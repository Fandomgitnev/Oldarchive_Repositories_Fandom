@echo off

for %%a in (MicrosoftEdgeUpdate WidgetService Widgets msedge msedgewebview2) do taskkill /f /im %%a.exe

reg add "HKLM\SOFTWARE\Microsoft\EdgeUpdate" /v "DoNotUpdateToEdgeWithChromium" /t REG_DWORD /d "1" /f
reg add "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdateDev" /v "AllowUninstall" /t REG_SZ /f

for %%a in (
	MicrosoftEdgeElevationService
	edgeupdatem
	edgeupdate
) do reg delete "HKLM\SYSTEM\CurrentControlSet\Services\%%a" /f

for /f "tokens=*" %%i in ('schtasks /query /fo csv /nh ^| findstr /i "MicrosoftEdgeUpdateTaskMachineCore MicrosoftEdgeUpdateTaskMachineUA"') do (
    for /f "tokens=1 delims=," %%j in ("%%i") do (
        schtasks /delete /tn "%%~j" /f
    )
)

rd /s /q "%windir%\SystemApps\Microsoft.MicrosoftEdge_8wekyb3d8bbwe"
rd /s /q "%programfiles(x86)%\Microsoft"
rd /s /q "%localappdata%\Microsoft\Edge"
rd /s /q "%localappdata%\Microsoft\EdgeBho"
rd /s /q "%localappdata%\Microsoft\EdgeUpdate"

pause >nul
exit