@echo off
bcdedit /set disabledynamictick yes
bcdedit /set useplatformclock true
echo successfully
pause
exit