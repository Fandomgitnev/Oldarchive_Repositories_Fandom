@echo off
bcdedit /set disabledynamictick yes
bcdedit /set useplatformclock false
echo successfully
pause
exit