echo 1 on or no on info
fsutil behavior set DisableDeleteNotify 0
info 2 on or off
fsutil behavior query disabledeletenotify
pause
exit