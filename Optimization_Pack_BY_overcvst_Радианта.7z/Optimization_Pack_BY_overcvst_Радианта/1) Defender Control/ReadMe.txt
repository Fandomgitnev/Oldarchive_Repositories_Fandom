Author: BlueLife, Velociraptor
www.sordum.org

####################--Defender Control v2.1--####################

Tuesday, March 1, 2022

1. [Added] � Different blocking method
2. [Added] � Some code improvements

####################--Defender Control v2.0--####################

Monday, 13 September 2021
1. [Removed] � Cmd parameter support (Defender control is using inside some malware)
2. [Fixed] � Defender Control Doesn't work on Windows 11 
3. [Fixed] � Error occurs when turning off Windows Defender
4. [Added] � Some code improvements

####################--Defender Control v1.9--####################

Friday , 21. May 2021 , What is New
1. [Fixed] � False Positive Issue
2. [Added] � Add it to the Exclusions list feature (Under the menu)

####################--Defender Control v1.8--####################

Wednesday, 21. april 2021 , What is New
1. [Fixed] � False Positive Issue
2. [Added] � Some minor improvements


####################--Defender Control v1.7--####################

Monday, 25. january 2021 , What is New
1. [Fixed] - Defender control doesn't work properly when Tamper Protection is active
2. [Fixed] - ID Protection prevent to use Defender contol on multiple pc (ID Protection removed)
3. [Fixed] - GUI Font is too small
4. [Added] - The / q parameter has been added. Status information can be obtained with Exit code
5. [Added] - Some code improvements

####################--Defender Control v1.6--####################

Monday , 16. December 2019 , What is New
1. [Fixed] � False Positive Issue (ID Protection added)
2. [Added] � A unique security code for the defender disable cmd command
3. [Added] � About screen

####################--Defender Control v1.5--####################

Friday , 12. April 2019 , What is New
1. [Fixed] � Defender Control Doesn�t work on Windows 10 1903

####################--Defender Control v1.4--####################

Thursday, 13. December 2018 , What is New
1. [Fixed] - Launch button doesn't work on Windows 10 1809
2. [Added] - Language support

####################--Defender Control v1.3--####################

Wednesday, 28. February 2018 , What is New
1. [Fixed] � Some minor BUGs

####################--Defender Control v1.2--####################

Thursday, 15. December 2016 , What is New
1. [Added] - new GUI
2. [Added] - Menu button

####################--Defender Control v1.1--####################
		
Tuesday, 10. May 2016 , What is New
1. [Fixed] � Some minor BUGs

####################--Defender Control v1.0--####################

Friday, 3. July 2015 , What is New
First Release , A small portable tool to disable and then enable Microsoft Windows defender

