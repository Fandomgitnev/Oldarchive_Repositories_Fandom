@echo off
setlocal
setlocal enabledelayedexpansion
echo                           [TEST For]
pause
For /F "delims=, tokens=1,2 " %%A IN ("1,2") do echo %%A %%B
for %%C in (lol) do (for /l %%E in (1,1,100) do (echo %%C))
timeout /t 5 >nul
for %%K in (.) do (for /l %%U in (1,1,100) do (echo%%K))
echo next its dynamick change echo "%%%%"
timeout /t 5 >nul
for %%K in (.) do (for /l %%U in (1,1,100) do (echo%%K))
rem ну вообщето он должен не так работать а чучуть вот так for /и без слеша "без аргументов" %%перемена in (название милион перем) do 
rem (set "%%п=то есть все что в п бдует принимать этот текст") потом просто любой вид проверки find findstr или если что то знаете другое используйте и потом если проверка 
rem прошла успешно то || не будет выполняться но если после проверки вощращаеться %errorleval%=1 то бедт выполнена команда после || 
rem set "название переменой из %%п= то будет принематься любой текст в "название милион перем""
rem в помощь вам 2bat и 2.txt  и honectrl
rem да была попытка создать проверку если 1 совпадает tt.txt в помошь
pause
cls
for %%I in (GG) do (set "%%I=yes Acer")
for /f "tokens=2 delims=:" %%Y in ('systeminfo ^| findstr /C:"System Manufacturer"') do (
set eee=%%Y
)
for /f "tokens=* delims= " %%Z in ("!eee!") do set "eee=%%Z"
echo !eee!
pause >nul
if /I "!eee!"=="Acer" (
echo !GG!
) else (
echo no its !eee!
)
echo %errorlevel%
pause >nul
cls
pause >nul
echo thx "https://youtu.be/hXpv8ghORdc?si=gdPdtOP47vbuAe0s"
endlocal
pause >nul