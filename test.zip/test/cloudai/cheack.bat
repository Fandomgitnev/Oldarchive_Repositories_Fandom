@echo off
title WTool Check Tweaks
goto main

:checkalltweaks
for %%g in (1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50) do (set "tw%%g=ON")
(
rem === Driver Tweaks ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate | find "0x1" || set "tw1=OFF"
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v SearchOrderConfig | find "0x0" || set "tw1=OFF"

rem === Background Application W11 ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled | find "0x1" || set "tw2=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle | find "0x0" || set "tw2=OFF"

rem === Map Service ===
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MapsBroker" /v Start | find "0x4" || set "tw3=OFF"

rem === Sticky Keys ===
reg query "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags | find "506" || set "tw4=OFF"

rem === VBS (Virtualization Based Security) ===
reg query "HKLM\SYSTEM\CurrentControlSet\Control\DeviceGuard" /v EnableVirtualizationBasedSecurity | find "0x0" || set "tw5=OFF"

rem === Game DVR ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR" /v AllowGameDVR | find "0x0" || set "tw6=OFF"
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR" /v AppCaptureEnabled | find "0x0" || set "tw6=OFF"
reg query "HKCU\System\GameConfigStore" /v GameDVR_Enabled | find "0x0" || set "tw6=OFF"

rem === Game Bar ===
reg query "HKCU\SOFTWARE\Microsoft\GameBar" /v AllowAutoGameMode | find "0x0" || set "tw7=OFF"
reg query "HKCU\SOFTWARE\Microsoft\GameBar" /v AutoGameModeEnabled | find "0x0" || set "tw7=OFF"
reg query "HKCU\SOFTWARE\Microsoft\GameBar" /v ShowStartupPanel | find "0x0" || set "tw7=OFF"

rem === Bing Search Highlights ===
reg query "HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer" /v NoSearchEverywhereLinkInStartMenu | find "0x1" || set "tw8=OFF"
reg query "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions | find "0x1" || set "tw8=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v IsDynamicSearchBoxEnabled | find "0x0" || set "tw8=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BingSearchEnabled | find "0x0" || set "tw8=OFF"

rem === Reserved Storage ===
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager" /v MiscPolicyInfo | find "0x2" || set "tw9=OFF"
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager" /v PassedPolicy | find "0x0" || set "tw9=OFF"
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager" /v ShippedWithReserves | find "0x0" || set "tw9=OFF"

rem === Low Disk Space Notification ===
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoLowDiskSpaceChecks | find "0x1" || set "tw10=OFF"

rem === Automatic Maintenance ===
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance" /v MaintenanceDisabled | find "0x1" || set "tw11=OFF"

rem === Network Throttling ===
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v NetworkThrottlingIndex | find "ffffffff" || set "tw12=OFF"

rem === Power Throttling ===
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" /v PowerThrottlingOff | find "0x1" || set "tw13=OFF"

rem === Clear Pagefile at Shutdown ===
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v ClearPageFileAtShutdown | find "0x1" || set "tw14=OFF"

rem === Auto End Tasks ===
reg query "HKCR\Control Panel\Desktop" /v AutoEndTasks | find "1" || set "tw15=OFF"

rem === Telemetry ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v AllowTelemetry | find "0x0" || set "tw16=OFF"

rem === Feedback Notifications ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection" /v DoNotShowFeedbackNotifications | find "0x1" || set "tw17=OFF"

rem === Notifications and Recommendations ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-338389Enabled | find "0x0" || set "tw18=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SubscribedContent-310093Enabled | find "0x0" || set "tw18=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement" /v ScoobeSystemSettingEnabled | find "0x0" || set "tw18=OFF"

rem === Start Menu Recommendations ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Start" /v ShowRecentList | find "0x0" || set "tw19=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Start" /v ShowFrequentList | find "0x0" || set "tw19=OFF"

rem === File Explorer Recommendations ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v ShowRecent | find "0x0" || set "tw20=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v ShowFrequent | find "0x0" || set "tw20=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v ShowRecommendations | find "0x0" || set "tw20=OFF"

rem === Content Delivery ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v ContentDeliveryAllowed | find "0x0" || set "tw21=OFF"
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SystemPaneSuggestionsEnabled | find "0x0" || set "tw21=OFF"

rem === Hide Recommended Section ===
reg query "HKLM\SOFTWARE\Microsoft\PolicyManager\current\device\Start" /v HideRecommendedSection | find "0x1" || set "tw22=OFF"
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v HideRecommendedSection | find "0x1" || set "tw22=OFF"

rem === Shortcut Arrow Removal ===
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer" /v link | find "00000000" || set "tw23=OFF"

rem === Logon Blur Effect ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v DisableAcrylicBackgroundOnLogon | find "0x1" || set "tw24=OFF"

rem === NumLock on Startup ===
reg query "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set "tw25=OFF"
reg query "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set "tw25=OFF"

rem === Show Seconds in Clock ===
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowSecondsInSystemClock | find "0x1" || set "tw26=OFF"

rem === Wallpaper Quality ===
reg query "HKCU\Control Panel\Desktop" /v JPEGImportQuality | find "0x64" || set "tw27=OFF"

rem === Dark Theme ===
reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AppsUseLightTheme | find "0x0" || set "tw28=OFF"
reg query "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v SystemUsesLightTheme | find "0x0" || set "tw28=OFF"

rem === Green Highlight Color ===
reg query "HKCU\Control Panel\Colors" /v Hilight | find "15 252 3" || set "tw29=OFF"
reg query "HKCU\Control Panel\Colors" /v HotTrackingColor | find "15 252 3" || set "tw29=OFF"

rem === Inactive Window Dark Color ===
reg query "HKCU\Software\Microsoft\Windows\DWM" /v AccentColorInactive | find "0" || set "tw30=OFF"

rem === Tooltip Hover Time ===
reg query "HKEY_CURRENT_USER\Control Panel\Mouse" /v MouseHoverTime | find "1" || set "tw31=OFF"

rem === Hibernation ===
powercfg /a | findstr /C:"Hibernation has not been enabled" || set "tw32=OFF"

rem === Pagefile ===
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v PagingFiles | find "1 1" || set "tw33=OFF"

rem === Smart Screen ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen | find "0x0" || set "tw34=OFF"
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v ConfigureAppInstallControlEnabled | find "0x0" || set "tw34=OFF"

rem === Biometrics Windows Hello ===
reg query "HKLM\SOFTWARE\Policies\Microsoft\Biometrics" /v Enabled | find "0x0" || set "tw35=OFF"
reg query "HKLM\SYSTEM\CurrentControlSet\Services\WbioSrvc" /v Start | find "0x3" || set "tw35=OFF"

rem === Windows Update Pause ===
reg query "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseUpdatesExpiryTime | find "2077" || set "tw36=OFF"

rem === Delayed Start Services ===
reg query "HKLM\System\CurrentControlSet\Services\EventSystem" /v DelayedAutostart | find "0x1" || set "tw37=OFF"
reg query "HKLM\System\CurrentControlSet\Services\NlaSvc" /v DelayedAutostart | find "0x1" || set "tw37=OFF"

rem === Priority AMD ===
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v "GPU Priority" | find "0x8" || set "tw38=OFF"
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games" /v Priority | find "0x6" || set "tw38=OFF"

rem === USB Autorun ===
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoDriveTypeAutoRun | find "0xff" || set "tw39=OFF"

rem === Remove Folders from This PC ===
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{088e3905-0323-4b02-9826-5d99428e115f}" >nul 2>&1 && set "tw40=OFF"
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{24ad3ad4-a569-4530-98e1-ab02f9417aa8}" >nul 2>&1 && set "tw40=OFF"
reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\{3dfdf296-dbec-4fb4-81d1-6a3438bcf4de}" >nul 2>&1 && set "tw40=OFF"

rem === Old Context Menu W11 ===
reg query "HKCU\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32" /ve | find '""' || set "tw41=OFF"

rem === OneDrive Removed ===
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{018D5C66-4533-4307-9B53-224DE2ED1FE6}" >nul 2>&1 && set "tw42=OFF"

rem === Edge Update Services ===
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdate" /v Start | find "0x4" || set "tw43=OFF"
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdatem" /v Start | find "0x4" || set "tw43=OFF"

)
exit /b

:main
cls
call :checkalltweaks
echo =====================================================
echo              WTool Tweak Status Check
echo =====================================================
echo.
echo === Driver / Auto Update ===
echo  Auto Download Driver:               %tw1%
echo.
echo === Windows 11 Specific ===
echo  Background Applications:            %tw2%
echo  Maps Service:                       %tw3%
echo.
echo === Accessibility ===
echo  Sticky Keys Disabled:               %tw4%
echo.
echo === Security / Performance ===
echo  VBS (Virtualization):               %tw5%
echo  Game DVR:                           %tw6%
echo  Game Bar:                           %tw7%
echo.
echo === Search / UI ===
echo  Bing Search Highlights:             %tw8%
echo.
echo === Storage ===
echo  Reserved Storage:                   %tw9%
echo  Low Disk Space Notification:        %tw10%
echo.
echo === Maintenance ===
echo  Automatic Maintenance:              %tw11%
echo.
echo === Network / Power ===
echo  Network Throttling:                 %tw12%
echo  Power Throttling:                   %tw13%
echo.
echo === Memory ===
echo  Clear Pagefile at Shutdown:         %tw14%
echo  Pagefile Disabled:                  %tw33%
echo.
echo === System Behavior ===
echo  Auto End Tasks:                     %tw15%
echo  Hibernation:                        %tw32%
echo.
echo === Privacy / Telemetry ===
echo  Telemetry:                          %tw16%
echo  Feedback Notifications:             %tw17%
echo  Notifications/Recommendations:      %tw18%
echo  Start Menu Recommendations:         %tw19%
echo  File Explorer Recommendations:      %tw20%
echo  Content Delivery:                   %tw21%
echo  Hide Recommended Section:           %tw22%
echo.
echo === Interface Tweaks ===
echo  Shortcut Arrow Removal:             %tw23%
echo  Logon Blur Effect:                  %tw24%
echo  NumLock on Startup:                 %tw25%
echo  Show Seconds in Clock:              %tw26%
echo  Wallpaper Quality 100:              %tw27%
echo  Dark Theme:                         %tw28%
echo  Green Highlight Color:              %tw29%
echo  Inactive Window Dark:               %tw30%
echo  Quick Tooltip:                      %tw31%
echo  Old Context Menu (W11):             %tw41%
echo  Remove Folders This PC:             %tw40%
echo.
echo === Security ===
echo  Smart Screen:                       %tw34%
echo  Biometrics (Windows Hello):         %tw35%
echo.
echo === Windows Update ===
echo  Windows Update Paused:              %tw36%
echo.
echo === Services ===
echo  Delayed Start Services:             %tw37%
echo  USB Autorun:                        %tw39%
echo  Edge Update Services:               %tw43%
echo.
echo === Advanced ===
echo  Priority (Games AMD/Intel):         %tw38%
echo  OneDrive Removed:                   %tw42%
echo.
echo =====================================================
echo.
pause
goto main