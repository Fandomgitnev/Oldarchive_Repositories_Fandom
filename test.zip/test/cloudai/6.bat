@echo off
setlocal enabledelayedexpansion
set col0=[92m
set col1=[93m
set col2=[91m
set retf=[0m
set pos=0

:loop
for /l %%i in (1,1,9) do (
  set /a r=!random! %% 3
  for %%c in (!r!) do set c%%i=!col%%c!
)

set /a pos=(!pos! + 1) %% 3

set sp0= 
set sp1= 
set sp2= 
set sp!pos!=  

echo.
echo   test color "*"
echo.
echo !sp0!!c1!* !c2!* !c3!*%retf%
echo !sp1!!c4!* !c5!* !c6!*%retf%
echo !sp2!!c7!* !c8!* !c9!*%retf%
echo.
pause >nul
goto loop