@echo off
setlocal enabledelayedexpansion
set col0=[92m
set col1=[93m
set col2=[91m
set retf=[0m

:loop
for /l %%i in (1,1,9) do (
  set /a r=!random! %% 3
  for %%c in (!r!) do set c%%i=!col%%c!
)
echo.
echo   test color "*"
echo.
echo  !c1!* !c2!* !c3!*
echo  !c4!* !c5!* !c6!*
echo  !c7!* !c8!* !c9!*%retf%
echo.
pause >nul
goto loop
rem если нужно вынести за код 
rem :loop
rem call :updatecolors
rem :updatecolors
rem for /l %%i in (1,1,9) do (
rem   set /a r=!random! %% 3
rem   for %%c in (!r!) do set c%%i=!col%%c!
rem )
rem exit /b