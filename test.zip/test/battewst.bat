@echo off
chcp 65001 >nul
@echo off
SetLocal EnableDelayedExpansion

pause 