@echo off
:color 
set grtf=[92m
set yewf=[93m
set redf=[91m
set retf=[0m
set col0=[92m
set col1=[93m
set col2=[91m
setlocal 
setlocal enabledelayedexpansion
:loop
for %%g in (p d f) do (set "%%g=%grtf%on%retf%")
(
find "3" 2.txt >nul || set "p=%redf%off%retf%"
) 
rem thx cloud
for /l %%i in (1,1,9) do (
  set /a r=!random! %% 3
  for %%c in (!r!) do set c%%i=!col%%c!
)
echo 	test color*
echo  !c1!* !c2!* !c3!*
echo  !c4!* !c5!* !c6!*
echo  !c7!* !c8!* !c9!*%retf%
echo. 
echo [ !p! ]
echo.
echo errorlevel=%errorlevel%
pause >nul
goto loop






