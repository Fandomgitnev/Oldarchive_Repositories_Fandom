@echo off
chcp 65001 >nul
call :color 
goto Interface1
:color
set on=[92m
set off=[91m
set res=[0m

:Interface1
setlocal enabledelayedexpansion
for %%g in (Proff) do (set "%%g=%on%[4mWork%res%")
(
reg query "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set "Proff= %off%[4mNO%res% "
reg query "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set "Proff= %off%[4mNO%res% "
) >nul 
echo ╔════════════════════════════════════════════════════════════╗
echo ║                       Interface                            ║
echo ╠════════════════════════════════════════════════════════════╣
echo ║   [7] On "NumLock" Start pc !Proff!%res%                           ║
echo ╚════════════════════════════════════════════════════════════╝
set /p Twint1=". >>"
if "%Twint1%"=="7" (
reg add "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
reg add "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
pause >nul
goto Interface1
) else ( 
goto Interface1
)