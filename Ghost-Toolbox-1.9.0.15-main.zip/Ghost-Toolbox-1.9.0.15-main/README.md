# Ghost-Toolbox-1.9.0.15 (From Windows 11 Ghost Spectre)

Run Ghost Toolbox on any OS <br>
Download the files, copy paste the "nhcolor.exe" in System32 <br>
copy paste ghost toolbox folder in C directory and now open the ghost_toolbox.cmd as admin or use ghost toolbox updater.exe <br>
