﻿
if ( $Ru ) { $text = 'Свои настройки PowerShell | System' }
else { $text = 'Custom PowerShell Settings | System' }

Write-Host
Write-Host " ============================================= " -ForegroundColor DarkGray
Write-Host "      $text" -ForegroundColor Green
Write-Host " ============================================= " -ForegroundColor DarkGray
Write-Host

if ( $Ru ) { $text = 'Тут может быть ваш код PowerShell, выполняющийся с правами System' }
else { $text = 'This might be your PowerShell code running under System rights.' }

Write-Host " $Text"

