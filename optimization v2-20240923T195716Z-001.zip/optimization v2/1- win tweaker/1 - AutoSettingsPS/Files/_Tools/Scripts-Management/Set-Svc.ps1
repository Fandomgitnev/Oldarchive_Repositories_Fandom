﻿
<#
.SYNOPSIS
 Настройка и/или проверка состояния служб.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Выполняет команду (настраивает) и/или делает проверку состояния или наличия службы.
 Настройка при любом уровне доступа, кроме блокированного раздела драйвером.

 Данная функция вместо командлета 'Set-Service', и выполняет действия, предназначенные для нее.
 Определяется тип: служба или драйвер. Если не служба, то будет пропуск.

 Используется функция Set-Reg для установки параметров реестра в разделе для служб и драйверов, независимо от доступа.
 Используется функция Show-Result для отображения результата в нужном виде.
 Используется функция Token-Impersonate для олицетворения за TrustedInstaller,
 но только если указано остановить службу, а доступа на остановку нет,
 будет попытка сделать под олицетворением.

 Выполняет команды или делает проверку параметра,
 через методы в RegistryKey [Microsoft.Win32.Registry]
 и ServiceController [System.ServiceProcess.ServiceController] из .NET,
 так как общее выполнение быстрее минимум в 2 раза,
 чем стандартными командлетами + есть дополнительные возможности.

 Добавлена возможность установки автоматического отложенного запуска.

 Нельзя использовать маски '*', кроме одного варианта, будут поняты буквально,
 в том числе все фильтры и т.д. Любые хитрые варианты используем оригинальными командлетами!

 Добавлены возможности: Применить, а затем проверить или только проверить.

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.PARAMETER Name
 Понимает только реальное имя службы, никаких отображаемых имен.

.PARAMETER OrigCmdlet
 Указывает выполнить настройку службы оригинальным командлетом Set-Service
 Необходимо в некторых случаях, когда система обратно включает службу, при настройке через реестр.

.INPUTS
 Строка с командой для стандартного командлета 'Set-Service' + добавлена возможность установить 'DelayedAuto'.

.EXAMPLE
    Set-Svc -Do:$Act Set-Service -Name spooler -StartupType DelayedAuto -Status Running

    Описание
    --------
    Если $Act = 'Set' Попытается Установить Отложенный Автозапуск и запустить службу spooler.
    С выводом результата и скрытием ошибок при выполнении,
    Если $Act = 'Check', только проверит.

.EXAMPLE
    Set-Svc -Do Set Set-Service -Name UnistoreSvc -StartupType Disabled

    Описание
    --------
    Попытается Установить тип запуска 'Отключено' у службы UnistoreSvc.
    С выводом результата, и скрытием ошибок при выполнении, кроме прерывающих.

.EXAMPLE
    Set-Svc -Do Set Set-Service -Name UnistoreSvc -Status Stopped


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия:  1.0
       Дата:  11-10-2018
 ==================================================

#>
Function Set-Svc {

    [CmdletBinding( SupportsShouldProcess = $false )] 
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [ValidateSet( 'Set-Service' )]
        [string] $Cmdlet
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1 )]
        [Alias( 'Name', 'SN' )]
        [string] $ServiceName
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'All' )]
        [Alias( 'StartMode', 'SM', 'ST' )]
        [ValidateSet( 'DelayedAuto', 'Automatic', 'Manual', 'Disabled' )]
        [string] $StartupType
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'All' )]
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Status' )]
        [ValidateSet( 'Running', 'Stopped' )]
        [string] $Status
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $OrigCmdlet    # Настройка командлетом Set-Service
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( $Do -eq 'Default' ) { $Do = 'Set' }

        # Перехват ошибок, только прерываемых исключений, в блоке Begin, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionSVC'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Получение команды действия для отображения, при необходимости.
        [string] $ActionSVC = ($MyInvocation.Line.Replace($NameThisFunction,'') -Replace '(\s*-Do[:]?\s*[^\s]*\s*)',' '
                              ).Replace('$Name',        "'$ServiceName'"          # Замена на значение вместо переменной '$Name'
                              ).Replace('$_.Name',      "'$ServiceName'"          # Замена на значение вместо переменной '$_.Name'
                              ).Replace('$StartupType', "'$StartupType'"          # Замена на значение вместо переменной '$StartupType'
                              ).Replace('$Status',      "'$Status'").Trim()       # Замена на значение вместо переменной '$Status'

        Write-Verbose "Команда:`n $ActionSVC"

        # Создаем хэш-таблицу $ShowResult, с возможностью изменять ее во внутренних временных функциях.
        # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
        Set-Variable -Name ShowResult -Value @{} -Option AllScope -Force
        $ShowResult['Do']   = $Do
        $ShowResult['Type'] = '{0}' -f $(if ( $L.s2 ) { $L.s2 } else { "Служба" })
        $ShowResult['Info'] = "$ActionSVC | $ServiceName"

        # Также добавляем тип ServiceProcess из .NET к текущему сеансу, для управления службами.
        if ( -not ( 'System.ServiceProcess.ServiceController' -as [type] )) { Add-Type -AssemblyName 'System.ServiceProcess' -ErrorAction Stop }

        # Пробуем подключение к службе.
        $Service = [System.ServiceProcess.ServiceController]::new($ServiceName)

        # Если контроллер служб получил пустые данные в любом из 3 параметров
        if (( -not $Service.Name ) -or ( -not [string] $Service.StartType ) -or ( -not $Service.Status ))
        {
            Write-Verbose "Служба: '$ServiceName' не существует!"

            [bool] $NotExist = $true ; Return
        }
        elseif (( -not $Service.ServiceType ) -or ( [string] $Service.ServiceType -like '*Driver*' ))
        {
            Write-Verbose "Это не Служба: '$ServiceName'"

            [bool] $NotExist = $true ; Return
        }

        # Указываем раздел служб и драйверов в реестре.
        [string] $Root = 'HKLM:'
        [string] $ServicePath = 'SYSTEM\CurrentControlSet\Services'
    }

    Process
    {
        # Перехват ошибок, только прерываемых исключений, в блоке Process, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionSVC'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Если нужно выйти или выполнить только проверку, переходим в End.
        if ( $Exit ) { Return }
        elseif (( $Do -eq 'Check' ) -or $NotExist ) { $isAct = '(Только проверено)' ; Return } else { $isAct = "(Выполнено, затем проверено)" }

        Write-Verbose "Выполняем настройку: '$Do'"

        # DelayedAuto = 2  (Delayed  =  DelayedAutoStart Dword 1)
        # Automatic   = 2
        # Manual      = 3
        # Disabled    = 4

        # Если указано настроить службу
        if ( $StartupType )
        {
            Write-Verbose "Настраиваем службу на '$StartupType'"

            [string] $Path = "$Root\$ServicePath\$ServiceName"

            if ( $OrigCmdlet ) { if ( $Service ) { $Service.Close() } }

            # Устанавливаем параметр в реестре, согласно указанному типу запуска.
            if ( $StartupType -eq 'DelayedAuto' )
            {
                if ( $OrigCmdlet ) { Set-Service -Name $ServiceName -StartupType Automatic -ErrorAction SilentlyContinue }
                
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 2
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'DelayedAutoStart' -Type DWord -Value 1
            }
            elseif ( $StartupType -eq 'Automatic' )
            {
                if ( $OrigCmdlet ) { Set-Service -Name $ServiceName -StartupType Automatic -ErrorAction SilentlyContinue }
                
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 2
                Set-Reg -NoCheck Remove-ItemProperty -Path $Path -Name 'DelayedAutoStart'
            }
            elseif ( $StartupType -eq 'Manual' )
            {
                if ( $OrigCmdlet ) { Set-Service -Name $ServiceName -StartupType Manual -ErrorAction SilentlyContinue }
                
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 3
            }
            elseif ( $StartupType -eq 'Disabled' )
            {
                if ( $OrigCmdlet ) { Set-Service -Name $ServiceName -StartupType Disabled -ErrorAction SilentlyContinue }
                
                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name 'Start' -Type DWord -Value 4
            }

            if ( $OrigCmdlet ) { $Service = [System.ServiceProcess.ServiceController]::new($ServiceName) }
        }

        # Если указано изменить состояние службы.
        if ( $Status )
        {
            if ( $Status -eq 'Running' ) { try { Write-Verbose "Запускаем службу" ; $Service.Start() } catch { Write-Verbose "Ошибка запуска" } }
            else
            {
                Write-Verbose "Останавливаем службу"

                try { $Service.Stop() }
                catch
                {
                    Write-Verbose "Не получилось остановить"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Пробуем еще раз"

                    try { $Service.Stop() }
                    catch
                    {
                        Write-Verbose "Не остановилась служба"
                    }
                    finally { Token-Impersonate -Reset }
                }
            }

            # Ожидание результата остановки, но не более 3 сек.
            [int] $WaitCount = 0
            do
            {
                try { $Service.Refresh() } catch {}
                Start-Sleep -Milliseconds 100
                $WaitCount++
            }
            until (( $Service.Status -notlike '*Pending*' ) -or ( $WaitCount -ge 30 ))
        }
    }

    End
    {
        # Перехват ошибок, только прерываемых исключений, в блоке End, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Ошибка в End" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionSVC'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выйти при ошибке.
        if ( $Exit )
        {
            # Освобождаем ресурсы контроллера служб.
            if ( $Service ) { $Service.Close() }

            Return  # выходим из функции
        }
        elseif ( $NotExist )
        {
            # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
            Show-Result @ShowResult

            # Освобождаем ресурсы контроллера служб.
            if ( $Service ) { $Service.Close() }

            Return  # выходим из функции
        }

        Write-Verbose "Начало проверки. Действие: '$Do'"

        [int] $isStartupType = $isDelayedValue = 0

        try { $isStartupType  = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                                "$ServicePath\$ServiceName",'ReadSubTree','QueryValues').GetValue('Start',0) } catch {}

        try { $isDelayedValue = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                                "$ServicePath\$ServiceName",'ReadSubTree','QueryValues').GetValue('DelayedAutoStart',0) } catch {}

        if (( 2 -eq $isStartupType ) -and ( 1 -eq $isDelayedValue )) { $isStartupType = 1 }

        # Получаем отображаемое имя службы.
        [string] $DisplayName = $Service.DisplayName

        [string] $isStatus = $Service.Status

        # Освобождаем ресурсы контроллера служб.
        if ( $Service ) { $Service.Close() }

        [string] $StateSVC = ''

        # Указываем параметр для реестра, согласно указанному типу запуска.
        if     ( 1 -eq $isStartupType ) { [string] $isStartupType = 'DelayedAuto' ; $StateSVC = '{0}' -f $(if ( $L.s6 ) { $L.s6 } else { "Авто-Отлож" }) }
        elseif ( 2 -eq $isStartupType ) { [string] $isStartupType = 'Automatic'   ; $StateSVC = '{0}' -f $(if ( $L.s7 ) { $L.s7 } else { "Авто"       }) }
        elseif ( 3 -eq $isStartupType ) { [string] $isStartupType = 'Manual'      ; $StateSVC = '{0}' -f $(if ( $L.s8 ) { $L.s8 } else { "Вручную"    }) }
        elseif ( 4 -eq $isStartupType ) { [string] $isStartupType = 'Disabled'    ; $StateSVC = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { "Отключена"  }) }

        if ( -not $StateSVC )
        {
            # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
            Show-Result @ShowResult

            Return  # выходим из функции
        }
        elseif ( $StartupType )
        {
             [array] $PossibleNames = @()
            [string] $SvcObjectName = $null

            try { $PossibleNames += ([Security.Principal.SecurityIdentifier]'S-1-5-32-546').Translate([Security.Principal.NTAccount]).Value -replace ('.*\\','') } catch {}  # Гости, Guests и тд
            try { $PossibleNames += ([System.Security.Principal.SecurityIdentifier]"$([Security.Principal.WindowsIdentity]::GetCurrent().Groups.AccountDomainSid.Value)-501").Translate([System.Security.Principal.NTAccount]).Value -replace ('.*\\','') } catch {}  # Гость, Guest и тд
            try { $SvcObjectName = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$ServicePath\$ServiceName",'ReadSubTree','QueryValues').GetValue('ObjectName',$null) } catch {}  # От кого Запуск службы 

            if ( $SvcObjectName -and $PossibleNames.Where({ $SvcObjectName -like "*$_" }) )
            {
                $SvcObjectName = "{0}: $SvcObjectName" -f $(if ( $L.s5 ) { $L.s5 } else { "Заблокирована, запуск от" })

                # Выводим полностью совпавшие полученные: 'Имя службы' [тип запуска] (Отображаемое имя).
                Write-Verbose "Заблокирована '$ServiceName' [$isStartupType] | $DisplayName"

                $ShowResult['Result'] = '+'
                $ShowResult['Status'] = $StateSVC
                $ShowResult['Info']   = "$ServiceName [$isStatus] | $SvcObjectName | $ActionSVC | $DisplayName"

                [bool] $ResultFunc = $true
            }
            elseif ( $StartupType -eq $isStartupType )
            {
                # Если все совпадает.

                # Выводим полностью совпавшие полученные: 'Имя службы' [тип запуска] (Отображаемое имя).
                Write-Verbose "Все совпадает с '$ServiceName' [$isStartupType] | $DisplayName"

                $ShowResult['Result'] = '+'
                $ShowResult['Status'] = $StateSVC
                $ShowResult['Info']   = "$ServiceName [$isStatus] | $ActionSVC | $DisplayName"

                [bool] $ResultFunc = $true
            }
            else
            {
                Write-Verbose "`nНе совпадает: `n   Проверили: '$ServiceName' [$StartupType] | $DisplayName`n    Получили: '$ServiceName' [$isStartupType] | $DisplayName"

                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = $StateSVC
                $ShowResult['Info']   = "$ServiceName [$isStatus] | $ActionSVC | $DisplayName"

                [bool] $ResultFunc = $false
            }
        }
        elseif ( $Status )
        {
            # Если статус совпадает.
            if ( $Status -eq $isStatus )
            {
                # Выводим полностью совпавшие полученные: 'Имя службы' [тип статуса] (Отображаемое имя).
                Write-Verbose "Все совпадает с '$ServiceName' [$isStatus] | $DisplayName"

                $ShowResult['Result'] = '+'
                $ShowResult['Status'] = $isStatus
                $ShowResult['Info']   = "$ServiceName [$isStatus] | $ActionSVC | $DisplayName"

                [bool] $ResultFunc = $true
            }
            else
            {
                Write-Verbose "`nНе совпадает: `n   Проверили: '$ServiceName' [$Status] | $DisplayName`n    Получили: '$ServiceName' [$isStatus] | $DisplayName"

                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = $isStatus
                $ShowResult['Info']   = "$ServiceName [$isStatus] | $ActionSVC | $DisplayName"

                [bool] $ResultFunc = $false
            }
        }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo   [Параметр правильный]  $isAct"
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр неверный]  $isAct"
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult
    }
}
