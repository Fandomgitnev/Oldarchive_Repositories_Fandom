﻿
<#
.SYNOPSIS
 Проверка задач на состояние, наличие, блокировки, наличие скрытого параметра MaintenanceSettings,
 и вывод результата в нужном виде.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Используется ComObject Schedule.Service для универсальной проверки состояния (а не статуса!) задачи (включена/отключена).
 Этот метод очень быстрый. От языка системы не зависит. (Через командлет очень медленно).

 Скрытый параметр MaintenanceSettings привязывает задачу к Автообслуживанию системы и выполняет такую задачу
 во время автообслуживания. И запрещает выполнять такую задачу при отключенном автообслуживании системы, даже вручную.

 Проверка блокировки рассчитана на проверку блокирована от изменения задача или нет.
 Блокировка выполняется через функцию Set-TaskAccess на раздел реестра задачи.

.EXAMPLE

    Check-State-Task '\Task' -Need Enabled -Return Bool

    Описание
    --------
    Проверить включена ли задача, вывод сделать в bool, результат относительно необходимости во включённом состоянии.
    Будет true, если есть и включена, в остальных случаях false.
    Если сделать относительно отключенного состояния -Need Disabled, то вывод будет противоположным,
    если есть и отключена, то будет true, в остальных случаях false.


.EXAMPLE

    Check-State-Task '\Task' -CheckExist -Return Bool

    Описание
    --------
    Проверить существует ли задача, вывод сделать в bool.
    Будет true, если есть, в остальных случаях false.


.EXAMPLE

    Check-State-Task '\Task' -CheckMaintenance -Return bool

    Описание
    --------
    Проверить существует ли скрытый параметр MaintenanceSettings у задачи, вывод сделать в bool.
    Будет true, если есть, в остальных случаях false.
    Если вывод сделать в Result, он по умолчанию, то,
    если есть параметр у задачи, вывод будет 2 символа: '► ', если нет параметра, вывод будет пустой: ''
    Рассчитано на вывод перед запросом вывода состояния задачи. Но символы будут с параметрами расскраски: '#Blue#► #'


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  04-02-2019
 ===============================================

#>
Function Check-State-Task {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string],[bool])]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [string] $TaskName
       ,
        [Parameter( Mandatory = $false )]
        [string] $TaskPath
       ,
        [Parameter( Mandatory = $true,  Position = 1, ParameterSetName = 'State' )]
        [ValidateSet( 'Enabled', 'Disabled' )]
        [string] $Need = 'Enabled'
       ,
        [Parameter( Mandatory = $false, Position = 2, ParameterSetName = 'State' )]
        [ValidateSet( 'Enabled', 'Disabled' )]
        [string] $Default   # Параметр по умолчанию, Нужен только для информации, истории.
       ,
        [Parameter( Mandatory = $false, Position = 3, ParameterSetName = 'State' )]
        [ValidateSet( 'Lock', 'UnLock' )]
        [string] $CheckLock
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Exist' )]
        [switch] $CheckExist
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Maintenance' )]
        [switch] $CheckMaintenance
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Result', 'Value', 'Bool' )]
        [string] $Return = 'Result'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Получаем строку с путем и именем к задаче и полный путь к файлу задачи.

    $TaskName = $TaskName.Trim('\ ')
    $TaskPath = $TaskPath.Trim('\ ')

    if ( -not $TaskName )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Имя задачи не указано или неверно указано" }
        Write-Warning "$NameThisFunction`: $text"

        Return    # Выход из функции
    }

    # Трим снова, так как путь может быть пустым, а разделителей по карям в данный момент не должно быть для указания файла.
    $TaskPathName = "$TaskPath\$TaskName".Trim('\')

    $TaskFile     = "$env:SystemRoot\System32\Tasks\$TaskPathName"
    $TaskPathName = "\$TaskPathName"

    $isTaskState = $null
    [string] $StateTSK    = '#Red#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { "Ошибка     " })
    [string] $ColorTsk    = 'DarkGray'
    [string] $isBlock     = ''
      [bool] $ResultState = $false

    # Внутренняя функция по поиску раздела задачи в реестре, по параметру Path значению: '\Путь\Имя'.
    Function Get-TaskRegKey {
            
        try
        {
            $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
            $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')
        }
        catch { $OpenRegKey = $null }
            
        if ( $OpenRegKey )
        {
            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
            {
                try
                {
                    $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                    if ( $OpenSubKey )
                    {
                        if ( $OpenSubKey.GetValue('Path',$null) -eq $TaskPathName )
                        {
                            # Передаем результат - найденный раздел реестра задачи, без RootKey и останавливаем дальнейший поиск.
                            "$RegKeyTasks\$SubKey"

                            $OpenSubKey.Close()
                            break
                        }

                        $OpenSubKey.Close()
                    }
                }
                catch {}
            }

            $OpenRegKey.Close()
        }
    }

    [string] $TaskRegKey = Get-TaskRegKey

    # Если раздел реестра и файл задачи существует.
    if (( $TaskRegKey ) -and (Test-Path -LiteralPath $TaskFile -PathType Leaf -ErrorAction SilentlyContinue ))
    {
        if ( $CheckExist )
        {
            [string] $StateTSK = '#DarkGray#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { "Существует " })

            if ( $Return -eq 'Result' ) { $StateTSK } else { $true }

            Return
        }

        $TaskState = $null
        $TaskMaintenance = $null

        try
        {
            [psobject] $ScheduleService = New-Object -ComObject Schedule.Service
            $ScheduleService.Connect()
            $GetTask = $ScheduleService.GetFolder("\$TaskPath").GetTask($TaskName)
            [bool] $TaskState = $GetTask.Enabled
            [bool] $TaskMaintenance = $GetTask.Xml -like '*MaintenanceSettings*'
        }
        catch {}

        if ( $CheckMaintenance )
        {
            if ( $TaskMaintenance )
            {
                [string] $StateTSK = ''

                if ( $Return -eq 'Result' ) { $StateTSK } else { $true }
            }
            else
            {
                [string] $StateTSK = '#Blue#► #'

                if ( $Return -eq 'Result' ) { $StateTSK } else { $false }
            }

            Return
        }

        if     (  $true -eq $TaskState ) { [string] $isTaskState = 'Enabled'  }
        elseif ( $false -eq $TaskState ) { [string] $isTaskState = 'Disabled' }
    }
    else
    {
        [string] $StateTSK = '#DarkGray#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { "Отсутствует" })

        if ( $CheckExist )
        {
            if ( $Return -eq 'Result' ) { $StateTSK } else { $false }

            Return
        }

        if ( $CheckMaintenance )
        {
            $StateTSK = ''

            if ( $Return -eq 'Result' ) { $StateTSK } else { $false }

            Return
        }

        if ( $Return -eq 'Result' ) { "$StateTSK$isBlock" }
        elseif ( $Return -eq 'Value' ) { $isTaskState }
        else { $ResultState }

        Return
    }

    if ( $isTaskState -eq $Need ) { $ResultState = $true } else { $ResultState = $false }

    if ( $CheckLock )
    {
        [string] $TaskSddl   = ''

        if ( $TaskRegKey )
        {
            try { $TaskSddl = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($TaskRegKey,'ReadSubTree','QueryValues').GetAccessControl().Sddl } catch {}
        }

        if ( -not $TaskSddl )
        {
            $isBlock = ' #Red#{0}#' -f $(if ( $L.s5 ) { $L.s5 } else { "(SDDL не получен)" })

            $ResultState = $false
        }
        elseif ( $TaskSddl -like "*(D;CI;DCLCWPSDRCWDWO;;;WD)*" )  # Проверка наличия запрета (запрета всего, кроме чтения для Группы "Все").
        {
            $isBlock = ' #Green#{0}#' -f $(if ( $L.s6 ) { $L.s6 } else { "(Заблокирована)" })

            if ( $CheckLock -eq 'Lock' ) { $ResultState = $true } else { $ResultState = $false }
        }
        else
        {
            $isBlock = ' #DarkGray#{0}#' -f $(if ( $L.s7 ) { $L.s7 } else { "(Не заблокирована)" })

            if ( $CheckLock -eq 'Lock' ) { $ResultState = $false } else { $ResultState = $true }
        }
    }

    if     ( $isTaskState -eq $Need    ) { $ColorTsk = 'Green'  }
    elseif ( $isTaskState -eq $Default ) { $ColorTsk = 'Yellow' }

    if     ( $isTaskState -eq 'Enabled'  ) { $StateTSK = "#$ColorTsk#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { "Включена   " }) }
    elseif ( $isTaskState -eq 'Disabled' ) { $StateTSK = "#$ColorTsk#{0}#" -f $(if ( $L.s9 ) { $L.s9 } else { "Отключена  " }) }

    if     ( $Return -eq 'Result' ) { [string] "$StateTSK$isBlock" }
    elseif ( $Return -eq 'Value'  ) { [string] $isTaskState }
    else { [bool] $ResultState }
}
