﻿
<#
.SYNOPSIS
 Назначение владельцев на файлы, папки или разделы реестра
 на любого указанного пользователя или группу. С возможностью добавления
 для них разрешения с полным доступом, или восстановления всех прав из SDDL.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.

 Дает текущему процессу привилегии "SeTakeOwnershipPrivilege", "SeRestorePrivilege" и "SeBackupPrivilege",
 которые позволяют получить доступ к любому объекту и назначать любого владельца на этот объект.
 Затем назначается владелец, и далее по выбору:
 разрешение "FullControl" или строка "SDDL" с полными параметрами безопасности.
 В конце отключение выданных привилегий, с возможностью не отключать.

.PARAMETER Path
 Единственный обязательный параметр. Должен идти первым.
 Путь к объекту, которому вы хотите изменить владельца и право доступа.
 Это может быть файл, папка или раздел реестра.
 Все пути обрабатываются по принципу 'LiteralPath',
 Поэтому путь может содержать любые символы. Параметр -Path всегда заменяется на -LiteralPath.

.PARAMETER User
 Строка. Группа или пользователь, которого вы хотите назначить владельцем указанного объекта.
 Должны быть в форматах: <Компьютер>\<Имя пользователя>, или <Имя пользователя>, или <SID>
 Для системных учетных записей, например, таких как "Система",
 можно указать как "NT AUTHORITY\Система", или "Система", но лучше универсально через SID: "S-1-5-18"
 Любые форматы будут преобразованы в NTAccount.

.PARAMETER Recurse
 Заставляет функцию анализировать путь рекурсивно,
 то есть обрабатывать также и все вложенные объекты.

.PARAMETER ExcludeParent
 Заставляет функцию пропускать родительский объект и обрабатывать только вложенные объекты.
 Учитывается только вместе с параметром -Recurse.
 Если в конце указанного пути присутствуют символы "\*",
 то -Recurse вместе с -ExcludeParent будет использовано автоматически.

.PARAMETER SetFullAccess
 Сообщает функции, что дополнительно к назначению владельцем,
 нужно установить разрешение с полным доступом для указанного пользователя или группы.
 Права с полным доступом добавляются с удалением всех правил для этого субъекта.
 Во время применения также сбрасывает все указанные явно запреты для группы "Все".
 Не даст выполниться вместе с "-RecoverySDDL", так как бессмысленно.
 Псевдоним -FullAccess

.PARAMETER RecoverySDDL
 Строка с набором параметров безопасности объекта в формате SDDL.
 В которую могут входить не только разрешения, но и владелец и др.
 Не даст выполниться вместе с "-SetFullAccess", так как бессмысленно.
 Получить SDDL можно например так: $Sddl = (Get-Item -LiteralPath $path -Force).GetAccessControl().Sddl
 или так: $Sddl = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues').GetAccessControl().Sddl
 Можно в строке с SDDL использовать любые переносы строк, они уберутся.
 Псевдоним -SDDL

.EXAMPLE
    Set-OwnerAndAccess -Path "HKLM:\SOFTWARE\1"

    Описание
    --------
    Изменяет владельца у "HKLM\SOFTWARE\1" на указанную по умолчанию "группу Администраторы".
    Без рекурсии и вывода подробной информации.

.EXAMPLE
    Set-OwnerAndAccess -Path "Registry::HKLM\SOFTWARE\[1]222" -User "NT SERVICE\TrustedInstaller" -Recurse -Verbose

    Описание
    --------
    Изменяет владельца у раздела "HKLM\SOFTWARE\[1]222" и его подразделов на "TrustedInstaller".
    Выводя подробную информацию.

.EXAMPLE
    Set-OwnerAndAccess -Path "D:\0[555].txt" -User $user

    Описание
    --------
    Изменяет владельца у файла "D:\0[555].txt" на:
    Если задать переменную: $user = "$env:COMPUTERNAME\$env:USERNAME", на "Имя текущего пользователя"
    Если задать переменную: $user = "S-1-5-18", на Группу "NT AUTHORITY\System"
    Без рекурсии и вывода подробной информации.

.EXAMPLE
    Set-OwnerAndAccess -Path "D:\1" -User $env:USERNAME -Recurse -SetFullAccess

    Описание
    --------
    Изменяет владельца и устанавливает права на полный доступ к папке "D:\1"
    и всех ее подпапок и файлов для "Имя текущего пользователя"
    Без вывода подробной информации.

.EXAMPLE
    Set-OwnerAndAccess -Path "HKLM:\SOFTWARE\1" -RecoverySDDL $SDDL -Verbose

    Описание
    --------
    Изменяет владельца у раздела "HKLM\SOFTWARE\1" на указанную по умолчанию "группу Администраторы".
    А затем заменяет все параметры безопасности, включая владельца, из указанной строки $SDDL.
    Если указать рекурсию, то у всех объектов будут одинаковые права, которые содержатся в указанном SDDL!
    С выводом подробной информации.

.NOTES
 ================================================
     Автор:  westlife (ru-board)   Версия 1.0
      Дата:  01-09-2018
 ================================================

#>
Function Set-OwnerAndAccess {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [ValidateNotNullOrEmpty()]
        [string] $Path
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [ValidateNotNullOrEmpty()]
        [string] $User = 'S-1-5-32-544'  # По умолчанию указана "группа Администраторы"
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $Recurse
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $ExcludeParent
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'FullAccess' )]
        [Alias( 'FullAccess' )]
        [switch] $SetFullAccess
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'SDDL' )]
        [Alias( 'SDDL' )]
        [ValidatePattern( '[OD]:[\w-\d]{2}' )]
        [string] $RecoverySDDL
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Подключаем .Net code для управления привилегиями, нужны права администратора.
        $TokenManipulatorAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class TokenManipulator
    {
        [DllImport("kernel32.dll", ExactSpelling = true)]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool AdjustTokenPrivileges(IntPtr htok, bool disall, ref TokPriv1Luid newst, int len, IntPtr prev, IntPtr relen);
        [DllImport("advapi32.dll", ExactSpelling = true, SetLastError = true)]
        internal static extern bool OpenProcessToken(IntPtr h, int acc, ref IntPtr phtok);
        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool LookupPrivilegeValue(string host, string name, ref long pluid);

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        internal struct TokPriv1Luid
        {
            public int Count;
            public long Luid;
            public int Attr;
        }

        internal const int SE_PRIVILEGE_DISABLED = 0x00000000;
        internal const int SE_PRIVILEGE_ENABLED = 0x00000002;
        internal const int TOKEN_QUERY = 0x00000008;
        internal const int TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        public static bool AddPrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_ENABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            return retVal;
        }

        public static bool RemovePrivilege(string privilege)
        {
            bool retVal;
            TokPriv1Luid tp;
            IntPtr hproc = GetCurrentProcess();
            IntPtr htok = IntPtr.Zero;
            retVal = OpenProcessToken(hproc, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref htok);
            tp.Count = 1;
            tp.Luid = 0;
            tp.Attr = SE_PRIVILEGE_DISABLED;
            retVal = LookupPrivilegeValue(null, privilege, ref tp.Luid);
            retVal = AdjustTokenPrivileges(htok, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
            return retVal;
        }
    }
}
'@
        if ( -not ( 'WinAPI.TokenManipulator' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $TokenManipulatorAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        if ( $RecoverySDDL )
        {
            $SetFullAccess = $False

            # Преобразование SDDL в одну строку без любых переносов и пробелов.
            $RecoverySDDL = $RecoverySDDL -Replace ('\s','')
        }

        [bool] $Exit = $false

        try
        {
            # Пробуем преобразовать имя как SID во владельца объект NTAccount из SecurityIdentifier для назначения владельцем и доступов.
            [psobject] $Owner = ([System.Security.Principal.SecurityIdentifier]"$User").Translate([System.Security.Principal.NTAccount])
        }
        catch
        {
            # При ошибке. Пробуем преобразовать имя из формата NTAccount в объект NTAccount для назначения владельцем и доступов.
            try
            {
                [psobject] $Owner = ([System.Security.Principal.NTAccount]"$User").Translate([System.Security.Principal.SecurityIdentifier]
                                    ).Translate([System.Security.Principal.NTAccount])
            }
            catch
            {
                [psobject] $Owner = $null
            }
        }

        if ( -not $Owner )
        {
            $text = "$NameThisFunction`: {0} `$User: '$User' {1} 'NTAccount'" -f
                $(if ( $L.s2 ) { $L.s2, $L.s2_1 } else { "Ошибка. Строка", "Не преобразуется в" })

            Write-Warning "$text"

            $Exit = $true ; Return
        }

        # Если в конце указанного пути присутствуют символы "\*",
        # то это включит рекурсию и пропуск родительского объекта и уберет эти символы.
        if ( $Path -match "\\[*]\s*$" ) { $Path = $Path.TrimEnd('\* ') ; $Recurse = $true ; $ExcludeParent = $true }
    }

    Process
    {
        # Перехват ошибок в блоке Process, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выход из функции, если была установлена переменная $Exit в блоке Begin.
        if ( $Exit ) { Return }

        Write-Verbose "Выдача привилегий к токену текущего процесса: SeTakeOwnershipPrivilege, SeRestorePrivilege, SeBackupPrivilege"

        [void][WinAPI.TokenManipulator]::AddPrivilege('SeTakeOwnershipPrivilege')
        [void][WinAPI.TokenManipulator]::AddPrivilege('SeRestorePrivilege')
        [void][WinAPI.TokenManipulator]::AddPrivilege('SeBackupPrivilege')

        if ( $SetFullAccess ) { Write-Verbose "Указан владелец: '$Owner', с установкой для него разрешения с полным доступом!" }
        else { Write-Verbose "Указан владелец: '$Owner'" }

        # Начало для разделов реестра. Только для самого указанного объекта.
        # Проверка наличия и доступа к указанному объекту, если нет объекта, то выйти из функции.
        # Если есть, то получить доступ из расчета указанных параметров.
        # Такая сложность для того, чтобы была возможность обработать указанный раздел с полным запретом всего и без какого либо доступа.
        if ( $Path -match "(?<Root>Registry::HK[\w]+\\|HKLM:\\|HKCU:\\)(?<Subkey>[^\s][^\r\n]+[^\s])" )
        {
            [string] $Root   = $matches.Root
            [string] $SubKey = $matches.Subkey

            if     ( $Root -like "*HKCU*" -or $Root -like "*HKEY_CURRENT_USER*"   ) { $RootKey = [Microsoft.Win32.Registry]::CurrentUser   ; $Path = "Registry::HKCU\$SubKey" }
            elseif ( $Root -like "*HKLM*" -or $Root -like "*HKEY_LOCAL_MACHINE*"  ) { $RootKey = [Microsoft.Win32.Registry]::LocalMachine  ; $Path = "Registry::HKLM\$SubKey" }
            elseif ( $Root -like "*HKCR*" -or $Root -like "*HKEY_CLASSES_ROOT*"   ) { $RootKey = [Microsoft.Win32.Registry]::ClassesRoot   ; $Path = "Registry::HKCR\$SubKey" }
            elseif ( $Root -like "*HKU*"  -or $Root -like "*HKEY_USERS*"          ) { $RootKey = [Microsoft.Win32.Registry]::Users         ; $Path = "Registry::HKU\$SubKey"  }
            elseif ( $Root -like "*HKCC*" -or $Root -like "*HKEY_CURRENT_CONFIG*" ) { $RootKey = [Microsoft.Win32.Registry]::CurrentConfig ; $Path = "Registry::HKCC\$SubKey" }
            else
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Раздел реестра неверный!`n   Раздел" }
                Write-Warning "$NameThisFunction`: $text`: '$Path'" ; Return
            }

            # Получение раздела реестра через открытие с доступом на изменение владельца, а после и права безопасности можно изменить.
            try { $Item = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree','TakeOwnership') }
            catch
            {
                $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Раздел реестра заблокирован!`nРаздел" }
                Write-Host "$text`: $Path" -ForegroundColor Yellow

                # Переход в блок End.
                Return
            }

            # Если нет раздела выйти из функции.
            if ( -not $Item )
            {
                $text = if ( $L.s5 ) { $L.s5 } else { "Раздел реестра не существует!`nРаздел" }
                Write-Host "$text`: $Path" -ForegroundColor Yellow

                # Переход в блок End.
                Return
            }

            # Получение полного пути для вывода информации.
            $ItemName = $Item.Name.TrimEnd("\")

            # Если указано пропустить родительский объект.
            if ( $ExcludeParent )
            {
                # Если включена рекурсия.
                if ( $Recurse )
                {
                    $Error.Clear()

                    # Проверка раздела на полный доступ.
                    try { $TestFullAccess = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree','FullControl') } catch {}

                    # Если доступа нет.
                    if ( $Error )
                    {
                        $text = if ( $L.s6 ) { $L.s6 } else { "Нельзя исключить родительский раздел реестра, `n   так как к нему нужно получить доступ!`n   Раздел" }
                        Write-Warning "$NameThisFunction`: $text`: $Path"

                        # Переход в блок End.
                        Return
                    }

                    Write-Verbose "Пропуск родительского объекта!"
                }
                else
                {
                    Write-Verbose "Выполнять не чего, один объект и он пропущен!"
                }
            }
            else   # Если не нужно пропускать родительский объект.
            {
                # Применение к объекту владельца нужно вначале, так как без этого не будет доступа к изменениям правил.
                Write-Verbose "Установка владельца на  '$ItemName'"
                $ACL = [System.Security.AccessControl.RegistrySecurity]::new()
                $ACL.SetOwner($Owner)
                $ACL.SetGroup($Owner)
                try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }

                # Если указано получение полного доступа.
                if ( $SetFullAccess.IsPresent )
                {
                    # Получаем параметры доступа из объекта.
                    $ACL = $Item.GetAccessControl()

                    # Создаем правило для владельца с полным доступом.
                    $RuleAccess = New-Object Security.AccessControl.RegistryAccessRule(
                        $Owner,
                        "FullControl",
                        "ContainerInherit",
                        "None",
                        "Allow"
                    )

                    # Создаем правило для группы "Все" с запрещающим типом.
                    # Нужно для сброса запрещающих правил у этой группы. Играют роль только имя и тип правила.
                    $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.RegistryAccessRule(
                        [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                        "SetValue",
                        "ContainerInherit",
                        "None",
                        "Deny"
                    )

                    # Заменяем все правила для владельца на полный доступ и удаляем все запрещающие для группы "Все".
                    Write-Verbose "Установка разрешения на '$ItemName'"
                    $ACL.ResetAccessRule($RuleAccess)
                    $ACL.RemoveAccessRuleAll($RuleDenyForEveryOneGroup)
                    try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                }
                elseif ( $RecoverySDDL )
                {
                    # Заменяет все параметры безопасности у объекта из SDDL, включая владельца и т.д. (если SDDL полный).
                    Write-Verbose "Применение прав SDDL к  '$ItemName'"
                    $ACL.SetSecurityDescriptorSddlForm($RecoverySDDL)
                    try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                }
            }

            # После изменения открытый раздел нужно закрыть для сохранения (разблокировать), для системных нет необходимости.
            $Item.Close()
            $Provider = 'Registry'
            $IsContainer = $true
        }

        # Начало для файловой системы. Только для самого указанного объекта.
        # Проверка наличия и доступа к указанному объекту, если нет объекта или доступа, то выйти из функции.
        # Если есть, то получить доступ из расчета указанных параметров.
        else
        {
            # Проверка наличия объекта, если его нет или нет доступа выйти из функции.
            try { $Item = Get-Item -LiteralPath FileSystem::$Path -Force -ErrorAction Stop }
            catch
            {
                if ( $_.CategoryInfo.Category -eq 'ObjectNotFound' )
                {
                    Write-Verbose "   $NameThisFunction`: Нет объекта: $Path"
                }
                else
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { "Нет Доступа у объекту" }
                    Write-Warning "   $NameThisFunction`: $text`: $Path"
                }

                Return   # Переход в блок End
            }

            # Получаем имя провайдера. Ожидается как "FileSystem".
            $Provider = $Item.PSProvider.Name

            # Если объект контейнер (папка) создаем переменную, что объект контейнер.
            if ( $Item.PSIsContainer ) { $IsContainer = $true }

            # Если объект контейнер (папка)
            if ( $IsContainer )
            {
                # Создаем пустой объект для параметров безопасности. Его достаточно если нужно только сменить владельца.
                $ACL = [System.Security.AccessControl.DirectorySecurity]::new()

                # Если указано и получить полный доступ.
                if ( $SetFullAccess.IsPresent )
                {
                    # Получаем параметры безопасности из объекта.
                    $ACL = $Item.GetAccessControl()

                    # Создаем правило для владельца с полным доступом для папок.
                    $RuleAccess = New-Object Security.AccessControl.FileSystemAccessRule(
                        $Owner,
                        "FullControl",
                        "ContainerInherit",
                        "None",
                        "Allow"
                    )

                    # Создаем правило для группы "Все" с запрещающим типом.
                    # Нужно для сброса запрещающих правил у этой группы. Играют роль только имя и тип правила.
                    $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.FileSystemAccessRule(
                        [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                        "Write",
                        "ContainerInherit",
                        "None",
                        "Deny"
                    )
                }
            }

            # если не контейнер (если не папка, а файл).
            else
            {
                # Создаем пустой объект для параметров безопасности. Его достаточно если нужно только сменить владельца.
                $ACL = [System.Security.AccessControl.FileSecurity]::new()

                # Если указоно и получение полного доступа.
                if ( $SetFullAccess.IsPresent )
                {
                    # Получаем параметры безопасности из объекта.
                    $ACL = $Item.GetAccessControl()

                    # Создаем правило для владельца с полным доступом для файлов.
                    $RuleAccess = New-Object Security.AccessControl.FileSystemAccessRule(
                        $Owner,
                        "FullControl",
                        "Allow"
                    )

                    # Создаем правило для группы "Все" с запрещающим типом для файлов.
                    # Нужно для сброса запрещающих правил у этой группы. Играют роль только имя и тип правила.
                    $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.FileSystemAccessRule(
                        [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                        "Write",
                        "Deny"
                    )
                }

                # Если указан пропуск родительского объекта при указании файла.
                if ( $ExcludeParent.IsPresent )
                {
                    $text = "$NameThisFunction`: {0}: $Path. {1}" -f $(if ( $L.s7 ) { $L.s7, $L.s7_1 } else { "Указан файл", "Родительский объект пропущен не будет!" })

                    Write-Warning "$text"
                }
            }


            # Применить, если не контейнер с пропуском родительского объекта.
            # То есть применять для файлов и контейнеров без пропуска родительского объекта.
            if ( -not ( $IsContainer -and $ExcludeParent.IsPresent ))
            {
                Write-Verbose   "Назначение владельца на '$Path'"
                $ACL.SetOwner($Owner)
                $ACL.SetGroup($Owner)
                try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }

                if ( $SetFullAccess ) {
                    Write-Verbose "Установка разрешения на '$Path'"
                    $ACL.ResetAccessRule($RuleAccess)
                    $ACL.RemoveAccessRuleAll($RuleDenyForEveryOneGroup)
                    try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                }
                elseif ( $RecoverySDDL ) {
                    Write-Verbose "Применение прав SDDL к  '$Path'"
                    $ACL.SetSecurityDescriptorSddlForm($RecoverySDDL)
                    try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                }
            }
            else
            {
                Write-Verbose "Родительский объект пропущен!"
            }
        }

        # Далее только если указана рекурсия !!!!!!!!!!!!!!!

        if ( $Recurse.IsPresent )
        {
            if ( $IsContainer )
            {
                Write-Verbose "Применяется рекурсия"

                $Error.Clear()

                # Получаем все вложенные объекты указанного пути,
                # исключая "параметры" реестра, так как настройки безопасности только у разделов (контейнеров).
                # Если у вложенных будут персональные ограничения, то к ним доступ не получить, нужно указывать их персонально.
                if ( $Provider -eq "Registry" )
                {
                    $Items = Get-ChildItem -LiteralPath $Path -Recurse -Force -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer }
                }
                else
                {
                    $Items = Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue | Sort-Object
                }

                if ( $Error.CategoryInfo.Category -like 'PermissionDenied' )
                {
                    $text = if ( $L.s8 ) { $L.s8 } else { "Пропущены объекты из рекурсии через Get-ChildItem, нет доступа!`n   Для их разблокировки нужно указать их персонально" }
                    Write-Warning "$NameThisFunction`: $text`:"

                    for ( $i = 0 ; $i -lt $Error.Count ; $i++ )
                    {
                        if ( $Error[$i].CategoryInfo.Category -like 'PermissionDenied' )
                        {
                            $text = if ( $L.s9 ) { $L.s9 } else { "Объект" }
                            Write-Warning "$text`: '$($Error[$i].TargetObject)'"
                        }
                    }
                }

                if ( $Items.Count -eq 0 )
                {
                    Write-Verbose "Родительский объект пустой. Нет вложенных объектов для обработки!"
                }

                # Выполнение рекурсии, если есть хотябы один вложенный объект.
                for ( $i = 0 ; $i -lt $Items.Count ; $i++ )
                {
                    # Выполнение действий в зависимости от типа объекта: файловый или реестр.
                    switch ( $Provider ) {

                        "FileSystem" {
                                        # Если файловая истема.

                                        $Item = Get-Item -LiteralPath $Items[$i].FullName -Force -ErrorAction SilentlyContinue

                                        if ( $Item.PSIsContainer )
                                        {
                                            $ACL = [System.Security.AccessControl.DirectorySecurity]::new()

                                            if ( $SetFullAccess.IsPresent )
                                            {
                                                try { $ACL = $Item.GetAccessControl() } catch {}

                                                $RuleAccess = New-Object Security.AccessControl.FileSystemAccessRule(
                                                    $Owner,
                                                    "FullControl",
                                                    "ContainerInherit",
                                                    "None",
                                                    "Allow"
                                                )

                                                $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.FileSystemAccessRule(
                                                    [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                                                    "Write",
                                                    "ContainerInherit",
                                                    "None",
                                                    "Deny"
                                                )
                                            }
                                        }
                                        else
                                        {
                                            $ACL = [System.Security.AccessControl.FileSecurity]::new()

                                            if ( $SetFullAccess.IsPresent )
                                            {
                                                try { $ACL = $Item.GetAccessControl() } catch {}

                                                $RuleAccess = New-Object Security.AccessControl.FileSystemAccessRule(
                                                    $Owner,
                                                    "FullControl",
                                                    "Allow"
                                                )

                                                $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.FileSystemAccessRule(
                                                    [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                                                    "Write",
                                                    "Deny"
                                                )
                                            }
                                        }

                                        $ItemName = $Item.FullName
                                     }

                        "Registry"   {
                                        # Если реестр.

                                        $Item = $Items[$i]

                                        # Get-Item или Get-ChildItem не дает доступа на изменения прав разделов реестра,
                                        # поэтому нужно открывать раздел реестра с доступом на изменение владельца или полным доступом.

                                        if ( $Item )
                                        {
                                            $Root = $Item.Name.Split("\")[0]

                                            switch ($Root) {
                                                "HKEY_CLASSES_ROOT"   { $RootKey = [Microsoft.Win32.Registry]::ClassesRoot   ; break }
                                                "HKEY_CURRENT_USER"   { $RootKey = [Microsoft.Win32.Registry]::CurrentUser   ; break }
                                                "HKEY_LOCAL_MACHINE"  { $RootKey = [Microsoft.Win32.Registry]::LocalMachine  ; break }
                                                "HKEY_USERS"          { $RootKey = [Microsoft.Win32.Registry]::Users         ; break }
                                                "HKEY_CURRENT_CONFIG" { $RootKey = [Microsoft.Win32.Registry]::CurrentConfig ; break }
                                            }

                                            $SubKey = $Item.Name.Replace("$Root\","")

                                            $Item = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree','TakeOwnership')

                                            $ACL = [System.Security.AccessControl.RegistrySecurity]::new()

                                            if ( $SetFullAccess.IsPresent )
                                            {
                                                try { $ACL = $Item.GetAccessControl() } catch {}

                                                $RuleAccess = New-Object Security.AccessControl.RegistryAccessRule(
                                                    $Owner,
                                                    "FullControl",
                                                    "ContainerInherit",
                                                    "None",
                                                    "Allow"
                                                )

                                                $RuleDenyForEveryOneGroup = New-Object Security.AccessControl.RegistryAccessRule(
                                                    [System.Security.Principal.SecurityIdentifier] "S-1-1-0",
                                                    "SetValue",
                                                    "ContainerInherit",
                                                    "None",
                                                    "Deny"
                                                )
                                            }

                                            try { $ItemName = $Item.Name.TrimEnd("\") } catch {}
                                        }
                                     }

                        default      {  Write-Verbose "Неизвестный PSProvider: $($Item.PSProvider.Name)"  }
                    }

                    # При рекурсии объект может перестать сущестовать к тому моменту, как до него дойдёт очередь обработки.
                    try
                    {
                        Write-Verbose   "Назначение владельца на '$ItemName'".Replace('\\?\','')
                        $ACL.SetOwner($Owner)
                        $ACL.SetGroup($Owner)
                        try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }

                        if ( $SetFullAccess ) {
                            Write-Verbose "Установка разрешения на '$ItemName'".Replace('\\?\','')
                            $ACL.ResetAccessRule($RuleAccess)
                            $ACL.RemoveAccessRuleAll($RuleDenyForEveryOneGroup)
                            try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                        }
                        elseif ( $RecoverySDDL ) {
                            Write-Verbose "Применение прав SDDL к  '$ItemName'".Replace('\\?\','')
                            $ACL.SetSecurityDescriptorSddlForm($RecoverySDDL)
                            try { $Item.SetAccessControl($ACL) } catch { Write-Verbose 'Set-OwnerAndAccess: Error Access (SetAccessControl)' }
                        }

                        # Если реестр, после изменения открытый раздел нужно закрыть для сохранения (разблокировать), для системных нет необходимости.
                        if ( $Provider -eq "Registry" ) { $Item.Close() }
                    }
                    catch {}
                }
            }
            else
            {
                Write-Verbose "   Указанный объект не является ни папкой, ни разделом реестра. Рекурсия невозможна."
            }
        } # Если рекурсия финиш.
    }
}
