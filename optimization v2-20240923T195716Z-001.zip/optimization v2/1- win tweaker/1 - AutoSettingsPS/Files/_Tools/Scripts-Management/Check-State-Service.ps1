﻿

# Проверка состояния служб
Function Check-State-Service {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'State' )]
    [OutputType([string],[bool])]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [Alias( 'Name' )]
        [ValidateNotNullOrEmpty()]
        [string] $ServiceName
       ,
        [Parameter( Mandatory = $false, Position = 1, ParameterSetName = 'State' )]
        [ValidateSet( 'DelayedAuto', 'Automatic', 'Manual', 'Disabled' )]
        [string] $Need
       ,
        [Parameter( Mandatory = $false, Position = 2, ParameterSetName = 'State' )]
        [ValidateSet( 'DelayedAuto', 'Automatic', 'Manual', 'Disabled' )]
        [string] $Default    # Параметр по умолчанию, Нужен только для информации, истории.
       ,
        [Parameter( Mandatory = $false, Position = 3, ParameterSetName = 'Exist' )]
        [switch] $CheckExist
       ,
        [Parameter( Mandatory = $false, Position = 4, ParameterSetName = 'Status' )]
        [switch] $CheckStatus
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Result', 'Value', 'Bool' )]
        [string] $Return = 'Result'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Также добавляем тип ServiceProcess из .NET к текущему сеансу, для управления службами.
    if ( -not ( 'System.ServiceProcess.ServiceController' -as [type] )) { Add-Type -AssemblyName 'System.ServiceProcess' -ErrorAction Stop }

    [psobject] $isStartupType  = $null
         [int] $isDelayedValue = 0
      [string] $ColorSVC       = 'Red'
      [string] $StateSVC       = '#Red#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { "Ошибка     " })
        [bool] $ResultState    = $false
               $OFS = ' '

    $Service = [System.ServiceProcess.ServiceController]::new($ServiceName)

    # Если контроллер служб получил пустые данные.
    if (( -not $Service.Name ) -or ( -not [string] $Service.StartType ) -or ( -not $Service.Status ))
    {
        [string] $StateSVC = "#DarkGray#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Отсутствует" })

        if ( $CheckExist )
        {
            if ( $Return -eq 'Result' ) { $StateSVC } else { $false }

            Return
        }

        if     ( $CheckStatus ) { "#DarkGray# ◄ ------- #" }
        elseif ( $Return -eq 'Result' ) { "$StateSVC" }
        elseif ( $Return -eq 'Value' ) { $isStartupType }
        else { $ResultState }

        Return
    }
    elseif (( -not $Service.ServiceType ) -or ( [string] $Service.ServiceType -like '*Driver*' ))
    {
        $StateSVC = "#DarkGray#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Не служба  " })

        if ( $CheckExist )
        {
            if ( $Return -eq 'Result' ) { $StateSVC } else { $false }

            Return
        }

        if ( $Return -eq 'Result' ) { "$StateSVC" }
        elseif ( $Return -eq 'Value' ) { $isValue }
        else { $ResultState }

        Return
    }
    elseif ( $CheckExist )
    {
        $StateSVC = "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Существует " })

        if ( $Return -eq 'Result' ) { $StateSVC } else { $true }

        Return
    }
    elseif ( $CheckStatus )
    {
        [string] $isStutus = $Service.Status

        if ( $isStutus -eq 'Stopped' ) { $StateSVC = "#DarkYellow# ◄ {0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Stopped " }) ; $ResultState = $false }
        else                           { $StateSVC =  "#DarkGreen# ◄ {0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Running " }) ; $ResultState = $true  }

        if     ( $Return -eq 'Result' ) { [string] "$StateSVC" }
        elseif ( $Return -eq 'Value'  ) { [string] $isStutus   }
        else { $ResultState }  # [bool]

        Return
    }


    $Service.Close()

    # Указываем раздел служб в реестре.
    [string] $ServicePath = 'SYSTEM\CurrentControlSet\Services'

    try { [int] $isStartupType  = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                                  "$ServicePath\$ServiceName",'ReadSubTree','QueryValues').GetValue('Start',0) } catch {}

    try { [int] $isDelayedValue = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                                  "$ServicePath\$ServiceName",'ReadSubTree','QueryValues').GetValue('DelayedAutoStart',0) } catch {}

    if (( $isStartupType -eq 2 ) -and ( $isDelayedValue -eq 1 )) { $isStartupType = 1 }

    if     ( 1 -eq $isStartupType ) { [string] $isStartupType = 'DelayedAuto' }
    elseif ( 2 -eq $isStartupType ) { [string] $isStartupType = 'Automatic'   }
    elseif ( 3 -eq $isStartupType ) { [string] $isStartupType = 'Manual'      }
    elseif ( 4 -eq $isStartupType ) { [string] $isStartupType = 'Disabled'    }

    if ( $isStartupType -eq $Need ) { $ColorSVC = 'Green' ; $ResultState = $true }
    else { $ColorSVC = 'Yellow' }

    if     ( 'DelayedAuto' -eq $isStartupType ) { $StateSVC = "#$ColorSVC#{0}#" -f $(if ( $L.s7  ) { $L.s7  } else { "Авто-Отлож " }) }  # Start = 1
    elseif (   'Automatic' -eq $isStartupType ) { $StateSVC = "#$ColorSVC#{0}#" -f $(if ( $L.s8  ) { $L.s8  } else { "Авто       " }) }  # Start = 2
    elseif (      'Manual' -eq $isStartupType ) { $StateSVC = "#$ColorSVC#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "Вручную    " }) }  # Start = 3
    elseif (    'Disabled' -eq $isStartupType ) { $StateSVC = "#$ColorSVC#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Отключена  " }) }  # Start = 4

    if     ( $Return -eq 'Result' ) { [string] "$StateSVC" }
    elseif ( $Return -eq 'Value'  ) { [string] $isStartupType }
    else { [bool] $ResultState }
}
