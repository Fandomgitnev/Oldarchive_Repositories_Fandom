﻿

# Проверка состояния драйверов
Function Check-State-Driver {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'State' )]
    [OutputType([string],[bool])]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [Alias( 'Name' )]
        [ValidateNotNullOrEmpty()]
        [string] $DriverName
       ,
        [Parameter( Mandatory = $false, Position = 1, ParameterSetName = 'State' )]
        [ValidateSet( 'Boot', 'System', 'Automatic', 'Manual', 'Disabled' )]
        [string] $Need
       ,
        [Parameter( Mandatory = $false, Position = 2, ParameterSetName = 'State' )]
        [ValidateSet( 'Boot', 'System', 'Automatic', 'Manual', 'Disabled' )]
        [string] $Default   # Параметр по умолчанию, Нужен только для информации, истории.
       ,
        [Parameter( Mandatory = $false, Position = 3, ParameterSetName = 'Exist' )]
        [switch] $CheckExist
       ,
        [Parameter( Mandatory = $false, Position = 4, ParameterSetName = 'Status' )]
        [switch] $CheckStatus
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Result', 'Value', 'Bool' )]
        [string] $Return = 'Result'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Также добавляем тип ServiceProcess из .NET к текущему сеансу, для управления службами.
    if ( -not ( 'System.ServiceProcess.ServiceController' -as [type] )) { Add-Type -AssemblyName 'System.ServiceProcess' -ErrorAction Stop }

      [string] $ColorDRV      = 'Red'
      [string] $StateDRV      = '#Red#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { "Ошибка     " })
        [bool] $ResultState   = $false
    [psobject] $isStartupType = $null

    $Driver = [System.ServiceProcess.ServiceController]::new($DriverName)

    # Если контроллер служб получил пустые данные.
    if (( -not $Driver.Name ) -or ( -not [string] $Driver.StartType ) -or ( -not $Driver.Status ))
    {
        $StateDRV = "#DarkGray#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Отсутствует" })

        if ( $CheckExist )
        {
            if ( $Return -eq 'Result' ) { $StateDRV } else { $false }

            Return
        }

        if     ( $CheckStatus ) { "#DarkGray# ◄ ------- #" }
        elseif ( $Return -eq 'Result' ) { "$StateDRV" }
        elseif ( $Return -eq 'Value'  ) { $isStartupType }
        else { $ResultState }

        Return
    }
    elseif ( -not ( [string] $Driver.ServiceType -like '*Driver*' ))
    {
        $StateDRV = "#DarkGray#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Не Драйвер " })

        if ( $CheckExist )
        {
            if ( $Return -eq 'Result' ) { $StateDRV } else { $false }

            Return
        }

        if     ( $Return -eq 'Result' ) { "$StateDRV" }
        elseif ( $Return -eq 'Value'  ) { $isStartupType }
        else { $ResultState }

        Return
    }
    elseif ( $CheckExist )
    {
        $StateDRV = "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Существует " })

        if ( $Return -eq 'Result' ) { $StateDRV } else { $true }

        Return
    }
    elseif ( $CheckStatus )
    {
        [string] $isStutus = $Driver.Status

        if ( $isStutus -eq 'Stopped' ) { $StateDRV = "#DarkYellow# ◄ {0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Stopped " }) ; $ResultState = $false }
        else                           { $StateDRV =  "#DarkGreen# ◄ {0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Running " }) ; $ResultState = $true  }

        if     ( $Return -eq 'Result' ) { [string] "$StateDRV" }
        elseif ( $Return -eq 'Value'  ) { [string] $isStutus   }
        else { $ResultState }  # [bool]

        Return
    }


    [string] $isStartupType = $Driver.StartType
    $Driver.Close()

    if ( $isStartupType -eq $Need ) { $ColorDRV = 'Green' ; $ResultState = $true }
    else { $ColorDRV = 'Yellow' }

    if     ( $isStartupType -eq 'Boot'      ) { $StateDRV = "#$ColorDRV#{0}#" -f $(if ( $L.s7  ) { $L.s7  } else { "Загрузка   " }) }  # Start = 0
    elseif ( $isStartupType -eq 'System'    ) { $StateDRV = "#$ColorDRV#{0}#" -f $(if ( $L.s8  ) { $L.s8  } else { "Система    " }) }  # Start = 1
    elseif ( $isStartupType -eq 'Automatic' ) { $StateDRV = "#$ColorDRV#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "Авто       " }) }  # Start = 2
    elseif ( $isStartupType -eq 'Manual'    ) { $StateDRV = "#$ColorDRV#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Вручную    " }) }  # Start = 3
    elseif ( $isStartupType -eq 'Disabled'  ) { $StateDRV = "#$ColorDRV#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "Отключён   " }) }  # Start = 4

    if     ( $Return -eq 'Result' ) { [string] "$StateDRV" }
    elseif ( $Return -eq 'Value'  ) { [string] $isStartupType }
    else { $ResultState }  # [bool]
}
