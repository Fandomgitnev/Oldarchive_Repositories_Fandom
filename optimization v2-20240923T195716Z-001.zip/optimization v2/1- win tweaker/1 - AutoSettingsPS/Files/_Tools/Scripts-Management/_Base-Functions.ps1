﻿
# Для указания не скролить консоль в строке меню, для открытия отдельных окон или приложений, чтобы команды не передавались открываемым окнам.
# Сбрасывается сама после первого использования.
Function Set-NoConsole-Scroll {
    [bool] $Global:NoConsoleScroll = $true
}

Function Get-ArchOS {
    if ( [System.Environment]::Is64BitOperatingSystem ) { 'x64' } else { 'x86' }
}

Function Get-VersOS {
    [System.Environment]::OSVersion.Version.ToString(3)
}

Function Get-RevisionOS {
    [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','UBR',$null)
}

Function Get-LangOS {
    # Показывает Изначальный язык Windows (GetSystemDefaultUILanguage)
    #[System.Globalization.CultureInfo]::InstalledUICulture.Name 
    # Показывает Установленный языковой пакет (MUI) и правильно настроенный у текущего пользователя.
    [System.Globalization.CultureInfo]::CurrentUICulture.Name
}

Function Get-NameOS
{
    [string] $NameOS      = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ProductName',$null)
    [string] $ReleaseId   = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ReleaseId',$null)
    [string] $DisplayVers = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','DisplayVersion',$null)

    if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) { $NameOS = $NameOS -replace ('Windows 10','Windows 11') }

    if     ( $ReleaseId -and $DisplayVers ) { "$NameOS #DarkGray#($ReleaseId, $DisplayVers)#" }
    elseif ( $ReleaseId                   ) { "$NameOS #DarkGray#($ReleaseId)#" }
    else                                    { "$NameOS" }
}

Function Get-Delay ( [Uint16] $ms = 1000 ) {
    Start-Sleep -Milliseconds $ms
}

Function Test-Internet ( [switch] $Bool, [switch] $Access, [string] $TestURL, [switch] $Menu )
{
    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( -not $TestURL )
    {
        # Взять адрес из Системных настроек для проверки сети
        $KeyInternet = 'HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
        $TestURL = [Microsoft.Win32.Registry]::GetValue($KeyInternet,'ActiveWebProbeHost',$null)
    }

    if ( -not $TestURL ) { $TestURL = 'google.com' }

    # Исключение проверки и отображения состояния интернета для меню, если так настроено в пресете
    if ( $Menu )
    {
        [string] $FilePresets = $FilePresetsGlobal

        # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
        # то будет использоваться как пресет для настроек первый из дополнительных найденных.
        try
        {
            [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
            [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
            [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

            [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
                $_.Name -like "$PresetsName`?*$PresetsExt"
            },'First',1)).FullName
        }
        catch { [string] $FoundPresetsMy = '' }

        if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

        # Если файл с пресетами существует.
        if ( [System.IO.File]::Exists($FilePresets) )
        {
            # Получение пресетов в переменную.
            try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
        }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Do-not-check-Internet\s*=\s*1\s*=' },'First',1) )
        {
            [bool] $NotCheckInternet = $true
        }
        else { [bool] $NotCheckInternet = $false }
    }

    # Отключение вывода прогресс бара
    $Global:ProgressPreference = 'SilentlyContinue'

    if ( $NotCheckInternet )
    {
        "#DarkGray#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Не проверялся       " })
    }
    elseif ( $Bool -and $Access )
    {
        Test-NetConnection -InformationLevel Quiet -ComputerName $TestURL -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -CommonTCPPort HTTP
    }
    elseif ( $Bool )
    {
        Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue
    }
    elseif ( $Access )
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( Test-NetConnection -InformationLevel Quiet -ComputerName $TestURL -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -CommonTCPPort HTTP )
        {
            "#Green#{0} #DarkCyan#{1}#" -f $(if ( $L.s1 ) { $L.s1,$L.s1_1 } else { "OnLine", "(+ PS Доступ)" })
        }
        elseif ( Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue )
        {
            "#Green#{0} #Red#{1}#" -f $(if ( $L.s2 ) { $L.s2,$L.s2_1 } else { "OnLine", "(Нет Доступа)" })
        }
        else
        {
            "#Red#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "OffLine             " })
        }
    }
    else
    {
        if ( Test-Connection $TestURL -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction SilentlyContinue )
        {
            "#Green#OnLine #"
        }
        else
        {
              "#Red#OffLine#"
        }
    }

    # Возврат показа прогресс бара
    $Global:ProgressPreference = 'Continue'
}


# Функция для проверки длины строки и подсветки любых нежелательных или проблемных символов в строке
# Для вывода через функцию Write-HostColor. Нужна для проверки пути к скрипту
Function Highlight-Problem-Symbols ( [string] $StringLine = '', [string] $MainColor = 'Cyan', [string] $HighlightColor = 'White:DarkRed' ) {

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [string] $NotProblemColor = 'DarkGray'

    if ( $StringLine )
    {
        if ( $StringLine -match '[^a-z0-9 ():\\._\-]+' )
        {
            $StringLine = ($StringLine.ToCharArray() | ForEach-Object {

                if ( $_ -match '[^a-z0-9 ():\\._\-]+' ) { "#$HighlightColor#$_#$NotProblemColor#" }
                else                                    { $_ }

            }) -join ''

            $StringLine = "#Red#{0} #DarkGray#| #$NotProblemColor#$StringLine#" -f $(if ( $L.s1 ) { $L.s1 } else { "Проблемные символы в пути!" })
        }
        elseif ( $StringLine.Length -gt 70 )
        {
            $StringLine = "#Red#{0} #DarkGray#| #$MainColor#$StringLine#" -f $(if ( $L.s2 ) { $L.s2 } else { "Путь слишком длинный!" })
        }

        "#$MainColor#$StringLine#"
    }
}


# Получение полных путей ко всем задачам по совпадениям с поисковым отрезком в имени, или полным путём
Function Get-Task-FullPaths {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType( [string[]] )]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $true, Position = 0 )]
        [string[]] $LikeNames
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $CompareFullPath  # Сравнение шаблона -LikeNames с полным путём, а не только с именем задачи
    )

    Process
    {
        if ( -not $LikeNames ) { Return }

        [string[]] $TaskPaths = $null
        [psobject] $OpenRegKey = $null
        [psobject] $OpenSubKey = $null
          [string] $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
          [string] $Path = ''
          [string] $Name = ''

        try
        {
            $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')
        }
        catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $LikeName in $LikeNames )
            {
                try
                {
                    # Поиск полного пути в разделах задач в реестре по значениям параметра Path
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        try { $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
                        catch { $OpenSubKey = $null }

                        if ( $OpenSubKey )
                        {
                            $Path = $OpenSubKey.GetValue('Path',$null)

                            if ( $Path -like '\*' )
                            {
                                if ( -not $CompareFullPath )
                                {
                                    $Name = $Path -Replace ('.*\\([^\\]+$)','$1')
                                    if ( $Name -like $LikeName ) { $TaskPaths += $Path }
                                }
                                else
                                {
                                    if ( $Path -like $LikeName ) { $TaskPaths += $Path }
                                }
                            }

                            $OpenSubKey.Close()
                        }
                    }
                }
                catch {}
            }

            $OpenRegKey.Close()
        }

        $TaskPaths.Where({$_})
    }
}

# Функция для получения пути к файлу для сохранения информации + Создание глобальной переменной,
# с нужным названием и полученным путём внутри этой переменной
Function Get-SaveListPath ( [string] $FileName = 'FileName', [string] $isVarNameGlobal = 'GlobalVarName' ) {

    if ( $CurrentRoot ) { $FileRoot = $CurrentRoot } else { $FileRoot = $env:SystemDrive }
    $VarValue = "$FileRoot\$FileName`_$((Get-Date).ToString('yyyyMMdd-HHmmss')).txt"

    # переменная с полученным путём
    Set-Variable -Name $isVarNameGlobal -Value $VarValue -Scope Global -Force

    # вывод полученного пути из созданной переменной
    Return (& $([scriptblock]::Create("`$$isVarNameGlobal")))
}


# Функция для закачки файлов по прямым линкам через System.Net.Http.HttpClient
Function Download-File {
    
    [CmdletBinding()]
    [OutputType([bool])]
    param (
        [Parameter(Position = 0)][string] $FileUrl
       ,
        [Parameter(Position = 1)][string] $DestFile
       ,
        [Parameter(Position = 2)][string] $UserAgent
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( -not ( $FileUrl -and $DestFile ) -or $FileUrl -notmatch '^http[s]?:\/\/.+' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Не указаны параметры" }
        Write-Host "   $NameThisFunction`: $text`: FileUrl: '$FileUrl', DestFile: '$DestFile'" -ForegroundColor DarkYellow
        Return
    }

    # Подгрузка класса
    if ( -not ( 'System.Net.Http' -as [type] )) { Add-Type -AssemblyName 'System.Net.Http' -ErrorAction Stop }

    [int] $try = 0

    # 2 попытки начать загружать файл, если первая не получила размер данных
    do 
    {
        if ( $try -ge 1 )
        {
            Start-Sleep -Milliseconds 300
            if ( $Response ) { $Response.Dispose() }
            if ( $httpClient ) { $httpClient.Dispose() }
        }

        $httpClient = [System.Net.Http.HttpClient]::new()
        $httpClient.Timeout = [timespan]::FromSeconds(20) # Максимальное Время задержки ответа (деф 100 сек)
        
        if ( $UserAgent )
        {
            # "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0"
            [bool] $resultUA = $httpClient.DefaultRequestHeaders.UserAgent.TryParseAdd($UserAgent)
            if ( -not $resultUA ) { Write-Host "$NameThisFunction`: Error adding User-Agent: $UserAgent" -ForegroundColor DarkYellow }
        }

        $Response = $httpClient.GetAsync($FileUrl,'ResponseHeadersRead')  # Начать соединение с сервером и загрузку данных в буфер

        # Пока нет ответа сервера положительного или отрицательного, предел указывается в $httpClient.Timeout
        while ( -not $Response.IsCompleted ) { Start-Sleep -Milliseconds 50 }

        $try++
    } 
    until ( $try -eq 2 -or $Response.Result.Content.Headers.ContentLength )

    [string] $DestFileName = $([System.IO.Path]::GetFileName($DestFile))

    # Если ошибка получения ответа от сервера или вышло время, выйти из функции
    if ( $Response.IsFaulted -or ( -not $Response.Result.IsSuccessStatusCode ) )
    {
        if ( $Response ) { $Response.Dispose() }
        if ( $httpClient ) { $httpClient.Dispose() }

        $text = if ( $L.s2 ) { $L.s2 } else { "Ошибка сервера." }
        Write-Warning "$NameThisFunction`: $text $DestFileName `n$FileUrl"
        
        Return
    }
    elseif ( -not $Response.Result.Content.Headers.ContentLength )
    {
        if ( $Response ) { $Response.Dispose() }
        if ( $httpClient ) { $httpClient.Dispose() }

        $text = if ( $L.s3 ) { $L.s3 } else { "Размер файла с сервера не получен." }
        Write-Warning "$NameThisFunction`: $text $DestFileName `n$FileUrl"
        
        Return
    }

    # Создать файловый стрим для записи файла
    try { $OutputFileStream = [System.IO.FileStream]::new($DestFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write) }
    catch
    {
        $text = if ( $L.s4 ) { $L.s4 } else { "Ошибка записи файла." }
        Write-Warning "$NameThisFunction`: $text $DestFileName`n$($_.CategoryInfo.Category): $($_.Exception.Message)"
            
        Return
    }
        
    # Начать записывать файл на диск из буфера
    $WriteFile = $Response.Result.Content.CopyToAsync($OutputFileStream)

     [int64] $TotalBytes = $Response.Result.Content.Headers.ContentLength
    [string] $FileSize   = ''

    if     ( $TotalBytes -gt 1gb ) { $FileSize = '{0} Gb' -f ( $TotalBytes / 1gb ).ToString('N1') }
    elseif ( $TotalBytes -gt 1mb ) { $FileSize = '{0} Mb' -f ( $TotalBytes / 1mb ).ToString('N1') }
    elseif ( $TotalBytes -gt 0   ) { $FileSize = '{0} Kb' -f ( $TotalBytes / 1kb ).ToString('N1') }
    
     [bool] $isDownloaded  = $false
     [bool] $isDownloading = $true
    
    [int64] $PreviousBytes = 0
      [int] $wait = 0
      [int] $Percent = 0

    # Пока не загружен или пока загружается файл
    while ( -Not $isDownloaded -and $isDownloading )
    {
        # для снятия нагрузки от частоты обработки и вывода прогресса.
        Start-Sleep -Milliseconds 100

        # Получить текущие записанные байты
        [int64] $WritedBytes = $OutputFileStream.Length
        
        # Если есть записанные байты, получить текущий процент записи, округляя всегда в меньшую сторону, 
        # грубо убирая знаки после запятой, чтобы показывало 100% только когда реально 100%
        $Percent = [System.Math]::Truncate(100*($WritedBytes/$TotalBytes))
        
        Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1

        # Если все байты записаны, выйти из while
        if ( $WritedBytes -eq $TotalBytes ) { $isDownloaded = $true }
        
        # Если нет изменений в записанных байтах, увеличить счетчик ожидания, если есть изменение, то обнулить его.
        if ( $PreviousBytes -eq $WritedBytes ) { $wait++ } else { $wait = 0 }
        $PreviousBytes = $WritedBytes

        # Если счетчик ожидания накопился до 60 (примерно 10 сек, с учетом всех задержек), загрузка остановилась, выйти из while
        if ( $wait -eq 60 ) { $isDownloading = $false }
    }

    Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1
    Start-Sleep -Milliseconds 500
    Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Completed -Id 1

    # "wait: $wait | PreviousBytes: $PreviousBytes | WritedBytes: $WritedBytes"

    if ( $TotalBytes -gt 0 ) { [int64] $Global:TotalBytesSize = $TotalBytes } else { [int64] $Global:TotalBytesSize = 0 }
    if ( $FileSize ) { [string] $Global:FileSizeNote = $FileSize } else { [string] $Global:FileSizeNote = '' }

    if ( -not $isDownloaded )
    {
        $text = if ( $L.s5 ) { $L.s5 } else { "Файл не загружен" }
        Write-Warning "$NameThisFunction`: $text`: $DestFileName"
    }

    # Отключить httpClient
    if ( $Response ) { $Response.Dispose() }
    if ( $httpClient ) { $httpClient.Dispose() }
    # Закрытие файлового стрима, для разблокировки файла.
    if ( $OutputFileStream ) { $OutputFileStream.Close() }

    Return $isDownloaded
}

# Функция получения web страницы через System.Net.Http.HttpClient
Function Get-ContentWebPage {
    
    [OutputType([string])]
    param (
        # Адрес страницы, которую требуется загрузить
        [Parameter(Mandatory)] [ValidateNotNullOrEmpty()] [string] $Url
    )

    # Если сборка 'System.Net.Http' не загружена, загрузить
    if ( -not ('System.Net.Http' -as [type] )) { Add-Type -AssemblyName 'System.Net.Http' -ErrorAction Stop }

    $HttpClient = [System.Net.Http.HttpClient]::new()
    $Response   = $HttpClient.GetStringAsync($URL)

    #region Spinner

    if ( $host.Name -eq 'ConsoleHost' ) 
    {
        if ( $Response )
        {
            [System.Console]::CursorVisible = $false

            while ( -not $Response.IsCompleted )
            {
                '|','/','—','\','|','/','—','\' | ForEach-Object -Process {
                    [System.Console]::Write("$_`b")
                    Start-Sleep -Milliseconds 20
                }
            }
        
            [System.Console]::Write(" `b")
            [System.Console]::CursorVisible = $true
        }
    }
    else
    {
        if ( $Response )
        {
            while ( -not $Response.IsCompleted ) {
                 Start-Sleep -Milliseconds 20
            }
        }
    }

    #endregion

    if ( $HttpClient ) { $HttpClient.Dispose() }
    
    Return $Response.Result
}

# Функция получения версии из строки (например имени файла)
Function Get-VersionFromName {
    
    [OutputType([version])]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        [string] $Str
    )

    process
    {
        if ( $Str -match '(?<Vers>(?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))' )
        {
            [version] $Version = $null
            if ([version]::TryParse($Matches.Vers, [ref] $Version)) { Return $Version }
        }
    }
}

# Функция получения списка файлов с прямыми ссылками по публичным ссылкам с облаков Google Drive и Yandex Disk
# используются функции: Get-ContentWebPage, Get-VersionFromName
Function Get-DirectoryItems {
    
    [OutputType([array])]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Url
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    [array] $DirectoryItems = @()
    [psobject] $Content = $null

    if ( $Url -like 'http*.Yandex.*' -or $Url -like 'http*yadi.sk*' )
    {
        $Url      = [Uri]::UnescapeDataString($Url)
        $API      = 'https://cloud-api.yandex.net/v1/disk/public/resources/'
        $Key      = $Url -replace '(http(s)*:\/(\/[^\/]+){3}).*','$1'  # захват начальной части URL
        $Path     = [Uri]::EscapeDataString($Url -replace $Key)
        $QueryUri = "{0}?public_key={1}&path={2}&limit=1000" -f $API, $Key, $Path  # &limit=1000  для увеличения ограничения выдачи списка файлов, по умолчанию = 20

        $Content = Get-ContentWebPage -Url $QueryUri

        try { $DirectoryItems = ConvertFrom-Json $Content } catch {}
        
        if ( $DirectoryItems._embedded.items.count )
        {
            $DirectoryItems = $DirectoryItems._embedded.items
            $DirectoryItems | ForEach-Object {
                $Params = @{
                    InputObject = $_
                    MemberType = 'NoteProperty'
                    Name = 'Version'
                    Value = Get-VersionFromName -Str $_.Name
                }

                Add-Member @Params -Force -ErrorAction SilentlyContinue
            }

            $DirectoryItems = $DirectoryItems | 
                Select-Object -Property Name, Version, @{name='Type';e={$_.media_type}}, @{name='Id';e={$_.resource_id}}, @{name='DirectUrl';e={$_.file}}
        }
    }
    elseif ( $Url -like 'http*.Google.*' )
    {
        $Content = Get-ContentWebPage -Url $Url

        if ( $Content )
        {
            [regex]::Matches($Content,'data-id="(.*?)".*?aria-label="(.*?)".*?data-tooltip="(.*?)"') | ForEach-Object -Process {
                $DirectoryItems += [PSCustomObject] @{
                    Name      = $_.Groups[3].Value
                    Version   = Get-VersionFromName -Str ($_.Groups[3].Value)
                    Type      = $_.Groups[2].Value -replace "$($_.Groups[3]) "
                    Id        = $_.Groups[1].Value
                    DirectUrl = "https://drive.google.com/uc?id=$($_.Groups[1].Value)"
                }
            }
        }
    }
    else { Write-Warning "   $NameThisFunction`: unknown link: $Url" }

    Return $DirectoryItems
}

# Функция закачки указанного имени файла по публичным ссылкам с облаков Google Drive и Yandex Disk
# используются функции: Get-VersionFromName, Get-DirectoryItems, Download-File
Function Get-FileFromServers {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string[]] $URLs
       ,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Name
       ,
        [string] $Extension
       ,
        [string] $CurrentVersion
       ,
        [string] $DestPath
       ,
        [switch] $DownloadByBrowser
       ,
        [switch] $OnlyCheck
       ,
        [switch] $CheckAllServers
       ,
        [ValidateSet( 'Google', 'Yandex|Yadi' )]
        [string] $PriorityServer
    ) 

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если не указан путь сохранения, загрузка будет в папку "Загрузки" текущего пользователя
    if (( -not $DestPath ) -and ( -not $OnlyCheck ))
    {
        [string] $Key = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'
        [string] $Downloads = [Microsoft.Win32.Registry]::GetValue("$Key\Shell Folders",'{374DE290-123F-4565-9164-39C4925E467B}',$null)
        if ( -not $Downloads ) { $Downloads = [Microsoft.Win32.Registry]::GetValue("$Key\User Shell Folders",'{374DE290-123F-4565-9164-39C4925E467B}',$null) }
        if ( [System.IO.Directory]::Exists($Downloads) ) { $DestPath = $Downloads }
    }

    [array] $isURLs = @()

    if ( $PriorityServer )
    {
        $isURLs = @($URLs).Where({ $_ -match ":\/\/[^\/\n\r]*?($PriorityServer)" })
        $isURLs += @($URLs).Where({ $_ -notmatch ":\/\/[^\/\n\r]*?($PriorityServer)" })
    }
    else
    {
        $isURLs = $URLs
    }

    foreach ( $URL in $isURLs )
    {
        if ( $Extension ) { $Regex = [regex]::new("^$Name.*?[.]$Extension$") ; $ShowName = "$Name ($Extension)" }
        else              { $Regex = [regex]::new("^$Name")                  ; $ShowName = "$Name" }

        if ( $CurrentVersion )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Поиск" }
            Write-Host "`n   $text`: " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s1_1 ) { $L.s1_1 } else { "Новой версии" }
            Write-Host "$text " -ForegroundColor DarkCyan  -NoNewline
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Поиск" }
            Write-Host "`n   $text`: " -ForegroundColor Cyan -NoNewline
        }

        Write-Host "$ShowName " -ForegroundColor White -NoNewline
        if ( $CurrentVersion ) { Write-Host "| $CurrentVersion " -ForegroundColor DarkGray } else { Write-Host }

        $text = if ( $L.s2 ) { $L.s2 } else { "  URL" }
        Write-Host "   $text`: $URL" -ForegroundColor DarkGray

        [array] $DirectoryItems = Get-DirectoryItems $URL

        $FileData = $DirectoryItems | Where-Object -Property Name -Match $Regex | Sort-Object -Property Name | Select-Object -Last 1  # если несколько файлов подпадет 
        $FileUrl  = $FileData.DirectUrl
        $FileName = $FileData.Name
        $DestFile = '{0}\{1}' -f $DestPath.TrimEnd('\'), $FileName

        if ( $FileUrl -and $FileName )
        {
            if ( $CurrentVersion )
            {
                [version] $VersionOld = $null
                [version]::TryParse($CurrentVersion,[ref]$VersionOld) > $null

                if ( $VersionOld -and ( $FileVersion = Get-VersionFromName -Str $FileName ))
                {
                    if ( $FileVersion -le $VersionOld )
                    {
                        $text = if ( $L.s3 ) { $L.s3 } else { " Файл" }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        
                        $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Актуальный" }
                        Write-Host "$text " -ForegroundColor DarkGreen -NoNewline
                        
                        $text = if ( $L.s3_2 ) { $L.s3_2 } else { "Найден" }
                        Write-Host "| $text`: $FileName " -ForegroundColor DarkGray -NoNewline
                        
                        if ( $OnlyCheck )
                        {
                            $text = if ( $L.s3_3 ) { $L.s3_3 } else { "Только проверка" }
                            Write-Host "| $text" -ForegroundColor DarkGray
                        }
                        else
                        {
                            Write-Host
                        }

                        if ( -not $CheckAllServers ) { break } else { Continue }
                    }
                }
            }

            $text = if ( $L.s3 ) { $L.s3 } else { " Файл" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
         
            $text = if ( $L.s3_2 ) { $L.s3_2 } else { "Найден" }
            Write-Host "$text " -ForegroundColor DarkGreen -NoNewline
            Write-Host "| $FileName " -ForegroundColor DarkGray
            
            Write-Host "    Link: DirectUrl | $FileUrl " -ForegroundColor DarkGray -NoNewline

            if ( $OnlyCheck )
            {
                $text = if ( $L.s3_3 ) { $L.s3_3 } else { "Только проверка" }
                Write-Host "| $text" -ForegroundColor DarkGray

                if ( -not $CheckAllServers ) { break } else { Continue }
            }
            else
            {
                $text = if ( $L.s3_4 ) { $L.s3_4 } else { "Скачиваем" }
                Write-Host "| $text ..." -ForegroundColor DarkGray
            }

            if ( $DownloadByBrowser )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "  URL" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Передача загрузки в браузер" }
                Write-Host "$text" -ForegroundColor White

                try { Start-Process $FileUrl -ErrorAction SilentlyContinue }
                catch
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { "   URL" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                    
                    $text = if ( $L.s2_2 ) { $L.s2_2 } else { "Ошибка передачи в браузер" }
                    Write-Host "$text" -ForegroundColor DarkYellow
                }
                
                break
            }
            else
            {
                $Result = Download-File -FileUrl $FileUrl -DestFile $DestFile
            }

            if ( $Result )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { " Файл" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                
                $text = if ( $L.s3_5 ) { $L.s3_5 } else { "Сохранён" }
                Write-Host "$text " -ForegroundColor Green -NoNewline
                Write-Host "| $DestFile" -ForegroundColor DarkGray

                break
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { " Файл" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                
                $text = if ( $L.s3_6 ) { $L.s3_6 } else { "Не Скачан" }
                Write-Host "$text" -ForegroundColor DarkYellow
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "  URL" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s2_3 ) { $L.s2_3 } else { "Нет данных" }
            Write-Host "$text" -ForegroundColor DarkYellow
        }
    }
}

# Функция проверки/закачки Новой версии скрипта AutoSettingsPS или пресетов
# используются функции: Get-FileFromServers и Test-Internet
Function Get-AutoSettingsPS-Update {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    param (
        [Parameter( ParameterSetName = 'LatestASPS' )]
        [switch] $LatestASPS
       ,
        [Parameter( ParameterSetName = 'Presets' )]
        [switch] $Presets
       ,
        [switch] $OnlyCheck
       ,
        [switch] $NoPause
    ) 

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( -not ( Test-Internet -Bool -Access ))
    {
        if ( -not $NoPause )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Нет доступа в Интернет для PS" }
            Write-Host "   $text" -ForegroundColor DarkYellow
        }
    }
    else
    {
        # Ссылки на ../Settings and Tools/Windows 10 1809+
        $URLs = 'https://drive.google.com/drive/folders/1BeIxTdr9ag9RIxAoPbw8K5lFVbywkFvC',
                'https://disk.yandex.com/d/Fa12eTeiCyGkcw'

        if ( -not $Presets )
        {    
            if ( $LatestASPS )
            {
                Get-FileFromServers -URLs $URLs -Name 'AutoSettingsPS' -Extension zip -OnlyCheck:$OnlyCheck
            }
            else
            {
                Get-FileFromServers -URLs $URLs -Name 'AutoSettingsPS' -Extension zip -CurrentVersion:$AutoSettingsVersion -OnlyCheck:$OnlyCheck
            }
        }
        else
        {
            Get-FileFromServers -URLs $URLs -Name 'Presets_Hard'      -Extension txt -OnlyCheck:$OnlyCheck
            Get-FileFromServers -URLs $URLs -Name 'QuickPresets_Hard' -Extension txt -OnlyCheck:$OnlyCheck
        }
    }

    if ( -not $NoPause )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Завершено" }
        Write-Host "`n   $text" -ForegroundColor DarkGray
        
        Get-Pause
    }
}


<#
Пример 1: Write-Warning-Log "`n Пример предупреждения 1 `n "

Пример 2: Write-Warning-Log "`n   Пример предупреждения `n   еще одного " "D:\Warnings.log"
#>
Function Write-Warning-Log {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [string] $Line
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $WarningsLogFile   # По умолчанию задан глобальный лог для предупреждений, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    Write-Warning "$Line"

    # Если не передан файл для сохранения или не назначен $WarningLog по умолчанию, сохранит в папку Temp пользователя.
    if ( $FileLog -eq '' )
    {
        # Расскрываем короткие имена в пути
        [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

        $FileLog = "$TempPath\AutoSettings-Warnings.log"

        $text = if ( $L.s1 ) { $L.s1 } else { "Это предупреждение записано в" }
        Write-host "   $text`: '$FileLog', " -BackgroundColor DarkYellow -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { "так как файл не был назначен" }
        Write-host "$text   " -BackgroundColor DarkYellow
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Это предупреждение записано в" }
        Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkYellow
    }

    # Out-File -FilePath $File -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line" -Append -Encoding utf8

    [System.Collections.Generic.List[string]] $log = "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line"
    [System.IO.File]::AppendAllLines($FileLog,$log,[System.Text.Encoding]::GetEncoding('utf-8'))
}


<#
примеры
Save-Error
или
Save-Error D:\Errors.log
#>
Function Save-Error {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $ErrorsLogFile  # По умолчанию задан глобальный лог для ошибок, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Error[0] -ne $null )
    {
        # Если не передан файл для сохранения или не назначен $ErrorsLog по умолчанию, сохранит лог в папку Temp пользователя.
        if ( $FileLog -eq '' )
        {
            $FileLog = "$env:TEMP\AutoSettings-Errors.log"

            $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
            Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

            $text = if ( $L.s1_1 ) { $L.s1_1 } else { "так как файл не был назначен" }
            Write-host "$text   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch { throw }
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
            Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch
            {
                # Если нет доступа на запись к директории скрипта, сохранить файл в папке темп пользователя
                $FileLog = "$env:TEMP\AutoSettings-Errors.log"

                $text = if ( $L.s1 ) { $L.s1 } else { "Эта ошибка записана в" }
                Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

                $text = if ( $L.s2 ) { $L.s2 } else { "так как нет доступа на запись в папку скрипта" }
                Write-host "$text   " -BackgroundColor DarkBlue

                try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
                catch { throw }
            }
        }
    }
}
