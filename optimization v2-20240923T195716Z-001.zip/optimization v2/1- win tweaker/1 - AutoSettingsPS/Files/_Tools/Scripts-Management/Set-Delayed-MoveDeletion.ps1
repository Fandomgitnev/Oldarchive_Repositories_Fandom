﻿
<#
.SYNOPSIS
 Отложенное удаление/переименование/перемещение на этап загрузки Windows.
 (только для системного диска и в пределах системного диска).

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется код C# (Win Api).
 Используется функция Set-OwnerAndAccess для получения полного доступа к файлам/папкам при необходимости. Необходим админский доступ к объекту.
 Используется функция Token-Impersonate для сброса олицетворения.

 Если указать только файлы/папки, то будет отложенное удаление.
 Если указать Имя для NewName, то будет переименование, если указать новое расположение, то будет перемещение.
 
 Все действия подчиняются правилу Win Api.
 Может не сработать, если будут какие-либо несоответствия, либо не будет свободное имя в этом месте, 
 либо функция Set-OwnerAndAccess не сможет получить доступ.

.EXAMPLE
    Set-Delayed-MoveDeletion C:\1\1.txt, C:\1\2.txt
    
    Описание
    --------
    Будут удалены оба файла: 1.txt и 2.txt
     
.EXAMPLE
    Set-Delayed-MoveDeletion C:\1\1.txt -NewName 222
    
    Описание
    --------
    Будет переименован файл C:\1\1.txt в C:\1\222

.EXAMPLE
    Set-Delayed-MoveDeletion 'C:\1\Новая папка (777)' -NewName 'C:\Новая папка (888)'
    
    Описание
    --------
    Будет перемещена папка 'Новая папка (777)' со всеми файлами из 'C:\1' в 'C:\Новая папка (888)'
     
.EXAMPLE
    Set-Delayed-MoveDeletion 'C:\1\Новая папка (777)' -NewName 'Новая папка (888)'
    
    Описание
    --------
    Будет переименована папка 'Новая папка (777)' в 'Новая папка (888)'

.EXAMPLE
    Set-Delayed-MoveDeletion 'C:\1\Новая папка (777)'
    
    Описание
    --------
    Будет удалена папка 'Новая папка (777)' со всеми файлами.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  02.12.2021
 ===============================================

#>
Function Set-Delayed-MoveDeletion {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false, Position = 1 )]
        [array] $Targets
       ,
        [Parameter( Mandatory = $false )]
        [Alias( 'NewDestination' )]
        [string] $NewName
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    if ( -not $Targets.Count ) { Write-Host "   $NameThisFunction`: Files not specified" -ForegroundColor DarkGray ; Return }
    if ( $NewName -and $Targets.Count -gt 1 ) { Write-Host "   $NameThisFunction`: Specify 1 file to move/rename" -ForegroundColor DarkGray ; Return }
    
    # Код C# для удаления/перемещения/переименования файлов при старте Windows (отложенное действие) 
    $DelayedAction = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class DelayedAction
    {
        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool MoveFileEx(string lpExistingFileName, string lpNewFileName, MoveFileFlags dwFlags);

        public enum MoveFileFlags
        {
	        MOVEFILE_DELAY_UNTIL_REBOOT = 0x00000004
        }

        public static bool MarkFileDelete (string sourcefile)
        {
	        return MoveFileEx(sourcefile, null, MoveFileFlags.MOVEFILE_DELAY_UNTIL_REBOOT);
        }

        public static bool MarkFileMove (string sourcefile, string destination)
        {
	        return MoveFileEx(sourcefile, destination, MoveFileFlags.MOVEFILE_DELAY_UNTIL_REBOOT);
        }
    }
}
'@

    if ( -not ( 'WinAPI.DelayedAction' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $DelayedAction -ErrorAction SilentlyContinue -Language CSharp -CompilerParameters $cp
    }

    Token-Impersonate -Reset

    # Получение списка уже добавленных из нечётных номеров строк. Если удаление, то вторая строка (чётная) пустая, иначе переименование
    [string[]] $Delayed = @()
    try { $Delayed = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager','PendingFileRenameOperations',@()) } catch {}
    [int] $N = 0 ; $Delayed = @($Delayed).ForEach({ if ( -not ($N % 2) ) { $_.Trim('\??\')} ; $N++ })

    foreach ( $Target in $Targets )
    {
        $isTarget = [System.IO.Path]::GetFullPath([System.Environment]::ExpandEnvironmentVariables($Target))

        if ( $Delayed -like $isTarget ) { Continue } # Пропуск уже добавленного

        if ( [System.IO.File]::Exists($isTarget) )
        {
            Set-OwnerAndAccess -Path $isTarget -SetFullAccess -Verbose:$false

            try
            {
                if ( $NewName )
                {
                    $isNewName = [System.Environment]::ExpandEnvironmentVariables($NewName)

                    if ( $isNewName -like '*:*' ) { $isDestination = $isNewName }
                    else
                    {
                        $isDestination = "{0}\$isNewName" -f [System.IO.Path]::GetDirectoryName($isTarget) 
                    }

                    Write-Verbose "     isTarget: $isTarget"
                    Write-Verbose "isDestination: $isDestination"

                    $Mark = [WinAPI.DelayedAction]::MarkFileMove($isTarget,$isDestination)
                }
                else
                {
                    $Mark = [WinAPI.DelayedAction]::MarkFileDelete($isTarget)
                }
            }
            catch { $Mark = $null }

            if ( -not $Mark )
            {
                Write-Host "   Error MarkFileDelete/MarkFileMove: $isTarget" -ForegroundColor Yellow
            }
        }
        elseif ( [System.IO.Directory]::Exists($isTarget) )
        {
            if ( $NewName )
            {
                Set-OwnerAndAccess -Path $isTarget -SetFullAccess -Verbose:$false

                $isNewName = [System.Environment]::ExpandEnvironmentVariables($NewName)

                if ( $isNewName -like '*:*' ) { $isDestination = $isNewName }
                else
                {
                    $isDestination = "{0}\$isNewName" -f [System.IO.Path]::GetDirectoryName($isTarget) 
                }

                Write-Verbose "     isTarget: $isTarget"
                Write-Verbose "isDestination: $isDestination"

                try { $Mark = [WinAPI.DelayedAction]::MarkFileMove($isTarget,$isDestination)}
                catch { $Mark = $null ; Write-Host "   Error MarkFileMove: $isTarget" -ForegroundColor DarkYellow }
            }
            else
            {
                Get-ChildItem -File -LiteralPath $isTarget -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
                    
                    $FullName = $_.FullName

                    Write-Verbose "Add: $FullName"

                    Set-OwnerAndAccess -Path $FullName -SetFullAccess -Verbose:$false
                    
                    try { $Mark = [WinAPI.DelayedAction]::MarkFileDelete($FullName) }
                    catch { $Mark = $null ; Write-Host "   Error MarkFileDelete: $FullName" -ForegroundColor DarkYellow }
                }

                Get-ChildItem -Directory -LiteralPath $isTarget -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
                    
                    $FullName = $_.FullName

                    Write-Verbose "Add: $FullName"

                    Set-OwnerAndAccess -Path $FullName -SetFullAccess -Verbose:$false
                    
                    try { $Mark = [WinAPI.DelayedAction]::MarkFileDelete($FullName) }
                    catch { $Mark = $null ; Write-Host "   Error MarkFileDelete: $FullName" -ForegroundColor DarkYellow }
                }

                Write-Verbose "Add: $isTarget"

                Set-OwnerAndAccess -Path $isTarget -SetFullAccess -Verbose:$false

                try { $Mark = [WinAPI.DelayedAction]::MarkFileDelete($isTarget) } catch { $Mark = $null }

                if ( -not $Mark )
                {
                    Write-Host "   Error MarkFileDelete: $isTarget" -ForegroundColor DarkYellow
                }
            }
        }
        else
        {
            Write-Host "   $NameThisFunction`: File does not exist: $isTarget" -ForegroundColor DarkGray
        }
    }
}