﻿
$Menu_Set_Apps_Management = @{

    Info =  @{

     #  0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| #Gray#$($L.s1_1) #Blue#$($L.s1_2)#" # Управление Apps/Appx | Загрузка/Установка/Перерегистрация/Удаление Модерн Приложений (Для всех пользователей!)
        3 = "      #DarkGray#$($L.s2)#"                                             # Для Удалённых Системных Apps создаётся задача автоочистки параметров, которые восстанавливают Обновления (CU)
        4 = "      #DarkGray#$($L.s3)#"                                             # Удалённые Системные Apps обновляются, но сами не восстанавливаются. При закачке очищается подпапка, кроме XML
        5 = "      #DarkGray#● = $($L.s4) | ■ = $($L.s4_1) | $($L.s4_2): #", "#White#& Run-Configs | -CheckState CurrentPreset#"  # ● = Установлен | ■ = Есть Appx | Изменить список Apps/Appx можно в файле пресетов, текущий файл: \Presets.txt
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s5) #Blue#Apps #DarkGray#$($L.s5_1):#",                       # Указанные Apps для Установки/Удаления:
                           "#DarkGray#$($L.s5_2): #", '& Test-Internet | -Access -Menu',        # Интернет: OnLine (+ Доступ для PS)
                    "    #DarkGray#DevMode: #", '& Set-Apps-Management | -CheckState DevMode'   # DevMode: По умолчанию

        1 = ''
        2 = '& Set-Apps-Management | -CheckState UninstallInstallApps'

      3 = "`n      #DarkGray#$($L.s6) #White#Appx #DarkGray#$($L.s6_1):#`n"       # Найденные/Настроенные Appx для Установки/Удаления/Скачивания в свои подпапки:
        4 = '& Set-Apps-Management | -CheckState DownloadAppx'

        5 = ''
    }

    Options = @{

        1 = "#Cyan#  [1]# = #Cyan#$($L.s8 )# $($L.s8_1 ) #DarkGray#| ► $(Get-SaveListPath SavedListApps SavePathAppsGlobal | Split-Path -leaf)#"                                                              #  [1] = Сохранить список установленных Apps для файла пресетов | ► Saved...

      2 = "`n#Blue# [10]# = #Blue#$($L.s9 )# $($L.s9_1 ) #DarkGray#| $($L.s9_2 )  #DarkBlue#◄#Blue# [100]# = #Blue#$($L.s9 )# $($L.s9_3 ) #DarkGray#| $($L.s9_4)#"           # [10] = Удалить Все    | Указанные для Удаления Apps     ◄ [100] = Удалить выборочно    | Ввод номеров (1 3 5 ...)
        3 = "#Blue# [20]# = #Blue#$($L.s10)# $($L.s10_1) #DarkGray#| $($L.s10_2)  #DarkBlue#◄#Blue# [200]# = #Blue#$($L.s10)# $($L.s10_3) #DarkGray#| $($L.s9_4)#"           # [20] = Установить Все | Указанные для Установки Apps    ◄ [200] = Установить выборочно | Ввод номеров (1 3 5 ...)

     4 = "`n#White# [30]# = #Whit#$($L.s11)# $($L.s11_1) #DarkGray#| $($L.s11_2)  #DarkGray#◄#Whit# [300]# = #Whit#$($L.s11)# $($L.s11_3) #DarkGray#| $($L.s9_4)#"           # [30] = Скачать Все    | Настроенные для Закачки Appx    ◄ [300] = Скачать выборочно    | Ввод номеров (1 3 5 ...)
       5 = "#White# [40]# = #Whit#$($L.s12)# $($L.s12_1) #DarkGray#| $($L.s12_2)  #DarkGray#◄#Whit# [400]# = #Whit#$($L.s12)# $($L.s12_3) #DarkGray#| $($L.s9_4)#"           # [40] = Установить Все | Найденные Appx в подпапках      ◄ [400] = Установить выборочно | Ввод номеров (1 3 5 ...)
       6 = "#White# [50]# = #Whit#$($L.s13)# $($L.s13_1) #DarkGray#| $($L.s13_2)  #DarkGray#◄#Whit# [500]# = #Whit#$($L.s13)# $($L.s13_3) #DarkGray#| $($L.s9_4)#"           # [50] = Удалить Все    | Найденные/Настроенные Apps      ◄ [500] = Удалить выборочно    | Ввод номеров (1 3 5 ...)
       7 = "#White# [60]# = #Whit#$($L.s14)# $($L.s14_1) #DarkGray#| $($L.s14_2)  #DarkGray#◄#Whit# [600]# = #Whit#$($L.s14)# $($L.s14_3) #DarkGray#| $($L.s9_4)#"           # [60] = Очистить Папку | Files\Appx\ от подпапок         ◄ [600] = Очистить выборочно   | Ввод номеров (1 3 5 ...)

     8 = "`n#White# [70]# = #Whit#$($L.s18)# $($L.s18_1) #DarkGray#| $($L.s18_2): $($AppxfolderGlobal.Replace($CurrentRoot,''))\#Gray#... #DarkGray#$($L.s18_3) |# ",        # [70] = Установить Все | Свои Appx файлы из папки: \Files\Appx\... (Пропуск подпапок) | Файлы не найдены
                            '& Set-Apps-Management | -CheckState AppxFiles'

   9 = "`n#DarkCya# [80]# = #DarkCyan#$($L.s19)# $($L.s19_1) #DarkGray#| $($L.s19_2)  #DarkCyan#◄ [800]# = #DarkCyan#$($L.s19_3)# $($L.s19_4) #DarkGray#| ",                 # [80] = Показать Имена | Автоочищаемых Системных Apps    ◄ [800] = Очистить Параметры   | 0 | Автоочистка для: 2
                            '& Set-Apps-Management | -CheckState CleanSystemApps'
      10 = "#Magen# [9!]# = #Mage#$($L.s20)# $($L.s20_1) #DarkGray#| $($L.s20_2)  #DarkMagenta#◄#Magenta# [9!0]# = #Magenta#$($L.s20)# $($L.s20_3) #DarkGray#| $($L.s9_4)#"  # [9!] = Установить Все | Удалённые системные Apps        ◄ [9!0] = Установить выборочно | Ввод номеров (1 3 5 ...)
       11 = "#Cyan# [$($L.s21)]# = #DarkGray#$($L.s21_1) #DarkCyan#[222]# = #DarkCyan#$($L.s21_2)# $($L.s21_3) #DarkGray#| $($L.s21_4)#"                                     # [Без ввода] = Возврат в меню Личных Настроек              [222] = Исправить Проблемы   | Staged Apps (Ввод номеров)

     12 = "$($L.s22) #DarkCya#[333]# = #DarkCyan#$($L.s22_1)# $($L.s22_2) #DarkGray#$($L.s22_3)#"                                                                            #                                                           [333] = Перезапустить Проводник (Корректно)

    }

    Selection = @{

        1 = '& Set-Apps-Management | -Option RunSaveListApps'

       10 = '& Set-Apps-Management | -Option RunUninstallApps'
      100 = '& Set-Apps-Management | -Option RunUninstallApps -Select'

       20 = '& Set-Apps-Management | -Option RunInstallApps'
      200 = '& Set-Apps-Management | -Option RunInstallApps -Select'

       30 = '& Set-Apps-Management | -Option RunDownloadAppx'
      300 = '& Set-Apps-Management | -Option RunDownloadAppx -Select'

       40 = '& Set-Apps-Management | -Option RunInstallDownloadedAppx'
      400 = '& Set-Apps-Management | -Option RunInstallDownloadedAppx -Select'

       50 = '& Set-Apps-Management | -Option RunUninstallApps -InstalledFromFolders'
      500 = '& Set-Apps-Management | -Option RunUninstallApps -InstalledFromFolders -Select'

       60 = '& Set-Apps-Management | -Option RunCleanDownloadedFolders'
      600 = '& Set-Apps-Management | -Option RunCleanDownloadedFolders -Select'

       70 = '& Set-Apps-Management | -Option RunInstallAppxFromFolder'

       80 = '& Set-Apps-Management | -Option CleanUninstalledSystemApps -NoPauses',   # Показать Имена Автоочищаемых Системных Apps
            '& Set-Apps-Management | -Option FixInstalledApps'                        # + Показать Проблемы установленных Apps
      800 = '& Set-Apps-Management | -Option CleanUninstalledSystemApps -Act Set'     # Очистить параметры удаленных системных Apps

     '9!' = '& Set-Apps-Management | -Option RunInstallApps -RestoreSystemApps'
    '9!0' = '& Set-Apps-Management | -Option RunInstallApps -RestoreSystemApps -Select'

      222 = '& Set-Apps-Management | -Option FixInstalledApps -Act Set -Select'            # Исправить проблемы установленных Apps
      333 = "   $($L.s23)", '& ReStart-Explorer'  # Перезапуск проводника (корректный)

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
