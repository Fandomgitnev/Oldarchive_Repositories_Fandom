﻿
$Menu_Set_Network_Settings = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#|# $($L.s1_1) #DarkGray#| $($L.s1_2) | #Blue#$($L.s1_3)#"  # Сеть | Настройка параметров | Для безопасности | Первый пункт [1] отключит Локальную Сеть!
        3 = "      #DarkGray#$($L.s2)#"                                                                  # Для Интернета достаточно компонента IPv4 в сетевом подключении
        4 = "      #DarkGray#$($L.s3)#"                                                                  # Но необходимо оставить компоненты: Бриджи Виртуальных Машин и Фаервола (Антивируса)
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        1 = "  $($L.s4): ", '& Check-State-Service | -ServiceName LanmanServer -Default Automatic -Need Disabled',  # Служба LanmanServer
                      "   $($L.s4_1): ", '& Set-Network-Settings | -CheckState NetMeeting',        # NetMeeting
                      "   $($L.s4_2): ", '& Set-Network-Settings | -CheckState RemoteAssistance'   # Удаленная Помощь


        2 = "  $($L.s5): ", '& Check-State-Driver | -DriverName NetBT -Default System -Need Disabled',  # Драйвер NetBios
                      "   $($L.s5_1): ", '& Set-Network-Settings | -CheckState RemoteMDM',              # Remote MDM
                      "   $($L.s5_2): ", '& Check-State-Task | -TaskName "\Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask" -Default Enabled -Need Disabled' # Задача Помощи


        3 = "  $($L.s6): ", '& Set-Network-Settings | -CheckState RemoteDCOM',                # Протокол DCOM
                     "    $($L.s6_1): ", '& Set-Network-Settings | -CheckState RemoteWinRM',  # Remote WinRM
                      "   $($L.s6_2): ", '& Check-State-Service | -ServiceName RemoteRegistry -Default Disabled -Need Disabled' # Служба RemoteRegistry

        4 = "  $($L.s7): ", '& Set-Network-Settings | -CheckState AutoShare',                                            #  Общие Адм. Ресурсы
                     "    $($L.s7_1): ", '& Check-State-Service | -ServiceName TrkWks -Default Automatic -Need Manual',  #  Служба TrkWks
                     "    $($L.s7_2): ", '& Check-State-Service | -ServiceName IKEEXT -Default Automatic -Need Manual'   #  Служба IKEEXT

        5 = "  $($L.s8): ", '& Set-Network-Settings | -CheckState ContextMenuShare'   # ПКМ Меню Отправить

      6 = "  $($L.s8_1): ", '& Set-Network-Settings | -CheckState MenuGiveAccessTo',   # ПКМ Меню Доступ
                     "    $($L.s8_2): ", '& Set-Network-Settings | -CheckState IPv6'   # Протокол IPv6

      7 = "`n  $($L.s9): ", '& Set-Network-Settings | -CheckState DnsLLMNR',                   #
                       "  $($L.s9_1): ", '& Set-Network-Settings | -CheckState DnsResolution', #
                      "   $($L.s9_2): ", '& Set-Network-Settings | -CheckState NCSI'           #

        8 = "  $($L.s9_3): ", '& Set-Network-Settings | -CheckState DnsParallel',              #
                       "  $($L.s9_4): ", '& Set-Network-Settings | -CheckState DnsDevolution' 

      9 = "`n  $($L.s10): ", '& Set-Network-Settings | -CheckState UnBlockAdress'      # Обход блокировок

     10 = '' #9 = "`n      #DarkGray#$($L.s11):#`n"  # Варианты для выбора
    }

    Options = @{

        0 = "#Cyan#  [0]# = #Green#$($L.s12) #White#$($L.s12_1) #DarkGray#| $($L.s12_2)#"   #  [0] = Выполнить 1-3 настройки сразу | Первые 3 варианта

      1 = "`n#Cyan#  [1]# = $($L.s13) #White#LanmanServ#DarkGray#/#White#NetBios#DarkGray#/#White#DCOM  #DarkGray#| $($L.s13_2) #DarkMagenta#◄#Magenta# [11]# = #Magenta#$($L.s13_3)#" # [1] = Отключить LanmanServ/NetBios/DCOM | Отключение служб локальной сети                      ◄ [11] = Восстановить
        2 = "#Cyan#  [2]# = $($L.s14) #White#$($L.s14_1) #DarkGray#| $($L.s14_2) #DarkMagenta#◄#Magenta# [12]# = #Magenta#$($L.s14_3)#"                                                # [2] = Отключить Удалённый доступ        | И Ручной режим служб: TrkWks, IKEEXT                 ◄ [12] = Восстановить
        3 = "#Cyan#  [3]# = $($L.s15) #White#$($L.s15_1) #DarkGray#| $($L.s15_2) #DarkMagenta#◄#Magenta# [13]# = #Magenta#$($L.s15_3)#"                                                # [3] = Отключить Общие Админ. Ресурсы    | C$, D$ и т.д.                                        ◄ [13] = Восстановить
        4 = "#Cyan#  [4]# = $($L.s16) #White#$($L.s16_1) #DarkGray#| $($L.s16_2) #DarkMagenta#◄#Magenta# [14]# = #Magenta#$($L.s16_3)#"                                                # [5] = Скрыть    Контекстные Меню        | Отправить (Share) + Предоставить доступ к            ◄ [15] = Восстановить
        5 = "#Cyan#  [5]# = $($L.s17) #White#$($L.s17_1) #DarkGray#| $($L.s17_2) #DarkMagenta#◄#Magenta# [15]# = #Magenta#$($L.s17_3)#"                                                # [5] = Скрыть    Контекстные Меню        | Отправить (Share) + Предоставить доступ к            ◄ [15] = Восстановить
        6 = "#Cyan#  [6]# = $($L.s18) #White#$($L.s18_1) #DarkGray#| $($L.s18_2) #DarkMagenta#◄#Magenta# [16]# = #Magenta#$($L.s18_3)#"                                                # [4] = Отключить протокол IPv6           | Лупбэк для программ будет работать                   ◄ [14] = Восстановить
        7 = "#Cyan#  [7]# = $($L.s19) #White#$($L.s19_1) #DarkGray#| $($L.s19_2) #DarkMagenta#◄#Magenta# [17]# = #Magenta#$($L.s19_3)#"                                                # [6] = Отключить Функции DNS             | LLMNR, Resolution, Devolution, ParallelAandAAAA      ◄ [16] = Восстановить
        8 = "#Cyan#  [8]# = $($L.s20) #White#$($L.s20_1)#", '& Set-Network-Settings | -CheckState PresetNCSI'," #DarkMagenta#◄#Magenta# [18]# = #Magenta#$($L.s20_3)#"                 # [7] = Настроить NCSI Индикатор Сети     | Debian NCSI                                          ◄ [17] = Восстановить
        9 = "#Cyan#  [9]# = $($L.s21) #White#$($L.s21_1)#", '& Set-Network-Settings | -CheckState UnBlockAdressCompare'," #DarkMagenta#◄#Magenta# [19]# = #Magenta#$($L.s21_3)#"       # [8] = Включить  Обход блокировок Сайтов | https://antizapret.prostovpn.org/proxy.pac           ◄ [18] = Восстановить

     10 = "`n#White# [10]# = #White#$($L.s22) #DarkGray#| $($L.s22_1)#"                     # [10] = Открыть Сетевые подключения | Для ручной настройки
      11 = "#Yellow# [20]# = #Yellow#$($L.s23) #DarkGray#| $($L.s23_1)#"                    # [20] = Меню Локальной Сети         | Настройка общего доступа к Локальной Сети

      12 = "`n#Cyan# [$($L.s24)]# = #DarkGray#$($L.s24_1)        #Magenta# [99]# = #Magenta#$($L.s24_2) #DarkGray#| $($L.s24_3)#`n"  # [Без ввода] = Возврат в меню Личных Настроек    [99] = Восстановить Все параметры  | По умолчанию
    }

    Selection = @{                                                          # ApplyGP у всех, чтобы пауза срабатывала только через это меню

        0 = '& Set-Network-Settings | -Act Set -Options DisableLocal,DisableRemote,DisableAdmRes -ApplyGP'

        1 = '& Set-Network-Settings | -Act Set -Options DisableLocal         -ApplyGP'
        2 = '& Set-Network-Settings | -Act Set -Options DisableRemote        -ApplyGP'
        3 = '& Set-Network-Settings | -Act Set -Options DisableAdmRes        -ApplyGP'
        4 = '& Set-Network-Settings | -Act Set -Options HideContextMenuShare -ApplyGP'
        5 = '& Set-Network-Settings | -Act Set -Options HideMenuGiveAccessTo -ApplyGP'
        6 = '& Set-Network-Settings | -Act Set -Options DisableIPv6          -ApplyGP'
        7 = '& Set-Network-Settings | -Act Set -Options DisableDnsFunctions  -ApplyGP'
        8 = '& Set-Network-Settings | -Act Set -Options ConfigNCSI           -ApplyGP'
        9 = '& Set-Network-Settings | -Act Set -Options EnableUnBlockSites   -ApplyGP'

       11 = '& Set-Network-Settings | -Act Default -Options DisableLocal         -ApplyGP'
       12 = '& Set-Network-Settings | -Act Default -Options DisableRemote        -ApplyGP'
       13 = '& Set-Network-Settings | -Act Default -Options DisableAdmRes        -ApplyGP'
       14 = '& Set-Network-Settings | -Act Default -Options HideContextMenuShare -ApplyGP'
       15 = '& Set-Network-Settings | -Act Default -Options HideMenuGiveAccessTo -ApplyGP'
       16 = '& Set-Network-Settings | -Act Default -Options DisableIPv6          -ApplyGP'
       17 = '& Set-Network-Settings | -Act Default -Options DisableDnsFunctions  -ApplyGP'
       18 = '& Set-Network-Settings | -Act Default -Options ConfigNCSI           -ApplyGP'
       19 = '& Set-Network-Settings | -Act Default -Options EnableUnBlockSites   -ApplyGP'

       10 = "    ► $($L.s22)", '& Start-Process | -FilePath ncpa.cpl', '& Start-Sleep | -Milliseconds 2000', '& Set-NoConsole-Scroll'   # Открытие Окна Сетевых подключений

       20 = "    ► $($L.s23)", '$Menu_Set_Network_Local'  # Меню Локальной Сети

       99 = '& Set-Network-Settings | -Act Default -Options DisableLocal,DisableRemote,DisableAdmRes,HideContextMenuShare,HideMenuGiveAccessTo,DisableIPv6,DisableDnsFunctions,ConfigNCSI,EnableUnBlockSites -ApplyGP'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
