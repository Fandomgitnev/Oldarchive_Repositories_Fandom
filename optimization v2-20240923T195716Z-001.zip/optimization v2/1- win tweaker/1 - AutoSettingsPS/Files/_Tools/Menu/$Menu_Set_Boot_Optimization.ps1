﻿
$Menu_Set_Boot_Optimization = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #DarkGray#| #Yellow#$($L.s1_2)" # Настройка Быстрого Запуска Windows, Гибернации | Оптимизации: RAM, Записи на диск, Запуска Windows и Программ
        3 = "      #DarkGray#$($L.s2)#"     # Быстрый запуск может создать проблемы, рекомендуется отключить.
        4 = "      #DarkGray#$($L.s3)#"     # Служба SysMain обеспечивает всю оптимизацию: RAM (Сжатие/Объединение страниц памяти и уменьшение записи на диск),
        5 = "      #DarkGray#$($L.s3_1)#"   # предугадывание запуска и предварительную выбору приложений, Запуска Windows.
        6 = "      #DarkGray#$($L.s3_2)#"   # Если системный диск SSD, оптимизацию Запуска Windows/Программ можно отключить (оптимизация памяти будет включена).
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

                   1 = "$($L.s4): ", '& Set-Boot-Optimization | -CheckState FastBoot'    # Быстрый запуск
                   2 = "$($L.s5): ", '& Set-Boot-Optimization | -CheckState Hibernate'   # Гибернация

                 3 = "`n$($L.s6): ", '& Check-State-Service | -ServiceName SysMain -Default Automatic -Need Disabled',  # Служба SysMain
                     "$($L.s6_1): ", '& Set-Boot-Optimization | -CheckState Superfetch'                                 # Параметр Superfetch

                   4 = "$($L.s7): ", '& Set-Boot-Optimization | -CheckState ReadyBoot',  # Анализ ReadyBoot
                   "  $($L.s7_1): ", '& Set-Boot-Optimization | -CheckState Prefetcher'  # Параметр Prefetcher

       5 = "`n#DarkGray#$($L.s8): "   #  Задачи SysMain
   6 = '      ResPriStaticDbSync: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\ResPriStaticDbSync" -Default Enabled -Need Disabled',
'    HybridDriveCachePrepopulate: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate" -Default Disabled -Need Disabled'

   7 = '    WsSwapAssessmentTask: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\WsSwapAssessmentTask" -Default Enabled -Need Disabled',
'      HybridDriveCacheRebalance: ', '& Check-State-Task | -TaskName "\Microsoft\Windows\Sysmain\HybridDriveCacheRebalance" -Default Disabled -Need Disabled'
    }

    Options = @{

       0 = "`n#DarkGray#$($L.s9):#`n"  # Настроить Запуск/Завершение работы Windows:

        1 = "#Cyan#  [1]# = $($L.s10) #DarkGray#| $($L.s10_1) #DarkMagenta#◄#Magenta# [101]# = #Magenta#$($L.s15)#"   # [1] = Отключить Быстрый запуск      | Для полноценного Завершения работы и Запуска Windows   ◄ [101] = Включить
        2 = "#Cyan#  [2]# = $($L.s11) #DarkGray#| $($L.s11_1) #DarkMagenta#◄#Magenta# [102]# = #Magenta#$($L.s15)#"   # [2] = Отключить Гибернацию          | Быстрый запуск Windows перестанет работать             ◄ [102] = Включить
    
       3 = "`n#DarkGray#$($L.s12):#`n" # Настроить Оптимизацию службой SysMain:
       
        4 = "#Cyan#  [3]# = $($L.s13) #DarkGray#| $($L.s13_1) #DarkMagenta#◄#Magenta# [103]# = #Magenta#$($L.s15)#"   # [3] = Отключить оптимизацию Запуска | Windows и Программ (Prefetch/Superfetch/ReadyBoot)     ◄ [103] = Включить
        5 = "#Cyan#  [4]# = $($L.s14) #DarkGray#| $($L.s14_1) #DarkMagenta#◄#Magenta# [104]# = #Magenta#$($L.s15)#"   # [4] = Отключить всю оптимизацию     | Памяти/Записи/Запуска (Службу SysMain/Задачи/Prefetch) ◄ [104] = Включить

      9 = "`n#Cyan#  [$($L.s16)]# = #DarkGray#$($L.s16_1)#`n"     # Без ввода = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Boot-Optimization | -Options FastBootDisable     -Act Set'
        2 = '& Set-Boot-Optimization | -Options HibernateDisable    -Act Set'
        3 = '& Set-Boot-Optimization | -Options PrefetchDisable     -Act Set'
        4 = '& Set-Boot-Optimization | -Options OptimizationDisable -Act Set'

      101 = '& Set-Boot-Optimization | -Options FastBootDisable     -Act Default'
      102 = '& Set-Boot-Optimization | -Options HibernateDisable    -Act Default'
      103 = '& Set-Boot-Optimization | -Options PrefetchDisable     -Act Default'
      104 = '& Set-Boot-Optimization | -Options OptimizationDisable -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
