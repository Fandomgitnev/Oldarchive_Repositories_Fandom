﻿
$Menu_Set_Lock_FilesExe = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"                                   # Запрет запуска EXE файлов по имени | Использовать осторожно, файлы могут влиять на загрузку Windows!
        3 = "      #DarkGray#$($L.s2)#"                                                        # Запрет может приводить к записи ошибок в журнал из-за невозможности запуска приложения, но не для всех файлов
        4 = "      #DarkGray#$($L.s3)#"                                                        # ● = Уже заблокирован; ○ = Не заблокирован
        5 = "      #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Список файлов exe можно изменить в файле пресетов, текущий файл:
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{
        
        1 = "      #DarkGray#$($L.s5  ): #",  '& Set-Lock-FilesExe | -CheckState PresetDebuggerCmd'  # Команда блокировки
        2 = "      #DarkGray#$($L.s5_1):#"    # Текущее состояние

        3 = '& Set-Lock-FilesExe | -CheckState ShowList'

      4 = "`n      #DarkGray#$($L.s6  ):#`n"  # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = #White#$($L.s7) #$($L.s7_1) #DarkGray#| $($L.s7_2)   #DarkCyan#◄#Cyan# [100]# = #White#$($L.s7 )# $($L.s7_3) #DarkGray#| $($L.s7_4)#"  #           [1] = Запретить Все | Без сообщений                      ◄ [100] = Запретить выборочно | Ввод номеров (1 3 5 ...)
        2 = "#Cyan#  [2]# = #White#$($L.s8) #$($L.s8_1) #DarkGray#| $($L.s8_2)   #DarkCyan#◄#Cyan# [200]# = #White#$($L.s8 )# $($L.s8_3) #DarkGray#| $($L.s8_4)#"  #           [2] = Запретить Все | При запуске показывать сообщение   ◄ [200] = Запретить выборочно | Ввод номеров (1 3 5 ...)

   3 = "`n#Magenta# [99]# = #Magenta#$($L.s9 ) #$($L.s9_1 ) #DarkGray#| $($L.s9_2 )   #DarkMagenta#◄#Magenta# [999]# = #Magenta#$($L.s9 )# $($L.s9_3 ) #DarkGray#| $($L.s9_4 )#"  # [99] = Восстановить Все | Разблокировать (По умолчанию)   ◄ [999] = Восстановить выборочно | Ввод номеров (1 3 5 ...)
     4 = "#Magenta# [9!]# = #Magenta#$($L.s10) #$($L.s10_1) #DarkGray#| $($L.s10_2)   #DarkMagenta#◄#Magenta# [99!]# = #Magenta#$($L.s10)# $($L.s10_3) #DarkGray#| $($L.s10_4)#"  # [9!] = Восстановить Все | И которых нет в пресете         ◄ [99!] = Восстановить выборочно | Ввод номеров (1 3 5 ...)

     5  = "#Cyan# [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n"  # [Без ввода] = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Lock-FilesExe | -Option LockFiles         -Act Set'
      100 = '& Set-Lock-FilesExe | -Option LockFiles         -Act Set -Select'

        2 = '& Set-Lock-FilesExe | -Option LockFilesWithShow -Act Set'
      200 = '& Set-Lock-FilesExe | -Option LockFilesWithShow -Act Set -Select'

       99 = '& Set-Lock-FilesExe | -Act Default'
      999 = '& Set-Lock-FilesExe | -Act Default -Select'

     '9!' = '& Set-Lock-FilesExe | -Act Default -AlsoNotInPreset'
    '99!' = '& Set-Lock-FilesExe | -Act Default -AlsoNotInPreset -Select'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
