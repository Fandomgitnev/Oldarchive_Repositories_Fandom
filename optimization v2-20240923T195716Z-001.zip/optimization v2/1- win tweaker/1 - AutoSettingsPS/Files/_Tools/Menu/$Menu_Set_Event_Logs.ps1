﻿
$Menu_Set_Event_Logs = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #DarkGray#| $($L.s1_2)#" # Настройка Журналов событий | Отключение Журналов уменьшает нагрузку на диск и процессор
        3 = "      #DarkGray#$($L.s2)#"                                 # Системные Журналы будут оставлены: Безопасность, Установка, Система и др. Но журнал PowerShell будет отключён
        4 = "      #DarkGray#$($L.s2_1): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Cписок исключённых журналов можно изменить в файле пресетов, текущий файл:
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        0 = "      $($L.s3  ): ", '& Check-State-Service | -ServiceName EventLog -Default Automatic -Need Disabled'     # Служба EventLog

    1 =   "`n      $($L.s4  ): ", '& Set-Event-Logs | -CheckState EventLogs', " #DarkGray#| $($L.s4_1)#"   # Журналы ... | Системные не учитываются
        2 = "      $($L.s4_2): ", '& Set-Event-Logs | -CheckState ExcludedLogs'   # Исключённые Журналы

      3 = "`n      #DarkGray#$($L.s5):#`n"  # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s6  ) #DarkGray#| $($L.s6_1)#"  # Отключение ведения всех журналов | Без Системных журналов
        2 = "#Cyan#  [2]# = $($L.s7  )#"                         # Очистка всех журналов
        3 = "#Cyan#  [3]# = $($L.s8  ) #DarkGray#| $($L.s8_1)#"  # Выполнить все действия | Отключить и Очистить

  4 = "`n#DarkCyan#  [4]# = $($L.s9  ) #DarkGray#| $($L.s9_1)#"  # Вывести список работающих журналов  | Кроме Системных журналов и исключённых
    5 = "#DarkCyan#  [5]# = $($L.s9_2) #DarkGray#| $($L.s9_3)#"  # Вывести список исключённых журналов | В файле пресетов

   6 = "`n#Magenta# [20]# = #Magenta#$($L.s10)# $($L.s10_1) #DarkGray#| $($L.s10_2)#" # Включить ведение всех журналов | Которые включены по умолчанию (317-341 шт)
     7 = "#Magenta# [99]# = #Magenta#$($L.s11)# $($L.s11_1) #DarkGray#| $($L.s11_2)#" # Включить ведение всех журналов | Которые включены по умолчанию (317-341 шт)

      8 = "`n#Cyan# [$($L.s12)]# = #DarkGray#$($L.s12_1)#`n"    # Без ввода = Возврат в меню Личных Настроек

    }

    Selection = @{

        1 = '& Set-Event-Logs | -Options EventLogsDisable -Act Set'
        2 = '& Set-Event-Logs | -Options ClearEventLogs   -Act Set'
        3 = '& Set-Event-Logs | -Options EventLogsDisable,ClearEventLogs -Act Set'

        4 = '& Set-Event-Logs | -Options ShowRunningLogs  -Act Check'
        5 = '& Set-Event-Logs | -Options ShowExcludedLogs -Act Check'

       20 = '& Set-Event-Logs | -Options EnableExcludedLogs -Act Set'
       99 = '& Set-Event-Logs | -Options EventLogsDisable -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
