﻿
$Menu_Set_Windows_Defender = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Защитник Windows и Центр Безопасности | Добавить в Исключения или Отключить
        3 = "      #DarkGray#$($L.s2)#"                       # Центр Безопасности контролирует состояние (Брандмауера, Антивируса, Обновления Windows, UAC и др.),
        4 = "      #DarkGray#$($L.s2_1)#"                     # запускает поиск вирусов, обеспечивает передачу данных для анализа безопасности и др.
        5 = "      #DarkGray#$($L.s2_2)#"                     # Если что-то не настроится, повторить выполнение ещё раз после перезагрузки
        6 = "      #Blue#$($L.s2_3)#"                         # Для отключения Защитника может потребоваться вручную отключить 'Защиту от Подделки' в его настройках
        7 = "      $($L.s2_4): ", '#White#& Run-Configs | -CheckState CurrentPreset#', ' #DarkGray#| & Set-Windows-Defender | -CheckState PresetExclusions'  # Папка скрипта будет добавлена в исключения. В файле Пресетов: \Presets  1.txt | Указано исключений: 6 шт
        8 = ' #DarkGray#======================================================================================================================#'
        9 = ''
    }

    Status = @{

        1 = "      $($L.s3 ): ", '& Set-Windows-Defender | -CheckState Exclusion'             # Исключение папки

        2 = "                      #DarkGray#$($L.s3_1):"                                     # Задачи
        3 = "      $($L.s4 ): ", '& Set-Windows-Defender | -CheckState Defender',             # Защитник
            "    $($L.s4_1 ): ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance" -Default Enabled -Need Disabled'
                                                                   
        4 = "      $($L.s5 ): ", '& Set-Windows-Defender | -CheckState Run',                  # Автозагрузка
            "    $($L.s5_1 ): ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cleanup" -Default Enabled -Need Disabled'
     
        5 = "      $($L.s6 ): ", '& Set-Windows-Defender | -CheckState TamperProtection',     # Защита от подделки
            "    $($L.s6_1 ): ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan" -Default Enabled -Need Disabled'
 
        6 = "                      $($L.s7): ", '& Check-State-Task | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Verification" -Default Enabled -Need Disabled'
        
        7 = "      $($L.s8 ): ", '& Set-Windows-Defender | -CheckState HideDefender'          # В Настройках

        8 = "      $($L.s9 ): ", '& Set-Windows-Defender | -CheckState ContextMenu',          # Контекстное меню
            "    $($L.s9_1 ): ", '& Set-Windows-Defender | -CheckState LockMpCmdRun'          # MpCmdRun.exe

      9 = "`n      $($L.s10): ", '& Check-State-Driver | -DriverName WdFilter -Default Boot -Need Disabled',                      # Драйвер WdFilter
                                 '& Check-State-Driver | -DriverName WdFilter -CheckStatus -Return Result',
               "     $($L.s10_1): ", '& Check-State-Service | -ServiceName SecurityHealthService -Default Manual -Need Disabled', # Служба SecurityHealthService
                                     '& Check-State-Service | -ServiceName SecurityHealthService -CheckStatus -Return Result'

       10 = "      $($L.s11): ", '& Check-State-Driver | -DriverName WdBoot -Default Boot -Need Disabled',                        # Драйвер WdBoot
                                 '& Check-State-Driver | -DriverName WdBoot -CheckStatus -Return Result',
               "     $($L.s11_1): ", '& Check-State-Service | -ServiceName WinDefend -Default Automatic -Need Disabled',          # Служба WinDefend
                                     '& Check-State-Service | -ServiceName WinDefend -CheckStatus -Return Result'

       11 = "      $($L.s12): ", '& Check-State-Driver | -DriverName WdNisDrv -Default Manual -Need Disabled',                    # Драйвер WdNisDrv
                                 '& Check-State-Driver | -DriverName WdNisDrv -CheckStatus -Return Result',
               "     $($L.s12_1): ",'& Check-State-Service | -ServiceName WdNisSvc -Default Manual -Need Disabled',               # Служба WdNisSvc
                                    '& Check-State-Service | -ServiceName WdNisSvc -CheckStatus -Return Result'

       12 = "      $($L.s13): ", '& Check-State-Driver | -DriverName MsSecFlt -Default Manual -Need Disabled',                    # Драйвер MsSecFlt
                                 '& Check-State-Driver | -DriverName MsSecFlt -CheckStatus -Return Result',
               "     $($L.s13_1): ",'& Check-State-Service | -ServiceName Sense -Default Manual -Need Disabled',                  # Служба Sense
                                    '& Check-State-Service | -ServiceName Sense -CheckStatus -Return Result'

     13 = "`n      #DarkGray#$($L.s14):"                                                                                          # Центр Безопасности
       14 = "      $($L.s15): ", '& Set-Windows-Defender | -CheckState SecurityCenterNotifications',                              # Уведомления
               "    $($L.s15_1 ): ", '& Check-State-Service | -ServiceName SgrmBroker -Default Manual -Need Disabled',            # Служба SgrmBroker
                                     '& Check-State-Service | -ServiceName SgrmBroker -CheckStatus -Return Result'

       15 = "      $($L.s16): ", '& Check-State-Service | -ServiceName wscsvc -Default Manual -Need Disabled',                    # Служба wscsvc
                                 '& Check-State-Service | -ServiceName wscsvc -CheckStatus -Return Result',
              "     $($L.s16_1 ): ", '& Check-State-Driver | -DriverName SgrmAgent -Default Manual -Need Disabled',               # Драйвер SgrmAgent
                                     '& Check-State-Driver | -DriverName SgrmAgent -CheckStatus -Return Result'

     16 = "`n      #DarkGray#$($L.s17):#`n"  # Варианты для выбора

    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s18) #DarkGray#| $($L.s18_1)#"                                                          #  [1] = Добавить в Исключения        | Только Исключения для Защитника
        2 = "#Cyan#  [2]# = $($L.s19) #DarkGray#| $($L.s19_1)   #DarkMagenta#◄#Magenta# [102]# = #Magenta#$($L.s19_2)#"  #  [2] = Отключить Защитник           | Отключение всех компонентов + Исключения   ◄ [102] = Включить
        3 = "#Cyan#  [3]# = $($L.s20) #DarkGray#| $($L.s20_1)   #DarkMagenta#◄#Magenta# [103]# = #Magenta#$($L.s19_2)#"  #  [3] = Отключить Центр Безопасности | Уведомления, службы и драйвер              ◄ [103] = Включить

        4 = "`n#Cyan# [$($L.s21)]# = #DarkGray#$($L.s21_1)   #Blue# [200]# = #Blue#$($L.s21_2)#`n"   # [Без ввода] = Возврат в меню Личных Настроек
    }

    Selection = @{                                                  # ApplyGP для вызова паузы при запуске из меню, чтобы через быстрые настройки не было паузы

        1 = '& Set-Windows-Defender | -Act Set -Option AddExclusions         -ApplyGP'
        2 = '& Set-Windows-Defender | -Act Set -Option DefenderDisable       -ApplyGP'
        3 = '& Set-Windows-Defender | -Act Set -Option SecurityCenterDisable -ApplyGP'

      102 = '& Set-Windows-Defender | -Act Default -Option DefenderDisable       -ApplyGP'
      103 = '& Set-Windows-Defender | -Act Default -Option SecurityCenterDisable -ApplyGP'

      200 = '& Set-Windows-Defender | -Act Check -Option OpenThreatSettings'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
