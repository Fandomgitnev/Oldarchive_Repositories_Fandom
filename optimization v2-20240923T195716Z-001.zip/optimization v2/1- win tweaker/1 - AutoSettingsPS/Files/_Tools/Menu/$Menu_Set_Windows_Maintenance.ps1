﻿
$Menu_Set_Windows_Maintenance = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#$($L.s1) #DarkGray#|# $($L.s1_1)" # Обслуживание Windows | Управление и Выполнение
        3 = "       #DarkGray#$($L.s2)#"                      # Возможность выполнить 5 важных последовательных действий, при запрещённом обслуживании
        4 = "       #DarkGray#$($L.s3)#"                      # Либо использовать встроенное стандартное обслуживание из Центра Безопасности и Обслуживания
        5 = "       #DarkGray#$($L.s4)#"                      # Очистку достаточно делать раз в пол года. Зависит от ситуации и свободного места на диске
        6 = "       #Blue#$($L.s5)#"                          # Перед выполнением любого обслуживания закройте все приложения, и дождитесь завершения!
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s6): #"     # В данный момент
        1 = "       $($L.s7 )#DarkGray#: #", '& Set-Windows-Maintenance | -CheckState Maintenance',             # Обслуживание
                "          $($L.s7_1)#DarkGray#: #", '& Set-Windows-Maintenance | -CheckState WakeUpForMaint',  # Пробуждение
                "          $($L.s7_2)#DarkGray#: #", '& Test-Internet | -Menu'                                  # Интернет
        2 = ''
    }

    Options = @{

      1 = "#Yellow#   [1]# = #Yellow#$($L.s8) #DarkGray#| $($L.s8_1)#"                                                       #  [1] = Меню Установки файлов Обновлений | Ручная установка файлов MSU или CAB из папки: \Files\Update
      2 = "#Yellow#   [2]# = #Yellow#$($L.s9) #DarkGray#| $($L.s9_1)#"                                                       #  [2] = Меню Бэкап/Установки Драйверов   | Резервирование/установка драйверов из папки:  \Files\Update\Drivers

      3 = "`n#Cyan#   [3]# = #Magenta#$($L.s10) #White#[4] [5] [6] [7] #DarkGray#| $($L.s10_2) | #Blue#~60 $($L.s10_3)#"      # [3] = Выполнить [4] [5] [6] [7]  | 4 варианта за раз | ~60 мин


      4 = "`n#Cyan#   [4]# = #Magenta#$($L.s11)# $($L.s11_1) #DarkGray#| $($L.s11_2) | #Blue#~7 $($L.s10_3)#"                #  [3] = Сгенерировать образа .NET  | .NET Framework для программ (Ngen.exe)  | ~7 мин
        5 = "#Cyan#   [5]# = #Magenta#$($L.s12)# $($L.s12_1) #DarkGray#| $($L.s12_2) | #",                                   #  [4] = Очистить папку WinSxS      | Очистка и сжатие старых обновлений      | ~40 мин
                                                              '& Set-Windows-Maintenance | -CheckState PresetResetBase'
        6 = "#Cyan#   [6]# = #Magenta#$($L.s13)# $($L.s13_1) #DarkGray#| $($L.s13_2) | #Blue#~20 $($L.s10_3)#"               #  [5] = Очистить Cистемный диск C: | Папки temp, логи, дампы и т.д.          | ~20 мин
        7 = "#Cyan#   [7]# = #Magenta#$($L.s14)# $($L.s14_1) #DarkGray#| $($L.s14_2): #",
                                                              '& Set-Windows-Maintenance | -CheckState PresetTimeServers',
                                                              " #DarkGray#$($L.s14_3)#"                                      #  [6] = Синхронизировать время     | Доп. Серверов: 6 шт (Возможна задержка)

    8 = "`n#Yellow#   [8]# = #Yellow#$($L.s15) #DarkGray#| $($L.s15_1)#"                                                     #  [8] = Меню оптимизации дисков | Дефрагментация, TRIM, Создание раздельных задач

      9 = "`n#Cyan#   [9]# = #Magenta#$($L.s16)# $($L.s16_1) #DarkGray#| $($L.s16_2) | #Blue#~60 $($L.s10_3)#"               #  [9] = Начать Стандартное Обслуживание Windows | Включит обслуживание и важные задачи | ~60 мин
        10 = "#Red#  [10]# = #Red#$($L.s17)# $($L.s17_1)#"                                                                   # [10] = Остановить Стандартное Обслуживание Windows

     11 = "`n#Cyan#  [20]# = $($L.s18)  #DarkMagenta#◄#Magenta# [120]# = #Magenta#$($L.s18_1) #DarkGray#| $($L.s18_2)#"      # [20] = Запретить Стандартное Обслуживание      ◄ [120] = Разрешить | По умолчанию
       12 = "#Cyan#  [21]# = $($L.s19)  #DarkMagenta#◄#Magenta# [121]# = #Magenta#$($L.s19_1) #DarkGray#| $($L.s19_2)#"      # [21] = Запретить Пробуждение для Обслуживания  ◄ [121] = Разрешить | По умолчанию

     13 = "`n#Cyan#  [$($L.s20)]# = #DarkGray#$($L.s20_1)#`n" #  [Без ввода] = Возврат в Главное Меню

    }

    Selection = @{

        1 = "    ► $($L.s8)",  '$Menu_Install_Offline_UpdateFiles' # Меню Установки файлов Обновлений
        2 = "    ► $($L.s9)",  '$Menu_BackUp_Install_Drivers'      # Меню Бэкап/Установки Драйверов

        3 = '& Set-Windows-Maintenance | -Options RunNgen,RunClearWinSxS,RunDiskClean,RunTimeSync -GetPause -Act Set'
        4 = '& Set-Windows-Maintenance | -Options RunNgen        -GetPause -Act Set'
        5 = '& Set-Windows-Maintenance | -Options RunClearWinSxS -GetPause -Act Set'
        6 = '& Set-Windows-Maintenance | -Options RunDiskClean   -GetPause -Act Set'
        7 = '& Set-Windows-Maintenance | -Options RunTimeSync    -GetPause -Act Set'

        8 = "    ► $($L.s15)", '$Menu_Set_Drives_Optimization'     # Меню оптимизации дисков

        9 = '& Set-Windows-Maintenance | -Options  RunStandartMaint  -GetPause -Act Set'
       10 = '& Set-Windows-Maintenance | -Options StopStandartMaint  -GetPause -Act Set'

       20 = '& Set-Windows-Maintenance | -Options MaintenanceDisable -GetPause -Act Set'
       21 = '& Set-Windows-Maintenance | -Options WakeUpMaintDisable -GetPause -Act Set'

      120 = '& Set-Windows-Maintenance | -Options MaintenanceDisable -GetPause -Act Default'
      121 = '& Set-Windows-Maintenance | -Options WakeUpMaintDisable -GetPause -Act Default'

   'Exit' = "  ◄◄◄ $($L.s20_1)", '$MainMenu' # Возврат в Главное Меню

    }
}
