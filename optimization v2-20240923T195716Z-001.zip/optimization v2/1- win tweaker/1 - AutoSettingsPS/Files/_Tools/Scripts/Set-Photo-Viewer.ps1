﻿
<#
.SYNOPSIS
 Восстановление параметров Стандартного просмотрщика Фото (Windows Photo Viewer).
 И корректное назначение на открытие указанных прямо или в пресете расширений,
 с генерацией Hash.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Photo_Viewer.
 Используется функция Set-OwnerAndAccess для настройки параметров безопасности через SDDL.
 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-FTAssociation для назначения файловых ассоциаций, с генерацией Hash
 и дополнительными параметрами и действиями.
 Для выполнения всех действий нужны права администратора.

 Получает из файла пресетов 'Presets.txt' список для назначения,
 неподходящие расширения будут пропущены.

.PARAMETER Extensions
 Массив с нужными расширениями файлов. Возможны только из этого списка расширений:
 'jpg', 'jpe', 'jpeg', 'jfif', 'bmp', 'dib', 'wdp', 'jxr', 'png', 'tiff', 'tif', 'gif'
 Если не указаны, берутся из файла пресетов.


.EXAMPLE
    Set-Photo-Viewer -Option OnlyRestore -Act Set

    Описание
    --------
    Только восстановит параметры Windows Photo Viewer.

.EXAMPLE
    Set-Photo-Viewer -Option SetToOpen -Act Set

    Описание
    --------
    Восстановит параметры Windows Photo Viewer, и назначит на открытие расширения из списка в пресете.

.EXAMPLE
    Set-Photo-Viewer -Option SetToOpen -Act Set -Extensions bmp,jpg

    Описание
    --------
    Восстановит параметры Windows Photo Viewer, и назначит на открытие указанные расширения.

.EXAMPLE
    Set-Photo-Viewer -CheckState Extension -Extensions jpg

    Описание
    --------
    Отобразит назначено ли это расширение на открытие через Windows Photo Viewer, этой функцией!
    Проверяется вариант, как настраивает данная функция, а не система!
    Система записывает параметр по другому. Если назначить вручную в параметрах, то функция это не определит.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  21-03-2019
 ===============================================

#>
Function Set-Photo-Viewer {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут используется только Set, а оставлены все варианты, чтобы не выкидывало ошибок и пропускало действие при неправильном варианте.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'OnlyRestore', 'SetToOpen' )]
        [string] $Option = 'OnlyRestore'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Extension', 'Preset', 'SystemSettings' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'jpg', 'jpe', 'jpeg', 'jfif', 'bmp', 'dib', 'wdp', 'jxr', 'png', 'tiff', 'tif', 'nef', 'orf', 'arw', 'cr2', 'gif' )]
        [string[]] $Extensions
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Список подходящих расширений для назначения на Windows Photo Viewer.
    [string[]] $ValidExt = 'jpg', 'jpe', 'jpeg', 'jfif', 'bmp', 'dib', 'wdp', 'jxr', 'png', 'tiff', 'tif', 'nef', 'orf', 'arw', 'cr2', 'gif'

    # Карта-шаблон параметров для настройки ассоциаций файлов, или их проверки.
    [hashtable] $ExtMap = @{

        'bmp'  = 'PhotoViewer.FileAssoc.Bitmap'
        'dib'  = 'PhotoViewer.FileAssoc.Bitmap'
        'jpg'  = 'PhotoViewer.FileAssoc.Jpeg'
        'jpe'  = 'PhotoViewer.FileAssoc.Jpeg'
        'jpeg' = 'PhotoViewer.FileAssoc.Jpeg'
        'jfif' = 'PhotoViewer.FileAssoc.Jfif'
        'png'  = 'PhotoViewer.FileAssoc.Png'
        'wdp'  = 'PhotoViewer.FileAssoc.Wdp'
        'jxr'  = 'PhotoViewer.FileAssoc.Wdp'
        'tif'  = 'PhotoViewer.FileAssoc.Tiff'
        'tiff' = 'PhotoViewer.FileAssoc.Tiff'
        'nef'  = 'PhotoViewer.FileAssoc.Tiff'
        'orf'  = 'PhotoViewer.FileAssoc.Tiff'
        'arw'  = 'PhotoViewer.FileAssoc.Tiff'
        'cr2'  = 'PhotoViewer.FileAssoc.Tiff'
        'gif'  = 'PhotoViewer.FileAssoc.Gif'
    }

    # Если не переданы функции расширения, иначе назначаем их
    if ( -not $Extensions )
    {
        # Получение расширений из файла пресетов.
        try { [string[]] $Presets = Select-String -LiteralPath $FilePresets -Pattern 'Set-Windows-Photo-Viewer' -SimpleMatch -Encoding utf8 -ErrorAction SilentlyContinue }
        catch {}

        # Раз есть параметры для расширений, берем из них список указанных там расширений в массив, исключая все лишнее, согласно подходящим расширениям.
        try { [string[]] $SetExtensions = ($Presets -like "*Set-Windows-Photo-Viewer*").Split('=',3)[1].Split().Where({ $_ -match "^$($ValidExt -join '$|^')$" }) }
        catch {}
    }
    else { [string[]] $SetExtensions = $Extensions }


    if ( $CheckState )
    {
        if ( $CheckState -eq 'Preset' )
        {
            # Если вызвана проверка наличия указанных в пресете расширений.

            # Если массив для расширений пустой. Иначе задаем и выводим список расширений.
            if ( -not $SetExtensions.Count )
            {
                [string] $isExt = "#Red#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Нет указанных расширений!" })
            }
            else
            {
                [string] $isExt = "#Green#{0}#" -f ( $SetExtensions -join ' ' )
            }

            $isExt
        }
        elseif ( $CheckState -eq 'SystemSettings' )
        {
            # Если вызвана проверка наличия восстановленных параметров Windows Photo Viewer. Проверяется по 2 разделам одного параметра.

            [string] $Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Photo Viewer\Capabilities\FileAssociations"
            [string] $CapabAssoc = [Microsoft.Win32.Registry]::GetValue($Path,'.wdp',$null)

            [string] $Path = "HKEY_LOCAL_MACHINE\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp\shell\open\DropTarget"
            [string] $CapabClsid = [Microsoft.Win32.Registry]::GetValue($Path,'Clsid',$null)

            if (( 'PhotoViewer.FileAssoc.Wdp' -eq $CapabAssoc ) -and ( '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}' -eq $CapabClsid ))
            {
                [string] $isSettings = "#Green#{0} #DarkGray#| {1}#" -f $(if ( $L.s3 ) { $L.s3, $L.s3_1 } else { "Восстановлена", "Вероятно" })
            }
            else { [string] $isSettings = "#Yellow#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Не восстановлена" }) }

            $isSettings
        }
        elseif ( $CheckState -eq 'Extension' )
        {
            # Если вызвана проверка назначено ли на открытие расширение, проверяется по методу назначения этой функцией, а не системой.

            if ( -not $SetExtensions.Count ) { [string] $isProgId = "#Red#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Нет указанных расширений!" }) }
            elseif ( $SetExtensions.Count -eq 1 )
            {
                [string] $Path = "HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.$SetExtensions\UserChoice"
                [string] $ProgId = [Microsoft.Win32.Registry]::GetValue($Path,'ProgId',$null)
                [string] $ValidProgId = $ExtMap[$SetExtensions]

                if ( $ValidProgId -eq $ProgId ) { [string] $isProgId = "#Green#{0}#"  -f $(if ( $L.s5 ) { $L.s5 } else { "Назначено"    }) }
                else                            { [string] $isProgId = "#Yellow#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Не назначено" }) }
            }
            else  { [string] $isProgId = "#Red#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Проверять только по одному расширению за раз!" }) }

            $isProgId
        }

        Return   # Выход из функции
    }


    # Далее, если выполнение ...


    if (( $Act -eq 'Check' ) -or ( $Act -eq 'Default' ))
    {
        $text = if ( $L.s8 ) { $L.s8 } else { "'Check/Default' не предусмотрены для настройки Стандартного просмотрщика Фото" }
        Write-Host "`n $NameThisFunction`: $text`n" -ForegroundColor DarkGray

        Return   # Выход из функции
    }


    $text = if ( $L.s9 ) { $L.s9 } else { "Функция 'Set-OwnerAndAccess' не подгружена!" }
    # Проверка наличия функции Set-OwnerAndAccess, используется для настройки параметров безопасности через SDDL.
    if ( -not ( Get-Command -CommandType Function -Name 'Set-OwnerAndAccess' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.

    $text = if ( $L.s10 ) { $L.s10 } else { "Функция 'Set-Reg' не подгружена!" }
    # Проверка наличия функции Set-Reg.
    if ( -not ( Get-Command -CommandType Function -Name 'Set-Reg' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.

    $text = if ( $L.s11 ) { $L.s11 } else { "Восстановление" }
    Write-Host "`n██ $text " -ForegroundColor White -NoNewline

    $text = if ( $L.s11_1 ) { $L.s11_1 } else { "Стандартного просмотрщика Фото" }
    Write-Host "$text " -ForegroundColor White -NoNewline

    $text = if ( $L.s11_2 ) { $L.s11_2 } else { "Функция" }
    Write-Host "(Windows Photo Viewer) | $text`: $NameThisFunction" -ForegroundColor DarkGray

    $text = if ( $L.s12 ) { $L.s12 } else { "Возврат поддержки графических файлов" }
    Write-Host "`n   $text`n" -ForegroundColor Cyan

    <##>

    [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows Photo Viewer\Capabilities\FileAssociations'

    # Выполнение для всех расширений из карты $ExtMap.
    # Переменные $Path, $Name и $Value везде и тут, нужны для замены их на значения из них для вывода в функции Set-Reg, иначе будет вывод названий переменных.
    foreach ( $Ext in $ExtMap.Keys )
    {
        [string] $Name  = ".$Ext"
        [string] $Value = $ExtMap[$Ext]

        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
    }

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Photo Viewer\Capabilities" -Name 'ApplicationDescription' -Type String '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3069'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows Photo Viewer\Capabilities" -Name 'ApplicationName' -Type String '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3009'

    $text = if ( $L.s13 ) { $L.s13 } else { "Добавление в меню для поддержки открытия файлов" }
    Write-Host "`n   $text`n" -ForegroundColor Cyan

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Applications\photoviewer.dll\shell\open" -Name 'MuiVerb' -Type String '@photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Applications\photoviewer.dll\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Applications\photoviewer.dll\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Jpeg`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg" -Name 'EditFlags' -Type DWord 10000
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg" -Name 'FriendlyTypeName' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll,-3055'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\imageres.dll,-72'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Jpeg\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\jpegfile\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\jpegfile\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\jpegfile\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.jpe' -Type DWord 0
    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.jpeg' -Type DWord 0
    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.jpg' -Type DWord 0

    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Bitmap`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Bitmap" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Bitmap" -Name 'FriendlyTypeName' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll,-3056'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Bitmap\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\imageres.dll,-70'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Bitmap\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Bitmap\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Paint.Picture\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Paint.Picture\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\Paint.Picture\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.bmp' -Type DWord 0
    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.dib' -Type DWord 0


    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Gif`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Gif" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Gif" -Name 'FriendlyTypeName' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll,-3057'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Gif\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\imageres.dll,-83'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Gif\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Gif\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\giffile\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\giffile\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\giffile\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.gif' -Type DWord 0
    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.ico' -Type DWord 0

    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Png`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Png" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Png" -Name 'FriendlyTypeName' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll,-3057'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Png\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\imageres.dll,-71'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Png\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Png\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pngfile\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pngfile\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pngfile\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.png' -Type DWord 0

    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Wdp`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp" -Name 'EditFlags' -Type DWord 10000
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\wmphoto.dll,-400'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.Wdp\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\wdpfile\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\wdpfile\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\wdpfile\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.wdp' -Type DWord 0
    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.jxr' -Type DWord 0

    $text = if ( $L.s14 ) { $L.s14 } else { "Восстановление параметров" }
    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s14_1 ) { $L.s14_1 } else { "для" }
    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
    Write-Host ".Jfif`n" -ForegroundColor White

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF" -Name 'EditFlags' -Type DWord 10000
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF" -Name 'ImageOptionFlags' -Type DWord 1
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF" -Name 'FriendlyTypeName' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll,-3055'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF\DefaultIcon" -Name '' -Type String '%SystemRoot%\System32\imageres.dll,-72'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\PhotoViewer.FileAssoc.JFIF\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pjpegfile\shell\open" -Name 'MuiVerb' -Type ExpandString '@%ProgramFiles%\Windows Photo Viewer\photoviewer.dll,-3043'
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pjpegfile\shell\open\command" -Name '' -Type ExpandString "%SystemRoot%\System32\rundll32.exe `"%ProgramFiles%\Windows Photo Viewer\PhotoViewer.dll`", ImageView_Fullscreen %1"
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\Classes\pjpegfile\shell\open\DropTarget" -Name 'Clsid' -Type String '{FFE2A43C-56B9-4bf5-9A79-CC6D4285608A}'

    Set-Reg New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts" -Name 'PBrush_.jfif' -Type DWord 0

    

    # Если указано назначить на открытие файлов, и есть переданные расширения, или полученные из пресета.
    if (( $Option -eq 'SetToOpen' ) -and $SetExtensions.Count )
    {
        # Проверка наличия функции Set-FTAssociation
        if ( -not ( Get-Command -CommandType Function -Name 'Set-FTAssociation' -ErrorAction SilentlyContinue ))
        { Write-Warning "`n  $NameThisFunction`: Function not found: Set-FTAssociation" ; Get-Pause ; Return } # Выход из функции.

        $text = if ( $L.s16 ) { $L.s16 } else { "Корректное назначение указанных расширений" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { "на открытие" }
        Write-Host "$text " -ForegroundColor White

        $text = if ( $L.s17 ) { $L.s17 } else { "С восстанавлением запрета на изменение в разделе и генерацией Hash" }
        Write-Host "   $text`n" -ForegroundColor DarkGray

        foreach ( $Ext in $SetExtensions )
        {
            $text = if ( $L.s18 ) { $L.s18 } else { "Расширение" }
            Write-Host "   • $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$Ext " -ForegroundColor Cyan

            # Выполняем назначение на открытие с генерацией Hash указанного ID и расширения, и установки запрета доступа на изменения на раздел.
            # Так же установка дополнительных параметров для соблюдения основных условий, чтобы в будущем не было сброса расширения на программу по умолчанию
            Set-FTAssociation -Extension ".$Ext" -ProgId "$($ExtMap[$Ext])"
        }    
    }
    elseif (( $Option -eq 'SetToOpen' ) -and ( -not $SetExtensions.Count ))
    {
        $text = if ( $L.s2 ) { $L.s2 } else { "Нет указанных расширений!" }
        Write-Host "`n   $text`n" -ForegroundColor Yellow
    }

    Get-Pause
}
