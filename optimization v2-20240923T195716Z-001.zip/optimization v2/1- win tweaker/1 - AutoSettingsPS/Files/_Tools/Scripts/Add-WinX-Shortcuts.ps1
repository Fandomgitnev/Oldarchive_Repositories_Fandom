﻿
<#
.SYNOPSIS
 Создание своих ярлыков в меню Win+X в указанной группе и позиции

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 
 Используется функция Manage-Shortcuts
 Используется функция ReStart-Explorer

.EXAMPLE

    Add-WinX-Shortcuts -Act Check
    Add-WinX-Shortcuts -Act Set
    Add-WinX-Shortcuts -Act Default


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  07-05-2022
 ===============================================

#>
Function Add-WinX-Shortcuts {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    # В каких группах надо удалить все ярлыки
    [array] $GroupsRemove = @()

    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Remove-Shortcuts-WinX-Group\s*=\s*1\s*=\s*(?<Groups>[a-z0-9,\s]+)==' },'First') )
    {
        foreach ( $Gr in $Matches.Groups.Split(',').Trim() )
        {
            if ( $Gr -match '^Group[1-9]$' ) { $GroupsRemove += $Gr }
        }

        if ( $GroupsRemove.Count ) { $GroupsRemove = $GroupsRemove | Sort-Object -Unique }
    }

    # Удалить ярлыки перед добавлением своих
    [array] $LnkRemove = @()

    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Remove-Shortcuts-WinX\s*=\s*1\s*=\s*(?<Lnk>[^=]+)==' },'First') )
    {
        foreach ( $Lnk in $Matches.Lnk.Split(',').Trim() )
        {
            $LnkRemove += $Lnk
        }

        if ( $LnkRemove.Count ) { $LnkRemove = $LnkRemove | Sort-Object -Unique }
    }

    # Для параметров ярлыков WinX из пресета
    [System.Collections.Generic.List[PSObject]] $AddShortcuts = @()

    # Получаем список и заполняем таблицу
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Add-Shortcut-To-WinX\s*=\s*1\s*=' | Sort-Object ))
    {
        # Берем заданный цвет
        if ( $Line -match '^\s*Add-Shortcut-To-WinX\s*=\s*1\s*=\s*(?<G>Group[1-9])\s*=\s*(?<N>N[1-9][0-9]*)\s*=\s*(?<Name>[^=]+)\s*=\s*(?<T>[^=]+)\s*=\s*(?<A>[^=]+)?\s*=\s*(?<W>[^=]+)?\s*=\s*(?<S>[a-z]+)?\s*=\s*(?<R>[a-z]+)?\s*=' )
        {
            try { $Name   = $Matches.Name.Trim().Split([System.IO.Path]::GetInvalidFileNameChars()) -join '_' } catch { $Name = $null }
            try { $Target = $Matches.T.Trim()    } catch { $Target = $null }

            if ( $Name -and $Target )
            {
                try { $Args    = $Matches.A.Trim() } catch { $Args    = $null }
                try { $WorkDir = $Matches.W.Trim() } catch { $WorkDir = $null }

                $elevate = $false
                try { if ( $Matches.R.Trim() -eq 'RunAsAdmin' ) { $elevate = $true } } catch {}
                
                $Style = $null
                try {
                    $Style = $Matches.S.Trim()
                    if     ( $Style -eq 'Min' ) { $Style = 'SHOWMINNOACTIVE' }
                    elseif ( $Style -eq 'Max' ) { $Style = 'SHOWMAXIMIZED' }
                    else                        { $Style = $null }
                } catch {}

                [int] $N = $Matches.N.Trim('N')

                while ( $AddShortcuts.Where({ $_.Group -eq $Matches.G }).N -like $N ) { $N++ }

                $AddShortcuts.Add( [PSCustomObject]@{
                    Group   = $Matches.G
                    N       = $N
                    Name    = $Name

                    targetPath  = $Target
                    arguments   = $Args
                    workingDir  = $WorkDir
                    windowStyle = $Style
                    elevate     = $elevate
                })
            }
        }
    }

    # Профили
    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    [array] $Accs = [PSCustomObject] @{ 
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        #Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source
    }

    if ( $Global:DataAllUsers.Redirects.Value )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({
            
            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                #Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source
            }
        })
    }

    [int] $LnkCount = 0

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Настройка Win+X меню" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { "Проверка" }
        Write-Host "| $text " -ForegroundColor DarkCyan -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        foreach ( $Acc in $Accs )
        {
            $NameUser = $Acc.Name
            $Profile  = $Acc.Profile

            Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
            Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

            [System.Collections.Generic.List[PSObject]] $Links = @()

            foreach ( $Group in ( $AddShortcuts.Group | Sort-Object -Unique ))
            {
                @(Get-ChildItem -File -LiteralPath "$Profile\AppData\Local\Microsoft\Windows\WinX\$Group" -ErrorAction SilentlyContinue).Where({ $_.Name -like "*.lnk" }) |
                    ForEach-Object {

                        if ( $_.Name -match '^[^\s_]+[+]0*[1-9][0-9]*\s-\s.+[.]lnk$' )
                        {
                            $Links.Add( [PSCustomObject]@{
                                Group   = $Group
                                Comment = Manage-Shortcuts -GetComment $_.FullName
                            })
                        }
                    }
            }

            [int] $Lenght = 0
            foreach ( $Name in $AddShortcuts.Name ) { if ( $Name.Length -gt $Lenght ) { $Lenght = $Name.Length }}

            $LnkCount = 0

            foreach ( $Shortcut in ( $AddShortcuts | Sort-Object -Property Group, N ))
            {
                if ( $LnkCount -eq 0 ) { Write-Host }
                
                if ( $Links.Where({ $_.Group -eq $Shortcut.Group -and $_.Comment -eq $Shortcut.Name }) )
                {
                    Write-Host "   +++ " -ForegroundColor Green -NoNewline
                    Write-Host "$($Shortcut.Group): " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$("{0,-$Lenght}" -f $Shortcut.Name) " -ForegroundColor Green -NoNewline
                    Write-Host "| $($Shortcut.targetPath)" -ForegroundColor DarkGray
                }
                else
                {
                    Write-Host "   --- " -ForegroundColor Yellow -NoNewline
                    Write-Host "$($Shortcut.Group): " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$("{0,-$Lenght}" -f $Shortcut.Name) " -ForegroundColor Yellow -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($Shortcut.targetPath)" -ForegroundColor DarkYellow

                    $NeedFix = $true
                }

                $LnkCount++
            }
        }

        if ( -not $LnkCount )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Ярлыки не настроены в пресете" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
        else
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Выполнено" }
            Write-Host "`n   $text" -ForegroundColor Green
        }
        
        Return
    }

    # Далее настройка

    [int] $LnkCreated = 0

    if ( $Act -eq 'Default' ) 
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Настройка Win+X меню" }
        Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s1_3 ) { $L.s1_3 } else { "по умолчанию" }
        Write-Host "| $text " -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        $DefaultProfile = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile

        [array] $DefaultLinks = @(Get-ChildItem -LiteralPath "$DefaultProfile\AppData\Local\Microsoft\Windows\WinX" -Force -Recurse -Depth 1 -ErrorAction SilentlyContinue
                                  ).Where({ $_.Name -match ".+[.](lnk|ini)$" -or $_.PSIsContainer })

        if ( @($DefaultLinks.Where({ $_.PSIsContainer })).Count -eq 3 -and $DefaultLinks.Count -gt 10 )
        {
            foreach ( $Acc in $Accs )
            {
                $NameUser = $Acc.Name
                $Profile  = $Acc.Profile

                Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
                Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

                $UserWinxFolder = "$Profile\AppData\Local\Microsoft\Windows\WinX"

                Get-ChildItem -Directory -Path $UserWinxFolder -Force -Recurse -ErrorAction SilentlyContinue |
                    ForEach-Object {
                        try { Remove-Item -Path "$($_.FullName)" -Force -Recurse -ErrorAction SilentlyContinue } catch {}
                    }

                foreach ( $Folder in $DefaultLinks.Where({ $_.PSIsContainer }))
                {
                    try
                    { 
                        $LnkCreated++

                        # Copy-Item -LiteralPath "$($Folder.FullName)" -Destination $UserWinxFolder -Force -Recurse -ErrorAction SilentlyContinue
                        # После других методов копирования дефолтных ярлыков Win+X меню (Copy-Item, [System.IO.File]::Copy(), Cmd Copy, XCopy.exe)
                        # не для всех файлов воспринимает подхват отображаемого имени из языковых параметров ini файла. После robocopy всё нормально.
                        robocopy.exe "$($Folder.FullName)" "$UserWinxFolder\$Folder" /E /COPY:DATSOU /DCOPY:DAT /XJ /R:2 /W:2 > $null

                        Write-Host "   ► " -ForegroundColor DarkMagenta -NoNewline
                        Write-Host "$UserWinxFolder\" -ForegroundColor DarkGray -NoNewline
                        Write-Host $Folder.Name -ForegroundColor White
                    }
                    catch {}
                }
            }
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Настройка Win+X меню" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        foreach ( $Acc in $Accs )
        {
            $NameUser = $Acc.Name
            $Profile  = $Acc.Profile
            $RegRoot  = "HKEY_USERS\$($Acc.SID)"

            [int] $CmdLnk = 0   # 0 = CMD ярлыки отключены в Win+X меню
            try { $CmdLnk = [Microsoft.Win32.Registry]::GetValue("$RegRoot\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",'DontUsePowerShellOnWinX',0) } catch {}

            Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
            Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray
            
            $UserWinxFolder = "$Profile\AppData\Local\Microsoft\Windows\WinX"

            [array] $UserLinks = @(Get-ChildItem -LiteralPath $UserWinxFolder -Recurse -Depth 1 -ErrorAction SilentlyContinue
                                    ).Where({ $_.Name -like "*.lnk" -or $_.PSIsContainer })

            [int] $N = 0

            # Удаление всех ярлыков из групп согласно пресету перед созданием новых
            if ( $GroupsRemove.Count )
            {
                foreach ( $Folder in $UserLinks.Where({ $_.PSIsContainer }))
                {
                    if ( $GroupsRemove -like $Folder.Name -and $UserLinks.Where({ -not $_.PSIsContainer -and $_.Directory.Name -eq $Folder.Name }).Count )
                    {
                        $N++
                        if ( $N -eq 1 ) { Write-Host }

                        try
                        {
                            Remove-Item -Path "$($Folder.FullName)\*" -Recurse -ErrorAction SilentlyContinue

                            Write-Host "   ► rem lnk: " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "$UserWinxFolder\" -ForegroundColor DarkGray -NoNewline
                            Write-Host $Folder.Name -ForegroundColor White -NoNewline
                            Write-Host "\*.lnk" -ForegroundColor DarkGray
                        }
                        catch {}
                    }
                }
                
                $UserLinks = $UserLinks.Where({ -not ( $GroupsRemove -like $_.Directory.Name )})
            }

            # Удаление отдельных ярлыков согласно пресету перед созданием новых
            if ( $LnkRemove.Count )
            {
                foreach ( $LnkName in $LnkRemove )
                {
                    if ( $File = $UserLinks.Where({ $_.Name -eq $LnkName -and -not ( $_.PSIsContainer -or $GroupsRemove -like $_.Directory.Name ) }))
                    {
                        $N++
                        if ( $N -eq 1 ) { Write-Host }

                        try
                        { 
                            Remove-Item -Path "$($File.FullName)" -Force -ErrorAction SilentlyContinue

                            Write-Host "   ► rem lnk: " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "$($File.Directory.FullName)\"  -ForegroundColor DarkGray -NoNewline
                            Write-Host $File.Name -ForegroundColor White
                        }
                        catch {}
                    }
                }

                $UserLinks = $UserLinks.Where({ $_.PSIsContainer -or ( -not $_.PSIsContainer -and -not ( $LnkRemove -like $_.Name ))})
            }

            # Ранее добавленные ярлыки
            $AddedUserLinks = $UserLinks.Where({ $_.Name -match '^[^\s_]+[+]0*[1-9][0-9]*\s-\s.+[.]lnk$' })
            # Добавление любых ярлыков из любых других доп. групп
            $AddedUserLinks += $UserLinks.Where({
                -not $_.PSIsContainer -and -not ( 'Group1','Group2','Group3' -like $_.Directory.Name ) -and -not ( $AddedUserLinks.FullName -like $_.FullName )
            })

            if ( $AddedUserLinks.Count )
            {
                # Исключение ранее добавленных из массива
                $UserLinks = $UserLinks.Where({ $_.PSIsContainer -or -not ( $AddedUserLinks.FullName -like $_.FullName )})

                # Удаление ранее добавленных ярлыков
                foreach ( $AddedUserLink in $AddedUserLinks )
                {
                    $N++
                    if ( $N -eq 1 ) { Write-Host }
                    
                    try
                    { 
                        Remove-Item -Path "$($AddedUserLink.FullName)" -Force -ErrorAction SilentlyContinue

                        Write-Host "   ► rem lnk: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$($AddedUserLink.Directory.FullName)\"  -ForegroundColor DarkGray -NoNewline
                        Write-Host $AddedUserLink.Name -ForegroundColor White
                    }
                    catch {}
                }
            }

            [System.Collections.Generic.List[PSObject]] $Links = @()
            [int] $N = 0
            [int] $PrefN = 0
            [array] $ini = @()
            [string] $Res = ''

            foreach ( $Group in ( $AddShortcuts.Group | Sort-Object -Unique -Descending ))
            {
                $Links = @()
                $N = 0
                $PrefN = 0

                $ini = @()
                try { $ini = Get-Content -LiteralPath "$UserWinxFolder\$Group\desktop.ini" -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}

                $UserLinks.Where({ -not $_.PSIsContainer -and $_.Directory.Name -eq $Group }) | ForEach-Object {

                    if ( $_.Name -match '^(?<Pref>[^\s_]+)([+](?<PrefN>0*[1-9][0-9]*))?\s-\s(?<Name>.+)[.]lnk$' )
                    {
                        $Pref = $Matches.Pref 
                        $Name = $Matches.Name
                        $FullName = $_.Name
                        $Res = ''

                        if ( $Matches.PrefN ) { $PrefN = $Matches.PrefN } else { $PrefN = 0 }

                        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 ) # Если ниже Windows 11, в ней другие ярлыки
                        {
                            if ( $CmdLnk )
                            {
                                if ( $Group -eq 'Group3' -and $Pref -match '^0(1|2)a$' ) { Return } # пропуск добавления PS lnks
                            }
                            else
                            {
                                if ( $Group -eq 'Group3' -and $Pref -match '^0(1|2)$' ) { Return }  # пропуск добавления CMD lnks
                            }
                        }

                        if ( -not $PrefN )
                        {
                            if ( $ini.Where({ $_ -match "^$([regex]::Escape($($FullName)))=(?<Res>.+)" }) )
                            {
                                if ( $Res = Manage-Shortcuts -GetLocalizedName $Matches.Res ) { $Name = $Res }
                            }
                        }

                        $Links.Insert( $N, [PSCustomObject]@{
                            Group    = $Group
                            Pref     = $Pref
                            PrefN    = $PrefN
                            Name     = $Name
                            FullName = $FullName
                        })

                        $N++
                    }
                }

                foreach ( $AddLnk in ( $AddShortcuts.Where({ $_.Group -eq $Group }) | Sort-Object -Property N ))
                {
                    $N = $AddLnk.N - 1

                    if ( $N )
                    {
                        if ( $AddLnk.N -gt $Links.Count )
                        {
                            $N     = $Links.Count
                            $Lnk   = $Links[-1]
                            $PrefN = $Lnk.PrefN + 1
                        }
                        else
                        {
                            $Lnk = $Links[$N - 1]

                            if ( $Lnk.PrefN )
                            {
                                if ( $Lnk.Pref -eq $Links[$N].Pref -and $Links[$N].PrefN ) { $PrefN = $Links[$N].PrefN } else { $PrefN = $Lnk.PrefN + 1 }
                            }
                            else { $PrefN = 1 }
                        }
                    }
                    else
                    {
                        $Lnk   = $Links[0]
                        $PrefN = 1
                    }
        
                    if ( $N -eq 0 )
                    {
                        if ( 'Group3' -eq $Group ) { $Pref = '00' } else { $Pref = 0 }
                    }
                    else { $Pref = $Lnk.Pref }

                    $Links.Insert( $N, [PSCustomObject]@{
                        Group = $Group
                        
                        Pref  = $Pref
                        PrefN = $PrefN
                        Name  = $AddLnk.Name
                        
                        FullName    = ('{0}+{1:00} - {2}.lnk' -f $Pref, $PrefN, $AddLnk.Name)
                        targetPath  = $AddLnk.targetPath
                        arguments   = $AddLnk.arguments
                        workingDir  = $AddLnk.workingDir
                        windowStyle = $AddLnk.windowStyle
                        elevate     = $AddLnk.elevate
                    })
                }

                Write-Host

                [int] $Lenght = 0
                foreach ( $Name in $Links.Name ) { if ( $Name.Length -gt $Lenght ) { $Lenght = $Name.Length }}

                [int] $Lenght2 = 0
                foreach ( $Name in $Links.FullName ) { if ( $Name.Length -gt $Lenght2 ) { $Lenght2 = $Name.Length }}

                [psobject] $Err = $null
                [hashtable] $CreateLnk = @{}
                $N = $Links.Count + 1

                foreach ( $Link in ( $Links | Sort-Object -Property Group, Pref, PrefN -Descending ))
                {
                    $N--

                    Write-Host "   $Group | $("{0,2}" -f $N). " -ForegroundColor DarkGray -NoNewline

                    if ( $Link.targetPath )
                    {
                        $CreateLnk = @{
                            lnkPath     = '{0}\{1}\{2}' -f $UserWinxFolder, $Link.Group, $Link.FullName
                            targetPath  = $Link.targetPath

                            arguments   = $Link.arguments
                            iconPath    = $Link.iconPath
                            workingDir  = $Link.workingDir
                            description = $Link.Name
                            windowStyle = $Link.windowStyle
                            elevate     = $Link.elevate
                            WinxHash    = $true
                        }

                        $Err = $null
                        $Err = Manage-Shortcuts -CreateLnk $CreateLnk

                        if ( $Err )
                        {
                            Write-Host "$("{0,-$Lenght}" -f $Link.Name) " -ForegroundColor Red -NoNewline
                            Write-Host "| ($Err) " -ForegroundColor Red -NoNewline

                            $NeedFix = $true
                        }
                        else
                        {
                            Write-Host "$("{0,-$Lenght}" -f $Link.Name) " -ForegroundColor Green -NoNewline
                            
                            $LnkCreated++
                        }
                    }
                    else
                    {
                        Write-Host "$("{0,-$Lenght}" -f $Link.Name) " -ForegroundColor DarkGray -NoNewline
                    }

                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$("{0,-$Lenght2}" -f $Link.FullName) " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($Link.targetPath)" -ForegroundColor DarkGray

                    $LnkCount++
                }
            }
        }

        if ( -not $LnkCount )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Ярлыки не настроены в пресете" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    if ( $LnkCreated )
    {
        ReStart-Explorer
    }

    $text = if ( $L.s3 ) { $L.s3 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green
}
