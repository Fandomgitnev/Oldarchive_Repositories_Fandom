﻿
<#
.SYNOPSIS
 Настройка или выполнение обслуживания системы отдельными действиями,
 или запуск стандартного обслуживания системы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Windows_Maintenance.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Test-Internet

.EXAMPLE
    Set-Windows-Maintenance -Options RunNgen,RunTimeSync -Act Set

    Описание
    --------
    Выполнить генерацию образов .NET и синхронизацию времени.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  30-04-2019
 ===============================================

#>
Function Set-Windows-Maintenance {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'MaintenanceDisable', 'WakeUpMaintDisable', 'RunNgen', 'RunClearWinSxS',
                      'RunDiskClean', 'RunTimeSync', 'RunStandartMaint', 'StopStandartMaint' )]
        [string[]] $Options = 'WakeUpMaintDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Maintenance', 'WakeUpForMaint', 'PresetTimeServers', 'PresetResetBase' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $GetPause
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    if ( $CheckState )
    {
        if ( 'Maintenance' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            try { [psobject] $Maintenance = [Microsoft.Win32.Registry]::GetValue($Key,'MaintenanceDisabled',$null)
            } catch { [psobject] $Maintenance = $null }

            if ( 1 -eq $Maintenance ) {  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Запрещено" }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Разрешено" }) } # Дефолт
        }
        elseif ( 'WakeUpForMaint' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            try { [psobject] $WakeUpForMaint = [Microsoft.Win32.Registry]::GetValue($Key,'WakeUp',$null)
            } catch { [psobject] $WakeUpForMaint = $null }

            if ( 0 -eq $WakeUpForMaint ) {  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Запрещено" }) }
            else                         { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Разрешено" }) } # Дефолт
        }
        elseif ( 'PresetTimeServers' -eq $CheckState )
        {
            [string[]] $PresetServers = $null

            foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Time-NTP-Servers\s*=\s*1' ))
            {
                if ( $Line -match '^\s*Time-NTP-Servers\s*=\s*1\s*=\s*(?<Servers>[^\r\n=]+)=' )
                {
                    [string[]] $PresetServers += ($Matches.Servers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" })
                }
            }

            if ( $PresetServers.Count ) { "#Magenta#$($PresetServers.Count) #DarkGray#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "шт" }) }
            else                        { "#Yellow#{0}#" -f $(if ( $L.s3_1 ) { $L.s3_1 } else { "Нет" }) }
        }
        elseif ( 'PresetResetBase' -eq $CheckState )
        {
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Use-Dism-ResetBase\s*=\s*1\s*=' },'First',1) )
            {
                [bool] $UseResetBase = $true
            }
            else { [bool] $UseResetBase = $false }

            if ( $UseResetBase ) { "#Blue#~80 {0} #DarkGray#[ #Magenta#{1} #DarkGray#]#" -f $(if ( $L.s3_2 ) { $L.s3_2, $L.s3_3 } else { "мин", "/ResetBase" }) }
            else {                 "#Blue#~40 {0} #DarkGray#[ {1} ]#"                    -f $(if ( $L.s3_2 ) { $L.s3_2, $L.s3_4 } else { "мин", "Без /ResetBase" }) }
        }

        Return
    }

    if (( $Options -like 'MaintenanceDisable' ) -or ( $Options -like 'WakeUpMaintDisable' ))
    {
        $text = if ( $L.s4 ) { $L.s4 } else { "Настройка Обслуживания Windows" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Options -like 'MaintenanceDisable' )
        {
            if ( $Act -ne 'Default' )
            {
                $text = if ( $L.s5 ) { $L.s5 } else { "Запрещение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Обслуживания" }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'MaintenanceDisabled' -Type DWord 1

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'MaintenanceDisabled' -Type DWord 1
                }
            }
            else
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Включение" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s6_1 ) { $L.s6_1 } else { "Разрешения Обслуживания" }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'
                }
            }
        }

        if ( $Options -like 'WakeUpMaintDisable' )
        {
            if ( $Act -ne 'Default' )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { "Запрещение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s7_1 ) { $L.s7_1 } else { "Пробуждения для Обслуживания" }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 0

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 0
                }
            }
            else
            {
                $text = if ( $L.s8 ) { $L.s8 } else { "Включение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Разрешения Пробуждения для Обслуживания" }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 1

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 1
                }
            }
        }
    }

    if (( $Options -match '^Run|^Stop' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s9 ) { $L.s9 } else { "Выполнение обслуживания Windows" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    if (( $Options -like 'RunNgen' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s10 ) { $L.s10 } else { "Выполнение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s10_1 ) { $L.s10_1 } else { "проверки и/или генерации образов .NET Framework" }
        Write-Host "$text " -ForegroundColor White -NoNewline
        Write-Host "| " -ForegroundColor DarkGray -NoNewline
        Write-Host "x86`n" -ForegroundColor Yellow

        [string] $NetPath = "$env:SystemDrive\Windows\Microsoft.NET\Framework"
        [string] $NGen40  = (Get-ChildItem -File -LiteralPath $NetPath -Recurse -Depth 1).FullName.Where({ $_ -like '*\v4.0*\ngen.exe' },'First',1)

        $text = if ( $L.s11 ) { $L.s11 } else { "Команда" }
        Write-Host "   $text`: $NGen40 ExecuteQueuedItems`n" -ForegroundColor DarkGray

        & $NGen40 ExecuteQueuedItems

        if ( $is64 )
        {
            $text = if ( $L.s10 ) { $L.s10 } else { "Выполнение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s10_1 ) { $L.s10_1 } else { "проверки и/или генерации образов .NET Framework" }
            Write-Host "$text " -ForegroundColor White -NoNewline
            Write-Host "| " -ForegroundColor DarkGray -NoNewline
            Write-Host "x64`n" -ForegroundColor Green

            [string] $NetPath = "$env:SystemDrive\Windows\Microsoft.NET\Framework64"
            [string] $NGen40  = (Get-ChildItem -File -LiteralPath $NetPath -Recurse -Depth 1).FullName.Where({ $_ -like '*\v4.0*\ngen.exe' },'First',1)

            $text = if ( $L.s11 ) { $L.s11 } else { "Команда" }
            Write-Host "   $text`: $NGen40 ExecuteQueuedItems`n" -ForegroundColor DarkGray

            & $NGen40 ExecuteQueuedItems
        }
    }

    if (( $Options -like 'RunClearWinSxS' ) -and ( $Act -eq 'Set' ))
    {
        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Use-Dism-ResetBase\s*=\s*1\s*=' },'First',1) )
        {
            [bool] $UseResetBase = $true
        }
        else { [bool] $UseResetBase = $false }

        $text = if ( $L.s12 ) { $L.s12 } else { "Выполнение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Очистки и сжатия папки WinSxS" }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s12_2 ) { $L.s12_2 } else { "Команда" }

        if ( $UseResetBase )
        {
            Write-Host "   $text`: Dism /Online /Cleanup-Image /StartComponentCleanup /ResetBase" -ForegroundColor DarkGray

            & Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase
        }
        else
        {
            Write-Host "   $text`: Dism /Online /Cleanup-Image /StartComponentCleanup" -ForegroundColor DarkGray

            & Dism.exe /Online /Cleanup-Image /StartComponentCleanup
        }

        $text = if ( $L.s13 ) { $L.s13 } else { "При завершении на 20.0% - очистка WinSxS не требовалась" }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        $text = if ( $L.s14 ) { $L.s14 } else { "Бывает 'Ошибка: 2' - это небольшой недочет Dism.exe или makecab.exe" }
        Write-Host "   $text" -ForegroundColor DarkGray

        $text = if ( $L.s15 ) { $L.s15 } else { "Не находят файл $env:SystemDrive\Windows\Logs\CBS\CbsPersist_***.log после его архивации и удаления утилитой makecab.exe" }
        Write-Host "   $text" -ForegroundColor DarkGray
    }

    if (( $Options -like 'RunDiskClean' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s16 ) { $L.s16 } else { "Выполнение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { "Очистки системного диска" }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s17 ) { $L.s17 } else { "Оценка файлов для очистки происходит для всех пунктов, но будет пропуск для" }
        Write-Host "   $text`:" -ForegroundColor DarkGray

         $text = if ( $L.s18 ) { $L.s18 } else { "Папка 'Загрузки', Корзина, Обновления, Кэш иконок, История файлов пользователя, BranchCache" }
        Write-Host "   $text`n" -ForegroundColor DarkGray

        [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'

        try { [string[]] $AllElements = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys').GetSubKeyNames() }
        catch { [string[]] $AllElements = $null }

        [string[]] $ElementsOff = 'DownloadsFolder', 'Recycle Bin', 'Update Cleanup', 'Service Pack Cleanup',
                                  'Thumbnail Cache', 'User file versions', 'BranchCache'

        # Устанавливаем настройки для cleanmgr.exe
        foreach ( $Element in $AllElements )
        {
            [string] $Path = "HKLM:\$SubKey\$Element"

            if ( $ElementsOff -like $Element )
            {
                Set-Reg New-ItemProperty -Path $Path -Name 'StateFlags7777' -Type DWord 0
            }
            else
            {
                Set-Reg New-ItemProperty -Path $Path -Name 'StateFlags7777' -Type DWord 2
            }
        }

        $text = if ( $L.s19 ) { $L.s19 } else { "Запуск" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s19_1 ) { $L.s19_1 } else { "очистки" }
        Write-Host "$text" -ForegroundColor White

        $text = if ( $L.s20 ) { $L.s20 } else { "Команда: Сleanmgr.exe /sagerun:7777 | С заданными параметрами" }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        $text = if ( $L.s21 ) { $L.s21 } else { "Ожидание" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s21_1 ) { $L.s21_1 } else { "завершения процесса Сleanmgr.exe ..." }
        Write-Host "$text" -ForegroundColor White

        try
        {
            Start-Process -FilePath $env:windir\system32\cleanmgr.exe -ArgumentList "/sagerun:7777"
        }
        catch {}

        [string] $ShowHideWindowAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class ShowHideWindow
    {
        [DllImport( "user32.dll", SetLastError = true )]
        public static extern bool ShowWindowAsync(
            IntPtr hWnd,
            int nCmdShow
        );
    }
}
'@
        if ( -not ( 'WinAPI.ShowHideWindow' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $ShowHideWindowAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        # SW_HIDE           = 0 | Скрыть окно и активизировать другое окно
        # SW_SHOWNORMAL     = 1 | Активизировать и отобразить окно. Если окно свернуто или развернуто.
        # SW_SHOWMINIMIZED  = 2 | Отобразить окно в свернутом виде
        # SW_SHOWNOACTIVATE = 4 | Отобразить окно в соответствии с последними значениями позиции и размера. Активное окно остается активным
        # SW_SHOW           = 5 | Активизировать окно
        # SW_MINIMIZE       = 6 | Свернуть окно и активизировать следующее окно в Z-порядке (следующее под свернутым окном)
        # SW_SHOWNA         = 8 | Отобразить окно в текущем состоянии. Активное окно остается активным
        # SW_RESTORE        = 9 | Активизировать и отобразить окно. Если окно свернуто или развернуто, Windows восстанавливает его исходный размер и положение
        # SW_SHOWDEFAULT   = 10 | (1+9) Активизировать и отобразить окно на переднем плане, если было свернуто или скрыто.

        # Периодическое изменение состояний окна cleanmgr для помощи завершения процессу cleanmgr.
        # Так как для завершения процесса cleanmgr, почти всегда, после выполнения им всех действий, нужно подвигать курсор над его окном,
        # иначе cleanmgr ждет этих действий бесконечно, как будто что то еще выполняет.
        # С этими манипуляциями не важно где курсор, и какое окно активно в данный момент.

        [int] $TryCount = 0

        # Ожидание завершения процесса 15 секунд максимум, затем переход далее
        do
        {
            Start-Sleep -Seconds 1

            $TryCount++

        } until ( -not ( Get-Process -Name cleanmgr -ErrorAction SilentlyContinue ) -or ( $TryCount -ge 15 ))


        [int] $TryCount = 0

        # Если процесс не завершён, помогаем ему, меняя состояние окна, пока он не завершиться, раз в 2 секунды.
        While ( $hwnd = Get-Process -Name cleanmgr -ErrorAction SilentlyContinue )
        {
            if ( 0 -eq $TryCount )
            {
                $text = if ( $L.s22 ) { $L.s22 } else { "Изменение" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s22_1 ) { $L.s22_1 } else { "состояния окна процесса Сleanmgr.exe, для помощи ему завершиться после выполнения" }
                Write-Host "$text" -ForegroundColor White

                $text = if ( $L.s23 ) { $L.s23 } else { "Его окно будет периодически сворачиваться, пока не завершится процесс ..." }
                Write-Host "   $text`n" -ForegroundColor White
            }
            else
            {
                $text = if ( $L.s24 ) { $L.s24 } else { "Процесс Сleanmgr.exe еще не завершился, меняем состояние окна" }
                Write-Host "     $text | $TryCount" -ForegroundColor DarkGray
            }

            try
            {
                [WinAPI.ShowHideWindow]::ShowWindowAsync($hwnd.MainWindowHandle, 6) *> $null   # Сворачиваем окно
                [WinAPI.ShowHideWindow]::ShowWindowAsync($hwnd.MainWindowHandle, 10) *> $null  # Восстанавливаем
            }
            catch {}

            Start-Sleep -Milliseconds 3000 ; $TryCount++
        }

        Write-Host

        # Удаляем установленные настройки для cleanmgr.exe
        foreach ( $Element in $AllElements )
        {
            [string] $Path = "HKLM:\$SubKey\$Element"

            Set-Reg Remove-ItemProperty -Path $Path -Name 'StateFlags7777'
        }
    }

    if (( $Options -like 'RunTimeSync' ) -and ( $Act -eq 'Set' ))
    {
        if ( Test-Internet -Bool )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time\Parameters'

            # Получаем список серверов настроенный в системе.
            try { [string[]] $SystemServers = [Microsoft.Win32.Registry]::GetValue($Key,'NtpServer',$null) }
            catch { [string[]] $SystemServers = $null }

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'
                
            try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues') }
            catch { [psobject] $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $Name in ( $OpenSubKey.GetValueNames() ))
                {
                    if ( $Name )
                    {
                        $SystemServers += $OpenSubKey.GetValue($Name,$null)
                    }
                }
                    
                $OpenSubkey.Close()
            }

            # Переводим его в массив, убирая пустые строки, и добавляя ко всем доп. параметр 0х9, после удаления любых доп. параметров.
            [string[]] $SystemServers = ($SystemServers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" }) | Select-Object -Unique

            [string[]] $PresetServers = $null

            # Получаем все сервера из пресета
            [string[]] $PresetServers = @()

            foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Time-NTP-Servers\s*=\s*1' ))
            {
                if ( $Line -match '^\s*Time-NTP-Servers\s*=\s*1\s*=\s*(?<Servers>[^\r\n=]+)=' )
                {
                    $PresetServers += ($Matches.Servers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" }) | Select-Object -Unique
                }
            }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Replace-Time-NTP-Servers\s*=\s*1\s*=' },'First',1) ) { [bool] $Replace = $true }
            else { [bool] $Replace = $false }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Sync-From-All-Server\s*=\s*1\s*=' },'First',1) ) { [bool] $SyncAll = $true }
            else { [bool] $SyncAll = $false }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Remove-Default-Servers\s*=\s*1\s*=' },'First',1) ) { [bool] $RemoveDefault = $true }
            else { [bool] $RemoveDefault = $false }


            if ( $Replace )
            {
                # Если есть сервера в пресете, то заменяем на них вместо системных.
                if ( $PresetServers.Count ) { $SystemServers = $PresetServers }
            }
            else
            {
                # Добавляем сервера из пресета к списку серверов из системы, но только которых еще нет в системе.
                $SystemServers += $PresetServers.Where({ -not ( $SystemServers -like $_ ) })
            }

            # Добавление дефолтных серверов к любым указаным или существующим наборам серверов, дубликаты удаляются.
            $SystemServers = ( $SystemServers += 'time.windows.com,0x9', 'time.nist.gov,0x9' ) | Select-Object -Unique

            # Если указано удалить дефолтные сервера MS
            if ( $RemoveDefault )
            {
                # Убираем дефолтные сервера.
                $SystemServers = @($SystemServers.Where({ $_ -notmatch '^(time[.]windows[.]com|time[.]nist[.]gov),0x9$' }))
            }
            else { $RemoveDefault = $false }

            # если нет ни каких в итоге, то вернуть дефолтные.
            if ( -not $SystemServers.Count ) { $SystemServers = 'time.windows.com,0x9', 'time.nist.gov,0x9' }

            $text = if ( $L.s25 ) { $L.s25 } else { "Выполнение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s25_1 ) { $L.s25_1 } else { "Синхронизации времени" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s25_2 ) { $L.s25_2 } else { "Интернет" }
            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "OnLine " -ForegroundColor Green -NoNewline

            $text = if ( $L.s25_3 ) { $L.s25_3 } else { "Результат может быть с задержкой" }
            Write-Host "| $text`n" -ForegroundColor DarkGray

            $text = if ( $L.s26 ) { $L.s26 } else { "Команда" }
            Write-Host "   $text`: w32tm.exe /ReSync /Force" -ForegroundColor DarkGray

            $text = if ( $L.s27 ) { $L.s27 } else { "Итоговый Список и порядок серверов" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            if ( $RemoveDefault )
            {
                $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Удалены" }
                Write-Host "($text`: time.windows.com, time.nist.gov)`n" -ForegroundColor DarkGray
            }
            else { Write-Host "`n" }

            [int] $CountServers = 0
            foreach ( $Server in $SystemServers )
            {
                $CountServers++

                Write-Host "$($CountServers.ToString().PadLeft(9,' ')) | " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Server -Replace ('(,[^\r\n]*)',''))" -ForegroundColor White
            }

            # Удаление списка серверов, чтобы обеспечить возможность замены на новые параметры из пресета, или снова вернуть старые.
            try
            {
                [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'

                foreach ( $Name in ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() ))
                {
                    if ( $Name )
                    {
                        [string] $Path = "HKLM:\$SubKey"

                        Set-Reg -NoCheck Remove-ItemProperty -Path $Path -Name $Name
                    }
                }
            }
            catch {}


            if ( $is64 )
            {
                try
                {
                    [string] $SubKey = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers'

                    foreach ( $Name in ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() ))
                    {
                        if ( $Name )
                        {
                            [string] $Path = "HKLM:\$SubKey"

                            Set-Reg -NoCheck Remove-ItemProperty -Path $Path -Name $Name
                        }
                    }
                }
                catch {}
            }

            Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers' -Name '' -Type String 0

            if ( $is64 )
            {
                Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers' -Name '' -Type String 0
            }

            [int] $CountServers = 0

            foreach ( $Server in ( $SystemServers -Replace '(,[^\r\n]*)','' ))
            {
                [string] $Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'
                [string] $Name  = $CountServers
                [string] $Value = $Server

                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name $Name -Type String $Value

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers'

                    Set-Reg -NoCheck New-ItemProperty -Path $Path -Name $Name -Type String $Value
                }

                $CountServers++
            }

            Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters' -Name 'Type' -Type String 'NTP'

            Set-Service -Name W32Time -StartupType Manual -Status Running -ErrorAction SilentlyContinue

            [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('cp866')

            try
            {
                if ( $SyncAll )
                {
                    $text = if ( $L.s28 ) { $L.s28 } else { "Синхронизация" }
                    Write-Host "`n   $text " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s28_1 ) { $L.s28_1 } else { "со всеми" }
                    Write-Host "$text " -ForegroundColor White -NoNewline

                    $text = if ( $L.s28_2 ) { $L.s28_2 } else { "серверами в списке" }
                    Write-Host "$text`n" -ForegroundColor DarkGray

                    & w32tm.exe /Config /SyncFromFlags:Manual /ManualPeerList:"$($SystemServers -join ' ')" /Update *>$null
                }
                else
                {
                    [string] $FirstServer = ( $SystemServers | Select-Object -First 1 ) -Replace '(,[^\r\n]*)',''

                    $text = if ( $L.s29 ) { $L.s29 } else { "Синхронизация" }
                    Write-Host "`n   $text " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s29_1 ) { $L.s29_1 } else { "с первым" }
                    Write-Host "$text " -ForegroundColor White -NoNewline

                    $text = if ( $L.s29_2 ) { $L.s29_2 } else { "сервером в списке" }
                    Write-Host "$text | " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$FirstServer `n" -ForegroundColor Green

                    & w32tm.exe /Config /SyncFromFlags:Manual /ManualPeerList:"$($SystemServers | Select-Object -First 1)" /Update *>$null
                }

                Restart-Service -Name W32Time -Force -ErrorAction SilentlyContinue

                & w32tm.exe /ReSync /Force *>$null
                & w32tm.exe /ReSync /NoWait

                $text = if ( $L.s30 ) { $L.s30 } else { "Результат Синхронизации от сервера" }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$((& w32tm.exe /Query /Source) -Replace '(,[^\r\n]*)','') " -ForegroundColor White -NoNewline

                $text = if ( $L.s30_1 ) { $L.s30_1 } else { "Если несколько серверов, то покажет любой из удачных" }
                Write-Host "| $text`n" -ForegroundColor DarkGray
            }
            catch {}

            [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('utf-8')
        }
        else
        {
            $text = if ( $L.s31 ) { $L.s31 } else { "Пропуск" }
            Write-Host "`n   $text " -ForegroundColor Yellow -NoNewline

            $text = if ( $L.s31_1 ) { $L.s31_1 } else { "Синхронизации времени" }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s31_2 ) { $L.s31_2 } else { "Интернет" }
            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "OffLine`n" -ForegroundColor Red
        }
    }

    if (( $Options -like 'RunStandartMaint' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s32 ) { $L.s32 } else { "Подготовка" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s32_1 ) { $L.s32_1 } else { "к Стандартному обслуживанию Windows" }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s33 ) { $L.s33 } else { "Включение" }
        Write-Host "   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s33_1 ) { $L.s33_1 } else { "важных параметров для обслуживания" }
        Write-Host "$text`n" -ForegroundColor White

        [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

        Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'

        if ( $is64 )
        {
            [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'
        }

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Diagnosis\Scheduled'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\ApplicationData\CleanupTemporaryState'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Chkdsk\ProactiveScan'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Chkdsk\SyspartRepair'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Plug and Play\Device Install Group Policy'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Servicing\StartComponentCleanup'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Time Synchronization\SynchronizeTime'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime'

        $text = if ( $L.s34 ) { $L.s34 } else { "Запуск в фоне" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Стандартного обслуживания Windows" }
        Write-Host "$text`n" -ForegroundColor White

        [string] $MSchedExe = "$env:SystemDrive\Windows\system32\MSchedExe.exe"

        $text = if ( $L.s35 ) { $L.s35 } else { "Команда" }
        Write-Host "   $text`: $MSchedExe Start`n" -ForegroundColor DarkGray

        try { [System.Diagnostics.Process]::Start($MSchedExe,'Start') > $null } catch {}

        $text = if ( $L.s35_1 ) { $L.s35_1 } else { "Выполнение в фоне может продлиться до 2 часов" }
        Write-Host "   $text" -ForegroundColor DarkGray

        Start-Sleep -Milliseconds 5000
    }

    if (( $Options -like 'StopStandartMaint' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s36 ) { $L.s36 } else { "Остановка" }
        Write-Host "`n   $text " -ForegroundColor Red -NoNewline

        $text = if ( $L.s36_1 ) { $L.s36_1 } else { "Стандартного обслуживания Windows" }
        Write-Host "$text`n" -ForegroundColor White

        [string] $MSchedExe = "$env:SystemDrive\Windows\system32\MSchedExe.exe"

        $text = if ( $L.s36_2 ) { $L.s36_2 } else { "Команда" }
        Write-Host "   $text`: $MSchedExe Stop`n" -ForegroundColor DarkGray

        try { [System.Diagnostics.Process]::Start($MSchedExe,'Stop') > $null } catch {}

        Start-Sleep -Milliseconds 2000
    }

    $text = if ( $L.s37 ) { $L.s37 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    if ( $GetPause )
    {
        Get-Pause
    }
}
