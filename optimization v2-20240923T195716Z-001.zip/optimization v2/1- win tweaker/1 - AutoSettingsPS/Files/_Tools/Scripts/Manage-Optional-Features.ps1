﻿
<#
.SYNOPSIS
 Функция для Включения/Отключения Дополнительных Компонентов (Windows Optional Features)
 Function to Enable/Disable Windows Optional Features

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Features_Capabilities

 Используется функция Get-Pause для установки паузы.
 Используется функция Write-HostColor, для вывода информации.
 Используется функции Get-ArchOS, Get-VersOS, Get-RevisionOS, Get-NameOS

 Получает из файла пресетов 'Presets.txt' список параметров для настройки и шаблоны исключений. 
 Настройка осуществляется через командлеты Enable-WindowsOptionalFeature и Disable-WindowsOptionalFeature
 Выводит текущее состояние указанных параметров


.EXAMPLE
    Manage-Optional-Features -SaveList

.EXAMPLE
    Manage-Optional-Features Check

.EXAMPLE
    Manage-Optional-Features Set


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  22-03-2021
 ===============================================

#>
Function Manage-Optional-Features {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'First', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]   # Default Не используется, будет выводить сообщение о пропуске.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'First'  )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Select' )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'SaveList' )]
        [switch] $SaveList
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NoTitle
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NoPause
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' )
    {
        $text = if ( $L.s9 ) { $L.s9 } else { "'Default' не предусмотрен" }
        Write-Host "`n   $NameThisFunction`: $text`n" -ForegroundColor DarkGray

        $noDefault = $true

        Return   # Выход из функции
    }

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    # Получить шаблоны имён для исключений
    [string[]] $GetExclusions = @()

    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Set-Feature-Exclusions\s*=\s*[*]\s*=.+' ))
    {
        if ( $Line -match '^\s*Set-Feature-Exclusions\s*=\s*[*]\s*=\s*(?<Excl>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|?``=#]+)==' )
        {
            $GetExclusions += @($Matches.Excl.Split(',').Trim('"''* ')).Where({$_})
        }
    }

    if ( $GetExclusions )
    {
        $ExclusionsMatch = ($GetExclusions.ForEach({[regex]::Escape($_)})) -join '|'
        $GetFeatures = Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue | Where-Object { $_.FeatureName -notmatch "^($ExclusionsMatch)" }
    }
    else
    {
        $ExclusionsMatch = $null
        $GetFeatures = Get-WindowsOptionalFeature -Online -ErrorAction SilentlyContinue
    }

    if ( $SaveList )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Сохранение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { "списка всех возможных Optional Features (Кроме исключений)" }
        Write-Host "$text " -ForegroundColor Gray

        if ( -not $SaveFileFeaturesGlobal ) { Write-Warning "$NameThisFunction`: The File to save not specified: `$SaveFileFeaturesGlobal" ; Return }
        
        $text = if ( $L.s1_2 ) { $L.s1_2 } else { "Файл" }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$SaveFileFeaturesGlobal" -ForegroundColor White

        $SaveExclusions = ''

        if ( $GetExclusions )
        {
            $SaveExclusions = $GetExclusions -join '; '

            $text = if ( $L.s2 ) { $L.s2 } else { "Шаблоны исключений" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$SaveExclusions`n" -ForegroundColor DarkCyan
        }

        $N = 0
        $Count  = $GetFeatures.Count
        $Format = @(1..$Count.ToString().Length).ForEach({'0'}) -join ''

        $FeaturesAll = $GetFeatures.FeatureName | ForEach-Object -Process {
            $N++
            Write-Host " | $(($N).ToString($Format)) : $Count | $_"
            Get-WindowsOptionalFeature -FeatureName $_ -Online -ErrorAction Continue
        }

        $Data = @()
        [int] $NameLenght = 0
        [int] $Lenght = 0
        foreach ( $F in $FeaturesAll )
        {
            $NameLenght = $F.FeatureName.Length
            if ( $Lenght -lt $NameLenght ) { $Lenght = $NameLenght }
        }

        foreach ( $F in $FeaturesAll )
        {
            $GetParent   = $F.CustomProperties.Where({$_.Name -eq 'Parent'}).Value
            $GetFullDesc = $F.CustomProperties.Where({$_.Name -eq 'Description'}).Value

            if ( $GetParent )
            {
                $FeatureNameParent = $FeaturesAll.Where({ $_.CustomProperties.Where({ $_.Name -eq 'UniqueName' }).Value -eq $GetParent }).FeatureName
                if ( $FeatureNameParent ) { $Parent = "Parent: $FeatureNameParent" }
            }
            else { $Parent = 'Parent: ----------' }

            if ( $F.DisplayName ) { $DisplayName = "DisplayName: $($F.DisplayName)" } else { $DisplayName = 'DisplayName: -----' }
            if ( $F.Description ) { $Desc = "Desc: $($F.Description)" } else { $Desc = 'Desc: -----' }
            if ( $GetFullDesc ) { $FullDesc = "FullDesc: $GetFullDesc" } else { $FullDesc = "FullDesc: -----" }
            if ( $F.State -eq 'Disabled' ) { $FeatureState = '-------' } else { $FeatureState = $F.State }

            $Data += "       Set-Optional-Feature = 0 = {0} == #Info: {1} | {2} | {3} | {4} | {5}" -f
                $F.FeatureName.ToString().PadRight($Lenght,' ').Substring(0,$Lenght),
                $FeatureState, $Parent, $DisplayName, $Desc, $FullDesc
        }

        if ( $Data )
        {
            # Все данные по Windows в начало экспортного списка
            try { "`n   Windows: $(Get-ArchOS) | $(Get-LangOS) | $(Get-VersOS).$(Get-RevisionOS) | $(([string] (Get-NameOS)).Replace('#DarkGray#','').Trim(' #'))`n`n   Windows Optional Features" |
                Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -ErrorAction Continue }
            catch { throw }

            if ( $SaveExclusions )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Шаблоны исключений" }
                try { "`n   $text`: $SaveExclusions`n" | Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -Append }
                catch { throw }
            }
            else { $Append = $false }

            try { $Data | Out-File -Width 1000 -FilePath $SaveFileFeaturesGlobal -Force -Encoding utf8 -Append }
            catch { throw }
        }
        else
        {
            Write-Warning "$NameThisFunction`: No data in Get-WindowsOptionalFeature -Online"
        }

        if ( -not $NoPause ) { Get-Pause }
        
        Return    # Выход
    }

    [int] $Number = 0
    [hashtable] $OptionalFeatures = @{}

    # Заполняем таблицу $OptionalFeatures. Для каждой строки подходящей под шаблон
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Set-Optional-Feature\s*=\s*[123]\s*=.+' ))
    {
        # Если строка совпадает с шаблоном, и не содержит все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match '^\s*Set-Optional-Feature\s*=\s*(?<Run>[123])\s*=\s*(?<Name>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|?*``=#]+)==' )
        {
            $Number++
            [string] $Name = $Matches.Name.Trim()
            [string] $Run  = $Matches.Run.Trim()

            $OptionalFeatures[$Number] = @{}

            if     ( $Run -eq 1 ) { $OptionalFeatures[$Number]['Run'] = 'Disable' }
            elseif ( $Run -eq 2 ) { $OptionalFeatures[$Number]['Run'] = 'Enable'  }
            else                  { $OptionalFeatures[$Number]['Run'] = 'Enable' ; $OptionalFeatures[$Number]['All'] = $true }

            if ( $(foreach ( $Key in $OptionalFeatures.Keys ) { $OptionalFeatures[$Key]['Name'] }) -like $Name )
            {
                $OptionalFeatures[$Number]['Skip'] = $true
                $OptionalFeatures[$Number]['Err']  = if ( $L.s3 ) { $L.s3 } else { 'Дубликат имени' }
                $OptionalFeatures[$Number]['dupl'] = $true
                $OptionalFeatures[$Number]['Stat'] = ''

                foreach ( $Key in $OptionalFeatures.Keys )
                {
                    if (( $Name -eq $OptionalFeatures[$Key]['Name'] ) -and ( $OptionalFeatures[$Key]['WrongName'] ))
                    {
                        $OptionalFeatures[$Number]['Err'] = if ( $L.s4 ) { $L.s4 } else { 'Нет совпадений (дубликат)' }
                        break
                    }
                }
            }
            else
            {
                $Feature = $GetFeatures.Where({ $_.FeatureName -like $Name },'First',1)

                if ( $Feature )
                {
                    $OptionalFeatures[$Number]['Skip'] = $false
                    $OptionalFeatures[$Number]['Stat'] = $Feature.State
                    $OptionalFeatures[$Number]['Err']  = ''
                }
                else
                {
                    $OptionalFeatures[$Number]['Skip'] = $true
                    $OptionalFeatures[$Number]['Stat'] = ''

                    if ( $ExclusionsMatch -and ( $Name -match "^($ExclusionsMatch)" ))
                    {
                        $OptionalFeatures[$Number]['Err']  = if ( $L.s5 ) { $L.s5 } else { "Подпадает под шаблон исключений" }
                        $OptionalFeatures[$Number]['Excl'] = $true
                    }
                    else
                    {
                        $OptionalFeatures[$Number]['Err']       = if ( $L.s6 ) { $L.s6 } else { 'Нет совпадений' }
                        $OptionalFeatures[$Number]['WrongName'] = $true
                    }
                }
            }
            
            $OptionalFeatures[$Number]['Name'] = $Name
        }
        elseif ( $Line -match '^\s*Set-Optional-Feature\s*=\s*(?<Run>[123])\s*=\s*(?<Name>.+)==' )
        {
            # Иначе если строка имеет запрещенные символы, пропускать
            $Number++
            [string] $Name = $Matches.Name.Trim()
            [string] $Run  = $Matches.Run.Trim()

            $OptionalFeatures[$Number] = @{}
            $OptionalFeatures[$Number]['Skip'] = $true
            $OptionalFeatures[$Number]['Stat'] = ''

            if ( $Run -eq 1 ) { $OptionalFeatures[$Number]['Run'] = 'Disable' }
            else              { $OptionalFeatures[$Number]['Run'] = 'Enable'  }

            if ( $(foreach ( $Key in $OptionalFeatures.Keys ) { $OptionalFeatures[$Key]['Name'] }) -like $Name )
            {
                $OptionalFeatures[$Number]['Err'] = if ( $L.s7 ) { $L.s7 } else { 'Запрещённые символы в строке пресета (дубликат)' }
            }
            else
            {
                $OptionalFeatures[$Number]['Err'] = if ( $L.s8 ) { $L.s8 } else { 'Запрещённые символы в строке пресета' }
            }
            
            $OptionalFeatures[$Number]['Name'] = $Name
        }
    }

    # Не выводить заголовок, если проверка параметров в пресете или предлагается выбор
    if ( -not $NoTitle -and -not $Select )
    {
        $text = if ( $L.s10 ) { $L.s10 } else { "Настройка" }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Windows Optional Features" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s10_2 ) { $L.s10_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    if ( -not $NoTitle ) { [int] $Indent = 4 } else { [int] $Indent = 7 }

    # Если указана необходимость выбрать нужные параметры.
    if ( $Select -and $OptionalFeatures.Count )
    {
        # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
          [char] $Escape          = 27
           [int] $StringsExcl     = 3              # Количество последних строк для затирания.
        [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
        [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

        Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline

        Write-Host "   Optional Features: " -ForegroundColor Blue -NoNewline
        
        $text = if ( $L.s11 ) { $L.s11 } else { 'Введите номера через пробел и/или диапазон через дефис' }
        
        Write-Host "$text"

        $text = if ( $L.s11_1 ) { $L.s11_1 } else { 'Номера' }

        # Ждем ввода пользователя.
        [string] $Choice = Read-Host -Prompt "   $text"

        [Uint16[]] $SelectedParams = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел и
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedParams, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            [array] $arr = @()

            # Добавление групп указанных через дефис
            foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

            $arr | ForEach-Object {
                
                try
                {
                    [Uint16] $ParamNumber = $_

                    if (( $ParamNumber -gt 0 ) -and ( $ParamNumber -le $OptionalFeatures.Count ) -and ( $SelectedParams -notcontains $ParamNumber ))
                    { [Uint16[]] $SelectedParams += $ParamNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedParams )
        {
            $text = if ( $L.s12 ) { $L.s12 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s13 ) { $L.s13 } else { 'Выбранные номера' }
        Write-HostColor "`n      $text`: #DarkGray#[ #White#$SelectedParams #DarkGray#]#`n"
    }

    # Выводим информацию по всем строкам.
    foreach ( $Number in $OptionalFeatures.Keys | Sort-Object )
    {
        if ( $Select -and ( -not ( $SelectedParams -like $Number ) )) { Continue }  # Пропуск не выбранных номеров, если был выбор

        $Run   = $OptionalFeatures[$Number]['Run']
        $Name  = $OptionalFeatures[$Number]['Name']
        $State = $OptionalFeatures[$Number]['Stat']
        $All   = $OptionalFeatures[$Number]['All']
        
        if ( $OptionalFeatures[$Number]['Skip'] )
        {
            $Status = 'х' ; $ColorName = 'Red' ; $Color = 'Red'

            if ( $OptionalFeatures[$Number]['Excl'] )
            {
                $ColorName = 'DarkGray' ; $Color = 'DarkCyan'
            }
            elseif ( $OptionalFeatures[$Number]['WrongName'] -or $OptionalFeatures[$Number]['dupl'] )
            {
                $ColorName = 'DarkGray' ; $Color = 'DarkGray' 
            }

            [string] $ResultShow = "#DarkGray#{0}. #Red#{1} #DarkGray#{2} | #$ColorName#{3} #DarkGray#| #$Color#{4}#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $Run.ToString().PadRight(7,' ').Substring(0,7),
                $Name,
                $OptionalFeatures[$Number]['Err']
        }
        else
        {
            $Status = '○' ; $Color = 'Yellow' ; $ColorName = 'White'

            if ( $State -eq 'Enabled' )
            {
                if ( $Run -eq 'Enable'  ) { $Status = '●' ; $Color = 'Green'  ; $ColorName = 'Green' ; $OptionalFeatures[$Number]['Skip'] = $true }
            }
            else
            {
                if ( $Run -eq 'Disable' ) { $Status = '●' ; $Color = 'Green'  ; $ColorName = 'Green' ; $OptionalFeatures[$Number]['Skip'] = $true }
            }

            if ( $All ) { $ShowAll = ' #DarkCyan#/All' } else { $ShowAll = '' }

            [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #DarkGray#{2} | #$ColorName#{3}$ShowAll" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $Run.ToString().PadRight(7,' ').Substring(0,7),
                $Name
        }

        if ( -not $NoTitle ) { Write-Host }

        Write-HostColor $ResultShow

        if ( $Act -eq 'Check' )
        {
            if (( -not $OptionalFeatures[$Number]['Skip'] ) -and ( -not $NoTitle )) { $NeedFix = $true }

            Continue
        }

        # Далее, если выполнение ...

        if ( $OptionalFeatures[$Number]['Skip'] )
        {
            if ( $OptionalFeatures[$Number]['Err'] )
            {
                $text = if ( $L.s14 ) { $L.s14 } else { 'Пропущено' }
                Write-Host "        $text" -ForegroundColor DarkYellow
            }
            else
            {
                if ( $State -eq 'Enabled' )
                {
                    $text = if ( $L.s15 ) { $L.s15 } else { 'Уже Включено' }
                    Write-Host "        $text" -ForegroundColor DarkGreen
                }
                else
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Уже Отключено' }
                    Write-Host "        $text" -ForegroundColor DarkGreen
                }
            }

            Continue
        }

        # Выполняем ..............
        
        # $ProgressPreference = 'SilentlyContinue'
        
        if ( $Run -eq 'Enable' )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Включение' }
            Write-Host "        >>>" -ForegroundColor DarkGray -NoNewline
            Write-Host " $text" -ForegroundColor Green

            try
            {
                if ( $All ) 
                {
                    Write-Host "        Enable-WindowsOptionalFeature -Online -All -FeatureName $Name -NoRestart" -ForegroundColor DarkGray
                    Enable-WindowsOptionalFeature -Online -All -FeatureName $Name -NoRestart -WarningAction SilentlyContinue -ErrorAction Continue > $null
                }
                else
                {
                    Write-Host "        Enable-WindowsOptionalFeature -Online -FeatureName $Name -NoRestart" -ForegroundColor DarkGray
                    Enable-WindowsOptionalFeature -Online      -FeatureName $Name -NoRestart -WarningAction SilentlyContinue -ErrorAction Continue > $null
                }

                # Исправление бага Панели Управления
                if (( $Name -eq 'SearchEngine-Client-Package' ) -and -not ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}",'',$null) ))
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}' -Name '' -Type String 'Indexing Options'
                }
            }
            catch
            {
                Write-Host "        Error: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                $NeedFix = $true
            }
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { 'Отключение' }
            Write-Host "        >>>" -ForegroundColor DarkGray -NoNewline
            Write-Host " $text" -ForegroundColor Magenta
            Write-Host "        Disable-WindowsOptionalFeature -Online -FeatureName $Name -NoRestart" -ForegroundColor DarkGray

            try { Disable-WindowsOptionalFeature -Online -FeatureName $Name -NoRestart -WarningAction SilentlyContinue -ErrorAction Continue > $null }
            catch
            {
                Write-Host "        Error: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                $NeedFix = $true
            }
            
            # Исправление бага Панели Управления
            if (( $Name -eq 'SearchEngine-Client-Package' ) -and ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}",'',$null) ))
            {
                Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}'
            }
        }

        $ProgressPreference = 'Continue'
    }

    if ( -not $OptionalFeatures.Count )
    {
        $text = if ( $L.s19 ) { $L.s19 } else { 'Не указаны Параметры в файле пресетов' }

        if ( $NoTitle )
        {
            Write-Host "         $text" -ForegroundColor DarkYellow
        }
        else
        {
            Write-Host "`n   $text`n" -ForegroundColor DarkYellow
        }
    }

    if ( $Act -eq 'Check' )
    {
        Return
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1) и не запрещена пауза тут
    if ( -not $MenuConfigsQuickSettings -and -not $NoPauses -and -not $NoPause )
    {
        Get-Pause
    }

    Return
}
