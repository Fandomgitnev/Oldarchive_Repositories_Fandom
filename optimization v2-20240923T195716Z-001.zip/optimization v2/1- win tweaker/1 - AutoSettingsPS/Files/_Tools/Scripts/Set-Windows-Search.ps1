﻿
<#
.SYNOPSIS
 Настройка поиска Windows и Кортаны (1809-2004)

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Windows_Search.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP также настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-SettingsPageVisibility для скрытия окон настроек из Параметров, с проверкой и выводом результата.

.EXAMPLE
    Set-Windows-Search -Options IndexDisable -Act Set

    Описание
    --------
    Отключить индексирование.

.EXAMPLE
    Set-Windows-Search -Options CortanaDisable -Act Default

    Описание
    --------
    Разрешить использовать кортану.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  26-04-2019
 ===============================================

#>
Function Set-Windows-Search {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут 'Check' используется только для проверки кортаны
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'IndexDisable', 'WSearchDisable', 'CortanaDisable' )]
        [string[]] $Options = 'CortanaDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'IndexPackage', 'Cortana', 'CortanaWeb', 'CortanaTaskBar', 'HideCortana' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    if ( $CheckState )
    {
        if ( 'IndexPackage' -eq $CheckState )
        {
            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\srchadmin.dll") )
            { [bool] $DllExist = $true } else { [bool] $DllExist = $false }

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
            try { [string] $IndexPending = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                           ).GetSubKeyNames() -like '*-SearchEngine-Client-Package~*'
            } catch { [string] $IndexPending = $null }

            if     (( -not $DllExist ) -and ( -not $IndexPending )) {  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Отключён  " }) }
            elseif ((      $DllExist ) -and ( -not $IndexPending )) { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Включён   " }) }
            else                                                    { "#Yellow#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Отключится" }) }
        }
        elseif ( 'Cortana' -eq $CheckState )
        {
            # Если Windows 10 старее версии 2004
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
            {
                try
                {
                    if ( Get-AppxPackage *Microsoft.Windows.Cortana* -ErrorAction SilentlyContinue )
                    { [bool] $CortanaApps = $true } else { [bool] $CortanaApps = $false }

                    try { [psobject] $AllowCortana = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Windows Search",'AllowCortana',$null) }
                    catch { [psobject] $AllowCortana = $null }

                    try { [psobject] $CortanaConsent = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search",'CortanaConsent',$null) }
                    catch { [psobject] $CortanaConsent = $null }

                    if ( $CortanaApps )
                    {
                        if (( 0 -eq $AllowCortana ) -and ( 0 -eq $CortanaConsent )) {  "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Отключена" }) }
                        else                                                        { "#Yellow#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Не Отключена" }) }
                    }
                    else
                    {
                        if (( 0 -eq $AllowCortana ) -and ( 0 -eq $CortanaConsent )) {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Удалена и Отключена" }) }
                        else                                                        { "#Yellow#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Удалена (Не отключена)" }) }
                    }
                }
                catch { "#red#{0}#" -f $(if ( $L.s7_2 ) { $L.s7_2 } else { "Отключена служба AppXSvc" }) }
            }
            else
            {
                # Иначе версия 2004 и новее (Microsoft.549981C3F5F10 App кортаны)

                [string] $Key = 'SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages'
                try { [string] $CortanaApp = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                           ).GetSubKeyNames() -like '*Microsoft.549981C3F5F10*'
                } catch { [string] $CortanaApp = '' }

                try { [psobject] $CortanaConsent = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search",'CortanaConsent',$null) }
                catch { [psobject] $CortanaConsent = $null }

                if    (( '' -eq $CortanaApp ) -and ( 0 -eq $CortanaConsent )) {  "#Green#{0}#" -f $(if ( $L.s6   ) { $L.s6   } else { "Удалена и Отключена"       }) }
                elseif ( '' -eq $CortanaApp )                                 {  "#Green#{0}#" -f $(if ( $L.s7_1 ) { $L.s7_1 } else { "Удалена"                   }) }
                elseif ( 0 -eq $CortanaConsent )                              { "#Yellow#{0}#" -f $(if ( $L.s4_1 ) { $L.s4_1 } else { "Отключена (Не удалена)"    }) }
                else                                                          { "#Yellow#{0}#" -f $(if ( $L.s5_1 ) { $L.s5_1 } else { "Не Отключена (Не удалена)" }) }
            }
        }
        elseif ( 'CortanaWeb' -eq $CheckState )
        {
            # Если Windows 10 старее версии 2004
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
            {
                try
                {
                    if ( Get-AppxPackage *Microsoft.Windows.Cortana* -ErrorAction SilentlyContinue )
                    { [bool] $CortanaApps = $true } else { [bool] $CortanaApps = $false }

                    try { [psobject] $CortanaWeb1 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Windows Search",'DisableWebSearch',$null) }
                    catch { [psobject] $CortanaWeb1 = $null }

                    try { [psobject] $CortanaWeb2 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Windows Search",'ConnectedSearchUseWeb',$null) }
                    catch { [psobject] $CortanaWeb2 = $null }

                    if ( $CortanaApps )
                    {
                        if (( 1 -eq $CortanaWeb1 ) -and ( 0 -eq $CortanaWeb2 )) {    "#Green#{0}#" -f $(if ( $L.s8  ) { $L.s8  } else { "Отключён"        }) }
                        else                                                    {   "#Yellow#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "Не Отключён"     }) }
                    } else                                                      { "#DarkGray#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Кортана Удалена" }) }
                }
                catch { "#red#{0}#" -f $(if ( $L.s7_2 ) { $L.s7_2 } else { "Отключена служба AppXSvc" }) }
            }
            else
            {
                # Иначе версия 2004 и новее (Microsoft.549981C3F5F10 App кортаны)

                [string] $Key = 'SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages'
                try { [string] $CortanaApp = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                           ).GetSubKeyNames() -like '*Microsoft.549981C3F5F10*'
                } catch { [string] $CortanaApp = '' }

                try { [psobject] $CortanaWeb1 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Windows Search",'DisableWebSearch',$null) }
                catch { [psobject] $CortanaWeb1 = $null }

                try { [psobject] $CortanaWeb2 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Windows Search",'ConnectedSearchUseWeb',$null) }
                catch { [psobject] $CortanaWeb2 = $null }

                if ( $CortanaApp )
                {
                    if (( 1 -eq $CortanaWeb1 ) -and ( 0 -eq $CortanaWeb2 )) {    "#Green#{0}#" -f $(if ( $L.s8  ) { $L.s8  } else { "Отключён"        }) }
                    else                                                    {   "#Yellow#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "Не Отключён"     }) }
                } else                                                      { "#DarkGray#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Кортана Удалена" }) }
            }
        }
        elseif ( 'CortanaTaskBar' -eq $CheckState )
        {
            # Если Windows 10 старее версии 2004
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
            {
                try { [psobject] $CortanaTaskBar = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Search",'SearchboxTaskbarMode',$null) }
                catch { [psobject] $CortanaTaskBar = $null }

                if ( 0 -eq $CortanaTaskBar ) {  "#Green#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "Скрыта                " }) }
                else                         { "#Yellow#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { "Не скрыта             " }) }
            }
            else
            {
                # Иначе версия 2004 и новее

                try { [psobject] $CortanaTaskBar = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced",'ShowCortanaButton',$null) }
                catch { [psobject] $CortanaTaskBar = $null }

                if ( 0 -eq $CortanaTaskBar ) {  "#Green#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "Скрыта                " }) }
                else                         { "#Yellow#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { "Не скрыта             " }) }
            }
        }
        elseif ( $CheckState -eq 'HideCortana' )
        {
            Set-SettingsPageVisibility -Names 'cortana','cortana-permissions','cortana-notifications',
                                              'cortana-moredetails','cortana-language','cortana-windowssearch' -Act Check -CheckOutForMenu
        }

        Return
    }

    [string] $RefreshExplorer = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class RefreshExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult);
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh()
        {
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);

            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);

            // Update taskbar
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");
        }

        private static readonly IntPtr hWnd = new IntPtr(65535);
        private const int Msg = 273;

        // Virtual key ID of the F5 in File Explorer
        private static readonly UIntPtr UIntPtr = new UIntPtr(41504);

        [DllImport("user32.dll", SetLastError=true)]
        public static extern int PostMessageW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);
        public static void PressF5Key()
        {
            // F5 pressing simulation to refresh the desktop
            PostMessageW(hWnd, Msg, UIntPtr, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.RefreshExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $RefreshExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    $text = if ( $L.s13 ) { $L.s13 } else { 'Настройка Поиска Windows' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s13_1 ) { $L.s13_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Options -like 'IndexDisable' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s14 ) { $L.s14 } else { 'Отключение' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s14_1 ) { $L.s14_1 } else { 'Индексирования' }
            Write-Host "$text`n" -ForegroundColor White

            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\srchadmin.dll") )
            { [bool] $DllExist = $true } else { [bool] $DllExist = $false }

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
            try { [string] $IndexPending = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                           ).GetSubKeyNames() -like '*-SearchEngine-Client-Package~*' | Select-Object -First 1
            } catch { [string] $IndexPending = $null }

            # Если система х64, удалить раздел реестра, из-за которого в панели управления остается пункт индексирования.
            if ( $is64 )
            {
                Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}'
            }
            
            # Не использовать индексирование при поиске в проводнике (скрывает предупреждение о включении индексирования)
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Search\Preferences' -Name 'WholeFileSystem' -Type DWord 1

            if (( $DllExist ) -and ( -not $IndexPending ))
            {
                Dism.exe /Online /Disable-Feature /FeatureName:searchengine-client-package /NoRestart
            }
            else
            {
                $text = if ( $L.s15 ) { $L.s15 } else { 'Компонент Индексирования уже отключен' }
                Write-Host "`n   $text" -ForegroundColor Green
            }
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s16 ) { $L.s16 } else { 'Восстановление' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'Индексирования' }
            Write-Host "$text`n" -ForegroundColor White

            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\srchadmin.dll") )
            { [bool] $DllExist = $true } else { [bool] $DllExist = $false }

            [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'
            try { [string] $IndexPending = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                           ).GetSubKeyNames() -like '*-SearchEngine-Client-Package~*' | Select-Object -First 1
            } catch { [string] $IndexPending = $null }

            # Если система х64, восстановить раздел реестра, из-за которого в панели управления остается пункт индексирования.
            if ( $is64 )
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}' -Name '' -Type String 'Indexing Options'
            }

            # Использовать индексирование при поиске в проводнике
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Search\Preferences' -Name 'WholeFileSystem'

            if (( $DllExist ) -and ( -not $IndexPending ))
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Компонент Индексирования уже включён' }
                Write-Host "`n   $text" -ForegroundColor Green
            }
            else
            {
                Dism.exe /Online /Enable-Feature /All /LimitAccess /FeatureName:searchengine-client-package /NoRestart
            }
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { "'Check' не предусмотрен для 'IndexDisable'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'WSearchDisable' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s19 ) { $L.s19 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Службы поиска" }
            Write-Host "$text`n" -ForegroundColor White

            Set-Svc -Do:$Act Set-Service -Name 'WSearch' -StartupType Disabled -Status Stopped
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s20 ) { $L.s20 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Службы поиска" }
            Write-Host "$text`n" -ForegroundColor White

            Set-Svc Set-Service -Name 'WSearch' -StartupType DelayedAuto
        }
        else
        {
            $text = if ( $L.s21 ) { $L.s21 } else { "'Check' не предусмотрен для 'WSearchDisable'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'CortanaDisable' )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s22 ) { $L.s22 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Кортаны" }
            Write-Host "$text `n" -ForegroundColor White

            # Комп\Адм. Шабл\Компоненты Windows\Поиск\ ... (этот раздел удаляется из ГП если удалить индексирование)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortana' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortanaAboveLock' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCloudSearch' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowSearchToUseLocation' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'BingSearchEnabled' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'DisableRemovableDriveIndexing' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'DisableWebSearch' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchUseWeb' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchUseWebOverMeteredConnections' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchPrivacy' -Type DWord 3
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchSafeSearch' -Type DWord 3

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexingOutlook' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexOnBattery' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexingEmailAttachments' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventRemoteQueries' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableSearchBoxSuggestions' -Type DWord 1

            # Дополнительные настройки
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Search' -Name 'AllowCortana' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\AboveLock' -Name 'AllowCortanaAboveLock' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Experience' -Name 'AllowCortana' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Speech_OneCore\Preferences' -Name 'ModelDownloadAllowed' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Windows Search' -Name 'CortanaConsent' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'AllowSearchToUseLocation' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BingSearchEnabled' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaConsent' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'DeviceHistoryEnabled' -Type DWord 0

            # Если Windows 10 старее версии 2004
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 0

                # Скрытие окна параметров из настроек.
                Set-SettingsPageVisibility -Act:$Act -Names 'cortana','cortana-permissions','cortana-notifications',
                                                            'cortana-moredetails','cortana-language','cortana-windowssearch'

                $DefProfile   = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile
                $DefSearchLnk = "$DefProfile\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"
                [string] $SearchLnk = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                if ( [System.IO.File]::Exists($DefSearchLnk) -and [System.IO.File]::Exists($SearchLnk) )
                {
                    if ( $Act -eq 'Set' )
                    {
                        $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                        Write-Host "`n   $text`: " -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s23_1 ) { $L.s23_1 } else { "ярлыка Поиска из меню Win + X" }
                        Write-Host "$text" -ForegroundColor White
                        Write-Host "   $SearchLnk" -ForegroundColor DarkGray

                        Remove-Item -LiteralPath \\?\$SearchLnk -Force -ErrorAction Continue
                    }
                    else
                    {
                        $NeedFix = $true

                        $text = if ( $L.s24 ) { $L.s24 } else { "Не удалён" }
                        Write-Host "`n   $text`: " -ForegroundColor Yellow -NoNewline

                        $text = if ( $L.s24_1 ) { $L.s24_1 } else { "ярлык Поиска из меню Win + X" }
                        Write-Host "$text" -ForegroundColor White
                        Write-Host "   $SearchLnk" -ForegroundColor DarkGray
                    }
                }
            }
            else
            {
                # Иначе версия 2004 и новее

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 0

                try
                {
                    $CortanaAppx = Get-AppxPackage *Microsoft.549981C3F5F10* -ErrorAction SilentlyContinue

                    if ( $CortanaAppx )
                    {
                        if ( $Act -eq 'Set' )
                        {
                            $text = if ( $L.s23 ) { $L.s23 } else { "Удаление" }
                            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                            $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Кортаны" }
                            Write-Host "$text" -ForegroundColor White
                            Write-Host "   Remove-AppxPackage 'Microsoft.549981C3F5F10'`n" -ForegroundColor DarkGray

                            # Отключение вывода прогресс бара, так как у Add-AppxPackage/Remove-AppxPackage он глючит и зависает поверх консоли
                            $ProgressPreference = 'SilentlyContinue'

                            # Удаление приложения кортаны у текущего пользователя
                            $CortanaAppx | Remove-AppxPackage -ErrorAction SilentlyContinue

                            # Возврат показа прогресс бара
                            $ProgressPreference = 'Continue'
                        }
                        else
                        {
                            $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Кортана не удалена" }
                            Write-Host "`n   $text" -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                    }
                    else
                    {
                        $text = if ( $L.s10 ) { $L.s10 } else { "Кортана удалена" }
                        Write-Host "`n   $text" -ForegroundColor Green
                    }
                }
                catch
                {
                    $text = if ( $L.s7_2 ) { $L.s7_2 } else { "Отключена служба AppXSvc" }
                    Write-Host "`n   $text" -ForegroundColor Red
                }

                # Скрытие окна параметров из настроек.
                Set-SettingsPageVisibility -Act:$Act -Names 'cortana','cortana-permissions','cortana-notifications',
                                                            'cortana-moredetails','cortana-language','cortana-windowssearch'
            }
        }
        else
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s25_1 ) { $L.s25_1 } else { "Кортаны" }
            Write-Host "$text`n" -ForegroundColor White

            # Комп\Адм. Шабл\Компоненты Windows\Поиск\ ...
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortana'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortanaAboveLock'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCloudSearch'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowSearchToUseLocation'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'BingSearchEnabled'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'DisableRemovableDriveIndexing'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'DisableWebSearch'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchUseWeb'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchUseWebOverMeteredConnections'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchPrivacy'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'ConnectedSearchSafeSearch'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexingOutlook'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexOnBattery'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventIndexingEmailAttachments'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'PreventRemoteQueries'

            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableSearchBoxSuggestions'

            # Дополнительные настройки
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Search' -Name 'AllowCortana'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\AboveLock' -Name 'AllowCortanaAboveLock'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Experience' -Name 'AllowCortana'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Speech_OneCore\Preferences' -Name 'ModelDownloadAllowed'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Windows Search' -Name 'CortanaConsent'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'AllowSearchToUseLocation'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'BingSearchEnabled'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaConsent'
            Set-Reg New-ItemProperty    -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'DeviceHistoryEnabled' -Type DWord 1

            # Удаление скрытия окна параметров из настроек, всех параметров с именем 'cortana'
            Set-SettingsPageVisibility -Remove -Names 'cortana'

            # Если Windows 10 старее версии 2004
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
            {
                Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode'

                $DefProfile   = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile
                $DefSearchLnk = "$DefProfile\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"
                $SearchLnk = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                if ( [System.IO.File]::Exists($DefSearchLnk) -and ( -not [System.IO.File]::Exists($SearchLnk) ) )
                {
                    $text = if ( $L.s26 ) { $L.s26 } else { "Восстановление" }
                    Write-Host "`n   $text`: " -ForegroundColor Magenta -NoNewline

                    $text = if ( $L.s26 ) { $L.s26 } else { "ярлыка Поиска в меню Win + X" }
                    Write-Host "$text" -ForegroundColor White
                    Write-Host "   $SearchLnk" -ForegroundColor DarkGray

                    Copy-Item -Path $DefSearchLnk -Destination $SearchLnk -Force -ErrorAction Continue
                }
            }
            else
            {
                # Иначе версия 2004 и новее

                $text = if ( $L.s26 ) { $L.s26 } else { "Восстановление" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Кортаны" }
                Write-Host "$text `n" -ForegroundColor White

                try
                {
                    $CortanaAppx = Get-AppxPackage *Microsoft.549981C3F5F10* -ErrorAction SilentlyContinue

                    if ( -not $CortanaAppx )
                    {
                        # Отключение вывода прогресс бара, так как у Add-AppxPackage он глючит и зависает поверх консоли
                        $ProgressPreference = 'SilentlyContinue'

                        [int] $N = 0
                        # Установка кортаны
                        Get-AppxPackage *Microsoft.549981C3F5F10* -AllUsers -ErrorAction Continue |
                            ForEach-Object {
                                Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ErrorAction Continue ; $N++ }

                        # Возврат показа прогресс бара
                        $ProgressPreference = 'Continue'

                        if ( -not $N )
                        {
                            $text = if ( $L.s22_2 ) { $L.s22_2 } else { "Нет пакета Кортаны, не восстановлено" }
                            Write-Host "`n   $text " -ForegroundColor Red
                        }
                        else
                        {
                            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 1
                        }
                    }
                    else
                    {
                        $text = if ( $L.s22_3 ) { $L.s22_3 } else { "Кортана уже установлена" }
                        Write-Host "`n   $text" -ForegroundColor Green
                    }
                }
                catch
                {
                    if ( Check-State-Service -ServiceName 'ClipSVC' -Need Manual -Return Bool )
                    {
                        $text = if ( $L.s7_2 ) { $L.s7_2 } else { "Отключена служба AppXSvc" }
                        Write-Host "`n   $text" -ForegroundColor Red
                    }
                    else
                    {
                        $text = if ( $L.s7_3 ) { $L.s7_3 } else { "Отключены службы AppXSvc и ClipSVC" }
                        Write-Host "`n   $text" -ForegroundColor Red
                    }
                }
            }
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        # Если запуск не из меню быстрых настроек
        if ( -not $MenuConfigsQuickSettings )
        {
            [WinAPI.RefreshExplorer]::Refresh()
            Start-Sleep -Milliseconds 500
            [WinAPI.RefreshExplorer]::PressF5Key()
        }

        $text = if ( $L.s27 ) { $L.s27 } else { "Необходимо перезагрузиться!" }
        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
