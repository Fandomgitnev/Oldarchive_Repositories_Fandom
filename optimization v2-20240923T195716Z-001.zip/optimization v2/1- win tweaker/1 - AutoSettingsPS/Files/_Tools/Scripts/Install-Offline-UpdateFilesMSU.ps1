﻿
<#
.SYNOPSIS
 Отображение данных или Установка обновлений из файлов MSU
 на текущую рабочую систему.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Используется функция Write-HostColor, для вывода информации.
 Используется утилита 7-zip для распаковки MSU и получения данных из MSU без распаковки.

 Происходит извлечение файла CAB из MSU во временную папку, и далее его Установка.

 Есть возможность обновить интегрированные в EnterpriseS/EnterpriseSN (LTSC) пакеты из полных редакций,
 которые не обновляются кумулятитвными обновлениями, так как не входят в комплект редакции и так же исключены из обновлений.
 Не все пакеты исключены из обновлений. Например исключён Классик Edge UWP, он нужен для использования режима киоска на LTSC.
 Накопительные обновления при установке обновляют существующие на данный момент пакеты, которые подходят для редакции.
 И пропускают если они исключены из обновлений либо уже обновлены этим или более новым кумулятивом.
 Если добавится компонент в системе, то кумулятив при повторной установке обновит только его.
 Это же происходит когда ЦО ставит обновление повторно и не один раз, это связано с добавленными компонентами,
 включёнными, изменёнными, добавленными языковыми файлами, или интегрированными просле установки кумулятива.

 Суть обновления исключённых компонентов заключается в правильной временной регистрации полного пакета CBS, как в Enterprise/Pro
 Далее обычная установка кумулятива поверх, он обновит только исключенные пакеты,
 так как только они будут не обновлены после обычной установки. И удалении временной регистрации CBS от полной редакции. Всё.

 Если после этого поставить в обычном режиме ещё раз этот же кумулятив или более новый,
 то исключённые компоненты будут восстановлены к изначальной версии.
 Поэтому нужно их обновлять каждый раз после обычной установки кумулятива!

.PARAMETER UpdatesFolder
 Папка где лежат файлы MSU, ищет файлы без рекурсии.
 По умолчанию указана глобальная переменная.
 Необходимый параметр!

.PARAMETER DismScratchDir
 Временная папка для Dism.
 По умолчанию указана глобальная переменная.

.PARAMETER Install
 Указывает выполнить установку.

.EXAMPLE
    Install-Offline-UpdateFilesMSU

    Описание
    --------
    Ищет все файлы MSU в указанной папке и выводит информацию о них.

.EXAMPLE
    Install-Offline-UpdateFilesMSU -Install

    Описание
    --------
    Ищет все файлы MSU в указанной папке, выводит информацию о них.
    Если разрядность подходит, то устанавливает.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  29.03.2019
 ===============================================

#>
Function Install-Offline-UpdateFilesMSU {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0 )]
        [string] $UpdatesFolder = $UpdatesFolderGlobal
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        [string] $DismScratchDir = $DismScratchDirGlobal
       ,
        [Parameter( Mandatory = $false, Position = 2 )]
        [switch] $Install   # Выполнить установку
       ,
        [Parameter( Mandatory = $false, Position = 3 )]
        [switch] $UpdateFullPkg  # Обновить интегрированные пакеты из полных редакций
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Проверка папки для обновлений.
    $text = if ( $L.s1 ) { $L.s1 } else { "Папка для обновлений не существует" }
    if ( -not [System.IO.Directory]::Exists($UpdatesFolder) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$UpdatesFolder'" ; Return }  # Выход из функции.

    $text = if ( $L.s2 ) { $L.s2 } else { "Не указан или не найден файл 7z.exe" }
    if ( -not [System.IO.File]::Exists($7z) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$7z'" ; Return }  # Выход из функции.

    [string] $Dism = 'Dism.exe'

    # Проверка временной папки для dism.
    $text = if ( $L.s3 ) { $L.s3 } else { "Не указана или не найдена временная папка для Dism.exe" }
    if ( -not [System.IO.Directory]::Exists($DismScratchDir) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$DismScratchDir'" ; Return }  # Выход из функции.

    if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $ArchOS = 'x64' } else { [string] $ArchOS = 'x86' }

    if ( $Install )
    {
        $text = if ( $L.s4 ) { $L.s4 } else { "Начало установки файлов MSU" }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }


    Function Get-ProPackageData {

        [int] $Build = [System.Environment]::OSVersion.Version.Build

        [array] $PkgInfo = @()

        if ( $Build -ge 17763 )
        {
            try
            {
                  [string] $RegKey     = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'
                [psobject] $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $ArchPkg = 'amd64' } else { [string] $ArchPkg = 'x86' }

                  [string] $PkgData         = ''
                  [string] $ProPkgName      = ''
                  [string] $PkgVers         = ''
                [psobject] $InstallTimeHigh = $null
                [psobject] $InstallTimeLow  = $null

                # Поиск раздела
                foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                {
                    #if ( $SubKey -match "^Microsoft-Windows-EnterpriseS[N]?Edition~(?<PkgData>[^~]+~$ArchPkg~~[0-9.]+)$" )
                    if ( $SubKey -match "^Microsoft-Windows-EnterpriseS[N]?Edition~(?<PkgData>[^~]+~$ArchPkg)~~(?<Version>[0-9.]+)$" )
                    {
                        [psobject] $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                        $PkgData = $Matches.PkgData
                        $PkgVers = $Matches.Version

                        if ( $OpenSubKey )
                        {
                            if ( $OpenSubKey.GetValue('CurrentState',$null) -like 112 )
                            {
                                $ProPkgName      = "Microsoft-Windows-ProfessionalEdition~$PkgData"
                                $InstallTimeHigh = $OpenSubKey.GetValue('InstallTimeHigh',0)
                                $InstallTimeLow  = $OpenSubKey.GetValue('InstallTimeLow',0)

                                $OpenSubKey.Close()

                                break
                            }

                            $OpenSubKey.Close()
                        }
                    }
                }

                $OpenRegKey.Close()
            }
            catch {}

            if ( $ProPkgName -and $PkgVers -and $InstallTimeHigh -and $InstallTimeLow )
            {
                $PkgInfo = New-Object PsObject -Property @{

                    'ProPkgName'      = $ProPkgName
                    'Version'         = $PkgVers
                    'InstallTimeHigh' = $InstallTimeHigh
                    'InstallTimeLow'  = $InstallTimeLow
                }
            }
        }

        $PkgInfo
    }


    # Временный показ надписи про ожидание
      [char] $Escape          = 27
       [int] $StringsExcl     = 2              # Количество последних строк для затирания.
    [string] $HideCursor      = "$Escape[?25l"
    [string] $ShowCursor      = "$Escape[?25h"
    [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
    [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

    $text = if ( $L.s5 ) { $L.s5 } else { "Получение данных у файлов обновлений ..."  }
    Write-Host "        $text `n" -ForegroundColor DarkCyan

     [array] $MsuInfo = @()
     [array] $MsuTXT  = @()
       [xml] $MsuXML  = ''
    [string] $MsuFile = ''
      [bool] $isMsuCU = $false

    [string] $MsuIdentName = ''
    [string] $MsuIdentVers = ''

    # Получение информации обо всех файлах MSU из их внутренних файлов TXT с именем *pkgProperties*, без распаковки.
    [hashtable] $MsuFilesData = @{}
    [int] $MsuNumber = 0
    (Get-ChildItem -File -LiteralPath \\?\$UpdatesFolder -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like '*.msu' }).Name.ForEach({

        $MsuNumber++
        $MsuInfo = @()
        $MsuTXT  = @()
        $MsuXML  = ''
        $MsuFile = "$UpdatesFolder\$_"
        $isMsuCU = $false
        $isPSFXv2 = $false

        $MsuIdentName = ''
        $MsuIdentVers = ''

        try
        {
            # Извлекаем данные из MSU из TXT файла с именем *pkgProperties* и xml без распаковки в одно действие.
            try { $MsuInfo = & $7z e "$MsuFile" '-i!*pkgProperties*.txt' '-i!*.xml'-so -sccUTF-8 2> $null } catch {}

            if ( $MsuInfo )
            {
                $MsuTXT = $MsuInfo -Replace('<[^\f]+>','')
                [xml] $MsuXML = [regex]::Matches($MsuInfo,'<[^\f]+>','IgnorePatternWhitespace').Value

                $MsuIdentName = $MsuXML.unattend.servicing.package.assemblyIdentity.name -join ''
                $MsuIdentVers = @($MsuXML.unattend.servicing.package.assemblyIdentity.version).Where({$_},'First')

                # Если накопительное обновление (CU - Cumulative Update)
                if ( $MsuIdentName -eq 'Package_for_RollupFix' ) { $isMsuCU = $true }
                elseif ( $MsuIdentName -like '*Package_for_ServicingStack*Multiple_Packages*' ) { $isMsuCU = $true ; $MsuIdentName = 'SSU + RollupFix' }
            }
            else
            {
                $MsuInfo = & $7z l "$MsuFile" -so -sccUTF-8 2> $null
                $Build = @([regex]::Match($MsuInfo,'SSU-(?<Build>[\d]+)').Groups).Where({ $_.Name -eq 'Build'}).Value

                if ( $Build -ge 22000 )
                {
                    foreach ( $i in ( $MsuInfo -like '*KB*.cab' ))
                    {
                        if ( $i -match '^(?<date>[\d.\/-]{10})[^\r\n]+KB(?<KB>[\d]{7})-(?<Arch>x[\d]{2})[.]cab$' )
                        {
                            $Date = $Matches.date
                            $KB   = $Matches.KB
                            $Arch = $Matches.Arch
                            
                            break
                        }
                    }

                    if ( $Arch -eq 'x64' ) { $Arch = 'amd64' }
                    elseif ( $Arch -eq 'x86' ) { $Arch = 'x86' }

                    if ( $KB -and $Arch )
                    {
                        $isMsuCU = $true
                        $isPSFXv2 = $true
                        $MsuTXT = "Product Name=""Windows 11.0""","Processor Architecture=""$Arch""","Build Date=""$Date""","KB Article Number=""$KB"""

                        $ExtractFolder = "$UpdatesFolder\$KB`_temp"
                        & $7z e "$MsuFile" -o"$ExtractFolder" *Metadata.cab -aoa -bso0 -bse0 -bsp0
                        & $7z e "$ExtractFolder\*Metadata.cab" -o"$ExtractFolder" LCU*.xml.cab -aoa -bso0 -bse0 -bsp0
                        [xml] $MsuXML = & $7z e "$ExtractFolder\LCU*.xml.cab" LCU*.xml -so -sccUTF-8 2> $null 

                        $MsuIdentName = 'SSU + RollupFix'
                        $MsuIdentVers =  @($MsuXML.CompDB.Packages.package.version).Where({$_},'First')

                        Remove-Item -LiteralPath $ExtractFolder -Force -Recurse -ErrorAction SilentlyContinue
                    }
                }
            }
        }
        catch {}

        if ( $MsuTXT -and $MsuIdentName )
        {
            # Добавляем номер обновления для принудитиельной сортировки накопительных обновлений по номеру,
            # чтобы они были всегда в конце списка, но отсортированы между собой.
            [string] $KB = & { if ( $MsuTXT.Where({ $_ -match '^\s*KB Article Number\s*=\s*\"([^\"\r\n]*)\"' },'First') ) { $Matches[1].Trim() } }

            # Добавляем в хэштаблицу данные из текущего MSU.
            $MsuFilesData[$MsuNumber] = @{ File = $MsuFile ; Data = $MsuTXT ; IdentName = $MsuIdentName ; IdentVers = $MsuIdentVers ; MsuCU = $isMsuCU ; KB = $KB ; isPSFXv2 = $isPSFXv2 }
        }
        else { $MsuNumber-- }
    })

    if ( -not $Install )
    {
        if ( -not $MsuNumber )
        {
            Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

            $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Подходящие файлы MSU Не найдены" }
            Write-Host "           $text" -ForegroundColor DarkYellow

            Return
        }
    }
    else
    {
        if ( -not $MsuNumber )
        {
            Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

            $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Подходящие файлы MSU Не найдены" }
            Write-Host "`n██  $NameThisFunction`: $text`n" -ForegroundColor DarkYellow

            Get-Pause ; Return
        }
    }


    # Сортировка msu
    try
    {
        # Создаем временную таблицу с накопительными обновлениями, отсортированными между собой по номеру обновления,
        # заданными начиная с -1000 номера списка, чтобы SSU + RollupFix были в начале списка, другие CU в конце списка после всех обнов.
        [hashtable] $MsuFilesCU = @{}
        ($MsuFilesData.Values | Sort-Object { $_.KB }).Foreach({
             if ( $_['MsuCU'] )
             {
                if ( $_['IdentName'] -eq 'SSU + RollupFix' )
                {
                    $MsuFilesCU[$MsuFilesCU.Count + -1000] = $_
                }
                else
                {
                    $MsuFilesCU[$MsuFilesCU.Count +  1000] = $_
                }
             }
        })

        # Создаем временную таблицу с обновлениями, кроме накопительных, без сортировки, то есть с полученной сортировкой по имени файла.
        # Чтобы оставить возможность указания сортировки по имени файлов для всех остальных обновлений.
        # Для этого обновления задаются под теми же полученными номерами списка таблицы.
        [hashtable] $MsuFilesDataTemp = @{}
        $MsuFilesData.Keys.Foreach({
             if ( -not ( $MsuFilesData[$_]['MsuCU'] )) { $MsuFilesDataTemp[$_] = $MsuFilesData[$_] }
        })

        # Создаем полную временную таблицу с отсортированными накопительными обновлениями и не отсортированными остальными.
        $MsuFilesDataTemp += $MsuFilesCU

        # Обнуляем итоговую таблицу.
        $MsuFilesData = @{}

        # Сортируем временную полную таблицу, и назначаем нормальную последовательность списку обновлений в итоговой таблице: 1,2,3, ...
        # Накопительные будут в конце списка и отсортированы между собой по номеру обновления,
        # остальные будут в той же последовательности в начале общего списка.
        $MsuFilesDataTemp.Keys | Sort-Object | ForEach-Object { $MsuFilesData[$MsuFilesData.Count + 1] = $MsuFilesDataTemp[$_] }
    }
    catch {}

    Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

    [bool] $isInstalled = $false

    # Обрабатываем хэштаблицу с данными обо всех MSU файлах, и выводим результат на экран или устанавливаем.
    [string[]] $NumbersKB = ''
    foreach ( $MsuN in ( $MsuFilesData.Keys | Sort-Object ))
    {
        [string] $MsuFileName = [System.IO.Path]::GetFileName($MsuFilesData[$MsuN]['File'])

        [string] $MsuProduct = & { if ( $MsuFilesData[$MsuN]['Data'].Where({ $_ -match '^\s*Product Name\s*=\s*\"([^\"\r\n]*)\"' },'First') ) { $Matches[1].Trim() } }
        [string] $MsuDate    = & { if ( $MsuFilesData[$MsuN]['Data'].Where({ $_ -match '^\s*Build Date\s*=\s*\"([^\"\r\n]*)\"' },'First') ) { $Matches[1].Trim() } }
        [string] $MsuKB      = & { if ( $MsuFilesData[$MsuN]['Data'].Where({ $_ -match '^\s*KB Article Number\s*=\s*\"([^\"\r\n]*)\"' },'First') ) { $Matches[1].Trim() } }
        [string] $MsuArch    = & { if ( $MsuFilesData[$MsuN]['Data'].Where({ $_ -match '^\s*Processor Architecture\s*=\s*\"([^\"\r\n]*)\"' },'First') ) { $Matches[1].Trim() } }
        
        if     ( $MsuArch -eq 'amd64' ) { $MsuArch = 'x64' ; [string] $SearchArch = 'x86'   } 
        elseif ( $MsuArch -eq 'x86'   ) { $MsuArch = 'x86' ; [string] $SearchArch = 'amd64' }
        else                            {                    [string] $SearchArch = '-----' }

        try { $MsuDate = "{1}.{2}.{0}" -f ($MsuDate.Split('-/.')) } catch {}

        $MsuIdentVers = $MsuFilesData[$MsuN]['IdentVers']
        $MsuIdentName = $MsuFilesData[$MsuN]['IdentName']

        [string] $MsuInfoCU = ''
        [string] $MsuNameCU = '  '
        [string] $NameColor = 'White'

        [string] $Arch64 = '#Green#x64'
        [string] $Arch86 = '#Yellow#x86'

          [bool] $isInstall    = $false
          [bool] $isPending    = $false
          [bool] $isSuperseded = $false

        if ( $MsuFilesData[$MsuN]['MsuCU'] )
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Накопительное обновление' }
            $MsuInfoCU = "#DarkGray#| #DarkCyan#$text " ; $MsuNameCU = '#Cyan#CU' ; $NameColor = 'DarkCyan'

            try
            {
                [string] $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing'

                $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKeyPackages\Packages",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    
                if ( $OpenKey )
                {
                    $SubKeyName = @($OpenKey.GetSubKeyNames()).Where({ $_ -like "*kb$MsuKB*" },'First')

                    if ( $SubKeyName )
                    {
                        $RollupFixName = @($OpenKey.OpenSubKey("$SubKeyName\Owners",'ReadSubTree','QueryValues').GetValueNames()).Where({ $_ -like '*Package_for_RollupFix*' },'First')

                        if ( $RollupFixName )
                        {
                            if ( [string][Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKeyPackages\PackagesPending\$RollupFixName",'','NoParam') )
                            {
                                $isPending = $true
                            }
                            else
                            {
                                $CurrentState = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKeyPackages\Packages\$RollupFixName",'CurrentState',0)
                                    
                                if ( $CurrentState -eq 112 )
                                {
                                    $isInstall = $true
                                }
                                elseif ( $CurrentState -eq 80 )
                                {
                                    $isSuperseded = $true
                                }
                            }
                        }
                    }

                    $OpenKey.Close()
                }
                
            }
            catch {}
        }
        else
        {
            # проверяем наличие в системе по номеру.
            [string] $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'

            try
            {
                [string] $isExist = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages,'ReadSubTree','QueryValues,EnumerateSubKeys'
                                      ).GetSubKeyNames().Where({ $_ -like "*kb$MsuKB*" },'First')
            }
            catch { [string] $isExist = '' }

            if ( $isExist ) { $isInstall = $true }
        }

        if ( -not $Install )
        {
            if ( $NumbersKB -like $MsuKB ) { Continue }  # Пропускаем из вывода, если номер KB уже был получен и выведен с учетом и этой разрядности.

            # Добавление текущего номера KB в массив для всех обрабатываемых номеров,
            # для исключения из отображения того же обновления MSU, но с другой разрядностью.
            $NumbersKB += $MsuKB

            # Поиск другой разрядности для текущего файла обновления. Если найдено, то назначение обоих типов разрядностей для отображения.
            [bool] $BothArch = $false
            foreach ( $MsuNN in $MsuFilesData.Keys )
            {
                if (( $MsuFilesData[$MsuNN]['Data'] -like "*KB Article Number*$MsuKB*" ) -and ( $MsuFilesData[$MsuNN]['Data'] -like "*Processor Architecture*$SearchArch*" ))
                { [bool] $BothArch = $true }
            }

            # Если разрядность у обновления MSU только одна, назначение типа нужной разрядности для отображения.
            if ( -not $BothArch )
            {
                if ( $MsuArch -eq 'x64' ) { [string] $Arch86 = '#DarkGray#---' } else { [string] $Arch64 = '#DarkGray#---' }
            }

            [string] $ArchShow = "$Arch64 #DarkGray#| $Arch86"
        }
        else
        {
            if ( $MsuArch -eq 'x64' ) { [string] $ArchShow = $Arch64 } else { [string] $ArchShow = $Arch86 }
        }


        if ( $MsuN -lt 10 ) { [string] $Space = ''.PadLeft(8,' ') } else { [string] $Space = ''.PadLeft(7,' ') }

        if ( $Install )
        {
            $Space = ''

            if ( $MsuArch -ne $ArchOS )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Разрядность MSU не подходит' }
                Write-Host "`n██  $text`: " -ForegroundColor DarkYellow -NoNewline
            }
            else
            {
                $text = if ( $L.s8 ) { $L.s8 } else { 'Установка MSU' }
                Write-Host "`n██  $text`: " -ForegroundColor Cyan -NoNewline
            }
        }

        # Вывод результата на экран.

        if     ( $isPending    ) { $text = if ( $L.s9   ) { $L.s9   } else { 'В ожидании' } ; $ColorState = 'DarkYellow' }
        elseif ( $isSuperseded ) { $text = if ( $L.s9_1 ) { $L.s9_1 } else { 'Заменён   ' } ; $ColorState = 'DarkGreen'  }
        elseif ( $isInstall    ) { $text = if ( $L.s10  ) { $L.s10  } else { 'Установлен' } ; $ColorState = 'Green'      }
        else                     { $text = if ( $L.s11  ) { $L.s11  } else { '----------' } ; $ColorState = 'DarkGray'   }

        $text = "$Space#DarkGray#$MsuN. #$ColorState#MSU#DarkGray#: kb#$NameColor#$MsuKB $MsuNameCU       #DarkGray#| $ArchShow #DarkGray#| {0} #DarkGray#| $MsuDate | $MsuProduct | #$ColorState#$text #DarkGray#| $MsuIdentName $MsuInfoCU#DarkGray#| $MsuFileName#" -f
            $MsuIdentVers.PadRight(16,' ')

        Write-HostColor "$text"

        # Если не установка или разрядность не подходит.
        if (( -not $Install ) -or ( $MsuArch -ne $ArchOS )) { Continue }  # Пропускаем итерацию, переходим к следующему элементу foreach.


        # Далее, если Установка ##############################


        $isInstalled = $true

        if ( $UpdateFullPkg -and $MsuFilesData[$MsuN]['MsuCU'] -and $isInstall )
        {
            [array] $PkgInfo = Get-ProPackageData

            if ( $PkgInfo.ProPkgName )
            {
                $text = if ( $L.s8_1 ) { $L.s8_1 } else { 'С Обновлением интегрированных пакетов из полных редакций' }
                Write-Host "    $text" -ForegroundColor DarkCyan

                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\$($PkgInfo.ProPkgName)~~0.0.0.0"
                Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 0 -NoCheck

                $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\Product'
                Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 0 -NoCheck

                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)"
                Set-Reg New-ItemProperty -Path $Path -Name "CurrentState" -Type DWord 112 -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallClient" -Type String 'DISM Package Manager Provider' -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallLocation" -Type String "\\?\$env:SystemDrive\Temp\Packages\" -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallName" -Type String "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version).mum" -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallTimeHigh" -Type DWord $PkgInfo.InstallTimeHigh -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallTimeLow" -Type DWord $PkgInfo.InstallTimeLow -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "InstallUser" -Type String 'S-1-5-18' -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "SelfUpdate" -Type DWord 0 -NoCheck
                Set-Reg New-ItemProperty -Path $Path -Name "Visibility" -Type DWord 1 -NoCheck

                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)\Owners"
                Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 131184 -NoCheck
            }
            else
            {
                $text = if ( $L.s8_2 ) { $L.s8_2 } else { 'Нет необходимости обновлять интегрированные пакеты из полных редакций' }
                Write-Host "    $text" -ForegroundColor DarkGray

                Continue  # Переход к следующей итерации foreach
            }
        }
        elseif ( $UpdateFullPkg -and $MsuFilesData[$MsuN]['MsuCU'] -and $isPending )
        {
            $text = if ( $L.s8_3 ) { $L.s8_3 } else { 'Накопительное обновление ожидает завершения установки, перезагрузитесь!' }
            Write-Host "`n    $text`n" -ForegroundColor Yellow

            Continue  # Переход к следующей итерации foreach
        }
        elseif ( $UpdateFullPkg -and $MsuFilesData[$MsuN]['MsuCU'] )
        {
            $text = if ( $L.s8_4 ) { $L.s8_4 } else { 'Сначала установите последнее Накопительное обновление в обычном режиме!' }
            Write-Host "`n    $text`n" -ForegroundColor Yellow

            Continue  # Переход к следующей итерации foreach
        }
        elseif ( $UpdateFullPkg )
        {
            $text = if ( $L.s8_5 ) { $L.s8_5 } else { 'MSU файл не Накопительное обновление' }
            Write-Host "`n    $text`n" -ForegroundColor Yellow

            Continue  # Переход к следующей итерации foreach
        }

        # Временная папка для распаковки MSU.
        [string] $TempFolder = "$UpdatesFolder\MSU_$MsuKB"

        [string] $CurrentMsuFile = $MsuFilesData[$MsuN]['File']

        if ( $MsuFilesData[$MsuN]['MsuCU'] )
        {
            if ( -not $MsuFilesData[$MsuN]['isPSFXv2'] )
            {
                $text = if ( $L.s12 ) { $L.s12 } else { 'Создание временной папки' }
                Write-Host "`n    $text`: '$TempFolder'" -ForegroundColor DarkGray

                if ( Test-Path -LiteralPath \\?\$TempFolder -PathType Any -ErrorAction SilentlyContinue )
                { Remove-Item -LiteralPath \\?\$TempFolder -Recurse -Force -ErrorAction SilentlyContinue }
                New-Item -ItemType Directory -Path $TempFolder -Force -ErrorAction SilentlyContinue > $null

                $text = if ( $L.s12_1 ) { $L.s12_1 } else { 'Извлечение CAB из MSU' }
                Write-Host "    $text`: '$CurrentMsuFile'" -ForegroundColor DarkGray

                # Извлекаем все файлы кроме трёх типов, во временную папку, при помощи 7z.exe
                & $7z e -tcab $CurrentMsuFile -o"$TempFolder" -x!"WSUSSCAN.cab" -x!"*Deployment*.cab" -x!"*Metadata*.cab" -aoa -bso0 -bse0 -bsp0

                Start-Sleep -Milliseconds 1000

                $text = if ( $L.s12_3 ) { $L.s12_3 } else { 'Установка MSU' }
                Write-Host "`n    $text " -ForegroundColor Magenta -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$CurrentMsuFile" -ForegroundColor White

                $text = if ( $L.s13 ) { $L.s13 } else { 'Команда' }
                Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package /PackagePath:$TempFolder" -ForegroundColor DarkGray

                # Выполнение интеграции распакованного CAB файла из MSU.
                & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package /PackagePath:"$TempFolder"
            }
            else
            {
                $text = if ( $L.s12_3 ) { $L.s12_3 } else { 'Установка MSU' }
                Write-Host "`n    $text PSFXv2 " -ForegroundColor Magenta -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$CurrentMsuFile" -ForegroundColor White

                $text = if ( $L.s13 ) { $L.s13 } else { 'Команда' }
                Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package /PackagePath:$CurrentMsuFile" -ForegroundColor DarkGray

                # Выполнение интеграции MSU файла
                & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package /PackagePath:"$CurrentMsuFile"
            }

            $text = if ( $L.s14 ) { $L.s14 } else { 'Установка' }
            Write-Host "`n    $text`: " -ForegroundColor DarkGray -NoNewline

            if ( $Global:LastExitCode -eq 3010 )
            {
                $text = if ( $L.s14_1 ) { $L.s14_1 } else { 'Необходима перезагрузка' }
                Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
            }
            elseif ( $Global:LastExitCode )
            {
                try { $err = "0x{0}" -f [System.Convert]::ToString($Global:LastExitCode, 16) } catch { $err = $Global:LastExitCode }

                $text = if ( $L.s14_2 ) { $L.s14_2 } else { 'Ошибка' }
                Write-Host "  $text`: $err  " -BackgroundColor DarkRed -ForegroundColor White
            }
            else
            {
                $text = if ( $L.s14_3 ) { $L.s14_3 } else { 'Выполнена' }
                Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
            }

            Start-Sleep -Milliseconds 1000

            if ( $UpdateFullPkg -and $MsuFilesData[$MsuN]['MsuCU'] -and $PkgInfo.ProPkgName )
            {
                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\$($PkgInfo.ProPkgName)~~0.0.0.0"
                Set-Reg Remove-Item -Path $Path -NoCheck
                $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\Product'
                Set-Reg Remove-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -NoCheck
                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)"
                Set-Reg Remove-Item -Path $Path -NoCheck
            }
        }
        else
        {
            $text = if ( $L.s12 ) { $L.s12 } else { 'Создание временной папки' }
            Write-Host "`n    $text`: '$TempFolder'" -ForegroundColor DarkGray

            if ( Test-Path -LiteralPath \\?\$TempFolder -PathType Any -ErrorAction SilentlyContinue )
            { Remove-Item -LiteralPath \\?\$TempFolder -Recurse -Force -ErrorAction SilentlyContinue }
            New-Item -ItemType Directory -Path $TempFolder -Force -ErrorAction SilentlyContinue > $null

            $text = if ( $L.s12_1 ) { $L.s12_1 } else { 'Извлечение CAB из MSU' }
            Write-Host "    $text`: '$CurrentMsuFile'" -ForegroundColor DarkGray

            # Извлекаем все файлы кроме WSUSSCAN.cab, во временную папку, при помощи 7z.exe.
            & $7z e -tcab $CurrentMsuFile -o"$TempFolder" -x!"WSUSSCAN.cab" -aoa -bso0 -bse0 -bsp0

            Start-Sleep -Milliseconds 1000

            [string] $FoundCab = (Get-ChildItem -File -LiteralPath \\?\$TempFolder -Force -ErrorAction SilentlyContinue
                                 ).Where({ $_.Name -like "*.cab" },'First').Name
            # Если файл извлекся.
            if ( $FoundCab )
            {
                $text = if ( $L.s12_2 ) { $L.s12_2 } else { 'Установка извлеченного CAB' }
                Write-Host "`n    $text " -ForegroundColor Magenta -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$FoundCab" -ForegroundColor White

                $text = if ( $L.s13 ) { $L.s13 } else { 'Команда' }
                Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package:$TempFolder\$FoundCab" -ForegroundColor DarkGray

                # Выполнение интеграции распакованного CAB файла из MSU.
                & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package:"$TempFolder\$FoundCab"

                $text = if ( $L.s14 ) { $L.s14 } else { 'Установка' }
                Write-Host "`n    $text`: " -ForegroundColor DarkGray -NoNewline

                if ( $Global:LastExitCode -eq 3010 )
                {
                    $text = if ( $L.s14_1 ) { $L.s14_1 } else { 'Необходима перезагрузка' }
                    Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
                }
                elseif ( $Global:LastExitCode )
                {
                    try { $err = "0x{0}" -f [System.Convert]::ToString($Global:LastExitCode, 16) } catch { $err = $Global:LastExitCode }

                    $text = if ( $L.s14_2 ) { $L.s14_2 } else { 'Ошибка' }
                    Write-Host "  $text`: $err  " -BackgroundColor DarkRed -ForegroundColor White
                }
                else
                {
                    $text = if ( $L.s14_3 ) { $L.s14_3 } else { 'Выполнена' }
                    Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
                }

                Start-Sleep -Milliseconds 1000

                if ( $UpdateFullPkg -and $MsuFilesData[$MsuN]['MsuCU'] -and $PkgInfo.ProPkgName )
                {
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\$($PkgInfo.ProPkgName)~~0.0.0.0"
                    Set-Reg Remove-Item -Path $Path -NoCheck
                    $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\Product'
                    Set-Reg Remove-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -NoCheck
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)"
                    Set-Reg Remove-Item -Path $Path -NoCheck
                }
            }
            else
            {
                $text = if ( $L.s16 ) { $L.s16 } else { 'CAB файл не извлекся!' }
                Write-Warning "$text"
            }
        }

        $text = if ( $L.s15 ) { $L.s15 } else { 'Удаление временной папки' }
        Write-Host "`n    $text`: '$TempFolder'" -ForegroundColor DarkGray

        Remove-Item -LiteralPath \\?\$TempFolder -Recurse -Force -ErrorAction SilentlyContinue
    }

    if ( $Install )
    {
        # Если было выполнение установки.
        if ( $isInstalled )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Выполнено' }
            Write-Host "`n██ $text" -ForegroundColor Green

            $text = if ( $L.s18 ) { $L.s18 } else { 'После установки обновлений необходима перезагрузка!' }
            Write-Host "   $text" -ForegroundColor DarkGreen
        }
        else
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Выполнено' }
            Write-Host "`n██ $text`n" -ForegroundColor Green
        }

        Get-Pause
    }
}
