﻿
# Группы параметров, не относящиеся к чему либо конкретно. Наборы параметров для разных настроек.
Function Set-Configs-Other2 {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false, Position = 1 )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [string[]] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [Environment]::Is64BitOperatingSystem


    # Далее сами настройки ...



    $Info = 'Настроить Internet Explorer'
    $Group = 'Other2-IE' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            "Отключить мастер первого запуска:" | Show-Info -Shift $L.s2 -NotIndent

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10RunOncePerInstallCompleted' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10TourNoShow' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10TourShown' -Type DWord 1

            if ( $act -eq 'Set' )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10TourShownTime' -Type Binary 00
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10RunOnceCompletionTime' -Type Binary 00
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10RunOnceLastShown_TIMESTAMP' -Type Binary 00
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'IE10RecommendedSettingsNo' -Type DWord 1
            }

            "Предотвратить повторное использование окна Internet Explorer:" | Show-Info -Shift $L.s3
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'AllowWindowReuse' -Type DWord 0

            "Отключить отладку скриптов:" | Show-Info -Shift $L.s4
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Disable Script Debugger' -Type String 'yes'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'DisableScriptDebuggerIE' -Type String 'yes'

            "Отключить автозаполнение форм:" | Show-Info -Shift $L.s5
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Use FormSuggest' -Type String 'no'

            "Не предлагать Internet Explorer использовать по умолчанию:" | Show-Info -Shift $L.s6
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Check_Associations' -Type String 'no'

            "Пустая страница по умолчанию в Internet Explorer:" | Show-Info -Shift $L.s7
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Start Page' -Type String 'about:Tabs'

            "Отключить встроенную проверку подлинности Windows:" | Show-Info -Shift $L.s8
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'EnableNegotiate' -Type DWord 0

            "Отключить предупреждение о начале просмотра веб-страницы через безопасное соединение:" | Show-Info -Shift $L.s9
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'WarnonZoneCrossing' -Type DWord 0

            "Кэш для временных файлов = 337Мб по умолчанию:" | Show-Info -Shift $L.s10
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\5.0\Cache\Content' -Name 'CacheLimit' -Type DWord 337920
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\5.0\LowCache\Content' -Name 'CacheLimit' -Type DWord 337920

            "Отключить предупреждение 'Информация переданная через Интернет, может стать доступной другим пользователям':" | Show-Info -Shift $L.s11
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\3' -Name '1601' -Type DWord 0

            "Отключить сообщение о возможности использования автозаполнения:" | Show-Info -Shift $L.s12
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\IntelliForms' -Name 'AskUser' -Type DWord 0

            "Не проверять цифровую подпись загружаемых программ:" | Show-Info -Shift $L.s13
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Download' -Name 'CheckExeSignatures' -Type String 'no'

            "Отключить использование рекомендуемых сайтов:" | Show-Info -Shift $L.s14
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Suggested Sites' -Name 'Enabled' -Type DWord 0

            "Открывать всплывающие окна в новой вкладке:" | Show-Info -Shift $L.s16
            # 0 = определяет IE (дефолт)
            # 1 = в новом окне
            # 2 = в новой вкладке
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'PopupsUseNewWindow' -Type DWord 2

            "При открытии новой вкладки открывать Новую страницу:" | Show-Info -Shift $L.s17
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'NewTabPageShow' -Type DWord 2

            "Не предупреждать об одновременном закрытии вкладок:" | Show-Info -Shift $L.s18
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'WarnOnClose' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'ShowTabsWelcome' -Type DWord 0

            "Всегда переключаться на новую вкладку при ее создании:" | Show-Info -Shift $L.s19
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'OpenInForeground' -Type DWord 1

            "Показывать строку состояния:" | Show-Info -Shift $L.s20
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\MINIE' -Name 'ShowStatusBar' -Type DWord 1

            "Отключить Internet Connection Wizard (при первом запуске IE):" | Show-Info -Shift $L.s21
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Connection Wizard' -Name 'Completed' -Type DWord 1

            "Отключить автопроверку веб каналов по раписанию:" | Show-Info -Shift $L.s22
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Feeds' -Name 'SyncStatus' -Type DWord 0

            "Не помечать автоматически веб канал как просмотреный:" | Show-Info -Shift $L.s23
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Feeds' -Name 'AutoMarkAsReadOPV' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            # Предотвратить повторное использование окна Internet Explorer
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'AllowWindowReuse'

            # Выключить автозаполнение форм
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Use FormSuggest'

            # Не предлагать Internet Explorer использовать по умолчанию
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Check_Associations'

            # Пустая страница по умолчанию в Internet Explorer
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Main' -Name 'Start Page' -Type String 'http://go.microsoft.com/fwlink/?LinkId=625119&clocalename=ru-RU'

            # Отключить встроенную проверку подлинности Windows
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'EnableNegotiate' -Type DWord 1

            # Отключить сообщение о возможности использования автозаполнения
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\IntelliForms' -Name 'AskUser'

            # Не проверять цифровую подпись загружаемых программ
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Download' -Name 'CheckExeSignatures'

            # Отключить использование рекомендуемых сайтов
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Suggested Sites' -Name 'Enabled'

            # Открывать всплывающие окна в новой вкладке
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'PopupsUseNewWindow'

            # При открытии новой вкладки открывать Новую страницу вкладки
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'NewTabPageShow'

            # Не предупреждать об одновременном закрытии вкладок
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'WarnOnClose'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'ShowTabsWelcome'

            # Всегда переключаться на новую вкладку при ее создании
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'OpenInForeground'

            # Показывать строку состояния
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\MINIE' -Name 'ShowStatusBar'

            # Отключить автопроверку веб каналов по раписанию
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Feeds' -Name 'SyncStatus'

            # Не помечать автоматически веб канал как просмотреный
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Feeds' -Name 'AutoMarkAsReadOPV'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Открывать ярлыки и ссылки из других программ в новом окне Internet Explorer'
    $Group = 'Other2-IE-NewWindow' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'ShortcutBehavior' -Type DWord 0
        
            # 0 = новое окно
            # 1 = текущее окно (дефолт)
            # 2 = ткущее окно в текущей вкладке
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\TabbedBrowsing' -Name 'ShortcutBehavior'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Добавить поиск Yandex в Internet Explorer'
    $Group = 'Other2-IE-Yandex' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act -NoIndentAfter

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {

            try
            {
                [string] $RegKey = 'Software\Microsoft\Internet Explorer\SearchScopes'

                [array] $Accs = [PSCustomObject] @{ 
                    Name = $env:USERNAME
                    Root = 'HKCU:'
                }

                if ( $Global:DataAllUsers.Redirects.Value )
                {
                    @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({

                        $Accs += [PSCustomObject] @{ 
                            Name = $_.Name
                            Root = $_.SID
                        }
                    })
                }

                foreach ( $Acc in $Accs )
                {
                    if ( $Acc.Root -eq 'HKCU:' )
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = $Acc.Root
                    }
                    else
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = "Registry::HKU\$($Acc.Root)"
                    }

                    [array] $isSearchGUIDs = @()

                    if ( $OpenRegKey )
                    {
                        foreach ( $GUID in $OpenRegKey.GetSubKeyNames() )
                        {
                            try { [psobject] $Openkey = $OpenRegKey.OpenSubKey($GUID,'ReadSubTree','QueryValues') }
                            catch { [psobject] $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $Openkey.GetValue('URL',$null) -like '*Yandex*' )
                                {
                                    $isSearchGUIDs = $GUID
                                }
                        
                                $Openkey.Close()
                            }
                        }

                        $OpenRegKey.Close()
                    }

                    # Только если применение, добавить поисковые движки, если их ещё нет. По умолчанию будет Yandex.
                    if ( $Act -eq 'Set' )
                    {
                        if ( -not $isSearchGUIDs.Count )
                        {
                            "Добавление Поискового движка 'Yandex' в IE:" | Show-Info -Shift "$($L.s2) ($($Acc.Name))"

                            # Генерация уникального GUID.
                            [string] $GUID = "{$((New-Guid).Guid.ToUpper())}"
                            [string] $Path = "$isRoot\Software\Microsoft\Internet Explorer\SearchScopes\$GUID"

                            Set-Reg New-ItemProperty -Path $Path -Name 'DisplayName' -Type String 'Yandex' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'FaviconURL' -Type String 'https://yandex.ru/favicon.ico' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'URL' -Type String 'https://yandex.ru/yandsearch?text={searchTerms}' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'ShowSearchSuggestions' -Type DWord 1 -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'SuggestionsURL_JSON' -Type String 'https://suggest.yandex.ru/suggest-ff.cgi?srv=ie11&part={searchTerms}' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'Codepage' -Type DWord 65001 -OnlyThisPath

                            "Установка По умолчанию Поискового движка 'Yandex' в IE:" | Show-Info -Shift "$($L.s3) ($($Acc.Name))"

                            [string] $Path = "$isRoot\Software\Microsoft\Internet Explorer\SearchScopes"
                            [string] $Value = $GUID
                            Set-Reg New-ItemProperty -Path $Path -Name 'DefaultScope' -Type String $Value -OnlyThisPath
                        }
                        else
                        {
                            $text = if ( $L.s6 ) { $L.s6 } else { "Поиск 'Yandex' в IE добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Green
                        }
                    }
                    else
                    {
                        if ( -not $isSearchGUIDs.Count )
                        {
                            $text = if ( $L.s5 ) { $L.s5 } else { "Поиск 'Yandex' в IE не добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                        else
                        {
                            $text = if ( $L.s6 ) { $L.s6 } else { "Поиск 'Yandex' в IE добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Green
                        }
                    }
                }
            }
            catch {}
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default -NoIndentAfter

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            try
            {
                   [int] $N = 0

                [string] $RegKey = 'Software\Microsoft\Internet Explorer\SearchScopes'

                [array] $Accs = [PSCustomObject] @{ 
                    Name = $env:USERNAME
                    Root = 'HKCU:'
                }

                if ( $Global:DataAllUsers.Redirects.Value )
                {
                    @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({

                        $Accs += [PSCustomObject] @{ 
                            Name = $_.Name
                            Root = $_.SID
                        }
                    })
                }

                foreach ( $Acc in $Accs )
                {
                    if ( $Acc.Root -eq 'HKCU:' )
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = $Acc.Root
                    }
                    else
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = "Registry::HKU\$($Acc.Root)"
                    }

                    [array] $isSearchGUIDs = @()

                    if ( $OpenRegKey )
                    {
                        foreach ( $GUID in $OpenRegKey.GetSubKeyNames() )
                        {
                            try { [psobject] $Openkey = $OpenRegKey.OpenSubKey($GUID,'ReadSubTree','QueryValues') }
                            catch { [psobject] $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $Openkey.GetValue('URL',$null) -like '*Yandex*' )
                                {
                                    $isSearchGUIDs += $GUID
                                }
                        
                                $Openkey.Close()
                            }
                        }

                        $OpenRegKey.Close()
                    }

                    if ( $isSearchGUIDs.Count )
                    {
                        $N++

                        "$($Acc.Name):" | Show-Info

                        foreach ( $GUID in $isSearchGUIDs )
                        {
                            [string] $Path = "$isRoot\Software\Microsoft\Internet Explorer\SearchScopes\$GUID"
                            Set-Reg Remove-Item -Path $Path -OnlyThisPath
                        }
                    }
                }
            }
            catch {}

            if ( -not $N ) { Write-Host "`n   ----------------------------" -ForegroundColor DarkGray }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Добавить поиск Google в Internet Explorer'
    $Group = 'Other2-IE-Google' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act -NoIndentAfter

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            try
            {
                [string] $RegKey = 'Software\Microsoft\Internet Explorer\SearchScopes'

                [array] $Accs = [PSCustomObject] @{ 
                    Name = $env:USERNAME
                    Root = 'HKCU:'
                }

                if ( $Global:DataAllUsers.Redirects.Value )
                {
                    @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({

                        $Accs += [PSCustomObject] @{ 
                            Name = $_.Name
                            Root = $_.SID
                        }
                    })
                }

                foreach ( $Acc in $Accs )
                {
                    if ( $Acc.Root -eq 'HKCU:' )
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = $Acc.Root
                    }
                    else
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = "Registry::HKU\$($Acc.Root)"
                    }

                    [array] $isSearchGUIDs = @()

                    if ( $OpenRegKey )
                    {
                        foreach ( $GUID in $OpenRegKey.GetSubKeyNames() )
                        {
                            try { [psobject] $Openkey = $OpenRegKey.OpenSubKey($GUID,'ReadSubTree','QueryValues') }
                            catch { [psobject] $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $Openkey.GetValue('URL',$null) -like '*Google*' )
                                {
                                    $isSearchGUIDs = $GUID
                                }
                        
                                $Openkey.Close()
                            }
                        }

                        $OpenRegKey.Close()
                    }

                    # Только если применение, добавить поисковые движки, если их ещё нет. По умолчанию будет Yandex.
                    if ( $Act -eq 'Set' )
                    {
                        if ( -not $isSearchGUIDs.Count )
                        {
                            "Добавление Поискового движка 'Google' в IE:" | Show-Info -Shift "$($L.s2) ($($Acc.Name))"

                            # Генерация уникального GUID.
                            [string] $GUID = "{$((New-Guid).Guid.ToUpper())}"
                            [string] $Path = "$isRoot\Software\Microsoft\Internet Explorer\SearchScopes\$GUID"

                            Set-Reg New-ItemProperty -Path $Path -Name 'DisplayName' -Type String 'Google' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'FaviconURL' -Type String 'https://www.google.ru/favicon.ico' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'URL' -Type String 'https://www.google.ru/search?hl=ru&q={searchTerms}' -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'ShowSearchSuggestions' -Type DWord 1 -OnlyThisPath
                            Set-Reg New-ItemProperty -Path $Path -Name 'SuggestionsURL_JSON' -Type String 'https://suggestqueries.google.com/complete/search?output=firefox&client=firefox&qu={searchTerms}' -OnlyThisPath
                        }
                        else
                        {
                            $text = if ( $L.s4 ) { $L.s4 } else { "Поиск 'Google' в IE добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Green
                        }
                    }
                    else
                    {
                        if ( -not $isSearchGUIDs.Count )
                        {
                            $text = if ( $L.s3 ) { $L.s3 } else { "Поиск 'Google' в IE не добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                        else
                        {
                            $text = if ( $L.s4 ) { $L.s4 } else { "Поиск 'Google' в IE добавлен" }
                            Write-Host "`n   $text ($($Acc.Name))" -ForegroundColor Green
                        }
                    }
                }
            }
            catch {}
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default -NoIndentAfter

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            try
            {
                   [int] $N = 0

                [string] $RegKey = 'Software\Microsoft\Internet Explorer\SearchScopes'

                [array] $Accs = [PSCustomObject] @{ 
                    Name = $env:USERNAME
                    Root = 'HKCU:'
                }

                if ( $Global:DataAllUsers.Redirects.Value )
                {
                    @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.NTUSER_Load })).ForEach({

                        $Accs += [PSCustomObject] @{ 
                            Name = $_.Name
                            Root = $_.SID
                        }
                    })
                }

                foreach ( $Acc in $Accs )
                {
                    if ( $Acc.Root -eq 'HKCU:' )
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = $Acc.Root
                    }
                    else
                    {
                        $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $isRoot     = "Registry::HKU\$($Acc.Root)"
                    }

                    [array] $isSearchGUIDs = @()

                    if ( $OpenRegKey )
                    {
                        foreach ( $GUID in $OpenRegKey.GetSubKeyNames() )
                        {
                            try { [psobject] $Openkey = $OpenRegKey.OpenSubKey($GUID,'ReadSubTree','QueryValues') }
                            catch { [psobject] $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $Openkey.GetValue('URL',$null) -like '*Google*' )
                                {
                                    $isSearchGUIDs += $GUID
                                }
                        
                                $Openkey.Close()
                            }
                        }

                        $OpenRegKey.Close()
                    }

                    if ( $isSearchGUIDs.Count )
                    {
                        $N++

                        "$($Acc.Name):" | Show-Info

                        foreach ( $GUID in $isSearchGUIDs )
                        {
                            [string] $Path = "$isRoot\Software\Microsoft\Internet Explorer\SearchScopes\$GUID"
                            Set-Reg Remove-Item -Path $Path -OnlyThisPath
                        }
                    }
                }
            }
            catch {}

            if ( -not $N ) { Write-Host "`n   ----------------------------" -ForegroundColor DarkGray }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Удалять кэш страниц при закрытии Internet Explorer'
    $Group = 'Other2-IE-DeleteClose' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Cache' -Name 'Persistent' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Cache' -Name 'Persistent' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Удалять все данные при закрытии Internet Explorer: История, Пароли, Формы, Куки, Временные файлы и т.д.'
    $Group = 'Other2-IE-DeleteAllClose' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'ClearBrowsingHistoryOnExit' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'UseAllowList' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanTIF' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanCookies' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanHistory' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanDownloadHistory' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanForms' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanPassword' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanTrackingProtection' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )  # IE Отключен на W11
        {
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'ClearBrowsingHistoryOnExit'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'UseAllowList'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanTIF'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanCookies'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanHistory'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanDownloadHistory'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanForms'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanPassword'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Privacy' -Name 'CleanTrackingProtection'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не поддерживается в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Очистка кэша IE | Только кэш страниц IE и Проводника (подключенных устройств)'
    $Group = 'Other2-IE-Cache-General' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Sub-Group-Other2\s*=\s*1\s*=\s*$Group\s*=\s*(?<MB>\d+)\s*=" },'First',1) )
        {
            [string] $MB = $Matches.MB.Trim()
        }
        else { [string] $MB = 100 }

        [array] $Accs = [PSCustomObject] @{ 
            Root    = 'HKEY_CURRENT_USER'
            Profile = $env:USERPROFILE
        }

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({
            
                $Accs += [PSCustomObject] @{ 
                    Root    = "HKEY_USERS\$($_.SID)"
                    Profile = $_.Profile
                }
            })
        }

        foreach ( $Acc in $Accs )
        {
            $UserProfile = $Acc.Profile

            $text = if ( $L.s2 ) { $L.s2 } else { 'Профиль' }
            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$UserProfile\ " -ForegroundColor White -NoNewline

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { 'Предупреждение от' }
                Write-Host "| $text`: $MB`mb`n" -ForegroundColor DarkGray
            }
            else { Write-Host "`n" }
            
            [string[]] $Paths = @()

            $Paths += "$UserProfile\AppData\Local\Microsoft\Windows\INetCache",
                      "$UserProfile\AppData\Local\Microsoft\Windows\IECompatCache",
                      "$UserProfile\AppData\Local\Microsoft\Windows\IECompatUaCache",
                      "$UserProfile\AppData\Local\Microsoft\Windows\IEDownloadHistory",
                      "$UserProfile\AppData\LocalLow\Microsoft\Internet Explorer\DOMStore",
                      "$UserProfile\AppData\LocalLow\Microsoft\Internet Explorer\EmieSiteList",
                      "$UserProfile\AppData\LocalLow\Microsoft\Internet Explorer\EmieUserList",
                      "$UserProfile\AppData\LocalLow\Microsoft\Internet Explorer\Services",
                      "$UserProfile\AppData\Local\Microsoft\PlayReady\Internet Explorer\InPrivate"

            # Проверяется Изменённая папка кэша 
            try
            {
                [string] $Key = "$($Acc.Root)\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
                [string] $UserCacheFolder = [Microsoft.Win32.Registry]::GetValue($Key,'Cache',$null) # Расскрывает переменные
                
                $UserCacheFolder = $UserCacheFolder -Replace([regex]::Escape($env:USERPROFILE),$UserProfile) # Заменяет профиль на текущий, если там указана переменная

                if ( $UserCacheFolder -and [System.IO.Directory]::Exists($UserCacheFolder) -and -not ( $Paths -like $UserCacheFolder ))
                {
                    $Paths += $UserCacheFolder
                }
            }
            catch {}

            if ( $Act -eq 'Set' ) { Stop-Process -Name iexplore -Force -ErrorAction SilentlyContinue }

            CleanUp-Files-Folders -Act $Act -Paths $Paths -WarningSize $MB
        }
    }



    $Info = 'Очистка кэша IE | Куки (вход на сайты), Автозаполнение (пароли, формы)'
    $Group = 'Other2-IE-Cache-Cookies' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Sub-Group-Other2\s*=\s*1\s*=\s*$Group\s*=\s*(?<MB>\d+)\s*=" },'First',1) )
        {
            [string] $MB = $Matches.MB.Trim()
        }
        else { [string] $MB = 100 }

        [array] $Profiles = $env:USERPROFILE

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                $Profiles += $_.Profile
            })
        }

        foreach ( $UserProfile in $Profiles )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Профиль' }
            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$UserProfile\ " -ForegroundColor White -NoNewline

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { 'Предупреждение от' }
                Write-Host "| $text`: $MB`mb`n" -ForegroundColor DarkGray
            }
            else { Write-Host "`n" }
            
            [string[]] $Paths = @()

            $Paths += "$UserProfile\AppData\Local\Microsoft\Vault",                # сохраненные формы и пароли
                      "$UserProfile\AppData\Local\Microsoft\Windows\INetCookies",  # вход на сайты
                      "$UserProfile\AppData\LocalLow\Microsoft\CryptnetUrlCache\Content",
                      "$UserProfile\AppData\LocalLow\Microsoft\CryptnetUrlCache\MetaData"

            if ( $Act -eq 'Set' ) { Stop-Process -Name iexplore -Force -ErrorAction SilentlyContinue }

            CleanUp-Files-Folders -Act $Act -Paths $Paths -WarningSize $MB
        }
    }



    $Info = 'Очистка кэша IE | Список посещённых страниц, История, Подписки и т.д'
    $Group = 'Other2-IE-Cache-History' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Sub-Group-Other2\s*=\s*1\s*=\s*$Group\s*=\s*(?<MB>\d+)\s*=" },'First',1) )
        {
            [string] $MB = $Matches.MB.Trim()
        }
        else { [string] $MB = 100 }

        [array] $Profiles = $env:USERPROFILE

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                $Profiles += $_.Profile
            })
        }

        foreach ( $UserProfile in $Profiles )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Профиль' }
            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$UserProfile\ " -ForegroundColor White -NoNewline

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { 'Предупреждение от' }
                Write-Host "| $text`: $MB`mb`n" -ForegroundColor DarkGray
            }
            else { Write-Host "`n" }
  
            [string[]] $Paths = @()

            $Paths += "$UserProfile\AppData\Local\Microsoft\Windows\History",  # история посещений
                      "$UserProfile\AppData\Local\Microsoft\Internet Explorer\Recovery",
                      "$UserProfile\AppData\Local\Microsoft\Feeds",
                      "$UserProfile\AppData\Local\Microsoft\Feeds Cache",
                      "$UserProfile\AppData\Roaming\Microsoft\Windows\Recent\CustomDestinations\28c8b86deab549a1.customDestinations-ms*",  # Кэш ссылок в проводнике
                      "$UserProfile\AppData\Local\Microsoft\Windows\WebCache" # WebCacheV01.dat и т.д. Заблокированные файлы процессами, процессы будут завершаться.

            if ( $Act -eq 'Set' ) { Stop-Process -Name iexplore -Force -ErrorAction SilentlyContinue }

            CleanUp-Files-Folders -Act $Act -Paths $Paths -WarningSize $MB -StopProcesses
        }
    }



    $Info = 'Настроить Windows Media Player 12'
    $Group = 'Other2-WMP12' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Принять лицензионное соглашение:" | Show-Info -Shift $L.s2 -NotIndent
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AcceptedPrivacyStatement' -Type DWord 1

        "Не добавлять файлы видео, найденные в библиотеке изображений:" | Show-Info -Shift $L.s3
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AddVideosFromPicturesLibrary' -Type DWord 0

        "Отключить автоматическое добавление музыки в библиотеку:" | Show-Info -Shift $L.s4
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AutoAddMusicToLibrary' -Type DWord 0

        "Не удалять файлы с компьютера при удалении из библиотеки:" | Show-Info -Shift $L.s5
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DeleteRemovesFromComputer' -Type DWord 0

        "Запретить автоматическую проверку лицензий защищённых файлов:" | Show-Info -Shift $L.s6
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DisableLicenseRefresh' -Type DWord 1

        "Проигрыватель уже запускался:" | Show-Info -Shift $L.s7
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'FirstRun' -Type DWord 0

        "Не сохранять оценки в файлах мультимедиа:" | Show-Info -Shift $L.s8
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'FlushRatingsToFiles' -Type DWord 0

        "Не обновлять содержимое библиотеки при первом запуске:" | Show-Info -Shift $L.s9
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'LibraryHasBeenRun' -Type DWord 1

        "Не показывать сведения о мультимедиа из Интернета и не обновлять файлы:" | Show-Info -Shift $L.s10
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'MetadataRetrieval' -Type DWord 0

        "Отключить загрузку лицензий на использование файлов мультимедиа:" | Show-Info -Shift $L.s11
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SilentAcquisition' -Type DWord 0

        "Не устанавливать автоматически часы на устройствах:" | Show-Info -Shift $L.s12
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SilentDRMConfiguration' -Type DWord 0

        "Не сохранять историю открытых файлов:" | Show-Info -Shift $L.s13
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DisableMRU' -Type DWord 1

        "Не отправлять данные об использовании проигрывателя в Microsoft:" | Show-Info -Shift $L.s14
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'UsageTracking' -Type DWord 0

        "Отключить идентификацию Windows Media Player на интернет-сайтах:" | Show-Info -Shift $L.s15
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SendUserGUID' -Type Binary 00

        "Отключить обновление Windows Media Player:" | Show-Info -Shift $L.s16
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AskMeAgain' -Type String 'No'

        "Не использовать Windows Media Player в on-line справочниках:" | Show-Info -Shift $L.s17
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'StartInMediaGuide' -Type DWord 0

        "Отключить Проигрыватель по размеру видео при запуске:" | Show-Info -Shift $L.s18
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SnapToVideoV11' -Type DWord 0

        "Не менять индекс лицензий аудио файлов:" | Show-Info -Shift $L.s19
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'MLSChangeIndexMusic' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        # Принять лицензионное соглашение
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AcceptedPrivacyStatement'

        # Не добавлять файлы видео, найденные в библиотеке изображений
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AddVideosFromPicturesLibrary'

        # Отключить автоматическое добавление музыки в библиотеку
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AutoAddMusicToLibrary'

        # Не удалять файлы с компьютера при удалении из библиотеки
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DeleteRemovesFromComputer'

        # Запретить автоматическую проверку лицензий защищённых файлов
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DisableLicenseRefresh'

        # Проигрыватель уже запускался
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'FirstRun'

        # Не сохранять оценки в файлах мультимедиа
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'FlushRatingsToFiles'

        # Не обновлять содержимое библиотеки при первом запуске
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'LibraryHasBeenRun'

        # Не показывать сведения о мультимедиа из Интернета и не обновлять файлы
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'MetadataRetrieval'

        # Отключить загрузку лицензий на использование файлов мультимедиа
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SilentAcquisition'

        # Не устанавливать автоматически часы на устройствах
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SilentDRMConfiguration'

        # Не сохранять историю открытых файлов
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'DisableMRU'

        # Не отправлять данные об использовании проигрывателя в Microsoft
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'UsageTracking'

        # Отключить идентификацию Windows Media Player на интернет-сайтах
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SendUserGUID'

        # Отключить обновление Windows Media Player
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'AskMeAgain'

        # Не использовать Windows Media Player в on-line справочниках
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'StartInMediaGuide'

        # Отключить Проигрыватель по размеру видео при запуске
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'SnapToVideoV11'

        # Дополнительная настройка
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\MediaPlayer\Preferences' -Name 'MLSChangeIndexMusic'
    }



    $Info = 'Отключить Windows Mail'
    $Group = 'Other2-WindowsMail' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Windows Mail "Отключить проверку серверов новостей почтой Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Mail' -Name 'DisableCommunities' -Type DWord 1
        # Пользователи\Адм. Шабл\Компоненты Windows\Windows Mail "Отключить проверку серверов новостей почтой Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows Mail' -Name 'DisableCommunities' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Windows Mail "Выключить приложение почта Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Mail' -Name 'ManualLaunchAllowed' -Type DWord 0
        # Пользователи\Адм. Шабл\Компоненты Windows\Windows Mail "Выключить приложение почта Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows Mail' -Name 'ManualLaunchAllowed' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Mail'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows Mail'
    }



    $Info = 'Включить NumLock на клавиатуре для всех, в том числе на Логин-Скрине'
    $Group = 'Other2-NumLock' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Если применение настроек.
        if ( $Act -eq 'Set' )
        {
            [psobject] $KeyBoard = New-Object -ComObject 'WScript.Shell'

            # Включаем NumLock, если Отключён.
            if ( -not [console]::NumberLock ) { $KeyBoard.SendKeys('{NumLock}') }
        }

        # Сброс по умолчанию
        if ( $Act -ne 'Check' )
        {
            # Не проверяется, так как меняется параметр в зависимости от параметра в .DEFAULT
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2
            Set-Reg -Do:$Act New-ItemProperty -Path 'Registry::HKU\S-1-5-18\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483650
        }
        Set-Reg -Do:$Act New-ItemProperty -Path 'Registry::HKU\S-1-5-19\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483650
        Set-Reg -Do:$Act New-ItemProperty -Path 'Registry::HKU\S-1-5-20\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483650

        # Включение по умолчанию NumLock для всех, можно: 2147483650 или 80000002, для текущего аккаунта HKCU будет выставлен результат: 2
        Set-Reg -Do:$Act New-ItemProperty -Path 'Registry::HKU\.DEFAULT\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483650
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        [psobject] $KeyBoard = New-Object -ComObject 'WScript.Shell'

        # Отключаем NumLock, если включён.
        if ( [console]::NumberLock ) { $KeyBoard.SendKeys('{NumLock}') }

        Set-Reg New-ItemProperty -Path 'HKCU:\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators'                  -Type String 2147483648
        Set-Reg New-ItemProperty -Path 'Registry::HKU\S-1-5-18\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483648
        Set-Reg New-ItemProperty -Path 'Registry::HKU\S-1-5-19\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483648
        Set-Reg New-ItemProperty -Path 'Registry::HKU\S-1-5-20\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483648
        Set-Reg New-ItemProperty -Path 'Registry::HKU\.DEFAULT\Control Panel\Keyboard' -Name 'InitialKeyboardIndicators' -Type String 2147483648
    }



    $Info = 'Отключение залипания клавиши SHIFT после 5 нажатий'
    $Group = 'Other2-StickyKeysSHIFT' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\StickyKeys' -Name 'Flags' -Type String '506'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Control Panel\Accessibility\StickyKeys' -Name 'Flags' -Type String '510'
    }



    $Info = 'Отключить Online советы в настройках'
    $Group = 'Other2-OnlineTipsSettings' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Панель управления "Разрешить онлайн советы" : Отключена
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'AllowOnlineTips' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'AllowOnlineTips'
    }



    $Info = 'Отключить отсрочку автозапуска приложений'
    $Group = 'Other2-StartupDelay' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Name 'StartupDelayInMSec' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Name 'StartupDelayInMSec' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Name 'StartupDelayInMSec'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' -Name 'StartupDelayInMSec'
    }



    $Info = 'Показывать номер ошибки на синем экране BSoD'
    $Group = 'Other2-ShowErrorBSoD' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'DisplayParameters' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'DisplayParameters'
    }



    $Info = 'Включить создание малого дампа памяти при сбоях'
    $Group = 'Other2-SmallCrashDump' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'CrashDumpEnabled' -Type DWord 3
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'CrashDumpEnabled' -Type DWord 7
    }



    $Info = "Отключить лог дампа памяти: $env:SystemDrive\DumpStack.log.tmp (2004)"
    $Group = 'Other2-DumpStackLog' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 ) # от 2004
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'EnableLogFile' -Type DWord 0

            $log = "$env:SystemDrive\DumpStack.log.tmp"
                
            if ( [System.IO.File]::Exists($log) )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                Write-Host "`n   $text`: $log" -ForegroundColor DarkGray

                if ( $Act -eq 'Set' )
                {
                    Set-Delayed-MoveDeletion -Targets $log
                }
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 ) # от 2004
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'EnableLogFile' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Не показывать уведомление "Установлено новое приложение" (Для назначения приложением по умолчанию)'
    $Group = 'Other2-NoNewAppAlert' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Проводник "Не показывать уведомление: Установлено новое приложение" : Включена
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'NoNewAppAlert' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'NoNewAppAlert'
    }



    $Info = 'Не показывать пользователю анимацию при первом входе в систему'
    $Group = 'Other2-FirstLogonAnimate' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Вход в систему "Показать анимацию при первом входе в систему " : Отключена
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableFirstLogonAnimation' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableFirstLogonAnimation'
    }



    $Info = 'Не разрешать Windows управлять моим принтером, используемым по умолчанию'
    $Group = 'Other2-DefaultPrinter' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name 'LegacyDefaultPrinterMode' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows' -Name 'LegacyDefaultPrinterMode' -Type DWord 0
    }



    $Info = 'Отключить уведомления от раскладки клавиатуры (2004)'
    $Group = 'Other2-InputSwitch' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 2004
    if ( $Groups -like $Group )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action $Act

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Microsoft.Windows.InputSwitchToastHandler' -Name 'Enabled' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action Default

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Microsoft.Windows.InputSwitchToastHandler' -Name 'Enabled'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Возврат флажка для включения автовхода в настройки netplwiz.exe (2004)'
    $Group = 'Other2-NetplwizPassword' ; $L = $Lang.$Group
    
    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 2004
    if ( $Groups -like $Group )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action $Act

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\PasswordLess\Device' -Name 'DevicePasswordLessBuildVersion' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action Default

            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\PasswordLess\Device' -Name 'DevicePasswordLessBuildVersion' -Type DWord 2
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключение размытия экрана входа в Windows (1903)'
    $Group = 'Other2-AcrylicOnLogon' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 1903
    if ( $Groups -like $Group )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            $Info | Show-Info -Shift $L.s1 -Action $Act

            # Комп\Адм. Шабл\Система\Вход в систему\ "Показывать прозрачный экран входа в систему"
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'DisableAcrylicBackgroundOnLogon' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            $Info | Show-Info -Shift $L.s1 -Action Default

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'DisableAcrylicBackgroundOnLogon'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить автозапуск для всех носителей и устройств'
    $Group = 'Other2-AutoPlayDevices' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers' -Name 'DisableAutoplay' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers' -Name 'DisableAutoplay' -Type DWord 0
    }



    $Info = 'Настроить Диспетчер задач'
    $Group = 'Other2-TaskManager' ; $L = $Lang.$Group

    # Будет настраиваться только если в не раскрытом виде, и если система RS5 x64
    if (( $Groups -like $Group ) -and ( $Act -eq 'Set' ) -and ( [System.Environment]::OSVersion.Version.Build -eq 17763 ) -and ( $is64 ))
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Stop-Process -Name Taskmgr -ErrorAction SilentlyContinue

        [string] $SubKey = 'Software\Microsoft\Windows\CurrentVersion\TaskManager'
        [byte[]] $Preferences = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\$SubKey",'Preferences',$null)

        # Проверка настроен ли диспетчер, по раскрытию его окна.
        if (( $Preferences.Count ) -and ( $Preferences[28] -eq 0 ))
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Диспетчер задач Уже настраивался" }
            Write-Host "      $text" -ForegroundColor Green
        }
        else
        {
            Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\TaskManager' -Name 'Preferences' -ErrorAction SilentlyContinue -Force
            $Preferences = $null
            Start-Process -WindowStyle Hidden -FilePath taskmgr.exe
            do
            {
                Start-Sleep -Milliseconds 100
                $Preferences = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\$SubKey",'Preferences',$null)
            }
            until ( $Preferences )
            Stop-Process -Name Taskmgr -ErrorAction SilentlyContinue

            $Preferences[28]   = 0    # Раскрыть диспетчер задач
            $Preferences[4016] = 1    # Показать журнал для всех процессов

            # Соотношение сторон и Размер (px) окна диспетчера по типу 4х3
            $Preferences[60] = 30     # По горизонтали Размер (px) Общий результат ширины с отрезками около 1050px
            $Preferences[61] = 4      # По горизонтали (+ к Размеру Количество Отрезков по 255px)
            $Preferences[64] = 15     # По Вертикали Размер (px)   Общий результат высоты с отрезками около 780px
            $Preferences[65] = 3      # По Вертикали (+ к Размеру Количество Отрезков по 255px)

            # Вкладка: Процессы (ширина колонок):
            $Preferences[116] = 60    # Имя Размер (px)
            $Preferences[117] = 1     # Имя (+ к Размеру Отрезков по 255px)
            $Preferences[228] = 77    # Состояние Размер (px)  Общий результат ширины колонки около 77px, так как отрезков нет.
            $Preferences[229] = 0     # Состояние (+ к Размеру Отрезков по 255px)

            # Вкладка: Автозагрузка (ширина колонок):
            $Preferences[964] = 86    # Имя Размер (px)
            $Preferences[965] = 1     # Имя (+ к Размеру Отрезков по 255px)

            # Вкладка: Пользователи (ширина колонок):
            $Preferences[1812] = 110  # Имя Размер (px)
            $Preferences[1813] = 1    # Имя (+ к Размеру Отрезков по 255px)

            # Вкладка: Журнал приложений (ширина колонок):
            $Preferences[2660] = 110  # Имя Размер (px)
            $Preferences[2661] = 1    # Имя (+ к Размеру Отрезков по 255px)

            $Preferences[3019] = 0    # Включить колонку Загрузки
            $Preferences[2996] = 115  # Загрузки Размер (px)
            $Preferences[2997] = 0    # Загрузки (+ к Размеру Отрезков по 255px)

            $Preferences[3075] = 0    # Включить колонку Отправки
            $Preferences[3052] = 105  # Отправки Размер (px)
            $Preferences[3053] = 0    # Отправки (+ к Размеру Отрезков по 255px)

            # Вкладка: Подробности (ширина колонок):
            $Preferences[4044] = 130  # Состояние Размер (px)
            $Preferences[4045] = 0    # Состояние (+ к Размеру Отрезков по 255px)
            $Preferences[4792] = 0    # Состояние (+ к Размеру Отрезков по 255px)
            $Preferences[4032] = 235  # Имя Размер (px)
            $Preferences[4033] = 0    # Имя (+ к Размеру Отрезков по 255px)
            $Preferences[4048] = 138  # Имя пользователя Размер (px)
            $Preferences[4049] = 0    # Имя пользователя (+ к Размеру Отрезков по 255px)
            $Preferences[4180] = 138  # Виртауализация UAC Размер (px)
            $Preferences[4181] = 0    # Виртауализация UAC (+ к Размеру Отрезков по 255px)
            $Preferences[4027] = 64   # Включение колонки Записано байт
            $Preferences[4152] = 160  # Записано байт Размер (px)
            $Preferences[4153] = 0    # Записано байт (+ к Размеру Отрезков по 255px)

            $Preferences[4029] = 4    # Включить Колонку ГПУ
            $Preferences[4200] = 40   # Колонка ГПУ Размер (px)
            $Preferences[4201] = 0    # Колонка ГПУ (+ к Размеру Отрезков по 255px)
            $Preferences[4268] = 42   # Колонка ГПУ переместить левее на 3 шага
            $Preferences[4336] = 13   # Колонка переместить память на 1 шаг в прово
            $Preferences[4364] = 30   # Колонка переместить байт   на 1 шаг в прово
            $Preferences[4384] = 37   # Колонка переместить UAC    на 1 шаг в прово

            # Вкладка: Службы (ширина колонок):
            $Preferences[4416] = 15   # Имя Размер (px)
            $Preferences[4417] = 1    # Имя (+ к Размеру Отрезков по 255px)
            $Preferences[4428] = 132  # Состояние Размер (px)
            $Preferences[4429] = 0    # Состояние (+ к Размеру Отрезков по 255px)
            $Preferences[4432] = 210  # Группа Размер (px)
            $Preferences[4433] = 0    # Группа (+ к Размеру Отрезков по 255px)

            [byte[]] $Value = $Preferences
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\TaskManager' -Name 'Preferences' -Type Binary $Value
        }
    }



    $Info = 'Удалить/восстановить Пункт индексирования в Панели Управления. Баг'
    $Group = 'Other2-ControlPanelBag' ; $L = $Lang.$Group

    if (( $Groups -like $Group ) -and $is64 )
    {
        [string] $SubKey   = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}'
        [string] $SubKey64 = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}'

        [string] $Value1 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'',$null)
        [string] $Value2 = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey64",'',$null)

        if ( $Act -eq 'Default' ) { [string] $Act2 = 'Set' } else { [string] $Act2 = $Act }

        $Info | Show-Info -Shift $L.s1 -Action $Act2

        if ( $Value2 -and ( -not $Value1 ))
        {
            "Удаление" | Show-Info -Shift $L.s2 -NotIndent

            Set-Reg -Do:$Act2 Remove-Item -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}'
        }
        elseif ( $Value1 -and ( -not $Value2 ))
        {
            "Восстановление" | Show-Info -Shift $L.s3 -NotIndent

            Set-Reg -Do:$Act2 New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace\{87D66A43-7B11-4A28-9811-C86EE395ACF7}' -Name '' -Type String 'Indexing Options'
        }
        else
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Исправление не требуется" }
            Write-Host "   $text`n" -ForegroundColor Green
        }
    }



    $Info = 'Показывать уведомление, когда компьютеру требуется перезагрузка для завершения обновления'
    $Group = 'Other2-UpdRestartNotify' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'RestartNotificationsAllowed2' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'RestartNotificationsAllowed2'
    }



    $Info = 'Отключить предварительные версии, инсайдерство + скрытие из настроек'
    $Group = 'Other2-PreviewBuilds' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Сборки для сбора данных и предварительные сборки "Переключение пользовательских элементов управления сборками для предварительной оценки"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds' -Name 'AllowBuildPreview' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\Центр обновления Windows для бизнеса "Управлять предварительными сборками"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuilds' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuildsPolicyValue' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'HideInsiderPage' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\PreviewBuilds'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuilds'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuildsPolicyValue'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'HideInsiderPage'
    }



    $Info = 'Скрыть сообщения в настройках о необходимости удаления параметров в реестре и др.'
    $Group = 'Other2-RegistryMessages' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'DiagnosticErrorText' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'DiagnosticLink' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'DiagnosticErrorText'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsSelfHost\UI\Visibility' -Name 'DiagnosticLink'
    }



    $Info = 'Скрыть рекламу Windows Update из модерн настроек'
    $Group = 'Other2-AdsInSettings' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'HideMCTLink' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'HideMCTLink'
    }



    $Info = 'Отключить Возможность использования web камеры на Лок-скрине'
    $Group = 'Other2-LockScreenCamera' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Панель управления\Персонализация "Запретить включение камеры с экрана блокировки" (включена)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization' -Name 'NoLockScreenCamera' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default
        
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Personalization' -Name 'NoLockScreenCamera'
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$InfoThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { "Необходимо перезагрузиться!" }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}