﻿
<#
.SYNOPSIS
 Настройка Контроля учетных записей (UAC).

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_UAC.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Drv для настройки драйверов, с проверкой и выводом результата.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.

.EXAMPLE
    Set-UAC -Options ForcedUAC -Act Set

    Описание
    --------
    Включить усиленный режим UAC.

.EXAMPLE
    Set-UAC -Act Default

    Описание
    --------
    Включить UAC по умолчанию.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  28-04-2019
 ===============================================

#>
Function Set-UAC {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'ForcedUAC', 'LowUAC', 'AutoAcceptUAC', 'DisableUAC' )]
        [string] $Option = 'ForcedUAC'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'UAC', 'EnableLUA', 'SecureDesktop', 'Virtualization', 'BehaviorAdmin' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( 'UAC' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\luafv'

            try { [psobject] $luafv = [Microsoft.Win32.Registry]::GetValue($Key,'Start',$null)
            } catch { [psobject] $luafv = $null }

            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            try { [psobject] $EnableLUA      = [Microsoft.Win32.Registry]::GetValue($Key,'EnableLUA',$null)
            } catch { [psobject] $EnableLUA = $null }

            try { [psobject] $SecureDesktop  = [Microsoft.Win32.Registry]::GetValue($Key,'PromptOnSecureDesktop',$null)
            } catch { [psobject] $SecureDesktop = $null }

            try { [psobject] $Virtualization = [Microsoft.Win32.Registry]::GetValue($Key,'EnableVirtualization',$null)
            } catch { [psobject] $Virtualization = $null }

            try { [psobject] $BehaviorAdmin  = [Microsoft.Win32.Registry]::GetValue($Key,'ConsentPromptBehaviorAdmin',$null)
            } catch { [psobject] $BehaviorAdmin = $null }

            if     (( 2 -eq $luafv ) -and ( 1 -eq $EnableLUA ) -and ( 1 -eq $SecureDesktop ) -and ( 1 -eq $Virtualization ) -and ( 5 -eq $BehaviorAdmin ))
            {
                "#Yellow#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "По умолчанию" })
            }
            elseif (( 2 -eq $luafv ) -and ( 1 -eq $EnableLUA ) -and ( 0 -eq $SecureDesktop ) -and ( 1 -eq $Virtualization ) -and ( 5 -eq $BehaviorAdmin ))
            {
                "#Magenta#{0} #DarkGray#| {1}#" -f $(if ( $L.s2 ) { $L.s2,$L.s2_1 } else { "Слабый режим", "Без затемнения" })
            }
            elseif (( 2 -eq $luafv ) -and ( 1 -eq $EnableLUA ) -and ( 1 -eq $SecureDesktop ) -and ( 1 -eq $Virtualization ) -and ( 2 -eq $BehaviorAdmin ))
            {
                "#Green#{0} #DarkGray#| {1}#" -f $(if ( $L.s3 ) { $L.s3,$L.s3_1 } else { "Усиленный режим", "Спрашивать для всех программ" })
            }
            elseif (( 2 -eq $luafv ) -and ( 1 -eq $EnableLUA ) -and ( 1 -eq $SecureDesktop ) -and ( 1 -eq $Virtualization ) -and ( 0 -eq $BehaviorAdmin ))
            {
                "#Magenta#{0} #DarkGray#| {1}#" -f $(if ( $L.s4 ) { $L.s4,$L.s4_1 } else { "АвтоСоглашение", "Только для Администраторов" })
            }
            elseif (( 2 -eq $luafv ) -and ( 1 -eq $EnableLUA ) -and ( 0 -eq $SecureDesktop ) -and ( 1 -eq $Virtualization ) -and ( 0 -eq $BehaviorAdmin ))
            {
                "#Magenta#{0} #DarkGray#| {1}#" -f $(if ( $L.s5 ) { $L.s5,$L.s5_1 } else { "АвтоСоглашение", "Настроен через панель управления" })
            }
            elseif (( 4 -eq $luafv ) -and ( 0 -eq $EnableLUA ) -and ( 0 -eq $SecureDesktop ) -and ( 0 -eq $Virtualization ) -and ( 0 -eq $BehaviorAdmin ))
            {
                "#Magenta#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Отключён" })
            }
            else
            {
                "#Red#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Неизвестный режим" })
            }
        }
        elseif ( 'EnableLUA' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            try { [psobject] $EnableLUA = [Microsoft.Win32.Registry]::GetValue($Key,'EnableLUA',$null)
            } catch { [psobject] $EnableLUA = $null }

            if     ( 0 -eq $EnableLUA ) { "#Magenta#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { "Не отображаются" }) }
            elseif ( 1 -eq $EnableLUA ) { "#Yellow#{0} #DarkGray#| {1}#" -f $(if ( $L.s9 ) { $L.s9,$L.s9_1 } else { "Выводятся", "По умолчанию" }) }
            else                        { "#Red#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Параметр Неверный" }) }
        }
        elseif ( 'SecureDesktop' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            try { [psobject] $SecureDesktop = [Microsoft.Win32.Registry]::GetValue($Key,'PromptOnSecureDesktop',$null)
            } catch { [psobject] $SecureDesktop = $null }

            if     ( 0 -eq $SecureDesktop ) { "#Magenta#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "Через интерактивный рабочий стол" }) }
            elseif ( 1 -eq $SecureDesktop ) { "#Yellow#{0} #DarkGray#| {1}#" -f $(if ( $L.s12 ) { $L.s12,$L.s12_1 } else { "Через безопасный рабочий стол", "По умолчанию" }) }
            else                            { "#Red#{0}#" -f $(if ( $L.s13 ) { $L.s13 } else { "Параметр Неверный" }) }
        }
        elseif ( 'Virtualization' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            try { [psobject] $Virtualization = [Microsoft.Win32.Registry]::GetValue($Key,'EnableVirtualization',$null)
            } catch { [psobject] $Virtualization = $null }

            if     ( 0 -eq $Virtualization ) { "#Magenta#{0}#" -f $(if ( $L.s14 ) { $L.s14 } else { "Отключена" }) }
            elseif ( 1 -eq $Virtualization ) { "#Yellow#{0} #DarkGray#| {1}#" -f $(if ( $L.s15 ) { $L.s15,$L.s15_1 } else { "Включена", "По умолчанию" }) }
            else                             { "#Red#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { "Параметр Неверный" }) }
        }
        elseif ( 'BehaviorAdmin' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            try { [psobject] $BehaviorAdmin = [Microsoft.Win32.Registry]::GetValue($Key,'ConsentPromptBehaviorAdmin',$null)
            } catch { [psobject] $BehaviorAdmin = $null }

            if ( $null -eq $BehaviorAdmin ) { "#Red#{0}#" -f $(if ( $L.s17 ) { $L.s17 } else { "Параметр Отсутствует" }) }
            elseif ( 0 -eq $BehaviorAdmin ) { "#Magenta#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { "Соглашаться Автоматически" }) }
            elseif ( 2 -eq $BehaviorAdmin ) { "#Green#{0} #DarkGray#| {1}#" -f $(if ( $L.s19 ) { $L.s19,$L.s19_1 } else { "Усиленный режим", "Запросы для всех программ" }) }
            elseif ( 5 -eq $BehaviorAdmin ) { "#Yellow#{0} #DarkGray#| {1}#" -f $(if ( $L.s20 ) { $L.s20,$L.s20_1 } else { "Запросы для несистемных программ", "По умолчанию" }) }
            else                            { "#DarkGray#{0}: #Yellow#$BehaviorAdmin#" -f $(if ( $L.s21 ) { $L.s21 } else { "Неизвестно" }) }
        }

        Return
    }

    $text = if ( $L.s22 ) { $L.s22 } else { "Настройка Контроля учетных записей" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Act -eq 'Default' )
    {
        $text = if ( $L.s23 ) { $L.s23 } else { "Восстановление" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s23_1 ) { $L.s23_1 } else { "Режима UAC" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s23_2 ) { $L.s23_2 } else { "По умолчанию" }
        Write-Host "| $text `n" -ForegroundColor DarkGray

        Set-Drv Set-Driver -Name 'luafv' -StartupType Automatic
        Set-Svc Set-Service -Name 'Appinfo' -StartupType Manual

        [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

        # Включить режим UAC одобрения администратором, отображать окно с запросом
        Set-Reg New-ItemProperty -Path $Path -Name 'EnableLUA' -Type DWord 1

        # Запросы на повышение прав обрабатывать через безопасный рабочий стол (с затемнением экрана)
        Set-Reg New-ItemProperty -Path $Path -Name 'PromptOnSecureDesktop' -Type DWord 1

        # Включить виртуализацию, перехват функций через драйвер luafv.sys - отслеживание чтения или записи в защищенные области системы
        Set-Reg New-ItemProperty -Path $Path -Name 'EnableVirtualization' -Type DWord 1

        # Выводить запрос на согласие для двоичных данных не из Windows для Учетных записей из группы "Администраторы"
        Set-Reg New-ItemProperty -Path $Path -Name 'ConsentPromptBehaviorAdmin' -Type DWord 5
    }
    else
    {
        if ( $Option -eq 'ForcedUAC' )
        {
            $text = if ( $L.s24 ) { $L.s24 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s24_1 ) { $L.s24_1 } else { "Усиленного режима UAC" }
            Write-Host "$text`n" -ForegroundColor White

            Set-Drv -Do:$Act Set-Driver -Name 'luafv' -StartupType Automatic
            Set-Svc -Do:$Act Set-Service -Name 'Appinfo' -StartupType Manual

            [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            # Включить режим UAC одобрения администратором, отображать окно с запросом
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableLUA' -Type DWord 1

            # Запросы на повышение прав обрабатывать через безопасный рабочий стол (с затемнением экрана)
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'PromptOnSecureDesktop' -Type DWord 1

            # Включить виртуализацию, перехват функций через драйвер luafv.sys - отслеживание чтения или записи в защищенные области системы
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableVirtualization' -Type DWord 1

            # Усиленный режим UAC. Запрос поступает для всех приложений, при доступе к системным данным, включая доверенные системные, с автовалидацией.
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ConsentPromptBehaviorAdmin' -Type DWord 2
        }
        elseif ( $Option -eq 'LowUAC' )
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s25_1 ) { $L.s25_1 } else { "Слабого режима UAC" }
            Write-Host "$text `n" -ForegroundColor White

            Set-Drv -Do:$Act Set-Driver -Name 'luafv' -StartupType Automatic
            Set-Svc -Do:$Act Set-Service -Name 'Appinfo' -StartupType Manual

            [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            # Включить режим UAC одобрения администратором, отображать окно с запросом
            Set-Reg New-ItemProperty -Path $Path -Name 'EnableLUA' -Type DWord 1

            # Выполнение запросов на повышение прав обрабатывать через интерактивный рабочий стол (без затемнения экрана)
            Set-Reg New-ItemProperty -Path $Path -Name 'PromptOnSecureDesktop' -Type DWord 0

            # Включить виртуализацию, перехват функций через драйвер luafv.sys - отслеживание чтения или записи в защищенные области системы
            Set-Reg New-ItemProperty -Path $Path -Name 'EnableVirtualization' -Type DWord 1

            # Выводить запрос на согласие для двоичных данных не из Windows для Учетных записей из группы "Администраторы"
            Set-Reg New-ItemProperty -Path $Path -Name 'ConsentPromptBehaviorAdmin' -Type DWord 5
        }
        elseif ( $Option -eq 'AutoAcceptUAC' )
        {
            $text = if ( $L.s26 ) { $L.s26 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s26_1 ) { $L.s26_1 } else { "Режима АвтоСоглашения UAC" }
            Write-Host "$text `n" -ForegroundColor White

            Set-Drv -Do:$Act Set-Driver -Name 'luafv' -StartupType Automatic
            Set-Svc -Do:$Act Set-Service -Name 'Appinfo' -StartupType Manual

            [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            # Включить режим UAC одобрения администратором, отображать окно с запросом
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableLUA' -Type DWord 1

            # Запросы на повышение прав обрабатывать через безопасный рабочий стол (с затемнением экрана)
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'PromptOnSecureDesktop' -Type DWord 1

            # Включить виртуализацию, перехват функций через драйвер luafv.sys - отслеживание чтения или записи в защищенные области системы
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableVirtualization' -Type DWord 1

            # Автоматически соглашаться на повышение прав, при запросе для Учетных записей из групп "Администраторы"
            # Запрос системе поступает, и если учетка админа, то выполняется автосоглашение на повышение прав.
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ConsentPromptBehaviorAdmin' -Type DWord 0
        }
        elseif ( $Option -eq 'DisableUAC' )
        {
            $text = if ( $L.s27 ) { $L.s27 } else { "Полное Отключение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline
            Write-Host "UAC `n" -ForegroundColor White

            Set-Drv -Do:$Act Set-Driver -Name 'luafv' -StartupType Disabled

            # Если UAC включен в любой режим, и отключить службу 'Appinfo', то права админа будет не получить!
            Set-Svc -Do:$Act Set-Service -Name 'Appinfo' -StartupType Manual

            [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System'

            # Отключить режим одобрения администратором
            # Окна с запросом повышения прав не предлагаются вообще для всех пользователей.
            # Если нет автосоглашения повышения прав, то повышения не будет.
            # Сами запросы идут, просто не отображаются пользователю.
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableLUA' -Type DWord 0

            # Выполнение запросов на повышение прав обрабатывать через интерактивный рабочий стол (без затемнения экрана)
            # не через "безопасный рабочий стол" (с затемнением экрана)
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'PromptOnSecureDesktop' -Type DWord 0

            # Отключить виртуализацию, перехват функций через драйвер luafv.sys - отслеживание чтения или записи в защищенные области системы
            # т.е. все программы получают сразу доступ к важным файлам системы и реестру. Ненужен и тормозит систему, при отключенном UAC.
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'EnableVirtualization' -Type DWord 0

            # Автоматически соглашаться на повышение прав при запросе для Учетных записей из группы "Администраторы"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ConsentPromptBehaviorAdmin' -Type DWord 0
        }
    }

    $text = if ( $L.s28 ) { $L.s28 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    Get-Pause
}
