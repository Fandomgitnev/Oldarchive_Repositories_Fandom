﻿
<#
 Функция для вывода в нужном виде переданных из других функций параметров.
 Рассчитана под ширину консоли в 120 символов.

 $Result = Пример: '--', '+', '!!!' - Полученный итоговый результат, Не найдено, Верно или Нет. Обрезка больше 3 символов.
 $Do     = Пример: 'Set', 'Check' - Что было указано сделать. Обрезка больше 5 символов.
 $Status = Пример: 'Верно', 'Неверно', 'Реальное состояние'. Обрезка больше 9 символов.
 $Type   = Пример: 'Служба', 'Задача', 'Реестр', 'ГП', 'Компонент'. Обрезка больше 9 символов.
 $Info   = Пример: 'Имя' или необходимые действия для понимания ситуации. Обрезка больше 73 символов.

 Результат: Действие: Состояние   Тип | (Команда)
   $Result:      $Do:   $Status $Type | $Info

 Пример:
 Show-Result -Result '!!!' -Do Check -Status Вкл -Type Служба -Info 'Disable: spooler - Диспетчер печати'

 Результат:
 !!!: Check:       Вкл    Служба | Disable: spooler - Диспетчер печати

 ==================================================
      Автор:  westlife (ru-board)  Версия:  1.0
       Дата:  23-10-2018
 ==================================================
#>
Function Show-Result {

    [CmdletBinding()]
    Param(
        [string] $Result = '--'
       ,[string] $Do     = '-----'
       ,[string] $Status = '-----------'
       ,[string] $Type   = '---------'
       ,[string] $Info   = '------'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction

    if ( $Result -eq '--' ) { [string] $No = '{0} | ' -f $(if ( $L.s1 ) { $L.s1 } else { 'Не найдено' }) }

    [string] $Show0 = '{0}: {1}: {2} ' -f $Result.PadLeft(3,' ').Substring(0,3),
                      $Do.PadLeft(5,' ').Substring(0,5), $Status.PadLeft(11,' ').Substring(0,11)
    [string] $Show1 = '{0} ' -f $Type.PadLeft(9,' ').Substring(0,9)
    [string] $Show2 = '| {0}{1}' -f $No, $Info

    if ( $Result -eq '!!!' )
    {
        Write-Host $Show0 -ForegroundColor Yellow -NoNewline ; Write-Host $Show1 -ForegroundColor White -NoNewline ; Write-HostColor $Show2 -ForegroundColor Gray
    }
    elseif ( $Result -eq '+' -and ( $Do -eq 'Set' -or $Do -eq 'Check' ))
    {
        Write-Host $Show0 -ForegroundColor Green  -NoNewline ; Write-Host $Show1 -ForegroundColor White -NoNewline ; Write-HostColor $Show2 -ForegroundColor DarkGray
    }
    else
    {
        Write-Host "$Show0$Show1$Show2" -ForegroundColor DarkGray
    }
}