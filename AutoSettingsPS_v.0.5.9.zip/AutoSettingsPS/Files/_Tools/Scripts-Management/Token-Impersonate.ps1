﻿
<#
.SYNOPSIS
 Олицетворение (Impersonate) себя за TrustedInstaller или SYSTEM (подключение токена от этих процессов).
 С их доступом и + дополнительно включенными у полученного токена всеми доступными для него привилегиями.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Олицетворение (Impersonate) - "Представиться другим" подменой токена.
 Это легальная возможность через WIN API.
 Нужны права администратора.
 Берется токен у процесса с необходимым доступом, и подменяется вместо токена у текущей среды.
 Текущая среда получает доступ и привилегии того процесса, оставаясь при этом в своем окружении!
 То есть раздел реестра HKCU остается доступным.

 Подмена токена (Impersonate) у текущей среды осуществляется
 без перезапуска текущего процесса, то есть на лету.
 С возможностью сброса Олицетворения.

 У Токена дополнительно включаются все возможные, но не задействованные привилегии.

 При Олицетворении в системе доступны не все действия, особенно при TrustedInstaller!
 Так как эти токены специально урезанные для разграничения доступов безопасности.
 TrustedInstaller - это права System, но со своими привилегиями и возможностями.
 Для доступа к файловой системе или реестру при любом Олицетворении работает корректно.
 При Олицетворении за TrustedInstaller нет доступа на применение SDDL и некоторые другие.

 Также закрыт доступ в некоторых случаях на изменение к WMI, например не дает доступ к CIM ресурсам через SCHTASKS,
 но через командлеты типа Enable-ScheduledTask дает.
 Настройку планировщика задач Windows можно выполнить через запуск отдельного процесса,
 с нужными правами, или получать доступ на файлы задач и/или реестр.
 Использование DISM под Impersonate также не получится, или whoami.exe и др.

 Если параметр запуска службы TrustedInstaller будет измененный,
 то он будет восстановлен "По умолчанию",
 чтобы была возможность запустить TrustedInstaller для получения его токена.

.PARAMETER Token
 Чьим токеном осуществить олицетворение.
 TI  = токен с правами TrustedInstaller. Берется у службы TrustedInstaller.
 SYS = токен с правами SYSTEM (S-1-5-18). Берется у процесса winlogon.exe.
 Токены берутся только один раз в текущей сессии, далее используются все время сохраненные в переменных.

.PARAMETER Reset
 Сброс Олицетворения, сохраняя возможность повторного олицетворения,
 мгновенно, без получения.

.EXAMPLE
    Token-Impersonate -Token SYS

    Описание
    --------
    Олицетворение текущей среды за System.
    Без вывода подробностей.


.EXAMPLE
    Token-Impersonate -Token TI -Verbose

    Описание
    --------
    Олицетворение текущей среды за TrustedInstaller.
    С выводом подробных действий.

.EXAMPLE
    Token-Impersonate -Reset

    Описание
    --------
    Сброс Олицетворения.
    Без вывода подробностей.


.NOTES
 =================================================
     Автор:  westlife (ru-board)   Версия 1.01
      Дата:  10-02-2023
 =================================================

#>
Function Token-Impersonate {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [parameter( Mandatory = $false, ParameterSetName = 'Token', Position = 0 )]
        [ValidateSet( 'TI', 'SYS' )]
        [string] $Token = 'SYS'
       ,
        [parameter( Mandatory = $true,  ParameterSetName = 'ResetToken' )]
        [switch] $Reset
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Ошибка в Begin' }
            Write-Warning "$NameThisFunction`: $text`:`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        [bool] $Exit = $false

        [string] $GetTokenAPI = @'
using System;
using System.ServiceProcess;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Security.Principal;

namespace WinAPI
{
    internal static class WinBase
    {
        [StructLayout( LayoutKind.Sequential )]
        internal struct SECURITY_ATTRIBUTES
        {
            public int nLength;
            public IntPtr lpSecurityDescriptor;
            public bool bInheritHandle;
        }

        [StructLayout( LayoutKind.Sequential, CharSet = CharSet.Unicode )]
        internal struct STARTUPINFO
        {
            public Int32 cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public uint dwX;
            public uint dwY;
            public uint dwXSize;
            public uint dwYSize;
            public uint dwXCountChars;
            public uint dwYCountChars;
            public uint dwFillAttribute;
            public uint dwFlags;
            public Int16 wShowWindow;
            public Int16 cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        [StructLayout( LayoutKind.Sequential )]
        internal struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public uint dwProcessId;
            public uint dwThreadId;
        }
    }

    internal static class WinNT
    {
        public enum TOKEN_TYPE
        {
            TokenPrimary = 1,
            TokenImpersonation
        }

        public enum SECURITY_IMPERSONATION_LEVEL
        {
            SecurityAnonymous,
            SecurityIdentification,
            SecurityImpersonation,
            SecurityDelegation
        }

        [StructLayout( LayoutKind.Sequential, Pack = 1 )]
        internal struct TokPriv1Luid
        {
            public uint PrivilegeCount;
            public long Luid;
            public UInt32 Attributes;
        }
    }

    internal static class Advapi32
    {
        public const int SE_PRIVILEGE_ENABLED = 0x00000002;
        public const uint CREATE_NO_WINDOW           = 0x08000000; // CreateProcessFlags
        public const uint CREATE_NEW_CONSOLE         = 0x00000010;
        public const uint CREATE_UNICODE_ENVIRONMENT = 0x00000400;

        public const UInt32 STANDARD_RIGHTS_REQUIRED = 0x000F0000;
        public const UInt32 STANDARD_RIGHTS_READ = 0x00020000;
        public const UInt32 TOKEN_ASSIGN_PRIMARY = 0x0001;
        public const UInt32 TOKEN_DUPLICATE = 0x0002;
        public const UInt32 TOKEN_IMPERSONATE = 0x0004;
        public const UInt32 TOKEN_QUERY = 0x0008;
        public const UInt32 TOKEN_QUERY_SOURCE = 0x0010;
        public const UInt32 TOKEN_ADJUST_PRIVILEGES = 0x0020;
        public const UInt32 TOKEN_ADJUST_GROUPS = 0x0040;
        public const UInt32 TOKEN_ADJUST_DEFAULT = 0x0080;
        public const UInt32 TOKEN_ADJUST_SESSIONID = 0x0100;
        public const UInt32 TOKEN_READ = (STANDARD_RIGHTS_READ | TOKEN_QUERY);
        public const UInt32 TOKEN_ALL_ACCESS = (
            STANDARD_RIGHTS_REQUIRED | TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE |
            TOKEN_IMPERSONATE | TOKEN_QUERY | TOKEN_QUERY_SOURCE | TOKEN_ADJUST_PRIVILEGES |
            TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT | TOKEN_ADJUST_SESSIONID
        );

        [DllImport( "advapi32.dll", SetLastError = true )]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool OpenProcessToken(
            IntPtr ProcessHandle,
            UInt32 DesiredAccess,
            out IntPtr TokenHandle
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Auto )]
        public extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            uint dwDesiredAccess,
            IntPtr lpTokenAttributes, // ref WinBase.SECURITY_ATTRIBUTES lpTokenAttributes,
            WinNT.SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            WinNT.TOKEN_TYPE TokenType,
            out IntPtr phNewToken
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Auto )]
        internal static extern bool LookupPrivilegeValue( string lpSystemName, string lpName, ref long lpLuid );

        [DllImport( "advapi32.dll", SetLastError = true )]
        internal static extern bool AdjustTokenPrivileges( IntPtr TokenHandle, bool DisableAllPrivileges, ref WinNT.TokPriv1Luid NewState,
            UInt32 Zero, IntPtr Null1, IntPtr Null2
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        public static extern bool CreateProcessAsUserW(
            IntPtr hToken,
            string lpApplicationName,
            string lpCommandLine,
            IntPtr lpProcessAttributes,   //ref WinBase.SECURITY_ATTRIBUTES lpProcessAttributes,
            IntPtr lpThreadAttributes,    //ref WinBase.SECURITY_ATTRIBUTES lpThreadAttributes,
            bool bInheritHandles,
            uint dwCreationFlags,
            IntPtr lpEnvironment,
            string lpCurrentDirectory,
            ref WinBase.STARTUPINFO lpStartupInfo,
            out WinBase.PROCESS_INFORMATION lpProcessInformation
        );

        [DllImport( "advapi32.dll", SetLastError = true )]
        public static extern bool SetTokenInformation(
            IntPtr TokenHandle, uint TokenInformationClass, ref IntPtr TokenInformation, int TokenInformationLength
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Auto )]
        public static extern bool RevertToSelf();
    }

    internal static class Kernel32
    {
        [Flags]
        public enum ProcessAccessFlags : uint
        {
            All = 0x001F0FFF,
            Terminate = 0x00000001,
            CreateThread = 0x00000002,
            VirtualMemoryOperation = 0x00000008,
            VirtualMemoryRead = 0x00000010,
            VirtualMemoryWrite = 0x00000020,
            DuplicateHandle = 0x00000040,
            CreateProcess = 0x000000080,
            SetQuota = 0x00000100,
            SetInformation = 0x00000200,
            QueryInformation = 0x00000400,
            QueryLimitedInformation = 0x00001000,
            Synchronize = 0x00100000
        }

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern IntPtr OpenProcess(ProcessAccessFlags processAccess, bool bInheritHandle, int processId);

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern bool CloseHandle(IntPtr hObject);

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern UInt32 WaitForSingleObject(IntPtr hHandle, UInt32 dwMilliseconds);

        [DllImport( "kernel32.dll", SetLastError = true )]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetExitCodeProcess(IntPtr hProcess, out UInt32 lpExitCode);

        [DllImport( "kernel32.dll", SetLastError = true )]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern bool CreatePipe(out IntPtr hReadPipe, out IntPtr hWritePipe, ref WinBase.SECURITY_ATTRIBUTES lpPipeAttributes, uint nSize);

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern bool SetHandleInformation(IntPtr hObject, uint dwMask, uint dwFlags);

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern bool ReadFile(IntPtr hFile, byte[] lpBuffer, int nNumberOfBytesToRead, ref int lpNumberOfBytesRead, IntPtr lpOverlapped/*IntPtr.Zero*/);

        [DllImport( "kernel32.dll" )]
        public static extern uint GetLastError();
    }

    internal static class Userenv
    {
        [DllImport( "userenv.dll", SetLastError = true )]
        public static extern bool CreateEnvironmentBlock(
            ref IntPtr lpEnvironment,
            IntPtr hToken,
            bool bInherit
        );
    }

    public static class ProcessConfig
    {
        public static IntPtr DuplicateTokenSYS(IntPtr hTokenSys)
        {
            IntPtr hProcess = IntPtr.Zero, hToken = IntPtr.Zero, hTokenDup = IntPtr.Zero;
            int pid = 0; string name;
            bool bSuccess, impersonate = false;

            try
            {
                if ( hTokenSys == IntPtr.Zero )
                {
                    bSuccess = RevertToRealSelf();
                    name = System.Text.Encoding.UTF8.GetString(new byte[] {87,73,78,76,79,71,79,78}); // винлогон (может быть несколько с разными сессиями)
                }
                else
                {
                    name = System.Text.Encoding.UTF8.GetString(new byte[] {84,82,85,83,84,69,68,73,78,83,84,65,76,76,69,82}); // ти (всегда с 0 сессией)
                    ServiceController controlTI = new ServiceController(name);
                    if (controlTI.Status == ServiceControllerStatus.Stopped)
                    {
                        controlTI.Start(); System.Threading.Thread.Sleep(5); controlTI.Close();
                    } // controlTI.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMilliseconds(1000)); // долговато ожидает Running даже при 1ms

                    impersonate = ImpersonateWithToken(hTokenSys);
                    if (!impersonate) { return IntPtr.Zero; }
                }

                IntPtr curSessionId = new IntPtr(Process.GetCurrentProcess().SessionId); // перенесён сюда выше для доп задержки если был запуск службы
                Process process = Array.Find(Process.GetProcessesByName(name), p => p.Id > 0);
                if ( process != null ) { pid = process.Id; } else { return IntPtr.Zero; }

                hProcess = Kernel32.OpenProcess(Kernel32.ProcessAccessFlags.All, true, pid);

                uint DesiredAccess = Advapi32.TOKEN_QUERY | Advapi32.TOKEN_DUPLICATE | Advapi32.TOKEN_ASSIGN_PRIMARY;
                bSuccess = Advapi32.OpenProcessToken(hProcess, DesiredAccess, out hToken);
                if (!bSuccess) { return IntPtr.Zero; }

                DesiredAccess = Advapi32.TOKEN_ALL_ACCESS;
                bSuccess = Advapi32.DuplicateTokenEx(hToken, DesiredAccess, IntPtr.Zero,
                    WinNT.SECURITY_IMPERSONATION_LEVEL.SecurityImpersonation, WinNT.TOKEN_TYPE.TokenPrimary, out hTokenDup);

                if (bSuccess) { bSuccess = EnableAllPrivilages(hTokenDup); }
                if (!impersonate) { hTokenSys = hTokenDup; impersonate = ImpersonateWithToken(hTokenSys); }
                if (impersonate)
                {   //  TOKEN_INFORMATION_CLASS TokenSessionId = 12; Marshal.SizeOf(UInt32 MaxValue: 0xFFFFFFFF, 4 294 967 295) на x86/x64 = 4
                    bSuccess = Advapi32.SetTokenInformation(hTokenDup, 12, ref curSessionId, 4);
                }
            }
            catch (Exception) {}
            finally
            {
                if (hProcess != IntPtr.Zero) { Kernel32.CloseHandle(hProcess); }
                if (hToken   != IntPtr.Zero) { Kernel32.CloseHandle(hToken);   }
                bSuccess = RevertToRealSelf(); // Console.WriteLine("Revert");
            }

            if ( hTokenDup != IntPtr.Zero ) { return hTokenDup; }
            else { return IntPtr.Zero; }
        }

        public static bool RevertToRealSelf()
        {
            try
            {
                Advapi32.RevertToSelf();
                WindowsImpersonationContext currentImpersonate = WindowsIdentity.GetCurrent().Impersonate();
                currentImpersonate.Undo();
                currentImpersonate.Dispose();
            }
            catch (Exception) { return false; }

            return true;
        }

        public static bool ImpersonateWithToken(IntPtr hTokenSys)
        {
            try
            {
                WindowsImpersonationContext ImpersonateSys = new WindowsIdentity(hTokenSys).Impersonate();
            }
            catch (Exception) { return false; }

            return true;
        }

        private enum PrivilegeNames { SeAssignPrimaryTokenPrivilege, SeBackupPrivilege, SeIncreaseQuotaPrivilege, SeLoadDriverPrivilege,
                                      SeManageVolumePrivilege, SeRestorePrivilege, SeSecurityPrivilege, SeShutdownPrivilege, SeSystemEnvironmentPrivilege,
                                      SeSystemTimePrivilege, SeTakeOwnershipPrivilege, SeTrustedCredmanAccessPrivilege, SeUndockPrivilege };

        private static bool EnableAllPrivilages(IntPtr hTokenSys)
        {
            WinNT.TokPriv1Luid tp; // newTokenPrivlege
            tp.PrivilegeCount = 1;
            tp.Luid = 0;
            tp.Attributes = Advapi32.SE_PRIVILEGE_ENABLED;
            bool bSuccess = false;

            try
            {
                foreach (string privilege in Enum.GetNames(typeof(PrivilegeNames)))
                {
                    bSuccess = Advapi32.LookupPrivilegeValue( null, privilege, ref tp.Luid );
                    bSuccess = Advapi32.AdjustTokenPrivileges( hTokenSys, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero );
                }
            }
            catch (Exception) { return false; }

            return bSuccess;
        }

        public static StructOut CreateProcessWithTokenSys(IntPtr hTokenSys, string AppPath, string Arguments, string CurrentDirectory,
            string Title, bool NoWindow, bool Wait, uint waitMs, bool WaitAndKill = false, UInt16 StdOutEnc = 0, bool Verbose = false)
        {
            uint exitCode = 0;
            bool bSuccess;
            bool bInherit = false;
            string stdOutString = "";
            IntPtr hReadOut = IntPtr.Zero, hWriteOut = IntPtr.Zero;
            const uint HANDLE_FLAG_INHERIT  = 0x00000001;
            const uint STARTF_USESTDHANDLES = 0x00000100;
            const UInt32 INFINITE = 0xFFFFFFFF; // (UInt32 MaxValue) 4 294 967 295
            // const UInt32 WAIT_OBJECT_0  = 0x00000000; // waitResult: 0 = дождался (хорошо) или был закрыт вручную
            // const UInt32 WAIT_ABANDONED = 0x00000080; // waitResult: 128 + 1 = 129 (упало приложение)
            // const UInt32 WAIT_TIMEOUT   = 0x00000102; // waitResult: 258 + 1 = 259 (вышло время)

            IntPtr NewEnvironment = IntPtr.Zero;
            bSuccess = Userenv.CreateEnvironmentBlock( ref NewEnvironment, hTokenSys, true );

            uint CreationFlags = Advapi32.CREATE_UNICODE_ENVIRONMENT;
            if (NoWindow || StdOutEnc > 0) { CreationFlags |= Advapi32.CREATE_NO_WINDOW;   }
            else                           { CreationFlags |= Advapi32.CREATE_NEW_CONSOLE; }

            WinBase.PROCESS_INFORMATION pi = new WinBase.PROCESS_INFORMATION();
            WinBase.STARTUPINFO si = new WinBase.STARTUPINFO();
            si.cb = Marshal.SizeOf(si);
            si.lpDesktop = "winsta0\\default";
            if (Title != "") { si.lpTitle = Title; }
            if (CurrentDirectory == "") { CurrentDirectory = null; }
            if (Arguments == "") { Arguments = AppPath; AppPath = null; }
            if (Wait && waitMs == 0) { waitMs = INFINITE; }  // бесконечно ждать

            try
            {
                if ( StdOutEnc > 0 )
                {
                    bInherit = true;
                    WinBase.SECURITY_ATTRIBUTES saAttr = new WinBase.SECURITY_ATTRIBUTES();
                    saAttr.nLength = Marshal.SizeOf(saAttr);
                    saAttr.bInheritHandle = true;
                    saAttr.lpSecurityDescriptor = IntPtr.Zero;

                    bSuccess = Kernel32.CreatePipe(out hReadOut, out hWriteOut, ref saAttr, 8192); // обязательный min 8161 символов и предел чтения за раз при любом размере
                    Kernel32.SetHandleInformation(hReadOut, HANDLE_FLAG_INHERIT, 0);
                    si.dwFlags = STARTF_USESTDHANDLES;
                    si.hStdOutput = hWriteOut;
                }

                bSuccess = ImpersonateWithToken(hTokenSys);

                if (Verbose) { Console.Write("Starting App: '" + AppPath + "'\nArg: '" + Arguments + "'\nDir: '" + CurrentDirectory + "'\nResult: "); };

                bSuccess = Advapi32.CreateProcessAsUserW( hTokenSys, AppPath, Arguments, IntPtr.Zero, IntPtr.Zero, bInherit,
                    (uint)CreationFlags, NewEnvironment, CurrentDirectory, ref si, out pi );

                if (Verbose) { Console.WriteLine(bSuccess + ""); };

                uint waitResult = 0;
                if (bSuccess)
                {
                    if (Wait)
                    {
                        waitResult = Kernel32.WaitForSingleObject(pi.hProcess, waitMs);   // ожидание завершения: 0 = по сути не ждёт;
                        if (WaitAndKill && waitResult > 0) { bSuccess = Kernel32.TerminateProcess(pi.hProcess, 100); }   // exitCode = 100 если не дождался и убило процесс
                        bSuccess = Kernel32.GetExitCodeProcess(pi.hProcess, out exitCode);   // Console.WriteLine("bSuccess: {0}", bSuccess);
                    }

                    if ( StdOutEnc > 0 )
                    {
                        int BUFSIZE = 8192; // max out 8161
                        byte[] buf = new byte[BUFSIZE];
                        int dwRead = 0;

                        if (hWriteOut != IntPtr.Zero) { Kernel32.CloseHandle(hWriteOut); }
                        bSuccess = Kernel32.ReadFile( hReadOut, buf, BUFSIZE, ref dwRead, IntPtr.Zero );
                        // Console.WriteLine("Error: {0}", Kernel32.GetLastError()); // ERROR_BROKEN_PIPE (109)
                        if (hReadOut != IntPtr.Zero) { Kernel32.CloseHandle(hReadOut); }

                        System.Text.Encoding enc;
                        try { enc = System.Text.Encoding.GetEncoding(StdOutEnc); } catch (Exception) { enc = System.Text.Encoding.GetEncoding(0); StdOutEnc = (ushort)enc.CodePage; }
                        stdOutString = enc.GetString(buf, 0, dwRead);

                        if (Verbose) { Console.WriteLine("StdOutEnc: " + StdOutEnc + " | Symbols: " + dwRead); };
                    }
                }
                else { exitCode = 1; }
                if (Verbose) { Console.WriteLine("Wait: " + Wait + " | WaitMs: " + waitMs + " | WaitRes: " + waitResult + " | ExitCode: " + exitCode); };
            }
            catch (Exception) {}
            finally
            {
                if (pi.hProcess != IntPtr.Zero) { Kernel32.CloseHandle(pi.hProcess); }
                if (pi.hThread  != IntPtr.Zero) { Kernel32.CloseHandle(pi.hThread);  }
                bSuccess = RevertToRealSelf();
            }

            StructOut so = new StructOut();
            so.ProcessId = pi.dwProcessId;
            so.ExitCode  = exitCode;
            so.StdOut    = stdOutString;

            return so;
        }

        [StructLayout( LayoutKind.Sequential, CharSet = CharSet.Unicode )]
        public struct StructOut
        {
            public uint ProcessId;
            public uint ExitCode;
            public string StdOut;
        }
    }
}
'@
        if ( -not ( 'WinAPI.ProcessConfig' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new(@('System.dll','System.ServiceProcess.dll'))
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $GetTokenAPI -Language CSharp -ErrorAction Stop -CompilerParameters $cp
        }

        # Если указан Cброс Олицетворения.
        if ( $Reset )
        {
            # Если олцетворение уже выполнено.
            if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -eq 'Impersonation' )
            {
                Write-Verbose 'Сбрасываем Олицетворение'

                [WinAPI.ProcessConfig]::RevertToRealSelf() > $null

                if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -eq 'Impersonation' )
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка, Олицетворение не сброшено!' }
                    Write-Warning "$text"

                    $Exit = $true ; Return
                }
                else { Write-Verbose 'Сброшено' }
            }
            else { Write-Verbose 'Сброс Олицетворения не требуется' }

            $Exit = $true ; Return  # Выходим из функции.
        }

        # Если не получена еще идентификация от системы, то получаем токен системы у процесса winlogon.exe,
        # и глобальную переменную, с его токеном.
        # Токен TrustedInstaller можно получить только с Олицетворением за систему, так как только у системы есть необходимые для этого привилегии.
        if ( -not ( $Global:Token_SYS -as [IntPtr] ))
        {
            Write-Verbose 'Получаем дубликат токена от SYSTEM (winlogon)'

            $Global:Token_SYS = [WinAPI.ProcessConfig]::DuplicateTokenSYS([System.IntPtr]::Zero)

            if ( $Global:Token_SYS -eq [IntPtr]::Zero )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { 'Ошибка получения дубликата токена от SYSTEM (winlogon)!' }
                Write-Warning "$NameThisFunction`: $text"

                $Exit = $true ; Return
            }
        }

        # Если указано получить токен от TrustedInstaller.
        if ( $Token -eq 'TI' )
        {
            if ( -not ( $Global:Token_TI -as [IntPtr] ))
            {
                Write-Verbose 'Получаем дубликат токена от TrustedInstaller'

                [string] $SubKey = 'SYSTEM\CurrentControlSet\Services\TrustedInstaller'

                [int] $StartType = 0

                # Получаем параметр типа запуска у службы TrustedInstaller (Установщик модулей Windows).
                try { $StartType = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'Start',$null) } catch {}

                # Если параметр запуска не является 2 (Авто) или 3 (Вручную).
                if (( 3 -ne $StartType ) -and ( 2 -ne $StartType ))
                {
                    Write-Verbose 'Устанавливаем тип запуска у службы TrustedInstaller ''Вручную'' (По умолчанию)'

                    [WinAPI.ProcessConfig]::ImpersonateWithToken($Global:Token_SYS) > $null

                    # Восстанавливаем доступ по умолчанию.
                    try { $OpenSubKeyTI = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree', 'TakeOwnership') }
                    catch { $OpenSubKeyTI = $null }

                    if ( $OpenSubKeyTI )
                    {
                        $AclTI = [System.Security.AccessControl.RegistrySecurity]::new()
                        $AclTI.SetOwner([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')
                        $AclTI.SetGroup([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')

                        try
                        {
                            $OpenSubKeyTI.SetAccessControl($AclTI)
                            $AclTI.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;KA;;;SY)(A;CIIO;GA;;;SY)(A;;KR;;;BA)(A;CIIO;GXGR;;;BA)(A;;KR;;;BU)(A;CIIO;GXGR;;;BU)')
                            $OpenSubKeyTI.SetAccessControl($AclTI)
                        }
                        catch {}

                        # Задаем параметр запуска по умолчанию.
                        try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree') }
                        catch { [psobject] $OpenSubkey = $null }

                        if ( $OpenSubkey )
                        {
                            $OpenSubkey.SetValue('Start',3,'Dword')

                            $OpenSubkey.Close()
                        }

                        $OpenSubKeyTI.Close()
                    }
                }

                $Global:Token_TI = [WinAPI.ProcessConfig]::DuplicateTokenSYS($Global:Token_SYS)

                if ( $Global:Token_TI -eq [IntPtr]::Zero )
                {
                    $text = if ( $L.s4 ) { $L.s4 } else { 'Ошибка получения дубликата токена от TrustedInstaller!' }
                    Write-Warning "$NameThisFunction`: $text"

                    $Exit = $true ; Return
                }
            }
        }
    }

    Process
    {
        # Перехват ошибок в блоке Process, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s5 ) { $L.s5 } else { 'Ошибка в Process' }
            Write-Warning "$NameThisFunction`: $text`:`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выход из функции, если была установлена переменная $Exit в блоке Begin.
        if ( $Exit ) { Return }

        if ( $Token -eq 'SYS' )
        {
            Write-Verbose 'Олицетворяем себя за SYSTEM'

            [WinAPI.ProcessConfig]::ImpersonateWithToken($Global:Token_SYS) > $null

            [PSObject] $isCurrentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()

            if (( $isCurrentIdentity.ImpersonationLevel -eq 'Impersonation' ) -and ( $isCurrentIdentity.IsSystem ) -and ( $isCurrentIdentity.Groups.Value.Count -eq 3 ))
            {
                Write-Verbose 'Выполнено Олицетворение себя за SYSTEM'
            }
            else
            {
                $text = if ( $L.s6 ) { $L.s6 } else { 'Ошибка. Олицетворение себя за SYSTEM НЕ выполнено!' }
                Write-Warning "$NameThisFunction`: $text"
            }
        }
        elseif ( $Token -eq 'TI'  )
        {
            Write-Verbose 'Олицетворяем себя за TrustedInstaller'

            [WinAPI.ProcessConfig]::ImpersonateWithToken($Global:Token_TI) > $null

            [PSObject] $isCurrentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()

            if (( $isCurrentIdentity.ImpersonationLevel -eq 'Impersonation' ) -and ( $isCurrentIdentity.IsSystem ) -and ( $isCurrentIdentity.Groups.Value -like 'S-1-5-80*' ))
            {
                Write-Verbose 'Выполнено Олицетворение себя за TrustedInstaller'
            }
            else
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Ошибка, Олицетворение себя за TrustedInstaller НЕ выполнено!' }
                Write-Warning "$NameThisFunction`: $text"
            }
        }
    }
}
