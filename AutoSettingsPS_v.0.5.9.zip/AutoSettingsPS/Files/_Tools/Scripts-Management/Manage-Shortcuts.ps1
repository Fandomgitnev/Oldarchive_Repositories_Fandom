﻿
<#
.SYNOPSIS
 Создание ярлыков к файлам, папкам, ссылкам или UWP

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 С поддержкой добавления Hash для Win+X меню

 [hashtable] $CreateLnk = @{
     lnkPath     = '%SystemDrive%\SystemSettings-Colors.lnk'  # String (Mandatory: (Mandatory) Folder path or FullPath)
     targetPath  = 'ms-settings:personalization-colors'       # String (Mandatory: File, folder, Link or UWP) (Affect on Hash)

     arguments   = $null    # $null/String (Affect on Hash)
     iconPath    = '%WinDir%\ImmersiveControlPanel\SystemSettings.exe' # $null/String (full path to the icon file: exe,ico)
     workingDir  = $null    # $null/String
     description = 'Colors' # $null/String
     windowStyle = $null    # $null/'SHOWNORMAL'/'SHOWMAXIMIZED'/'SHOWMINNOACTIVE'
     elevate     = $null    # $null/$false/$true (Set RunAsAdmin)
     WinxHash    = $null    # $null/$false/$true (Add WinX hash)
     NoTrack     = $null    # $null/$false/$true (Not add tracking/telemetry data)
     NoRelative  = $null    # $null/$false/$true (Not add Relative path), не будет его, если только путь не прямой: начинается с %SystemRoot% и т.д.
 }

.EXAMPLE

    Manage-Shortcuts -CreateLnk $CreateLnk
    Manage-Shortcuts -AddWinxHash    "C:\Shortcut.lnk"
    Manage-Shortcuts -ElevateEnable  "C:\Shortcut.lnk"
    Manage-Shortcuts -ElevateDisable "C:\Shortcut.lnk"

    Manage-Shortcuts -GetComment     "C:\Shortcut.lnk"
    Manage-Shortcuts -GetLocalizedName '%windir%\explorer.exe,-22001'

.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  24-04-2023
 =================================================

#>
Function Manage-Shortcuts {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string])]
    Param(
        [Parameter( Mandatory = $false, ParameterSetName = 'CreateLnk' )]
        [PSObject] $CreateLnk # [hashtable]
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'AddWinxHash' )]
        [string] $AddWinxHash
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'ElevateEnable' )]
        [string] $ElevateEnable
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'ElevateDisable' )]
        [string] $ElevateDisable
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'GetComment' )]
        [string] $GetComment
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'LocalizedName' )]
        [string] $GetLocalizedName
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name
    [PSObject] $Err = " $NameThisFunction`: Skip"

    $Shortcut = @'
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Text.RegularExpressions;

namespace WinAPI
{
    public class Shortcut
    {
        /// Получение параметров из файла ярлыка
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
        private static extern void SHCreateItemFromParsingName(
            [In][MarshalAs(UnmanagedType.LPWStr)] string pszPath,
            [In] IntPtr pbc,
            [In][MarshalAs(UnmanagedType.LPStruct)] Guid riid,
            [Out][MarshalAs(UnmanagedType.Interface, IidParameterIndex = 2)] out IShellItem2 ppv
        );

        /// Получение и изменение propertyStore в файлах ярлыков
        [DllImport("shell32.dll", CharSet = CharSet.Unicode, SetLastError=true)]
        private static extern void SHGetPropertyStoreFromParsingName(
            [In] [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
            IntPtr zeroWorks,
            GPS flags, // GETPROPERTYSTOREFLAGS
            ref Guid riid,
            [Out] out IPropertyStore propertyStore
        );

        /// стандарная генерация хэша
        [DllImport("shlwapi.dll", CharSet = CharSet.Unicode, ExactSpelling = true, SetLastError = true)]
        private static extern int HashData(
            [In, MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.U1, SizeParamIndex = 1)] byte[] pbData,
            int cbData,
            [Out, MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.U1, SizeParamIndex = 3)] byte[] pbHash,
            int cbHash
        );

        [StructLayout(LayoutKind.Sequential)]
        private struct PROPERTYKEY
        {
            public Guid formatId;
            public int propertyId;

            public PROPERTYKEY(string formatId, int propertyId)
            {
                this.formatId = new Guid(formatId);
                this.propertyId = propertyId;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct PROPVARIANT
        {
            public short variantType;
            public short Reserved1, Reserved2, Reserved3;
            public IntPtr pointerValue;
        }

        [ComImport]
        [Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IPropertyStore
        {
            [PreserveSig]
            int GetCount([Out] out uint cProps);
            [PreserveSig]
            int GetAt([In] uint iProp, out PROPERTYKEY pkey);
            [PreserveSig]
            int GetValue([In] ref PROPERTYKEY key, out PROPVARIANT pv); // [SecurityCritical]
            [PreserveSig]
            int SetValue([In] ref PROPERTYKEY key, [In] ref PROPVARIANT pv); // [SecurityCritical]
            [PreserveSig]
            int Commit();
        }

        [ComImportAttribute()]
        [GuidAttribute("45e2b4ae-b1c3-11d0-b92f-00a0c90312e1")]
        [InterfaceTypeAttribute(ComInterfaceType.InterfaceIsIUnknown)]
        private interface IShellLinkDataList
        {
            void AddDataBlock(IntPtr pDataBlock);
            void CopyDataBlock(uint dwSig, out IntPtr ppDataBlock);
            void RemoveDataBlock(uint dwSig);
            void GetFlags(out uint pdwFlags);
            void SetFlags(uint dwFlags);
        }

        private enum GPS
        {
            DEFAULT = 0x00000000,
            HANDLERPROPERTIESONLY = 0x00000001,   // only include properties directly from the file's property handler
            READWRITE = 0x00000002,   // Writable stores will only include handler properties
            TEMPORARY = 0x00000004,   // A read/write store that only holds properties for the lifetime of the IShellItem object
            FASTPROPERTIESONLY = 0x00000008,   // do not include any properties from the file's property handler (because the file's property handler will hit the disk)
            OPENSLOWITEM = 0x00000010,   // include properties from a file's property handler, even if it means retrieving the file from offline storage.
            DELAYCREATION = 0x00000020,   // delay the creation of the file's property handler until those properties are read, written, or enumerated
            BESTEFFORT = 0x00000040,   // For readonly stores, succeed and return all available properties, even if one or more sources of properties fails. Not valid with GPS.READWRITE.
            NO_OPLOCK = 0x00000080,   // some data sources protect the read property store with an oplock, this disables that
            MASK_VALID = 0x000000FF
        }

        [Flags()]
        private enum SLGP_FLAGS
        {
            /// Retrieves the standard short (8.3 format) file name
            SLGP_SHORTPATH = 0x1,
            /// Retrieves the Universal Naming Convention (UNC) path name of the file
            SLGP_UNCPRIORITY = 0x2,
            /// Retrieves the raw path name. A raw path is something that might not exist and may include environment variables that need to be expanded
            SLGP_RAWPATH = 0x4
        }

        [Flags()]
        private enum SLR_FLAGS
        {
            /// Do not display a dialog box if the link cannot be resolved. When SLR_NO_UI is set,
            /// the high-order word of fFlags can be set to a time-out value that specifies the
            /// maximum amount of time to be spent resolving the link. The function returns if the
            /// link cannot be resolved within the time-out duration. If the high-order word is set
            /// to zero, the time-out duration will be set to the default value of 3,000 milliseconds
            /// (3 seconds). To specify a value, set the high word of fFlags to the desired time-out
            /// duration, in milliseconds.
            SLR_NO_UI = 0x1,

            /// Obsolete and no longer used
            SLR_ANY_MATCH = 0x2,

            /// If the link object has changed, update its path and list of identifiers.
            /// If SLR_UPDATE is set, you do not need to call IPersistFile::IsDirty to determine
            /// whether or not the link object has changed.
            SLR_UPDATE = 0x4,

            /// Do not update the link information
            SLR_NOUPDATE = 0x8,

            /// Do not execute the search heuristics
            SLR_NOSEARCH = 0x10,

            /// Do not use distributed link tracking
            SLR_NOTRACK = 0x20,

            /// Disable distributed link tracking. By default, distributed link tracking tracks
            /// removable media across multiple devices based on the volume name. It also uses the
            /// Universal Naming Convention (UNC) path to track remote file systems whose drive letter
            /// has changed. Setting SLR_NOLINKINFO disables both types of tracking.
            SLR_NOLINKINFO = 0x40,

            /// Call the Microsoft Windows Installer
            SLR_INVOKE_MSI = 0x80
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct FILETIME
        {
            public UInt32 dwLowDateTime;
            public UInt32 dwHighDateTime;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct WIN32_FIND_DATAW
        {
            public UInt32 dwFileAttributes;
            public FILETIME ftCreationTime;
            public FILETIME ftLastAccessTime;
            public FILETIME ftLastWriteTime;
            public UInt32 nFileSizeHigh;
            public UInt32 nFileSizeLow;
            public UInt32 dwReserved0;
            public UInt32 dwReserved1;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            public string cFileName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
            public string cAlternateFileName;
        }

        /// SHELLITEMCOMPAREHINTF.  SICHINT_*.
        private enum SICHINT : uint
        {
            DISPLAY = 0x00000000,   /// <summary>iOrder based on display in a folder view</summary>
            ALLFIELDS = 0x80000000, /// <summary>exact instance compare</summary>
            CANONICAL = 0x10000000, /// <summary>iOrder based on canonical name (better performance)</summary>
            TEST_FILESYSPATH_IF_NOT_EQUAL = 0x20000000,
        };

        /// ShellItem enum.  SIGDN_*.
        private enum SIGDN : uint
        {                                             // lower word (& with 0xFFFF)
            NORMALDISPLAY = 0x00000000, // SHGDN_NORMAL
            PARENTRELATIVEPARSING = 0x80018001, // SHGDN_INFOLDER | SHGDN_FORPARSING
            DESKTOPABSOLUTEPARSING = 0x80028000, // SHGDN_FORPARSING
            PARENTRELATIVEEDITING = 0x80031001, // SHGDN_INFOLDER | SHGDN_FOREDITING
            DESKTOPABSOLUTEEDITING = 0x8004c000, // SHGDN_FORPARSING | SHGDN_FORADDRESSBAR
            FILESYSPATH = 0x80058000, // SHGDN_FORPARSING
            URL = 0x80068000, // SHGDN_FORPARSING
            PARENTRELATIVEFORADDRESSBAR = 0x8007c001, // SHGDN_INFOLDER | SHGDN_FORPARSING | SHGDN_FORADDRESSBAR
            PARENTRELATIVE = 0x80080001, // SHGDN_INFOLDER
        }

        /// IShellFolder::GetAttributesOf flags
        [Flags]
        private enum SFGAO : uint
        {
            /// <summary>Objects can be copied</summary>
            /// <remarks>DROPEFFECT_COPY</remarks>
            CANCOPY = 0x1,
            /// <summary>Objects can be moved</summary>
            /// <remarks>DROPEFFECT_MOVE</remarks>
            CANMOVE = 0x2,
            /// <summary>Objects can be linked</summary>
            /// <remarks>
            /// DROPEFFECT_LINK.
            ///
            /// If this bit is set on an item in the shell folder, a
            /// 'Create Shortcut' menu item will be added to the File
            /// menu and context menus for the item.  If the user selects
            /// that command, your IContextMenu::InvokeCommand() will be called
            /// with 'link'.
            /// That flag will also be used to determine if 'Create Shortcut'
            /// should be added when the item in your folder is dragged to another
            /// folder.
            /// </remarks>
            CANLINK = 0x4,
            /// <summary>supports BindToObject(IID_IStorage)</summary>
            STORAGE = 0x00000008,
            /// <summary>Objects can be renamed</summary>
            CANRENAME = 0x00000010,
            /// <summary>Objects can be deleted</summary>
            CANDELETE = 0x00000020,
            /// <summary>Objects have property sheets</summary>
            HASPROPSHEET = 0x00000040,

            // unused = 0x00000080,

            /// <summary>Objects are drop target</summary>
            DROPTARGET = 0x00000100,
            CAPABILITYMASK = 0x00000177,
            // unused = 0x00000200,
            // unused = 0x00000400,
            // unused = 0x00000800,
            // unused = 0x00001000,
            /// <summary>Object is encrypted (use alt color)</summary>
            ENCRYPTED = 0x00002000,
            /// <summary>'Slow' object</summary>
            ISSLOW = 0x00004000,
            /// <summary>Ghosted icon</summary>
            GHOSTED = 0x00008000,
            /// <summary>Shortcut (link)</summary>
            LINK = 0x00010000,
            /// <summary>Shared</summary>
            SHARE = 0x00020000,
            /// <summary>Read-only</summary>
            READONLY = 0x00040000,
            /// <summary> Hidden object</summary>
            HIDDEN = 0x00080000,
            DISPLAYATTRMASK = 0x000FC000,
            /// <summary> May contain children with SFGAO_FILESYSTEM</summary>
            FILESYSANCESTOR = 0x10000000,
            /// <summary>Support BindToObject(IID_IShellFolder)</summary>
            FOLDER = 0x20000000,
            /// <summary>Is a win32 file system object (file/folder/root)</summary>
            FILESYSTEM = 0x40000000,
            /// <summary>May contain children with SFGAO_FOLDER (may be slow)</summary>
            HASSUBFOLDER = 0x80000000,
            CONTENTSMASK = 0x80000000,
            /// <summary>Invalidate cached information (may be slow)</summary>
            VALIDATE = 0x01000000,
            /// <summary>Is this removeable media?</summary>
            REMOVABLE = 0x02000000,
            /// <summary> Object is compressed (use alt color)</summary>
            COMPRESSED = 0x04000000,
            /// <summary>Supports IShellFolder, but only implements CreateViewObject() (non-folder view)</summary>
            BROWSABLE = 0x08000000,
            /// <summary>Is a non-enumerated object (should be hidden)</summary>
            NONENUMERATED = 0x00100000,
            /// <summary>Should show bold in explorer tree</summary>
            NEWCONTENT = 0x00200000,
            /// <summary>Obsolete</summary>
            CANMONIKER = 0x00400000,
            /// <summary>Obsolete</summary>
            HASSTORAGE = 0x00400000,
            /// <summary>Supports BindToObject(IID_IStream)</summary>
            STREAM = 0x00400000,
            /// <summary>May contain children with SFGAO_STORAGE or SFGAO_STREAM</summary>
            STORAGEANCESTOR = 0x00800000,
            /// <summary>For determining storage capabilities, ie for open/save semantics</summary>
            STORAGECAPMASK = 0x70C50008,
            /// <summary>
            /// Attributes that are masked out for PKEY_SFGAOFlags because they are considered
            /// to cause slow calculations or lack context
            /// (SFGAO_VALIDATE | SFGAO_ISSLOW | SFGAO_HASSUBFOLDER and others)
            /// </summary>
            PKEYSFGAOMASK = 0x81044000,
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("43826d1e-e718-42ee-bc55-a1e261c37bfe")]
        private interface IShellItem
        {
            [return: MarshalAs(UnmanagedType.Interface)]
            object BindToHandler(IBindCtx pbc, [In] ref Guid bhid, [In] ref Guid riid);

            IShellItem GetParent();

            [return: MarshalAs(UnmanagedType.LPWStr)]
            string GetDisplayName(SIGDN sigdnName);

            SFGAO GetAttributes(SFGAO sfgaoMask);

            int Compare(IShellItem psi, SICHINT hint);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("7e9fb0d3-919f-4307-ab2e-9b1860310c93")]
        private interface IShellItem2 : IShellItem
        {
            #region IShellItem redeclarations
            [return: MarshalAs(UnmanagedType.Interface)]
            new object BindToHandler([In] IBindCtx pbc, [In] ref Guid bhid, [In] ref Guid riid);
            new IShellItem GetParent();
            [return: MarshalAs(UnmanagedType.LPWStr)]
            new string GetDisplayName(SIGDN sigdnName);
            new SFGAO GetAttributes(SFGAO sfgaoMask);
            new int Compare(IShellItem psi, SICHINT hint);
            #endregion

            [return: MarshalAs(UnmanagedType.Interface)]
            object GetPropertyStore(
                GPS flags,
                [In] ref Guid riid);

            [return: MarshalAs(UnmanagedType.Interface)]
            object GetPropertyStoreWithCreateObject(
                GPS flags,
                [MarshalAs(UnmanagedType.IUnknown)] object punkCreateObject,   // factory for low-rights creation of type ICreateObject
                [In] ref Guid riid);

            [return: MarshalAs(UnmanagedType.Interface)]
            object GetPropertyStoreForKeys(
                IntPtr rgKeys,
                uint cKeys,
                GPS flags,
                [In] ref Guid riid);

            [return: MarshalAs(UnmanagedType.Interface)]
            object GetPropertyDescriptionList(
                IntPtr keyType,
                [In] ref Guid riid);

            // Ensures any cached information in this item is up to date, or returns __HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND) if the item does not exist.
            void Update(IBindCtx pbc);

            /// <SecurityNote>
            ///   Critical : Calls critical methods
            /// <SecurityNote>
            ///[SecurityCritical] using System.Security;
            PROPVARIANT GetProperty(IntPtr key);

            Guid GetCLSID(IntPtr key);

            FILETIME GetFileTime(IntPtr key);

            int GetInt32(IntPtr key);

            [return: MarshalAs(UnmanagedType.LPWStr)]
            string GetString(PROPERTYKEY key);

            uint GetUInt32(IntPtr key);

            ulong GetUInt64(IntPtr key);

            [return: MarshalAs(UnmanagedType.Bool)]
            void GetBool(IntPtr key);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("000214F9-0000-0000-C000-000000000046")]
        private interface IShellLink
        {
            /// Retrieves the path and file name of a Shell link object
            void GetPath([Out(), MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszFile, int cchMaxPath, out WIN32_FIND_DATAW pfd, SLGP_FLAGS fFlags);

            /// Retrieves the list of item identifiers for a Shell link object
            void GetIDList(out IntPtr ppidl);
            /// Sets the pointer to an item identifier list (PIDL) for a Shell link object.
            void SetIDList(IntPtr pidl);

            /// Retrieves the description string for a Shell link object
            void GetDescription([Out(), MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxName);
            /// Sets the description for a Shell link object. The description can be any application-defined string
            void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);

            /// Retrieves the name of the working directory for a Shell link object
            void GetWorkingDirectory([Out(), MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszDir, int cchMaxPath);
            /// Sets the name of the working directory for a Shell link object
            void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);

            /// Retrieves the command-line arguments associated with a Shell link object
            void GetArguments([Out(), MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszArgs, int cchMaxPath);
            /// Sets the command-line arguments for a Shell link object
            void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);

            /// Retrieves the hot key for a Shell link object
            void GetHotkey(out ushort pwHotkey);
            /// Sets a hot key for a Shell link object
            void SetHotkey(ushort wHotkey);

            /// Retrieves the show command for a Shell link object (DisplayMade)
            void GetShowCmd(out int piShowCmd);
            /// Sets the show command for a Shell link object. The show command sets the initial show state of the window.
            void SetShowCmd(int iShowCmd);

            /// Retrieves the location (path and index) of the icon for a Shell link object
            void GetIconLocation([Out(), MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszIconPath, int cchIconPath, out int piIcon);
            /// Sets the location (path and index) of the icon for a Shell link object
            void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);

            /// Sets the relative path to the Shell link object
            void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);

            /// Attempts to find the target of a Shell link, even if it has been moved or renamed
            void Resolve(IntPtr hwnd, SLR_FLAGS fFlags);

            /// Sets the path and file name of a Shell link object (Target exe)
            void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("0000010c-0000-0000-c000-000000000046")]
        private interface IPersist
        {
            [PreserveSig]
            void GetClassID(out Guid pClassID);
        }

        [ComImport]
        [InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        [Guid("0000010b-0000-0000-C000-000000000046")]
        private interface IPersistFile : IPersist
        {
            new void GetClassID(out Guid pClassID);
            [PreserveSig]
            int IsDirty();

            [PreserveSig]
            void Load([In, MarshalAs(UnmanagedType.LPWStr)]
            string pszFileName, uint dwMode);

            [PreserveSig]
            void Save([In, MarshalAs(UnmanagedType.LPWStr)] string pszFileName,
                [In, MarshalAs(UnmanagedType.Bool)] bool fRemember);

            [PreserveSig]
            void SaveCompleted([In, MarshalAs(UnmanagedType.LPWStr)] string pszFileName);

            [PreserveSig]
            void GetCurFile([In, MarshalAs(UnmanagedType.LPWStr)] string ppszFileName);
        }

        [ComImport]
        [Guid("00021401-0000-0000-C000-000000000046")]
        private class ShellLink
        {
        }

        /// Преобразование переменных в абсолютные пути
        private static string ExpandEnvVar(string withVars)
        {
            if (withVars == null) { return null; }
            MatchCollection matches = Regex.Matches(withVars, "%.*%");

            foreach (Match match in matches)
            {
                if (Environment.GetEnvironmentVariable(match.Value.Trim('%')) == null)
                {
                    return null;
                }
            }

            return Environment.ExpandEnvironmentVariables(withVars);
        }

        private static void WriteWinXHash(string lnkFile, IntPtr Hash)
        {
            PROPERTYKEY PKEY_WINX_HASH = new PROPERTYKEY("fb8d2d7b-90d1-4e34-bf60-6eac09922bbf", 2);

            IPropertyStore Store = null;
            Guid guid_Store = typeof(IPropertyStore).GUID;

            try
            {
                SHGetPropertyStoreFromParsingName(lnkFile, IntPtr.Zero, GPS.READWRITE, ref guid_Store, out Store);

                PROPVARIANT propValue = new PROPVARIANT(); // GetPropValue
                Store.GetValue(ref PKEY_WINX_HASH, out propValue); // если нет - создаёт заготовку pv с VT_EMPTY

                if ( propValue.pointerValue != Hash )
                {
                    short VT_UI4 = 0x0013; // при VT_EMPTY = 0x0000 (удалит, оставив pv пустой c guid, только при записи другого pv убирается)
                    propValue.variantType = VT_UI4;
                    propValue.pointerValue = Hash;

                    Store.SetValue(ref PKEY_WINX_HASH, ref propValue);
                    Store.Commit();
                }
            }
            catch (Exception) {}

            // Close the property writer
            if (Store != null)
            {
                Marshal.ReleaseComObject(Store);
                Store = null;
            }
        }

        [Flags]
        public enum DisplayMode : int
        {
            SHOWNORMAL      = 1,
            SHOWMAXIMIZED   = 3,
            SHOWMINNOACTIVE = 7
        }

        /// Создать ярлык и + можно добавить хеш
        public static string CreateLnk(string lnkPath, string targetPath, string arguments,
            string lnkIcon, string workingDir, string Description, string WindowStyle, bool Elevate, bool WinxHash, bool NoTrack = false, bool NoRelative = false)
        {
            if (string.IsNullOrWhiteSpace(lnkPath)) { return "Error: lnkPath for the shortcut is not specified"; }
            else if (string.IsNullOrWhiteSpace(targetPath)) { return "Error: target Path is not specified"; }

            string lnkName = string.Empty; /// Имя файла ярлыка

            if (!lnkPath.EndsWith(".lnk", true, CultureInfo.InvariantCulture))
            {
                lnkName = Regex.Replace(Path.GetFileNameWithoutExtension(targetPath), @"(.+)_.+!.+", @"$1"); /// Имя ярлыка из цели для ярлыка, с сокращением UWP имени
            }
            else { lnkName = Path.GetFileNameWithoutExtension(lnkPath); } /// Имя ярлыка из "путь.lnk"

            if (string.IsNullOrWhiteSpace(lnkName)) { return "Error: shortcut name not generated"; }
            else { lnkName = lnkName + ".lnk"; }

            string lnkDir = Path.GetDirectoryName(lnkPath);
            if (string.IsNullOrWhiteSpace(lnkDir)) { lnkDir = lnkPath; }

            lnkPath = Path.Combine(lnkDir, lnkName);

            DisplayMode mode = DisplayMode.SHOWNORMAL;

            IShellLink Shortcut = (IShellLink) new ShellLink();
            IPersistFile file = (IPersistFile) Shortcut;
            IShellLinkDataList shellLink = (IShellLinkDataList) file;
            IPropertyStore Store = (IPropertyStore) file;

            try
            {
                if (!Directory.Exists(lnkDir))
                {
                    /// создание папки, если её нет
                    DirectoryInfo di = Directory.CreateDirectory(lnkDir);
                }

                if (!string.IsNullOrWhiteSpace(WindowStyle))
                {
                    mode = (DisplayMode) Enum.Parse(typeof(DisplayMode), WindowStyle, true);
                }

                int dm = Convert.ToInt32(mode);

                string iconPath = string.Empty;
                int iconIndex   = 0;

                if (!string.IsNullOrWhiteSpace(lnkIcon))
                {
                    string[] icon = lnkIcon.Split(new[] { ',' }, 2, StringSplitOptions.None);

                    iconPath = icon[0];

                    if (icon.Length > 1)
                    {
                        iconIndex = Convert.ToInt32(icon[1].ToString(), CultureInfo.InvariantCulture);
                    }
                }

                uint inflags;
                if (NoTrack) { shellLink.SetFlags(2359552); }

                Shortcut.SetPath(targetPath);     // Target exe (влияет на хэш)
                if (NoRelative && targetPath.StartsWith("%")) {
                    Shortcut.SetRelativePath(string.Empty, 0);
                    if (NoTrack) { shellLink.GetFlags(out inflags); shellLink.SetFlags((inflags | 33554432));}
                }

                Shortcut.SetArguments(arguments); // (влияет на хэш)
                Shortcut.SetWorkingDirectory(workingDir);
                if ( Description.Length > 0 ) { Shortcut.SetDescription(Description); }
                Shortcut.SetShowCmd(dm); // Window Style
                if ( iconPath.Length > 1 ) { Shortcut.SetIconLocation(iconPath, iconIndex); }
                if (Elevate) { shellLink.GetFlags(out inflags); shellLink.SetFlags((inflags | 8192)); }

                // [Metadata Property Store]
                PROPVARIANT pv = new PROPVARIANT();
                short VT_UI4 = 0x0013;
                pv.variantType = VT_UI4;
                
                /*PROPERTYKEY PKEY_BASE = new PROPERTYKEY("46588ae2-4cbc-4338-bbfc-139326986dce", 0); // Base MS 
                pv.pointerValue = IntPtr.Zero;
                Store.SetValue(ref PKEY_BASE, ref pv);*/

                if (WinxHash)
                {
                    IntPtr isHash = GenerateHash(targetPath, arguments);
                    if ( isHash != IntPtr.Zero )
                    {
                        PROPERTYKEY PKEY_WINX_HASH = new PROPERTYKEY("fb8d2d7b-90d1-4e34-bf60-6eac09922bbf", 2);
                        pv.pointerValue = isHash;
                        Store.SetValue(ref PKEY_WINX_HASH, ref pv);
                    }
                }

                Store.Commit();

                file.Save(lnkPath, false);

                return null; // Ok 
            }
            catch (Exception e)
            {
                return "Error: " + e.Message;
            }
            finally
            {
                if (Shortcut != null)
                {
                    Marshal.ReleaseComObject(Shortcut);
                    Shortcut = null;
                }

                if (Store != null)
                {
                    Marshal.ReleaseComObject(Store);
                    Store = null;
                }
            }
        }

        /// замена начальной части пути до exe на FolderDescriptions GUID этих расположений:
        /// HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\{F38BF404-1D43-42F2-9305-67DE0B28FC23}
        private static readonly KeyValuePair<string, string>[] SystemFolderMapping = new[]
        {
            new KeyValuePair<string, string>(ExpandEnvVar("%PROGRAMFILES%").ToLower(), "{905E63B6-C1BF-494E-B29C-65B732D3D21A}"),
            new KeyValuePair<string, string>(ExpandEnvVar("%SYSTEMROOT%\\System32").ToLower(), "{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}"),
            new KeyValuePair<string, string>(ExpandEnvVar("%SYSTEMROOT%").ToLower(), "{F38BF404-1D43-42F2-9305-67DE0B28FC23}")
            // new KeyValuePair<string, string>(ExpandEnvVar("%WINDIR%").ToLower(), "{F38BF404-1D43-42F2-9305-67DE0B28FC23}")
        };

        /// Генерация хеша для .lnk для пкм меню пуск: %UserProfile%\AppData\Local\Microsoft\Windows\WinX\...
        private static IntPtr GenerateHash(string exeTarget, string exeArg = null)
        {
            IntPtr Hash = IntPtr.Zero;
            string property = string.Empty;

            if (!string.IsNullOrWhiteSpace(exeTarget))
            {
                property = ExpandEnvVar(exeTarget);

                foreach (var kv in SystemFolderMapping)
                {
                    // Замена части пути к exe файлу на определённый GUID для правильного хэша
                    // заменяются только расположения для файлов в %PROGRAMFILES%, %WINDIR%\System32, %WINDIR%, %SYSTEMROOT%
                    property = property.ToLower().Replace(kv.Key, kv.Value);
                }

                if (!string.IsNullOrWhiteSpace(exeArg)) { property += exeArg; }
                property += "do not prehash links.  this should only be done by the user."; /// Специальная обязательная секретная строка
                property = property.ToLower();

                byte[] inBytes  = Encoding.GetEncoding(1200).GetBytes(property);
                int byteCount   = inBytes.Length;
                byte[] outBytes = new byte[byteCount];
                int hashResult  = HashData(inBytes, byteCount, outBytes, byteCount); // int > Marshal.GetLastWin32Error(); 0 = Ok

                if (hashResult == 0)
                {
                    Hash = (IntPtr) BitConverter.ToUInt32(outBytes, 0);
                }
            }
            
            return Hash;
        }

        /// Добавление хеша в файл .lnk для пкм меню пуск: %UserProfile%\AppData\Local\Microsoft\Windows\WinX\...
        private static string SetPropertyStoreData(string lnkFile)
        {
            PROPERTYKEY PKEY_Link_TargetPath = new PROPERTYKEY("B9B4B3FC-2B51-4A42-B5D8-324146AFCF25", 2);
            PROPERTYKEY PKEY_Link_Arguments  = new PROPERTYKEY("436F2667-14E2-4FEB-B30A-146C53B5B674", 100);

            IShellItem2 shellItem = null;
            string exeTarget = string.Empty, exeArg = string.Empty; // , property = string.Empty;

            try
            {
                SHCreateItemFromParsingName(lnkFile, IntPtr.Zero, typeof(IShellItem2).GUID, out shellItem);

                exeTarget = ExpandEnvVar(shellItem.GetString(PKEY_Link_TargetPath));
                exeArg    = shellItem.GetString(PKEY_Link_Arguments);
            }
            catch (Exception) {}

            if (shellItem != null)
            {
                Marshal.ReleaseComObject(shellItem);
                shellItem = null;
            }

            if (!string.IsNullOrWhiteSpace(exeTarget))
            {
                IntPtr isHash = GenerateHash(exeTarget, exeArg);
                if ( isHash != IntPtr.Zero )
                {
                    // Запись хэша в ярлык
                    WriteWinXHash(lnkFile, isHash);
                }
                else { return "Error: isHash = IntPtr.Zero"; }

                return null; /// "hash: " + " (" + isHash + ") | String: " + property;
            }
            else { return "Error: exeTarget = 0"; }
        }

        /// добавить хеш в lnk
        public static string SetHashLnk(string lnkFile)
        {
            string result = SetPropertyStoreData(lnkFile);
            return result;
        }

        /// добавить хеш нескольким файлам lnk сразу
        public static string[] SetHashLnk(string[] lnkFiles)
        {
            string[] result = {};

            foreach (string lnk in lnkFiles)
            {
                Array.Resize(ref result, result.Length + 1);

                result[result.Length - 1] = SetPropertyStoreData(lnk);
            }

            return result;
        }

        /// Установка/Снятие бита в ярлыке для требования повышения привилегий при запуске, закрывать стрим не нужно, так как using() закрывает
        public static string ElevateLnk(string lnkFile, bool elevate)
        {
            try
            {
                using (FileStream fileStream = new FileStream(lnkFile, FileMode.Open, FileAccess.ReadWrite))
                {
                    fileStream.Seek(21, SeekOrigin.Begin); // 21 = 0x15
                    int b = fileStream.ReadByte() | 32;    // 32 = 0x20
                    fileStream.Seek(21, SeekOrigin.Begin);
                    
                    if (elevate)
                    {
                        fileStream.WriteByte((byte) b);
                    }
                    else
                    {
                        fileStream.WriteByte((byte) (b ^ 32));
                    }
                }

                return null;
            }
            catch (Exception e)
            {
                return "Error: " + e.Message;
            }
        }

        /// Получение комментария из ярлыка
        public static string GetComment(string lnkFile)
        {
            IShellLink lnk      = (IShellLink)new ShellLink();
            IPersistFile file   = (IPersistFile)lnk;
            const int STGM_READ = 0;
            file.Load(lnkFile, STGM_READ);

            const int MAX_PATH = 260;

            StringBuilder desc = new StringBuilder(MAX_PATH);
            lnk.GetDescription(desc, desc.MaxCapacity);

            if (lnk != null)
            {
                Marshal.ReleaseComObject(lnk);
                lnk = null;
            }

            if (desc.Length > 0)
            {
                return desc.ToString();
            }

            return null;
        }
    }

    /// Для получения локализации из файлов ресурсов: exe, dll, и т.д. "%windir%\File.dll,-1" или "D:\File.exe",1 и т.д. (любая комбинация)
    public class LibraryResource
    {
        [DllImport("kernel32.dll", CharSet=CharSet.Auto)]
        private static extern IntPtr LoadLibraryEx(
        [MarshalAs(UnmanagedType.LPTStr)] string lpLibFileName, IntPtr hFile, int dwFlags);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int LoadString(IntPtr hInstance, int ID, StringBuilder lpBuffer, int nBufferMax);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FreeLibrary(IntPtr hModule);

        private const int LOAD_LIBRARY_AS_DATAFILE = 0x00000002;
        private const int LOAD_LIBRARY_AS_IMAGE_RESOURCE = 0x00000020;

        public static string GetLocalizedString(string libString, int index = 0)
        {
            IntPtr lib = IntPtr.Zero;
            StringBuilder result = new StringBuilder(2048);

            try
            {
                string[] resource = libString.Split(new[] { ',' }, 2, StringSplitOptions.None);

                string file = Environment.ExpandEnvironmentVariables(resource[0].Trim('@',' ','\u0009')); /// \u0009 = char Tab

                if (resource.Length > 1)
                {
                    index = Convert.ToInt32(resource[1].ToString(), CultureInfo.InvariantCulture);
                }

                lib = LoadLibraryEx(file, IntPtr.Zero, LOAD_LIBRARY_AS_DATAFILE | LOAD_LIBRARY_AS_IMAGE_RESOURCE);
                LoadString(lib, Math.Abs(index), result, result.Capacity);
            }
            catch (Exception) {}
            finally
            {
            	if ( lib != IntPtr.Zero ) { FreeLibrary(lib); }
            }

            if ( result.Length > 0 )
            {
                return result.ToString();
            }

            return null;
        }
    }
}
'@
    if ( -not ( 'WinAPI.Shortcut' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $Shortcut -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    if ( $GetComment )
    {
        Return [WinAPI.Shortcut]::GetComment($GetComment)
    }
    elseif ( $GetLocalizedName )
    {
        Return [WinAPI.LibraryResource]::GetLocalizedString($GetLocalizedName)
    }
    elseif ( $CreateLnk )
    {
        $Err = [WinAPI.Shortcut]::CreateLnk(
            $CreateLnk.lnkPath,     $CreateLnk.targetPath, $CreateLnk.arguments,
            $CreateLnk.iconPath,    $CreateLnk.workingDir, $CreateLnk.description,
            $CreateLnk.windowStyle, $CreateLnk.elevate,    $CreateLnk.WinxHash,
            $CreateLnk.NoTrack,     $CreateLnk.NoRelative
        )

        if ( $Err ) { $Err = " $NameThisFunction`: $Err" }

        Return $Err
    }
    elseif ( $AddWinxHash )
    {
        $Err = [WinAPI.Shortcut]::SetHashLnk($AddWinxHash)

        if ( $Err ) { $Err = " $NameThisFunction`: $Err" }

        Return $Err
    }
    elseif ( $ElevateEnable )
    {
        $Err = [WinAPI.Shortcut]::ElevateLnk($ElevateEnable, $true)

        if ( $Err ) { $Err = " $NameThisFunction`: $Err" }

        Return $Err
    }
    elseif ( $ElevateDisable )
    {
        $Err = [WinAPI.Shortcut]::ElevateLnk($ElevateDisable, $false)

        if ( $Err ) { $Err = " $NameThisFunction`: $Err" }

        Return $Err
    }

    Return $Err
}
