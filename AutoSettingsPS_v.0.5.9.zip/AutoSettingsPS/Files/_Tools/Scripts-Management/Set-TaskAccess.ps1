﻿
<#
.SYNOPSIS
 Блокировка/разблокировка изменения параметров или состояния задач.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Выполняет блокировку задач путем установки на раздел реестра задачи
 для группы 'Все' запрета на изменение параметров.

 Получение и установка параметров доступа осуществляется
 через функцию Set-OwnerAndAccess добавлением/удалением Ace с блокировкой изменения.

 Добавлены возможности: только применить, только проверить, или применить, а затем проверить,
 с выводом результата.

 Вывод полученных данных в консоль осуществляется через функцию Show-Result,
 для отображения в нужном виде.

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.PARAMETER Access
 Варианты:
 Lock   = Блокировать.
 UnLock = Разблокировать.

.EXAMPLE
    Set-TaskAccess -Do Set -TaskName 'Имя' -TaskPath '\путь' -Access Lock
    Set-TaskAccess -Do Check -TaskName 'Имя' -TaskPath '\путь' -Access Check
    Set-TaskAccess -Do Check -TaskName '\путь\Имя' -Access Check

    Описание
    --------
    Установит запрет на изменение параметров задачи, и выведет результат действия.
    И два варианта только проверки.

.NOTES
 ====================================================
      Автор:  westlife (ru-board)  Версия:  1.0.1
       Дата:  25-06-2023
 ====================================================

#>
Function Set-TaskAccess {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [ValidateSet( 'Lock', 'UnLock' )]
        [string] $Access
       ,
        [Parameter( Mandatory = $true,  Position = 1 )]
        [string] $TaskName
       ,
        [Parameter( Mandatory = $false )]
        [string] $TaskPath
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Do -eq 'Default' ) { $Do = 'Set' }

    # Перехват ошибок, только прерываемых исключений, для выхода из функции.
    # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
    trap
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Ошибка' }
        Write-Warning "$text`: '$Action'" ; break
    }

    # Получение команды действия для отображения, при необходимости.
    $Action = $(($MyInvocation.Line.Replace('-Do:$Act','')).Trim())

    Write-Verbose "Команда:`n $Action"

    $TaskName = $TaskName.Trim('\ ')
    $TaskPath = $TaskPath.Trim('\ ')

    if ( -not $TaskName )
    {
        $text = if ( $L.s2 ) { $L.s2 } else { 'Имя задачи не указано или неверно указано' }
        Write-Warning "$NameThisFunction`: $text"
        Return
    }

    # Трим снова, так как путь может быть пустым, а разделителей по карям в данный момент не должно быть.
    $TaskPathName = "$TaskPath\$TaskName".Trim('\')
    $TaskPathName = "\$TaskPathName"

    try
    {
        [string] $TaskRegKey  = ''
        [string] $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
        $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenRegKey )
        {
            # Поиск раздела задачи в реестре, по параметру Path значению: '\Путь\Имя'.
            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
            {
                $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                if ( $OpenSubKey )
                {
                    if ( $OpenSubKey.GetValue('Path',$null) -like $TaskPathName )
                    {
                        $TaskRegKey = "$RegKeyTasks\$SubKey"

                        $OpenSubKey.Close()
                        $OpenRegKey.Close()
                        break
                    }

                    $OpenSubKey.Close()
                }
            }

            $OpenRegKey.Close()
        }
    }
    catch {}

    # Создаем хэш-таблицу $ShowResult,
    # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
    Set-Variable -Name ShowResult -Value @{} -Force
    $ShowResult['Do']   = $Do
    $ShowResult['Type'] = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Блокир-ка' })
    $ShowResult['Info'] = "$NameThisFunction`: $Access '$TaskPathName'"

    if ( $TaskRegKey )
    {
        [string] $TaskSddl = Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -GetSDDL -WithSacl

        if ( $Do -eq 'Set' )
        {
            if ( $Access -eq 'Lock' )
            {
                if ( -not ( $TaskSddl -match '\(D;CI;DCLC[^)]*?;;;WD\)' ))
                {
                    Write-Verbose 'Блокировка задачи'

                    $TaskSddl = $TaskSddl -replace '\(D;[^)]*?;;;WD\)','' -replace '(^[^(]+)','$1(D;CI;DCLC;;;WD)' # Только добавление запрета изменения для всех

                    # Установка владельцем группы Администраторы, Primary Group = Администраторы, отключение наследования, очистка всех явно указанных разрешений.
                    # Установка для системы и администраторов разрешения только на чтение, И главное - добавление группы 'Все' с запретом на все, кроме чтения параметров.
                    # Это только запрет для группы Все: Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -RecoverySDDL 'O:BAG:BAD:AI(D;CI;DCLCWPSDRCWDWO;;;WD)'

                    Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -RecoverySDDL $TaskSddl
                    
                    $TaskSddl = Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -GetSDDL
                }
            }
            else
            {
                if ( $TaskSddl -match '\(D;[^)]*?;;;WD\)' )
                {
                    Write-Verbose 'Удаление запрета доступа для всех к задаче'

                    $TaskSddl = $TaskSddl -replace '\(D;[^)]*?;;;WD\)',''

                    Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -RecoverySDDL $TaskSddl
                    
                    $TaskSddl = Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -GetSDDL
                }
            }
        }

        Write-Verbose 'Проверка блокировки'
        
        # Проверка наличия запрета всего, кроме чтения для Группы Все.
        if ( -not $TaskSddl )
        {
            Write-Verbose 'SDDL у Задачи не получен!'

            $ShowResult['Status'] = 'Lock Error'
            $ShowResult['Result'] = '!!!'
            $ResultFunc = $false
        }
        elseif ( $TaskSddl -match '\(D;CI;DCLC[^)]*?;;;WD\)' )
        {
            Write-Verbose 'Задача заблокирована'

            $ShowResult['Status'] = 'Lock'

            if ( $Access -eq 'Lock' )
            {
                $ShowResult['Result'] = '+'
                $ResultFunc = $true
            }
            else
            {
                $ShowResult['Result'] = '!!!'
                $ResultFunc = $false
            }
        }
        else
        {
            Write-Verbose 'Задача разблокирована'

            $ShowResult['Status'] = 'UnLock'

            if ( $Access -eq 'UnLock' )
            {
                $ShowResult['Result'] = '+'
                $ResultFunc = $true
            }
            else
            {
                $ShowResult['Result'] = '!!!'
                $ResultFunc = $false
            }
        }
    }
    else
    {
        Write-Verbose 'Задача не найдена'
        $ResultFunc = $true
    }

    if ( $Do -eq 'Check' ) { $isAct = '(Только проверено)' } else { $isAct = '(Выполнено, затем проверено)' }

    # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
    if ( $ResultFunc )
    {
        Write-Verbose "   Вернo    [Параметр Блокировки соответствует]  $isAct"
    }
    else
    {
        $NeedFix = $true
        Write-Verbose  "   Не верно   [Параметр Блокировки Не соответствует]  $isAct"
    }

    Write-Verbose 'Передаем данные для вывода в функцию Show-Result'

    # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
    Show-Result @ShowResult
}
