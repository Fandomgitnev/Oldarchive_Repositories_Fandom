﻿
<#
.SYNOPSIS
 Создание, удаление, настройка и/или проверка состояния задач.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Выполняет команду и/или делает проверку состояния или наличия задачи.
 Принимает командлеты: 'Enable-ScheduledTask', 'Disable-ScheduledTask', 'Register-ScheduledTask', 'Unregister-ScheduledTask'

 Используется функция Token-Privileges для включения привилегий.
 Используется функция Token-Impersonate для олицетворения за TrustedInstaller, если нет доступа.
 Используется функция Start-ProcessFromSYS для запуска команд от TI
 Используется функция Set-OwnerAndAccess для получения временного доступа, при необходимости.
 Используется функция Show-Result для отображения результата в нужном виде.

 Используется ComObject Schedule.Service для универсальной проверки состояния (а не статуса!) задачи (включена/отключена).
 Этот метод очень быстрый. От языка системы не зависит. (Через командлет очень медленно).

 Если нет доступа к задаче, то выполняется с олицетворением за TrustedInstaller, если все равно нет,
 то получает временный доступ к файлу и к разделу реестра задачи.
 Доступ будет не получить, если будет блокировка драйвером в системе.
 После этого выполняет действие и возвращает сохраненные перед выполнением настройки доступа, если были изменены.

 Для Register-ScheduledTask, если нет задачи и доступа и не помогает олицетворение за TI, сначала создается файл-пустышка с доступом.
 Можно использовать splatting.

 Добавлены возможности: Применить, а затем проверить или только проверить.

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.INPUTS
 Строка с командой для указанных стандартных командлетов.

.EXAMPLE
    Set-Tsk Disable-ScheduledTask -TaskName 'BackgroundUploadTask' -TaskPath '\Microsoft\Windows\SettingSync'

    Описание
    --------
    Попытается отключить задачу 'BackgroundUploadTask'.
    При ошибке выполнения получит временный доступ к файлу задачи и к ее разделу реестра,
    Затем провторит операцию, с выводом результата, и скрытием ошибок при выполнении, кроме прерывающих.
    Без -Do, эквивалентно -Do Set.

.EXAMPLE
    Set-Tsk -Do:Check Enable-ScheduledTask -TaskName 'BackgroundUploadTask' -TaskPath '\Microsoft\Windows\SettingSync'

    Описание
    --------
    Только проверит соответствие результату указанного командлета, если будет отключена выведет не соответствие,
    если будет отсутствовать выведет отсутствие задачи.
    С выводом результата, и скрытием ошибок при выполнении, кроме прерывающих.

.EXAMPLE
    Set-Tsk -Do:Set Register-ScheduledTask @Parameters

    Описание
    --------
    Попытается выполнить создание задачи, при ошибке доступа - получит доступ, с созданием файла пустышки, при необходимости.
    Задача будет пересоздана, при наличии, так как параметр -Force добавляется автоматически по умолчанию.
    С выводом результата, и скрытием ошибок при выполнении, кроме прерывающих.

.NOTES
 ====================================================
      Автор:  westlife (ru-board)  Версия:  1.0.1
       Дата:  19-02-2023
 ====================================================

#>
Function Set-Tsk {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [ValidateSet( 'Enable-ScheduledTask', 'Disable-ScheduledTask', 'Register-ScheduledTask', 'Unregister-ScheduledTask' )]
        [string] $Cmdlet
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1 )]
        [string] $TaskName
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [string] $TaskPath
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [psobject] $InputObject
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )] $Action
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $Description
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $Principal
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $Settings
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $Trigger
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] [securestring] $Password
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $User
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] $RunLevel
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] [string] $XML
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] [switch] $Force
       ,[Parameter( Mandatory = $false, ValueFromPipeline = $false )] [switch] $Confirm
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( $Do -eq 'Default' ) { $Do = 'Set' }

        # Перехват ошибок, только прерываемых исключений, в блоке Begin, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Ошибка в Begin' }
            Write-Warning "$NameThisFunction`: $text`: '$ActionTSK'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Получение команды действия для отображения, при необходимости.
        [string] $ActionTSK = ($MyInvocation.Line.Replace($NameThisFunction,'') -Replace '(\s*-Do[:]?\s*[^\s]*\s*)',' ').Trim()

        Write-Verbose "Команда:`n $ActionTSK"

        # Очищаем имя и путь от разделителей и пробелов по краям.
        # Для получения далее правильного полного пути, и правильных отдельных имени и пути.
        # Так как, в некоторых случаях, их обязательно нужно указывать командлетам по отдельности, поэтому тут всегда по отдельности.
        $TaskName = $TaskName.Trim('\ ')
        $TaskPath = $TaskPath.Trim('\ ')

        [bool] $Exit = $false

        if ( -not $TaskName )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Имя задачи не указано или неверно указано' }
            Write-Warning "$NameThisFunction`: $text"
            $Exit = $true ; Return
        }

        # Трим снова, так как путь может быть пустым, а разделителей по карям в данный момент не должно быть для Split-Path и указания файла.
        $TaskPathName = "$TaskPath\$TaskName".Trim('\')

        $TaskName = $TaskPathName | Split-Path -leaf -ErrorAction Stop
        $TaskPath = $TaskPathName | Split-Path -Parent -ErrorAction Stop

        # $TaskPath2 для
        if ( $TaskPath ) { [string] $TaskPath2 = "\$TaskPath" ; $TaskPath = "\$TaskPath\" }
        else             { [string] $TaskPath2 = '\'          ; $TaskPath = '\'           }

        $TaskFile     = "$env:SystemRoot\System32\Tasks\$TaskPathName"
        $TaskPathName = "\$TaskPathName"

        # Создаем хэш-таблицу $ShowResult,
        # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
        Set-Variable -Name ShowResult -Value @{} -Force
        $ShowResult['Do']   = $Do
        $ShowResult['Type'] = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Задача' })
        $ShowResult['Info'] = "$Cmdlet '$TaskPathName'"

        # Подключаем привилегии, включая SeBackupPrivilege для доступа к файловой системе при любых настройках доступа.
        # 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege', 'SeSecurityPrivilege'
        Token-Privileges -Enable4Privileges # Подгружает общий type, и включает 4 привилегии только один раз, и запоминает, что включал

        # Внутренняя функция по поиску раздела задачи в реестре, по параметру Path значению: '\Путь\Имя'.
        Function Get-TaskRegKey {

            try
            {
                $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
                $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')
            }
            catch { $OpenRegKey = $null }

            if ( $OpenRegKey )
            {
                foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                {
                    try
                    {
                        $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                        if ( $OpenSubKey )
                        {
                            if ( $OpenSubKey.GetValue('Path',$null) -eq $TaskPathName )
                            {
                                # Передаем результат - найденный раздел реестра задачи, без RootKey и останавливаем дальнейший поиск.
                                "$RegKeyTasks\$SubKey"

                                $OpenSubKey.Close()
                                break
                            }

                            $OpenSubKey.Close()
                        }
                    }
                    catch {}
                }

                $OpenRegKey.Close()
            }
        }
    }

    Process
    {
        # Перехват ошибок, только прерываемых исключений, в блоке Process, без выхода из функции.
        trap
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'Ошибка в Process' }
            Write-Warning "$NameThisFunction`: $text`: '$ActionTSK'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            continue
        }

        # Если нужно выйти или выполнить только проверку, переходим в End.
        if ( $Exit ) { Return }
        elseif ( $Do -eq 'Check' ) { $isAct = '(Только проверено)' ; Return } else { $isAct = "(Выполнено, затем проверено)" }

        Write-Verbose "Выполняем настройку '$Do'"

        $FileSddlBackUP = $RegSddlBackUP = $null

        [bool] $NotExist = $false

        if ( $Cmdlet -eq 'Register-ScheduledTask' )
        {
            Write-Verbose "Создание задачи: '$TaskPathName'"

            # Получаем переданные параметры для сплаттинга, удалем из них лишние параметры, и заменяем на правильные отдельные путь и имя.
            [hashtable] $Parameters = $MyInvocation.BoundParameters
            $Parameters.Remove('Cmdlet')
            $Parameters.Remove('Do')
            $Parameters['TaskName'] = $TaskName
            $Parameters['TaskPath'] = $TaskPath
            $Parameters['Force']    = $true

            # Пробуем выполнить действие, с перезаписью, так как параметр -Force добавляется автоматически.
            Write-Verbose 'Выполнение Register-ScheduledTask @Parameters -Force'

            try { Register-ScheduledTask @Parameters -ErrorAction Stop > $null }
            catch
            {
                # Если ошибка доступа.
                if ( $_.CategoryInfo.Category -eq 'PermissionDenied' )
                {
                    Write-Verbose 'Нет доступа'

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose 'Выполняем еще раз под олицетворением'

                    try { Register-ScheduledTask @Parameters -ErrorAction Stop > $null }
                    catch
                    {
                        # Если ошибка доступа.
                        if ( $_.CategoryInfo.Category -eq 'PermissionDenied' )
                        {
                            Write-Verbose 'Нет доступа всё равно'

                            # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                            Token-Impersonate -Token SYS

                            # Если файл существует.
                            if ( Test-Path -LiteralPath $TaskFile -PathType Leaf -ErrorAction SilentlyContinue )
                            {
                                # Поучаем доступ к файлу задачи, с предварительным запоминанием параметров доступа.
                                Write-Verbose "Сохраняем SDDL и получаем доступ к '$TaskFile'"
                                try { $FileSddlBackUP = Set-OwnerAndAccess -Path $TaskFile -GetSDDL } catch {}

                                Set-OwnerAndAccess -Path $TaskFile -SetFullAccess

                                # Получаем доступ к разделу реестра задачи, после его нахождения, с предварительным запоминанием параметров доступа.
                                $TaskRegKey = Get-TaskRegKey
                                Write-Verbose "Сохраняем SDDL и получаем доступ к 'HKLM:\$TaskRegKey'"
                                try { $RegSddlBackUP = Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -GetSDDL } catch {}

                                Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -SetFullAccess

                                Write-Verbose 'Выполнение Register-ScheduledTask @Parameters -Force'
                                # Пробуем выполнить действие повторно, без -ErrorAction Stop, так как после получения доступа тупит командлет.
                                try { Register-ScheduledTask @Parameters > $null } catch {}

                                if ( $FileSddlBackUP )
                                {
                                    # Восстановление доступа на файл задачи после выполнения.
                                    Write-Verbose "Восстановление доступа к '$TaskFile'"
                                    Set-OwnerAndAccess -Path $TaskFile -RecoverySDDL $FileSddlBackUP
                                }

                                if ( $RegSddlBackUP )
                                {
                                    # Восстановление доступа на раздел рееестра после выполнения.
                                    Write-Verbose "Восстановление доступа к 'HKLM:\$TaskRegKey'"
                                    Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -RecoverySDDL $RegSddlBackUP
                                }
                            }
                            else
                            {
                                # Иначе, файла не существует, как и доступа.

                                # Выполняем создание файла пустышки с именем задачи с олицетворением за TrustedInstaller.
                                Write-Verbose "Cоздание файла пустышки от имени Системы '$TaskFile'"
                                try { $null > $TaskFile ; Start-Sleep -Milliseconds 100 } catch {}

                                # Получаем доступ к файлу-пустышке с именем задачи, с предварительным запоминанием параметров доступа.
                                Write-Verbose "Сохраняем SDDL и получаем доступ к файлу пустышке '$TaskFile'"
                                try { $FileSddlBackUP = Set-OwnerAndAccess -Path $TaskFile -GetSDDL } catch {}

                                Set-OwnerAndAccess -Path $TaskFile -SetFullAccess

                                Start-Sleep -Milliseconds 50

                                # Пробуем выполнить действие повторно,
                                # без -ErrorAction Stop, так как после получения доступа тупит командлет, делает, но выкидывает ошибку, что нет задачи.
                                Write-Verbose 'Выполнение Register-ScheduledTask @Parameters -Force'
                                try { Register-ScheduledTask @Parameters > $null } catch {}

                                if ( $FileSddlBackUP )
                                {
                                    # Восстановление доступа на файл задачи после выполнения.
                                    Write-Verbose "Восстановление доступа к '$TaskFile'"
                                    Set-OwnerAndAccess -Path $TaskFile -RecoverySDDL $FileSddlBackUP
                                }
                            }
                        }
                        else
                        {
                            $text = if ( $L.s5 ) { $L.s5 } else { 'Неизвестная проблема. Задача' }
                            Write-Warning "`n   $NameThisFunction $Cmdlet`: $text`: '$TaskPathName',`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
                        }
                    }
                    finally { Token-Impersonate -Reset }
                }
                else
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { 'Неизвестная проблема. Задача' }
                    Write-Warning "`n   $NameThisFunction $Cmdlet`: $text`: '$TaskPathName',`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
                }
            }
        }
        elseif ( $Cmdlet -eq 'Unregister-ScheduledTask' )
        {
            Write-Verbose "Удаление задачи: '$TaskPathName'"

            # Пробуем удалить задачу.
            Write-Verbose "Выполнение Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false"

            try { Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false -ErrorAction Stop > $null }
            catch
            {
                # Если ошибка при отсутствии задачи, переходим в блок End, иначе выводим полученную ошибку.
                if ( $_.CategoryInfo.Category -eq 'ObjectNotFound' ) {  Write-Verbose 'Задача не существует' ; [bool] $NotExist = $true ; Return }
                else
                {
                    Write-Verbose 'Не выполнено'

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose 'Выполняем еще раз под олицетворением'

                    try { Unregister-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -Confirm:$false -ErrorAction Stop > $null }
                    catch
                    {
                        Write-Verbose 'Не выполнено, выполняем еще раз, используем SCHTASKS'

                        $ExitCode = Start-ProcessFromSYS TI -CmdLine "SCHTASKS /Delete /TN ""$TaskPathName"" /F" -NoWindow -Wait -ExitCode

                        if ( $ExitCode )
                        {
                            $text = if ( $L.s6 ) { $L.s6 } else { 'Проблема с удалением. Задача' }
                            Write-Host "   $NameThisFunction ExitCode`: $ExitCode`: $text`: '$TaskPathName'" -ForegroundColor DarkYellow
                        }
                    }
                }
            }
        }
        else
        {
            # Включение или отключение задачи.

            if ( $Cmdlet -eq 'Enable-ScheduledTask' )
            {
                Write-Verbose "Включение задачи: '$TaskPathName'"
            }
            else
            {
                Write-Verbose "Отключение задачи: '$TaskPathName'"
            }

            # Пробуем включить или отключить задачу.
            Write-Verbose "Выполнение $Cmdlet -TaskName $TaskName -TaskPath $TaskPath"

            try { & $Cmdlet -TaskName $TaskName -TaskPath $TaskPath -ErrorAction Stop > $null }
            catch
            {
                # Если задачи не существует, переходим в блок End.
                if ( $_.CategoryInfo.Category -eq 'ObjectNotFound' ) { Write-Verbose 'Задача не существует' ; [bool] $NotExist = $true ; Return }
                elseif ( $_.CategoryInfo.Category -eq 'PermissionDenied' )
                {
                    # Если нет доступа.

                    Write-Verbose 'Нет доступа'

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose 'Выполняем еще раз под олицетворением'

                    try { & $Cmdlet -TaskName $TaskName -TaskPath $TaskPath -ErrorAction Stop > $null }
                    catch
                    {
                        Write-Verbose 'Нет доступа, используем SCHTASKS'

                        $ExitCode = Start-ProcessFromSYS TI -CmdLine "SCHTASKS /Change /TN ""$TaskPathName"" /$($Cmdlet.Split('-')[0])" -NoWindow -Wait -ExitCode

                        if ( $ExitCode )
                        {
                            Write-Verbose "SCHTASKS ExitCode: $ExitCode, используем смену прав"

                            try
                            {
                                # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                                Token-Impersonate -Token SYS

                                # Поучаем доступ к файлу задачи, с предварительным запоминанием параметров доступа.
                                Write-Verbose "Сохраняем SDDL и получаем доступ к '$TaskFile'"
                                try { $FileSddlBackUP = Set-OwnerAndAccess -Path $TaskFile -GetSDDL } catch {}

                                Set-OwnerAndAccess -Path $TaskFile -SetFullAccess

                                # Получаем доступ к разделу реестра задачи, после его нахождения, с предварительным запоминанием параметров доступа.
                                $TaskRegKey = Get-TaskRegKey
                                Write-Verbose "Сохраняем SDDL и получаем доступ к 'HKLM:\$TaskRegKey'"
                                try { $RegSddlBackUP = Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -GetSDDL } catch {}

                                Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -SetFullAccess

                                # Пробуем выполнить действие повторно,
                                # без -ErrorAction Stop, так как после получения доступа тупит командлет, делает, но выкидывает ошибку, что нет задачи.
                                Write-Verbose "Выполнение $Cmdlet -TaskName $TaskName -TaskPath $TaskPath"
                                try { & $Cmdlet -TaskName $TaskName -TaskPath $TaskPath -ErrorAction SilentlyContinue > $null } catch {}

                                if ( $FileSddlBackUP )
                                {
                                    # Восстановление доступа на файл задачи после выполнения.
                                    Write-Verbose "Восстановление доступа к '$TaskFile'"
                                    Set-OwnerAndAccess -Path $TaskFile -RecoverySDDL $FileSddlBackUP
                                }

                                if ( $RegSddlBackUP )
                                {
                                    # Восстановление доступа на раздел рееестра после выполнения.
                                    Write-Verbose "Восстановление доступа к 'HKLM:\$TaskRegKey'"
                                    Set-OwnerAndAccess -Path "HKLM:\$TaskRegKey" -RecoverySDDL $RegSddlBackUP
                                }
                            }
                            catch {}
                            finally { Token-Impersonate -Reset }
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { 'Неизвестная проблема. Задача' }
                    Write-Warning "`n   $NameThisFunction $Cmdlet`: $text`: '$TaskPathName',`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
                }
            }
        }
    }

    End
    {
        # Перехват ошибок, только прерываемых исключений, в блоке End, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s7 ) { $L.s7 } else { 'Ошибка в End' }
            Write-Warning "$NameThisFunction`: $text`: '$ActionTSK'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выйти при ошибке.
        if ( $Exit )
        {
            Return  # выходим из функции
        }

        Write-Verbose "Начало Проверки. Действие: '$Do'"

        [string] $TaskState  = ''
          [bool] $ResultFunc = $false

        # Если раздел реестра и файл задачи существует.
        if (( Get-TaskRegKey ) -and ( Test-Path -LiteralPath $TaskFile -PathType Leaf -ErrorAction SilentlyContinue ))
        {
            # Пробуем получить состояние (а не статус!), и этот метод очень быстрый, в сравнении с командлетом.
            [psobject] $GetTaskState = $null
            try
            {
                [System.__ComObject] $ScheduleService = New-Object -ComObject Schedule.Service
                $ScheduleService.Connect()
                [bool] $GetTaskState = $ScheduleService.GetFolder($TaskPath2).GetTask($TaskName).Enabled
            }
            catch {}

            if     (  $true -eq $GetTaskState ) { $TaskState = 'Enabled'  }
            elseif ( $false -eq $GetTaskState ) { $TaskState = 'Disabled' }

            # Если состояние задачи "Включено".
            if ( $TaskState -eq 'Enabled' )
            {
                Write-Verbose "Задача включена '$TaskPathName'"

                # 'Enable-ScheduledTask', 'Disable-ScheduledTask', 'Register-ScheduledTask', 'Unregister-ScheduledTask'

                if (( $Cmdlet -eq 'Enable-ScheduledTask' ) -or ( $Cmdlet -eq 'Register-ScheduledTask' ))
                {
                    # Добавляем данные для вывода в консоль.
                    $ShowResult['Result'] = '+'
                    $ShowResult['Status'] = '{0}' -f $(if ( $L.s8 ) { $L.s8 } else { 'Включена' })

                    # Результат выполнения функции положительный.
                    $ResultFunc = $true
                }
                else
                {
                    $ShowResult['Result'] = '!!!'
                    $ShowResult['Status'] = '{0}' -f $(if ( $L.s8 ) { $L.s8 } else { 'Включена' })

                    $ResultFunc = $false
                }
            }
            elseif ( $TaskState -eq 'Disabled'  )
            {
                Write-Verbose "Задача отключена '$TaskPathName'"

                if (( $Cmdlet -eq 'Disable-ScheduledTask' ) -or ( $Cmdlet -eq 'Register-ScheduledTask' ))
                {
                    $ShowResult['Result'] = '+'
                    $ShowResult['Status'] = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { 'Отключена' })

                    $ResultFunc = $true
                }
                else
                {
                    $ShowResult['Result'] = '!!!'
                    $ShowResult['Status'] = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { 'Отключена' })

                    $ResultFunc = $false
                }
            }
            else
            {
                Write-Verbose "Ошибка получения состояния задачи '$TaskPathName'"

                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = '{0}' -f $(if ( $L.s10 ) { $L.s10 } else { 'Ошибка' })

                $ResultFunc = $false
            }
        }
        else
        {
            Write-Verbose "Задача отсутствует '$TaskPathName'"

            if (( $Cmdlet -eq 'Enable-ScheduledTask' ) -or ( $Cmdlet -eq 'Disable-ScheduledTask' ))
            {
                $ShowResult.Remove('Result')

                $ResultFunc = $true
            }
            elseif ( $Cmdlet -eq 'Register-ScheduledTask' )
            {
                $ShowResult['Result'] = '!!!'
                $ShowResult['Status'] = '{0}' -f $(if ( $L.s11 ) { $L.s11 } else { 'Нет Задачи' })

                $ResultFunc = $false
            }
            else
            {
                # 'Unregister-ScheduledTask', то есть удаление.

                if (( $Do -eq 'Set' ) -and ( -not $NotExist ))
                {
                    $ShowResult['Result'] = '+'
                    $ShowResult['Status'] = '{0}' -f $(if ( $L.s12 ) { $L.s12 } else { 'Удалена' })
                }
                else
                {
                    $ShowResult.Remove('Result')
                }

                $ResultFunc = $true
            }
        }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo    [Параметр правильный]  $isAct"
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр не правильный]  $isAct"
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult
    }
}
