﻿
<#
.SYNOPSIS
 Подгрузка и выгрузка кустов реестра.

.DESCRIPTION
 Сделана для скрипта RepackWIMPS и AutoSettingsPS
 Корневой куст для подгрузки куста по умолчанию: HKLM. Можно указать HKU

 Используется winapi на C# вместо reg.exe
 Используется функция Token-Privileges для включения привилегий и подгрузки общего type

 Бывает блокируются хэндлы открытого куста, после использования команды создания разделов,
 или задержка при освобождении хэндлов, и не дает выгрузить куст.
 Этот момент учитывается, и используются дополнительные команды для освобождения хэндлов
 и выгрузки куста. Выполняются эти действия пока куст не будет выгружен.

.PARAMETER RegRoot
 Корневой раздел для подгрузки: HKLM или HKU. Нет разницы куда подгружать любой куст, но иногда нужно использовать конкретный раздел.

.PARAMETER SpecialPathLoad
 Указывает использовать только переданный префикс для создания подраздела для подгрузки
 Иначе используется сложение: префикс + имя файла и расширение

.PARAMETER Silent
 Указывает не выводить информации при выполнении, но возвращает 0 (без ошибок) или 1 (была ошибка).
 Так же всего 4 попытки выгрузки куста (вместо бесконечных), и если не получится, возврат 1


.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SOFTWARE" -Load

    Описание
    --------
    Подгрузит куст в HKLM\_TEMP_SOFTWARE

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SYSTEM" -SpecialPathLoad -Load

    Описание
    --------
    Подгрузит куст в HKLM\_TEMP_

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile "...\Offline\Windows\System32\config\SYSTEM" -Unload

    Описание
    --------
    Выгрузит куст HKLM\_TEMP_SYSTEM

.EXAMPLE
    RegHive-LoadUnload -RegPrefix '_TEMP_' -HiveFile '%UserProfile%\NTUSER.DAT' -RegRoot USERS -Unload

    Описание
    --------
    Выгрузит куст HKU\_TEMP_NTUSER.DAT


.NOTES
 ===================================================
     Автор:  westlife (ru-board)   Версия 1.0.2
      Дата:  20-02-2023
 ===================================================

#>
Function RegHive-LoadUnload {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [string] $RegPrefix
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1, ParameterSetName = 'Load' )]
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1, ParameterSetName = 'Unload' )]
        [string] $HiveFile
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Load' )]
        [switch] $Load
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Unload' )]
        [switch] $Unload
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'USERS', 'MACHINE' )]
        [string] $RegRoot = 'MACHINE'
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $SpecialPathLoad
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $Silent
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $RegPrefix -notmatch '^[\d\w-]+$' )
    {
        $Global:LastExitCode = 1

        if ( $Silent ) { Return }

        $text = if ( $L.s1 ) { $L.s1 } else { 'Неверный префикс' }
        Write-Warning "$NameThisFunction`: $text`: '$RegPrefix'"

        $text = if ( $L.s2 ) { $L.s2 } else { 'Должен соответствовать шаблону: ''^[\d\w-]+$'' (Буквы, цифры, символы: ''-'', ''_'')' }
        Write-Warning "$NameThisFunction`: $text"

        Return  # Выход из функции
    }

    $HiveFile = [System.Environment]::ExpandEnvironmentVariables($HiveFile)

    if ( $Load -and ( -not [System.IO.File]::Exists($HiveFile) ))
    {
        $Global:LastExitCode = 1

        if ( $Silent ) { Return }

        $text = if ( $L.s3 ) { $L.s3 } else { 'Не найден файл куста реестра' }
        Write-Host "    $NameThisFunction`: $text`: '$HiveFile'" -ForegroundColor DarkYellow

        Return   # Выход из функции
    }

    # Подключаем привилегии для доступа к файловой системе при любых настройках доступа.
    # 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege', 'SeSecurityPrivilege'. Реально тут нужны 2 и 3.
    Token-Privileges -Enable4Privileges # Подгружает общий type, и включает 4 привилегии только один раз, и запоминает, что включал

    if ( $SpecialPathLoad )
    {
        [string] $Subkey = $RegPrefix
    }
    else
    {
        if ( $Unload -and -not $HiveFile )
        {
            $Global:LastExitCode = 1

            if ( $Silent ) { Return }

            $text = if ( $L.s3_1 ) { $L.s3_1 } else { 'Не указан файл куст реестра' } # Без SpecialPathLoad Префикс складывается из префикса и имени файла куста
            Write-Host "    $NameThisFunction`: $text`: '$HiveFile'" -ForegroundColor DarkYellow

            Return   # Выход из функции
        }

        [string] $Subkey = '{0}{1}' -f $RegPrefix, [System.IO.Path]::GetFileName($HiveFile)
    }

    if ( $RegRoot -eq 'MACHINE' )
    {
        $Root     = [Microsoft.Win32.Registry]::LocalMachine
        $RootHive = [Microsoft.Win32.RegistryHive]::LocalMachine

        [string] $ShowPathLoad = "HKLM\$Subkey"
    }
    else
    {
        $Root     = [Microsoft.Win32.Registry]::Users
        $RootHive = [Microsoft.Win32.RegistryHive]::Users

        [string] $ShowPathLoad = "HKU\$Subkey"
    }

    if ( $Load )
    {
        if ( -not $Silent )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'Загрузка куста реестра' }
            Write-Host "    $text`: " -ForegroundColor Blue -NoNewline
            Write-Host "$($ShowPathLoad.PadRight(21,' ')) " -ForegroundColor White -NoNewline

            $text = if ( $L.s4_1 ) { $L.s4_1 } else { 'из' }
            Write-Host "| $text $HiveFile" -ForegroundColor DarkGray -NoNewline
        }

        [psobject] $SubKeyIn = $Root.GetSubKeyNames() -like $Subkey

        if ( $SubKeyIn )
        {
            $Global:LastExitCode = 0

            if ( $Silent ) { Return }

            $text = if ( $L.s5 ) { $L.s5 } else { 'Пропущено, по этому пути куст реестра уже подгружен!' }
            Write-Host " | $text" -ForegroundColor DarkGray
        }
        else
        {
            $Global:LastExitCode = [WinAPI.RegistryUtils]::LoadHive( $RootHive, $Subkey, $HiveFile )

            if ( $Global:LastExitCode )
            {
                if ( $Silent ) { Return }

                Write-Host "`n"

                $text = if ( $L.s6 ) { $L.s6 } else { 'Ошибка при загрузке куста' }
                Write-Warning "$NameThisFunction`: $text`: '$HiveFile' | Error: $Global:LastExitCode`n"
            }
            else
            {
                if ( $Silent ) { Return }

                Write-Host ' | ' -ForegroundColor DarkGray -NoNewline ; Write-Host '●' -ForegroundColor Green
            }
        }
    }
    else
    {
        [psobject] $SubKeyIn = $Root.GetSubKeyNames() -like $Subkey

        if ( $SubKeyIn )
        {
            if ( -not $Silent )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Выгрузка куста' }
                Write-Host "    $text`: " -ForegroundColor Blue -NoNewline
                Write-Host $ShowPathLoad -ForegroundColor White -NoNewline
            }

            [System.GC]::Collect([System.GC]::MaxGeneration, [System.GCCollectionMode]::Forced, $true)
            Start-Sleep -Milliseconds 10

            [WinAPI.RegistryUtils]::UnloadHive( $RootHive, $Subkey ) > $null

            $SubKeyIn = $Root.GetSubKeyNames() -like $Subkey

            if ( $SubKeyIn )
            {
                [int] $TryUnload = 0
                [int] $TrySilent = 0

                do
                {
                    $TryUnload++

                    if ( -not $Silent )
                    {
                        $text = if ( $L.s8 ) { $L.s8 } else { 'Повторная попытка выгрузки куста' }
                        Write-Host "`n    $text`: " -ForegroundColor DarkMagenta -NoNewline
                        Write-Host $ShowPathLoad -ForegroundColor White -NoNewline
                    }
                    else { $TrySilent = $TryUnload }

                    if ( $TryUnload -eq 2 ) { Stop-Process -Name regedit -Force -ErrorAction SilentlyContinue }

                    [System.GC]::Collect([System.GC]::MaxGeneration, [System.GCCollectionMode]::Forced, $true)

                    if ( $TryUnload -ge 3 )
                    {
                        if ( -not $Silent )
                        {
                            $text = if ( $L.s9 ) { $L.s9 } else { 'Что то блокирует куст, закройте все другие приложения!' }
                            Write-Host "`n      $text" -ForegroundColor Red -NoNewline
                        }

                        Start-Sleep -Milliseconds 1000
                    }
                    else
                    {
                        Start-Sleep -Milliseconds 300
                    }

                    [WinAPI.RegistryUtils]::UnloadHive( $RootHive, $Subkey ) > $null

                    $SubKeyIn = $Root.GetSubKeyNames() -like $Subkey
                }
                until ( -not $SubKeyIn -or $TrySilent -ge 3 )
            }

            if ( $Silent )
            {
                if ( $SubKeyIn -and $TrySilent -ge 3 )
                {
                    $Global:LastExitCode = 1
                }
                else
                {
                    $Global:LastExitCode = 0
                }

                Return
            }
            else
            {
                $Global:LastExitCode = 0

                Write-Host ' | ' -ForegroundColor DarkGray -NoNewline ; Write-Host '●' -ForegroundColor Green
            }
        }
        else
        {
            $Global:LastExitCode = 0

            if ( $Silent ) { Return }

            $text = if ( $L.s10 ) { $L.s10 } else { 'Куст реестра не подгружен' }
            Write-Host "    $NameThisFunction`: $text`: '$ShowPathLoad'" -ForegroundColor DarkGray
        }
    }
}
