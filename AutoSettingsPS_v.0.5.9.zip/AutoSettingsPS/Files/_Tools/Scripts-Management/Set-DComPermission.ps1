﻿
<#
.SYNOPSIS
 Добавление (замена), удаление или проверка разрешений доступов для DCOM.
 Для исправления ошибок доступов, отображающихся в журнале событий системы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Используется функция Set-Reg для установки параметров реестра в разделе для служб и драйверов, независимо от доступа.
 Используется функция Token-Impersonate для олицетворения за TrustedInstaller, если нет доступа для выполнения.
 Используется функция Set-OwnerAndAccess для получения и возврата доступа, если не помогло олицетворение.

 Выполняется получение Binary параметра из реестра найденного по AppID.
 Конвертирование его в SecurityDescriptor.
 Поиск в нём указанных разрешений с типом запрета для указанного SID.
 Добавление (если существует сначала удаляет), или Удаление, если указано удалить.
 Конвертирование изменённого SecurityDescriptor обратно в Binary,
 и замена на этот параметр в реестре через Set-Reg.

 Если AppID есть, а параметра нет, то будет создан базовый SecurityDescriptor и добавление к нему указанных доступов.

 Выполняется корректно, на сколько смог разобраться и воспроизвести необходимые действия в упрощенном виде,
 согласно требуемым правилам.
 Усложнять с разными вариациями небольших изменений без удалений 'Ace', с расчётом побитовых операций с масками для AccessMask не стал,
 не имеет смысла в контексте скрипта. Так как этой функции полностью достаточно для скрипта.

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать, не обязательный.
 Варианты:
 1. Set    = Только Выполнить (по умолчанию). Упрощенная функция, без проверки разрешений DCOM после выполнения.
 2. Check  = Только проверить.

.PARAMETER AppID
 AppID нужного COM-сервера.

.PARAMETER TypePermission
 Тип разрешений.
 LaunchPermission - Разрешения для Запуска и Активации. (обычно тут проблема) (Можно только: 'LocalLaunch', 'LocalActivation', 'RemoteLaunch', 'RemoteActivation')
 AccessPermission - Разрешения для Доступа.  (Можно только: 'LocalAccess', 'RemoteAccess')

.PARAMETER SIDs
 Массив SIDs пользователей или групп, для которых нужно настроить разрешения.

.PARAMETER AceType
 Тип разрешения: Запретить (Deni) или Разрешить (Allow).

.PARAMETER Permissions
 Список самих разрешений: LocalLaunch и т.д.

.PARAMETER Remove
 Выполняет удаление указанных SID из разрешений DCOM для AppID.

.EXAMPLE
    Set-DComPermission -AppID '{00000000-0000-0000-0000-000000000000}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-32-545' `
         -AceType 'AccessAllowed' -Permissions 'LocalLaunch','LocalActivation' -Do Check  -Verbose

    Описание
    --------
    Проверяет у DCOM для AppID разрешение для группы Пользователи на запуск и активацию.
    С Выводом подробных сведений.

.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 1.0
       Дата:  24-06-2019
 ==================================================

#>
Function Set-DComPermission {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [ValidatePattern( '^{[\w-]+}$' )]
        [string] $AppID
       ,
        [Parameter( Mandatory = $true,  Position = 1 )]
        [ValidateSet( 'LaunchPermission', 'AccessPermission' )]
        [Alias( 'Type' )]
        [string] $TypePermission
       ,
        [Parameter( Mandatory = $true,  Position = 2 )]
        [ValidateNotNullOrEmpty()]
        [string[]] $SIDs
       ,
        [Parameter( Mandatory = $true,  Position = 3 )]
        [System.Security.AccessControl.AceType] $AceType
       ,
        [Parameter( Mandatory = $true,  Position = 4, ParameterSetName = 'Add' )]
        [ValidateSet( 'LocalLaunch', 'LocalActivation', 'RemoteLaunch', 'RemoteActivation', 'LocalAccess', 'RemoteAccess' )]
        [string[]] $Permissions
       ,
        [Parameter( Mandatory = $true,  Position = 5, ParameterSetName = 'Remove' )]
        [switch] $Remove
       ,
        [Parameter( Mandatory = $false, Position = 6 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Do -eq 'Default' ) { $Do = 'Set' }

    # Права доступа для AccessMask для побитового сложения или вычитания.
    [Uint16] $RIGHTS_EXECUTE         = 1
    [Uint16] $RIGHTS_EXECUTE_LOCAL   = 2
    [Uint16] $RIGHTS_EXECUTE_REMOTE  = 4
    [Uint16] $RIGHTS_ACTIVATE_LOCAL  = 8
    [Uint16] $RIGHTS_ACTIVATE_REMOTE = 16

    Write-Verbose "Открываем раздел реестра с AppID: '$AppID'"
    try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey("AppID\$AppID",'ReadSubTree','QueryValues') }
    catch { [psobject] $OpenSubKey = $null }

    $text = if ( $L.s1 ) { $L.s1 } else { 'AppID не найден' }
    if ( -not $OpenSubKey ) { Write-Warning "$NameThisFunction`: $text`: '$AppID'" ; Return }

    Write-Verbose "Получаем Binary параметр доступа: '$TypePermission'"
    try
    {
        [Byte[]] $BinaryValue = $OpenSubKey.GetValue($TypePermission,$null)
        [string] $NameAppID = $OpenSubKey.GetValue('',$null)

        $OpenSubkey.Close()
    }
    catch { [Byte[]] $BinaryValue = $null }

    Write-Verbose 'Конвертируем полученный параметр Binary в SecurityDescriptor'
    try { [psobject] $SecDesc = [System.Security.AccessControl.RawSecurityDescriptor]::new($BinaryValue, 0) }
    catch
    {
        Write-Verbose 'Создание нового SecurityDescriptor с правами По умолчанию, так как не получен у AppID'
        [Uint16] $Revision = 2
        [psobject] $SecDesc = [System.Security.AccessControl.RawSecurityDescriptor]::new(
            ([System.Security.AccessControl.ControlFlags]::DiscretionaryAclPresent, [System.Security.AccessControl.ControlFlags]::SelfRelative),
            'S-1-5-18', 'S-1-5-18', $null, [System.Security.AccessControl.RawAcl]::new($Revision,1))
    }

    Write-Verbose 'Создние параметра AccessMask для ACE (параметры доступа для Acl)'

    [Uint16] $AccessMask = $RIGHTS_EXECUTE

    # Для Запуска и активации возможны 4 вида параметра, для Доступа только 2 параметра.
    if ( $TypePermission -eq 'LaunchPermission' )
    {
        if ( $Permissions -contains 'LocalLaunch'      ) { $AccessMask = $AccessMask -bor $RIGHTS_EXECUTE_LOCAL   }
        if ( $Permissions -contains 'RemoteLaunch'     ) { $AccessMask = $AccessMask -bor $RIGHTS_EXECUTE_REMOTE  }
        if ( $Permissions -contains 'LocalActivation'  ) { $AccessMask = $AccessMask -bor $RIGHTS_ACTIVATE_LOCAL  }
        if ( $Permissions -contains 'RemoteActivation' ) { $AccessMask = $AccessMask -bor $RIGHTS_ACTIVATE_REMOTE }
    }
    else
    {
        if ( $Permissions -contains 'LocalAccess'      ) { $AccessMask = $AccessMask -bor $RIGHTS_EXECUTE_LOCAL   }
        if ( $Permissions -contains 'RemoteAccess'     ) { $AccessMask = $AccessMask -bor $RIGHTS_EXECUTE_REMOTE  }
    }

    if (( -not $Remove ) -and ( $AccessMask -eq 1 ))
    {
        $text = "$NameThisFunction`: {0}:`n  '$($Permissions -join ', ' )'`n  {1}: '$TypePermission'" -f
            $(if ( $L.s2 ) { $L.s2, $L.s2_1 } else { 'Пропуск, неправильно указаны параметры доступа', 'Для типа' })

        Write-Warning "$text"

        Return
    }

    Write-Verbose 'Поиск существующих SID (ACE) в параметре ACL'

    # Получаем Acl (Разрешения) из SecurityDescriptor.
    [psobject] $Acl = $SecDesc.DiscretionaryAcl

    [bool] $ResultFunc = $true

    # Для каждого указанного SID.
    foreach ( $SID in $SIDs ) {

        [bool] $Found = $false

        try
        {
            [System.Security.Principal.SecurityIdentifier] $SIDid = $SID
            ($SIDid).Translate([System.Security.Principal.NTAccount]) *> $null
        }
        catch
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'SID не преобразуется в NTAccount' }
            Write-Warning "$NameThisFunction`: $text`: '$SID'"
            Continue
        }

        if ( $Do -eq 'Set' )
        {
            Write-Verbose "Создаём новый Ace (Разрешение) для SID: '$SID', с типом: '$AceType'"

            [psobject] $Ace = [System.Security.AccessControl.CommonAce]::new(
                [System.Security.AccessControl.AceFlags]::None,
                [System.Security.AccessControl.AceQualifier] $AceType.value__,
                $AccessMask, $SIDid, $false, $null)
        }

        # Поиск Ace в Acl с SID и типом доступа, и удаление, если найден, для возможности добавить SID с нужными правами.
        for ( $item = 0 ; $item -lt $Acl.Count ; $item++ ) {

            $FoundAce = $Acl[$item]

            # Если Ace совпадает с SID и типом доступа.
            if (( $FoundAce.SecurityIdentifier -eq $SIDid ) -and ( $FoundAce.AceType -eq $AceType )) {

                Write-Verbose "Найден в Acl SID: '$SID', с типом: '$AceType'"

                # Если только проверка.
                if ( $Do -eq 'Check' )
                {
                    # Если битовая Маска разрешений не сопадает или была команда удалить Доступ для SID с этим типом доступа,
                    # то Задать что не соответствует.
                    if (( $FoundAce.AccessMask -ne $AccessMask ) -or $Remove ) { $ResultFunc = $false }
                    else { Write-Verbose "Параметр доступа для AccessMask верный: '$AccessMask'" }
                }
                else
                {
                    Write-Verbose "Удаляем найденый в Acl SID: '$SID', с типом: '$AceType'"

                    # Иначе выполнить удлание этого Ace.
                    $Acl.RemoveAce($item)
                }

                # Был найден SID с типом доступа.
                $Found = $true
                break
            }
        }

        # Если нужно добавить/заменить доступ для SID
        if ( -not $Remove )
        {
            if ( -not $Found )
            {
                Write-Verbose "Не было в Acl SID: '$SID', с типом: '$AceType'"

                if ( $Do -eq 'Check' ) { $ResultFunc = $false }
            }

            if ( $Do -eq 'Set' )
            {
                Write-Verbose "Добавление в Acl SID: '$SID', с типом: '$AceType'"

                # Если Разрешение на доступ, то добавление в конец массива Acl,
                # иначе в начало, так как запреты должны быть перед разрешениями в записях Acl.
                if ( $AceType -eq 'AccessAllowed' ) { $Acl.InsertAce($Acl.Count, $Ace) }
                else { $Acl.InsertAce(0, $Ace)  }
            }
        }
        else
        {
            # Иначе нужно было удаление, поэтому пропускаем добавление.

            if ( $Found ) { Write-Verbose "Удалён ACE из Acl с SID: '$SID', и типом: '$AceType'" }
            else { Write-Verbose "ACE в Acl не найден с SID: '$SID', и типом: '$AceType'" }
        }
    }

    # Если нужно выполнить действие.
    if ( $Do -eq 'Set' )
    {
        Write-Verbose 'Конвертируем Acl обратно в массив binary для параметра реестра.'

        $SecDesc.DiscretionaryAcl = $Acl
        [byte[]] $SecDescBytes = New-Object -TypeName 'byte[]' -ArgumentList $SecDesc.BinaryLength
        $SecDesc.GetBinaryForm($SecDescBytes, 0)

        [string] $Path  = "Registry::HKCR\AppID\$AppID"
        [string] $Name  = $TypePermission
        [byte[]] $Value = $SecDescBytes

        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type Binary $Value -Verbose:$false
    }
    else
    {
        # Иначе была только проверка.

        if ( -not $ResultFunc )
        {
            # Задаём глобальную переменную сообщающую о несоответствии команде, и необходимости исправления.
            $NeedFix = $true

            $text = if ( $L.s3 ) { $L.s3 } else { '    Неверно' }
            Write-Host "!!!: Check: $text " -ForegroundColor Yellow -NoNewline
            Write-Host '     DCOM ' -ForegroundColor White -NoNewline

            $text = "| {0}: '$NameAppID' AppID: {$AppID} {1}: '$TypePermission' SIDs: $($SIDs -join ', ')" -f
                $(if ( $L.s5 ) { $L.s5, $L.s5_1 } else { 'Имя', 'Тип' })

            Write-Host "$text" -ForegroundColor Gray
        }
        else
        {
            $text = if ( $L.s4 ) { $L.s4 } else { '      Верно' }
            Write-Host "  +: Check: $text " -ForegroundColor Green -NoNewline
            Write-Host '     DCOM ' -ForegroundColor White -NoNewline

            $text = "| {0}: '$NameAppID' AppID: {$AppID} {1}: '$TypePermission' SIDs: $($SIDs -join ', ')" -f
                $(if ( $L.s5 ) { $L.s5, $L.s5_1 } else { 'Имя', 'Тип' })

            Write-Host "$text" -ForegroundColor DarkGray
        }
    }
}
