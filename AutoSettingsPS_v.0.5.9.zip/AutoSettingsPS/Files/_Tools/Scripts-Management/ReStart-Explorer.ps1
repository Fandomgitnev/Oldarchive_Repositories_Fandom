﻿
<#
.SYNOPSIS
 Перезапуск/Запуск или остановка процесса Проводника.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Корректная остановка процесса проводника ("Gracefully" - с сохранением текущих данных)

 Запоминает открытые окна проводника перед их закрытием,
 и открывает их в свёрнутом виде после перезапуска, или остановки и затем запуска.
 Понимает все типы путей открытых окон, с поддержкой в путях кириллицы, спецсимволов и пробелов.

.PARAMETER Stop
 Остановить процесс проводника.

.PARAMETER Retry
 Используется только внутри самой себя, если вдруг процесс не завершился с параметром Stop.
 Для повторной попытки.

.PARAMETER DoNotOpenWindows
 Не открывать закрытые окна проводника.

.EXAMPLE
    ReStart-Explorer

    Описание
    --------
    Запуск или перезапуск проводника. Зависит от ситуации.

.EXAMPLE
    ReStart-Explorer -Stop -Verbose

    Описание
    --------
    Остановка процесса проводника, если он существует.
    С отображением происходящих действий.


.NOTES
 ====================================================
      Автор:  westlife (ru-board)  Версия: 2.0.1
       Дата:  09-04-2023
 ====================================================

#>
Function ReStart-Explorer {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    Param (
        [Parameter( Mandatory = $false, ParameterSetName = 'Stop', Position = 0 )]
        [switch] $Stop
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Stop' )]
        [switch] $Retry
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'DoNotOpen' )]
        [switch] $DoNotOpenWindows
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Close' )]
        [switch] $OnlyCloseWindows
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Open' )]
        [switch] $OnlyOpenWindows
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Lock' )]
        [switch] $LockSetForeground
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'UnLock' )]
        [switch] $UnLockSetForeground
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'UnLockA' )]
        [switch] $UnLockSetForegroundAsync
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'UnLockA' )]
        [int] $UnLockDelayMS = 5000
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Lock' )]
        [Parameter( Mandatory = $false, ParameterSetName = 'UnLock' )]
        [Parameter( Mandatory = $false, ParameterSetName = 'UnLockA' )]
        [switch] $SetFocusToCurrentWindow
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    [string] $WinAPIExplorer = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace WinAPI
{
    public static class Explorer
    {
        [DllImport( "user32.dll", CharSet = CharSet.Unicode )]
        private static extern uint RealGetWindowClass(IntPtr hWnd, StringBuilder strText, uint maxCount);

        [DllImport( "user32.dll", CharSet = CharSet.Unicode )]
        private static extern int PostMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam); // async

        [DllImport("user32.dll", CharSet = CharSet.Unicode )]
        private static extern int SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam); // sync

        [DllImport( "user32.dll", CharSet = CharSet.Unicode )]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport( "user32.dll" )]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool LockSetForegroundWindow(uint uLockCode);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
        
        [DllImport("user32.dll", CharSet = CharSet.Unicode )]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, int dwExtraInfo);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId); // uint

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool FlashWindow(IntPtr hwnd, bool bInvert);

        public static Queue<string> CloseOpenWindows(bool outPaths = false)
        {
            Queue<string> ListPaths = new Queue<string>();
            Queue<object> closeWindowItems = new Queue<object>();
            object shellApplication = null;

            try
            {
                Guid CLSID_ShellApplication = new Guid("13709620-C279-11CE-A49E-444553540000");
                Type shellApplicationType = Type.GetTypeFromCLSID(CLSID_ShellApplication, true);

                shellApplication = Activator.CreateInstance(shellApplicationType);

                object windows = shellApplicationType.InvokeMember("Windows", BindingFlags.InvokeMethod, null, shellApplication, new object[] { });

                Type windowsType = windows.GetType();
                int count = (int)windowsType.InvokeMember("Count", BindingFlags.GetProperty, null, windows, null);

                for (int i = 0; i < count; i++)
                {
                    object item = windowsType.InvokeMember("Item", BindingFlags.InvokeMethod, null, windows, new object[] { i });
                    if ( item == null ) { continue; } // Перейти к следующему для пропуска пустого объекта, чтобы не выкидывало из дальнейшего перебора

                    closeWindowItems.Enqueue(item); // add
                    if (!outPaths) { continue; } // Перейти к следующему, если только закрыть окна

                    Type itemType = item.GetType();
                    object document = itemType.InvokeMember("Document", BindingFlags.GetProperty, null, item, null);

                    Type DocumentType = document.GetType();
                    object folder = DocumentType.InvokeMember("Folder", BindingFlags.GetProperty, null, document, null);

                    Type FolderType = folder.GetType();
                    object self = FolderType.InvokeMember("Self", BindingFlags.GetProperty, null, folder, null);

                    Type SelfType = self.GetType();
                    string path = (string)SelfType.InvokeMember("Path", BindingFlags.GetProperty, null, self, null);

                    if (!string.IsNullOrWhiteSpace(path) && !ListPaths.Contains(path)) { ListPaths.Enqueue(path); } // add
                }

                while(closeWindowItems.Count > 0)
                {
                    object item = closeWindowItems.Dequeue(); // берёт первый из очереди, удаляя его
                    item.GetType().InvokeMember("Quit", BindingFlags.InvokeMethod, null, item, null);
                }
            }
            catch (Exception) {}

            return ListPaths;
        }

        private const uint WM_EXITEXPLORER = 0x5b4; // WM_USER = 0x400; + 0x1b4 = 1460 (0x5b4)

        private static string GetWindowClass(IntPtr hWnd)
        {
            StringBuilder wndClass = new StringBuilder(255);
            RealGetWindowClass(hWnd, wndClass, 255);

            return (wndClass.ToString().ToUpper());
        }

        private static void StopSearchHost()
        {
            Process[] procs = Process.GetProcessesByName("SearchHost");

            for (int i = 0; i < procs.Length; i++)
            {
                try { procs[i].Kill(); } catch (Exception) {} // при попытке Kill() для завершающегося процесса может выкинуть отказ доступа.
                procs[i].WaitForExit(100);
                procs[i].Close();
            }
        }

        private static void CloseExplorer()
        {
            Process[] procs = GetExplorerProcesses();
            string wndClass = null;
            IntPtr hWnd = IntPtr.Zero;

            StopSearchHost();

            for (int i = 0; i < procs.Length; i++)
            {
                hWnd = procs[i].MainWindowHandle;
                wndClass = GetWindowClass(hWnd);

                if (wndClass.Equals("SHELL_TRAYWND"))
                {
                    PostMessage(hWnd, WM_EXITEXPLORER, IntPtr.Zero, IntPtr.Zero);
                    procs[i].WaitForExit(1000); // важно! самое долгое, 500-1000мс закрывается процесс
                }

                procs[i].Close();
            }

            int n = 0; bool stopAll = false;

            do
            {
                n++;

                procs = GetExplorerProcesses(); // важно! после WM_EXITEXPLORER

                for (int i = 0; i < procs.Length; i++)
                {
                    hWnd = procs[i].MainWindowHandle;
                    wndClass = GetWindowClass(hWnd);

                    if (!wndClass.Equals("SHELL_TRAYWND") || stopAll)
                    {
                        try { procs[i].Kill(); } catch (Exception) {} // при попытке Kill() для завершающегося процесса может выкинуть отказ доступа.
                        procs[i].WaitForExit(100);
                    }

                    procs[i].Close();
                }

                if (!stopAll && procs.Length == 1 && wndClass.Equals("SHELL_TRAYWND")) { stopAll = true; n = 9; Thread.Sleep(1000); }
            }
            while ((procs).Length > 0 && n < 10);
        }

        private static int LockNum = 0; // номер блокировки перехвата фокуса (установки приложениями своего окна активным)

        public static void LockSetForeground()
        {
            LockNum++;
            LockSetForegroundWindow(1); // uint LSFW_LOCK = 1
        }

        public static void UnLockSetForeground()
        {
            if (LockNum == 0) { return; }
            LockSetForegroundWindow(2); LockNum = 0; // uint LSFW_UNLOCK = 2
        }

        public static async void UnLockSetForegroundAsync(int delay = 5000)
        {
            if (LockNum == 0) { return; }
            int curLockNum = LockNum; // для отмены этой разблокировки, если была снова вызвана блокировка, до выполнения этой
            await Task.Run(() =>
            {
                Thread.Sleep(delay);
                if (curLockNum == LockNum) { LockSetForegroundWindow(2); LockNum = 0; } // uint LSFW_UNLOCK = 2
            });
        }

        public static Process[] GetExplorerProcesses()
        {
            Process[] procs = Process.GetProcessesByName("explorer");

            return (procs);
        }

        public static Queue<string> ExitExplorer(bool outPaths = false)
        {
            Queue<string> paths = CloseOpenWindows(outPaths);
            CloseExplorer();

            return (paths);
        }

        public static bool StartExplorerShell()
        {
            bool isStarted = false;
            
            if (FindWindow("SHELL_TRAYWND", (string) null) == IntPtr.Zero)
            {
                UnLockSetForeground();

                try { Process.Start("explorer.exe", " /LOADSAVEDWINDOWS"); } catch (Exception) {}
                
                Thread.Sleep(500); // лучше ничего не делать так как: "Progman" (Desktop) стартует = < 100ms; "SystemTray_Main" (tray, уже с таскбаром) стартует = ~600ms
                int n = 0;
                while (FindWindow("SystemTray_Main", (string) null) == IntPtr.Zero && n < 100) // 100 * Sleep(30) реально = ~3,6 сек максимального ожидания
                {
                    n++; Thread.Sleep(30);
                }

                if ( n == 100 ) { isStarted = false; } else { isStarted = true; Thread.Sleep(200); }
            }

            return isStarted;
        }

        private static bool SkipSetFocus = false; // параметр для разового пропуска перехвата фокуса 

        public static void SkipSetFocusOnce()
        {
            SkipSetFocus = true;
        }

        // Установка фокуса если проводник или uwp перехватили/вылезли на передний план, иначе только мигание иконки на таскбаре
        public static void SetFocusToCurrentWindow(bool onlyBlink = false)
        {
            if (SkipSetFocus) { SkipSetFocus = false; return; }

            Process proc = Process.GetCurrentProcess();
            IntPtr hWndActive = IntPtr.Zero, hWnd = proc.MainWindowHandle; proc.Close();
            bool isFocus = false, bOut = false;
            string procName = String.Empty;

            int count = 0, id = 0, n = 0;

            do
            {
                count++;

                hWndActive = GetForegroundWindow();

                if ( hWnd != hWndActive )
                {
                    if (onlyBlink) { bOut = FlashWindow(hWnd, false); return; } // только мигание иконки на таскбаре

                    id = 0; n = 0;

                    try {
                        GetWindowThreadProcessId(hWndActive, out id);
                        proc = Process.GetProcessById(id);
                        procName = proc.ProcessName.ToUpper(); proc.Close();
                    } catch (Exception) {}

                    if (Regex.IsMatch(procName, "^(SEARCHHOST|SHELLEXPERIENCEHOST)$"))
                    {
                        SendMessage(hWndActive, 0x0010, IntPtr.Zero, IntPtr.Zero); // sync (WM_CLOSE)
                    
                        Thread.Sleep(200);
                        do { n++; Thread.Sleep(20); keybd_event(0,0,0,0); isFocus = SetForegroundWindow(hWnd); }
                        while (!isFocus && n < 25); // 25 = 500ms при 20  // закрыть окно и сделать активным, так как блокирует смену фокуса
                    }
                    else if (Regex.IsMatch(procName, "^(|IDLE|EXPLORER|APPLICATIONFRAMEHOST)$" )) // if null, or IDLE (null), or ...
                    {
                        do { n++; Thread.Sleep(20); keybd_event(0,0,0,0); isFocus = SetForegroundWindow(hWnd); }
                        while (!isFocus && n < 10);  // только сделать активным, если не сможет тоже будет мигать иконка
                    }
                    else { bOut = FlashWindow(hWnd, false); isFocus = true; }

                    if (!isFocus && count == 1 && procName.Equals("SEARCHHOST"))
                    {
                        StopSearchHost();
                    }
                }
                else { isFocus = true; }
            }
            while (!isFocus && count < 2); // 2 раза максимум. Второй раз нужен только если SearchHost.exe заблокировал фокус, и попытаться вернуть фокус после его остановки
        }
    }
}
'@
    if ( -not ( 'WinAPI.Explorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $WinAPIExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    if ( $LockSetForeground )
    {
        Write-Verbose 'Блокировка установки активного окна приложениями'

        if ( $SetFocusToCurrentWindow )
        {
            [WinAPI.Explorer]::SetFocusToCurrentWindow() # сделать окно активным на переднем плане (Z положение), если фокус у UWP или проводника
        }

        [WinAPI.Explorer]::LockSetForeground()

        return
    }
    elseif ( $UnLockSetForeground )
    {
        Write-Verbose 'Снятие блокировки установки активного окна приложениями'

        [WinAPI.Explorer]::UnLockSetForeground()

        if ( $SetFocusToCurrentWindow )
        {
            [WinAPI.Explorer]::SetFocusToCurrentWindow() # сделать окно активным на переднем плане (Z положение), если фокус у UWP или проводника
        }

        return
    }
    elseif ( $UnLockSetForegroundAsync )
    {
        Write-Verbose 'Снятие блокировки установки активного окна приложениями асинхронно с задержкой'

        [WinAPI.Explorer]::UnLockSetForegroundAsync($UnLockDelayMS)

        if ( $SetFocusToCurrentWindow )
        {
            [WinAPI.Explorer]::SetFocusToCurrentWindow() # сделать окно активным на переднем плане (Z положение), если фокус у UWP или проводника
        }

        return
    }

    if ( -not ( Get-Variable -Name OpenedFolders -Scope Global -ErrorAction SilentlyContinue ))
    {
        Set-Variable -Name OpenedFolders -Value ([System.Collections.Queue] @()) -Scope Global -Option AllScope -Force -ErrorAction SilentlyContinue
    }

    if ( -not $OnlyOpenWindows )  
    {
        # Если есть процессы с именем Explorer.
        if ( @([WinAPI.Explorer]::GetExplorerProcesses()).Length )
        {
            if ( $OnlyCloseWindows )
            {
                Write-Verbose 'Только закрываем открытые окна с сохранением путей'

                if ( -not @($Global:OpenedFolders).Count )
                {
                    # Закрыть окна и сохранить их пути
                    try { $Global:OpenedFolders = [WinAPI.Explorer]::CloseOpenWindows($true) } catch {}
                }
                else
                {
                    # Закрыть окна
                    try { [WinAPI.Explorer]::CloseOpenWindows() } catch {}
                }

                Return
            }
            else
            {
                Write-Verbose 'Завершаем процесс Проводника'

                if ( -not $Retry )
                {
                    if ( -not @($Global:OpenedFolders).Count )
                    {
                        Write-Verbose 'Сохраняем все открытые окна Проводника'

                        # Закрыть окна, Вывести их пути, и Завершить работу проводника, с сохранением данных.
                        try { $Global:OpenedFolders = [WinAPI.Explorer]::ExitExplorer($true) } catch {}
                    }
                    else
                    {
                        Write-Verbose 'Без сохранения открытых окон Проводника'

                        # Закрыть окна и Завершить работу проводника, с сохранением данных.
                        try { [WinAPI.Explorer]::ExitExplorer($false) } catch {}
                    }
                }
                else
                {
                    Write-Verbose 'Retry | Без сохранения открытых окон Проводника'

                    # Закрыть окна и Завершить работу проводника, с сохранением данных.
                    try { [WinAPI.Explorer]::ExitExplorer($false) } catch {}
                }

                if ( $Stop )
                {
                    # Если процесс проводника все еще существует, вывести предупреждение и еще раз перезапустить, для очень не стандартных ситуаций
                    if ( @([WinAPI.Explorer]::GetExplorerProcesses()).Length )
                    {
                        if ( -not $Retry )
                        {
                            Write-Host "$NameThisFunction`: Explorer process exit error" -ForegroundColor DarkGray

                            # Повторный перезапуск/закрытие проводника при проблеме
                            ReStart-Explorer -Stop -Retry
                        }
                        else
                        {
                            Write-Host "$NameThisFunction`: Explorer process exit error" -ForegroundColor DarkYellow
                        }
                    }
                }
            }
        }
        else
        {
            Write-Verbose 'Нет процессов Проводника'

            if ( $OnlyCloseWindows ) { Return }
        }
    }

    # Если не указано остановить процесс, выполняем запуск проводника, повторяя, пока не запустится.
    if ( -not $Stop )
    {
        Write-Verbose 'Указано запустить Проводник после его завершения'
        Write-Verbose 'Запускаем Shell Проводника текущего пользователя, пока не будет запущен'
        [bool] $isStarted = [WinAPI.Explorer]::StartExplorerShell()  # ждёт не дольше 3,6 сек, и ничего не делает, если оболочка (трей/рабстол) уже запущена

        if ( -not $DoNotOpenWindows -and $Global:OpenedFolders.Count )
        {
            Write-Verbose 'Открываем обратно все открытые папки в свёрнутом виде'

            if ( $isStarted ) { Write-Host "`n   ReStart-Explorer: true" -ForegroundColor DarkGray } else { Write-Host }

            [WinAPI.Explorer]::SetFocusToCurrentWindow()
            [WinAPI.Explorer]::LockSetForeground() # Запрет перехвата фокуса при запуске окон проводника, особенно важно на W11 22621

            $StartInfo = [System.Diagnostics.ProcessStartInfo]::new("$env:windir\explorer.exe")
            $StartInfo.WindowStyle = 'Minimized'

            while ( $Global:OpenedFolders.Count )
            {
                $OpenedFolder = $Global:OpenedFolders.Dequeue() # Берёт первый из очереди и удаляет его, обнулять переменную не нужно

                if ( $OpenedFolder -like '::{*}' )
                {
                    $OpenedFolder = "shell:$OpenedFolder"
                    # Открывает пути вида: Shell:::{GUID}
                    $StartInfo.Arguments = "/n,""$OpenedFolder"""
                    try { $Process = [System.Diagnostics.Process]::Start($StartInfo) ; $Process.Close() } catch {}
                }
                elseif ( [System.IO.Directory]::Exists($OpenedFolder) )
                {
                    # Открывает пути с поддержкой в путях кириллицы, спецсимволов и пробелов
                    $StartInfo.Arguments = "/n,""$OpenedFolder"""
                    try { $Process = [System.Diagnostics.Process]::Start($StartInfo) ; $Process.Close() } catch {}
                }
                
                Write-Host "   ReStart-Explorer: Open: $OpenedFolder" -ForegroundColor DarkGray

                if ( $Global:OpenedFolders.Count ) # Пока ещё есть папки для открытия
                {
                    # На W11 22621 некоторые из группы окон стартуют с багом (маленького размера) если быстро их открывать подряд, новый убогий UWP проводник тупит, 500ms не всегда достаточно, да 800 хз.
                    if ( [System.Environment]::OSVersion.Version.Build -ge 22621 ) { Start-Sleep -Milliseconds 800 }
                }
            }

            Write-Host
            [WinAPI.Explorer]::UnLockSetForegroundAsync(5000)
        }

        # Доп. задержка для W11 к 200ms, так как тяжело выполнятся командам скрипта далее во время запуска проводника
        if ( $isStarted -and ( [System.Environment]::OSVersion.Version.Build -ge 22621 )) { Start-Sleep -Milliseconds 1000 }
    }
    else { Write-Verbose 'Процесс Проводника остановлен' }
}
