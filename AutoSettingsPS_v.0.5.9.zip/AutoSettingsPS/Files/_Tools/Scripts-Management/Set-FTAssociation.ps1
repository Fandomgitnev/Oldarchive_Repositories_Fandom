﻿
<#
.SYNOPSIS
 Функция для назначения файловых ассоциаций, с возможностью регистрации программы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Поддержка от Windows 10 17763 x64/x86 (1809)

 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Token-Privileges для включения привилегий и подгрузки общего type

 Корректное назначение, с правильной генерацией Hash и установкой запрета доступа на изменение на раздел реестра расширения.
 После назначения не предлагается выбрать приложение при открытии файла.
 Возможна Регистрация портабельной программы, если указать путь вместо ProgId.
 Без использования утилит.
 Поддерживаются системные переменные в пути к файлам, например: %ProgramFiles(x86)% или %SystemDrive%


.PARAMETER Extension
 Указать расширение или протокол

.PARAMETER ProgId
 Можно указать ID программы для расширения. Его нужно знать. ID существует если приложение установлено и было назначено хотябы один раз.
 У каждой программы и под каждое расширение ID может отличаться.
 Или указать путь до портабельной программы для полной регистрации.
 В этом случае при регистрации генерируется всего 6 видов ProgID: [Имя файла exe].[Тип программы][Тип ассоциации],
 пример: Thebat64.MAILPROTOCOLS, Firefox.WEBFILES, FSViewer.FILES
 Путь к программе указывать в кавычках, если есть пробелы.

.PARAMETER Icon
 Указать иконку для конкретного расширения, только если указан путь до программы, чтобы можно было сгенерировать правильный ProgId
 При указании пути до портабельного браузера будет только одна иконка, вот для этих протоколов/расширений: http/https/ftp/.htm/.html/.shtml/.xht/.xhtml
 Если вы сами указываете ProgId и один на все расширения, то указанная иконка будет одна на все файлы назначенные на этот ProgId, которая была назначена последней.
 Путь к иконке всегда указывать в кавычках, если есть пробелы или указан индекс иконки через запятую.
 Чтобы удалить ошибочно назначенную иконку, применить повторно без указания иконки

.EXAMPLE
    Set-FTAssociation -Extension .txt -ProgPath "%ProgramFiles(x86)%\AkelPad\AkelPad.exe" -Icon "%ProgramFiles(x86)%\AkelPad\AkelPad.exe,0"

.EXAMPLE
    Set-FTAssociation .inf Applications\AkelPad.exe

.EXAMPLE
    Set-FTAssociation .jpg PhotoViewer.FileAssoc.Jpeg  # Если восстановлен PhotoViewer

.EXAMPLE
    Set-FTAssociation -Protocol http -ProgId IE.HTTP  # Установка на открытие протокола http через IE

.EXAMPLE
    Set-FTAssociation https IE.HTTPS
    Set-FTAssociation http  IE.HTTP
    Set-FTAssociation .html IE.AssocFile.HTM
    Set-FTAssociation .htm  IE.AssocFile.HTM

    Set-FTAssociation http  -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe" -Web
    Set-FTAssociation https -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe" -Web
    Set-FTAssociation .html -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe" -Web
    Set-FTAssociation .htm  -ProgPath "C:\Firefox.ESR.x64.LibPortablePlus\core\firefox.exe" -Web

    Set-FTAssociation .jpg  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .jpeg -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .jpe  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .bmp  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .dib  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .png  -ProgPath "C:\FSViewer75\FSViewer.exe" -Icon "C:\FSViewer75\FSViewer.exe,0"

    Set-FTAssociation .tif  "C:\FSViewer75\FSViewer.exe" "C:\FSViewer75\FSViewer.exe,0"
    Set-FTAssociation .tiff "C:\FSViewer75\FSViewer.exe" "C:\FSViewer75\FSViewer.exe,0"

    Set-FTAssociation .inf Applications\AkelPad.exe
    Set-FTAssociation .csv Applications\AkelPad.exe
    Set-FTAssociation .txt Applications\AkelPad.exe
    Set-FTAssociation .ini Applications\AkelPad.exe

    Set-FTAssociation .cab CABFolder
    Set-FTAssociation .cab CABFolder -Icon "%SystemRoot%\system32\cabview.dll,0"

    # Для открытия через Microsoft.Windows.Photos
    Set-FTAssociation .bmp -ProgId AppX43hnxtbyyps62jhe9sqpdzxn1790zetc
    Set-FTAssociation .bmp -ProgId AppX43hnxtbyyps62jhe9sqpdzxn1790zetc -Unregister

    # Если уже был назначен хотябы один раз Windows, иначе надо настраивать с путями к exe, как с портабл программами
    Set-FTAssociation http MSEdgeHTM
    Set-FTAssociation https MSEdgeHTM
    Set-FTAssociation .htm MSEdgeHTM
    Set-FTAssociation .html MSEdgeHTM

    Set-FTAssociation mailto "C:\TheBat!\thebat64.exe" -Mail
    Set-FTAssociation .eml   "C:\TheBat!\thebat64.exe" -Mail
    Set-FTAssociation .msg   "C:\TheBat!\thebat64.exe" -Mail
    Set-FTAssociation .xpi   "C:\TheBat!\thebat64.exe" -Mail
    Set-FTAssociation .ics   "C:\TheBat!\thebat64.exe" -Mail
    Set-FTAssociation .mbox  "C:\TheBat!\thebat64.exe" -Mail

    Set-FTAssociation .mbox  "C:\TheBat!\thebat64.exe" -Unregister


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.3
      инфо:  За основу взяты скрипты: https://github.com/DanysysTeam/PS-SFTA | https://github.com/default-username-was-already-taken/set-fileassoc
      Дата:  20-02-2023
 =================================================

#>
Function Set-FTAssociation {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'Web' )]
    Param(
        [Parameter( Mandatory = $false, Position = 0 )]
        [Alias( 'Protocol' )]
        [String] $Extension
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        [Alias( 'ProgPath' )]
        [String] $ProgId
       ,
        [Parameter( Mandatory = $false, Position = 2 )]
        [String] $Icon
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Web' )]
        [switch] $Web
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Mail' )]
        [switch] $Mail
       ,
        [Parameter( Mandatory = $false )]
        [switch] $Unregister
    )

    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    if ( $Unregister )
    {
        if ( -not $ProgId )
        { Write-Host "`n   $NameThisFunction`: You must specify the ProgID and Extension or Path to file exe" -ForegroundColor DarkYellow ; Return }

        # Глобальное Отключение разрешения перенаправления для настройки реестра у дефолтного профиля, если он настраивается
        @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $false })

        if ( $ProgId.Contains(':') -and $ProgId.EndsWith('.exe', 'OrdinalIgnoreCase') )
        {
            [string] $FileEXE = [System.IO.Path]::GetFileName($ProgId) -Replace ('\s','')

            $FileEXE  = '{0}{1}' -f $FileEXE.Substring(0, 1).ToUpperInvariant(), $FileEXE.Remove(0, 1)
            $FileName = [System.IO.Path]::GetFileNameWithoutExtension($FileEXE)

            $ProgFullName = "$FileName Portable"

            Write-Host "`n   $NameThisFunction`: Unregister: $ProgFullName" -ForegroundColor Magenta

            foreach ( $RegRoot in @('HKCU:','HKLM:') )
            {
                $Path = "$RegRoot\Software\Clients\StartMenuInternet\$ProgFullName"
                Set-Reg Remove-Item -Path $Path

                $Path = "$RegRoot\Software\Clients\Mail\$ProgFullName"
                Set-Reg Remove-Item -Path $Path

                $Path = "$RegRoot\Software\PortableProgram\$ProgFullName"
                Set-Reg Remove-Item -Path $Path

                $Path = "$RegRoot\Software\RegisteredApplications"
                $Name = $ProgFullName
                Set-Reg Remove-ItemProperty -Path $Path -Name $Name
            }

            $Subkey = "Software\Classes\Applications\$FileEXE"
            $Value = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\$Subkey\shell\open\command",'',$null)

            if ( $Value -and ( $Value -like "*$ProgId*" ))
            {
                $Path = "HKCU:\$Subkey"
                Set-Reg Remove-Item -Path $Path
            }

            [array] $IDs = 'WEBFILES','WEBPROTOCOLS','MAILFILES','MAILPROTOCOLS','FILES','PROTOCOLS'

            foreach ( $id in $IDs )
            {
                $Path = "HKCU:\Software\Classes\$FileName.$Id"
                Set-Reg Remove-Item -Path $Path
            }

            $Subkey = 'Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts'
            try { $OpenSubKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($Subkey,'ReadSubTree','QueryValues') }
            catch { $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                foreach ( $Name in ( $OpenSubKey.GetValueNames() -match "^$FileName[.]($($IDs -join '|'))$" ))
                {
                    $Path = "HKCU:\$Subkey"
                    Set-Reg Remove-ItemProperty -Path $Path -Name $Name
                }

                $OpenSubKey.Close()
            }
        }

        if ( $Extension )
        {
            Write-Host "`n   $NameThisFunction`: Unassociation/unblock: $Extension | $ProgId" -ForegroundColor Magenta

            [int] $count = 0

            if ( $Extension.Contains('.') )
            {
                $Subkey = "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\UserChoice"
                $Value = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\$Subkey",'ProgId',$null)
                if ( $Value -eq $ProgId )
                {
                    $Path = "HKCU:\$Subkey"
                    Set-Reg Remove-Item -Path $Path

                    $count++
                }

                # Удаление 'NoOpenWith' у всех зарегистрированных ProgID от UWP для этого расширения
                try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey("Software\Classes\$Extension\OpenWithProgids",'ReadSubTree','QueryValues') }
                catch { [psobject] $OpenSubkey = $null }

                if ( $OpenSubkey )
                {
                    foreach ( $AppxProgID in ( $OpenSubkey.GetValueNames() -match '^AppX|edge' ))
                    {
                        $Path = "HKCU:\Software\Classes\$AppxProgID"

                        # Удаление запретов назначения для этого UWP
                        Set-Reg Remove-ItemProperty -Path $Path -Name 'NoOpenWith'
                        Set-Reg Remove-ItemProperty -Path $Path -Name 'NoStaticDefaultVerb'

                        $count++
                    }

                    $OpenSubkey.Close()
                }
            }
            else
            {
                $Subkey = "Software\Microsoft\Windows\Shell\Associations\UrlAssociations\$Extension\UserChoice"
                $Value = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\$Subkey",'ProgId',$null)
                if ( $Value -eq $ProgId )
                {
                    $Path = "HKCU:\$Subkey"
                    Set-Reg Remove-Item -Path $Path

                    $count++
                }
            }

            if ( -not $count )
            {
                Write-Host "`n   There are no associations/blocks" -ForegroundColor DarkGray
            }
        }
        else
        {
            Write-Host "   $NameThisFunction`: The extension is not specified" -ForegroundColor DarkGray
        }

        # Возврат разрешения перенаправления на дефолтный профиль, если он настраивается
        @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $true })

        Return
    }

    #region Check variable

    if ( -not ( $Extension -and $ProgId ))
    { Write-Warning "$NameThisFunction`: You must specify Extension and ProgId" ; Return }

    # Раскрытие переменных, если они есть
    $ProgId = [System.Environment]::ExpandEnvironmentVariables($ProgId)

    if ( -not $Web -and -not $Mail )
    {
        if ( $Extension -match '^(http|https|ftp|microsoft-edge|[.](htm|html|shtml|xht|xhtml|webp))$' )
        {
            $Web = $true
        }
        elseif ( $Extension -match '^(mailto|[.](eml|msg|ics|mbox|xpi|vcf))$' )
        {
            $Mail = $true
        }
    }

    # Если в ProgId указали путь к программе и она найдена, а если не найдена вывести поредупреждение и выйти из функции
    if ( $ProgId.Contains(':') -and [System.IO.File]::Exists($ProgId) )
    {
        # Назначение пути к программе и генерация ProgId, с установкой только первой буквы в верхний регистр
        # для красоты, чтобы не затрагивать другие буквы с разными типами регистра.
        $RegisterProgPath = $ProgId
        $FileEXE  = [System.IO.Path]::GetFileName($RegisterProgPath) -Replace ('\s','')
        $FileEXE  = '{0}{1}' -f $FileEXE.Substring(0, 1).ToUpperInvariant(), $FileEXE.Remove(0, 1)
        $FileName = [System.IO.Path]::GetFileNameWithoutExtension($FileEXE)

        if ( $Web )
        {
            if ( $Extension.Contains('.') ) { $ProgId = "$FileName.WEBFILES"     }
            else                            { $ProgId = "$FileName.WEBPROTOCOLS" }
        }
        elseif ( $Mail )
        {
            if ( $Extension.Contains('.') ) { $ProgId = "$FileName.MAILFILES"     }
            else                            { $ProgId = "$FileName.MAILPROTOCOLS" }
        }
        else
        {
            if ( $Extension.Contains('.') ) { $ProgId = "$FileName.FILES"     }
            else                            { $ProgId = "$FileName.PROTOCOLS" }
        }
    }
    elseif ( $ProgId.Contains(':') )
    {
        Write-Warning "$NameThisFunction`: Program not exist: $ProgId" ; Return
    }

    # Если не указан путь к программе
    if ( -not $RegisterProgPath )
    {
        try   { $OpenSubKey = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($ProgID,'ReadSubTree','QueryValues') }
        catch { $OpenSubKey = $null }

        # Если указанный ProgID не зарегистрирован, то выйти из функции
        if ( -not $OpenSubKey.Name ) { Write-Warning "$NameThisFunction`: ProgID not registered: '$ProgID'" ; Return }
        else { $OpenSubKey.Close() }
    }

    if ( $Icon )
    {
        if ( $Icon -ne '%1' )
        {
            # Раскрытие переменных
            $Icon     = [System.Environment]::ExpandEnvironmentVariables($Icon)
            $IconFile = @($Icon.Split(','))[0].Trim()

            # Если файл иконки не найден, вывести предупреждение, обнулить иконку и продолжить
            if ( -not [System.IO.File]::Exists($IconFile) -and $IconFile -notlike '*ms-resource://*' )
            {
                if ( $RegisterProgPath ) { $Icon = "$RegisterProgPath,0" } else { $Icon = '' }

                Write-Host "$NameThisFunction`: Icon File not exist: $IconFile" -ForegroundColor DarkGray
            }
        }
    }
    elseif ( $RegisterProgPath ) { $Icon = "$RegisterProgPath,0" }

    # Глобальное Отключение разрешения перенаправления для настройки реестра у дефолтного профиля, если он настраивается
    @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $false })

    Write-Verbose "             Ext: $Extension"
    Write-Verbose "          ProgId: $ProgId"
    Write-Verbose "         FileEXE: $FileEXE"
    Write-Verbose "        FileName: $FileName"
    Write-Verbose "RegisterProgPath: $RegisterProgPath"
    Write-Verbose "            Icon: $Icon"

    Write-Verbose "             Web: $Web"
    Write-Verbose "            Mail: $Mail"
    Write-Verbose "      Unregister: $Unregister"

    #endregion Check variable

    #region func

    # Подключаем привилегии для доступа к файловой системе при любых настройках доступа.
    # 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege', 'SeSecurityPrivilege'
    Token-Privileges -Enable4Privileges # Подгружает общий type, и включает 4 привилегии только один раз, и запоминает, что включал

    Function Refresh-Explorer {

        $Code = @'
using System;
using System.Runtime.InteropServices;

namespace Explorer
{
    public class RefreshRegistry
    {
        [System.Runtime.InteropServices.DllImport("Shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh() {
            SHChangeNotify(0x8000000, 0, IntPtr.Zero, IntPtr.Zero);
        }
    }
}
'@
        try
        {
            if ( -not ( 'Explorer.RefreshRegistry' -as [type] ))
            {
                $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
                $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
                $cp.GenerateInMemory = $true
                $cp.CompilerOptions = '/platform:anycpu /nologo'

                Add-Type -TypeDefinition $Code -ErrorAction Stop -Language CSharp -CompilerParameters $cp
            }
        }
        catch {}

        try { [Explorer.RefreshRegistry]::Refresh() } catch {}
    }

    Function Set-Icon {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Icon
        )

        $Path  = "HKCU:\Software\Classes\$ProgId\DefaultIcon"
        $Value = $Icon

        Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
    }

    Token-Impersonate -Reset

    # Профили
    [array] $Accs = [PSCustomObject] @{
        Root = 'HKCU:'
        SID  = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    }

    if ( $Global:DataAllUsers.Redirects.Value )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

            $Accs += [PSCustomObject] @{
                Root = $_.SID
                SID  = $_.SID
            }
        })
    }

    [array] $Script:RegisteredProgIDs = @() # Для Регистрации всех ProgID для указанного расширения в ApplicationAssociationToasts

    Function Remove-UserChoiceKey {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $SubKey
        )

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegHive = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isSubKey = $SubKey
            }
            else
            {
                $RegHive = [Microsoft.Win32.RegistryHive]::Users
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            # удаляет, не смотря на конкретные запреты доступа для текущего пользователя, хоть он и админ. Если есть доступ к разделу уровня текущей оболочки.
            # Оставлено это удаление, чтобы функция Set-Reg не тратила время на получение имперсонейшн от System, при ошибке удаления в первый раз
            try { [WinAPI.RegistryUtils]::DeleteKey($RegHive,$isSubKey) } catch {}
        }

        $Path = "HKCU:\$SubKey"
        Set-Reg Remove-Item -Path $Path
    }

    Function Set-UserAccessKey {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $SubKey
        )

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $isSubKey = $SubKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            try
            {
                $OpenSubKey = $RegRoot.OpenSubKey($isSubKey,'ReadWriteSubTree','TakeOwnership')

                if ( $OpenSubKey )
                {
                    $Acl = [System.Security.AccessControl.RegistrySecurity]::new()
                    $UserSID = $Acc.SID
                    $Acl.SetSecurityDescriptorSddlForm("O:$UserSID`G:$UserSID`D:AI(D;;DC;;;$UserSID)")
                    try { $OpenSubKey.SetAccessControl($Acl) } catch {}
                    $OpenSubKey.Close()
                }

                Write-Verbose "Set User Access Ok: HKCU:\$isSubKey"
            }
            catch { Write-Warning "$NameThisFunction`: Set User Access FAIL: HKCU:\$isSubKey" }
        }
    }

    Function Write-ExtensionKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
        )

        $OrigProgID = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\$Extension",'',$null)

        if ( $OrigProgID )
        {
            # Сохранить историю возможных ProgId с Extension или protocol для системного ProgID
            $Script:RegisteredProgIDs += $OrigProgID
        }

        # Для Extension и protocol
        # Сохранить историю возможных ProgId с Extension или protocol
        $Name = '{0}' -f [System.IO.Path]::GetFileName($ProgId)
        $Script:RegisteredProgIDs += $Name

        if ( $ProgId -ne $Name )
        {
            $Script:RegisteredProgIDs += $ProgId
        }

        # Если нет системного ProgId, задать указанный ProgId для расширения
        if ( -not $OrigProgID )
        {
            $Path  = "HKCU:\Software\Classes\$Extension"
            $Value = $ProgId
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
        }

        # Задать указанный ProgId в варианты возможных для назначения
        $Path = "HKCU:\Software\Classes\$Extension\OpenWithProgids"
        $Name = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())

        # Задать системный ProgId в параметры расширения для проводника в варианты возможных для назначения, а если его нет, то указанный ProgId
        $Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\OpenWithProgids"
        if ( $OrigProgID )
        {
            $Name = $OrigProgID
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())
        }

        $Name = $ProgID
        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type None ([byte[]]@())

        # удаление раздела UserChoice
        $Subkey = "Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Extension\UserChoice"
        $Path   = "HKCU:\$Subkey"
        Remove-UserChoiceKey -SubKey $Subkey

        # Установка параметров в UserChoice, раздел создается автоматически
        $Value = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name 'ProgId' -Type String $Value

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $RegHive  = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isRoot   = $Acc.Root
                $isSubKey = $Subkey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $RegHive  = [Microsoft.Win32.RegistryHive]::Users
                $isRoot   = "Registry::HKU"
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            # Получение хэша на основе времени последней модификации раздела, после создания и установки первого параметра
            $ProgHash = Get-Hash -ProgId $ProgId -Extension $Extension -SubKey $isSubKey -SID $Acc.SID -HIVE $RegHive

            $Path  = "$isRoot\$isSubKey"
            $Value = $ProgHash

            Set-Reg New-ItemProperty -Path $Path -Name 'Hash' -Type String $Value -OnlyThisPath
        }

        # Установка запрета на изменение на раздел UserChoice, который ставит винда при назначении
        Set-UserAccessKey -SubKey $Subkey
    }

    Function Write-ProtocolKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Protocol
        )

        $SubKey = "Software\Microsoft\Windows\Shell\Associations\UrlAssociations\$Protocol\UserChoice"
        $Path   = "HKCU:\$SubKey"

        # удаление раздела UserChoice протокола
        Remove-UserChoiceKey -SubKey $Subkey

        # Установка параметров в UserChoice протокола (запрет на раздел устанавливать не надо)
        $Value = $ProgId
        Set-Reg New-ItemProperty -Path $Path -Name 'ProgId' -Type String $Value

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $RegHive  = [Microsoft.Win32.RegistryHive]::CurrentUser
                $isRoot   = $Acc.Root
                $isSubKey = $SubKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $RegHive  = [Microsoft.Win32.RegistryHive]::Users
                $isRoot   = 'Registry::HKU'
                $isSubKey = "$($Acc.Root)\$SubKey"
            }

            # Получение хэша на основе времени последней модификации раздела, после создания и установки первого параметра
            $ProgHash = Get-Hash -ProgId $ProgId -Extension $Extension -SubKey $isSubKey -SID $Acc.SID -HIVE $RegHive

            $Path  = "$isRoot\$isSubKey"
            $Value = $ProgHash

            Set-Reg New-ItemProperty -Path $Path -Name 'Hash' -Type String $Value -OnlyThisPath
        }
    }

    # Регистрация расширения со всеми зарегистрированными ProgID
    Function Add-Registered-ProgID {

        Param(
           [Parameter( Position = 0, Mandatory = $true )] [String] $Extension
        )

        if ( $Extension.Contains('.') ) { [string] $Assocs = 'FileAssociations' } else { [string] $Assocs = 'UrlAssociations' }

        [string] $RegKey = 'SOFTWARE\RegisteredApplications'

        try { $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey, 'ReadSubTree','QueryValues') } catch {}

        if ( $OpenRegKey )
        {
            foreach ( $ValueName in $OpenRegKey.GetValueNames() )
            {
                $Subkey = $OpenRegKey.GetValue($ValueName,$null)

                if ( $Subkey )
                {
                    try { $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$Subkey\$Assocs", 'ReadSubTree','QueryValues') } catch {}

                    if ( $OpenKey )
                    {
                        $isProgID = $Openkey.GetValue($Extension,$null)

                        if ( $isProgID )
                        {
                            $Script:RegisteredProgIDs += $isProgID
                        }

                        $Openkey.Close()
                    }
                }
            }

            $OpenRegKey.Close()
        }

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                $isRoot   = $Acc.Root
                $isRegKey = $RegKey
            }
            else
            {
                $RegRoot  = [Microsoft.Win32.Registry]::Users
                $isRoot   = "Registry::HKU\$($Acc.Root)"
                $isRegKey = "$($Acc.Root)\$RegKey"
            }

            $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues')

            [array] $UserRegisteredProgIDs = @()

            if ( $OpenRegKey )
            {
                foreach ( $ValueName in $OpenRegKey.GetValueNames() )
                {
                    $Subkey = $OpenRegKey.GetValue($ValueName,$null)

                    if ( $Subkey )
                    {
                        $OpenKey = $RegRoot.OpenSubKey("$Subkey\$Assocs", 'ReadSubTree','QueryValues')

                        if ( $OpenKey )
                        {
                            $isProgID = $Openkey.GetValue($Extension,$null)

                            if ( $isProgID )
                            {
                                $UserRegisteredProgIDs += $isProgID
                            }

                            $Openkey.Close()
                        }
                    }
                }

                $OpenRegKey.Close()
            }

            $UserRegisteredProgIDs = ( $Script:RegisteredProgIDs + $UserRegisteredProgIDs | Sort-Object -Unique )

            foreach ( $UserProgID in $UserRegisteredProgIDs )
            {
                $Path = "$isRoot\Software\Microsoft\Windows\CurrentVersion\ApplicationAssociationToasts"
                $Name = "$UserProgID`_$Extension"

                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 0 -OnlyThisPath
            }
        }
    }

    Function Write-AdditionalKeys {

        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
        )

        # Все эти параметры для соблюдения основных условий, для предотвращения сброса в будущем назначенного приложения на расширение.

        $OrigProgID = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\$Extension",'',$null)

        # Для Extension и protocol
        # Если есть системный ProgId для расширения или протокола, то записать его в уже настроенное по умолчанию
        if ( $OrigProgID )
        {
            $Path = 'Registry::HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\FileAssociations\ProgIds'
            $Name = "_$Extension"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 1
        }

        # Только Extension.
        if ( $Extension.Contains('.') )
        {
            [bool] $isEdge = $false

            foreach ( $Acc in $Accs )
            {
                if ( $Acc.Root -eq 'HKCU:' )
                {
                    $RegRoot  = [Microsoft.Win32.Registry]::CurrentUser
                    $RegHive  = 'HKEY_CURRENT_USER'
                    $isRoot   = $Acc.Root
                    $isRegKey = 'Software\Classes'
                }
                else
                {
                    $RegRoot  = [Microsoft.Win32.Registry]::Users
                    $RegHive  = 'HKEY_USERS'
                    $isRoot   = 'Registry::HKU'
                    $isRegKey = "$($Acc.Root)_Classes"
                }

                # Установка 'NoOpenWith' для всех зарегистрированных ProgID у расширения от Appx. Это не скрывает приложение из выбора.
                try { [psobject] $OpenSubkey = $RegRoot.OpenSubKey("$isRegKey\$Extension\OpenWithProgids",'ReadSubTree','QueryValues') }
                catch { [psobject] $OpenSubkey = $null }

                if ( $ProgId -match '^AppX|edge' ) { $isProgIdMS = $true } else { $isProgIdMS = $false }

                if ( $OpenSubkey )
                {
                    foreach ( $AppxProgID in ( $OpenSubkey.GetValueNames() -match '^AppX|edge' )) # -match '^AppX|edge' -like 'AppX*'
                    {
                        # Если приложение установлено
                        if ( [Microsoft.Win32.Registry]::GetValue("$RegHive\$isRegKey\$AppxProgID\Shell\open",'PackageId',$null) )
                        {
                            $Path = "$isRoot\$isRegKey\$AppxProgID"

                            # Если указанный ProgId для назначения от UWP или Edge, то удалить все блокировки у найденных ProgID от UWP или Edge для этого расширения
                            if ( $isProgIdMS )
                            {
                                # Удаление запретов назначения для этого UWP
                                Set-Reg Remove-ItemProperty -Path $Path -Name 'NoOpenWith' -OnlyThisPath
                                Set-Reg Remove-ItemProperty -Path $Path -Name 'NoStaticDefaultVerb' -OnlyThisPath
                            }
                            else
                            {
                                # Иначе, Запрет открытия файлов этими ProgID от UWP или Edge, чтобы не сбрасывались ассоциации на него. Это не мешает назначить на открытие этим UWP
                                # только исчезает галочка (всегда использовать) при настройке на отдельные расширения, если для него назначено это приложение
                                Set-Reg New-ItemProperty -Path $Path -Name 'NoOpenWith' -Type String '' -OnlyThisPath
                            }

                            $Script:RegisteredProgIDs += $AppxProgID
                        }
                    }

                    $OpenSubkey.Close()
                }
            }

            # Восстановление необходимых параметров для расширений графических файлов
            if ( 'picture' -eq [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\KindMap",$Extension,$null) -and
                 [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\PBrush\CLSID",'',$null) )
            {
                $Script:RegisteredProgIDs += 'PBrush'
            }
        }

        # Регистрация всех нужных и дополнительно полученных далее ProgID для этого расширения в ApplicationAssociationToasts
        Add-Registered-ProgID -Extension $Extension
    }

    Function Get-Hash {

        [CmdletBinding()]
        [OutputType([string])]
        Param(
            [Parameter( Position = 0, Mandatory = $true )] [String] $ProgId
           ,[Parameter( Position = 1, Mandatory = $true )] [String] $Extension
           ,[Parameter( Position = 2, Mandatory = $true )] [String] $SubKey
           ,[Parameter( Position = 3, Mandatory = $true )] [String] $SID
           ,[Parameter( Position = 4, Mandatory = $true )] [String] $HIVE
        )

        # C# код для генерации хэша
        $PatentHash = @'
using System;

namespace FileAssoc
{
    public static class PatentHash
    {
        public static uint[] WordSwap(byte[] a, int sz, byte[] md5)
        {
            if (sz < 2 || (sz & 1) == 1) {
                throw new ArgumentException(String.Format("Invalid input size: {0}", sz), "sz");
            }

            unchecked {
                uint o1 = 0;
                uint o2 = 0;
                int ta = 0;
                int ts = sz;
                int ti = ((sz - 2) >> 1) + 1;

                uint c0 = (BitConverter.ToUInt32(md5, 0) | 1) + 0x69FB0000;
                uint c1 = (BitConverter.ToUInt32(md5, 4) | 1) + 0x13DB0000;

                for (uint i = (uint)ti; i > 0; i--) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;
                    ta += 8;
                    ts -= 2;

                    uint v1 = 0x79F8A395 * (n * c0 - 0x10FA9605 * (n >> 16)) + 0x689B6B9F * ((n * c0 - 0x10FA9605 * (n >> 16)) >> 16);
                    uint v2 = 0xEA970001 * v1 - 0x3C101569 * (v1 >> 16);
                    uint v3 = BitConverter.ToUInt32(a, ta - 4) + v2;
                    uint v4 = v3 * c1 - 0x3CE8EC25 * (v3 >> 16);
                    uint v5 = 0x59C3AF2D * v4 - 0x2232E0F1 * (v4 >> 16);

                    o1 = 0x1EC90001 * v5 + 0x35BD1EC9 * (v5 >> 16);
                    o2 += o1 + v2;
                }

                if (ts == 1) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;

                    uint v1 = n * c0 - 0x10FA9605 * (n >> 16);
                    uint v2 = 0xEA970001 * (0x79F8A395 * v1 + 0x689B6B9F * (v1 >> 16)) -
                              0x3C101569 * ((0x79F8A395 * v1 + 0x689B6B9F * (v1 >> 16)) >> 16);
                    uint v3 = v2 * c1 - 0x3CE8EC25 * (v2 >> 16);

                    o1 = 0x1EC90001 * (0x59C3AF2D * v3 - 0x2232E0F1 * (v3 >> 16)) +
                         0x35BD1EC9 * ((0x59C3AF2D * v3 - 0x2232E0F1 * (v3 >> 16)) >> 16);
                    o2 += o1 + v2;
                }

                uint[] ret = new uint[2];
                ret[0] = o1;
                ret[1] = o2;
                return ret;
            }
        }

        public static uint[] Reversible(byte[] a, int sz, byte[] md5)
        {
            if (sz < 2 || (sz & 1) == 1) {
                throw new ArgumentException(String.Format("Invalid input size: {0}", sz), "sz");
            }

            unchecked {
                uint o1 = 0;
                uint o2 = 0;
                int ta = 0;
                int ts = sz;
                int ti = ((sz - 2) >> 1) + 1;

                uint c0 = BitConverter.ToUInt32(md5, 0) | 1;
                uint c1 = BitConverter.ToUInt32(md5, 4) | 1;

                for (uint i = (uint)ti; i > 0; i--) {
                    uint n = (BitConverter.ToUInt32(a, ta) + o1) * c0;
                    n = 0xB1110000 * n - 0x30674EEF * (n >> 16);
                    ta += 8;
                    ts -= 2;

                    uint v1 = 0x5B9F0000 * n - 0x78F7A461 * (n >> 16);
                    uint v2 = 0x1D830000 * (0x12CEB96D * (v1 >> 16) - 0x46930000 * v1) +
                              0x257E1D83 * ((0x12CEB96D * (v1 >> 16) - 0x46930000 * v1) >> 16);
                    uint v3 = BitConverter.ToUInt32(a, ta - 4) + v2;

                    uint v4 = 0x16F50000 * c1 * v3 - 0x5D8BE90B * (c1 * v3 >> 16);
                    uint v5 = 0x2B890000 * (0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16)) +
                              0x7C932B89 * ((0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16)) >> 16);

                    o1 = 0x9F690000 * v5 - 0x405B6097 * (v5 >> 16);
                    o2 += o1 + v2;
                }

                if (ts == 1) {
                    uint n = BitConverter.ToUInt32(a, ta) + o1;

                    uint v1 = 0xB1110000 * c0 * n - 0x30674EEF * ((c0 * n) >> 16);
                    uint v2 = 0x5B9F0000 * v1 - 0x78F7A461 * (v1 >> 16);
                    uint v3 = 0x1D830000 * (0x12CEB96D * (v2 >> 16) - 0x46930000 * v2) +
                              0x257E1D83 * ((0x12CEB96D * (v2 >> 16) - 0x46930000 * v2) >> 16);
                    uint v4 = 0x16F50000 * c1 * v3 - 0x5D8BE90B * ((c1 * v3) >> 16);
                    uint v5 = 0x96FF0000 * v4 - 0x2C7C6901 * (v4 >> 16);

                    o1 = 0x9F690000 * (0x2B890000 * v5 + 0x7C932B89 * (v5 >> 16)) -
                         0x405B6097 * ((0x2B890000 * v5 + 0x7C932B89 * (v5 >> 16)) >> 16);
                    o2 += o1 + v2;
                }

                uint[] ret = new uint[2];
                ret[0] = o1;
                ret[1] = o2;
                return ret;
            }
        }

        public static long MakeLong(uint left, uint right) {
           return (long)left << 32 | (long)right;
        }
    }
}
'@
        if ( -not ( 'FileAssoc.PatentHash' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $PatentHash -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        Function Get-KeyLastWriteTime ( $SubKey ) {

            try {
                $LM = [WinAPI.RegistryUtils]::GetLastModified($HIVE,$SubKey)
                $FT = ([DateTime]::New($LM.Year, $LM.Month, $LM.Day, $LM.Hour, $LM.Minute, 0, $LM.Kind)).ToFileTime()

                return [string]::Format('{0:x8}{1:x8}', $FT -shr 32, $FT -band [uint32]::MaxValue)

            } catch {
                Write-Warning "Failed to get last write time for UserChoice subkey: $SubKey"
            }
        }

        # Получение секретной строки: User Choice set via Windows User Experience {D18B6DD5-6124-4341-9318-804003BAFA0B}, пока везде одинаковая
        Function Get-UserExperience {

            [OutputType([string])]

            $userExperienceSearch = 'User Choice set via Windows User Experience'
            $user32Path = "$([Environment]::GetFolderPath([Environment+SpecialFolder]::SystemX86))\Shell32.dll"
            $fileStream = [System.IO.File]::Open($user32Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
            $binaryReader = New-Object System.IO.BinaryReader($fileStream)
            [Byte[]] $bytesData = $binaryReader.ReadBytes(5mb)
            $fileStream.Close()
            $dataString = [Text.Encoding]::Unicode.GetString($bytesData)
            $position1 = $dataString.IndexOf($userExperienceSearch)
            $position2 = $dataString.IndexOf('}', $position1)

            Return $dataString.Substring($position1, $position2 - $position1 + 1)
        }

        Function Get-DataArray {

            [OutputType([array])]

           #$userExperience   = Get-UserExperience
            $userExperience   = 'User Choice set via Windows User Experience {D18B6DD5-6124-4341-9318-804003BAFA0B}'
            $userSid          = $SID
            $KeyLastWriteTime = Get-KeyLastWriteTime $SubKey
            $baseInfo         = ('{0}{1}{2}{3}{4}' -f $Extension, $userSid, $ProgId, $KeyLastWriteTime, $userExperience).ToLowerInvariant()

            $StringToUTF16LEArray = [System.Collections.ArrayList]@([System.Text.Encoding]::Unicode.GetBytes($baseInfo))
            $StringToUTF16LEArray += (0,0)

            Return $StringToUTF16LEArray
        }

        Function Get-PatentHash ([byte[]]$A, [byte[]]$MD5) {

            [OutputType([string])]

            $Size = $A.Count
            $ShiftedSize = ($Size -shr 2) - ($Size -shr 2 -band 1) * 1

            [uint32[]]$A1 = [FileAssoc.PatentHash]::WordSwap($A, [int]$ShiftedSize, $MD5)
            [uint32[]]$A2 = [FileAssoc.PatentHash]::Reversible($A, [int]$ShiftedSize, $MD5)

            $Ret = [FileAssoc.PatentHash]::MakeLong($A1[1] -bxor $A2[1], $A1[0] -bxor $A2[0])

            Return [System.Convert]::ToBase64String([System.BitConverter]::GetBytes([Int64]$Ret))
        }

        $DataArray = Get-DataArray
        $DataMD5   = [System.Security.Cryptography.HashAlgorithm]::Create('MD5').ComputeHash($DataArray)
        $Hash      = Get-PatentHash $DataArray $DataMD5

        Return $Hash
    }

    #endregion func

    # Далее выполнение действий ....

    # Если надо зарегистрировать Portable программу
    if ( $RegisterProgPath )
    {
        $progCommand = """$RegisterProgPath"" ""%1"""

        # Register Classes\$ProgId
        $Path  = "HKCU:\Software\Classes\$ProgId\shell\open\command"
        $Value = $progCommand
        Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

        $ProgFullName = "$FileName Portable"

        if ( $Web )
        {
            # Регистрация Браузера

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName"
            $Value = $ProgFullName
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
            Set-Reg New-ItemProperty -Path $Path -Name 'LocalizedString' -Type String $Value

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities"
            $Value = $FileName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationName' -Type String $Value
            $Value = "Registered with AutoSettingsPS"
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationDescription' -Type String $Value

            $Value = $ProgFullName
            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\Startmenu"
            Set-Reg New-ItemProperty -Path $Path -Name 'StartMenuInternet' -Type String $Value

            $OpenCommand = """$RegisterProgPath"""

            $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\shell\open\command"
            $Value = $OpenCommand
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            if ( $Extension.Contains('.') )
            {
                $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\FileAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
            }
            else
            {
                $Path = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\Capabilities\URLAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value

                $Path  = "HKCU:\Software\Classes\$ProgId"
                $Value = $ProgFullName
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
                Set-Reg New-ItemProperty -Path $Path -Name 'URL Protocol' -Type String ''
            }

            if ( $Icon )
            {
                $Path  = "HKCU:\Software\Clients\StartMenuInternet\$ProgFullName\DefaultIcon"
                $Value = $Icon

                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
            }

            $Path  = "HKCU:\Software\RegisteredApplications"
            $Name  = $ProgFullName
            $Value = "SOFTWARE\Clients\StartMenuInternet\$ProgFullName\Capabilities"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
        }
        elseif ( $Mail )
        {
            # Регистрация Почтового клиента

            $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName"
            $Value = $ProgFullName
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
            Set-Reg New-ItemProperty -Path $Path -Name 'LocalizedString' -Type String $Value

            $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\Capabilities"
            $Value = $FileName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationName' -Type String $Value
            $Value = "Registered with AutoSettingsPS"
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationDescription' -Type String $Value

            $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\Capabilities\Startmenu"
            $Value = $ProgFullName
            Set-Reg New-ItemProperty -Path $Path -Name 'Mail' -Type String $Value

            $OpenCommand = """$RegisterProgPath"""

            $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\shell\open\command"
            $Value = $OpenCommand
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            if ( $Extension.Contains('.') )
            {
                $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\Capabilities\FileAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
            }
            else
            {
                $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\Capabilities\URLAssociations"
                $Name  = $Extension
                $Value = $ProgId
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value

                if ( $Extension -eq 'mailto' )
                {
                    $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\Protocols\mailto"
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String 'URL:MailTo Protocol'
                    Set-Reg New-ItemProperty -Path $Path -Name 'EditFlags' -Type Binary 0x2,0x0,0x0,0x0
                    Set-Reg New-ItemProperty -Path $Path -Name 'URL Protocol' -Type String ''
                }

                $Path = "HKCU:\Software\Clients\Mail\$ProgFullName\Protocols\mailto\shell\open\command"
                $Value = $progCommand
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                $Path = "HKCU:\Software\Classes\mailto"
                Set-Reg New-ItemProperty -Path $Path -Name 'URL Protocol' -Type String ''

                $Path  = "HKCU:\Software\Classes\$ProgId"
                $Value = $ProgFullName
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
                Set-Reg New-ItemProperty -Path $Path -Name 'URL Protocol' -Type String ''
            }

            if ( $Icon )
            {
                $Path  = "HKCU:\Software\Clients\Mail\$ProgFullName\DefaultIcon"
                $Value = $Icon

                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                if ( $Extension -eq 'mailto' )
                {
                    $Path = "HKCU:\Software\Clients\Mail\$ProgFullName\Protocols\mailto\DefaultIcon"
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value
                }
            }

            $Path  = 'HKCU:\Software\RegisteredApplications'
            $Name  = $ProgFullName
            $Value = "SOFTWARE\Clients\Mail\$ProgFullName\Capabilities"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
        }
        elseif ( $Extension.Contains('.') )
        {
            # Регистрация как обычной программы, не интернет клиента: браузер, мэйл

            # Register Applications\$FileEXE
            $Path  = "HKCU:\Software\Classes\Applications\$FileEXE\shell\open\command"
            $Value = $progCommand
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            # Register PortableProgram\$ProgFullName
            $Path  = "HKCU:\Software\PortableProgram\$ProgFullName\Capabilities"
            $Value = $FileName
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationName' -Type String $Value
            $Value = "Registered with AutoSettingsPS"
            Set-Reg New-ItemProperty -Path $Path -Name 'ApplicationDescription' -Type String $Value

            $Path  = "HKCU:\Software\PortableProgram\$ProgFullName\Capabilities\FileAssociations"
            $Name  = $Extension
            $Value = $ProgId
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value

            # Register RegisteredApplications
            $Path  = 'HKCU:\Software\RegisteredApplications'
            $Name  = $ProgFullName
            $Value = "SOFTWARE\PortableProgram\$ProgFullName\Capabilities"
            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value
        }
    }

    if ( $Icon )
    {
        Write-Verbose "Set Icon: $Icon"
        Set-Icon $ProgId $Icon
    }

    Write-Verbose "Write Additional Keys For: $ProgId | $Extension"

    # Если указано расширение файла, настраиваем расширение, иначе протокол
    if ( $Extension.Contains('.') )
    {
        Write-Verbose "Write Registry Extension: $Extension"
        Write-ExtensionKeys -ProgId $ProgId -Extension $Extension
    }
    else
    {
        Write-Verbose "Write Registry Protocol: $Extension"
        Write-ProtocolKeys -ProgId $ProgId -Protocol $Extension
    }

    # Установка дополнительных параметров для соблюдения выжных условий
    Write-AdditionalKeys -ProgId $ProgId -Extension $Extension

    Refresh-Explorer

    # Возврат разрешения перенаправления на дефолтный профиль, если он настраивается
    @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $true })
}
