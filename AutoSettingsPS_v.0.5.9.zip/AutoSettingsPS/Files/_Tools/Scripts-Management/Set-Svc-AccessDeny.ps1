﻿
# установка запретов доступа к службе на любое изменение, запуск и получение данных по доступу
Function Set-Svc-AccessDeny {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $true, Position = 1 )]
        [Alias( 'DriverName' )]
        [string] $ServiceName
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NeedUnlock
       ,
        [Parameter( Mandatory = $false )]
        [switch] $ForMenu
       ,
        [Parameter( Mandatory = $false )]
        [string] $ForcedSDDL   # SDDL Настроенный на прямую, результат после перезагрузки, указывать самостоятельно не надо, просто для инфы передается.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    Token-Impersonate -Token SYS

    [string] $SDDL = Set-OwnerAndAccess -Path $ServiceName -GetSDDL -Service -WithSacl

    if ( $Act -eq 'Set' )
    {
        if ( $SDDL )
        {
            Token-Impersonate -Token TI

            [bool] $Forced = $false

            if ( -not ( $SDDL -like '*(D;;DCSWRPWPDTLOCRSDRCWDWO;;;WD)*' ))
            {
                $SDDL = $SDDL -replace 'D:(\(D;;[^)]+;;;WD\))?','D:(D;;DCSWRPWPDTLOCRSDRCWDWO;;;WD)' -replace 'AU;FA;([^)]+;;;WD)','AU;SA;$1' -replace '\(A;;(CC)?([^)]+;;;(SU|S-1-5-80-[^)]+)\))','(A;;$2'

                # Если ошибка доступа, настроить напрямую через отдельный процесс под TI (Для драйвера защитника WdFilter сделали запрет изменения дескриптора через API)
                if ( Set-OwnerAndAccess -Path $ServiceName -RecoverySDDL $SDDL -WithSacl -Service -ExitCode )
                {
                    [string] $strBytes = [WinAPI.RegistryManage]::SDDLtoStringOfBytes($SDDL)
                    
                    if ( $strBytes )
                    {
                        [string] $COM = "try { [Microsoft.Win32.Registry]::SetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$ServiceName\Security','Security',([byte[]]@($strBytes)),'Binary') } catch {}"
                        
                        if ( -not ( Start-ProcessFromSYS -Token TI -CmdLine "powershell.exe -nop -c ""& `$([scriptblock]::Create(""""""$COM""""""))""" -NoWindow -Wait -ExitCode ))
                        {
                            $Forced = $true
                        }
                    }
                }
            }

            if ( $Forced ) { Set-Svc-AccessDeny -Act Check -ServiceName $ServiceName -ForcedSDDL $SDDL }
            else           { Set-Svc-AccessDeny -Act Check -ServiceName $ServiceName                   }
        }
        else
        {
            Write-Host '   ○ ' -ForegroundColor DarkGray -NoNewline
            Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
            Write-Host "$ServiceName" -ForegroundColor DarkGray
        }
    }
    elseif ( $Act -eq 'Check' )
    {
        if ( $SDDL )
        {
            if ( $ForcedSDDL ) { $SDDL = $ForcedSDDL }

            if ( $SDDL -match '\(D;;[^)]+;;;WD\)' )
            {
                if ( $ForMenu )
                {
                    '#DarkCyan#[Locked]#'
                }
                else
                {
                    if ( $NeedUnlock )
                    {
                        Write-Host '   ○ ' -ForegroundColor Yellow -NoNewline
                        Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$ServiceName" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                    else
                    {
                        Write-Host '   ● ' -ForegroundColor Green -NoNewline
                        Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$ServiceName" -ForegroundColor White -NoNewline

                        if ( $ForcedSDDL ) { Write-Host ' [Need Reboot]' -ForegroundColor Cyan } else { Write-Host }
                    }
                }
            }
            else
            {
                if ( $ForMenu )
                {
                    '#DarkGray#[UnLock]#'
                }
                else
                {
                    if ( $NeedUnlock )
                    {
                        Write-Host '   ● ' -ForegroundColor Green -NoNewline
                        Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$ServiceName" -ForegroundColor Magenta -NoNewline

                        if ( $ForcedSDDL ) { Write-Host ' [Need Reboot]' -ForegroundColor Cyan } else { Write-Host }
                    }
                    else
                    {
                        Write-Host '   ○ ' -ForegroundColor Yellow -NoNewline
                        Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$ServiceName" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                }
            }
        }
        else
        {
            if ( $ForMenu )
            {
                '#DarkGray#[------]#'
            }
            else
            {
                Write-Host '   ○ ' -ForegroundColor DarkGray -NoNewline
                Write-Host "| $NameThisFunction`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$ServiceName" -ForegroundColor DarkGray
            }
        }
    }
    else   # Default
    {
        if ( $SDDL )
        {
            [bool] $Forced = $false

            if ( $SDDL -match '\(D;;[^)]+;;;WD\)' )
            {
                Token-Impersonate -Token TI

                $SDDL = $SDDL -replace '\(D;;[^)]+;;;WD\)','' -replace 'AU;SA;([^)]+;;;WD)','AU;FA;$1' -replace '\(A;;(CC)?([^)]+;;;(SU|S-1-5-80-[^)]+)\))','(A;;CC$2'

                # Если ошибка доступа, настроить напрямую через отдельный процесс
                if ( Set-OwnerAndAccess -Path $ServiceName -RecoverySDDL $SDDL -WithSacl -Service -ExitCode )
                {
                    [string] $strBytes = [WinAPI.RegistryManage]::SDDLtoStringOfBytes($SDDL)
                    
                    if ( $strBytes )
                    {
                        [string] $COM = "try { [Microsoft.Win32.Registry]::SetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$ServiceName\Security','Security',([byte[]]@($strBytes)),'Binary') } catch {}"

                        if ( -not ( Start-ProcessFromSYS -Token TI -CmdLine "powershell.exe -nop -c ""& `$([scriptblock]::Create(""""""$COM""""""))""" -NoWindow -Wait -ExitCode ))
                        {
                            $Forced = $true
                        }
                    }
                }
            }

            if ( $Forced ) { Set-Svc-AccessDeny -Act Check -ServiceName $ServiceName -NeedUnlock -ForcedSDDL $SDDL }
            else           { Set-Svc-AccessDeny -Act Check -ServiceName $ServiceName -NeedUnlock                   }
        }
        else
        {
            Write-Host '   ○ ' -ForegroundColor DarkGray -NoNewline
            Write-Host "| $NameThisFunction | " -ForegroundColor DarkGray -NoNewline
            Write-Host "$ServiceName" -ForegroundColor DarkGray
        }
    }

    Token-Impersonate -Reset
}
