﻿
<#
.SYNOPSIS
 Получить список настроек из первого по алфавиту файла пресета, начинающегося с имени указанного файла,
 если таких нет, то открытие указанного файла, если он есть.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется для получения пресетов из текущего файла пресетов в глобальную переменную
 Сортировка как в проводнике через API.

.EXAMPLE
    $ListPresets = Get-List-Presets -File 'C:\Presets.txt'

    Описание
    --------
    Получить список настроек из первого файла подходящего под шаблон "Presets*.txt".

.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  18.04.2023
 =================================================

#>
Function Get-List-Presets {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string[]])]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [string] $File
       ,
        [Parameter( Mandatory = $false )]
        [switch] $QuickPreset
    )

    $NaturalSort = @'
using System.Runtime.InteropServices;
public static class NaturalSort
{
    [DllImport("Shlwapi.dll", CharSet = CharSet.Unicode)]
    private static extern int StrCmpLogicalW(string psz1, string psz2);
    public static string[] Sort(string[] array)
    {
        System.Array.Sort(array, (psz1, psz2) => StrCmpLogicalW(psz1, psz2));
        return array;
    }
}
'@
    if ( -not ( 'NaturalSort' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $NaturalSort -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    [string] $FoundPresetsMy = ''
    
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($File)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($File)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($File)

        $FoundPresetsMy = [NaturalSort]::Sort(@([System.IO.Directory]::EnumerateFiles($PresetsPath,"$PresetsName*$PresetsExt")).Where({ $_ -notlike "*\$PresetsName$PresetsExt" }))[0]
    }
    catch {}

    if ( $FoundPresetsMy ) { $File = $FoundPresetsMy }

    if ( $QuickPreset )
    {
        $CurrentQuickPresetsFile = $File
    }
    else
    {
        $CurrentPresetsFile = $File
    }

    # Получение данных из пресета.
    try { Return (Get-Content -LiteralPath \\?\$File -Encoding UTF8 -ErrorAction SilentlyContinue) } catch { Return [string[]]::new(0) }
}
