﻿
<#
.SYNOPSIS
 Выполнение функций, указанных в файле пресетов быстрых настроек,
 для выполнения или восстановления параметров.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Run_Configs.ps1.

 Используется функция Get-Pause для установки паузы.
 Используется функция Write-HostColor для раскраски вывода.
 Используется функция Set-LGP, тут для применения Групповых Политик, записанных в переменную.

 Функции для написаны под один стандарт,
 чтобы принимали одинаковые аргументы для указания выполнения или восстановления.

.EXAMPLE
    Run-QuickSettings -Options SetConfigs,SetMySettingsPS -Act Set

    Описание
    --------
    Выполнить все функции в пресете, с указанием аргумента для применения параметров + выполнить все файлы ps1.
    Указанные в пресете аргументы функций подхватываются.

.EXAMPLE
    Run-QuickSettings -Options SetConfigs -Act Default

    Описание
    --------
    Выполнить все функции в пресете, с указанием аргумента для восстановления параметров.
    Указанные в пресете аргументы функций подхватываются.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  09-03-2019
 ===============================================

#>
Function Run-QuickSettings {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'Set', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'SetConfigs', 'SetMySettingsPS', 'SetMySettingsCMD', 'SetMySettingsREG' )]
        [string[]] $Options = 'SetConfigs'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Configs', 'MySettingsPS', 'MySettingsCMD', 'MySettingsREG', 'CurrentPreset' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FileQuickPresets = $FileQuickPresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [string] $FolderForMySettings = $FolderForMySettingsGlobal
    )

    # Получение имени этой функции.
    $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [string[]] $ListQuickPresets = Get-List-Presets -File $FileQuickPresets -QuickPreset

    if ( -not $ListQuickPresets.Count )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны группы в файле пресетов' }
        Write-Warning "`n  $NameThisFunction`: $text`: '$FileQuickPresets'"

        Get-Pause ; Return     # Выход из функции.
    }

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresetsGlobal

    [int] $Number = 0
    [hashtable] $QuickConfigs = @{}

    if ( $Act -eq 'Default' ) { [string] $isQuickPreset = 'Quick-Apply-Default' } else { [string] $isQuickPreset = 'Quick-Apply-Settings' }

    # Получаем список функций из файла пресетов. И заполняем таблицу $QuickConfigs.
    foreach ( $Line in ( $ListQuickPresets -match "^\s*$isQuickPreset\s*=\s*1\s*=.+" ))
    {
        if ( $Line -match "^\s*$isQuickPreset\s*=\s*1\s*=\s*(?<FuncName>[^#=\s]+)(?<Args>[^#=\n\r]+)?=((?<Note>[^#\n\r]+)=)?" )
        {
            $Number++
            [string] $FunctionName = $Matches.FuncName

            try { [string] $FunctionArgs = $Matches.Args.Trim() } catch { [string] $FunctionArgs = '' }
            try { [string] $FunctionNote = $Matches.Note.Trim() } catch { [string] $FunctionNote = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Нет описания' }) }
            if ( -not $FunctionNote ){ [string] $FunctionNote = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Нет описания' }) }

            $QuickConfigs[$Number] = @{}

            $QuickConfigs[$Number]['FunctionName'] = $FunctionName
            $QuickConfigs[$Number]['FunctionArgs'] = $FunctionArgs
            $QuickConfigs[$Number]['FunctionNote'] = $FunctionNote

            # Если функция не существует.
            if ( -not ( Get-Command -CommandType Function -Name $FunctionName -ErrorAction SilentlyContinue ))
            {
                $QuickConfigs[$Number]['FuncResult']   = '#Red#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Не существует' })
                $QuickConfigs[$Number]['FunctionSkip'] = $true
            }
            else
            {
                $QuickConfigs[$Number]['FunctionSkip'] = $false
            }
        }
    }

    if ( $ListQuickPresets.Where({ $_ -match '^\s*Quick-Apply-MySettingsPS\s*=\s*1\s*=' },'First') )
    {
        [bool] $ApplyMySettingsPS = $true
    }
    else { [bool] $ApplyMySettingsPS = $false }

    if ( $ListQuickPresets.Where({ $_ -match '^\s*Quick-Apply-MySettingsCMD\s*=\s*1\s*=' },'First') )
    {
        [bool] $ApplyMySettingsCMD = $true
    }
    else { [bool] $ApplyMySettingsCMD = $false }

    if ( $ListQuickPresets.Where({ $_ -match '^\s*Quick-Apply-MySettingsREG\s*=\s*1\s*=' },'First') )
    {
        [bool] $ApplyMySettingsREG = $true
    }
    else { [bool] $ApplyMySettingsREG = $false }

    # Если указано вывести информацию по наличию параметров.
    if ( $CheckState )
    {
        if ( $CheckState -eq 'Configs' )
        {
            [int] $NumShow = 0

            if ( $Act -eq 'Default' ) { [string] $ColorName = '#Yellow#' } else { [string] $ColorName = '#Green#' }

            # Выводим информацию по всем функциям.
            foreach ( $Number in $QuickConfigs.Keys | Sort-Object )
            {
                $NumShow++

                [string] $FuncArgs = $QuickConfigs[$Number]['FunctionArgs']
                if ( $FuncArgs ) { $FuncArgs = "{0}: #White#$FuncArgs" -f $(if ( $L.s5 ) { $L.s5 } else { 'арг' }) }

                [string] $ResultShow = "#DarkGray#{0}. $ColorName{1} #DarkGray#| {2} | {3}$FuncArgs#" -f
                    $Number.ToString().PadLeft(5,' '),
                    $QuickConfigs[$Number]['FunctionName'].ToString().PadRight(24,' '),
                    $QuickConfigs[$Number]['FunctionNote'].ToString().PadRight(58,' ').Substring(0,58),
                    $QuickConfigs[$Number]['FuncResult']

                Write-HostColor $ResultShow
            }

            if ( -not $NumShow )
            {
                $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны группы в файле пресетов' }
                Write-Host "         $text" -ForegroundColor Yellow
            }
        }
        elseif ( $CheckState -eq 'MySettingsPS' )
        {
            if ( -not $ApplyMySettingsPS )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Файлы ps1: Выполнение файлов ps1 отключено в файле пресетов' }
                Write-Host "`n       $text`: " -ForegroundColor DarkGray

                Return
            }

            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $PSFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                      ).Where({ $_.Name -like '*.ps1' }).FullName
                if ( $PSFiles.Count )
                {
                    $text = if ( $L.s6 ) { $L.s6 } else { 'Файлы ps1' }
                    Write-Host "`n       $text`: "

                    [int] $PsCount = 0
                    foreach ( $PsFile in $PsFiles )
                    {
                        $PsCount++

                        [string] $PsFileName = [System.IO.Path]::GetFileName($PsFile)

                        Write-Host "$($PsCount.ToString().PadLeft(11,' ')). " -ForegroundColor DarkGray -NoNewline
                        Write-Host "ps1: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$PsFileName " -ForegroundColor Green -NoNewline

                        if ( $PsFileName -like '*_TI.ps1' )
                        {
                            $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Выполнение с подключенным токеном от' }
                            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host 'TrustedInstaller' -ForegroundColor Magenta
                        }
                        elseif ( $PsFileName -like '*_SYS.ps1' )
                        {
                            $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Выполнение с подключенным токеном от' }
                            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host 'System' -ForegroundColor Magenta
                        }
                        else  { Write-Host }
                    }
                }
                else
                {
                    $text = if ( $L.s8 ) { $L.s8 } else { 'Файлы ps1: Свои файлы ps1 не найдены' }
                    Write-Host "`n       $text" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s9 ) { $L.s9 } else { 'Файлы ps1: Нет папки для своих Файлов ps1' }
                Write-Host "`n       $text`: '$FolderForMySettings'" -ForegroundColor DarkGray
            }
        }
        elseif ( $CheckState -eq 'MySettingsCMD' )
        {
            if ( -not $ApplyMySettingsCMD )
            {
                $text = if ( $L.s11 ) { $L.s11 } else { 'Файлы cmd: Выполнение файлов cmd отключено в файле пресетов' }
                Write-Host "`n       $text" -ForegroundColor DarkGray

                Return
            }

            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $CmdFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                       ).Where({ $_.Name -match "\.bat$|\.cmd$" }).FullName
                if ( $CmdFiles.Count )
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { 'Файлы cmd' }
                    Write-Host "`n       $text`: "

                    [int] $CmdCount = 0
                    foreach ( $CmdFile in $CmdFiles )
                    {
                        $CmdCount++

                        [string] $CmdFileName = [System.IO.Path]::GetFileName($CmdFile)

                        Write-Host "$($CmdCount.ToString().PadLeft(11,' ')). " -ForegroundColor DarkGray -NoNewline
                        Write-Host 'cmd: ' -ForegroundColor DarkGray -NoNewline
                        Write-Host "$CmdFileName" -ForegroundColor Green
                    }
                }
                else
                {
                    $text = if ( $L.s12 ) { $L.s12 } else { 'Файлы cmd: Свои файлы cmd не найдены' }
                    Write-Host "`n       $text" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s13 ) { $L.s13 } else { 'Файлы cmd: Нет папки для своих Файлов cmd' }
                Write-Host "`n       $text`: '$FolderForMySettings'" -ForegroundColor DarkGray
            }
        }
        elseif ( $CheckState -eq 'MySettingsREG' )
        {
            if ( -not $ApplyMySettingsREG )
            {
                $text = if ( $L.s15 ) { $L.s15 } else { 'Файлы reg: Выполнение файлов reg отключено в файле пресетов' }
                Write-Host "`n       $text" -ForegroundColor DarkGray

                Return
            }

            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $RegFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                       ).Where({ $_.Name -like '*.reg' }).FullName
                if ( $RegFiles.Count )
                {
                    $text = if ( $L.s14 ) { $L.s14 } else { 'Файлы reg' }
                    Write-Host "`n       $text`: "

                    [int] $RegCount = 0
                    foreach ( $RegFile in $RegFiles )
                    {
                        $RegCount++

                        [string] $RegFileName = [System.IO.Path]::GetFileName($RegFile)

                        Write-Host "$($RegCount.ToString().PadLeft(11,' ')). " -ForegroundColor DarkGray -NoNewline
                        Write-Host 'reg: ' -ForegroundColor DarkGray -NoNewline
                        Write-Host "$RegFileName" -ForegroundColor Green
                    }
                }
                else
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Файлы reg: Свои файлы reg не найдены' }
                    Write-Host "`n       $text" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Файлы reg: Нет папки для своих Файлов reg' }
                Write-Host "`n       $text`: '$FolderForMySettings'" -ForegroundColor DarkGray
            }
        }
        elseif ( $CheckState -eq 'CurrentPreset' )
        {
            try { $CurrentQuickPresetsFile.Replace($CurrentRoot,'') } catch {}
        }

        Return      # Выход из функции.
    }



    # Далее, если выполнение ...


    [string] $RefreshExplorer = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class RefreshExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult);
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh()
        {
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);

            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);

            // Update taskbar
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");
        }

        private static readonly IntPtr hWnd = new IntPtr(65535);
        private const int Msg = 273;

        // Virtual key ID of the F5 in File Explorer
        private static readonly UIntPtr UIntPtr = new UIntPtr(41504);

        [DllImport("user32.dll", SetLastError=true)]
        public static extern int PostMessageW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);
        public static void PressF5Key()
        {
            // F5 pressing simulation to refresh the desktop
            PostMessageW(hWnd, Msg, UIntPtr, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.RefreshExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $RefreshExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    # Переменная для запускаемых функций, указать что выполняются группы настроек
    Set-Variable -Name MenuConfigsQuickSettings -Value $true -Option AllScope -Force

    if ( $Options -like 'SetConfigs' )
    {
        if ( $InputMenu ) { [bool] $RunQuickSettings = $true }

        if ( $Act -eq 'Default' )
        {
            $text = if ( $L.s18 ) { $L.s18 } else { 'Восстановление параметров по умолчанию' }
            Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s19 ) { $L.s19 } else { 'Функция' }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
        }
        else
        {
            $text = if ( $L.s20 ) { $L.s20 } else { 'Применение параметров' }
            Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s19 ) { $L.s19 } else { 'Функция' }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
        }

         [int] $NumVerify    = 0
        [bool] $NeedFixExist = $false

        foreach ( $Number in $QuickConfigs.Keys | Sort-Object )
        {
            $NumVerify++

            [string] $FunctionName = $QuickConfigs[$Number]['FunctionName']
            [string] $FunctionArgs = $QuickConfigs[$Number]['FunctionArgs']
            [string] $FunctionNote = $QuickConfigs[$Number]['FunctionNote']
              [bool] $FunctionSkip = $QuickConfigs[$Number]['FunctionSkip']

            # Проверяем существование функции.
            if ( $FunctionSkip )
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Функция для настройки Не существует' }

                Write-HostColor "`n#Red#██  $text`: #White#$FunctionName #DarkGray#| $FunctionNote#"

                Continue  # Переход к следующей итерации foreach.
            }
            else
            {
                $NeedFix = $false

                if ( $Act -eq 'Default' )
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { 'Восстановление' }
                    Write-Host "`n██ $text`: " -ForegroundColor Magenta -NoNewline
                }
                else
                {
                    $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'Применение' }
                    Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
                }

                Write-Host "$FunctionName " -ForegroundColor White -NoNewline
                Write-Host "| $FunctionNote" -ForegroundColor DarkGray -NoNewline

                # Если есть аргументы.
                if ( $FunctionArgs )
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { 'арг' }
                    Write-Host " | $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$FunctionArgs" -ForegroundColor White

                    [psobject] $FuncScriptBlock = [scriptblock]::Create( "$FunctionName $FunctionArgs" )

                    try { & $FuncScriptBlock }
                    catch
                    {
                        $text = if ( $L.s23 ) { $L.s23 } else { "Проблема запуска функции!`n`tКоманда" }
                        Write-Warning "$NameThisFunction`: $text`: $FuncScriptBlock`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                    }
                }
                else
                {
                    Write-Host

                    try { & $FunctionName }
                    catch
                    {
                        $text = if ( $L.s23 ) { $L.s23 } else { "Проблема запуска функции!`n`tКоманда" }
                        Write-Warning "$NameThisFunction`: $text`: $FunctionName`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                    }
                }

                if ( $NeedFix )
                {
                    [bool] $NeedFixExist = $true

                    $text = "`n     #White#$FunctionName #DarkGray#| #Yellow#{0}#" -f $(if ( $L.s24 ) { $L.s24 } else { 'Есть проблемы' })
                    Write-HostColor "$text"
                }
            }
        }

        if ( -not $NumVerify )
        {
            $text = if ( $L.s25 ) { $L.s25 } else { 'Нет параметров' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
        }
        else
        {
            if ( $NeedFixExist )
            {
                $text = if ( $L.s26 ) { $L.s26 } else { 'Были проблемы во время' }
                Write-Host "`n██████ $text " -ForegroundColor DarkYellow -NoNewline

                if ( $Act -eq 'Default' )
                {
                    $text = if ( $L.s26_1 ) { $L.s26_1 } else { 'восстановления!!!' }
                    Write-Host "$text" -ForegroundColor Magenta
                }
                else
                {
                    $text = if ( $L.s26_2 ) { $L.s26_2 } else { 'применения!!!' }
                    Write-Host "$text" -ForegroundColor Yellow
                }

                Write-Host "────────────────────────────────────────────────────────────────────────────────────────`n" -ForegroundColor DarkYellow
            }
            else
            {
                if ( $Act -eq 'Default' )
                {
                    $text = if ( $L.s27 ) { $L.s27 } else { 'Все параметры были восстановлены' }
                    Write-Host "`n██████ $text " -ForegroundColor Magenta -NoNewline
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Ошибок не было' }
                    Write-Host "$text" -ForegroundColor Green
                    Write-Host "────────────────────────────────────────────────────────────────────────────────────────`n" -ForegroundColor Magenta
                }
                else
                {
                    $text = if ( $L.s28 ) { $L.s28 } else { 'Все параметры были применены' }
                    Write-Host "`n██████ $text " -ForegroundColor Green -NoNewline
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Ошибок не было' }
                    Write-Host "$text" -ForegroundColor Green
                    Write-Host "────────────────────────────────────────────────────────────────────────────────────────`n" -ForegroundColor Green
                }
            }
        }
    }

    if ( $Options -like 'SetMySettingsPS' )
    {
        $text = if ( $L.s29 ) { $L.s29 } else { 'Выполнение Файлов' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline
        Write-Host 'ps1 ' -ForegroundColor White -NoNewline

        $text = if ( $L.s19 ) { $L.s19 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( -not $ApplyMySettingsPS )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
            Write-Host "`n           $text ps1 | " -NoNewline

            $text = if ( $L.s31 ) { $L.s31 } else { 'Выполнение файлов ps1 отключено в файле пресетов' }
            Write-Host "$text`n" -ForegroundColor DarkGray
        }
        else
        {
            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $PSFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                        ).Where({ $_.Name -like '*.ps1' }).FullName
                if ( $PSFiles.Count )
                {
                    [int] $PsCount = 0
                    foreach ( $PsFile in $PsFiles )
                    {
                        $PsCount++

                        [string] $PsFileName = [System.IO.Path]::GetFileName($PsFile)

                        Write-Host "`n$($PsCount.ToString().PadLeft(4,' '))" -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s30_1 ) { $L.s30_1 } else { 'Файл' }
                        Write-Host " ► $text ps1 | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$PsFileName " -ForegroundColor Cyan -NoNewline

                        if ( $PsFileName -like '*_TI.ps1' )
                        {
                            $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Выполнение с подключенным токеном от' }
                            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "TrustedInstaller `n" -ForegroundColor Magenta

                            Token-Impersonate -Token TI

                            Import-Module -Name $PsFile -Force -Scope Global -ErrorAction Continue

                            Token-Impersonate -Reset
                        }
                        elseif ( $PsFileName -like '*_SYS.ps1' )
                        {
                            $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Выполнение с подключенным токеном от' }
                            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "System `n" -ForegroundColor Magenta

                            Token-Impersonate -Token SYS

                            Import-Module -Name $PsFile -Force -Scope Global -ErrorAction Continue

                            Token-Impersonate -Reset
                        }
                        else
                        {
                            Write-Host "`n"

                            Import-Module -Name $PsFile -Force -Scope Global -ErrorAction Continue
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                    Write-Host "`n       $text ps1: " -NoNewline

                    $text = if ( $L.s32 ) { $L.s32 } else { 'Свои файлы ps1 не найдены' }
                    Write-Host "$text`n" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                Write-Host "`n       $text ps1: " -NoNewline

                $text = if ( $L.s33 ) { $L.s33 } else { 'Нет папки для своих Файлов ps1' }
                Write-Host "$text`: '$FolderForMySettings'`n" -ForegroundColor DarkGray
            }
        }
    }

    # Если был сброс всех Групповых Политик через функцию Set-Group-Policy, обнуляем глобальные параметры ГП и сбрасываем переменную GroupPoliciesReset.
    if ( $true -eq $GroupPoliciesReset ) { $Global:SettingsGP = @() ; $Global:RemoveValuesGP = @() ; $GroupPoliciesReset = $false }

    # Если есть подготовленные параметры Групповых Политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнить их применение.
    if ( $Global:SettingsGP -or $Global:RemoveValuesGP ) { Set-LGP -ApplyGP }

    if ( $Options -like 'SetMySettingsCMD' )
    {
        $text = if ( $L.s29 ) { $L.s29 } else { 'Выполнение Файлов' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline
        Write-Host 'cmd ' -ForegroundColor White -NoNewline

        $text = if ( $L.s19 ) { $L.s19 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( -not $ApplyMySettingsCMD )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
            Write-Host "`n           $text cmd | " -NoNewline

            $text = if ( $L.s34 ) { $L.s34 } else { 'Выполнение файлов cmd отключено в файле пресетов' }
            Write-Host "$text`n" -ForegroundColor DarkGray
        }
        else
        {
            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $CmdFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                       ).Where({ $_.Name -match '\.bat$|\.cmd$' }).FullName
                if ( $CmdFiles.Count )
                {
                    [int] $CmdCount = 0
                    foreach ( $CmdFile in $CmdFiles )
                    {
                        $CmdCount++

                        [string] $CmdFileName = [System.IO.Path]::GetFileName($CmdFile)

                        Write-Host "`n$($CmdCount.ToString().PadLeft(4,' '))" -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s30_1 ) { $L.s30_1 } else { 'Файл' }
                        Write-Host " ► $text cmd | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$CmdFileName`n" -ForegroundColor Cyan

                        try { & "$env:SystemDrive\Windows\system32\cmd.exe" /c "$CmdFile" } catch {}
                    }
                }
                else
                {
                    $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                    Write-Host "`n       $text cmd: " -NoNewline

                    $text = if ( $L.s35 ) { $L.s35 } else { 'Свои файлы cmd не найдены' }
                    Write-Host "$text`n" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                Write-Host "`n       $text cmd: " -NoNewline

                $text = if ( $L.s36 ) { $L.s36 } else { 'Нет папки для своих Файлов cmd' }
                Write-Host "$text`: '$FolderForMySettings'`n" -ForegroundColor DarkGray
            }
        }
    }

    if ( $Options -like 'SetMySettingsREG' )
    {
        $text = if ( $L.s29 ) { $L.s29 } else { 'Выполнение Файлов' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline
        Write-Host 'reg ' -ForegroundColor White -NoNewline

        $text = if ( $L.s19 ) { $L.s19 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( -not $ApplyMySettingsREG )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
            Write-Host "`n           $text reg | " -NoNewline

            $text = if ( $L.s37 ) { $L.s37 } else { 'Выполнение файлов reg отключено в файле пресетов' }
            Write-Host "$text`n" -ForegroundColor DarkGray
        }
        else
        {
            if ( [System.IO.Directory]::Exists($FolderForMySettings) )
            {
                [string[]] $RegFiles = (Get-ChildItem -File -LiteralPath $FolderForMySettings -Force -ErrorAction SilentlyContinue
                                       ).Where({ $_.Name -like '*.reg' }).FullName
                if ( $RegFiles.Count )
                {
                    [int] $RegCount = 0
                    foreach ( $RegFile in $RegFiles )
                    {
                        $RegCount++

                        [string] $RegFileName = [System.IO.Path]::GetFileName($RegFile)

                        Write-Host "`n$($RegCount.ToString().PadLeft(4,' '))" -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s30_1 ) { $L.s30_1 } else { 'Файл' }
                        Write-Host " ► $text reg | " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$RegFileName`n" -ForegroundColor Cyan

                        try { & "$env:SystemDrive\Windows\system32\reg.exe" Import "$RegFile" } catch {}
                    }
                }
                else
                {
                    $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                    Write-Host "`n       $text reg: " -NoNewline

                    $text = if ( $L.s38 ) { $L.s38 } else { 'Свои файлы reg не найдены' }
                    Write-Host "$text`n" -ForegroundColor DarkGray
                }
            }
            else
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Файлы' }
                Write-Host "`n       $text reg: " -NoNewline

                $text = if ( $L.s39 ) { $L.s39 } else { 'Нет папки для своих Файлов reg' }
                Write-Host "$text`: '$FolderForMySettings'`n" -ForegroundColor DarkGray
            }
        }
    }

    if ( $InputMenu ) { [bool] $RunQuickSettings = $false }

    Start-Sleep -Milliseconds 500
    [WinAPI.RefreshExplorer]::Refresh()
    Start-Sleep -Milliseconds 500
    [WinAPI.RefreshExplorer]::PressF5Key()

    Get-Pause
}
