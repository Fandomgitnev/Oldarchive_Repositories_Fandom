﻿
<#
.SYNOPSIS
 Отключение всех настроек конфиденциальности для режима OOBE
 в том числе в NTUSER.DAT дефолтного профиля и всех подключенных других профилей (для пропуска окна при первом входе в Новый Аккаунт)

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата
 Используется функция Set-LGP для установки параметров реестра и ГП, с проверкой и выводом результата
 Используется функция RegHives-User-LoadUnload для Подгрузки и Выгрузки кустов реестра дефолтного профиля
 Используется функция Show-Info для вывода названия с нужным форамтированием

 Можно использовать для исключения проблемы при входе в новый аккаунт, после удаления UWP App: Microsoft.Windows.CloudExperienceHost
 Настройки конфиденциальности будут предустановлены для всех создающихся после этого аккаунтов,
 и предложение о их настройке не появляется, что исключает все проблемы далее при использовании Windows на этом аккаунте.
 Достаточно запрета в ГП, но эти параметры могут быть легко сброшены, поэтому не надёжны.

 Настройки кроме раздела Privacy можно переопределить на свои (включить)

.EXAMPLE
    Set-PrivacySettingsOOBE

.EXAMPLE
    Set-PrivacySettingsOOBE Default


.NOTES
 ================================================
     Автор:  westlife (ru-board)  Версия 1.01
      Дата:  12-06-2020
 ================================================

#>
Function Set-PrivacySettingsOOBE {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
    )

    # Получение имени этой функции.
    $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия.
    # для получения предустановок для Распознования голоса и Местоположения для функции Set-Configs-SyncApps
    [string[]] $Groups = Get-Configs-Groups -Actions $Act -FuncName 'Set-Configs-SyncApps'

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    $Info = 'Отключение всех настроек конфиденциальности для режима OOBE в NTUSER.DAT'

    if ( $Act -ne 'Default' )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
        # бэкап проверяется и создается при необходимости
        RegHives-User-LoadUnload -DefaultProfile -Load

        # Запретить запускать настройки конфиденциальности при первом входе в аккаунт
        # Эти 2 параметра на всякий случай, могут быть легко сброшены по умолчанию, не надёжно, HKCU имеет приоритет.
        # Могут быть переопределены непосредственно через ГП так как ГП на параметры в реестре "по барабану", и применяются после создания HKCU из NTUSER.DAT
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OOBE' -Name 'DisablePrivacyExperience' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\OOBE' -Name 'DisablePrivacyExperience' -Type DWord 1

        # Если пресет настроен на отключение Конфиденциального доступа к "Распознование голоса"
        if ( $Groups -like 'Apps-PrivacyAccess-VoiceRecogn' )
        {
            # Отправлять Распознование голоса в сети для Кортаны и др ('Отключить Конфиденциальный доступ к "Распознование голоса"'): 0 = Отключено; 1 = Включено
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' -Name 'HasAccepted' -Type DWord 0
        }
        else
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' -Name 'HasAccepted' -Type DWord 1
        }

        # Если пресет настроен на отключение Конфиденциального доступа к "Расположение"
        if ( $Groups -like 'Apps-PrivacyAccess-Location' )
        {
            # Передавать Местоположение (Отключить Конфиденциальный доступ к "Расположение"): Deny = Запрещено; Allow = Разрешено
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Deny'
        }
        else
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value' -Type String 'Allow'
        }

        # Разрешить поиск этого устройства: 0 = Отключено; 1 = Включено. Зависит от Местоположения
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Settings\FindMyDevice' -Name 'LocationSyncEnabled' -Type DWord 0

        # Отправлять данные Рукописного ввода и с клавиатуры: 0 = Отключено; 1 = Включено
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\TIPC' -Name 'Enabled' -Type DWord 0

        # Отправлять индивидуальный идентификатор "для персональной рекламы": 0 = Отключено; 1 = Включено
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id' -Type String 'null'

        # Разрешить Авторизацию через камеру: 0 = Отключено; 1 = Включено
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\AccessPage\Camera' -Name 'CameraEnabled' -Type DWord 0

        # Отправка индивидуальных Диагностических данных: 0 = Отключено; 1 = Включено
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -Type DWord 0

        # Указать версию настроек конфиденциальности
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'PrivacyConsentPresentationVersion' -Type DWord 2
        # Если версия старше 19041 (2004)
        if ( [System.Environment]::OSVersion.Version.Build -lt 19041 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'PrivacyConsentSettingsVersion' -Type DWord 2
        }
        else
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'PrivacyConsentSettingsVersion' -Type DWord 3
        }

        # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
        RegHives-User-LoadUnload -DefaultProfile -Unload
    }
    else
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
        # бэкап проверяется и создается при необходимости
        RegHives-User-LoadUnload -DefaultProfile -Load

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OOBE'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\OOBE'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' -Name 'HasAccepted'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' -Name 'Value'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Settings\FindMyDevice' -Name 'LocationSyncEnabled'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\TIPC' -Name 'Enabled'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\AccessPage\Camera' -Name 'CameraEnabled'

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -Type DWord 2
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'PrivacyConsentPresentationVersion'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'PrivacyConsentSettingsVersion'

        # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
        RegHives-User-LoadUnload -DefaultProfile -Unload
    }
}
