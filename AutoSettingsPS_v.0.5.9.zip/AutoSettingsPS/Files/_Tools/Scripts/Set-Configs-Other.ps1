﻿
# Группы параметров, не относящиеся к чему либо конкретно. Наборы параметров для разных настроек.
Function Set-Configs-Other {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [PSCustomObject] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem
    if ( -not $Groups.Length ) { Write-Host "`n   $($Lang.$NameThisFunction.s0)" -ForegroundColor DarkGray }

    # Далее сами настройки ...



    $Info = 'Отключить Службу ''Retail Demo'' (скрытый режим для розничной торговли)'
    $Group = 'Other-RetailDemo' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'RetailDemo' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'RetailDemo' -StartupType Manual
    }



    $Info = 'Отключить Службу маршрутизации push-сообщений WAP'
    $Group = 'Other-DMWapPushService' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Служба маршрутизации push-сообщений WAP (нужна для Unified Write Filter):' | Show-Info -Shift $L.s2 -NotIndent
        # Проблема: Если отключить dmwappushservice, то не включить UWF Unified Write Filter (Объединенный фильтр записи)
        # И поиск обновлений через ЦО может длиться до 10 минут.
        Set-Svc -Do:$Act Set-Service -Name 'dmwappushservice' -StartupType Disabled -OrigCmdlet
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'dmwappushservice' -StartupType Manual
    }



    $Info = 'Отключить Службу общих сетевых ресурсов проигрывателя Windows Media'
    $Group = 'Other-WMPNetworkSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'WMPNetworkSvc' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'WMPNetworkSvc' -StartupType Manual

        # Служба поиска WSearch нужна для работы служб WMPNetworkSvc и fhsvc (File History)
        Set-Svc Set-Service -Name 'WSearch' -StartupType DelayedAuto
    }



    $Info = 'Отключить Задачу ''Обновление новых файлов в библиотеке мультимедиа'''
    $Group = 'Other-WMPTaskUpdateLib' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Media Sharing\UpdateLibrary'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Media Sharing\UpdateLibrary'
    }



    $Info = 'Отключить Доступ в интернет службе защиты аудио - Windows Media Digital Rights Management (DRM)'
    $Group = 'Other-WMDRM' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Управление цифровыми правами Windows Media "Запретить доступ к Интернету для Windows Media DRM" (включена)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WMDRM' -Name 'DisableOnline' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WMDRM' -Name 'DisableOnline'
    }



    $Info = 'Отключить Службу ''Управление сервером сетевой политики'''
    $Group = 'Other-NPSMSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'NPSMSvc' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'NPSMSvc' -StartupType Manual
    }



    $Info = 'Отключить Службу ''Служба политики отображения'''
    $Group = 'Other-DispBrokerDesktopSvc' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'DispBrokerDesktopSvc' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'DispBrokerDesktopSvc' -StartupType DelayedAuto
    }



    $Info = 'Отключить Задачу ''Очистка системного диска во время простоя'''
    $Group = 'Other-Task1' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DiskCleanup\SilentCleanup'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DiskCleanup\SilentCleanup'
    }



    $Info = 'Отключить Задачу ''Оценка объема использования диска'''
    $Group = 'Other-Task2' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DiskFootprint\Diagnostics'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DiskFootprint\Diagnostics'
    }



    $Info = 'Отключить Задачу ''Перемещение Modern Apps на другой диск по необходимости'''
    $Group = 'Other-Task3' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DiskFootprint\StorageSense'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DiskFootprint\StorageSense'
    }



    $Info = 'Отключить Задачу ''Проверка томов на отказоустойчивость'''
    $Group = 'Other-Task4' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan'
    }



    $Info = 'Отключить Задачу ''Проверка томов на отказоустойчивость'''
    $Group = 'Other-Task5' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan for Crash Recovery'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Data Integrity Scan\Data Integrity Scan for Crash Recovery'
    }



    $Info = 'Отключить Задачу ''Измерение быстродействия и возможности системы'''
    $Group = 'Other-Task6' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Maintenance\WinSAT'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Maintenance\WinSAT'
    }



    $Info = 'Отключить Задачу ''Обслуживание памяти во время простоя и при ошибках'''
    $Group = 'Other-Task7' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\MemoryDiagnostic\ProcessMemoryDiagnosticEvents'
    }



    $Info = 'Отключить Задачу ''Обслуживание памяти во время простоя и при ошибках'''
    $Group = 'Other-Task8' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\MemoryDiagnostic\RunFullMemoryDiagnostic'
    }



    $Info = 'Отключить Задачу ''Анализирование энергопотребления системы'''
    $Group = 'Other-Task9' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem'
    }



    $Info = 'Отключить Задачу ''Очистка контента Retail Demo'''
    $Group = 'Other-Task10' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\RetailDemo\CleanupOfflineContent'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\RetailDemo\CleanupOfflineContent'
    }



    $Info = 'Отключить Задачу ''Уведомление о вашем расположении'''
    $Group = 'Other-Task11' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Location\Notifications'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Location\Notifications'
    }



    $Info = 'Отключить Задачу ''Уведомление о вашем расположении'''
    $Group = 'Other-Task12' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Location\WindowsActionDialog'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Location\WindowsActionDialog'
    }



    $Info = 'Отключить Задачу ''Очистка языковых параметров'''
    $Group = 'Other-Task13' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\MUI\LPRemove'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\MUI\LPRemove'
    }



    $Info = 'Отключить Задачу ''Обслуживание дисковых пространств (аналог RAID, виртуальные диски)'''
    $Group = 'Other-Task14' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\SpacePort\SpaceAgentTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\SpacePort\SpaceAgentTask'
    }



    $Info = 'Отключить Задачу ''Обслуживание дисковых пространств (аналог RAID, виртуальные диски)'''
    $Group = 'Other-Task15' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\SpacePort\SpaceManagerTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\SpacePort\SpaceManagerTask'
    }



    $Info = 'Отключить Задачу ''Загрузка голосовых моделей'''
    $Group = 'Other-Task16' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Speech\SpeechModelDownloadTask'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Speech\SpeechModelDownloadTask'
    }



    $Info = 'Отключить Задачу ''Active Directory'''
    $Group = 'Other-Task17' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Active Directory Rights Management Services Client\AD RMS Rights Policy Template Management (Manual)'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\Active Directory Rights Management Services Client\AD RMS Rights Policy Template Management (Manual)'
    }



    $Info = 'Отключить Задачу ''Active Directory'''
    $Group = 'Other-Task18' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\File Classification Infrastructure\Property Definition Sync'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\File Classification Infrastructure\Property Definition Sync'
    }



    $Info = 'Отключить Задачу ''Work Folders Logon Synchronization'''
    $Group = 'Other-Task19' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Work Folders\Work Folders Logon Synchronization'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Work Folders\Work Folders Logon Synchronization'
    }



    $Info = 'Отключить Задачу ''Work Folders Maintenance Work'''
    $Group = 'Other-Task20' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Work Folders\Work Folders Maintenance Work'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Work Folders\Work Folders Maintenance Work'
    }



    $Info = 'Отключить задачи ProvTool.exe (для SYSPREP и изменения редакции Windows)'
    $Group = 'Other-Provisioning' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Задачи по согласованию пакетов во время SYSPREP и др. через 'ProvTool.exe':" | Show-Info -Shift $L.s2 -NotIndent
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Management\Provisioning\Logon'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Management\Provisioning\Cellular'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Management\Provisioning\Logon'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Management\Provisioning\Cellular'
    }



    $Info = 'Отключить Сопряжение с дисплеями Wi-Fi и устр. Bluetooth'
    $Group = 'Other-Displays' ; $L = $Lang.$Group

    # Если отключить (настроить) или выполнить проверку.
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'ConsentUxUserSvc' -StartupType Disabled

        # Проблема: Если отключить 'DevicesFlowUserSvc' Параметры будут крашится при заходе в Раздел "Устройства"
        # Set-Svc -Do:$Act Set-Service -Name 'DevicesFlowUserSvc' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Иначе восстановить по умолчанию.

        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'ConsentUxUserSvc' -StartupType Manual

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\ConsentUxUserSvc','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\ConsentUxUserSvc' -Name 'UserServiceFlags' -Type DWord 3
        }

        Set-Svc Set-Service -Name 'DevicesFlowUserSvc' -StartupType Manual

        try { $ImagePath = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\DevicesFlowUserSvc','ImagePath',$null) }
        catch { $ImagePath = $null }

        if ( $ImagePath )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\DevicesFlowUserSvc' -Name 'UserServiceFlags' -Type DWord 3
        }
    }



    $Info = 'Отключить автоподключения к неизвестным WiFi'
    $Group = 'Other-WiFi-Settings' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Отключить автопередачу паролей к своим WiFi на сервер Microsoft (WiFiSense):' | Show-Info -Shift $L.s2 -NotIndent
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots' -Name 'value' -Type DWord 0

        'Запретить автоподключение к WiFi без пароля и от моих контактов:' | Show-Info -Shift $L.s3
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config' -Name 'AutoConnectAllowedOEM' -Type DWord 0

        # Автоподключение к WiFi и сбор сведений [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DataCollection\Default\WifiAutoConnectConfig' -Name 'AutoConnectEnabled' -Type DWord 0

        Write-Host

        # Сети Hotspot 2.0 : Разрешить использовать веб-службу регистрации для подключения [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WlanSvc\AnqpCache' -Name 'OsuRegistrationStatus' -Type DWord 0

        # Создание и совместное использование профилей (недокументированные параметры) [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\features' -Name 'WiFiSenseOpen' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\features' -Name 'WiFiSenseCredShared' -Type DWord 0

        # Отправка данных в Outlook.com [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\ABCH' -Name 'OptInStatus' -Type DWord 0
        # Отправка данных в Skype  [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\ABCH-SKYPE' -Name 'OptInStatus' -Type DWord 0
        # Отправка данных в Facebook  [ Отключено ]
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\FACEBOOK' -Name 'OptInStatus' -Type DWord 0


        'Запрет автоподключения к WiFi без паролей всем пользователям, найденных в этом разделе:' | Show-Info -Shift $L.s4
        ' 316 = Все отключено; 317 = только автоподключение к WiFi без пароля'                    | Show-Info -Shift $L.s5 -NotIndent
        '1853 = Все включено;  380 = только автоподключение к WiFi от ваших контактов'            | Show-Info -Shift $L.s6 -NotIndent

        # (0x73d) 1853 = Все включено
        # (0x37c)  892 = Автоподключение к Wi-Fi своих контактов и к платным услугам
        # (0x33d)  829 = Автоподключение к Wi-Fi без пароля и к платным услугам
        # (0x17d)  381 = Автоподключение к Wi-Fi без пароля, а также к своим контактам
        # (0x33c)  828 = Автоподключение только к платным услугам
        # (0x17c)  380 = Автоподключение только к Wi-Fi своих контактов
        # (0x13d)  317 = Автоподключение только к Wi-Fi без пароля
        # (0x13c)  316 = Все отключено

        [string] $SubKey = 'SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\features'
        [string] $Path = ''
        [string[]] $FoundSubkeys = $null

        try
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            $FoundSubkeys = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like 'S-1*' })
            $OpenSubKey.Close()
        }
        catch {}

        [int] $NumKeys = 0
        foreach ( $FoundSubkey in $FoundSubkeys ) {
            $NumKeys++

            $Path = "HKLM:\$SubKey\$FoundSubkey"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'FeatureStates' -Type DWord 316

            $Path = "HKLM:\$SubKey\$FoundSubkey\SocialNetworks\ABCH"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OptInStatus' -Type DWord 0

            $Path = "HKLM:\$SubKey\$FoundSubkey\SocialNetworks\ABCH-SKYPE"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OptInStatus' -Type DWord 0

            $Path = "HKLM:\$SubKey\$FoundSubkey\SocialNetworks\FACEBOOK"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OptInStatus' -Type DWord 0
        }

        if ( -not $NumKeys )
        {
            $text = if ( $L.s7 ) { $L.s7 } else { 'Нет разделов для WiFi' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }

        'Служба для Windows Connect Now, настраивает параметры точки доступа или WiFi:' | Show-Info -Shift $L.s8
        Set-Svc -Do:$Act Set-Service -Name 'wcncsvc' -StartupType Disabled

        'Задачи для фонового взаимодействия через WiFi:' | Show-Info -Shift $L.s9
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\NlaSvc\WiFiTask'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WCM\WiFiTask'

        'Задачи синхронизации и обнаружении WiFi и профилей eSIM-карт:' | Show-Info -Shift $L.s10
        # Wlan Sync task WiFiCloudStore.dll
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WlanSvc\CDSSync'
        # WiFiTask.exe
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WwanSvc\NotificationTask'
        # MBMediaManager.dll OobeEsimDiscoveryTask
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WwanSvc\OobeDiscovery'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots' -Name 'value' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\config' -Name 'AutoConnectAllowedOEM'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\DataCollection\Default\WifiAutoConnectConfig' -Name 'AutoConnectEnabled' -Type DWord 1

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WlanSvc\AnqpCache' -Name 'OsuRegistrationStatus' -Type DWord 0
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\features' -Name 'WiFiSenseOpen'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\features' -Name 'WiFiSenseCredShared'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\ABCH' -Name 'OptInStatus'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\ABCH-SKYPE' -Name 'OptInStatus'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\WcmSvc\wifinetworkmanager\SocialNetworks\FACEBOOK' -Name 'OptInStatus'

        Set-Svc Set-Service -Name 'wcncsvc' -StartupType Manual

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\NlaSvc\WiFiTask'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\WCM\WiFiTask'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\WlanSvc\CDSSync'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\WwanSvc\NotificationTask'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\WwanSvc\OobeDiscovery'
    }



    $Info = 'Отключить Проекцию на этот компьютер'
    $Group = 'Other-ProjectionToPC' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Проекция на этот компьютер с других устройств, кроме ручной:" | Show-Info -Shift $L.s2 -NotIndent
        # ГП: Компоненты Windows/Подключить
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Connect' -Name 'AllowProjectionToPC' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Connect' -Name 'AllowProjectionToPC'
    }



    $Info = 'Отключить Zone.Identifier'
    $Group = 'Other-Zone.Identifier' ; $L = $Lang.$Group

    # Несколько вариантов настройки для возможности выбрать вариант для исключения бага хромиум браузеров при сохранении файла на рабочий стол и его не отображении без обновления.
    if ( $Groups -like "$Group-?" )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( $Groups -like "$Group-1" )
        {
            "Отключить сохранение сведений о зоне происхождения файлов (Zone.Identifier) (Будет баг):" | Show-Info -Shift $L.s2 -NotIndent
            # ГП: Конфиг. Пользователя > адм. шаблоны > компоненты Windows > диспетчер вложений
            # Параметр "LowRiskFileTypes" нужен для отключения запроса при уже сохраненной зоне происхождения файла.
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'HideZoneInfoOnProperties' -Type DWord 0
        }
        elseif ( $Groups -like "$Group-2" )
        {
            "Включить Игнорирование сведений о зоне происхождения файлов:" | Show-Info -Shift $L.s3 -NotIndent
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'HideZoneInfoOnProperties' -Type DWord 0
        }
        elseif ( $Groups -like "$Group-3" )
        {
            "Включить Игнорирование + скрыть её из свойств файла:" | Show-Info -Shift $L.s4 -NotIndent
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'HideZoneInfoOnProperties' -Type DWord 1
        }

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'DefaultFileTypeRisk' -Type DWord 6152

        # [string] $Value = '.7z;.zip;.rar;.iso;.nfo;.txt;.inf;.ini;.xml;.pdf;.bat;.com;.cmd;.reg;.msi;.exe;.htm;.html;.gif;.png;.bmp;.jpg;.avi;.mpg;.mpeg;.mov;.mkv;.flv;.srt;.flac;.mp3;.m3u;.cue;.wav;.chm;.mdb;'
        # Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Type String $Value

        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Zone-LowRiskFileTypes\s*=\s*1\s*=\s*(?<Ext>(\s*[.][a-z0-9]{1,}[;]\s*)+)\s*=" },'First') )
        {
            [string] $Value = $Matches.Ext -Replace('\s','')

            Write-Host "`n   • LowRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline

            if ( $Value.Length -gt 214 )
            {
                Write-Host "$($Value.Substring(0,214))" -ForegroundColor DarkGray
                Write-Host "                       $($Value.Substring(214))" -ForegroundColor DarkGray
            }
            else { Write-Host "$Value" -ForegroundColor DarkGray }

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes' -Type String $Value
        }
        else
        {
            Write-Host "`n   • LowRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline
            Write-Host '---' -ForegroundColor DarkGray

            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes'
        }

        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Zone-ModRiskFileTypes\s*=\s*1\s*=\s*(?<Ext>(\s*[.][a-z0-9]{1,}[;]\s*)+)\s*=" },'First') )
        {
            [string] $Value = $Matches.Ext -Replace('\s','')

            Write-Host "`n   • ModRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline

            if ( $Value.Length -gt 214 )
            {
                Write-Host "$($Value.Substring(0,214))" -ForegroundColor DarkGray
                Write-Host "                       $($Value.Substring(214))" -ForegroundColor DarkGray
            }
            else { Write-Host "$Value" -ForegroundColor DarkGray }

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'ModRiskFileTypes' -Type String $Value
        }
        else
        {
            Write-Host "`n   • ModRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline
            Write-Host '---' -ForegroundColor DarkGray

            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'ModRiskFileTypes'
        }

        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Zone-HighRiskFileTypes\s*=\s*1\s*=\s*(?<Ext>(\s*[.][a-z0-9]{1,}[;]\s*)+)\s*=" },'First') )
        {
            [string] $Value = $Matches.Ext -Replace('\s','')

            Write-Host "`n   • HighRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline

            if ( $Value.Length -gt 214 )
            {
                Write-Host "$($Value.Substring(0,214))" -ForegroundColor DarkGray
                Write-Host "                       $($Value.Substring(214))" -ForegroundColor DarkGray
            }
            else { Write-Host "$Value" -ForegroundColor DarkGray }

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'HighRiskFileTypes' -Type String $Value
        }
        else
        {
            Write-Host "`n   • HighRiskFileTypes: " -ForegroundColor DarkCyan -NoNewline
            Write-Host '---' -ForegroundColor DarkGray

            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'HighRiskFileTypes'
        }
    }
    elseif ( $Groups -like "$Group-?-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'SaveZoneInformation'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Attachments' -Name 'HideZoneInfoOnProperties'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'DefaultFileTypeRisk'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'LowRiskFileTypes'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'ModRiskFileTypes'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Associations' -Name 'HighRiskFileTypes'
    }



    $Info = 'Отключить Фрейм Сервер MS для веб-камер'
    $Group = 'Other-Webcam-FrameServer' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Отключить Фрейм Сервер M$, решает или создаёт проблему с блокировкой веб камеры'             | Show-Info -Shift $L.s2 -NotIndent
        'Фрейм Сервер Позволяет получать доступ к одной камере нескольким Приложениям/Пользователям:' | Show-Info -Shift $L.s3 -NotIndent

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Media Foundation\Platform' -Name 'EnableFrameServerMode' -Type DWord 0

        if ( $is64 ) {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows Media Foundation\Platform' -Name 'EnableFrameServerMode' -Type DWord 0
        }

        Set-Svc -Do:$Act Set-Service -Name 'FrameServer' -StartupType Disabled
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Media Foundation\Platform' -Name 'EnableFrameServerMode'

        if ( $is64 ) {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows Media Foundation\Platform' -Name 'EnableFrameServerMode'
        }

        Set-Svc Set-Service -Name 'FrameServer' -StartupType Manual
    }



    $Info = 'Запретить выполнение программы Звукозапись'
    $Group = 'Other-SoundRecorder' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # ГП: Компоненты Windows/Звукозапись
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SoundRecorder' -Name 'Soundrec' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SoundRecorder' -Name 'Soundrec'
    }



    $Info = 'Отключить Цифровой ящик Windows Marketplace'
    $Group = 'Other-DigitalLocker' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Запртетить цифровой ящик Windows Marketplace:' | Show-Info -Shift $L.s2 -NotIndent
        # ГП: Компоненты Windows/Цифровой ящик
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Digital Locker' -Name 'DoNotRunDigitalLocker' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Digital Locker' -Name 'DoNotRunDigitalLocker'
    }



    $Info = 'Отключить Историю файлов (Архивация)'
    $Group = 'Other-FileHistory' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Служба истории файлов:' | Show-Info -Shift $L.s2 -NotIndent
        # Отключение оригинальным компандлетом, так как при приминение ГП через LGPO.exe, процесс svchost.exe включает её обратно, если отключать службу через реестр.
        Set-Svc -Do:$Act Set-Service -Name 'fhsvc' -StartupType Disabled -Status Stopped -OrigCmdlet

        'Отключение архивации:' | Show-Info -Shift $L.s3
        # Комп\Адм. Шабл\Компоненты Windows\История файлов" (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\FileHistory' -Name 'Disabled' -Type DWord 1

        'Отключение лога журнала архивации:' | Show-Info -Shift $L.s4
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-FileHistory-Engine/BackupLog' -Name 'Enabled' -Type DWord 0

        'Отключение отображения вкладки ''Предыдущие версии'' в свойствах файлов' | Show-Info -Shift $L.s5
        'И Удалить пункт ''Восстановить прежнюю версию'' из контекстного меню:'   | Show-Info -Shift $L.s6 -NotIndent
        # Два эти параметра делают одно и тоже.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'NoPreviousVersionsPage' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{596AB062-B4D2-4215-9F74-E9109B0A8153}' -Type String ''

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{596AB062-B4D2-4215-9F74-E9109B0A8153}' -Type String ''
        }

        'Задача для использования архивации (Работает только от Автообслуживания):' | Show-Info -Shift $L.s7
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\FileHistory\File History (maintenance mode)'

        # Скрытие раздела архивации из модерн параметров (В Обновление и Безопасность)
        Set-SettingsPageVisibility -Act:$Act -Names 'backup'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'fhsvc' -StartupType Manual -OrigCmdlet
        # Служба поиска WSearch нужна для работы служб WMPNetworkSvc и fhsvc (File History)
        Set-Svc Set-Service -Name 'WSearch' -StartupType DelayedAuto

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\FileHistory'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-FileHistory-Engine/BackupLog' -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'NoPreviousVersionsPage'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{596AB062-B4D2-4215-9F74-E9109B0A8153}'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{596AB062-B4D2-4215-9F74-E9109B0A8153}'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\FileHistory\File History (maintenance mode)'

        Set-SettingsPageVisibility -Names 'backup' -Remove
    }



    $Info = 'Отключить Автоматический запуск приложений после перезагрузки'
    $Group = 'Other-AutoStart' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Параметры входа в Windows\ "Автоматически выполнить вход последнего текущего пользователя после инициированной системой перезагрузки"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DisableAutomaticRestartSignOn' -Type DWord 1

        [array] $SIDs = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.ProfileType -eq 'User' })).ForEach({ $SIDs += $_.SID })
        }

        foreach ( $SID in ( $SIDs | Sort-Object -Unique ))
        {
            $Path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\UserARSO\$SID"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OptOut' -Type DWord 1
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'DisableAutomaticRestartSignOn'

        [array] $SIDs = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.ProfileType -eq 'User' })).ForEach({ $SIDs += $_.SID })
        }

        foreach ( $SID in ( $SIDs | Sort-Object -Unique ))
        {
            $Path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\UserARSO\$SID"
            Set-Reg New-ItemProperty -Path $Path -Name 'OptOut' -Type DWord 0
        }
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$NameThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { 'Необходимо перезагрузиться!' }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen

        Get-Pause
    }
}

