﻿
<#
.SYNOPSIS
 Настройка Проводника для скрытия/возврата папок пользователя,
 дубликатов устройств, значка сеть и Быстрого доступа.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Explorer_Settings.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра,
 с проверкой и выводом результата. Независимо от доступа, если не блокируется драйвером.
 Используется функция Expand-Path для раскрытия путей.
 Используется функция Get-List-Presets

 Константы для shell Attributes
 https://docs.microsoft.com/en-us/windows/win32/shell/sfgao?redirectedfrom=MSDN
 0xa0100000 (оригинал) + 0x00080000 (SFGAO_HIDDEN) = # HEX = 0xa0180000 | Dec (uint) = 2685927424

 "0x{0:x2}" -f (0xa0100000 + 0x00080000)

 Блокирует drag в левую панель в дерево папок:
 0xa0100000 (оригинал) + 0x00100000 (SFGAO_NONENUMERATED) + 0x00400000 (SFGAO_STREAM) = # HEX = 0xa0600000 | Dec (uint) = 2690646016

 Появляется значок на раб столе:
 0xa0100000 (оригинал) + 0x00080000 (SFGAO_HIDDEN) + 0x00100000 (SFGAO_NONENUMERATED) =  # HEX = 0xa0280000

.EXAMPLE
    Set-Explorer-Settings -Options VideoHide -Act Set

    Описание
    --------
    Скрыть папку Видео из проводника.

.EXAMPLE
    Set-Explorer-Settings -CheckState DocumentsHide

    Описание
    --------
    Проверить состояние отображения папки Документы.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  21-04-2019
 ===============================================

#>
Function Set-Explorer-Settings {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут 'Check' не используется, оставлено, чтобы было по стандарту и не выкидывало ошибок, если будет использовано.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide',
                      'DuplicateDevicesHide', 'NetIconHide', 'QuickAccessHide', 'ClearIconCache', 'ClearThumbCache', 'SetWallPaper' )]
        [string[]] $Options = '3dHide'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide',
                      'DuplicateDevicesHide', 'NetIconHide', 'QuickAccessHide', 'WallPaper', 'ImageForWallPaper' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [string] $GraphicsFileFolder = $FileFolderGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    # Действие = Название Папки для отображения, CLSID, CLSID TargetKnownFolder, CLSID BaseFolder (если есть)
    [hashtable] $FoldersData = @{
        'VideoHide'     = ('{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Видео'            })),'{F86FA3AB-70D2-4FC7-9C99-FCBF05467F3A}','{35286A68-3C57-41A1-BBB1-0EAE73D76C95}','{A0953C92-50DC-43BF-BE83-3742FED03C9C}','CLSID_ThisPCLocalVideosRegFolder'
        'DocumentsHide' = ('{0}' -f $(if ( $L.s2 ) { $L.s2 } else { 'Документы'        })),'{D3162B92-9365-467A-956B-92703ACA08AF}','{F42EE2D3-909F-4907-8871-4C22FC0BF756}','{A8CDFF1C-4878-43BE-B5FD-F8091C1C60D0}','CLSID_ThisPCLocalDocumentsRegFolder'
        'DownloadsHide' = ('{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Загрузки'         })),'{088E3905-0323-4B02-9826-5D99428E115F}','{7D83EE9B-2244-4E70-B1F5-5393042AF1E4}','{374DE290-123F-4565-9164-39C4925E467B}','CLSID_ThisPCLocalDownloadsRegFolder'
        'PicturesHide'  = ('{0}' -f $(if ( $L.s4 ) { $L.s4 } else { 'Изображения'      })),'{24AD3AD4-A569-4530-98E1-AB02F9417AA8}','{0DDD015D-B06C-45D5-8C4C-F59713854639}','{3ADD1653-EB32-4CB0-BBD7-DFA0ABB5ACCA}','CLSID_ThisPCLocalPicturesRegFolder'
        'MusicHide'     = ('{0}' -f $(if ( $L.s5 ) { $L.s5 } else { 'Музыка'           })),'{3DFDF296-DBEC-4FB4-81D1-6A3438BCF4DE}','{A0C69A99-21C8-4671-8703-7934162FCF1D}','{1CF1260C-4DD0-4EBB-811F-33C572699FDE}','CLSID_ThisPCMyMusicRegFolder'
        'DesktopHide'   = ('{0}' -f $(if ( $L.s6 ) { $L.s6 } else { 'Рабочий стол'     })),'{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}','{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}','','CLSID_ThisPCDesktopRegFolder'
        '3dHide'        = ('{0}' -f $(if ( $L.s7 ) { $L.s7 } else { 'Объемные объекты' })),'{0DB7E03F-FC29-4DC6-9020-FF41B59E513A}','{31C0DD25-9439-4F12-BF41-7FF4EDA38722}','',''
    }

    $BuildOS = [System.Environment]::OSVersion.Version.Build

    if ( $CheckState )
    {
        if ( 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide' -like $CheckState )
        {
            [string] $CLSID = $FoldersData[$CheckState][1]

            try { [psobject] $TypeName = [Microsoft.Win32.Registry]::GetValue("HKEY_CLASSES_ROOT\CLSID\{A0953C92-50DC-43bf-BE83-3742FED03C9C}",'System.IsPinnedToNameSpaceTree_Old',$null)
            } catch { [psobject] $TypeName = $null }

            [string] $PinnedName = 'System.IsPinnedToNameSpaceTree'

            if ( -not ( $TypeName -like $null )) { $PinnedName = 'System.IsPinnedToNameSpaceTree_Old' } # 22621 +

            if ( $BuildOS -lt 22621 )
            {
                try { [psobject] $FolderHide1 = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\$CLSID",$PinnedName,$null)
                } catch { [psobject] $FolderHide1 = $null }

                try { [psobject] $FolderHide2 = [Microsoft.Win32.Registry]::GetValue("HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\HideMyComputerIcons",$CLSID,$null)
                } catch { [psobject] $FolderHide2 = $null }

                try
                {
                    [bool] $FolderHide3 = $false
                    $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID",'ReadSubTree','QueryValues')
                    
                    if ( $OpenSubKey ) { $FolderHide3 = $true ; $OpenSubKey.Close() }
                }
                catch {}

                try { [psobject] $FolderShow = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\$CLSID",$PinnedName,$null)
                } catch { [psobject] $FolderShow = $null }

                if     (( 0 -eq $FolderHide1 ) -and (   1 -eq $FolderHide2 ) -and ( -not $FolderHide3   )) {  '#Green#{0}#' -f $(if ( $L.s8  ) { $L.s8  } else { 'Скрыта           ' }) }
                elseif (( 0 -eq $FolderHide1 ) -and ( ( 1 -ne $FolderHide2 ) -or  (      $FolderHide3 ) )) {  '#Green#{0} #Yellow#{1}#' -f $(if ( $L.s9 ) { $L.s9,$L.s9_1 } else { 'Скрыта','(Не везде)' }) }
                elseif ( -not $FolderShow                                                                ) {  '#Green#{0}#' -f $(if ( $L.s8  ) { $L.s8  } else { 'Скрыта           ' }) }
                else                                                                                       { '#Yellow#{0}#' -f $(if ( $L.s10 ) { $L.s10 } else { 'Отображается     ' }) }
            }
            else
            {
                try
                {
                    [int] $HideIfEnabled = 0
                    $HideIfEnabled = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID",'HideIfEnabled',0)
                }
                catch {}

                if ( $HideIfEnabled -eq 0x022ab9b9 -or $CheckState -eq '3dHide' )
                {
                     '#Yellow#{0}#' -f $(if ( $L.s8  ) { $L.s8 } else { 'Скрыта           ' }) # Дефолт
                }
                else
                {
                     '#Green#{0}#' -f $(if ( $L.s10 ) { $L.s10 } else { 'Отображается     ' })
                }
            }
        }
        elseif ( 'DuplicateDevicesHide' -eq $CheckState )
        {
            if ( $BuildOS -lt 22621 )
            {
                try { [psobject] $Duplicate = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}",'ReadSubTree','QueryValues')
                } catch { [psobject] $Duplicate = $null }

                if ( -not $Duplicate ) {  '#Green#{0}#' -f $(if ( $L.s11   ) { $L.s11    } else { 'Скрыты' }) }
                else                   { '#Yellow#{0}#' -f $(if ( $L.s11_1 ) { $L.s11_1  } else { 'Отображаются' }) }
            }
            else
            {
                '#DarkGray#------------#'
            }
        }
        elseif ( 'NetIconHide' -eq $CheckState )
        {
            if ( $BuildOS -lt 22621 )
            {
                try { [psobject] $NetIconHide1 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder','Attributes',$null)
                } catch { [psobject] $NetIconHide1 = $null }

                try { [psobject] $NetIconHide2 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}','System.IsPinnedToNameSpaceTree',$null)
                } catch { [psobject] $NetIconHide2 = $null }

                if     ( 0xb0940064 -eq $NetIconHide1 -and 0 -eq $NetIconHide2 ) {  '#Green#{0}#' -f $(if ( $L.s12 ) { $L.s12 } else { 'Скрыт' }) }
                elseif ( $null -eq $NetIconHide1 -and $null -eq $NetIconHide2 )  { '#Yellow#{0}#' -f $(if ( $L.s13 ) { $L.s13 } else { 'Отображается' }) }
                else                                                             {  '#Green#{0} #Yellow#{1}#' -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Скрыт','(Не везде)' }) }
            }
            else
            {
                '#DarkGray#------------#'
            }
        }
        elseif ( 'QuickAccessHide' -eq $CheckState )
        {
            if ( $BuildOS -lt 22621 )
            {
                try { [psobject] $FastAccess1 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder','Attributes',$null)
                } catch { [psobject] $FastAccess1 = $null }

                try { [psobject] $FastAccess2 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}','System.IsPinnedToNameSpaceTree',$null)
                } catch { [psobject] $FastAccess2 = $null }

                try { [psobject] $FastAccess3 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer','HubMode',$null)
                } catch { [psobject] $FastAccess3 = $null }

                if     ( 0xa0180000 -eq $FastAccess1 -and $null -eq $FastAccess2 -and 1 -eq $FastAccess3 ) {  '#Green#{0}#' -f $(if ( $L.s12 ) { $L.s12 } else { 'Скрыт' }) }
                elseif ( $null -eq $FastAccess1 -and $null -eq $FastAccess2 -and 1 -ne $FastAccess3 )      { '#Yellow#{0}#' -f $(if ( $L.s13 ) { $L.s13 } else { 'Отображается' }) }
                else                                                                                       {  '#Green#{0} #Yellow#{1}#' -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Скрыт','(Не везде)' }) }
            }
            else
            {
                '#DarkGray#------------#'
            }
        }
        elseif ( 'WallPaper' -eq $CheckState )
        {
            try { [string] $WallPaper = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Control Panel\Desktop','WallPaper',$null)
            } catch { [string] $WallPaper = '' }


            if ( $WallPaper ) { "#DarkGray#$WallPaper#" } else { '#DarkGray#{0}#' -f $(if ( $L.s15 ) { $L.s15 } else { 'Не известно' }) }
        }
        elseif ( 'ImageForWallPaper' -eq $CheckState )
        {
            [string] $Target = ''
              [bool] $Skip   = $false

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Image-WallPaper\s*=\s*1\s*=\s*(?<Target>([a-z]:|shell:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $Target = $Matches.Target.Trim() | Expand-Path
            }
            else
            {
                '#DarkGray#{0}#' -f $(if ( $L.s35_2 ) { $L.s35_2 } else { 'Отключена настройка обоев рабочего стола' })

                $Skip = $true
            }

            if ( -not $Skip )
            {
                if ( -not $Target )
                {
                    $Target = $GraphicsFileFolder

                    [string] $GraphicsFile = ((Get-ChildItem -File -LiteralPath \\?\$Target -ErrorAction SilentlyContinue).Where({ $_.Name -match '[.]jpg$|[.]jpeg$|[.]bmp$' },'First')).FullName
                }
                elseif ( [System.IO.Directory]::Exists($Target) )
                {
                    [string] $GraphicsFile = ((Get-ChildItem -File -LiteralPath \\?\$Target -ErrorAction SilentlyContinue).Where({ $_.Name -match '[.]jpg$|[.]jpeg$|[.]bmp$' },'First')).FullName
                }
                elseif (( [System.IO.File]::Exists($Target) ) -and ( $Target -match '[.]jpg$|[.]jpeg$|[.]bmp$' ))
                {
                    [string] $GraphicsFile = $Target
                }
                else { [string] $GraphicsFile = '' }

                if ( $GraphicsFile ) { '#Green#{0}#' -f $GraphicsFile.TrimStart('\\?\') } else { "#Red#{0}, #DarkGray#{1}: $Target#" -f $(if ( $L.s16 ) { $L.s16,$L.s16_1 } else { "Не найден","Расположение" }) }
            }
        }

        Return
    }


    [string] $WallpaperAPI = @'
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class Wallpaper
    {
        [DllImport( "user32.dll", CharSet = CharSet.Auto )]
        static extern int SystemParametersInfo (uint uAction, uint uParam, string lpvParam, uint fuWinIni);

        private static uint SPI_SETDESKWALLPAPER = 0x0014;
        private static uint SPIF_SENDCHANGE      = 0x03;

        public static void SetWallpaper(string FilePath)
        {
            SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, FilePath, SPIF_SENDCHANGE);
        }
    }
}
'@

    [string] $RefreshExplorer = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class RefreshExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult);
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh()
        {
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);

            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);

            // Update taskbar
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");
        }

        private static readonly IntPtr hWnd = new IntPtr(65535);
        private const int Msg = 273;

        // Virtual key ID of the F5 in File Explorer
        private static readonly UIntPtr UIntPtr = new UIntPtr(41504);

        [DllImport("user32.dll", SetLastError=true)]
        public static extern int PostMessageW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);
        public static void PressF5Key()
        {
            // F5 pressing simulation to refresh the desktop
            PostMessageW(hWnd, Msg, UIntPtr, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.RefreshExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $RefreshExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    # Глобальное Отключение разрешения перенаправления для настройки реестра у дефолтного профиля, если он настраивается
    @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $false })

    # Внутренняя Функция скрытия/возврата 7 видов папок пользователя из проводника, чтобы сократить количество кода.
    Function Show-Hide-UserFolders {

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param(
            [Parameter( Mandatory = $true,  Position = 0 )]
            [ValidateSet( 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide' )]
            [string] $Folder
           ,
            [Parameter( Mandatory = $false )]
            [switch] $Hide
        )

        if ( $Folder -eq '3dHide' -and [System.Environment]::OSVersion.Version.Build -ge 22000 )
        {
            Write-Host "`n   $Folder`: Skip for W11" -ForegroundColor DarkGray
            Return
        }

        [string] $FolderName        = $FoldersData[$Folder][0]
        [string] $CLSID             = $FoldersData[$Folder][1]
        [string] $TargetKnownFolder = $FoldersData[$Folder][2]
        [string] $CLSIDBaseFolder   = $FoldersData[$Folder][3]
        [string] $CLSIDType         = $FoldersData[$Folder][4] # W11 22621 +

        if ( -not $Hide )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Возврат' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s17_1 ) { $L.s17_1 } else { 'папки' }
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$FolderName`n" -ForegroundColor White

            [string] $Path = "HKCU:\Software\Classes\CLSID\$CLSID"
            Set-Reg Remove-Item -Path $Path

            if ( $is64 )
            {
                $Path = "HKCU:\Software\Classes\Wow6432Node\CLSID\$CLSID"
                Set-Reg Remove-Item -Path $Path
            }

            $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
            $Value = $CLSIDType
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

            if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
            {
                Set-Reg Remove-ItemProperty -Path $Path -Name 'HideIfEnabled'
            }

            if ( $is64 )
            {
                $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
                $Value = $CLSIDType
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
                {
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'HideIfEnabled'
                }
            }

            $Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideMyComputerIcons"
            $Name = $CLSID
            Set-Reg Remove-ItemProperty -Path $Path -Name $Name
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { 'Скрытие' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s18_1 ) { $L.s18_1 } else { 'папки' }
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$FolderName`n" -ForegroundColor White

            try { [psobject] $TypeName = [Microsoft.Win32.Registry]::GetValue("HKEY_CLASSES_ROOT\CLSID\{A0953C92-50DC-43bf-BE83-3742FED03C9C}",'System.IsPinnedToNameSpaceTree_Old',$null)
            } catch { [psobject] $TypeName = $null }

            [string] $PinnedName = 'System.IsPinnedToNameSpaceTree'

            if ( -not ( $TypeName -like $null )) { $PinnedName = 'System.IsPinnedToNameSpaceTree_Old' } # 22621 +

            if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
            {
                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
                $Value = $CLSIDType
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
                {
                    Set-Reg New-ItemProperty -Path $Path -Name 'HideIfEnabled'-Type DWord 0x22ab9b9
                }

                if ( $is64 )
                {
                    $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
                    $Value = $CLSIDType
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                    if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
                    {
                        Set-Reg New-ItemProperty -Path $Path -Name 'HideIfEnabled'-Type DWord 0x22ab9b9
                    }
                }
            }
            else
            {
                [string] $Path = "HKCU:\Software\Classes\CLSID\$CLSID"
                Set-Reg New-ItemProperty -Path $Path -Name $PinnedName -Type DWord 0

                if ( $is64 )
                {
                    $Path = "HKCU:\Software\Classes\Wow6432Node\CLSID\$CLSID"
                    Set-Reg New-ItemProperty -Path $Path -Name $PinnedName -Type DWord 0
                }

                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSID"
                    Set-Reg Remove-Item -Path $Path
                }

                $Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideMyComputerIcons'
                $Name = $CLSID
                Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 1
            }
        }


        # Далее Восстановление других параметров по умолчанию, так как могут быть измененными и влиять на результат.

        $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\RemovedFolders'
        $Name = $CLSID
        Set-Reg Remove-ItemProperty -Path $Path -Name $Name

        if ( $CLSIDBaseFolder )
        {
            $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSIDBaseFolder"
            Set-Reg New-Item -Path $Path

            if ( $is64 )
            {
                $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\MyComputer\NameSpace\$CLSIDBaseFolder"
                Set-Reg New-Item -Path $Path
            }

            $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\$TargetKnownFolder\PropertyBag"
            Set-Reg New-ItemProperty -Path $Path -Name 'ThisPCPolicy' -Type String 'Show'

            if ( $is64 )
            {
                $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\$TargetKnownFolder\PropertyBag"
                Set-Reg New-ItemProperty -Path $Path -Name 'ThisPCPolicy' -Type String 'Show'
            }
        }
        else
        {
            $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\$TargetKnownFolder\PropertyBag"
            Set-Reg Remove-ItemProperty -Path $Path -Name 'ThisPCPolicy'

            if ( $is64 )
            {
                $Path = "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Explorer\FolderDescriptions\$TargetKnownFolder\PropertyBag"
                Set-Reg Remove-ItemProperty -Path $Path -Name 'ThisPCPolicy'
            }
        }
    }

    $text = if ( $L.s19 ) { $L.s19 } else { 'Настройка параметров Проводника' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s19_1 ) { $L.s19_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    # Если в выборе присутствует хотябы один из этих вариантов.
    if ( $Options.Where({ 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide' -like $_ }) )
    {
        # Для каждого варианта, соответствующего одному из этих наборов.
        foreach ( $Folder in $Options.Where({ 'VideoHide', 'DocumentsHide', 'DownloadsHide', 'PicturesHide', 'MusicHide', 'DesktopHide', '3dHide' -like $_ }) )
        {
            if     ( $Act -eq 'Set'     ) { Show-Hide-UserFolders -Folder $Folder -Hide }
            elseif ( $Act -eq 'Default' ) { Show-Hide-UserFolders -Folder $Folder       }
            else
            {
                $text = if ( $L.s20 ) { $L.s20 } else { '''Check'' не предусмотрен для' }
                Write-Host "   $text '$Folder'" -ForegroundColor DarkGray
            }
        }
    }

    if ( $Options -like 'DuplicateDevicesHide' )
    {
        if ( $BuildOS -lt 22621 )
        {
            if ( $Act -eq 'Set' )
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Скрытие' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s21_1 ) { $L.s21_1 } else { 'Дубликатов съемных устройств' }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                    Set-Reg Remove-Item -Path $Path
                }

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                [string] $Path = 'HKCU:\Software\Classes\CLSID\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\Wow6432Node\CLSID\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                    Set-Reg Remove-Item -Path $Path
                }
            }
            elseif ( $Act -eq 'Default' )
            {
                $text = if ( $L.s22 ) { $L.s22 } else { 'Возврат' }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'Дубликатов съемных устройств' }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                Set-Reg New-ItemProperty -Path $Path -Name '' -Type String 'Removable Drives'

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\DelegateFolders\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String 'Removable Drives'
                }

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                [string] $Path = 'HKCU:\Software\Classes\CLSID\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\Wow6432Node\CLSID\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}'
                    Set-Reg Remove-Item -Path $Path
                }
            }
            else
            {
                $text = if ( $L.s23 ) { $L.s23 } else { '''Check'' не предусмотрен для ''DuplicateDevicesHide''' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            Write-Host "`n   $Options`: Only for W11 < 22621" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'NetIconHide' )
    {
        if ( $BuildOS -lt 22621 )
        {
            if ( $Act -eq 'Set' )
            {
                $text = if ( $L.s24 ) { $L.s24 } else { 'Скрытие' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s24_1 ) { $L.s24_1 } else { 'Значка Сети' }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s24_2 ) { $L.s24_2 } else { 'Нужен перезапуск Проводника' }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKCU:\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0940064

                $Path = 'HKCU:\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 0

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0940064

                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                    Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 0
                }

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0040064

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0040064

                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'
                }
            }
            elseif ( $Act -eq 'Default' )
            {
                $text = if ( $L.s25 ) { $L.s25 } else { 'Возврат' }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s25_1 ) { $L.s25_1 } else { 'Значка Сети' }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s25_2 ) { $L.s25_2 } else { 'Нужен перезапуск Проводника' }
                Write-Host "$text`n" -ForegroundColor White

                $Path = 'HKCU:\Software\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                    Set-Reg Remove-Item -Path $Path
                }

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0040064

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xb0040064

                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{F02C1A0D-BE21-4350-88B0-7367FC96EF3C}'
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'
                }
            }
            else
            {
                $text = if ( $L.s26 ) { $L.s26 } else { '''Check'' не предусмотрен для ''NetIconHide''' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            Write-Host "`n   $Options`: Only for W11 < 22621" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'QuickAccessHide' )
    {
        if ( $BuildOS -lt 22621 )
        {
            if ( $Act -eq 'Set' )
            {
                $text = if ( $L.s27 ) { $L.s27 } else { 'Скрытие' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Быстрый доступ' }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s27_2 ) { $L.s27_2 } else { 'Нужен перезапуск проводника' }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKCU:\Software\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0180000

                $Path = 'HKCU:\Software\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0180000

                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree'
                }

                # Открывать проводник в Этот компьютер, так как скрывается быстрый доступ.
                $Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
                Set-Reg New-ItemProperty -Path $Path -Name 'LaunchTo' -Type DWord 1

                $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer'
                Set-Reg New-ItemProperty -Path $Path -Name 'HubMode' -Type DWord 1

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0100000

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 1

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0100000

                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                    Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 1
                }
            }
            elseif ( $Act -eq 'Default' )
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Возврат' }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s28_1 ) { $L.s28_1 } else { 'Быстрый доступ' }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s28_2 ) { $L.s28_2 } else { 'Нужен перезапуск проводника' }
                Write-Host "$text`n" -ForegroundColor White

                $Path = 'HKCU:\Software\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                Set-Reg Remove-Item -Path $Path

                if ( $is64 )
                {
                    $Path = 'HKCU:\Software\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                    Set-Reg Remove-Item -Path $Path
                }

                $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer'
                Set-Reg Remove-ItemProperty -Path $Path -Name 'HubMode'

                # Далее восстановление других параметров по дефолту, могут быть изменены и влиять на результат.

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0100000

                $Path = 'HKLM:\SOFTWARE\Classes\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 1

                if ( $is64 )
                {
                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}\ShellFolder'
                    Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 0xa0100000

                    $Path = 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{679f85cb-0220-4080-b29b-5540cc05aab6}'
                    Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedtoNameSpaceTree' -Type DWord 1
                }

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'HubMode'
                Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowFrequent'
            }
            else
            {
                $text = if ( $L.s29 ) { $L.s29 } else { '''Check'' не предусмотрен для ''QuickAccessHide''' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            Write-Host "`n   $Options`: Only for W11 < 22621" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'ClearIconCache' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { 'Очистка' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s30_1 ) { $L.s30_1 } else { 'Кэша иконок Проводника (iconcache*.db)' }
            Write-Host "$text`n" -ForegroundColor White

            ReStart-Explorer -Stop

            [string[]] $Paths = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\Explorer","$env:USERPROFILE\AppData\Local"
            try { (Get-ChildItem -File -Path $Paths -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like "IconCache*.db" }).FullName | ForEach-Object {

                    $text = if ( $L.s31 ) { $L.s31 } else { 'Удаление' }
                    Write-Host "   $text`: " -NoNewline -ForegroundColor Cyan
                    Write-Host "$_" -ForegroundColor DarkGray
                    try { Remove-Item -LiteralPath "\\?\$_" -Force -ErrorAction SilentlyContinue } catch {}
                }
            } catch {}

            ReStart-Explorer
        }
        else
        {
            $text = if ( $L.s32 ) { $L.s32 } else { '''Check'' и ''Default'' не предусмотрен для ''ClearIconCache''' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'ClearThumbCache' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s33 ) { $L.s33 } else { 'Очистка' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Кэша эскизов Проводника (thumbcache*.db)' }
            Write-Host "$text`n" -ForegroundColor White

            ReStart-Explorer -Stop

            [string] $Paths = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\Explorer"
            try { (Get-ChildItem -File -Path $Paths -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like 'thumbcache*.db' }).FullName | ForEach-Object {

                    $text = if ( $L.s31 ) { $L.s31 } else { 'Удаление' }
                    Write-Host "   $text`: " -NoNewline -ForegroundColor Cyan
                    Write-Host "$_" -ForegroundColor DarkGray
                    try { Remove-Item -LiteralPath "\\?\$_" -Force -ErrorAction SilentlyContinue } catch {}
                }
            } catch {}

            ReStart-Explorer
        }
        else
        {
            $text = if ( $L.s34 ) { $L.s34 } else { '''Check'' и ''Default'' не предусмотрен для ''ClearThumbCache''' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'SetWallPaper' )
    {
        if ( -not ( 'WinAPI.Wallpaper' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $WallpaperAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        if ( $Act -eq 'Set' )
        {
            [string] $Target = ''
              [bool] $Skip   = $false

            # Берем заданный путь в пресете для указанной папки, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Image-WallPaper\s*=\s*1\s*=\s*(?<Target>([a-z]:|shell:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $Target = $Matches.Target.Trim() | Expand-Path
            }
            else
            {
                $text = if ( $L.s35_2 ) { $L.s35_2 } else { 'Отключена настройка обоев рабочего стола' }
                Write-Host "`n   $text " -ForegroundColor DarkGray

                $Skip = $true
            }

            if ( -not $Skip )
            {
                $text = if ( $L.s35 ) { $L.s35 } else { 'Установка' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s35_1 ) { $L.s35_1 } else { 'Обоев рабочего стола' }
                Write-Host "$text" -ForegroundColor White

                if ( -not $Target )
                {
                    $Target = $GraphicsFileFolder

                    [string] $GraphicsFile = ((Get-ChildItem -File -LiteralPath \\?\$Target -ErrorAction SilentlyContinue).Where({ $_.Name -match '[.]jpg$|[.]jpeg$|[.]bmp$' },'First')).FullName
                }
                elseif ( [System.IO.Directory]::Exists($Target) )
                {
                    [string] $GraphicsFile = ((Get-ChildItem -File -LiteralPath \\?\$Target -ErrorAction SilentlyContinue).Where({ $_.Name -match '[.]jpg$|[.]jpeg$|[.]bmp$' },'First')).FullName
                }
                elseif (( [System.IO.File]::Exists($Target) ) -and ( $Target -match '[.]jpg$|[.]jpeg$|[.]bmp$' ))
                {
                    [string] $GraphicsFile = $Target
                }
                else { [string] $GraphicsFile = '' }

                if ( $GraphicsFile )
                {
                    # Родительский раздел реестра с параметрами расположения пользовательских папок.
                    [string] $Key = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders'

                    # Получаем установленное в данный момент расположение в реестре для текущей папки.
                    [string] $FindPath = [Microsoft.Win32.Registry]::GetValue($Key,'My Pictures',$null) # переменные раскрываются

                    if ( $FindPath )
                    {
                        [string] $GraphicsFileName = [System.IO.Path]::GetFileName($GraphicsFile)

                        $text = if ( $L.s36 ) { $L.s36 } else { 'Копируем файл' }
                        Write-Host  "`n   $text " -ForegroundColor DarkGray -NoNewline
                        Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                        Write-Host  "$GraphicsFileName" -ForegroundColor White

                        $text = if ( $L.s37 ) { $L.s37 } else { '      В папку' }
                        Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                        Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                        Write-Host  "$FindPath" -ForegroundColor White

                        try { Copy-Item -LiteralPath $GraphicsFile -Destination $FindPath -Force -ErrorAction SilentlyContinue }
                        catch {}

                        [string] $Image = "$FindPath\$GraphicsFileName"

                        if ( [System.IO.File]::Exists($Image) )
                        {
                            $text = if ( $L.s38 ) { $L.s38 } else { 'Устанавливаем' }
                            Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                            Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                            Write-Host  "$Image" -ForegroundColor Green

                            try { [WinAPI.Wallpaper]::SetWallpaper($Image) } catch {}

                            # Настройка других акков
                            [array] $Accs = @()

                            if ( $Global:DataAllUsers.Redirects.Value )
                            {
                                @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

                                    $Accs += [PSCustomObject] @{
                                        Name     = $_.Name
                                        FullName = $_.FullName
                                        Root     = $_.SID
                                        Profile  = $_.Profile
                                        SID      = $_.SID
                                        Source   = $_.Source
                                    }
                                })
                            }

                            [int] $P = 0

                            foreach ( $Acc in $Accs )
                            {
                                $UserName = $Acc.Name
                                $isRoot   = "Registry::HKU\$($Acc.Root)"
                                $Profile  = $Acc.Profile

                                $SubKey = 'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'
                                $Key    = "HKEY_USERS\$($Acc.Root)\$SubKey"
                                try { [string] $UserPictures = [Microsoft.Win32.Registry]::GetValue($Key,'My Pictures',$null) } catch { [string] $UserPictures = '' }

                                if ( $UserPictures -and [System.IO.Directory]::Exists($UserPictures) )
                                {
                                    if ( $FindPath -eq $UserPictures ) { continue }

                                    Write-Host "`n   $UserName " -ForegroundColor White -NoNewline
                                    Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

                                    $text = if ( $L.s36 ) { $L.s36 } else { 'Копируем файл' }
                                    Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                                    Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                                    Write-Host  "$GraphicsFileName" -ForegroundColor White

                                    $text = if ( $L.s37 ) { $L.s37 } else { '      В папку' }
                                    Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                                    Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                                    Write-Host  "$UserPictures" -ForegroundColor White

                                    try { Copy-Item -LiteralPath $GraphicsFile -Destination $UserPictures -Force -ErrorAction SilentlyContinue }
                                    catch {}

                                    [string] $Image = "$UserPictures\$GraphicsFileName"

                                    if ( [System.IO.File]::Exists($Image) )
                                    {
                                        $text = if ( $L.s38 ) { $L.s38 } else { 'Устанавливаем' }
                                        Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                                        Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                                        Write-Host  "$Image" -ForegroundColor Green

                                        $Subkey = 'Control Panel\Desktop'

                                        try
                                        {
                                            [byte[]] $Bytes = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($Acc.Root)\$Subkey",'TranscodedImageCache',$null)

                                            if ( 800 -ne $Bytes.Count ) { continue }

                                            [byte[]] $StartBytes = $Bytes[0..23]
                                            [byte[]] $SringBytes = [System.Text.Encoding]::Unicode.GetBytes($Image.ToCharArray())
                                            [byte[]] $AllBytes = $StartBytes + $SringBytes + [byte[]]::new(800 - 24 - $SringBytes.Count)

                                            if ( 800 -ne $AllBytes.Count ) { continue }
                                        }
                                        catch { continue }

                                        $Path = "$isRoot\$Subkey"
                                        [byte[]] $Value = $AllBytes

                                        Set-Reg New-ItemProperty -Path $Path -Name 'TranscodedImageCache' -Type Binary $Value -OnlyThisPath

                                        [string] $Value = $Image

                                        Set-Reg New-ItemProperty -Path $Path -Name 'WallPaper' -Type String $Value -OnlyThisPath

                                        $Subkey = 'Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers'

                                        try { $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$Subkey", 'ReadSubTree','QueryValues') }
                                        catch { $OpenRegKey = $null }

                                        [array] $Values = @()

                                        if ( $OpenRegKey )
                                        {
                                            foreach ( $ValueName in ( $OpenRegKey.GetValueNames() -like 'BackgroundHistoryPath*' ))
                                            {
                                                $Value = $OpenRegKey.GetValue($ValueName,$null)

                                                if ( $Value )
                                                {
                                                    $Values += $Value
                                                }
                                            }

                                            $OpenRegKey.Close()
                                        }

                                        $Value = $Image
                                        $Path  = "$isRoot\$Subkey"
                                        Set-Reg New-ItemProperty -Path $Path -Name 'BackgroundHistoryPath0' -Type String $Value -OnlyThisPath

                                        $Values = $Values.Where({ $_ -and $_ -notlike $Image },'First',4)

                                        [int] $N = 1
                                        foreach ( $Value in $Values )
                                        {
                                            $Name = "BackgroundHistoryPath$N"
                                            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value -OnlyThisPath
                                            $N++
                                        }

                                        if ( $Profile -eq $env:USERPROFILE ) { Continue }

                                        [array] $Paths = "$Profile\AppData\Roaming\Microsoft\Windows\Themes\TranscodedWallpaper",
                                                         "$Profile\AppData\Roaming\Microsoft\Windows\Themes\CachedFiles"
                                        try { Remove-Item -LiteralPath $Paths -Recurse -Force -ErrorAction SilentlyContinue } catch {}

                                        $File = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Themes\TranscodedWallpaper"
                                        $Dest = "$Profile\AppData\Roaming\Microsoft\Windows\Themes"

                                        if ( -not $P ) { Start-Sleep -Milliseconds 1000 ; $P++ }

                                        try { Copy-Item -Path $File -Destination $Dest -Force -ErrorAction SilentlyContinue }
                                        catch {}
                                    }
                                }
                            }
                        }
                        else
                        {
                            $text = if ( $L.s39 ) { $L.s39 } else { 'Не скопировался файл в папку ''Изображения'' текущего пользователя!' }
                            Write-Host  "`n   $text" -ForegroundColor Yellow
                        }
                    }
                    else
                    {
                        $text = if ( $L.s40 ) { $L.s40 } else { 'Не найдено расположение папки ''Изображения'' текущего пользователя!' }
                        Write-Host  "`n   $text" -ForegroundColor Yellow
                    }
                }
                else
                {
                    $text = if ( $L.s41 ) { $L.s41 } else { 'Не найден Графический Файл для Обоев рабочего стола, Расположение' }
                    Write-Host  "`n   $text`: $Target" -ForegroundColor Yellow
                }
            }
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s42 ) { $L.s42 } else { 'Возврат' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s42_1 ) { $L.s42_1 } else { 'Обоев рабочего стола' }
            Write-Host "$text" -ForegroundColor White

            [string] $Image = "$env:SystemDrive\windows\web\wallpaper\windows\img0.jpg"

            if ( [System.IO.File]::Exists($Image) )
            {
                $text = if ( $L.s43 ) { $L.s43 } else { 'Устанавливаем' }
                Write-Host  "`n   $text " -ForegroundColor DarkGray -NoNewline
                Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                Write-Host  "$Image" -ForegroundColor Green

                try { [WinAPI.Wallpaper]::SetWallpaper($Image) } catch {}

                # Настройка других акков
                [array] $Accs = @()

                if ( $Global:DataAllUsers.Redirects.Value )
                {
                    @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

                        $Accs += [PSCustomObject] @{
                            Name     = $_.Name
                            FullName = $_.FullName
                            Root     = $_.SID
                            Profile  = $_.Profile
                            SID      = $_.SID
                            Source   = $_.Source
                        }
                    })
                }

                [int] $P = 0

                foreach ( $Acc in $Accs )
                {
                    $UserName = $Acc.Name
                    $isRoot   = "Registry::HKU\$($Acc.Root)"
                    $Profile  = $Acc.Profile

                    $Subkey = 'Control Panel\Desktop'

                    try
                    {
                        [byte[]] $Bytes = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($Acc.Root)\$Subkey",'TranscodedImageCache',$null)

                        if ( 800 -ne $Bytes.Count ) { continue }

                        [byte[]] $StartBytes = $Bytes[0..23]
                        [byte[]] $SringBytes = [System.Text.Encoding]::Unicode.GetBytes($Image.ToCharArray())
                        [byte[]] $AllBytes = $StartBytes + $SringBytes + [byte[]]::new(800 - 24 - $SringBytes.Count)

                        if ( 800 -ne $AllBytes.Count ) { continue }
                    }
                    catch { continue }

                    Write-Host "`n   $UserName " -ForegroundColor White -NoNewline
                    Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

                    $text = if ( $L.s38 ) { $L.s38 } else { 'Устанавливаем' }
                    Write-Host  "   $text " -ForegroundColor DarkGray -NoNewline
                    Write-Host  '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host  "$Image" -ForegroundColor Green

                    $Path = "$isRoot\$Subkey"
                    [byte[]] $Value = $AllBytes

                    Set-Reg New-ItemProperty -Path $Path -Name 'TranscodedImageCache' -Type Binary $Value -OnlyThisPath

                    [string] $Value = $Image

                    Set-Reg New-ItemProperty -Path $Path -Name 'WallPaper' -Type String $Value -OnlyThisPath

                    $Subkey = 'Software\Microsoft\Windows\CurrentVersion\Explorer\Wallpapers'

                    try { $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$($Acc.Root)\$Subkey", 'ReadSubTree','QueryValues') } catch { $OpenRegKey = $null }

                    [array] $Values = @()

                    if ( $OpenRegKey )
                    {
                        foreach ( $ValueName in ( $OpenRegKey.GetValueNames() -like 'BackgroundHistoryPath*' ))
                        {
                            $Value = $OpenRegKey.GetValue($ValueName,$null)

                            if ( $Value )
                            {
                                $Values += $Value
                            }
                        }

                        $OpenRegKey.Close()
                    }

                    $Value = $Image
                    $Path  = "$isRoot\$Subkey"
                    Set-Reg New-ItemProperty -Path $Path -Name 'BackgroundHistoryPath0' -Type String $Value -OnlyThisPath

                    $Values = $Values.Where({ $_ -and $_ -notlike $Image },'First',4)

                    [int] $N = 1
                    foreach ( $Value in $Values )
                    {
                        $Name = "BackgroundHistoryPath$N"
                        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type String $Value -OnlyThisPath
                        $N++
                    }

                    if ( $Profile -eq $env:USERPROFILE ) { Continue }

                    [array] $Paths = "$Profile\AppData\Roaming\Microsoft\Windows\Themes\TranscodedWallpaper",
                                     "$Profile\AppData\Roaming\Microsoft\Windows\Themes\CachedFiles"
                    try { Remove-Item -LiteralPath $Paths -Recurse -Force -ErrorAction SilentlyContinue } catch {}

                    $File = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Themes\TranscodedWallpaper"
                    $Dest = "$Profile\AppData\Roaming\Microsoft\Windows\Themes"

                    if ( -not $P ) { Start-Sleep -Milliseconds 1000 ; $P++ }

                    try { Copy-Item -Path $File -Destination $Dest -Force -ErrorAction SilentlyContinue }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s44 ) { $L.s44 } else { 'Не найден Файл Обоев Рабочего стола По умолчанию' }
                Write-Host  "`n   $text`: '$Image'" -ForegroundColor Yellow
            }
        }
        else
        {
            $text = if ( $L.s45 ) { $L.s45 } else { '''Check'' не предусмотрен для ''SetWallPaper''' }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }
    }

    # Если запуск не из меню быстрых настроек
    if ( -not $MenuConfigsQuickSettings )
    {
        Start-Sleep -Milliseconds 500
        [WinAPI.RefreshExplorer]::Refresh()
        Start-Sleep -Milliseconds 500
        [WinAPI.RefreshExplorer]::PressF5Key()
    }

    # Возврат разрешения перенаправления на дефолтный профиль, если он настраивается
    @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.DefaultAccount = $true })

    Get-Pause
}
