﻿
<#
.SYNOPSIS
 Настройка Центра Обновлений (Windows Update)
 Несколько предустановленных вариантов.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Set_Update_Windows

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Start-ProcessFromSYS для запуска команд от TI
 Используется функция Set-SettingsPageVisibility для скрытия окон настроек из Параметров, с проверкой и выводом результата.
 Используется функция Get-Task-FullPaths для получения для отключения всех задач в разделе UpdateOrchestrator

.EXAMPLE
    Set-Update-Windows -Act Set -Option Disable -ApplyGP

    Описание
    --------
    Полное отключение обновлений.


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  15-03-2023
 =================================================

#>
Function Set-Update-Windows {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'DisableWu', 'DisableWuGPOnly', 'DisableWuGPExceptStore', 'NotifyWu', 'ManualWu', 
                      'ClearCache', 'ClearCacheAll', 'EnableOtherMS', 'DisableLangUpdate',
                      'BlockServices', 'BlockWaaSdelTools', 'NotUpgradeOSver' )]
        [string] $Option = 'ManualWu'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $NoHeader
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Update', 'Delivery', 'HideUpdate', 'HideDelivery', 'OtherMS', 'StubFile', 'HealthUtility','WaaSMedicAgent','upfc','UpgradeOSver' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( $CheckState -eq 'Update' )
        {
            [int] $Disable = $Disable1 = $Disable2 = $Disable3 = $Manual1 = $Manual2 = $Auto = 0

            try { [int] $Disable1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','DisableWindowsUpdateAccess',$null) } catch {}
            try { [int] $Disable2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','SetDisableUXWUAccess',$null) } catch {}
            try { [int] $Disable3 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','DoNotConnectToWindowsUpdateInternetLocations',$null) } catch {}

            try { [int] $Manual1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU','NoAutoUpdate',$null) } catch {}
            try { [int] $Manual2 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer','NoAutoUpdate',$null) } catch {}

            try { [int] $Auto = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU','AUOptions',$null) } catch {}

            try { [int] $Disable = $Disable1 + $Disable2 + $Disable3 } catch { [int] $Disable = 0 }
            try { [int] $Manual  = $Manual1 + $Manual2               } catch { [int] $Manual  = 0 }

            if     ( 3 -eq $Disable )  {    '#Green#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключено всё          ' }) }
            elseif ( $Disable       )  {    '#Green#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Отключено (кроме Store)' }) }
            elseif ( $Manual        )  {   '#Yellow#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { 'Вручную                ' }) }
            else
            {
                if     ( 2 -eq $Auto ) { '#DarkCyan#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Уведомление            ' }) }
                elseif ( 3 -eq $Auto ) {   '#Yellow#{0}#' -f $(if ( $L.s5 ) { $L.s5 } else { 'Загрузка/Уведомление   ' }) }
                elseif ( 4 -eq $Auto ) {   '#Yellow#{0}#' -f $(if ( $L.s6 ) { $L.s6 } else { 'Автоустановка          ' }) }
                else                   {   '#Yellow#{0}#' -f $(if ( $L.s7 ) { $L.s7 } else { 'По умолчанию           ' }) }
            }
        }
        elseif ( $CheckState -eq 'Delivery' )
        {
            try { $Delivery = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization','DODownLoadMode',$null)
            } catch { $Delivery = $null }

            if     (   0 -eq $Delivery ) {  '#Green#{0}#' -f $(if ( $L.s9  ) { $L.s9  } else { 'HTTP, без пиринга      ' }) }
            elseif (   1 -eq $Delivery ) { '#Yellow#{0}#' -f $(if ( $L.s10 ) { $L.s10 } else { 'HTTP + (Локальная сеть)' }) }
            elseif (   2 -eq $Delivery ) { '#Yellow#{0}#' -f $(if ( $L.s11 ) { $L.s11 } else { 'HTTP + (Частная группа)' }) }
            elseif (   3 -eq $Delivery ) { '#Yellow#{0}#' -f $(if ( $L.s12 ) { $L.s12 } else { 'HTTP + Интернет пиринг ' }) }
            elseif (  99 -eq $Delivery ) {  '#Green#{0}#' -f $(if ( $L.s13 ) { $L.s13 } else { 'HTTP, без пиринга      ' }) }
            elseif ( 100 -eq $Delivery ) {  '#Green#{0}#' -f $(if ( $L.s14 ) { $L.s14 } else { 'Отключено              ' }) }
            else                         { '#Yellow#{0}#' -f $(if ( $L.s15 ) { $L.s15 } else { 'По умолчанию           ' }) }
        }
        elseif ( $CheckState -eq 'HideUpdate' )
        {
            Set-SettingsPageVisibility -Names 'windowsupdate' -Act Check -CheckOutForMenu
        }
        elseif ( $CheckState -eq 'HideDelivery' )
        {
            Set-SettingsPageVisibility -Names 'delivery-optimization' -Act Check -CheckOutForMenu
        }
        elseif ( $CheckState -eq 'OtherMS' )
        {
            [int[]] $RegWU = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\7971F918-A847-4430-9279-4A52D1EFE18D','RegisteredWithAU',0),
                             [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\Pending\7971F918-A847-4430-9279-4A52D1EFE18D','RegisterWithAU',0)

            if ( $RegWU -like 1 )
            {
                '#Green#{0}#'  -f $(if ( $L.s15_1 ) { $L.s15_1 } else { 'Включено ' })
            }
            else
            {
                '#Yellow#{0}#' -f $(if ( $L.s15_2 ) { $L.s15_2 } else { 'Отключено' })
            }
        }
        elseif ( $CheckState -eq 'StubFile' )
        {
            [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"

            if ( [System.IO.File]::Exists($File) )
            {
                '#Green#{0} #DarkGray#| {1}#' -f $(if ( $L.s17_2 ) { $L.s17_2 } else { 'Создан' }), '%WinDir%\SoftwareDistribution\Download'
            }
            else
            {
                '#DarkGray#{0}#'              -f $(if ( $L.s17_3 ) { $L.s17_3 } else { 'Не Создан' })
            }
        }
        elseif ( $CheckState -eq 'HealthUtility' )
        {
            [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                  'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

            [psobject] $OpenSubKey = $null
            [array] $Installed = @()

            foreach ( $RegKey in $RegKeys )
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                if ( $OpenSubKey )
                {
                    foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                    {
                        $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                        $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                        if (( $DisplayName -like 'Microsoft*Update*Health*Tools*' ) -and ( $UninstallString -like 'msiexec*' ))
                        {
                            $Installed += 1
                        }
                    }

                    $OpenSubKey.Close()
                }
            }

            if ( $Installed.Length )
            {
                '#Yellow#{0}#'   -f $(if ( $L.s15_5 ) { $L.s15_5 } else { 'Установлен   ' })
            }
            else
            {
                '#DarkGray#{0}#' -f $(if ( $L.s15_6 ) { $L.s15_6 } else { 'Не установлен' })
            }
        }
        elseif ( $CheckState -eq 'WaaSMedicAgent' )
        {
            [string] $LockExe = ''

            try { $LockExe = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\WaaSMedicAgent.exe','Debugger','') }
            catch {}

            if ( @([System.Diagnostics.Process]::GetProcessesByName('WaaSMedicAgent')).Count ) { $Proc = '#Green#◄ running' } else { $Proc = '#DarkYellow#◄ stopped' }

            if ( $LockExe ) {  "#Green#{0} $Proc #DarkGray#| {1}#" -f $(if ( $L.s19_1 ) { $L.s19_1 } else { 'Заблочен'    }), $LockExe }
            else            { "#Yellow#{0} $Proc#"                 -f $(if ( $L.s19_2 ) { $L.s19_2 } else { 'Не заблочен' }) }
        }
        elseif ( $CheckState -eq 'upfc' )
        {
            [string] $LockExe = ''

            try { $LockExe = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\upfc.exe','Debugger','') }
            catch {}

            if ( @([System.Diagnostics.Process]::GetProcessesByName('upfc')).Count ) { $Proc = '#Green#◄ running' } else { $Proc = '#DarkYellow#◄ stopped' }

            if ( $LockExe ) {  "#Green#{0} $Proc #DarkGray#| {1} #" -f $(if ( $L.s19_1 ) { $L.s19_1 } else { 'Заблочен'    }), $LockExe }
            else            { "#Yellow#{0} $Proc#"                  -f $(if ( $L.s19_2 ) { $L.s19_2 } else { 'Не заблочен' }) }
        }
        elseif ( $CheckState -eq 'UpgradeOSver' )
        {
            [int] $Target = 0

            try { $Target = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersion',0) }
            catch {}

            [string] $TargetInfo = ''

            try { $TargetInfo = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersionInfo','') }
            catch {}


            if ( $Target -eq 1 -and $TargetInfo ) { '#Green#{0}#' -f $TargetInfo.PadRight(6,' ').Substring(0,6) }
            else                                  { '#DarkGray#----  #' }
        }

        Return
    }

    Function Telemetry-Data-Collection-Disable {
        
        # Чтобы не собирала данные по отключению, и не адартировали защиту (уменьшить шансы) 
        Set-Svc -Do:$Act Set-Service -Name 'DiagTrack' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'diagnosticshub.standardcollector.service' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'InventorySvc' -StartupType Disabled -Status Stopped  # CompatTelRunner

        if ( $Act -eq 'Set' )
        {
            Stop-Service -Name PcaSvc -ErrorAction 0 -WarningAction 0  # CompatTelRunner
            Stop-Process -Name CompatTelRunner,diagtrackrunner -Force -ErrorAction 0 -WarningAction 0
        }

        [string[]] $tasks = '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
                            '\Microsoft\Windows\Application Experience\PcaPatchDbTask',
                            '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
                            '\Microsoft\Windows\Application Experience\SdbinstMergeDbTask',
                            '\Microsoft\Windows\Application Experience\StartupAppTask',
                            '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
                            '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'

        foreach ( $task in $tasks )
        {
            if ( -not ( Check-State-Task $task -Need Disabled -Return Bool ))
            {
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $task
                
                if ( $task -eq '\Microsoft\Windows\Application Experience\PcaPatchDbTask' )
                {
                    Set-TaskAccess -Do:$Act -TaskName $task -Access Lock
                }
            }
        }
    }

    if ( $Act -ne 'Default' )
    {
        if ( -not $NoHeader )
        {
            $text = if ( $L.s16 ) { $L.s16 } else { 'Настройка Центра Обновлений Windows' }
            Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'Функция' }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
        }

        if ( $Option -like 'DisableWu*' )
        {
            if ( $Option -eq 'DisableWu' )
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Отключение Обновления Полностью' }
                Write-Host "`n   $text`n" -ForegroundColor DarkCyan

                $text = if ( $L.s18 ) { $L.s18 } else { 'Служба wuauserv, нужна для некоторых типов активаций Windows' }
                Write-Host "   $text`n" -ForegroundColor DarkGray

                Telemetry-Data-Collection-Disable
                Write-Host

                # Проблема: Служба 'wuauserv' нужна для некоторых типов активаций Windows
                # Problem: The 'wuauserv' service is needed for some types of Windows activations
                Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Disabled -Status Stopped -OrigCmdlet

                # Проблема: Принудительная остановка службы 'UsoSvc' приводит к зависанию почти всех функций и элементов системы, тогда только ресет. Эта служба включает задачу Scheduled Start.
                # Problem: Forcing the 'UsoSvc' service to stop causes almost all functions and elements of the system to freeze, then only reset. This service includes the Scheduled Start task.
                Set-Svc -Do:$Act Set-Service -Name 'UsoSvc' -StartupType Disabled -OrigCmdlet
                Set-Svc -Do:$Act Set-Service -Name 'uhssvc' -StartupType Disabled -OrigCmdlet
                Set-Svc -Do:$Act Set-Service -Name 'DoSvc' -StartupType Disabled -Status Stopped
                Set-Svc -Do:$Act Set-Service -Name 'BITS' -StartupType Disabled -Status Stopped
                Set-Svc -Do:$Act Set-Service -Name 'WaaSMedicSvc' -StartupType Disabled -Status Stopped

                [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"

                if ( -not ( [System.IO.File]::Exists($File) ))
                {
                    $text = if ( $L.s17_1 ) { $L.s17_1 } else { 'Создание файла-заглушки' }
                    Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$File" -ForegroundColor DarkGray

                    try
                    {
                        Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
                        New-Item -ItemType File -Path $File -Force -ErrorAction SilentlyContinue > $null
                        (Get-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                    }
                    catch {}

                    if ( [System.IO.File]::Exists($File) )
                    {
                        $text = if ( $L.s17_2 ) { $L.s17_2 } else { 'Создан' }
                        Write-Host "   $text`n" -ForegroundColor DarkGreen
                    }
                    else
                    {
                        $text = if ( $L.s17_3 ) { $L.s17_3 } else { 'Не Создан' }
                        Write-Host "   $text`n" -ForegroundColor Yellow
                    }
                }
                else
                {
                    $text = if ( $L.s17_4 ) { $L.s17_4 } else { 'Файл-заглушка существует' }
                    Write-Host "`n   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$File`n" -ForegroundColor DarkGray
                }

                if ( $Act -eq 'Set' )
                {
                    & LODCTR.exe /D:BITS

                    if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like '*BITS*(Disabled)' )
                    {
                        $text = if ( $L.s19 ) { $L.s19 } else { '  Выполнено' }
                        Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                        Write-Host '     BITS ' -ForegroundColor White -NoNewline
                        Write-Host "| $BITS" -ForegroundColor DarkGray
                    }
                }

                Set-SettingsPageVisibility -Act:$Act -Names 'windowsupdate', 'delivery-optimization'

                if ( $Act -eq 'Set' )
                {
                    Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Disabled -Status Stopped -OrigCmdlet
                    Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
                }

                # Блокировка WaaS и удаление Tools
                Set-Update-Windows -Act Set -Option BlockWaaSdelTools -NoHeader
            }
            elseif ( $Option -like 'DisableWuGP*' )
            {
                if ( $Option -eq 'DisableWuGPOnly' )
                {
                    $text = if ( $L.s17_8 ) { $L.s17_8 } else { 'Отключение Обновления только через ГП (и MS Store)' }
                    Write-Host "`n   $text`n" -ForegroundColor DarkCyan
                }
                elseif ( $Option -eq 'DisableWuGPExceptStore' )
                {
                    $text = if ( $L.s17_9 ) { $L.s17_9 } else { 'Отключение Обновления только через ГП (кроме MS Store)' }
                    Write-Host "`n   $text`n" -ForegroundColor DarkCyan
                }

                Telemetry-Data-Collection-Disable

                # разблокировка доступа к службам ЦО
                Set-Update-Windows -Act Default -Option BlockServices -NoHeader

                Write-Host

                Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Manual
                Set-Svc -Do:$Act Set-Service -Name 'BITS' -StartupType Manual
                Set-Svc -Do:$Act Set-Service -Name 'DoSvc' -StartupType Manual

                Set-Svc -Do:$Act Set-Service -Name 'UsoSvc' -StartupType DelayedAuto


                if ( $Act -eq 'Set' )
                {
                    Write-Host

                    [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
                    if ( [System.IO.File]::Exists($File) )
                    {
                        $text = if ( $L.s17_5 ) { $L.s17_5 } else { 'Удаление файла-заглушки' }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$File`n" -ForegroundColor DarkGray

                        try { Remove-Item -LiteralPath \\?\$File -Force -ErrorAction SilentlyContinue } catch {}
                    }

                    & LODCTR.exe /E:BITS

                    if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like '*BITS*(Enabled)' )
                    {
                        $text = if ( $L.s19 ) { $L.s19 } else { '  Выполнено' }
                        Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                        Write-Host '     BITS ' -ForegroundColor White -NoNewline
                        Write-Host "| $BITS" -ForegroundColor DarkGray
                    }
                }

                Set-SettingsPageVisibility -Act:$Act -Remove -Names 'windowsupdate', 'delivery-optimization'
            }

            # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить доступ ко всем компонентам Центра обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Запретить доступ для использования любых средств Центра обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'SetDisableUXWUAccess' -Type DWord 1

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Отключена) (ручной режим)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 1

            # Если не нужно блокировать магазин
            if ( $Option -eq 'DisableWuGPExceptStore' )
            {
                # Чтобы не запрещало Store качать обновы
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations'
            }
            else
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не подключаться к расположениям Центра обновления Windows в Интернете" (Включена)
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations' -Type DWord 1
            }

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Уазать размещение службы обновлений Майкрософт в интрасети ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUServer' -Type String '-'
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUStatusServer' -Type String '-'
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'UpdateServiceUrlAlternate' -Type String '-'

            # Чтобы ЦО не обходил запреты обновления через настройки интрасети (блокировку через ГП, и вообще наглость)
            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не разрешать политикам задержки получения обновлений инициировать сканирование в Центре обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableDualScan' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Включена, HTTP, без пиринга)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name 'DODownLoadMode' -Type DWord 0
        
            # Задачи
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'

            # Отключение всех найденных в UpdateOrchestrator задач, так как их названия и количество все время меняется.
            Get-Task-FullPaths -LikeName \Microsoft\Windows\UpdateOrchestrator\* -CompareFullPath | ForEach-Object {

                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $_
            }

            if (( $Act -eq 'Set' ) -and ( $Option -like 'DisableWuGP*' ) -and $ApplyGP )
            {
                # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
                Set-LGP -ApplyGP

                # Обновление ГП вызывает запуск служб ЦО, а необходимо чтобы эта служба оставалась остановленной
                Start-Sleep -Milliseconds 2000
                Stop-Service -Name wuauserv -Force -WarningAction 0 -ErrorAction 0
            }
        }
        elseif (( $Option -eq 'NotifyWu' ) -or ( $Option -eq 'ManualWu' ))
        {
            if ( $Option -eq 'NotifyWu' )
            {
                $text = if ( $L.s20 ) { $L.s20 } else { 'Проверять и только сообщать о наличии обновлений' }
                Write-Host "`n   $text`:" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Ручная Установка Обновлений' }
                Write-Host "`n   $text`:" -ForegroundColor DarkCyan
            }

            # Так как состояние служб все время меняется при включенных режимах, то будет сообщаться только если отключено.
            # Иначе проверяться будет полученное состояние, чтобы выводилось, что все нормально, при любом состоянии, кроме отключено.
            if ( $Act -eq 'Check' )
            {
                Write-Host

                Set-Svc-AccessDeny -ServiceName 'wuauserv'     -Act Check -NeedUnlock
                Set-Svc-AccessDeny -ServiceName 'UsoSvc'       -Act Check -NeedUnlock
                Set-Svc-AccessDeny -ServiceName 'DoSvc'        -Act Check -NeedUnlock
                Set-Svc-AccessDeny -ServiceName 'WaaSMedicSvc' -Act Check -NeedUnlock

                Write-Host

                [string[]] $Services = 'wuauserv', 'BITS', 'DoSvc', 'UsoSvc'

                foreach ( $Service in $Services )
                {
                    [string] $SvcState = Check-State-Service $Service -Return Value

                    [string] $Name = $Service

                    if ( 'Disabled' -eq $SvcState )
                    {
                        Set-Svc -Do:$Act Set-Service -Name $Name -StartupType Manual
                    }
                    elseif ( $SvcState )
                    {
                        [string] $StartupType = $SvcState

                        try
                        {
                            Set-Svc -Do:$Act Set-Service -Name $Name -StartupType $StartupType
                        }
                        catch {}
                    }
                }

                [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
                if ( [System.IO.File]::Exists($File) )
                {
                    $text = if ( $L.s17_4 ) { $L.s17_4 } else { 'Файл-заглушка существует' }
                    Write-Host "`n   $text`: " -ForegroundColor Yellow -NoNewline
                    Write-Host "$File`n" -ForegroundColor DarkGray

                    $NeedFix = $true
                }
            }
            else
            {
                # Иначе Set - настройка служб

                # разблокировка доступа к службам ЦО
                Set-Update-Windows -Act Default -Option BlockServices -NoHeader

                Write-Host

                [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
                if ( [System.IO.File]::Exists($File) )
                {
                    $text = if ( $L.s17_5 ) { $L.s17_5 } else { 'Удаление файла-заглушки' }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$File`n" -ForegroundColor DarkGray

                    try { Remove-Item -LiteralPath \\?\$File -Force -ErrorAction SilentlyContinue } catch {}
                }

                Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Manual -Status Stopped
                Set-Svc -Do:$Act Set-Service -Name 'BITS' -StartupType Manual -Status Stopped
                Set-Svc -Do:$Act Set-Service -Name 'DoSvc' -StartupType Manual

                Set-Svc -Do:$Act Set-Service -Name 'UsoSvc' -StartupType DelayedAuto
            }

            if ( $Act -eq 'Set' )
            {
                & LODCTR.exe /E:BITS

                if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like '*BITS*(Enabled)' )
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { '  Выполнено' }
                    Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                    Write-Host '     BITS ' -ForegroundColor White -NoNewline
                    Write-Host "| $BITS" -ForegroundColor DarkGray
                }
            }

            # Чтобы не делало проверки, а только настройку, так как состояния задач ЦО всё время меняет по ситуации
            if ( $Act -eq 'Set' )
            {
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask'

                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Backup Scan'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Download'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Install'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Report policies'
                #Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Work'
               
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Maintenance Install'
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Reboot'
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'
            }

            if ( $Act -eq 'Check' )
            {
                # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить доступ ко всем компонентам Центра обновления Windows" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Запретить доступ для использования любых средств Центра обновления Windows" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'SetDisableUXWUAccess'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не подключаться к расположениям Центра обновления Windows в Интернете" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations'

                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUServer'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUStatusServer'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'UpdateServiceUrlAlternate'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Уазать размещение службы обновлений Майкрософт в интрасети ..." (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer'
            }
            elseif ( $Act -eq 'Set' )
            {
                try { [int] $DriverExcl = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null) }
                catch { [int] $DriverExcl = 0 }

                try { $ManagePreviewBuilds = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ManagePreviewBuilds',$null) }
                catch { $ManagePreviewBuilds = $null }
                try { $ManagePreviewBuildsPolicy = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ManagePreviewBuildsPolicyValue',$null) }
                catch { $ManagePreviewBuildsPolicy = $null }

                [int] $Target = 0
                try { $Target = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersion',0) }
                catch {}

                [string] $TargetInfo = ''
                try { $TargetInfo = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersionInfo','') }
                catch {}

                # Удаление всего раздела, для очистки параметров из ГП, так как удаление параметра воспринимается в некоторых политиках как "Отключено", а не как "Не задано"!
                Set-LGP -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
                Set-LGP -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'

                # Если есть политика исключения драйверов, то установка его обратно, после удаления всего раздела из политики.
                if ( $DriverExcl )
                {
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1
                }

                if ( [int32]::TryParse("$ManagePreviewBuilds",[ref]$null) -and [int32]::TryParse("$ManagePreviewBuildsPolicy",[ref]$null) )
                {
                    # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\Центр обновления Windows для бизнеса "Управлять предварительными сборками"
                    $Value = $ManagePreviewBuilds
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuilds' -Type DWord $Value
                    $Value = $ManagePreviewBuildsPolicy
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuildsPolicyValue' -Type DWord $Value
                }

                # Было настроено не повышать версию, восстановление параметров после очистки
                if ( $Target -eq 1 -and $TargetInfo )
                {
                    Set-Update-Windows -Act Set -Option NotUpgradeOSver -NoHeader
                }
            }

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows"
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate'

            if ( $Option -eq 'ManualWu' )
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Отключено)
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 1
            }
            elseif ( $Option -eq 'NotifyWu' )
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Включено, Уведомление о наличии)
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'AUOptions' -Type DWord 2
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallDay' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallTime' -Type DWord 3
            }

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не разрешать политикам задержки получения обновлений инициировать сканирование в Центре обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableDualScan' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Частота поиска автоматических обновлений" (Отключено)
            # Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'DetectionFrequencyEnabled' -Type DWord 0

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Включить рекомендуемые обновления через автоматическое обновление" (Не задано) Работает только при автоматическом обновлении!
            # Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'IncludeRecommendedUpdates'

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Включено, HTTP, без пиринга)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name 'DODownLoadMode' -Type DWord 0

            Set-SettingsPageVisibility -Act:$Act -Remove -Names 'windowsupdate', 'delivery-optimization'

            if (( $Act -eq 'Set' ) -and $ApplyGP )
            {
                # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
                Set-LGP -ApplyGP

                # Обновление ГП вызывает запуск служб ЦО, а необходимо чтобы эта служба оставалась остановленной
                Start-Sleep -Milliseconds 2000
                Stop-Service -Name wuauserv -Force -WarningAction 0 -ErrorAction 0
            }
        }
        elseif ( $Option -like 'ClearCache*' )
        {
            if ( $Act -eq 'Set' )
            {
                if ( $Option -eq 'ClearCacheAll' )
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { 'Полная Очистка Кэша Обновлений' }
                    Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

                    [string] $DataStoreMatch  = '==========='
                }
                else
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { 'Очистка Кэша Обновлений (без журнала обновлений)' }
                    Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

                    [string] $DataStoreMatch = '\\SoftwareDistribution\\DataStore$|\\USOPrivate\\UpdateStore\\'
                }

                [hashtable] $SvcDefault = @{

                    'wuauserv' = 'Manual'
                    'UsoSvc'   = 'DelayedAuto'
                    'BITS'     = 'Manual'
                    'CryptSvc' = 'Automatic'
                }

                # Сохранение состояния и статуса службы, чтобы воспроизвести его после выполнения
                [array] $CheckSVC = @()
                foreach ( $Name in 'wuauserv','UsoSvc','BITS','CryptSvc' )
                {
                    $CheckSVC += [PSCustomObject] @{
                        Name        = $Name
                        StartupType = (Check-State-Service $Name -Return Value)
                        Status      = (Check-State-Service $Name -Return Value -CheckStatus).Trim()
                        Default     = $SvcDefault.$Name
                    }
                }

                Set-Svc Set-Service -Name 'wuauserv' -Status Stopped
                Set-Svc Set-Service -Name 'BITS' -Status Stopped
                Set-Svc Set-Service -Name 'CryptSvc' -Status Stopped
                Set-Svc Set-Service -Name 'UsoSvc' -Status Stopped
                Set-Svc Set-Service -Name 'uhssvc' -StartupType Disabled -OrigCmdlet -Status Stopped

                [string[]] $Paths = "$env:SystemRoot\SoftwareDistribution\",
                                    "$env:ProgramData\USOPrivate\UpdateStore\",
                                    "$env:SystemRoot\System32\catroot2\"

                Token-Impersonate -Token SYS

                foreach ( $Path in ( $Paths -notmatch $DataStoreMatch ))
                {
                    $text = if ( $L.s24 ) { $L.s24 } else { 'Удаление кэша в' }
                    Write-Host "`n   $text '$Path'" -ForegroundColor DarkCyan

                    # Отсутствие папки может приводить к большим и не явным проблемам
                    if ( -not [System.IO.Directory]::Exists($Path) )
                    {
                        try { New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop > $null }
                        catch
                        {
                            Write-Warning "New-Item Directory: Error: '$Path'`n`t$($_.exception.Message)"
                        }
                    }
                    else
                    {
                        (Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue
                            ).FullName.Where({ $_ -notmatch $DataStoreMatch }).ForEach({

                                $text = if ( $L.s25 ) { $L.s25 } else { '      Удаление:' }
                                Write-Host "   $text '$_'" -ForegroundColor DarkGray

                                Remove-Item -LiteralPath "\\?\$_" -Recurse -Force -ErrorAction SilentlyContinue
                            })
                    }
                }

                Token-Impersonate -Reset

                Write-Host

                # Восстанавливаем состояние служб, если работала настраиваем полностью как по умолчанию и запускаем
                # Либо просто опять стопаем, чтобы показывало состояние и результат в выводе
                foreach ( $SVC in $CheckSVC )
                {
                    if ( $SVC.StartupType -and $SVC.Status -and $SVC.Default )
                    {
                        $Name = $SVC.Name

                        if ( $SVC.Status -eq 'Running' )
                        {
                            if ( $SVC.StartupType -eq 'Disabled' )
                            {
                                Set-Svc Set-Service -Name $Name -StartupType Disabled
                            }
                            else
                            {
                                $StartupType = $SVC.Default

                                Set-Svc Set-Service -Name $Name -StartupType $StartupType -Status Running
                            }
                        }
                        else
                        {
                            $Name = $SVC.Name
                            #$StartupType = $SVC.StartupType

                            Set-Svc Set-Service -Name $Name -Status Stopped
                        }
                    }
                }

                if ( $CheckSVC.Where({ $_.Name -eq 'wuauserv' }).StartupType -eq 'Disabled' )
                {
                    [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"

                    if ( -not ( [System.IO.File]::Exists($File) ))
                    {
                        $text = if ( $L.s17_1 ) { $L.s17_1 } else { 'Создание файла-заглушки' }
                        Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$File" -ForegroundColor DarkGray

                        try
                        {
                            Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
                            New-Item -ItemType File -Path $File -Force -ErrorAction SilentlyContinue > $null
                            (Get-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                        }
                        catch {}

                        if ( [System.IO.File]::Exists($File) )
                        {
                            $text = if ( $L.s17_2 ) { $L.s17_2 } else { 'Создан' }
                            Write-Host "   $text`n" -ForegroundColor DarkGreen
                        }
                        else
                        {
                            $text = if ( $L.s17_3 ) { $L.s17_3 } else { 'Не Создан' }
                            Write-Host "   $text`n" -ForegroundColor Yellow
                        }
                    }
                    else
                    {
                        $text = if ( $L.s17_4 ) { $L.s17_4 } else { 'Файл-заглушка существует' }
                        Write-Host "`n   $text`: " -ForegroundColor DarkGreen -NoNewline
                        Write-Host "$File`n" -ForegroundColor DarkGray
                    }
                }

                Get-Pause

                Return  # Выход из функции
            }
            else
            {
                $text = if ( $L.s26 ) { $L.s26 } else { '''Check'' не предусмотрен для ''ClearCache''' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'EnableOtherMS' )
        {
            $text = if ( $L.s27_2 ) { $L.s27_2 } else { 'Включение обновления других продуктов MS' }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            [int] $ServWU = 4

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\wuauserv','ReadSubTree','QueryValues')
                $ServWU = $OpenSubKey.GetValue('Start',4)
                $OpenSubKey.Close()
            }
            catch {}

            if ( $Act -eq 'Set' )
            {
                # Если служба wuauserv существует и не отключена
                if ( $ServWU -ne 4 )
                {
                    try
                    {
                        # Настройка фоновым процессом, с ограничением по времени 6 сек, и принудительным завершением процесса потом.
                        $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
                        $StartInfo.FileName = 'PowerShell.exe' ; $StartInfo.WindowStyle = 'Hidden' ; $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false
                        $StartInfo.Arguments = "-WindowStyle Hidden -NoLogo -NoProfile -Command (New-Object -ComObject 'Microsoft.Update.ServiceManager').AddService2('7971f918-a847-4430-9279-4a52d1efe18d', 7, '') > `$null"

                        $Process = [System.Diagnostics.Process]::Start($StartInfo)
                        $Process.WaitForExit(6000) > $null
                        try { $Process.Kill() } catch {}
                        $Process.Close()
                    }
                    catch {}

                    $text = if ( $L.s27_3 ) { $L.s27_3 } else { 'Завершено' }

                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
                else
                {
                    $text = if ( $L.s15_4 ) { $L.s15_4 } else { 'Пропущено' }

                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
            }
            elseif ( $Act -eq 'Check' )
            {
                # Если служба wuauserv существует и не отключена
                if ( $ServWU -ne 4 )
                {
                    [int[]] $RegWU = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\7971F918-A847-4430-9279-4A52D1EFE18D','RegisteredWithAU',0),
                                     [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\Pending\7971F918-A847-4430-9279-4A52D1EFE18D','RegisterWithAU',0)

                    if ( $RegWU -like 1 )
                    {
                        $text = if ( $L.s15_1 ) { $L.s15_1 } else { 'Включено ' }

                        Write-Host "`n   $text" -ForegroundColor DarkCyan
                    }
                    else
                    {
                        $text = if ( $L.s15_2 ) { $L.s15_2 } else { 'Отключено' }

                        Write-Host "`n   $text" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                }
                else
                {
                    $text = if ( $L.s15_4 ) { $L.s15_4 } else { 'Пропущено' }

                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
            }
        }
        elseif ( $Option -eq 'DisableLangUpdate' )
        {
            $text = if ( $L.s28 ) { $L.s28 } else { 'Отключение обновления языковых компонентов' }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            Set-Svc -Do:$Act Set-Service -Name 'LxpSvc' -StartupType Disabled -Status Stopped

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Installation'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources'
        }
        elseif ( $Option -eq 'NotUpgradeOSver' )
        {
            $text = if ( $L.s20_1 ) { $L.s20_1 } else { 'Не повышать версию ОС до конца срока' }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

            [string] $Value = ''

            try { $Value = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','DisplayVersion','') }
            catch {}

            if ( $Value )
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\... для бизнеса
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'TargetReleaseVersion' -Type DWord 1
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'TargetReleaseVersionInfo' -Type String $Value

                if ( [System.Environment]::OSVersion.Version.Build -lt 22000 ) { $Value = 'Windows 10' } else { $Value = 'Windows 11' }

                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ProductVersion' -Type String $Value
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableOSUpgrade' -Type DWord 1

                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'DisableOSUpgrade' -Type DWord 1

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\Setup\UpgradeNotification' -Name 'UpgradeAvailable' -Type DWord 0
            }
            else
            {
                Write-Host '   No DisplayVersion' -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'BlockServices' )
        {
            $text = if ( $L.s19_3 ) { $L.s19_3 } else { 'Блокировка доступа к службам ЦО' }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            # Блокировка установкой дескриптора безопасности
            if ( $Act -eq 'Set' )
            {
                Write-Host
                Telemetry-Data-Collection-Disable

                # Блокировка WaaS и удаление Tools
                Set-Update-Windows -Act Set -Option BlockWaaSdelTools -NoHeader

                Write-Host

                Set-Svc-AccessDeny -ServiceName 'wuauserv'     -Act Set
                Set-Svc-AccessDeny -ServiceName 'UsoSvc'       -Act Set
                Set-Svc-AccessDeny -ServiceName 'DoSvc'        -Act Set
                Set-Svc-AccessDeny -ServiceName 'WaaSMedicSvc' -Act Set
            }
            else
            {
                Write-Host

                Set-Svc-AccessDeny -ServiceName 'wuauserv'     -Act Check
                Set-Svc-AccessDeny -ServiceName 'UsoSvc'       -Act Check
                Set-Svc-AccessDeny -ServiceName 'DoSvc'        -Act Check
                Set-Svc-AccessDeny -ServiceName 'WaaSMedicSvc' -Act Check
            }
        }
        elseif ( $Option -eq 'BlockWaaSdelTools' )
        {
            $text = if ( $L.s19_6 ) { $L.s19_6 } else { 'Блокировка запуска утилит WaaS и удаление Microsoft Update Health Tools' }
            Write-Host "`n   $text`: `n" -ForegroundColor DarkCyan

            Telemetry-Data-Collection-Disable

            # Удаление Microsoft Update Health Tools
            [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                  'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

            [psobject] $OpenSubKey = $null
            [array] $Installed = @()

            foreach ( $RegKey in $RegKeys )
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                if ( $OpenSubKey )
                {
                    foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                    {
                        $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                        $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                        if (( $DisplayName -like 'Microsoft*Update*Health*Tools*' ) -and ( $UninstallString -like 'msiexec*' ))
                        {
                            $Installed += [PSCustomObject] @{
                                DisplayName     = $DisplayName
                                UninstallString = $UninstallString -replace 'msiexec(.exe)?',''
                            }
                        }
                    }

                    $OpenSubKey.Close()
                }
            }

            if ( $Installed.Length ) { Write-Host }
            else
            {
                $text = if ( $L.s19_7 ) { $L.s19_7 } else { 'Microsoft Update Health Tools не установлен' }
                Write-Host "`n   $text" -ForegroundColor DarkGray
            }

            $Installed | ForEach-Object {

                $text = if ( $L.s17_6 ) { $L.s17_6 } else { 'Установлен' }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$($_.DisplayName) | msiexec.exe $($_.UninstallString)" -ForegroundColor White

                if ( $Act -eq 'Set' )
                {
                    $text = if ( $L.s17_7 ) { $L.s17_7 } else { 'Удаление' }
                    Write-Host "   $text ...`n" -ForegroundColor Cyan

                    $StartInfo = [System.Diagnostics.ProcessStartInfo]::new('msiexec.exe')
                    $StartInfo.Arguments = '{0} /quiet /noreboot' -f $_.UninstallString
                    $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false

                    try { $P = [System.Diagnostics.Process]::Start($StartInfo) ; $P.WaitForExit() ; $P.Close() }
                    catch { Write-Host "   Uninstall Error: $($_.DisplayName) | msiexec.exe $($_.UninstallString) /quiet /noreboot" -ForegroundColor Red }
                }
                else
                {
                    $NeedFix = $true
                }
            }

            try
            {
                $Name = 'uhssvc'   # Microsoft Update Health Tools

                if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$Name",'ImagePath',$null) -like '*\uhssvc.*' )
                {
                    Set-Svc -Do:$Act Set-Service -Name $Name -StartupType Disabled -Status Stopped -OrigCmdlet

                    if ( $Act -eq 'Set' )
                    {
                        try { (Get-WmiObject win32_service -Filter "name='$Name'").delete() > $null } catch {}
                        try { Remove-Item -LiteralPath "$env:ProgramFiles\Microsoft Update Health Tools" -Recurse -Force -ErrorAction SilentlyContinue } catch {}
                    }

                    $Path = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
                    Set-Reg -Do:$Act Remove-Item -Path $Path
                }
            }
            catch {}

            $text = if ( $L.s19_8 ) { $L.s19_8 } else { 'Блокировка запуска' }
            Write-Host "`n   $text`: WaaSMedicAgent.exe, upfc.exe`n" -ForegroundColor DarkGray

            # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
            $ListPresetsGlobal = Get-List-Presets -File $FilePresets

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
            {
                [string] $Value = $Matches.Debugger.Trim()
            }
            else { [string] $Value = 'dllhost.exe' }

            if ( $Act -eq 'Set' )
            {
                Start-ProcessFromSYS TI -CmdLine "powershell.exe -nop -c ""gwmi -Query 'SELECT * FROM win32_process WHERE Name=''upfc.exe'' OR Name=''WaaSMedicAgent.exe'''|%{`$_.Terminate()}""" -NoWindow -Wait
            }

            if ( $Act -eq 'Check' )
            {
                $Debugger = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\WaaSMedicAgent.exe','Debugger','')
                if ( $Debugger ) { $Value = $Debugger }
            }
            
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\WaaSMedicAgent.exe' -Name 'Debugger' -Type String $Value
            
            if ( $Act -eq 'Check' )
            {
                $Debugger = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\upfc.exe','Debugger','')
                if ( $Debugger ) { $Value = $Debugger }
            }
            
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\upfc.exe' -Name 'Debugger' -Type String $Value
            
            Set-Svc -Do:$Act Set-Service -Name 'WaaSMedicSvc' -StartupType Disabled -Status Stopped
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        if ( -not $NoHeader )
        {
            $text = if ( $L.s16 ) { $L.s16 } else { 'Настройка Центра Обновлений Windows' }
            Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'Функция' }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
        }

        if ( $Option -eq 'EnableOtherMS' )
        {
            $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Отключение обновления других продуктов MS (По умолчанию)' }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            [int] $ServWU = 4

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\wuauserv','ReadSubTree','QueryValues')
                $ServWU = $OpenSubKey.GetValue('Start',4)
                $OpenSubKey.Close()
            }
            catch {}

            if ( $ServWU -ne 4 )
            {
                try
                {
                    # Настройка фоновым процессом, с ограничением по времени 6 сек, и принудительным завершением процесса потом.
                    $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
                    $StartInfo.FileName = 'PowerShell.exe' ; $StartInfo.WindowStyle = 'Hidden' ; $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false
                    $StartInfo.Arguments = "-WindowStyle Hidden -NoLogo -NoProfile -Command (New-Object -ComObject 'Microsoft.Update.ServiceManager').RemoveService('7971f918-a847-4430-9279-4a52d1efe18d') > `$null"

                    $Process = [System.Diagnostics.Process]::Start($StartInfo)
                    $Process.WaitForExit(6000) > $null
                    try { $Process.Kill() } catch {}
                    $Process.Close()
                }
                catch {}

                $text = if ( $L.s27_3 ) { $L.s27_3 } else { 'Завершено' }

                Write-Host "   $text" -ForegroundColor DarkGray
            }
            else
            {
                $text = if ( $L.s15_4 ) { $L.s15_4 } else { 'Пропущено' }

                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'DisableLangUpdate' )
        {
            $text = if ( $L.s29 ) { $L.s29 } else { 'Восстановление обновления языковых компонентов (По умолчанию)' }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Svc Set-Service -Name 'LxpSvc' -StartupType Manual

            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Installation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources'
        }
        elseif ( $Option -eq 'NotUpgradeOSver' )
        {
            $text = if ( $L.s20_2 ) { $L.s20_2 } else { 'Повышать версию ОС (По умолчанию)' }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'TargetReleaseVersion'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'TargetReleaseVersionInfo'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ProductVersion'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableOSUpgrade'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\WindowsStore' -Name 'DisableOSUpgrade'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\Setup\UpgradeNotification' -Name 'UpgradeAvailable'
        }
        elseif ( $Option -eq 'BlockServices' )
        {
            $text = if ( $L.s19_4 ) { $L.s19_4 } else { 'Разблокировка доступа к службам (По умолчанию)' }
            Write-Host "`n   $text`: " -ForegroundColor Magenta -NoNewline
            Write-Host "wuauserv/UsoSvc/DoSvc/WaaSMedicSvc`n" -ForegroundColor DarkGray

            Set-Svc-AccessDeny -ServiceName 'wuauserv'     -Act Default
            Set-Svc-AccessDeny -ServiceName 'UsoSvc'       -Act Default
            Set-Svc-AccessDeny -ServiceName 'DoSvc'        -Act Default
            Set-Svc-AccessDeny -ServiceName 'WaaSMedicSvc' -Act Default
        }
        elseif ( $Option -eq 'BlockWaaSdelTools' )
        {
            $text = if ( $L.s19_9 ) { $L.s19_9 } else { 'Разблокировка запуска' }
            Write-Host "`n   $text`: WaaSMedicAgent.exe, upfc.exe`n" -ForegroundColor DarkGray

            # Удаление блокировки запуска WaaSMedicAgent.exe и upfc.exe
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\WaaSMedicAgent.exe' -Name 'Debugger'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\upfc.exe' -Name 'Debugger'
        }
        else  # восстановить всё По умолчанию.
        {
            $text = if ( $L.s27 ) { $L.s27 } else { 'Восстановление обновлений (По умолчанию)' }
            Write-Host "`n   $text`:`n" -ForegroundColor Magenta

            [int] $Target = 0
            try { $Target = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersion',0) }
            catch {}

            [string] $TargetInfo = ''
            try { $TargetInfo = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','TargetReleaseVersionInfo','') }
            catch {}

            [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
            if ( [System.IO.File]::Exists($File) )
            {
                $text = if ( $L.s17_5 ) { $L.s17_5 } else { 'Удаление файла-заглушки' }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$File`n" -ForegroundColor DarkGray

                try { Remove-Item -LiteralPath \\?\$File -Force -ErrorAction SilentlyContinue } catch {}
            }

            # разблокировка доступа к службам ЦО
            Set-Update-Windows -Act Default -Option BlockServices -NoHeader

            # удаление параметров не повышать версию
            Set-Update-Windows -Act Default -Option NotUpgradeOSver -NoHeader

            # Если Полный сброс вообще всего (когда без указания параметра вообще)
            if ( -not ( $Option -like 'DisableWu*' ))
            {
                # Удаление блокировки запуска WaaSMedicAgent.exe и upfc.exe
                Set-Update-Windows -Act Default -Option BlockWaaSdelTools -NoHeader
            }

            Write-Host

            Set-Svc Set-Service -Name 'wuauserv' -StartupType Manual
            Set-Svc Set-Service -Name 'BITS'     -StartupType Manual
            Set-Svc Set-Service -Name 'DoSvc' -StartupType Manual
            Set-Svc Set-Service -Name 'UsoSvc' -StartupType DelayedAuto
           
            #Set-Svc Set-Service -Name 'uhssvc' -StartupType DelayedAuto
            #Set-Svc Set-Service -Name 'WaaSMedicSvc' -StartupType Manual

            & LODCTR.exe /E:BITS

            if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like '*BITS*(Enabled)' )
            {
                $text = if ( $L.s19 ) { $L.s19 } else { '  Выполнено' }
                Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                Write-Host '     BITS ' -ForegroundColor White -NoNewline
                Write-Host "| $BITS" -ForegroundColor DarkGray
            }

            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask'
            
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Backup Scan'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Download'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Install'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Report policies'
            #Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Work'

            #Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Maintenance Install'
            #Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'

            # Если Полный сброс вообще всего (указан какой либо параметр)
            if ( -not ( $Option -like 'DisableWu*' ))
            {
                # удаление параметров не обновлять языковые файлы
                Set-Update-Windows -Act Default -Option DisableLangUpdate -NoHeader
            }

            try { [int] $DriverExcl = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null)
            } catch { [int] $DriverExcl = 0 }

            # Сброс всех ГП для ЦО
            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'

            # Если есть политика исключения драйверов, то установка его обратно, после удаления всего раздела из политики.
            if ( $DriverExcl )
            {
                Set-LGP New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1
            }

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate'

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Не задано)
            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'

            Set-SettingsPageVisibility -Names 'windowsupdate', 'delivery-optimization' -Remove

            # Если НЕ полный сброс вообще всего
            if ( $Option -like 'DisableWu*' )
            {
                # если было настроено не повышать версию, восстановление параметров после очистки
                if ( $Target -eq 1 -and $TargetInfo )
                {
                    Set-Update-Windows -Act Set -Option NotUpgradeOSver -NoHeader
                }
            }
            else
            {
                # удаление параметров не обновлять другие продукты MS
                Set-Update-Windows -Act Default -Option EnableOtherMS -NoHeader
            }
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        if ( $Option -ne 'EnableOtherMS' )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { 'Необходимо перезагрузиться!' }
            Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen
        }

        Get-Pause
    }
}
