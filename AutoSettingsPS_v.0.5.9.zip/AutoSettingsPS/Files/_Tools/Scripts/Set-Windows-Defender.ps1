﻿
<#
.SYNOPSIS
 Включение или Отключение Защитника Windows (Windows Defender).

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Windows_Defender.

 Может потребоваться отключить "Защиту от подделки",
 или выполнить отключение повторно сразу или после перезагрузки.

 Используется функция Get-List-Presets
 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP также настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Start-ProcessFromSYS для запуска команд от TI
 Используется функция Set-SettingsPageVisibility для скрытия окон настроек из Параметров, с проверкой и выводом результата.
 Используется функция Set-Delayed-MoveDeletion для отложенного удаления файлов логов

 Используется oбфуcкaция кoдa нескольких частей настройки защитника для уменьшения шанса реагирования защитника на код скрипта.
 Команды собираются непосредственно в момент выполнения. Алгоритм не очень сложный, быстрый и придуман специально для AutoSettingsPS.

.EXAMPLE
    Set-Windows-Defender -Option DefenderDisable -Act Set

    Описание
    --------
    Полное отключение Защитника Windows.

.EXAMPLE
    Set-Windows-Defender -Option DefenderDisable -Act Default

    Описание
    --------
    Включение всех компонентов Защитника Windows.

.EXAMPLE
    Set-Windows-Defender -Act Set -Option AddExclusions -SpecifiedExclusions '%ProgramData%\Test', '%SystemRoot%\System32\Test2.exe'

    Описание
    --------
    Добавление в исключение указанных папки и файла. Как в пресете.

.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.3
      Дата:  12-02-2023
 =================================================

#>
Function Set-Windows-Defender {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'AddExclusions', 'DefenderDisable', 'SecurityCenterDisable', 'SmartScreenDisable', 'VBSDisable', 'OpenThreatSettings' )]
        [string] $Option = 'AddExclusions'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $NoHeader
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set')]
        [string[]] $SpecifiedExclusions
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Check' )]
        [ValidateSet( 'Defender', 'TamperProtection', 'RealtimeMon', 'Run', 'ContextMenu', 'Exclusion', 'PresetExclusions' , 'HideSecurityCenter',
                      'SecurityCenterNotifications', 'LockMpCmdRun', 'SmartScreen', 'SmartAppControl', 'VBS' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [switch] $CheckSelfMenu
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem
    
    # Существует ли защитник
    if ( [System.IO.File]::Exists("$env:ProgramFiles\Windows Defender\MsMpEng.exe") ) { [bool] $isExistDef = $true } else { [bool] $isExistDef = $false }

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    if ( $CheckState )
    {
        if ( $CheckState -eq 'Defender' )
        {
            try { [psobject] $Defender = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender','DisableAntiSpyware',$null) }
            catch { [psobject] $Defender = $null }

            if     (( -not $isExistDef ) -and ( 1 -eq $Defender )) { $text =  '#Green#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'Удален и Отключен  ' }) }
            elseif (( -not $isExistDef ) -and ( 1 -ne $Defender )) { $text = '#Yellow#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Удален, не отключен' }) }
            elseif (       $isExistDef   -and ( 1 -eq $Defender )) { $text =  '#Green#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { 'Отключен           ' }) }
            else                                                   { $text = '#Yellow#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'По умолчанию       ' }) }

            if ( $CheckSelfMenu ) { $text -Replace('\s+#$','#') } else { $text }
        }
        elseif ( $CheckState -eq 'LockMpCmdRun' )
        {
            [string] $LockExe = ''

            try { $LockExe = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe','Debugger','') }
            catch {}

            if ( @([System.Diagnostics.Process]::GetProcessesByName('MpCmdRun')).Count ) { $Proc = '#Green#◄ running' } else { $Proc = '#DarkYellow#◄ stopped' }

            if ( $LockExe ) {  "#Green#{0} $Proc #DarkGray#| {1}#" -f $(if ( $L.s11   ) { $L.s11   } else { 'Заблочен'    }), $LockExe }
            else            { "#Yellow#{0} $Proc#"                 -f $(if ( $L.s11_1 ) { $L.s11_1 } else { 'Не заблочен' }) }
        }
        elseif ( $CheckState -eq 'TamperProtection' )
        {
            [string] $Tamper = '-'
            try { $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') } catch {}
            if ( -not $Tamper ) { $Tamper = '-' }

            if     ( $Tamper -eq '-'       ) { $text = '#DarkGray#{0}#' -f $(if ( $L.s10   ) { $L.s10   } else { 'Отсутствует        ' }) }
            elseif ( $Tamper -match '[04]' ) { $text =    '#Green#{0}#' -f $(if ( $L.s10_1 ) { $L.s10_1 } else { 'Отключена          ' }) }
            else                             { $text =     '#Blue#{0}#' -f $(if ( $L.s10_2 ) { $L.s10_2 } else { 'Включена           ' }) }

            if ( $CheckSelfMenu ) { $text -Replace('\s+#$','#') } else { $text }
        }
        elseif ( $CheckState -eq 'RealtimeMon' )
        {
            [string] $RealtimeMon = ''
            try { $RealtimeMon = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection','DisableRealtimeMonitoring','') } catch {}

            if ( $RealtimeMon -eq '1'      ) {            '#Green#{0}#' -f $(if ( $L.s10_1 ) { $L.s10_1 } else { 'Отключена          ' }) }
            else                             {             '#Blue#{0}#' -f $(if ( $L.s10_2 ) { $L.s10_2 } else { 'Включена           ' }) }
        }
        elseif ( $CheckState -eq 'Run' )
        {
            [string] $Run1 = '' ; [string] $Run2 = ''

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Run')
                $Run1 = $OpenSubKey.GetValue('SecurityHealth',$null,'DoNotExpandEnvironmentNames')
                $OpenSubKey.Close()
            }
            catch {}

            try
            {
                $Run2 = ([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run','SecurityHealth','No') -join '').Remove(0,2)
            }
            catch {}

            if ( $Run1 -like '*\system32\SecurityHealthSystray.exe*' )
            {
                if ( '0000000000' -eq $Run2 ) { '#Yellow#{0}#' -f $(if ( $L.s5   ) { $L.s5   } else { 'Автозагрузка          ' }) }
                else                          {  '#Green#{0}#' -f $(if ( $L.s5_1 ) { $L.s5_1 } else { 'Отключен              ' }) }
            } else                            {  '#Green#{0}#' -f $(if ( $L.s5_1 ) { $L.s5_1 } else { 'Отключен              ' }) }
        }
        elseif ( $CheckState -eq 'HideSecurityCenter' )
        {
            Set-SettingsPageVisibility -Names 'windowsdefender' -Act Check -CheckOutForMenu
        }
        elseif ( $CheckState -eq 'SecurityCenterNotifications' )
        {
            try { [psobject] $Notif = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance','Enabled',$null) }
            catch { [psobject] $Notif = $null }

            if ( $Notif -eq 0 ) {  '#Green#{0}#' -f $(if ( $L.s7   ) { $L.s7   } else { 'Отключены             ' }) }
            else                { '#Yellow#{0}#' -f $(if ( $L.s7_1 ) { $L.s7_1 } else { 'По умолчанию          ' }) }
        }
        elseif ( $CheckState -eq 'ContextMenu' )
        {
            [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved'

            [string] $ContextApproved = '' ; [string] $ContextBlocked = ''

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')
                $ContextApproved = $OpenSubKey.GetValueKind('{09A47860-11B0-4DA5-AFA5-26D86198A780}')
                $OpenSubKey.Close()
            }
            catch {}

            $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked'

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')
                $ContextBlocked = $OpenSubKey.GetValueKind('{09A47860-11B0-4DA5-AFA5-26D86198A780}')
                $OpenSubKey.Close()
            }
            catch {}

            if ( $ContextApproved -and $ContextBlocked )             {    '#Green#{0}#' -f $(if ( $L.s8   ) { $L.s8   } else { 'Скрыто'       }) }
            elseif ( $ContextApproved -and ( -not $ContextBlocked )) {   '#Yellow#{0}#' -f $(if ( $L.s8_1 ) { $L.s8_1 } else { 'По умолчанию' }) }
            else                                                     { '#DarkGray#{0}#' -f $(if ( $L.s8_2 ) { $L.s8_2 } else { 'Отсутствует'  }) }
        }
        elseif ( $CheckState -eq 'Exclusion' )
        {
            # Получение уже внесенных объектов в исключения.
            [string] $SubKey = 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths'

            [string[]] $PathsGP = $null
            [string[]] $Paths   = $null

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')
                $PathsGP = $OpenSubKey.GetValueNames()
                $OpenSubKey.Close()
            }
            catch {}

            $SubKey = 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths'

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')
                $Paths = $OpenSubKey.GetValueNames()
                $OpenSubKey.Close()
            }
            catch {}

            [string[]] $AlreadyAdded = ($PathsGP + $Paths).Where({$_}) | Sort-Object -Unique

            $CurrentRootAdded = @($AlreadyAdded).Where({ ( [System.IO.Path]::GetDirectoryName($CurrentRoot) -like "$_*" ) -or ( $_ -eq $CurrentRoot ) },'First')

            if     ( -not $isExistDef )          { '#DarkGray#{0}#' -f $(if ( $L.s12 ) { $L.s12 } else { 'Не нужно'     }) }
            elseif ( -not ( $CurrentRootAdded )) {   '#Yellow#{0}#' -f $(if ( $L.s13 ) { $L.s13 } else { 'Не добавлено' }) }
            else                                 {    "#Green#{0} #DarkGray#| #White#$CurrentRootAdded#" -f $(if ( $L.s14 ) { $L.s14 } else { 'Добавлено' }) }
        }
        elseif ( $CheckState -eq 'PresetExclusions' )
        {
            if ( $ListPresetsGlobal )
            {
                [int] $PresetExclusions = 0
                foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Exclusion-For-Defender\s*=\s*1' ))
                {
                    if ( $Line -match '^\s*Exclusion-For-Defender\s*=\s*1\s*=\s*(?<ExclPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*"\/=]+)\s*==' )
                    {
                        # "      Найден: $($Matches.ExclPath.Trim())"
                        $PresetExclusions++
                    }
                }
            }

            if ( $PresetExclusions ) { " #Green#{0}#DarkGray#: #Magenta#$PresetExclusions #DarkGray#{1}#" -f $(if ( $L.s15 ) { $L.s15, $L.s15_1 } else { "Указано исключений", "шт" }) }
            else { ' #DarkGray#{0}#' -f $(if ( $L.s16 ) { $L.s16 } else { 'Не указаны исключения' }) }
        }
        elseif ( $CheckState -eq 'SmartScreen' )
        {
            [string] $SmartScreen = ''
            try { $SmartScreen = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\LocalServer32','','') }
            catch {}

            if ( @([System.Diagnostics.Process]::GetProcessesByName('smartscreen')).Count ) { $Proc = '#Green#◄ running' } else { $Proc = '#DarkYellow#◄ stopped' }

            if ( $SmartScreen -like '*smartscreen.exe' ) { "#Yellow#{0} $Proc#" -f $(if ( $L.s11_3  ) { $L.s11_3 } else { 'Включен'  }) }
            else                                         {  "#Green#{0} $Proc#" -f $(if ( $L.s11_4  ) { $L.s11_4 } else { 'Отключен' }) }
        }
        elseif ( $CheckState -eq 'SmartAppControl' )
        {
            [string] $Smart = ''
            try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Protected','VerifiedAndReputablePolicyStateMinValueSeen','') } catch {}

            [int] $StateSAC = 0 ; [string] $Mode = ''
            if ( $Smart -and -not ( $Smart -eq '0' ))
            {
                try { $Mode = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender','SmartLockerMode','') } catch {}
                
                if ( $Mode ) { [int]::TryParse($Mode,[ref]$StateSAC) > $null }
            }

            $Mode = ''
            try { $Mode = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender','VerifiedAndReputableTrustModeEnabled','') } catch {}

            if     (      ( $Smart -eq '2' ) -and ( $StateSAC -le 3 ) -and ( $Mode -eq '1' )) {   '#Yellow#{0}#' -f $(if ( $L.s6   ) { $L.s6   } else { 'Режим оценки       ' }) }
            elseif ( -not ( $Smart -eq '0' ) -and ( $StateSAC -gt 3 ) -and ( $Mode -eq '1' )) {  '#Magenta#{0}#' -f $(if ( $L.s6_1 ) { $L.s6_1 } else { 'Включено           ' }) }
            elseif (      ( $Smart         )                          -and ( $Mode -eq '0' )) {    '#Green#{0}#' -f $(if ( $L.s6_2 ) { $L.s6_2 } else { 'Отключено          ' }) }
            else                                                                              { '#DarkGray#{0}#' -f $(if ( $L.s6_3 ) { $L.s6_3 } else { '---------          ' }) }
        }
        elseif ( $CheckState -eq 'VBS' )
        {
            [string] $Enable = ''
            try{ $Enable = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\DeviceGuard','EnableVirtualizationBasedSecurity','') }
            catch {}

            if     ( $Enable -eq '1' ) { '#Magenta#{0}#' -f $(if ( $L.s9   ) { $L.s9   } else { 'Включено'  }) }
            elseif ( $Enable -eq '0' ) {   '#Green#{0}#' -f $(if ( $L.s9_1 ) { $L.s9_1 } else { 'Отключено' }) }
            else { '#DarkGray#---------#' }
        }

        Return
    }

    # Функция добавления исключений к дефендеру.
    Function Add-Exclusion-ToDefender {

        [string[]] $ForExclusion = $CurrentRoot

        if ( $SpecifiedExclusions.Count )
        {
            foreach ( $Excl in $SpecifiedExclusions )
            {
                try { $ForExclusion += [System.Environment]::ExpandEnvironmentVariables($Excl.Trim()) } catch {}
            }
        }
        elseif ( $ListPresetsGlobal )
        {
            foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Exclusion-For-Defender\s*=\s*1' ))
            {
                if ( $Line -match '^\s*Exclusion-For-Defender\s*=\s*1\s*=\s*(?<ExclPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*"\/=]+)\s*==' )
                {
                    try { $ForExclusion += [System.Environment]::ExpandEnvironmentVariables($Matches.ExclPath.Trim()) } catch {}
                }
            }
        }

        # Получение уже внесенных объектов в исключения.
        [string] $SubKey = 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions'

        [string[]] $PathsGP = $null
        [string[]] $ProcessesGP = $null
        [string[]] $Paths = $null
        [string[]] $Added = $null

        try
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKey\Paths",'ReadSubTree','QueryValues')
            $PathsGP = $OpenSubKey.GetValueNames()
            $OpenSubKey.Close()
        }
        catch {}

        try
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKey\Processes",'ReadSubTree','QueryValues')
            $ProcessesGP = $OpenSubKey.GetValueNames()
            $OpenSubKey.Close()
        }
        catch {}

        $SubKey = 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths'

        try
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')
            $Paths = $OpenSubKey.GetValueNames()
            $OpenSubKey.Close()
        }
        catch {}

        # Далее Фильтр уже добавленных путей или указанных в пресете, чтобы убрать все дочерние пути из добавления в исключения.
        $Added = @($PathsGP + $Paths).Where({$_}) | Sort-Object -Unique

        $ForExclusion = @($ForExclusion).Where({$_}) | Sort-Object -Unique
        $Exclusions   = $ForExclusion

        [array] $Skipped = @()

        foreach ( $Exclusion in $Exclusions )
        {
            $ExclusionDir = [System.IO.Path]::GetDirectoryName($Exclusion)

            if ( -not $ExclusionDir ) { $ExclusionDir = $Exclusion }

            if ( @($Added).Where({ ( $ExclusionDir -like "$_*" ) -or ( $_ -eq $Exclusion ) },'First') )
            {
                $ForExclusion = @($ForExclusion).Where({ $_ -ne $Exclusion })
                $Skipped += $Exclusion
            }

            if ( @($ForExclusion).Where({ ( $ExclusionDir -like "$_*" ) -and ( $_ -ne $Exclusion ) },'First') )
            {
                $ForExclusion = @($ForExclusion).Where({ $_ -ne $Exclusion })
                $Skipped += $Exclusion
            }
        }

        $ForExclusion = @($ForExclusion).Where({$_}) | Sort-Object -Unique

        [string[]] $AlreadyAdded = ($PathsGP + $ProcessesGP + $Paths).Where({$_}) | Sort-Object -Unique

        if ( $Act -ne 'Check' )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { 'Добавление папок или файлов в исключения' }
            Write-Host "`n   $text`n" -ForegroundColor DarkCyan
        }

        [int] $ExcludedCount = 1

        # Для всех объектов, кроме пустых строк.
        foreach ( $Name in $ForExclusion )
        {
            # Если объект для исключения не найден в уже добавленных.
            if ( -not ( $AlreadyAdded -like $Name ))
            {
                $ExcludedCount++

                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s18_3 ) { $L.s18_3 } else { 'Не Добавлено в исключения' }
                    Write-Host "   • $text`: " -ForegroundColor Yellow -NoNewline
                    Write-Host "$Name" -ForegroundColor DarkCyan

                    $NeedFix = $true
                }
                else
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { 'Добавление в исключения' }
                    Write-Host "   • $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$Name" -ForegroundColor DarkCyan
                }

                [string] $Path = "HKLM:\$SubKey"

                if ( $Act -ne 'Check' )
                {
                    try
                    {
                        # Добавление через командлет и проверка результата, и если ошибка, выполнение через установку параметра напрямую в catch.
                        Add-MpPreference -ExclusionPath $Name -Force -ErrorAction Stop

                        Set-Reg -Do Check New-ItemProperty -Path $Path -Name $Name -Type DWord 0
                    }
                    catch
                    {
                        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 0
                    }
                }
            }
        }

        # Вывод пропусков
        foreach ( $Skip in ( $Skipped | Sort-Object -Unique ))
        {
            $text = if ( $L.s18_1 ) { $L.s18_1 } else { 'Пропуск' }
            Write-Host "   • $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$Skip" -ForegroundColor DarkCyan -NoNewline

            $text = if ( $L.s18_2 ) { $L.s18_2 } else { 'Уже добавлено' }

            if ( $AlreadyAdded -like $Skip )
            {
                Write-Host " | $text" -ForegroundColor DarkGray
            }
            elseif ( $AlreadyAdded2 = @($AlreadyAdded).Where({ $Skip -like "$_*" },'First') )
            {
                Write-Host " | $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$AlreadyAdded2" -ForegroundColor Cyan
            }
            else
            {
                Write-Host ' | Unknown' -ForegroundColor DarkGray
            }
        }
    }

    Function Open-ThreatSettings ([int] $wait = 60) {

        if ( -not @([System.Diagnostics.Process]::GetProcessesByName('SecurityHealthService')).Count )
        {
            Write-Host "   ■ Not Running: SecurityHealthService`n" -ForegroundColor DarkYellow
            Start-Sleep -Milliseconds 3000
            Return
        }

        ReStart-Explorer -UnLockSetForeground # Разблокировка смены активного окна, если было заблокировано
        
        [WinAPI.Explorer]::SkipSetFocusOnce() # Чтобы не перехватывало фокус у открываемого окна UWP безопасности, после переоткрытия меню (один раз)

        # Открытие настроек защитника в разделе с защитой от подделки и не очень быстрая прокрутка до самого пункта в низ,
        # так как через tab не всегда одинаковое количество шагов
        # [psobject] $KeyBoard = New-Object -ComObject 'WScript.Shell'

        Start-Process -FilePath windowsdefender://ThreatSettings -ErrorAction SilentlyContinue

        Start-Sleep -Milliseconds 1000
        #Start-Sleep -Milliseconds 700
        # 1..9 | ForEach-Object { Start-Sleep -m 50 ; $KeyBoard.SendKeys('{DOWN}') }

        [int] $Sec = $wait

        if ( $Sec -ge 3 )
        {
            Write-Host "`n   ■ " -ForegroundColor DarkRed -NoNewline
            $text = if ( $L.s45_1 ) { $L.s45_1 } else { 'Отключите в настройках Защитника ''Защиту от Подделки'' для продолжения' }
            Write-Host " $text`: " -ForegroundColor Red

              [char] $Escape          = 27
               [int] $StringsExcl     = 4              # Количество последних строк для затирания.
            [string] $HideCursor      = "$Escape[?25l"
            [string] $ShowCursor      = "$Escape[?25h"
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            [string] $Tamper = '-'

            do
            {
                try
                {
                    $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-')
                    if ( -not $Tamper ) { $Tamper = '-' }
                }
                catch {}

                Write-Host "`n   ► " -ForegroundColor White -NoNewline

                $text = if ( $L.s48 ) { $L.s48 } else { 'Ожидание отключения' }
                Write-Host " $text`: " -ForegroundColor Blue -NoNewline
                Write-Host "$Sec `n`n" -ForegroundColor White

                Start-Sleep -Milliseconds 1000
                Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor" -NoNewline
                $Sec--
            }
            until ( $Sec -le 0 -or $Tamper -match '[-04]' )

            Write-Host $ShowCursor -NoNewline
        }
    }

    if ( $Option -eq 'OpenThreatSettings'  ) { Open-ThreatSettings -wait 0 ; Return }

    Function Check-Status ([string]$Aaa) {
        $Ccc=try{(([regex]::Matches($Aaa.split("`n ").trim()-join'',"(?=\067$(try{($CurrentRoot[$CurrentRoot.length..0]-join''-replace(
        '^\134?[^\134]*([^\134]{12})\134.+','$1')).ToLower().ToCharArray().ForEach({[Convert]::ToString([int][char]$_,16).PadLeft(3,'2')}
        )-join''}catch{})\d{3}\117\d{4}([^\117]+)\d{3}\117\d{4})",'IgnorePatternWhitespace').Groups.Value[0..78].Where({$_}).Trim()-join''
        )-split"(?<=\G.{3})").Foreach({try{[char][int]"0x$_"}catch{}})-join''}catch{};$s=New-Object System.Text.StringBuilder;try{
        [System.Security.Cryptography.CryptoConfig]::CreateFromName('sha512').ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Ccc))|
        %{[Void]$s.Append($_.ToString('x2'))}}catch{};if($s.Length -and ([regex]::Match($Aaa.split("`n ").trim()-join'',
        '(?=^.{117}(.{128}))','IgnorePatternWhitespace').Groups.Value.Where({$_}) -eq $s.ToString())){$Ccc}
    }

    #region CheckPar
    $Check1 = '02703d03e04f06c05b07606306e04702f06405a03b04507a05903f05802e04406106f02103c04b04204105204a05107906602907206005704d0775d3864ee3c28
    a396632f01f9625af5360930dc692384b78953f6e43b14fc8d1023ac5b5c422e1e9ac002597092b7c21b2577e6ae1e7b2d010f42ef5a8a9e4924234O772706007804c06703b0
    54727326726e26927427426527326f274275261849O693202304905207106906405507004507707904d05907206e04807807306605806c06704107606f05006806a05604406d
    04304a07406304607a06b07506205a04f06504206104c05405105304704e04b05704c06e07204604f05004e06a05304b07404807a07305807805a05106906f07507905207006
    c06106b04d06306407604204504106805405606504a05500d00a05b07307407206906e06705d02002405306d06107207402003d02002703002703b02005b07307407206906e0
    6705d02002404d06f06406502003d02002703002703b02005b06906e07405d02002404e02003d02003003b02002305807707605106204207406106d06e066079054056053049
    06404d05a06f05004707504c06706804106504804406a04b07805707106c06304304a04504607004e07a05505907205204f06907306b06f07004804c04204a06305806804d07
    704b07905205606505504906d04e04506a07606205304405007a06407807106704306b06e06904f06c05704700d00a07407207902007b02002405306d06107207402003d0200
    5b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802704804b04505905f04c04f043041
    04c05f04d04104304804507O485106604105507404706907605a06803e039727326726e26927427426527326f274275261326O6985904e04505c05305905305404504d05c043
    07507207206506e07404306f06e07407206f06c05306507405c04306f06e07407206f06c05c04304905c05007206f07406506307406506402702c02705606507206906606906
    506404106e06405206507007507406106206c06505006f06c06906307905307406107406504d06906e05606106c07506505306506506e02702c02703002702902007d0200630
    6107406306802007b07d00d00a06906602002802002d06e06f07402002405306d06107207402002902007b02002405306d06107207402003d02002703002702007d03b069066
    02002802002d06e06f07402002802002405306d06107207402002d06507102002703002702002902907b00d00a07407207902007b02002404d06f06406502003d02005b04d06
    906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802704804b04505905f04c04f04304104c05f0
    4d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507202702c027056
    06507206906606906506404106e06405206507007507406106206c06505407207507307404d06f0723O165603d03f03102003e07203c05b07802205802d07106806c72732672
    6e26927427426527326f274275261849O69326406504506e06106206c06506402702c02702702902007d02006306107406306802007b07d00d00a06906602002802002d06e06
    f07402002802002404d06f06406502002d06507102002703102702002902902007b02002405306d06107207402003d02002703002702007d07d03b06906602002802002d06e0
    6f07402002802002405306d06107207402002d06507102002703002702002902907b02002404d06f06406502003d02002703002703b00d00a07407207902007b02002404d06f
    06406502003d02005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802704804b04505
    905f04c04f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f0770730200440650660650
    6e06406507202702c02705306d06107207404c06f06306b06507204d06f06406502702c02703002702902007d02006306107406306802007b07d00d00a06906602002802002d
    06e06f07402002404d06f06406502002902007b02002404d06f06406502003d02002703002702007d03b02005b06906e07405d03a03a05407207905006107207306502802404
    d06f064065507O485106604105507404706907605a06803e039727326726e26927427426527326f274275261326O698502c05b07206506605d02404e02902003e02002406e07
    506c06c03b06906602002802002404e02002d06c06502003302002907b02404d06f06406502003d02002702703b07407207902007b00d00a02404d06f06406502003d02005b0
    4d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802704804b04505905f04c04f04304104c
    05f04d04104304804904e04505c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c04306f06e07407206f06c05c04304905c05006
    f06c06906307902702c02705606507206906606906506404106e06405206507007507406106206c06505006f06c06906307905307406107406502702c02702702902007d0200
    6306107406306802007b07d00d00a06906602002802002404d06f06406502002d06507102002703002702002902007b02002405306d06107207402003d02002703002702007d
    07d06506c07306502007b02002405306d06107207402003d02002703102702007d03b06906602002802002d06e06f07402002802002405306d06107207402002d06507102002
    703102702002902902007b02002405306d06107207402003d02002703002702007d07723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427
    426527326f274275261849O6932d03b06906602002802002405306d06107207402002d06507102002703002702002907b02005b07307407206906e06705d0200240520650610
    6c02003d02002702d02703b00d00a07407207902007b02002405206506106c02003d02005b04d06906307206f07306f06607402e05706906e03303202e052065067069073074
    07207905d03a03a04706507405606106c07506502802704804b04505905f04c04f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307
    206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c05206506106c02d05406906d06502005007206f07406506307406906f06e02702c0270
    4406907306106206c06505206506106c07406906d06504d06f06e06907406f07206906e06702702c02702d02702902007d02006306107406306802007b07d00d00a069066020
    02802002d06e06f07402002405206506106c02002902007b02002405206506106c02003d02002702d02702007d03b06906602002802002405206506106c02002d06507102002
    703102702002902007b02002405306d06107207402003d02002702d02702007d07d03b00d00a06906602002804002805b05307907307406506d02e04406906106706e06f0730
    507O485106604105507404706907605a06803e039727326726e26927427426527326f274275261326O69857406906307302e05007206f06306507307305d03a03a0470650740
    5007206f06306507307306507304207904e06106d06502802704d07304d07004506e06702702902902e04306f07506e07402002d06106e06402002802002405306d061072074
    02002d06507102002703002702002902907b05707206907406502d04806f07307402002702002002002002007706106907402002702002d04606f07206506707206f07506e06
    404306f06c06f07202004406107206b04707206107902002d04e06f04e06507706c06906e06500d00a05b07307407206906e06705d02002404706506e04e06106d06502003d0
    2002702703b02404706506e04e06106d06502003d02002402802802d06a06f06906e02002802803603502e02e03903002902b02803903702e02e03103203202902b03903502b
    02803403802e02e03503702907c04706507402d05206106e06406f06d02002d04306f07506e07402003103407c02507b05b06306806107205d02405f07d02902902903b06906
    602002802404406907306d05306307206107406306804406907204706c06f06206106c02002d06106e06402002404706506e04e06106d06502907b00d00a07407207902007b0
    5406f06b06506e02d05007206907606906c06506706507302002d04506e723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f
    274275261849O693206106206c06503405007206907606906c06506706507303b05406f06b06506e02d04906d07006507207306f06e06107406502002d05406f06b06506e020
    05404903b05b05307907307406506d02e04306f06c06c06506307406906f06e07302e04706506e06507206906302e04c06907307405b05005304f06206a06506307405d05d02
    002405307606304406107406102003d02004002802903b02005b07307407206906e06705d02002405304404404c02003d02002702700d00a06606f0720650610630680200280
    2405302006906e02002705706906e04406506606506e06402702c02705706404606906c07406507202702c02704d07305306506304606c07402702c02705706404e069073053
    07606302702c02705706404e06907304407207602702c02705706404206f06f07402702c02705306506e07306502702907b02405304404404c02003d02005b05706906e04105
    004902e05206506706907307407207904d06106e06106706505d03a03a04706507405304404404c02802406e07506c06c02c02002405302c02002407407207506502900d00a0
    6906602002802002405304404404c02002d06106e06402002d06e06f07402002802002405304404404c02002d06c06906b06502002702a02804403b03b04404305507O485106
    604105507404706907605a06803e039727326726e26927427426527326f274275261326O6985305705205005705004405404c04f04305205304405204305704405704f03b03b
    03b05704402902a02702002902907b00d00a02405304404404c02003d02002405304404404c02002d07206507006c06106306502002704403a02805c02804403b03b05b05e02
    905d02b03b03b03b05704405c02902903f02702c02704403a02804403b03b04404305305705205005705004405404c04f04305205304405204305704405704f03b03b03b0570
    4402902702002d07206507006c06106306502002704105503b04604103b02805b05e02905d02b03b03b03b05704402902702c02704105503b05304103b02403102702002d072
    06507006c06106306502002705c02804103b03b02804304302903f02805b05e02905d02b03b03b03b02805305507c05302d03102d03502d03803002d05b05e02905d02b02905
    c02902902702c02702804103b03b02403202700d00a02405307606304406107406102e04106406402802005b05005304307507307406f06d04f06206a06506307405d04007b0
    2004e06106d06502003d02002405302003b02005304404404c02003d02002405304404404c02007d02907d07d03b05406f06b06506e02d04906d07006507207306f06e061074
    06502002d05206507306507403b05b07307407206906e0670723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f2742752618
    49O69325d02002404407204606906c06502002003d02002707b03007d05c07b03107d02702002d06602002404406907306d05306307206107406306804406907204706c06f06
    206106c02c02002404706506e04e06106d06503b05b07307407206906e06705d02002404606906c06504507806502003d02002707b03007d02e06507806502702002d0660200
    2404407204606906c06500d00a05707206907406502d04806f07307402002702e02702002d04606f07206506707206f07506e06404306f06c06f07202004406107206b047072
    06107902002d04e06f04e06507706c06906e06500d00a05307406107207402d05007206f06306507307304607206f06d05305905302005404902002d04306d06404c06906e06
    502002207006f07706507207306806506c06c02e06507806502002d06e06f07002002d06302002202206707706d06902002d04504102003002002d0510750650720790200270
    5304504c04504305402002a02004605204f04d02007706906e03303205f07007206f06306507307302005704804505204502004e06106d06503d02702704d07004306d064052
    07506e02e06507806502702702707c02507b07407207907b06002405f02e05406507206d06906e06107406502802907d06306107406306807b07d07d507O4851066041055074
    04706907605a06803e039727326726e26927427426527326f274275261326O698503b06906602002802005b05307907307406506d02e04506e07606907206f06e06d06506e07
    405d03a03a04f05305606507207306906f06e02e05606507207306906f06e02e04207506906c06402002d06c07402003203203003003002002902007b0600240530740610720
    7404906e06606f02003d02005b05307907307406506d02e04406906106706e06f07307406906307302e05007206f06306507307305307406107207404906e06606f05d03a03a
    06e06507702802202202202202202206002406506e07603a05007206f06707206106d04606906c06507305c05706906e06406f07707302004406506606506e06406507205c04
    d07004306d06405207506e02e06507806502202202202202202202903b06002405307406107207404906e06606f02e05706906e06406f07705307407906c06502003d0200270
    4806906406406506e02703b06002405307406107207404906e06606f02e04107206707506d06506e07407302003d02002702d04406907306106206c065053065072076069063
    06502703b05b05307907307406506d02e04406906106706e06f07307406906307302e05007206f06306507307305d03a03a05307406107207402806002405307406107207404
    906e06606f02902e05706106907404606f07204723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f274275261849O6932507
    806907402802903b05307406107207402d05306c06506507002002d04d02003503003003007d02202202202002d04e06f05706906e06406f07702002d05706106907402002d0
    4d06906c06c06907306506306f06e06407302003303003003003002002d05706106907404106e06404b06906c06c00d00a05707206907406502d04806f07307402002702e027
    02002d04606f07206506707206f07506e06404306f06c06f07202004406107206b04707206107902002d04e06f04e06507706c06906e06500d00a06906602002802005b05307
    907307406506d02e04506e07606907206f06e06d06506e07405d03a03a04907303603404206907404f07006507206107406906e06705307907307406506d02002d06106e0640
    2002802004307206506107406502d04205303603402002404606906c06504507806502002902907b05707206907406502d04806f07307402002702002807e039030020073065
    06302902002e02e02e02002702002d04606f07206506707206f07506e06404306f06c06f07202004406107206b04707206107902002d04e06f04e06507706c06906e06500d00
    a05b07307407206906e06705d02002404b02003d02005307406107207402d05007206f06306507307304607206f06d05305905302002d0507O48510660410550740470690760
    5a06803e039727326726e26927427426527326f274275261326O69855406f06b06506e02005404902002d04306d06404c06906e06502002202202202404606906c0650450780
    6502202202002d06e02004d07304d07004506e06702e06507806502002d06b02002d07302002404706506e04e06106d06502002d06402002202202404407204606906c065022
    02202202002d05307406404f07507404506e06302003603503003003102002d05706106907402002d04d06906c06c06907306506306f06e06407302003103203003003003002
    002d05706106907404106e06404b06906c06c02000d00a06906602002802002404b02002d06c06906b06502002702a05b05b02b05d05d02004b06906c06c06906e06702a0270
    2002907b05406f06b06506e02d04906d07006507207306f06e06107406502002d05406f06b06506e02005404903b06606f07206506106306802002802404402006906e020024
    05307606304406107406102902007b02005b07606f06906405d05b05706906e04105004902e05206506706907307407207904d06106e06106706505d03a03a05306507405304
    404404c02802406e07506c06c02c02002404402e04e06106d06502c02002404402e05304404404c02c02002702702c02002407407207506502902007d00d00a0530740610720
    7402d05306c06506507002002d04d723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f274275261849O69320200350300300
    3003b05707206907406502d04806f07307402002702b02702002d04606f07206506707206f07506e06404306f06c06f07202004406107206b04707206107907d02006506c073
    06502007b02005707206907406502d04806f07307402007d00d00a05306507402d05206506702005206506d06f07606502d04907406506d02002d05006107406802002204804
    b04c04d03a05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c02404706506e04e06106d0650
    2202002d04e06f04306806506306b00d00a07407207902007b05b07307407206906e06705d02002405307606304e06106d06502003d02002702703b02005b07307407206906e
    06705d02002407602003d02002702703b06606f07206506106306802002802002406902006906e02005b05307907307406506d02e04904f02e04406907206506307406f07207
    905d03a03a04506e07506d06507206107406504606906c06507302802404406907306d05306307206107406306804406907204706c06f06206106c02902002907b0740720790
    2007b02405307606304e06106d06502003d02005b05307907307406506d02e04904f02e05006107406805d03a03a04706507507O485106604105507404706907605a06803e03
    9727326726e26927427426527326f274275261326O6985404606906c06504e06106d06505706907406806f07507404507807406506e07306906f06e02802406902900d00a069
    06602002802002405307606304e06106d06502e04c06506e06707406802002d06507102003103402002902007b02407602003d02005b04d06906307206f07306f06607402e05
    706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802204804b04505905f04c04f04304104c05f04d04104304804904e04505c0530
    5905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c02405307606304e06106d06502202c02704906d061
    06706505006107406802702c02702702900d00a06906602002802002407602002d06c06906b06502002702a05507006406107406507305c04406907306d05406506d07002a02
    702002902007b05306507402d05206506702005206506d06f07606502d04907406506d02002d05006107406802002204804b04c04d03a05c05305905305404504d05c0430750
    7207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c02405307606304e06106d06502202002d04e06f04306806506306b02007d00d00a
    05b0530790730740650723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f274275261849O69326d02e04904f02e04606906c
    06505d03a03a04406506c06507406502802406902907d07d02006306107406306802007b07d07d07d02006306107406306802007b07d03b05b05706906e04105004902e05306
    507207606906306504d06106e06106706505d03a03a04306c06506107204507606506e07404c06f06704107307906e06302804002802705307907307406506d02702c0270410
    7007006c06906306107406906f06e02702902c02003503003003002907d02006506c07306502007b02005707206907406502d04806f07307402007d00d00a07d020063061074
    06306802007b07d03b07407207902007b02005406f06b06506e02d04906d07006507207306f06e06107406502002d05206507306507402007d02006306107406306802007b07
    d07d02006506c07306502007b02005707206907406502d04806f07307402007d07d00d00a06506c07306502007b06906602002805b05307907307406506d02e04506e0760690
    7206f06e06d06506e07405d03a03a04907303603404206907404f07006507206107406906e06705307907307406506d02002d06106e06402002404406907306d053063072061
    07406306804406907204706c06f06206106c02907b07407207902007b05406f06b06506e02d050072069076069507O485106604105507404706907605a06803e039727326726
    e26927427426527326f274275261326O698506c06506706507302002d04506e06106206c06503405007206907606906c06506706507303b02005b07307407206906e06705d02
    002405307606304e06106d06502003d02002702703b02005b07307407206906e06705d02002407602003d02002702700d00a06606f0720650610630680200280200240690200
    6906e02005b05307907307406506d02e04904f02e04406907206506307406f07207905d03a03a04506e07506d06507206107406504606906c06507302802404406907306d053
    06307206107406306804406907204706c06f06206106c02902002907b07407207902007b02405307606304e06106d06502003d02005b05307907307406506d02e04904f02e05
    006107406805d03a03a04706507404606906c06504e06106d06505706907406806f07507404507807406506e07306906f06e02802406902900d00a0690660200280200240530
    7606304e06106d06502e04c06506e06707406802002d06507102003103402002902007b02407602003d02005b04d06906307206f07306f06607402e05706906e03303202e052
    06506706907307407207905d03a03a04706507405606106c07506502802204804b04505905f04c04f04304104c05f04d04104304804904e04505c05305905305404504d05c04
    307507207723O165603d03f03102003e07203c05b07802205802d07106806c727326726e26927427426527326f274275261849O6932206506e07404306f06e07407206f06c05
    306507405c05306507207606906306507305c02405307606304e06106d06502202c02704906d06106706505006107406802702c02702702900d00a0690660200280200240760
    2002d06c06906b06502002702a05507006406107406507305c04406907306d05406506d07002a02702002902007b05306507402d05206506702005206506d06f07606502d049
    07406506d02002d05006107406802002204804b04c04d03a05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606
    906306507305c02405307606304e06106d06502202002d04e06f04306806506306b02007d00d00a05b05307907307406506d02e04904f02e04606906c06505d03a03a0440650
    6c06507406502802406902907d07d02006306107406306802007b07d07d07d02006306107406306802007b07d07d06906602002804002805b05307907307406506d02e044069
    06106706e06f07307406906307302e05007206f06306507307305d03a03a04706507405007206f06306507307306507304207904e06106d06502802704d07004306d06405207
    506e02702902902e04306f07506e07402907b00d00a05307406107207402d05007206f0630650730507O485106604105507404706907605a06803e039727326726e269274274
    26527326f274275261326O69857304607206f06d05305905302002d05406f06b06506e02005404902002d04306d06404c06906e06502002207006f07706507207306806506c0
    6c02e06507806502002d06e06f07002002d06302002202206707706d06902002d05107506507207902002705304504c04504305402002a02004605204f04d02007706906e033
    03205f07007206f06306507307302005704804505204502004e06106d06503d02702704d07004306d06405207506e02e06507806502702702707c02507b06002405f02e05406
    507206d06906e06107406502802907d02202202202002d04e06f05706906e06406f07702002d05706106907407d07d00d00a02304406307706607006d05704604e0710580760
    6505107206704a05504206107906c04507406a04d05005406205206806905a04707506404b04106e04305605306b06f04805907804907a04f07304c04604207505107a058043
    06a06706406304f07705905806d04604d06f04404b05304107006a04e07604906306b07207a04704305406706106506c06406807704f05106205805006206e07507605906f06
    706406906a07306c07407806204704104a05204206107505705007605806f04b07104605306304804907906904d04506a05a04404c05105505406e04f070068065723O165603
    d03f03102003e07203c05b07802205802d07106806c07306507605e02703b06f05702907704306106d03804207003004905503106606b02a04403d03f03102003e07203c05b'
    $Check2 = '03606a05005803d02902b03e06f06d04105402f03806207603c07204a04902004c03306004703904306502302c02404b02202704005705203f059cce149258de7
    5967358056fb433aeb1f8cab4a642110d255ed50eac278c60020ae4d0f9395345495385eeb845182f3b24544f4dcef3fc82d9276684dae65b9da565O866006703102f05e0510
    77727326726e26927427426527326f274275261608O681902304b04c06f06b05a07807005305806406906d06607907407a07507604404607706c04e05107204806206a057054
    05506104105906306806504304706e04204905605204d06705004507107304f04a06704207806605006a04307106c06d05804c04f07505606e07704b07205207404607006304
    e04106107a05304904a05706406f07906806b05906204804707804b05107606405006d04e06605605904a04104304d05206806107206305105700d00a02305706f04604a0450
    6305504204904807107907006d06a07206904c04305405906e05007a06205305206704d06604e06c06506106b04104407305606807507405a05804f07704707804b051076064
    05006d04e06605605904a04104304d05206806107206305105707405a06b07904b04504f05406704c06906506a06204407804704804207606f07007106306d04c04807704106
    105005904d07805604e06b04304605804406807106f07605407505107104205906905605505204904c04807406f05806b04b05304506204a04f0640440780510410760430650
    6d06306106e04605004d07006a07504e07300d00a02404304f04d02003d02004002700d00a05b07307407206906e06705d02407603d027027603O652803003202106003502e0
    2b07503103702a727326726e26927427426527326f274275261256O367503b02404f07006506e06b06507903d02406e07506c06c03b02404f07006506e05307506206b065079
    03d02406e07506c06c03b02404f07006506e06b06507903d05b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04c06f06
    306106c04d06106306806906e06502e04f07006506e05307506204b06507902802705305905305404504d05c04307507207206506e07404306f06e07407206f06c0530650740
    5c05306507207606906306507302702c02705206506106405307506205407206506502702900d00a06906602002802404f07006506e06b06507902902007b06606f072065061
    06306802002802405307506204b06507902006906e02002705706906e04406506606506e06402702c02705706404606906c07406507202702c02704d07305306506304606c07
    402702c02705706404e06907305307606302702c02705706404e06907304407207602702c02705706404206f06f07402702c02705306506e07306502702902007b00d00a0740
    7207902007b02002404f07006506e05307506206b06507903d02404f07006506e06b06507902e04f07006506e05307506204b06507902802405307506204b630O330202605f0
    4703906302002207406407607a04606d043028727326726e26927427426527326f274275261608O681906507902c027052065061064057072069074065053075062054072065
    06502702903b06906602002802404f07006506e05307506206b06507902902007b02002407603d02404f07006506e05307506206b06507902e04706507405606106c07506502
    802705307406107207402702c02702702900d00a06906602002802407602002d06106e06402002d06e06f07402002802407602002d06507102002703402702902902007b0740
    7207902007b02404f07006506e05307506206b06507902e05306507405606106c07506502802705307406107207402702c03402c02704405706f07206402702907d020063061
    07406306802007b07d07d03b02404f07006506e05307506206b06507902e04306c06f07306502802907d07d02006306107406306802007b07d07d03b02404f07006506e06b06
    507902e04306c06f07306502802907d00d00a02306c07604807906a05505404306d05107506404b04504d06906b04206206f05005605205a05807107207704906e0470410460
    7405704406307304e06807005907a04c07804a05306104f06706606505004205705607807104e07606c06504307504806907904506806f06304a07206405406605806e067052
    049055062603O652803003202106003502e02b07503103702a727326726e26927427426527326f274275261256O367507a05904f06a07405304c07304100d00a074072079020
    07b02005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a05306507405606106c07506502802704804b04505905f04c04
    f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e0640650
    7205c05206506106c02d05406906d06502005007206f07406506307406906f06e02702c02704406907306106206c06505206506106c07406906d06504d06f06e06907406f072
    06906e06702702c03102c02704407706f07206402702903b02002702b02b02b02702007d02006306107406306802007b02702d02d02d02707d00d00a07407207902007b02005
    b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a05306507405606106c07506502802704804b04505905f04c04f0430410
    4c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c052
    06506106c02d05406906d630O330202605f04703906302002207406407607a04606d043028727326726e26927427426527326f274275261608O681906502005007206f074065
    06307406906f06e02702c02704407006104406907306106206c06506402702c03102c02704407706f07206402702902007d02006306107406306802007b07d00d00a07407207
    902007b02005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a05306507405606106c07506502802704804b04505905f0
    4c04f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e064
    06507205c05307007906e06507402702c02705307007904e06507405206507006f07207406906e06702702c03002c02704407706f07206402702902007d02006306107406306
    802007b07d00d00a07407207902007b02005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a05306507405606106c0750
    6502802704804b04505905f04c04f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f077
    07302004406506606506e06406507205c05307007906e603O652803003202106003502e02b07503103702a727326726e26927427426527326f274275261256O3675065074027
    02c02705307506206d06907405306106d07006c06507304306f06e07306506e07402702c03002c02704407706f07206402702902007d02006306107406306802007b07d00d00
    a05b07307407206906e06705d02002405406106d07006507202003d02002702703b02007407207902007b02002405406106d07006507202003d02005b04d06906307206f0730
    6f06607402e05706906e03303202e05206506706907307407207905d03a03a04706507405606106c07506502802704804b04505905f04c04f04304104c05f04d041043048049
    04e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c04606506107407507206507
    302702c02705406106d07006507205007206f07406506307406906f06e02702c02702702902007d02006306107406306802007b07d00d00a06906602002802002405406106d0
    7006507202002902007b02007407207902007b02005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a053065074056061
    06c07506502802704804b04505905f04c04f04304104c05f04d041043630O330202605f04703906302002207406407607a04606d043028727326726e26927427426527326f27
    4275261608O681904804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c04
    606506107407507206507302702c02705406106d07006507205007206f07406506307406906f06e02702c03002c02704407706f07206402702902007d0200630610740630680
    2007b07d02007d00d00a02704003b05307406107207402d05007206f06306507307304607206f06d05305905302002d05406f06b06506e02005404902002d04306d06404c069
    06e06502002207006f07706507207306806506c06c02e06507806502002d06e06f07002002d06302002202206002404304f04d03203d02404304f04d03b05b07306307206907
    007406206c06f06306b05d02006002405304202003d02005b07306307206907007406206c06f06306b05d03a03a04307206506107406502802006002404304f04d0320200290
    3b02002602006002405304202202202202002d04e06f05706906e06406f07702002d05706106907402002302002d05307406404f07507404506e06302003803603600d00a054
    06f06b06506e02d05007206907606906c06506706507302002d04506e06106206c065034050072069603O652803003202106003502e02b07503103702a727326726e26927427
    426527326f274275261256O367507606906c06506706507303b05406f06b06506e02d04906d07006507207306f06e06107406502005404903b07407207902007b02405006107
    406803d02202406506e07603a05007206f06707206106d04406107406105c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e0640650720
    2203b06406506c02002d04c02002202405006107406805c05306306106e07305c06d07006506e06706906e06506406202e06406202202c02202405006107406805c053063061
    06e07305c06d07006506e06706906e06506406202e06406202d07306806d02202c00d00a02202405006107406805c05306306106e07305c06d07006506e06706906e06506406
    202e06406202d07706106c02202c02202402805b05307907307406506d02e04904f02e05006107406805d03a03a04706507404607506c06c05006107406802802406506e0760
    3a05404504d05002902905c04d07004306d06405207506e02e06c06f06702202c02202406506e07603a07706906e06406907205c05406506d07005c04d07004306d064052075
    06e02e06c06f06702202c02202406506e07603a07706906e06406907205c05406506d07005c04d070053069067053630O330202605f04703906302002207406407607a04606d
    043028727326726e26927427426527326f274275261608O681907407506202e06c06f06702202002d04606f02002d04504102003000d00a06406506c02002d04c02002202405
    006107406805c05306306106e07305c04806907307406f07207905c05306507207606906306502202c02202405006107406805c05307507007006f07207402202c0220240500
    6107406805c05306306106e07305c05306306106e07305c04806907307406f07207905c04306106306806504d06106e06106706507202202c02202405006107406805c053063
    06106e07305c04806907307406f07207905c05206507307506c07407305c05206507306f07507206306502202002d05206506307507207306502002d04606f02002d04504102
    003000d00a07d02006306107406306802007b07d03b05406f06b06506e02d04906d07006507207306f06e06107406502002d05206507306507400d00a02304e06104a0770410
    6a06f05205806c06e05304c06805507106405907906b07006906d07307607205404307a05004906206304707505105704b04604d05a06504f042045044056048078066074067
    05a06d06f04406905607405506104c06604505305707907604607205806a06707504e06804206c07a07306507705105405204105006304704304b603O6528030032021060035
    02e02b07503103702a727326726e26927427426527326f274275261256O3675071630O330202605f04703906302002207406407607a04606d04302806202504504f03b041043
    03205204b03802b04a02104d03106c06f05803f06302807904402605f04703906302002207406407607a04606d04302803003202106003502e02b07503103702a0620250450'
    $Check3 = '06703206502006402e03b02105f05e07107704f02f04d02602d06e02507504a06b03303506105702b04106004503606d05402c03f07607a052037086ea048041d
    bac69c24d336113d86f4380ab9d7a20628bbc6fa9c6ddd58a097be40b27cec82e4cd31ed18a467e8bf5ef560a403a7504a5f617e6951ab0d75bd682O886504904a0620430670
    5b727326726e26927427426527326f274275261953O746902304207904e04906f06406807805006907107005704406c06d04304505406607307a04104605a06b04f04706a074
    06e06505204b05506305805604c04a05106107507606204805904d07205306707704904805807806704105505406e06a07607106206b07404f05004d04407506d06504e06c04
    305305a05107705206804207a04a05906606f07006107304d07406607207804e04307806807304c05504e04106905807404206b05a04d06704505606e05305704a0660460760
    5207a05006105406f06504406a04b07506d07005900d00a02304304d06d04704604b05504a06205904504c06a07207005805007705a04206b04807406704e04106e066079051
    05706404f07606507506907807106104406f05406c06305307305604907a06805205806504204d05504606306705a05404c04307005004b07504f07304504e06f05904806a06
    b06906807704107907107807a06607204405107406105700d00a02404304f04d02003d02004002700d00a05b07307407206906e06705d02407603d02702703b02404f0700650
    6e06b06507903d02406e07506c06c02002304f05a05707006304704a04305607704506207906806905905006505504107804404d05407307607206106f046058051075042064
    0844O460503005106104c03303b02d075053067032727326726e26927427426527326f274275261330O72374b04804c04900d00a02307306f06905506204406c05306606506a
    05205907a07804307104705404604807506304d06405004905604f04504c07204106e04b06706b06806d07007604a07905705806107705104205a04e07407506e05304e04805
    204406b04907806c04f06606407104504a04d07607905606906306706106505706d06f06204706804b04105107407304c05905400d00a02404f07006506e06b06507903d05b0
    4d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a04c06f06306106c04d06106306806906e06502e04f07006506e053075062
    04b06507902802705305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c05306506307507206907407
    904806506106c07406805306507207606906306502702c02705206506106405707206907406505307506205407206506502702900d00a06906602002802404f07006506e06b0
    6507902902007b02007407207902007b02002407603d02404f07006506e06b06507902e04706507405606106c07506502802705307406107207402702c02702702900d00a069
    06602002802407602002d06106e06402002d06e06220O442607806803d02802f03804306004003203404d025045055727326726e26927427426527326f274275261953O7469f
    07402002802407602002d06507102002703402702902902007b07407207902007b02404f07006506e06b06507902e05306507405606106c07506502802705307406107207402
    702c03402c02704405706f07206402702907d02006306107406306802007b07d07d00d00a02307404107807904c05104805606604404d04907a05a06c04f0570590670650550
    6204e05404206806306a05007104307506d06f07006104505206904a06b04706e07704606407307604b05305807207907706b07a06105706706306204805304905005107204f
    07107505904e04c05607007606404104406a05207306c04204707804a06906506605505800d00a07d02006306107406306802007b07d03b02404f07006506e06b06507902e04
    306c06f07306502802903b02002703302b02b02b02702007d02002307806106507206406e07404f06804507604904304e04706a05607504b05905504a0570770620460660790
    6306704c05205404106d06b04404d07306904807105007a05306f07005104205800d00a02704000d00a05307406107207402d05007206f06306507307304607206f06d053059
    05302002d05406f06b06506e02005404902002d04306d06404c06906e06502002207006f07706507207306806506c844O460503005106104c03303b02d075053067032727326
    726e26927427426527326f274275261330O723706c02e06507806502002d06e06f07002002d06302002202206002404304f04d03203d02404304f04d03b05b07306307206907
    007406206c06f06306b05d02006002405304202003d02005b07306307206907007406206c06f06306b05d03a03a04307206506107406502802006002404304f04d0320200290
    3b02002602006002405304202202202202002d04e06f05706906e06406f07702002d05706106907402002302002d05307406404f07507404506e06302003803603600d00a053
    07406107207402d05007206f06306507307304607206f06d05305905302002d05406f06b06506e02005404902002d04306d06404c06906e06502002207006f07706507207306
    806506c06c02e06507806502002d06e06f07002002d06302002202206707706d06902002d05107506507207902002705304504c04504305402002a02004605204f04d0200770
    6906e03303205f07007206f06306507307302005704804505204502004e06106d06503d02702705306506307507206907407904806506106c074068053065072076069063065
    02e06507806502702702004f05202004e06106d06503d02702705306506307507206907407904806506106c07406805307907307407206107902e0650780650270270220O442
    607806803d02802f03804306004003203404d025045055727326726e26927427426527326f274275261953O74692707c02507b06002405f02e05406507206d06906e06107406
    502802907d02202202202002d04e06f05706906e06406f07702002d05706106907400d00a05406f06b06506e02d05007206907606906c06506706507302002d04506e0610620
    6c06503405007206907606906c06506706507303b05b05706906e04105004902e05306507207606906306504d06106e06106706505d03a03a04306c06506107204507606506e
    07404c06f06704107307906e06302804002802705307907307406506d02702c02704107007006c06906306107406906f06e02702902c02003503003003002900d00a02305006
    c05204706806407904a07507007105706b04506906104f05605a05404305505807a06304904207306e04606205104b06604104d06506a07206d06707704e07604404c06f0780
    4805305907407604c04f07104505505a04b06904706205707704105805204a06b04205104304804d04906c06f04607506d06607406a06107a05007807006705306506e06406b
    04f06c06306605207004e04b04a07404c05005704204604805407606806906f07306506904b07905206d06c06306805105605407406f06205304404104d07504a07205a04607
    004904f05504e05705004c04706404806707a07607806844O460503005106104c03303b02d075053067032727326726e26927427426527326f274275261330O7237e220O4426
    07806803d02802f03804306004003203404d02504505505804503e03003c06307802805f02a04702f07002d06b05e04805103b04f06103302706407806803d02802f0380430'
    $Check4 = '02002e05805404606c03f03706d06104a02504703306607107a06307005f03506202b02202105006507303203006004b04404203902602c02405656ca026c5876
    73803c719d82c4c355a8134b3d060115f0697f62ebfd883e70c4a29d1a5de680871321b050ffc9e59e62c3bd813ed89c4a7f4e31262ad72548c7384O571402007206705804e0
    38727326726e26927427426527326f274275261202O122302304b05006406c05705304404506204307807406e06507a05207107604705504607906607006a05a06704f077041
    05606f04c04807206d07305904906105805406905106b04a04d04204e07506806306407405405205905505304c04607504b04104e06504504d04707a07106a04a06c07707604
    405606306804806f04904206e05107306d06206b05806600d00a02305a05104306605506204107a05606707407807104d06904906806505404804a04b04507304c04e06a0760
    7004605904f07206106c0713O417707305105703a03803b02e04302c052036727326726e26927427426527326f274275261506O20486404707705706e06b05006f0790520420
    6d05307505804406305406904305607206e05507604806604e06707705307306506b04407404605906407a04904705205004f04b07105a05104c06105707806a07504a06c00d
    00a05307406107207402d05007206f06306507307304607206f06d05305905302002d05406f06b06506e02005404902002d04306d06404c06906e06502002207006f07706507
    207306806506c06c02e06507806502002d06e06f07002002d06302002202202007407207902007b02421O128403402d07404704b02702f03904404a05506707003a040727326
    726e26927427426527326f274275261202O1223005b04d06906307206f07306f06607402e05706906e03303202e05206506706907307407207905d03a03a0530650740560610
    6c07506502802704804b04505905f04c04f04304104c05f04d04104304804904e04505c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e064
    06f07707302004e05405c04307507207206506e07405606507207306906f06e05c04906d06106706502004606906c06502004507806506307507406906f06e02004f07007406
    906f06e07305c713O417707305105703a03803b02e04302c052036727326726e26927427426527326f274275261506O204804d07004306d06405207506e02e06507806502702
    c02704406506207506706706507202702c02702405606106c07506502702c02705307407206906e06702702907d02006306107406306802007b07d02202202202002d04e06f0
    5706906e06406f07702002d05706106907400d00a02306a06f07a05604805707504106905806b06106206707204f06d04a04307304606e04e044059052042047076071066051
    06806c05506307804905405a05007006404d07704506505304b04c07407906f0500630460421O128403402d07404704b02702f03904404a05506707003a040727326726e2692
    7427426527326f274275261202O12235405107004407704105706204805804c04a05904504f04b06a06806405604e06707107a06606d05307607305a04307806e06904d06b00
    d00a02306905406e07505a06a04a04206c04e06307607705705104407305804b04806505606206704105004705204c04f04907906d07806b0590740530450660720640550700
    4d06f06804306107a07104605806705307706204e05907005a06407805104706f07a04605404206507404f06b05606107307104a04b06904404c05207204107606305505706c
    06713O417707305105703a03803b02e04302c052036727326726e26927427426527326f274275261506O2048d421O128403402d07404704b02702f03904404a05506707003a0
    4006202002b03104e04c02f06c05b02104003905805503206006a04504402405207a02906703402d07404704b02702f03904404a05506707003a04007305105703a03803b02'
    #endregion CheckPar

    Function Create-BS64 ([string]$File) {
        if ( -not ( $File )) { Return 0 }

        # res85 ascii encoder https://github.com/AveYo/Compressed2TXT | Modified for AutoSettingsPS
        [string] $DecoderBAT85 = @'
using System.IO;public class DecoderBAT85{public static void DecodeString (ref string f, string fo, string key){
unchecked{byte[] b85=new byte[256];long n=0;int p=0,q=0,c=255,z=f.Length;while (c>0) b85[c--]=85;while (c<85) b85[key[c]]=(byte)c++;
int[] p85={52200625,614125,7225,85,1};using (FileStream o=new FileStream(fo,FileMode.Create)){for (int i=0; i!=z; i++){
c=b85[f[i]];if (c==85) continue;n += c * p85[p++];if (p==5){p=0; q=4;while (q > 0){q--;o.WriteByte((byte)(n>>8*q));}
n=0;}}if (p>0){for (int i=0;i<5-p;i++){n += 84 * p85[p+i];}q=4;while (q > p-1){q--;o.WriteByte((byte)(n>>8*q));}}}}}}
'@
        if ( -not ( 'DecoderBAT85' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $DecoderBAT85 -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        [string] $BS64 = Get-Encoded-BS64
        try
        {
            [DecoderBAT85]::DecodeString( [ref] $BS64, $File, '~pGOPH48s;U1gVDX![6BM}m/.|QTz0@9ct2A3)WY]7$=qZ#uv&a^JxRjhor_SlIL{fCdeKN+n5-E,y?iFwk(b' )

            if ( [System.IO.File]::Exists($File) ) { return 1 } else { Return 0 }
        }
        catch { Return 0 }
    }

    Function Telemetry-Data-Collection-Disable {
        
        # Чтобы не собирала данные по отключению, и не адартировали защиту (уменьшить шансы) 
        Set-Svc -Do:$Act Set-Service -Name 'DiagTrack' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'diagnosticshub.standardcollector.service' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'InventorySvc' -StartupType Disabled -Status Stopped  # CompatTelRunner

        if ( $Act -eq 'Set' )
        {
            Stop-Service -Name PcaSvc -ErrorAction 0 -WarningAction 0  # CompatTelRunner
            Stop-Process -Name CompatTelRunner,diagtrackrunner -Force -ErrorAction 0 -WarningAction 0
        }

        [string[]] $tasks = '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
                            '\Microsoft\Windows\Application Experience\PcaPatchDbTask',
                            '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
                            '\Microsoft\Windows\Application Experience\SdbinstMergeDbTask',
                            '\Microsoft\Windows\Application Experience\StartupAppTask',
                            '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
                            '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'

        foreach ( $task in $tasks )
        {
            if ( -not ( Check-State-Task $task -Need Disabled -Return Bool ))
            {
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $task
                
                if ( $task -eq '\Microsoft\Windows\Application Experience\PcaPatchDbTask' )
                {
                    Set-TaskAccess -Do:$Act -TaskName $task -Access Lock
                }
            }
        }
    }

    if ( -not $NoHeader )
    {
        $text = if ( $L.s19 ) { $L.s19 } else { 'Настройка Защитника Windows' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s19_1 ) { $L.s19_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray
    }

    if ( $Act -ne 'Default' )
    {
        if ( $Option -eq 'DefenderDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s28_1 ) { $L.s28_1 } else { 'Проверка Полного Отключения Защитника Windows' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Полное Отключение Защитника Windows' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }

            if ( $Act -ne 'Check' )
            {
                if ( $isExistDef )
                {
                    # Добавление в исключения, добавляются исключения, которые еще не добавлены.
                    Add-Exclusion-ToDefender
                }
            }

            $text = if ( $L.s29 ) { $L.s29 } else { 'Отключение Защитника Windows' }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

            Telemetry-Data-Collection-Disable
            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Выключить плановое исправление" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableRoutinelyTakingAction' -Type DWord 1

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Разрешить запуск службы защиты от вредоносных программ с обычным приоритетом" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'AllowFastServiceStartup' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Разрешить постоянную работу службы защиты от вредоносных программ" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'ServiceKeepAlive' -Type DWord 0

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Выключить защиту в реальном времени" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Проверять все загруженные файлы и вложения" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableIOAVProtection' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableBehaviorMonitoring' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableOnAccessProtection' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableScanOnRealtimeEnable' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableScriptScanning' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для включения защиты в реальном времени" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableRealtimeMonitoring' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для включения контроля поведения" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableBehaviorMonitoring' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для проверки всех загруженных файлов и вложений" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableIOAVProtection' -Type DWord 0

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Настроить локальное переопределение для отправки отчетов в Microsoft MAPS" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'LocalSettingOverrideSpynetReporting' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Присоединиться к Microsoft MAPS" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'SpynetReporting' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Отправлять образцы файлов, если требуется дальнейший анализ" (Включена) (Никогда не отправлять)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 2
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Настройка функции "Блокировка при первом появлении"" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'DisableBlockAtFirstSeen' -Type DWord 1

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Включить проверку после обновления службы анализа безопасности" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'DisableScanOnUpdate' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Запускать обновление службы анализа безопасности при запуске" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'DisableUpdateOnStartupWithoutEngine' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Проверять наличие последней версии службы защиты от вирусов и программ-шпионов при запуске" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'UpdateOnStartUp' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'RealtimeSignatureDelivery' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'UpdateOnStartUp' -Type DWord 0

            # отключить отправку рапортов
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting' -Name 'DisableGenericRePorts' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableArchiveScanning' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableCatchupFullScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableCatchupQuickScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableRemovableDriveScanning' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableRestorePoint' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableScanningMappedNetworkDrivesForFullScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableScanningNetworkFiles' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'ScanOnlyIfIdle' -Type DWord 1

            if ( $Act -ne 'Check' )
            {
                # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
                # Применение ГП не в конце настройки, так как необходимо чтобы выключились службы и драйвера, чтобы был доступ к настройке служб и исключений.
                Set-LGP -ApplyGP

                Start-Sleep -Milliseconds 1000
            }

            [string] $Smart = '0';[int] $StateSAC = 0; # Если существует и не отключена Новая защита: Интеллектуальное управление приложениями (Smart App Control)
            try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Policy','VerifiedAndReputablePolicyState','0') } catch {}
            if ( -not $Smart ) { $Smart = '0' }; [int]::TryParse($Smart,[ref]$StateSAC) > $null
            if ( $StateSAC )
            {
                Write-Host

                # интеллектуальное управление приложениями | Smart App Control| (отключить, нужна перезагрузка!)
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy' -Name 'VerifiedAndReputablePolicyState' -Type DWord 0
            }

            Write-Host

            # Отключение и удаление логов
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/Operational' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/WHC' -Name 'Enabled' -Type DWord 0

            [int] $N = 0
            Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Defender*' } | ForEach-Object {

                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName

                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline

                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s20 ) { $L.s20 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

            Write-Host

            [int] $Count = 0

            # если есть раздел
            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger','000',$true) )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger' -Name 'Start' -Type DWord 0
                $Count++
            }
            
            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger','000',$true) )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger' -Name 'Start' -Type DWord 0
                $Count++
            }

            if ( $Count ) { Write-Host }

            # Удаление логов
            Token-Impersonate -Token TI
            Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\LogFiles\WMI","$env:SystemDrive\ProgramData\Microsoft\Diagnosis\ETLLogs\AutoLogger"  -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Defender*.etl*' } | ForEach-Object {

                $Count++
                if ( $Count -eq 1 ) { Write-Host }

                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                }
            }
            Token-Impersonate -Reset

            try
            {
                [string] $Tamper = '-'
                $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-')
                if ( -not $Tamper ) { $Tamper = '-' }
            }
            catch {}

            # Если существует Защитник
            if ( $isExistDef )
            {
                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check1)))}catch{} }

                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'Проверка Отключенных компонентов Защитника' }
                    Write-Host "`n   $text" -ForegroundColor DarkCyan
                }
                else
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { 'Отключение компонентов Защитника' }
                    Write-Host "`n   $text" -ForegroundColor DarkCyan
                }

                if ( $Act -eq 'Set' )
                {
                    Write-Host

                    # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1
                }

                ######## services ###################################################################################
                # Принудительная остановка некоторых служб и драйверов, в данном случае и не только,
                # может привести к синему экрану.
                #region services

                $text = if ( $L.s30 ) { $L.s30 } else { 'Отключение Служб' }
                Write-Host "`n   $text`:" -ForegroundColor DarkGray

                [string] $Smart = '0';[int] $StateSAC = 0; # Если существует и не отключена Новая защита: Интеллектуальное управление приложениями (Smart App Control)
                try { $Smart = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\CI\Policy','VerifiedAndReputablePolicyState','0') } catch {}
                if ( -not $Smart ) { $Smart = '0' }; [int]::TryParse($Smart,[ref]$StateSAC) > $null; [int] $wait = 0
                # Если нет или была отключена Новая защита: Интеллектуальное управление приложениями (Smart App Control) нужно отрубать, иначе без защитника все проги будут запускаться ооооооочень долго
                if ( -not $StateSAC )
                {
                    if (( $Act -eq 'Set' ) -and ( Set-OwnerAndAccess -Path 'WinDefend' -GetSDDL -Service ))
                    {
                        Write-Host "   wait (10 sec) ...`n" -ForegroundColor DarkGray # Важно, тут везде всё не просто так, и последовательность тоже.
                        Start-Sleep -Milliseconds 10000; $wait++
                    }
                    else { Write-Host }

                    Set-Svc-AccessDeny -ServiceName 'WinDefend' -Act $Act
                    Set-Svc-AccessDeny -ServiceName 'WdNisSvc'  -Act $Act
                    Set-Svc-AccessDeny -ServiceName 'Sense'     -Act $Act
                    Set-Svc-AccessDeny -ServiceName 'WdFilter'  -Act $Act # не дает настроить на версии 19045.3086, используется настройка на прямую, результат после перезагрузки
                    Set-Svc-AccessDeny -ServiceName 'WdBoot'    -Act $Act
                    Set-Svc-AccessDeny -ServiceName 'WdNisDrv'  -Act $Act
                    Set-Svc-AccessDeny -ServiceName 'MsSecFlt'  -Act $Act
                }

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check2)))}catch{}}

                Write-Host

                Set-Svc -Do:$Act Set-Service -Name 'WinDefend' -StartupType Disabled
                Set-Svc -Do:$Act Set-Service -Name 'WdNisSvc' -StartupType Disabled
                Set-Svc -Do:$Act Set-Service -Name 'Sense' -StartupType Disabled
                
                Set-Svc -Do:$Act Set-Service -Name 'webthreatdefsvc' -StartupType Disabled
                Set-Svc -Do:$Act Set-Service -Name 'webthreatdefusersvc' -StartupType Disabled

                $text = if ( $L.s31 ) { $L.s31 } else { 'Отключение Драйверов' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Drv -Do:$Act Set-Driver -Name 'WdFilter' -StartupType Disabled
                Set-Drv -Do:$Act Set-Driver -Name 'WdBoot' -StartupType Disabled
                Set-Drv -Do:$Act Set-Driver -Name 'WdNisDrv' -StartupType Disabled
                Set-Drv -Do:$Act Set-Driver -Name 'MsSecFlt' -StartupType Disabled
                
                Set-Drv -Do:$Act Set-Driver -Name 'wtd' -StartupType Disabled

                #endregion services
                ######## end services ####################################################################################

                Write-Host

                [int] $Count = 0

                if ( -not ( $Tamper -match '[-04]' ))
                {
                    $Count++
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Type DWord 0
                }

                if ( $Act -eq 'Set' )
                {
                    $Count++
                    # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1
                }

                if ( $Count ) { Write-Host }

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 1
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DpaDisabled' -Type DWord 1
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReporting' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'MAPSconcurrency' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReportingLocation' -Type MultiString 'https://0.0.0.0'

                $text = if ( $L.s25 ) { $L.s25 } else { 'Удаление из автозапуска Старых параметров, которые добавляет Защитник. Видимо баг' }
                Write-Host "`n   $text`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'WindowsDefender'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'WindowsDefender'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'WindowsDefender'

                $text = if ( $L.s26 ) { $L.s26 } else { 'Скрытие контекстного меню' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}' -Type String ''

                if ( $is64 )
                {
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}' -Type String ''
                }

                if ( $Act -eq 'Set' )
                {
                    $dll = "$env:SystemDrive\Program Files\Windows Defender\shellext.dll"
                    if ( [System.IO.File]::Exists($dll) )
                    {
                        Write-Host "`n   regsvr32.exe /u $dll /s" -ForegroundColor DarkGray
                        try { & regsvr32.exe /u "$dll" /s > $null } catch {}
                    }
                }

                # Проверка отключен ли главный драйвер защитника
                [bool] $Skip = $false ; [string] $V = ''
                try { $V = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WdFilter','Start','') } catch {}
                if ( $V -and -not ( $V -eq '4' )) { $Skip = $true }

                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление Задач' }
                Write-Host "`n   $text`:" -ForegroundColor DarkGray

                [int] $Count = 0

                # Отключение всех найденных в \Microsoft\Windows\Windows Defender\* задач, чтобы выполнялось, если они есть, так быстрее.
                Get-Task-FullPaths -LikeName '\Microsoft\Windows\Windows Defender\*' -CompareFullPath | ForEach-Object {
                    $Count++

                    if ( $Count -eq 1 ) { Write-Host }

                    if ( $Act -eq 'Set' -and $Skip )
                    {
                        Set-Tsk -Do:Check Unregister-ScheduledTask -TaskName $_
                    }
                    else
                    {
                        Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_
                    }
                }

                if ( -not $Count )
                {
                    $text = if ( $L.s23_1 ) { $L.s23_1 } else { 'Нет задач' }
                    Write-Host "    $text" -ForegroundColor DarkGray
                }

                #Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance'
                #Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup'
                #Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan'
                #Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Verification'

                $text = if ( $L.s32 ) { $L.s32 } else { 'Блокировка запуска' }
                Write-Host "`n   $text`: MpCmdRun.exe`n" -ForegroundColor DarkGray

                if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
                {
                    [string] $Value = $Matches.Debugger.Trim()
                }
                else { [string] $Value = 'dllhost.exe' }

                $Debugger = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe','Debugger','')

                if ( $Act -eq 'Set' -and $Skip )
                {
                    if ( $Debugger ) { $Value = $Debugger }
                    Set-Reg -Do:Check New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger' -Type String $Value
                }
                else
                {
                    if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check4)))}catch{} }
                    elseif ( $Debugger ) { $Value = $Debugger }

                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger' -Type String $Value
                }

                #
                #########################################################################################
                # Проверка Защиты от Подделки и предложение отключить ее вручную.

                <#
                if ( $Act -ne 'Check' )
                {
                    try
                    {
                        [string] $Tamper = '-'
                        $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-')
                        if ( -not $Tamper ) { $Tamper = '-' }
                    }
                    catch {}

                    if ( $Tamper -notmatch '[-04]' )
                    {
                        try { $AppxErr = $false ; $SecHealtName = (Get-AppxPackage -Name '*SecHealthUI*' -ErrorAction SilentlyContinue).Name }
                        catch { $AppxErr = $true ; $SecHealtName = $null }

                        if ( $AppxErr )
                        {
                            $text = if ( $L.s45_2 ) { $L.s45_2 } else { 'Отключена служба AppXSvc' }
                            Write-Host "`n   $text" -ForegroundColor Red
                        }
                        elseif ( -not $SecHealtName )
                        {
                            $text = if ( $L.s45 ) { $L.s45 } else { 'Защита не отключена, а системный App уже удалён: Microsoft.Windows.SecHealthUI/Microsoft.SecHealthUI' }
                            Write-Host "`n   $text" -ForegroundColor Yellow
                        }
                        else
                        {
                            if ((Check-State-Service -ServiceName SecurityHealthService -CheckStatus -Return Value) -ne 'Running' -or
                                (Check-State-Service -ServiceName WinDefend -CheckStatus -Return Value) -ne 'Running' -or
                                (Check-State-Driver  -DriverName  WdFilter  -CheckStatus -Return Value) -ne 'Running' )
                            {
                                Write-Host "`n   Not running: SecurityHealthService -or WinDefend -or WdFilter" -ForegroundColor DarkGray
                            }
                            else { Open-ThreatSettings }
                        }
                    }
                }
                #>

                # конец проверки защиты от подделки
                #########################################################################################
                #

                if ( $Act -eq 'Set' )
                {
                    Write-Host

                    # Повтор отключения, так как бывает при выполнении далее, после отключения, винда включает эти обратно,
                    # когда видит, что они были отключены. И не важно каким методом их отключать. началось после какого-то обновления
                    # или времени пройденном после последнего обновления или всё вместе, на LTSC .1397 уже включает.

                    Set-Svc -Do:$Act Set-Service -Name 'WinDefend' -StartupType Disabled
                    Set-Drv -Do:$Act Set-Driver -Name 'WdFilter' -StartupType Disabled
                    Set-Drv -Do:$Act Set-Driver -Name 'WdBoot' -StartupType Disabled
                }

                # Если нет или была отключена Новая защита: Интеллектуальное управление приложениями (Smart App Control) нужно отрубать, иначе без защитника все проги будут запускаться ооооооочень долго
                if ( -not $StateSAC )
                {
                    if (( $Act -eq 'Set') -and $wait )
                    {
                        Write-Host "`n   wait (5 sec) ...`n" -ForegroundColor DarkGray # Важно, тут везде всё не просто так, и последовательность тоже.
                        Start-Sleep -Milliseconds 5000
                    }

                    # Скрыть раздел защитника в безопасности, если служба защитника заблокирована дескриптором, так как после блокировки, его перезапускает сервис службы.
                    # защитник может восстанавить свои параметры, нужно подождать чтобы убедиться. Иначе настройки скроет и вручную не отключить, если метод перестанет работать, придется восстанавливать сначала.
                    if ( -not ( Set-OwnerAndAccess -Path 'WinDefend' -GetSDDL -Service ))
                    {
                        # Скрыть раздел управления защитником из центра безопасности:
                        # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Клиентский интерфейс\ "Включить режим пользовательского интерфейса без монитора" (Включена)
                        # Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\UX Configuration' -Name 'UILockdown' -Type DWord 1
                        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'UILockdown' -Type DWord 1
                        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'UILockdown' -Type DWord 1

                        Write-Host
                    }
                }

                # Повторная Проверка Защиты от Подделки.
                try
                {
                    [string] $Tamper = '-'
                    $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-')
                    if ( -not $Tamper ) { $Tamper = '-' }
                }
                catch {}

                if ( $Tamper -eq '-' )
                {
                    $text = if ( $L.s49 ) { $L.s49 } else { '''Защита от Подделки'' отсутствует' }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                elseif ( $Tamper -match '[04]' )
                {
                    $text = if ( $L.s51 ) { $L.s51 } else { '''Защита от Подделки'' отключена' }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                elseif ( $Tamper -match '[1235]' )
                {
                    $text = if ( $L.s52 ) { $L.s52 } else { '''Защита от Подделки'' не отключена' }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                else
                {
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White
                }
            }
            else
            {
                $text = if ( $L.s27 ) { $L.s27 } else { 'Нет Защитника Windows' }
                Write-Host "`n   $text " -ForegroundColor DarkGreen -NoNewline
            }
        }
        elseif ( $Option -eq 'AddExclusions' )
        {
            if ( $isExistDef )
            {
                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s34 ) { $L.s34 } else { 'Проверка Исключений' }
                    Write-Host "   $text`n" -ForegroundColor DarkCyan
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Защитника Windows не существует, пропуск добавления в исключения' }
                Write-Host "   $text`n" -ForegroundColor DarkGray

                Return
            }

            # Добавление в исключения, добавляются исключения, которые еще не добавлены.
            Add-Exclusion-ToDefender

            if ( $ApplyGP )
            {
                # Если запуск не из главных меню быстрых настроек (0 и 1)
                if ( -not $MenuConfigsQuickSettings )
                {
                    Get-Pause
                }
            }

            Return
        }
        elseif ( $Option -eq 'SecurityCenterDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s54 ) { $L.s54 } else { 'Проверка Отключения Центра Безопасности' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s55 ) { $L.s55 } else { 'Отключение Центра Безопасности' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }

            Token-Impersonate -Reset

            [bool] $Skip = $false ; [string] $V = ''
            try { $V = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WdFilter','Start','') } catch {}
            if ( $V -and -not ( $V -eq '4' )) { $Skip = $true }

            # Существует ли файл
            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\SecurityHealthSystray.exe") ) { [bool] $isExistExe = $true } else { [bool] $isExistExe = $false }

            # Если драйвер защитника не отключен, пропустить отключение центра безопасности, смысла нет его отключать и не будет доступа к настройкам, если что.
            if (( $Act -eq 'Set' ) -and $Skip )
            {
                $text = if ( $L.s55_1 ) { $L.s55_1 } else { 'Защитник не отключен, пропуск отключения Центра Безопасности' }
                Write-Host "`n   $text" -ForegroundColor DarkGray
            }
            else
            {
                Write-Host
                Telemetry-Data-Collection-Disable
                Write-Host

                Set-Svc -Do:$Act Set-Service -Name 'wscsvc' -StartupType Disabled
                Set-Svc -Do:$Act Set-Service -Name 'SgrmBroker' -StartupType Disabled
                Set-Drv -Do:$Act Set-Driver -Name 'SgrmAgent' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check3)))}catch{} }
                Set-Svc -Do:$Act Set-Service -Name 'SecurityHealthService' -StartupType Disabled
            
                if ( $Act -ne 'Check' )
                {
                    [int] $N = 0

                    while ( [System.Diagnostics.Process]::GetProcessesByName('SecurityHealthSystray').Count -and $N -lt 10 )
                    { $N++ ; try { & $env:SystemRoot\System32\taskkill.exe /t /im SecurityHealthSystray.exe *> $null } catch {} ; Start-Sleep -Milliseconds 10 }

                    if ( $N ) { Stop-Process -Name SecurityHealthSystray -Force -ErrorAction SilentlyContinue }
                }

                Write-Host
            
                Set-Svc-AccessDeny -ServiceName 'SecurityHealthService' -Act $Act
            
                Write-Host

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 0
        
                # Скрытие окна параметров из настроек.
                Set-SettingsPageVisibility -Act:$Act -Names 'windowsdefender'

                $text = if ( $L.s24 ) { $L.s24 } else { 'Удаление автозапуска' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'SecurityHealth'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'SecurityHealth'
                
                if ( $isExistExe )
                {
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'SecurityHealth' -Type ExpandString '%windir%\system32\SecurityHealthSystray.exe'
                }
            }
        }
        elseif ( $Option -eq 'SmartScreenDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s57 ) { $L.s57 } else { 'Проверка Отключения SmartScreen' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s58 ) { $L.s58 } else { 'Отключение SmartScreen' }
                Write-Host "   $text" -ForegroundColor DarkCyan
            }

            Write-Host
            Telemetry-Data-Collection-Disable
            Write-Host

            # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure Windows Defender SmartScreen : Disable
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Type DWord 0

            # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure app install control : Enable
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControlEnabled' -Type DWord 1

            # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure app install control : Enable
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControl' -Type String 'Anywhere'

            # Отключение SmartScreen для приложений и файлов
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled' -Type String 'Off'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled' -Type String 'Anywhere'

            # Отключение SmartScreen в IE
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\PhishingFilter' -Name 'EnabledV9' -Type DWord 0

            # Отключение SmartScreen для приложений Microsoft Store
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'PreventOverride' -Type DWord 0

            if ( Check-State-Registry -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe' -Return Bool )
            {
                # Отключение SmartScreen в Edge Классик
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride' -Type DWord 0
            }

            # Отключение SmartScreen в Microsoft Edge
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenEnabled' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenPuaEnabled' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverrideAppRepUnknown' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverrideAppRepUnknown' -Type DWord 0
            
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride' -Type DWord 0

            # Отключение SmartScreen Extended
            if ( [System.Environment]::OSVersion.Version.Build -ge 22621 )
            {
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'ServiceEnabled' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyUnsafeApp' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyMalicious' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyPasswordReuse' -Type DWord 0
            }

            # Удаление регистрации SmartScreen, чтобы служба DcomLaunch даже не пыталась его запускать, и он не сможет запускаться в принципе
            Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}'
            Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}'
            #   есть еще тут       HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}
            if ( $Act -eq 'Set' ) { Stop-Process -Name 'SmartScreen' -Force -ErrorAction SilentlyContinue }

            # SmartScreen
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Настроить Обнаружение потенциально нежелательных приложений" (Включено - выключение)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'PUAProtection' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_EdgeSmartScreenOff' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_StoreAppsSmartScreenOff' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_PuaSmartScreenOff' -Type DWord 1

            # Убирает вызов окна предупреждения (и SmartScreen, если он включен), когда у файла exe стоит метка Zone.Identifier (заблокирован)
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\open' -Name 'NoSmartScreen' -Type String ''
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\runas' -Name 'NoSmartScreen' -Type String ''
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\runasuser' -Name 'NoSmartScreen' -Type String ''

            # Скрыть раздел из центра безопасности:
            #Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\App and browser protection' -Name 'UILockdown' -Type DWord 1
        }
        elseif ( $Option -eq 'VBSDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Проверка Отключения ''Безопасность на основе виртуализации''' }
                Write-Host "   $text`n" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s21_1 ) { $L.s21_1 } else { 'Отключение ''Безопасность на основе виртуализации''' }
                Write-Host "   $text`n" -ForegroundColor DarkCyan
            }

            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'HypervisorEnforcedCodeIntegrity'
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'LsaCfgFlags'
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'RequirePlatformSecurityFeatures'
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'ConfigureSystemGuardLaunch'
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'ConfigureKernelShadowStacksLaunch'

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'HVCIMATRequired' -Type DWord 0

            Write-Host

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Device security' -Name 'UILockdown' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Device security' -Name 'UILockdown' -Type DWord 1

            Write-Host

            Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'WasEnabledBy'
            Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'WasEnabledBySysprep'

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'RequirePlatformSecurityFeatures' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'Locked' -Type DWord 0
            
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'HVCIMATRequired' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'Locked' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'AuditModeEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'WasEnabledBy' -Type DWord 4
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        if ( $Option -eq 'AddExclusions' )
        {
            $text = if ( $L.s35 ) { $L.s35 } else { 'Не предусмотрено удаление добавленных исключений Защитника Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray

            Return   # Выход
        }
        elseif ( $Option -eq 'DefenderDisable' )
        {
            $text = if ( $L.s36 ) { $L.s36 } else { 'Восстановление Защитника Windows (По умолчанию)' }
            Write-Host "   $text`:`n" -ForegroundColor Magenta

            Telemetry-Data-Collection-Disable
            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware'

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Выключить плановое исправление" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableRoutinelyTakingAction'

            # Если существует защитник
            if ( $isExistDef )
            {
                # Добавление в исключения, добавляются исключения, которые еще не добавлены.
                Add-Exclusion-ToDefender

                $text = if ( $L.s37 ) { $L.s37 } else { 'Включение Служб' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Svc Set-Service -Name 'WinDefend' -StartupType Automatic
                Set-Svc Set-Service -Name 'WdNisSvc' -StartupType Manual
                Set-Svc Set-Service -Name 'Sense' -StartupType Manual

                Set-Svc Set-Service -Name 'webthreatdefsvc' -StartupType Manual
                Set-Svc Set-Service -Name 'webthreatdefusersvc' -StartupType Automatic

                $text = if ( $L.s38 ) { $L.s38 } else { 'Включение Драйверов' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Drv Set-Driver -Name 'WdFilter' -StartupType Boot
                Set-Drv Set-Driver -Name 'WdBoot' -StartupType Boot
                Set-Drv Set-Driver -Name 'WdNisDrv' -StartupType Manual
                Set-Drv Set-Driver -Name 'MsSecFlt' -StartupType Boot
                
                Set-Drv Set-Driver -Name 'wtd' -StartupType Automatic

                Write-Host

                Set-Svc-AccessDeny -ServiceName 'WinDefend' -Act Default
                Set-Svc-AccessDeny -ServiceName 'WdNisSvc'  -Act Default
                Set-Svc-AccessDeny -ServiceName 'Sense'     -Act Default
                Set-Svc-AccessDeny -ServiceName 'WdFilter'  -Act Default
                Set-Svc-AccessDeny -ServiceName 'WdBoot'    -Act Default
                Set-Svc-AccessDeny -ServiceName 'WdNisDrv'  -Act Default
                Set-Svc-AccessDeny -ServiceName 'MsSecFlt'  -Act Default
                
                $text = if ( $L.s39 ) { $L.s39 } else { 'Включение Задач' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Verification'

                Write-Host

                try
                {
                    [string] $Tamper = '-'
                    $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-')
                    if ( -not $Tamper ) { $Tamper = '-' }
                }
                catch {}

                if ( -not ( $Tamper -eq '-' ))
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Type DWord 5
                }

                try { [int] $RealtimeMonitoring = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection','DisableRealtimeMonitoring',0) }
                catch { [int] $RealtimeMonitoring = 0 }

                if ( $RealtimeMonitoring -ne 0 )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 0
                }

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DpaDisabled' -Type DWord 0

                try { [int] $SpyNetReporting = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Spynet','SpyNetReporting',0) }
                catch { [int] $SpyNetReporting = 0 }

                if ( $SpyNetReporting -eq 0 )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReporting' -Type DWord 1
                }

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 1

                Write-Host

                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Quarantine'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Remediation'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\UX Configuration'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'

                Write-Host

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'UILockdown'
                Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'UILockdown'

                # Расширенные уведомления Защитника
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications'
                # Уведомления Защитника
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'FilesBlockedNotificationDisabled'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'NoActionNotificationDisabled'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'SummaryNotificationDisabled'

                Write-Host

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/Operational' -Name 'Enabled' -Type DWord 1
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/WHC' -Name 'Enabled' -Type DWord 1

                # если есть раздел
                if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger','000',$true) )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger' -Name 'Start' -Type DWord 1
                }

                if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger','000',$true) )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger' -Name 'Start' -Type DWord 1
                }

                Write-Host

                # Удаление блокировки запуска MpCmdRun.exe, который запускает служба wscsvc и настраивает им защитник.
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger'

                $text = if ( $L.s41 ) { $L.s41 } else { 'Восстановление Контекстного меню' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}'

                $dll = "$env:SystemDrive\Program Files\Windows Defender\shellext.dll"
                if ( [System.IO.File]::Exists($dll) )
                {
                    Write-Host "`n   regsvr32.exe $dll /s`n" -ForegroundColor DarkGray
                    try { & regsvr32.exe "$dll" /s > $null } catch {}
                }

                $text = if ( $L.s32_1 ) { $L.s32_1 } else { 'Снятие блокировки запуска' }
                Write-Host "`n   $text`: MpCmdRun.exe`n" -ForegroundColor DarkGray

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger'

                Write-Host

                # Восстановление Центра Безопасности, смысла нет восстанавливать только защитник без управления
                Set-Windows-Defender -Act Default -Option SecurityCenterDisable -NoHeader
            }
            else
            {
                $text = if ( $L.s43 ) { $L.s43 } else { 'Нет Защитника Windows' }
                Write-Host "`n   $text " -ForegroundColor DarkGreen -NoNewline

                $text = if ( $L.s43_1 ) { $L.s43_1 } else { 'Пропуск действий восстановления' }
                Write-Host "| $text`n" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'SecurityCenterDisable' )
        {
            $text = if ( $L.s53 ) { $L.s53 } else { 'Восстановление Центра Безопасности (По умолчанию)' }
            Write-Host "   $text`:`n" -ForegroundColor Magenta

            Telemetry-Data-Collection-Disable
            Write-Host

            Set-Svc Set-Service -Name 'wscsvc' -StartupType DelayedAuto
            Set-Svc Set-Service -Name 'SgrmBroker' -StartupType DelayedAuto
            Set-Drv Set-Driver -Name 'SgrmAgent' -StartupType Boot

            if ( -not ( Check-State-Service -ServiceName 'SecurityHealthService' -CheckExist -Return Bool ))
            {
                if ( [System.IO.File]::Exists("$env:SystemRoot\system32\SecurityHealthService.exe") )
                {
                    # Создание службы с оригинальными параметрами, если была удалена
                    [array]$CmdLine = 'cmd.exe /d /q /c chcp 65001>nul&sc create SecurityHealthService BinPath= %systemroot%\system32\SecurityHealthService.exe ',
                    'start= demand obj= LocalSystem depend= RpcSs DisplayName= @%systemroot%\system32\SecurityHealthAgent.dll,-1002',
                    '&&(sc description SecurityHealthService "@%systemroot%\system32\SecurityHealthAgent.dll,-1001"',
                    '& sc privs SecurityHealthService SeImpersonatePrivilege/SeBackupPrivilege/SeRestorePrivilege/SeDebugPrivilege/',
                    'SeChangeNotifyPrivilege/SeSecurityPrivilege/SeAssignPrimaryTokenPrivilege/SeTcbPrivilege/SeSystemEnvironmentPrivilege/SeShutdownPrivilege',
                    '& sc sidtype SecurityHealthService unrestricted & sc failure SecurityHealthService reset= 86400 actions= restart/60000/restart/60000/""/""',
                    '& reg add HKLM\SYSTEM\CurrentControlSet\Services\SecurityHealthService /v LaunchProtected /t REG_DWORD /d 2 /f)'

                    Start-ProcessFromSYS TI -CmdLine ($CmdLine -join '') -NoWindow -Wait -Milliseconds 3000
                }
            }

            Write-Host
            
            Set-Svc-AccessDeny -ServiceName 'SecurityHealthService' -Act Default

            Write-Host

            Set-Svc Set-Service -Name 'SecurityHealthService' -StartupType Manual

            Set-Reg Remove-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled'
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 1

            $text = if ( $L.s42 ) { $L.s42 } else { 'Удаление скрытия параметров защитника из настроек' }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

            # Удаление скрытия окна параметров из настроек.
            Set-SettingsPageVisibility -Names 'windowsdefender' -Remove

            $text = if ( $L.s40 ) { $L.s40 } else { 'Возврат автозапуска' }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

            # Если cуществует файл
            if ( [System.IO.File]::Exists("$env:SystemRoot\System32\SecurityHealthSystray.exe") )
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'SecurityHealth' -Type ExpandString '%windir%\system32\SecurityHealthSystray.exe'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'SecurityHealth'
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'SecurityHealth' -Type Binary 0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0
            }

            $text = if ( $L.s25 ) { $L.s25 } else { 'Удаление из автозапуска Старых параметров, которые добавляет Защитник. Видимо баг' }
            Write-Host "`n   $text`n" -ForegroundColor DarkGray

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'WindowsDefender'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'WindowsDefender'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'WindowsDefender'
        }
        elseif ( $Option -eq 'SmartScreenDisable' )
        {
            $text = if ( $L.s56 ) { $L.s56 } else { 'Восстановление SmartScreen (По умолчанию)' }
            Write-Host "   $text`:`n" -ForegroundColor Magenta

            Telemetry-Data-Collection-Disable
            Write-Host

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControlEnabled'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControl'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\PhishingFilter' -Name 'EnabledV9'

            Set-Reg New-ItemProperty    -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 1
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'PreventOverride'

            Set-LGP Remove-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverrideAppRepUnknown'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverrideAppRepUnknown'

            Set-LGP Remove-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride'

            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenEnabled'
            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenPuaEnabled'

            Set-LGP Remove-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'ServiceEnabled' -Type DWord 0
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyUnsafeApp'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyMalicious'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WTDS\Components' -Name 'NotifyPasswordReuse'

            # Регистрация SmartScreen
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -Name '' -Type String 'SmartScreen'
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -Name 'AppID' -Type String '{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}'

            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\InProcServer32' -Name '' -Type String "$env:SystemDrive\Windows\System32\smartscreenps.dll"
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\InProcServer32' -Name 'ThreadingModel' -Type String 'Both'

            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\LocalServer32' -Name '' -Type String "$env:SystemDrive\Windows\System32\smartscreen.exe"

            [string] $Sddl = 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI
                (A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                (A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                (A;;KR;;;SY)(A;CIIO;GR;;;SY)(A;;KR;;;BA)(A;CIIO;GR;;;BA)(A;;KR;;;BU)(A;CIIO;GR;;;BU)(A;;KR;;;AC)(A;CIIO;GR;;;AC)
                (A;;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)
                (A;CIIO;GR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)S:AINO_ACCESS_CONTROL'

            Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Classes\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -RecoverySDDL $Sddl -WithSacl

            if ( $is64 )
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -Name '' -Type String 'SmartScreen'
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -Name 'AppID' -Type String '{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}'

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\InProcServer32' -Name '' -Type String "$env:SystemDrive\Windows\System32\smartscreenps.dll"
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\InProcServer32' -Name 'ThreadingModel' -Type String 'Both'

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}\LocalServer32' -Name '' -Type String "$env:SystemDrive\Windows\System32\smartscreen.exe"
            
                Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Classes\WOW6432Node\CLSID\{a463fcb9-6b1c-4e0d-a80b-a2ca7999e25d}' -RecoverySDDL $Sddl -WithSacl
            }

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Настроить Обнаружение потенциально нежелательных приложений" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'PUAProtection'
            
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_EdgeSmartScreenOff'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_StoreAppsSmartScreenOff'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows Security Health\State' -Name 'AppAndBrowser_PuaSmartScreenOff'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\open' -Name 'NoSmartScreen'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\runas' -Name 'NoSmartScreen'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\exefile\shell\runasuser' -Name 'NoSmartScreen'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\App and browser protection' -Name 'UILockdown'
        }
        elseif ( $Option -eq 'VBSDisable' )
        {
            $text = if ( $L.s21_2 ) { $L.s21_2 } else { 'Восстановление ''Безопасность на основе виртуализации'' (По умолчанию)' }
            Write-Host "   $text`: `n" -ForegroundColor Magenta

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'HypervisorEnforcedCodeIntegrity'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'LsaCfgFlags'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'RequirePlatformSecurityFeatures'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'ConfigureSystemGuardLaunch'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'ConfigureKernelShadowStacksLaunch'

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceGuard' -Name 'HVCIMATRequired'

            Write-Host

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Device security' -Name 'UILockdown'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Device security' -Name 'UILockdown'

            Write-Host

            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'WasEnabledBy'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'WasEnabledBySysprep'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'EnableVirtualizationBasedSecurity'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'RequirePlatformSecurityFeatures'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard' -Name 'Locked'
            
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'Enabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'HVCIMATRequired'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name 'Locked'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'Enabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'AuditModeEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\DeviceGuard\Scenarios\KernelShadowStacks' -Name 'WasEnabledBy'
        }
    }

    if ( $ApplyGP )
    {
        if ( -not ( $Option -eq 'TaskUpdateDefender' ))
        {
            # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
            Set-LGP -ApplyGP

            $text = if ( $L.s44 ) { $L.s44 } else { 'Необходимо перезагрузиться!' }
            Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen
        }

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings )
        {
            Get-Pause
        }
    }
}
