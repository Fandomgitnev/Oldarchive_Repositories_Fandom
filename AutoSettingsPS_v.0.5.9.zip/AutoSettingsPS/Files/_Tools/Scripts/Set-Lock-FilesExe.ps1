﻿
<#
.SYNOPSIS
 Установка запрета запуска EXE файлов, указанных в пресете.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Lock_FilesExe.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра.
 Используется функция Write-HostColor для раскраски вывода.
 Используется функция Get-List-Presets

.EXAMPLE
    Set-Lock-FilesExe -Option 'LockFiles' -Act Set

    Описание
    --------
    Установить запреты запуска EXE файлов, указанных в файле пресетов.

.EXAMPLE
    Set-Lock-FilesExe -Act Default

    Описание
    --------
    Удалить все запреты запуска EXE файлов


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  21-05-2019
 ===============================================

#>
Function Set-Lock-FilesExe {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'LockFiles', 'LockFilesWithShow' )]
        [string] $Option = 'LockFiles'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set'  )]
        [switch] $AlsoNotInPreset
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set'  )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Select' )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ShowList', 'LockedCount', 'PresetDebuggerCmd' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
    {
        [string] $DebuggerCmd = $Matches.Debugger.Trim()
    }
    else { [string] $DebuggerCmd = 'dllhost.exe' }

    if ( $CheckState -eq 'PresetDebuggerCmd' )
    {
        Return "#Blue#$DebuggerCmd#"
    }

    [array] $PresetExe = @()

    # Получаем список файлов exe для блокировки из файла пресетов. И заполняем таблицу $AllExeFiles.
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Set-Lock-FileExe-Name\s*=\s*1\s*=' ))
    {
        # Берем заданный путь в пресете для указанного файла, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match "^\s*Set-Lock-FileExe-Name\s*=\s*1\s*=\s*(?<FileName>[^$([regex]::Escape([System.IO.Path]::InvalidPathChars))?``#'=*\\/:]+[.]exe\s*)=((?<Note>[^#\n\r]+)=)?" )
        {
            [string] $FileName = $Matches.FileName.Trim()

            try { [string] $FileNote = $Matches.Note.Trim() } catch { [string] $FileNote = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }
            if ( -not $FileNote ) { [string] $FileNote = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }

            $PresetExe += [PSCustomObject] @{
                FileName = $FileName
                FileNote = $FileNote
                Locked   = $false
                Preset   = $true
            }
        }
    }

    [array] $ExeLocked = @()

    [string] $LockSubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'

    try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($LockSubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
    catch { [psobject] $OpenSubkey = $null }

    if ( $OpenSubkey )
    {
        foreach ( $ExeFile in ($OpenSubkey.GetSubKeyNames() -like '*.exe' ) )
        {
            try { [psobject] $Openkey = $OpenSubkey.OpenSubKey($ExeFile,'ReadSubTree','QueryValues') }
            catch { [psobject] $Openkey = $null }

            if ( $Openkey )
            {
                $Debugger = $Openkey.GetValue('Debugger',$null)

                if ( $Debugger -like '?*' )
                {
                    $ExeLocked += [PSCustomObject] @{
                        ExeFile  = $ExeFile
                        Debugger = $Debugger
                    }
                }

                $Openkey.Close()
            }
        }

        $OpenSubkey.Close()
    }

    foreach ( $Exe in $ExeLocked )
    {
        if ( $PresetExe.FileName -like $Exe.ExeFile )
        {
            $PresetExe.Where({$_.FileName -eq $Exe.ExeFile}) | Add-Member -Force -NotePropertyMembers @{
                Locked   = $true
                Debugger = $Exe.Debugger
            }
        }
        else
        {
            $PresetExe += [PSCustomObject] @{ FileName = $Exe.ExeFile ; FileNote = '' ; Locked = $true ; Preset = $false ; Debugger = $Exe.Debugger }
        }
    }

    [hashtable] $AllExeFiles = @{}

    [int] $Number = 0
    foreach ( $Item in ( $PresetExe | Sort-Object -Property FileName -Unique ))
    {
        $Number++
        $AllExeFiles[$Number] = @{}
        $AllExeFiles[$Number]['FileName'] = $Item.FileName
        $AllExeFiles[$Number]['FileNote'] = $Item.FileNote
        $AllExeFiles[$Number]['Locked']   = $Item.Locked
        $AllExeFiles[$Number]['Preset']   = $Item.Preset
        $AllExeFiles[$Number]['Debugger'] = $Item.Debugger
    }

    if ( $CheckState -eq 'LockedCount' )
    {
        [int64] $LockedCount = @(@($AllExeFiles.Values.Locked).Where({$_ -eq $true})).Count

        if ( -not $LockedCount ) { '#DarkYellow#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Нет блокировок' }) }
        else { "#Green#$LockedCount#" }

        Return
    }

    # Не выводить заголовок, если проверка параметров в пресете или предлагается выбор
    if ( -not $CheckState -and -not $Select )
    {
        $text = if ( $L.s3 ) { $L.s3 } else { 'Запрет запуска EXE файлов' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s3_1 ) { $L.s3_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Act -eq 'Default' )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'Разблокировка (По умолчанию)' }
            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

            if ( $AlsoNotInPreset ) { Write-Host "/All" -ForegroundColor DarkGray } else { Write-Host }
        }
        elseif ( $Act -eq 'Check' )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { 'Проверка запретов' }
            Write-Host "   $text" -ForegroundColor DarkCyan
        }
        else
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Установка запретов' }
            Write-Host "   $text" -ForegroundColor Green
        }
    }

    [int] $NameLenght = 0
    [int] $Lenght = 0
    foreach ( $F in $PresetExe.FileName )
    {
        $NameLenght = $F.Length
        if ( $Lenght -lt $NameLenght ) { $Lenght = $NameLenght }
    }

    if ( $CheckState ) { [int] $Indent = 8 } else { [int] $Indent = 4 ; $Lenght = 0 }

    # Если указана необходимость выбрать нужные параметры.
    if ( $Select -and $AllExeFiles.Count )
    {
        # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
          [char] $Escape          = 27
           [int] $StringsExcl     = 3              # Количество последних строк для затирания.
        [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
        [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

        Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline

        if ( $Act -eq 'Default' ) { $text = if ( $L.s7 ) { $L.s7 } else { 'Введите номера через пробел и/или диапазон через дефис (убрать запрет)' } }
        else                      { $text = if ( $L.s8 ) { $L.s8 } else { 'Введите номера через пробел и/или диапазон через дефис (заблокировать)' } }

        Write-Host "   $text"

        $text = if ( $L.s8_1 ) { $L.s8_1 } else { 'Номера' }

        # Ждем ввода пользователя.
        [string] $Choice = Read-Host -Prompt "   $text"

        [Uint16[]] $SelectedParams = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел и
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedParams, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            [array] $arr = @()

            # Добавление групп указанных через дефис
            foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

            $arr | ForEach-Object {

                try
                {
                    [Uint16] $ParamNumber = $_

                    if (( $ParamNumber -gt 0 ) -and ( $ParamNumber -le $AllExeFiles.Count ) -and ( $SelectedParams -notcontains $ParamNumber ))
                    { [Uint16[]] $SelectedParams += $ParamNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedParams )
        {
            $text = if ( $L.s9 ) { $L.s9 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s10 ) { $L.s10 } else { 'Выбранные номера' }
        Write-HostColor "`n      $text`: #DarkGray#[ #White#$SelectedParams #DarkGray#]#"
    }

    [string] $LockPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'

    [bool] $Skip = $false

    # Выводим информацию и/или выполняем действие по всему списку
    foreach ( $Number in $AllExeFiles.Keys | Sort-Object )
    {
        if ( $Select -and ( -not ( $SelectedParams -like $Number ) )) { Continue }  # Пропуск не выбранных номеров, если был выбор

        $FileName = $AllExeFiles[$Number]['FileName']
        $FileNote = $AllExeFiles[$Number]['FileNote']
        $Debugger = $AllExeFiles[$Number]['Debugger']

        if ( $FileNote ) { $ShowFileNote = " #DarkGray#| $FileNote" } else { $ShowFileNote = '' }
        if ( $Debugger ) { $ShowDebugger = " #DarkGray#| Debugger: $Debugger" } else { $ShowDebugger = '' }

        $Status = '○' ; $Color = 'Red' ; $ColorName = 'Gray'

        if ( $AllExeFiles[$Number]['Locked'] ) { $Status = '●' ; $Color = 'Green' }

        $Skip = $false

        if ( -not $AllExeFiles[$Number]['Preset'] )
        {
            $ColorName = 'DarkCyan'
            $ShowFileNote = " #DarkGray#| #DarkCyan#{0}" -f $(if ( $L.s11 ) { $L.s11 } else { 'Нет в пресете' })

            if ( -not $AlsoNotInPreset ) { $Skip = $true }
        }

        # Обрезка команды $Debugger и добавление в конце "...", если она присутствует и общая длина вывода превышает 285 символов. Чтобы при выводе в консоли не перебегала на новую строку.
        [int] $MaxLength = 285
        [int] $ResultLength = "$($FileName.ToString().PadRight($Lenght,' ')) | $FileNote | Debugger: $Debugger".Length

        if ( $Debugger -and $ResultLength -gt $MaxLength )
        {
            [int] $DebuggerLength = "$Debugger".Length

            [int] $PadRight = $DebuggerLength - ( $ResultLength - $MaxLength )

            if ( $PadRight -gt 0 ) { $Debugger = "{0}..." -f $Debugger.PadRight($PadRight,' ').Substring(0,$PadRight) }

            [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #$ColorName#{2}$ShowFileNote #DarkGray#| Debugger: {3}#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $FileName.ToString().PadRight($Lenght,' '),
                $Debugger
        }
        else
        {
            [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #$ColorName#{2}$ShowFileNote$ShowDebugger#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $Status,
                $FileName.ToString().PadRight($Lenght,' ')
        }

        if ( -not $CheckState ) { Write-Host }

        Write-HostColor $ResultShow

        if ( $CheckState -or $Skip ) { Continue }

        [string] $Path  = "$LockPath\$FileName"

        if ( $Act -ne 'Default' )
        {
            [string] $Value = $DebuggerCmd

            if ( $Option -eq 'LockFilesWithShow' )
            {
                # Этот метод отображаются и при запуске скрытых процессов
                $Value = 'mshta.exe vbscript:createobject("wscript.shell").Popup("{0}  |  {1}",6,"AutoSettingsPS",64)(close)' -f
                   $FileName,
                   $(if ( $L.s12 ) { $L.s12 } else { 'Запуск заблокирован!' })
            }

            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'Debugger' -Type String $Value
        }
        else
        {
            Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
        }
    }

    if ( -not $AllExeFiles.Count )
    {
        if ( -not $CheckState ) { Write-Host }

        $text = if ( $L.s13 ) { $L.s13 } else { 'Нет заблокированных и указаных EXE в файле пресетов' }
        Write-Host "        $text" -ForegroundColor DarkYellow
    }

    if ( -not $CheckState )
    {
        $text = if ( $L.s14 ) { $L.s14 } else { 'Завершено' }
        Write-Host "`n   $text" -ForegroundColor Green
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1) и не вывод состояния для меню
    if ( -not $MenuConfigsQuickSettings -and -not $CheckState )
    {
        Get-Pause
    }
}
