﻿
<#
.SYNOPSIS
 Сохранение и установка драйверов из папки

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Используется функция Write-HostColor, для вывода информации.


.EXAMPLE
    BackUp-Install-Drivers -DriversFolder D:\DriverBackup -BackUp

    Описание
    --------
    Сохранить драйвера

.EXAMPLE
    BackUp-Install-Drivers -DriversFolder D:\DriverBackup -Install

    Описание
    --------
    Установить драйвера из папки

.EXAMPLE
    BackUp-Install-Drivers -DriversFolder D:\DriverBackup -ShowDrivers

    Описание
    --------
    Показать сохранённые драйвера в папке

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  03.07.2020
 ===============================================

#>
Function BackUp-Install-Drivers {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 0 )]
        [string] $DriversFolder = $DriversFolderGlobal
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'ShowBackUp' )]
        [switch] $ShowDrivers   # Вывести список сохраненных драйверов.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'BackUp' )]
        [switch] $BackUp        # Выполнить сохранение.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Install' )]
        [switch] $Install       # Выполнить установку.
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $ShowDrivers )
    {
        [array] $Drivers = @()
        (Get-ChildItem -File -LiteralPath $DriversFolder -Recurse -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like '*.inf' }).ForEach({
            try
            {
                $DR = Get-WindowsDriver -Driver $_.fullName -Online -ErrorAction SilentlyContinue
                $DR | Add-Member -Force -NotePropertyMembers @{ NameFolder = $_.Directory.Name }

                $Drivers += $DR
            }
            catch {}
        })

        if ( $Drivers.Count )
        {
            $Drivers = $Drivers | Select-Object ClassName, ProviderName, Date, Version, NameFolder, DriverSignature, BootCritical -Unique | Sort-Object ClassName, Version

            [int] $N = 1

            for ( $i = 0 ; $i -lt $Drivers.Count ; $i++ )
            {
                $text = '#DarkGray#{0,5}. #Green#{1} #DarkGray#|# {2} #DarkGray#|# {3} #DarkGray#|# {4} #DarkGray#| {5} | Boot: {6} | {7}#' -f
                    $N,
                    $Drivers.Get($i).ClassName.ToString().PadRight(12,' ').Substring(0,12),
                    $Drivers.Get($i).ProviderName.ToString().PadRight(14,' ').Substring(0,14),
                    $Drivers.Get($i).Date.ToShortDateString().PadRight(10,' ').Substring(0,10),
                    $Drivers.Get($i).Version.ToString().PadRight(15,' '),
                    $Drivers.Get($i).DriverSignature.ToString().PadRight(8,' '),
                    $Drivers.Get($i).BootCritical.ToString().PadRight(5,' '),
                    $Drivers.Get($i).NameFolder

                Write-HostColor $text
                $N++
            }
        }
        else
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Нет сохранённых драйверов в' }
            Write-Host "         $text " -ForegroundColor Yellow -NoNewline
            Write-Host '| ' -ForegroundColor DarkGray -NoNewline
            Write-Host "$DriversFolder" -ForegroundColor White
        }
    }
    elseif ( $BackUp )
    {
        $text = if ( $L.s2 ) { $L.s2 } else { 'Сохранение драйверов' }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        $text = if ( $L.s3 ) { $L.s3 } else { 'В папку' }
        Write-Host "`n   $text`: $DriversFolder" -ForegroundColor DarkGray


        if ( -not [System.IO.Directory]::Exists($DriversFolder) )
        {
            try { New-Item -ItemType Directory -Path $DriversFolder -Force -ErrorAction Stop > $null }
            catch
            {
                $text = if ( $L.s4 ) { $L.s4 } else { 'Ошибка при создании папки' }
                Write-Warning "$text`: '$DriversFolder'`n`t$($_.exception.Message)"

                Get-Pause ; Return
            }
        }

        #Export-WindowsDriver -Online -Destination $DriversFolder -ErrorAction Continue > $null # Баг W11
        dism.exe /online /export-driver /destination:"$DriversFolder" > $null

        $text = if ( $L.s5 ) { $L.s5 } else { 'Выполнено' }
        Write-Host "`n   $text" -ForegroundColor Green

        Get-Pause
    }
    elseif ( $Install )
    {
        $text = if ( $L.s6 ) { $L.s6 } else { 'Добавление драйверов в хранилище и установка' }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s6_1 ) { $L.s6_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        $text = if ( $L.s7 ) { $L.s7 } else { 'Из папки' }
        Write-Host "`n   $text`: $DriversFolder`n" -ForegroundColor DarkGray

        [int] $N = 0

        (Get-ChildItem -File -LiteralPath $DriversFolder -Recurse -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like '*.inf' }).fullName.ForEach({

            $N++

            $text = if ( $L.s8 ) { $L.s8 } else { 'Установка' }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$_" -ForegroundColor White

            # Добавление драйверов в хранилище и установка
            pnputil.exe -i -a "$_" > $null
        })

        if ( -not $N )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Нет сохранённых драйверов в' }
            Write-Host "`n   $text " -ForegroundColor Yellow -NoNewline
            Write-Host '| ' -ForegroundColor DarkGray -NoNewline
            Write-Host "$DriversFolder" -ForegroundColor White
        }

        $text = if ( $L.s5 ) { $L.s5 } else { 'Выполнено' }
        Write-Host "`n   $text" -ForegroundColor Green

        Get-Pause
    }
}
