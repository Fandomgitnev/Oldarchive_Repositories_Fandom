﻿
# Группы параметров, относящиеся к Проводнику или Оформлению.
Function Set-Configs-Explorer {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [PSCustomObject] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem
    if ( -not $Groups.Length ) { Write-Host "`n   $($Lang.$NameThisFunction.s0)" -ForegroundColor DarkGray }

    # Далее сами настройки ...



    $Info = 'Включить Отображение скрытых файлов, папок и дисков'
    $Group = 'Expl-HiddenFiles' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'Hidden' -Type DWord 1

    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'Hidden' -Type DWord 2
    }



    $Info = 'Включить Отображение защищённых системных файлов и папок'
    $Group = 'Expl-SuperHiddenFiles' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowSuperHidden' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowSuperHidden' -Type DWord 0
    }



    $Info = 'Включить Отображение расширений имён файлов'
    $Group = 'Expl-FileExtensions' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'HideFileExt' -Type DWord 0

    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'HideFileExt' -Type DWord 1
    }



    $Info = 'Скрыть Опции Bitlocker'
    $Group = 'Expl-Bitlocker' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        'Скрыть опции Bitlocker из ПКМ меню и проводника'       | Show-Info -Shift $L.s2 -NotIndent
        'Управлять будет можно только через панель управления:' | Show-Info -Shift $L.s2_1 -NotIndent

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\change-passphrase' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\change-pin' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\encrypt-bde-elev' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\encrypt-bde' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\manage-bde' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\resume-bde-elev' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\resume-bde' -Name 'LegacyDisable' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\unlock-bde' -Name 'LegacyDisable' -Type String ''
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\change-passphrase' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\change-pin' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\encrypt-bde-elev' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\encrypt-bde' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\manage-bde' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\resume-bde-elev' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\resume-bde' -Name 'LegacyDisable'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Drive\shell\unlock-bde' -Name 'LegacyDisable'
    }



    $Info = 'Скрыть пункты 3D Print и 3D Edit из Контекстного меню'
    $Group = 'Expl-3DPrintEdit' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Classes\SystemFileAssociations','ReadSubTree','QueryValues,EnumerateSubKeys')

        [int] $CountName = 0

        if ( $OpenSubkey )
        {
            [string[]] $SubKeyNames = $null
            [string] $Path = $null

            foreach ( $Subkey in $OpenSubkey.GetSubKeyNames() )
            {
                $SubKeyNames = $null

                try
                {
                    $OpenKey = $OpenSubkey.OpenSubKey("$Subkey\Shell",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $SubKeyNames = $OpenKey.GetSubKeyNames()
                    $OpenKey.Close()
                }
                catch {}

                foreach ( $SubKeyName in $SubKeyNames )
                {
                    if ( $SubKeyName -like '*3D*' )
                    {
                         $Path = "HKLM:\SOFTWARE\Classes\SystemFileAssociations\$Subkey\Shell\$SubKeyName"
                         Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly' -Type String ''

                         $CountName++
                    }
                }
            }

            $OpenSubkey.Close()
        }

        if ( -not $CountName )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Нет пунтков 3D Print и 3D Edit в контекстном меню' }
            Write-Host "       $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        '3mf','bmp','fbx','gif','glb','jfif','jpe','jpeg','jpg','obj','ply','png','stl','tif','tiff' | ForEach-Object {

            $Path = "HKLM:\SOFTWARE\Classes\SystemFileAssociations\.$_\Shell\3D Edit"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String '@%SystemRoot%\system32\mspaint.exe,-59500'
            Set-Reg Remove-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly'

            $Path = "HKLM:\SOFTWARE\Classes\SystemFileAssociations\.$_\Shell\3D Edit\Command"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type ExpandString '%SystemRoot%\system32\mspaint.exe "%1" /ForceBootstrapPaint3D'
        }

        '3ds','3mf','dae','dxf','obj','ply','stl','wrl' | ForEach-Object {

            $Path = "HKLM:\SOFTWARE\Classes\SystemFileAssociations\.$_\Shell\3D Print"
            Set-Reg New-ItemProperty -Path $Path -Name '' -Type String '@%SystemRoot%\system32\PrintDialogs3D.dll,-5039'
            Set-Reg Remove-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly'

            $Path = "HKLM:\SOFTWARE\Classes\SystemFileAssociations\.$_\Shell\3D Print\Command"
            Set-Reg New-ItemProperty -Path $Path -Name 'DelegateExecute' -Type String '{1A68CF90-753A-4523-A4A4-40CAB4BC6EFF}'
        }
    }



    $Info = 'Удалить из контекстного меню ''Отправить'' дубликаты пункта Получатель факса'
    $Group = 'Expl-SendToFaxDuplicate' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [array] $Profiles = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\SendTo"

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
                $Profiles += "$($_.Profile)\AppData\Roaming\Microsoft\Windows\SendTo"
            })
        }

        [int] $N = 0
        Get-ChildItem -File -LiteralPath $Profiles -Recurse -ErrorAction SilentlyContinue | ForEach-Object {

            if ( $_.Name -like '*.lnk' -and -not ( $_.Name -like 'Fax Recipient.lnk' ))
            {
                if ( (Get-Content -LiteralPath $_.FullName -Force -Encoding UTF8 -ErrorAction SilentlyContinue) -like '*wfs.exe*' )
                {
                    $N++

                    # Удаление всех дубликатов: Получатель факса (любой локализации)
                    $text = if ( $L.s2 ) { $L.s2 } else { 'Удаление' }

                    if ( $Act -eq 'Check' )
                    {
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$($_.Name)" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                    else
                    {
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$($_.Name)" -ForegroundColor DarkGray

                        Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                    }
                }
            }
        }

        if ( $N -eq 0 )
        {
            $text = if ( $L.s3 ) { $L.s3 } else { 'Нет дубликата' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Удалить из контекстного меню ''Отправить'' пункты: Адресат, Документы, Получатель факса'
    $Group = 'Expl-SendToItems' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [array] $Profiles = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\SendTo"

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
                $Profiles += "$($_.Profile)\AppData\Roaming\Microsoft\Windows\SendTo"
            })
        }

        Get-ChildItem -File -LiteralPath $Profiles -ErrorAction SilentlyContinue | ForEach-Object {

            $text = if ( $L.s2 ) { $L.s2 } else { 'Удаление' }

            if ( $_.Name -like '*.lnk' )
            {
                if ( (Get-Content -LiteralPath $_.FullName -Force -Encoding UTF8 -ErrorAction SilentlyContinue) -like '*wfs.exe*' )
                {
                    if ( $Act -eq 'Check' )
                    {
                        # Удаление всех ярлыков: получатель факса (любой локализации)
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$($_.Name)" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                    else
                    {
                        # Удаление всех ярлыков: получатель факса (любой локализации)
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$($_.Name)" -ForegroundColor DarkGray

                        Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                    }
                }
            }
            elseif ( $_.Name -like '*.MAPIMail' )
            {
                if ( $Act -eq 'Check' )
                {
                    # Удаление всех ярлыков: адресат (Mail)
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$($_.Name)" -ForegroundColor Yellow

                    $NeedFix = $true
                }
                else
                {
                    # Удаление всех ярлыков: адресат (Mail)
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$($_.Name)" -ForegroundColor DarkGray

                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
            }
            elseif ( $_.Name -like '*.mydocs' )
            {
                if ( $Act -eq 'Check' )
                {
                    # Удаление всех ярлыков: Документы
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$($_.Name)" -ForegroundColor Yellow

                    $NeedFix = $true
                }
                else
                {
                    # Удаление всех ярлыков: Документы
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$($_.Name)" -ForegroundColor DarkGray

                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        [array] $Profiles = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\SendTo"

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
                $Profiles += "$($_.Profile)\AppData\Roaming\Microsoft\Windows\SendTo"
            })
        }

        foreach ( $Profile in $Profiles )
        {
            $GetShortcats = Get-ChildItem -File -LiteralPath $Profile -ErrorAction SilentlyContinue

            $text = if ( $L.s3 ) { $L.s3 } else { 'Восстановление' }

            if ( -not ( $GetShortcats.Name -like 'Mail Recipient.MAPIMail' ))
            {
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host 'Mail Recipient.MAPIMail' -ForegroundColor DarkGray

                [System.IO.File]::WriteAllLines("$Profile\Mail Recipient.MAPIMail",'Mail')
            }

            if ( -not ( $GetShortcats.Name -like '*.mydocs' ))
            {
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host 'Documents.mydocs' -ForegroundColor DarkGray

                [System.IO.File]::WriteAllLines("$Profile\Documents.mydocs",'')
            }

            if ( -not ( $GetShortcats.Name -like 'Fax Recipient.lnk' ))
            {
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host 'Fax Recipient.lnk' -ForegroundColor DarkGray

                try
                {
                    $WScriptShell = New-Object -ComObject WScript.Shell
                    $Shortcut = $WScriptShell.CreateShortcut("$Profile\Fax Recipient.lnk")
                    $Shortcut.TargetPath   = '%windir%\system32\WFS.exe'
                    $Shortcut.Arguments    = '/SendTo'
                    $shortcut.IconLocation = '%windir%\system32\WFSR.dll,0'
                    $Shortcut.Description  = 'Fax'
                    $Shortcut.Save()
                }
                catch{}
            }
        }
    }



    $Info = 'Удалить из контекстного меню ''Создать'' пункт: ''Точечный рисунок'''
    $Group = 'Expl-NewItems-BMP' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\.bmp\ShellNew'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.bmp\ShellNew' -Name 'ItemName' -Type ExpandString '@%systemroot%\system32\mspaint.exe,-59414'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.bmp\ShellNew' -Name 'NullFile' -Type String ''
    }



    $Info = 'Удалить из контекстного меню ''Создать'' пункт: ''Контакт'''
    $Group = 'Expl-NewItems-Contact' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\.contact\ShellNew'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.contact\ShellNew' -Name 'command' -Type ExpandString '"%programFiles%\Windows Mail\Wab.exe" /CreateContact "%1"'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.contact\ShellNew' -Name 'iconpath' -Type ExpandString '%ProgramFiles%\Windows Mail\wab.exe,1'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.contact\ShellNew' -Name 'MenuText' -Type ExpandString '@%CommonProgramFiles%\system\wab32res.dll,-10203'
    }



    $Info = 'Удалить из контекстного меню ''Создать'' пункт: ''Сжатая ZIP-папка'''
    $Group = 'Expl-NewItems-ZIP' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\.zip\CompressedFolder\ShellNew'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.zip\CompressedFolder\ShellNew' -Name 'ItemName' -Type ExpandString '@%SystemRoot%\system32\zipfldr.dll,-10194'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.zip\CompressedFolder\ShellNew' -Name 'Data' -Type Binary '504b0506000000000000000000000000000000000000'
    }



    $Info = 'Удалить из контекстного меню ''Создать'' пункт: ''Документ в формате RTF'''
    $Group = 'Expl-NewItems-RTF' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Classes\.rtf\ShellNew'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.rtf\ShellNew' -Name 'Data' -Type String '{\rtf1}'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.rtf\ShellNew' -Name 'ItemName' -Type ExpandString '@%ProgramFiles%\Windows NT\Accessories\WORDPAD.EXE,-213'
    }



    $Info = 'Добавить разделитель в контекстное меню Корзины'
    $Group = 'Expl-RecycleBinSeparat' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Параметр 'DelegateExecute' для того, чтобы очистители реестра не считали параметр ошибочным, так как они считают параметры без действия или значения ошибочными.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{645FF040-5081-101B-9F08-00AA002F954E}\shell\Separator' -Name 'CommandFlags' -Type DWord 40
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\CLSID\{645FF040-5081-101B-9F08-00AA002F954E}\shell\Separator\command' -Name 'DelegateExecute' -Type String '{48527bb3-e8de-450b-8910-8c4099cb8624}'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\CLSID\{645FF040-5081-101B-9F08-00AA002F954E}\shell\Separator'
    }



    $Info = 'Скрыть пункт ''Передать на устройство'' из контекстного меню для медиа/фото файлов'
    $Group = 'Expl-CastToDevice' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{7AD84985-87B4-4a16-BE58-8B72A5B390F7}' -Type String ''

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{7AD84985-87B4-4a16-BE58-8B72A5B390F7}' -Type String ''
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{7AD84985-87B4-4a16-BE58-8B72A5B390F7}'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{7AD84985-87B4-4a16-BE58-8B72A5B390F7}'
    }



    $Info = 'Скрыть пункт ''Исправление проблем с совместимостью'' из контекстного меню'
    $Group = 'Expl-HideFixCompat' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{1D27F844-3A1F-4410-85AC-14651078412D}' -Type String ''

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{1D27F844-3A1F-4410-85AC-14651078412D}' -Type String ''
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{1D27F844-3A1F-4410-85AC-14651078412D}'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{1D27F844-3A1F-4410-85AC-14651078412D}'
    }



    $Info = 'Скрыть пункт ''Изменить с помощью приложения Фотографии'' из контекстного меню'
    $Group = 'Expl-HideEditWithPhotos' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string] $RegKey = 'Software\Classes\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellEdit'
         [array] $Roots  = 'HKCU:'

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.UsrClass_Load })).ForEach({ $Roots += $_.SID })
        }

        [int] $N = 0

        foreach ( $Key in $Roots )
        {
            try
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    $OpenRegKey.Close()

                    $N++

                    $Path = "$isRoot\$RegKey"

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly' -Type String '' -OnlyThisPath
                }
            }
            catch {}
        }

        if ( -not $N )  { Write-Host '   ------------------------------' -ForegroundColor DarkGray }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        [string] $RegKey = 'Software\Classes\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellEdit'
         [array] $Roots  = 'HKCU:'

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.UsrClass_Load })).ForEach({ $Roots += $_.SID })
        }

        [int] $N = 0

        foreach ( $Key in $Roots )
        {
            try
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    $OpenRegKey.Close()

                    $N++

                    $Path = "$isRoot\$RegKey"

                    Set-Reg Remove-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly' -OnlyThisPath
                }
            }
            catch {}
        }

        if ( -not $N )  { Write-Host '   ------------------------------' -ForegroundColor DarkGray }
    }



    $Info = 'Скрыть пункт ''Создать новое видео'' из контекстного меню'
    $Group = 'Expl-HideCreateVideo' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string] $RegKey = 'Software\Classes\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo'
         [array] $Roots  = 'HKCU:'

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.UsrClass_Load })).ForEach({ $Roots += $_.SID })
        }

        [int] $N = 0

        foreach ( $Key in $Roots )
        {
            try
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    $OpenRegKey.Close()

                    $N++

                    $Path = "$isRoot\$RegKey"

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly' -Type String '' -OnlyThisPath
                }
            }
            catch {}
        }

        if ( -not $N )  { Write-Host '   ------------------------------' -ForegroundColor DarkGray }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        [string] $RegKey = 'Software\Classes\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo'
         [array] $Roots  = 'HKCU:'

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.SID -and $_.UsrClass_Load })).ForEach({ $Roots += $_.SID })
        }

        [int] $N = 0

        foreach ( $Key in $Roots )
        {
            try
            {
                if ( $Key -eq 'HKCU:' )
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = $Key
                }
                else
                {
                    $OpenRegKey = [Microsoft.Win32.Registry]::Users.OpenSubKey("$Key\$RegKey",'ReadSubTree','QueryValues,EnumerateSubKeys')
                    $isRoot     = "Registry::HKU\$Key"
                }

                if ( $OpenRegKey )
                {
                    $OpenRegKey.Close()

                    $N++

                    $Path = "$isRoot\$RegKey"

                    Set-Reg Remove-ItemProperty -Path $Path -Name 'ProgrammaticAccessOnly' -OnlyThisPath
                }
            }
            catch {}
        }

        if ( -not $N )  { Write-Host '   ------------------------------' -ForegroundColor DarkGray }
    }



    $Info = 'Скрыть пункт ''Печать'' из контекстного меню .bat и .cmd файлов'
    $Group = 'Expl-HidePrintCmd' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\batfile\shell\print' -Name 'ProgrammaticAccessOnly' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\cmdfile\shell\print' -Name 'ProgrammaticAccessOnly' -Type String ''
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\batfile\shell\print' -Name 'ProgrammaticAccessOnly'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\cmdfile\shell\print' -Name 'ProgrammaticAccessOnly'
    }



    $Info = 'Скрыть пункт ''Добавить в библиотеку'' из контекстного меню для папок'
    $Group = 'Expl-HideIncludeInLibrary' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Folder\shellex\ContextMenuHandlers\Library Location' -Name '(Default)' -Type None ([byte[]]@())
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Folder\shellex\ContextMenuHandlers\Library Location' -Name '(Default)' -Type String '{3dad6c5d-2167-4cae-9914-f99e41c12cfa}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\Folder\shellex\ContextMenuHandlers\Library Location'
    }



    $Info = 'Скрыть пункт ''Отправить'' из контекстного меню папок/файлов'
    $Group = 'Expl-HideSendTo' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo' -Name '(Default)' -Type String '-{7BA4C740-9E81-11CF-99D3-00AA004AE837}'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\AllFilesystemObjects\shellex\ContextMenuHandlers\SendTo' -Name '(Default)' -Type String '{7BA4C740-9E81-11CF-99D3-00AA004AE837}'
    }



    $Info = 'Добавить пункт ''Извлечь'' в контекстное меню для файлов .msi'
    $Group = 'Expl-AddExtractMsi' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Msi.Package\shell\Extract' -Name 'MUIVerb' -Type String '@shell32.dll,-37514'  # Извлечь всё/Extract all
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Msi.Package\shell\Extract' -Name 'Icon' -Type String 'shell32.dll,-16817'      # Иконка 'серая стрелка вверх'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Msi.Package\shell\Extract\Command' -Name '(Default)' -Type String 'msiexec.exe /a "%1" /qb TARGETDIR="%1 extracted"'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\Msi.Package\shell\Extract'
    }



    $Info = 'Добавить пункт ''Установить'' в контекстное меню для файлов .cab'
    $Group = 'Expl-AddInstallCab' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\SystemFileAssociations\.cab\Shell\RunAs' -Name '(Default)' -Type String 'Install Cab File'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\SystemFileAssociations\.cab\Shell\RunAs' -Name 'HasLUAShield' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\SystemFileAssociations\.cab\Shell\RunAs' -Name 'MUIVerb' -Type String '@shell32.dll,-10210'  #  Установить/Install
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\SystemFileAssociations\.cab\Shell\RunAs\Command' -Name '(Default)' -Type String 'cmd /k dism /online /add-package /packagepath:"%1"'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\SystemFileAssociations\.cab\Shell'
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\CABFolder\Shell\RunAs'
    }



    $Info = 'Заменить PowerShell на CMD в Win+X меню'
    $Group = 'Expl-ShowCmdInWinX' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'DontUsePowerShellOnWinX' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'DontUsePowerShellOnWinX' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Настроить Win+X меню (Добавить свои ярлыки)'
    $Group = 'Expl-AddShortcutToWinX' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Add-WinX-Shortcuts -Act $Act
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Add-WinX-Shortcuts -Act Default
    }



    $Info = 'Отображать значок ''Этот компьютер'' на рабочем столе'
    $Group = 'Expl-ThisComputerIcon' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{20D04FE0-3AEA-1069-A2D8-08002B30309D}' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{20D04FE0-3AEA-1069-A2D8-08002B30309D}'
    }



    $Info = 'Открывать ''Этот компьютер'' в Проводнике'
    $Group = 'Expl-OpenThisComputer' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'LaunchTo' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'LaunchTo'
    }



    $Info = 'Скрыть иконку ''Люди'' с панели задач'
    $Group = 'Expl-HidePeopleBar' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'HidePeopleBar' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'HidePeopleBar'
    }



    $Info = 'Скрыть иконку ''Провести собрание'' с панели задач (2004)'
    $Group = 'Expl-HideMeetNow' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 2004
    if ( $Groups -like $Group )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action $Act

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'HideSCAMeetNow' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'HideSCAMeetNow' -Type DWord 1

            <# чтобы изменить переключатель в настройках обязательно Нужен перезапуск проводника, иначе не применится вообще
            try { $Settings = @([Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3','Settings',$null)) } catch {}

            if ( $Settings.Count -gt 9 )
            {
			    $Settings[9] = 128

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3' -Name 'Settings' -Type Binary $Settings
            }
            #>
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            $Info | Show-Info -Shift $L.s1 -Action Default

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'HideSCAMeetNow'
            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'HideSCAMeetNow'

            <# чтобы изменить переключатель в настройках обязательно Нужен перезапуск проводника, иначе не применится вообще
            try { $Settings = @([Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3','Settings',$null)) } catch {}

            if ( $Settings.Count -gt 9 )
            {
			    $Settings[9] = 0

                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StuckRects3' -Name 'Settings' -Type Binary $Settings
            }
            #>
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить и Скрыть иконку ''Новости и интересы'' с панели задач (21H1)'
    $Group = 'Expl-HideNewsAndInterest' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 2004
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{B6D83264-AC99-4C7B-B230-5A15CE7A1F72}','',$null) -like '*ShellFeed*' )
            {
                # на 21H2 напрямую править не дают, только руками через ПКМ меню. Настройки храянтся в скрытом разделе файла куста \REGISTRY\A\{GUID} https://docs.microsoft.com/en-us/windows-hardware/drivers/kernel/filtering-registry-operations-on-application-hives
                #Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds' -Name 'ShellFeedsTaskbarViewMode' -Type DWord 2

                # Конфигурация компьютера - Административные шаблоны - Компоненты Windоws - Новости и интересы "Включить новости и интересы на панели задач" - "Отключено"
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' -Name 'EnableFeeds' -Type DWord 0
            }
            else
            {
                $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
        {
            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CLSID\{B6D83264-AC99-4C7B-B230-5A15CE7A1F72}','',$null) -like '*ShellFeed*' )
            {
                Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' -Name 'EnableFeeds'
            }
            else
            {
                $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Скрыть иконку ''Представление задач'' на панели задач'
    $Group = 'Expl-TaskbarTaskView' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowTaskViewButton' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowTaskViewButton' -Type DWord 1
    }



    $Info = 'Скрыть иконку ''Чат'' на панели задач (W11)'
    $Group = 'Expl-TaskbarChat' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarMn' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarMn' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Скрыть иконку ''Мини-приложения'' на панели задач (W11)'
    $Group = 'Expl-Taskbarwidgets' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarDa' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarDa' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить оптимизированное для облака содержимое (2009 19042)'
    $Group = 'Expl-CloudOptimizContent' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 19042 )
        {
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableCloudOptimizedContent' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableCloudOptimizedContent'
    }



    $Info = 'Установить Пустой шаблон Пуска без ярлыков (W11)'
    $Group = 'Expl-EmptyStartTemplate' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )
        {
            Set-Empty-Start-Template -Act $Act
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )
        {
            Set-Empty-Start-Template -Act Default
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Настроить Поиск на Панели задач'
    $Group = 'Expl-SearchboxTaskbarMode' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act -NoIndentAfter

        if ( $Groups.$Group -eq 1 ) { $Value = 1 ; 'Свернуть в иконку' | Show-Info -Shift $L.s2 } # (SubParam)
        else                        { $Value = 0 ; 'Скрыть'            | Show-Info -Shift $L.s3 }

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord $Value
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -in 19041..21999 ) # если от 2004 и до W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 2
        }
        else
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 1
        }
    }



    $Info = 'Отключить показ главного в поиске (предложения, картинки Bing в панели/поле поиска)'
    $Group = 'Expl-SearchDynamicContent' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 19041 ) # если от 2004
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings' -Name 'IsDynamicSearchBoxEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds\DSB' -Name 'ShowDynamicContent' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds\DSB' -Name 'IsDynamicContentAvailable' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings' -Name 'IsDynamicSearchBoxEnabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds\DSB' -Name 'ShowDynamicContent'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds\DSB' -Name 'IsDynamicContentAvailable'
    }



    $Info = 'Скрыть Кортану с Панели задач (2004 до W11)'
    $Group = 'Expl-ShowCortanaButton' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -in 19041..21999 ) # Настройка только для версии Windows 10 от 2004 и до W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -in 19041..21999 )
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить все уведомления и скрыть иконку Центра уведомлений на панели задач'
    $Group = 'Expl-NotificationCenter' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

	    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableNotificationCenter' -Type DWord 1
	    Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableNotificationCenter' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications' -Name 'ToastEnabled' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

	    Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableNotificationCenter'
	    Set-LGP Remove-ItemProperty -Path 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableNotificationCenter'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\PushNotifications' -Name 'ToastEnabled'
    }



    $Info = 'Включить Классический Компактный режим Проводника'
    $Group = 'Expl-UseCompactMode' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        try { [string] $isModeExists = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\Folder\UseCompactMode','Type',$null) }
        catch { [string] $isModeExists = $null }

        if ( $isModeExists )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'UseCompactMode' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        try { [string] $isModeExists = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced\Folder\UseCompactMode','Type',$null) }
        catch { [string] $isModeExists = $null }

        if ( $isModeExists )
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'UseCompactMode' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить показ макетов прикрепления при наведении указателя на кнопку увеличения окна (W11)'
    $Group = 'Expl-SnapAssistFlyout' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'EnableSnapAssistFlyout' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'EnableSnapAssistFlyout' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Включить выравнивание панели задач слева (W11)'
    $Group = 'Expl-LeftAlignmentTaskbar' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAl' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarAl' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Включить Контекстное меню Проводника как в Windows 10 (W11)'
    $Group = 'Expl-ContextMenuWin10' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32' -Name '' -Type String ''

            if ( $is64 )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\WOW6432Node\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32' -Name '' -Type String ''
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}'
            Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\WOW6432Node\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}'
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Использование 100% качества картинки, при установке обоев рабочего стола (по умолчанию 85%)'
    $Group = 'Expl-WallpaperQuality' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'JPEGImportQuality' -Type DWord 100
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Control Panel\Desktop' -Name 'JPEGImportQuality'
    }



    $Info = 'Включить мелкие значки в Панели управления'
    $Group = 'Expl-ControlPanelItems' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel' -Name 'AllItemsIconView' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel' -Name 'StartupPage' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel' -Name 'AllItemsIconView'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel' -Name 'StartupPage'
    }



    $Info = 'Отключить Вэб публикацию в списке задач для файлов'
    $Group = 'Expl-WebPublishingWizard' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить веб-публикацию в списке задач для файлов и папок" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoPublishingWizard' -Type DWord 1
        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить веб-публикацию в списке задач для файлов и папок" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoPublishingWizard' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoPublishingWizard'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoPublishingWizard'
    }



    $Info = 'Отключить Обновление файлов помощника по поиску'
    $Group = 'Expl-ContentFileUpdates' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить обновление файлов содержимого помощника по поиску" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SearchCompanion' -Name 'DisableContentFileUpdates' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SearchCompanion' -Name 'DisableContentFileUpdates'
    }



    $Info = 'Отключить Рейтинг справки'
    $Group = 'Expl-FeedbackRating' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключение рейтинга справки" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoExplicitFeedback' -Type DWord 1
        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключение рейтинга справки" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoImplicitFeedback' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoExplicitFeedback'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoImplicitFeedback'
    }



    $Info = 'Отключить Активную справку'
    $Group = 'Expl-ActiveHelp' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить обновление файлов содержимого помощника по поиску" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoActiveHelp' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Assistance\Client\1.0' -Name 'NoActiveHelp'
    }



    $Info = 'Отключить запуск справки (helppane.exe) по нажатию F1'
    $Group = 'Expl-HelpPaneF1' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act Remove-Item -Path 'HKCU:\Software\Classes\Typelib\{8cec5860-07a1-11d9-b15e-000d56bfe6ee}'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\AppID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}' -Name 'RunAs' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}\LocalServer32' -Name '(Default)' -Type None ([byte[]]@())

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\WOW6432Node\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}\LocalServer32' -Name '(Default)' -Type None ([byte[]]@())
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\WOW6432Node\Classes\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}\LocalServer32' -Name '(Default)' -Type None ([byte[]]@())
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\Typelib\{8cec5860-07a1-11d9-b15e-000d56bfe6ee}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\AppID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Classes\WOW6432Node\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}'
        Set-Reg Remove-Item -Path 'HKCU:\Software\WOW6432Node\Classes\CLSID\{8cec58ae-07a1-11d9-b15e-000d56bfe6ee}'
    }



    $Info = 'Скрыть стрелки у ярлыков'
    $Group = 'Expl-ArrowsShortcuts' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        $Ico = "$env:SystemRoot\Blank.ico"

        if ( $Act -eq 'Set' )
        {
            if ( -not [System.IO.File]::Exists($Ico) )
            {
                try
                {
                    # Сжатые байты в Base64
                    $IcoBase64 = 'H4sIAAAAAAAEAO3af0gTURwA8O/OaWqaS4tmaTu3OQwXLIVcueaPzVIqS4uaIGy5MMEM+wEOKlo/NGuWsyQlNUkqDIcG9k9hNIeKSpr9EmP9EDMTS
                    zQFNTTXXQZZLc0SNPl++D7evXv3xt27d8fj7QAYwAQaA0j4TACsp7ZForFysTeAzAaAJL+VWQDvfQBYrLFyAtX04hqAM1sjNzg7LnWkmjpHhMuj6Vo62dtRWeyB4ngA
                    oipCHrJdk9/9MmqfWbRIHvWspN31Xn0Rx/YycTOvJYt7djB/cZPGP/MSITbbgVWG3Rn7A4edjMtST4nmg0kI9uXQyqwb3FXn4uy2LZwqkQ8IrZvGI42qtqI1dCSXf9h
                    VoPVNHi4POE7kFpg5RdlUFPIclhgzXoyyro+Mj/yQTmhsHzjt83Z87BGY7Hs9fzk49rie+FDX7RJV/0OEqDPy+mT6Nll2Hx36d0fTo4/sELywfoWQnM/Zw9H2fOwKEt
                    953RM0KLV6IWBUqzPMJfcNTrEt9dXKgZMMY47hyLCN5eoIqz2VI18hla8I+n1Yqt3JsgsFtmxumT4vlS14qM+pZvsUevvq/BRSLk/nr1qedQ5kHcp2btWtT3kSpvtas
                    2BejF2mU5VDcM5zHjOqo5Fjaop7VcFb5BnfEBj6SNUo4Xsk+iulfH6i305p2NZm9Q1JmKo57opkc0Kz6nzFJk1pw8iQn9ddwUF1gOnQyo7qUqZjm5CRXs4kG1214o3w
                    Y6GGHaD7aVeFB1NIGLmwWgctQkLVv8Smtj8JepOgS8goDQ5nWOkmxeMHQazA7krtmxiqa6/FcGwWrHtq4Cwd2hziRY0UapSI01KgN75GuimFVC303ycRP9lbkNslstr
                    pt24rdZW5tVtWddIDHSLCIuWloaoTPvQDQyXVt4eIpvX+zf1FCCE0rRQKBYHngBBCCCGEEEIIIYQQQgih2WQ2/HcwG84BIYTmIstXU89H6ezY37efK/m/9gP9nRZJpW
                    AY950Wa8aGA0JoiqZjjorzXIQQQghNBc4/EJrbLBMYtViOTVT/Jyb7DXqdgl6WIOH7OkUwc+b6YzJTeZ/huw/NNv/r+B1b2wR4Pfx9e7I0/tgvL5G+tvs9AAA='
                    $BytesCompressed = [System.Convert]::FromBase64String($IcoBase64.Replace("`r`n",''))

                    $InputMS  = [System.IO.MemoryStream]::new($BytesCompressed)
                    $OutputMS = [System.IO.MemoryStream]::new()
                    $GzipStream = [System.IO.Compression.GZipStream]::new($InputMS,[System.IO.Compression.CompressionMode]::Decompress)
                    $GzipStream.CopyTo($OutputMS)
                    $GzipStream.Close()
                    $InputMS.Close()
                    [byte[]] $Bytes = $OutputMS.ToArray()
                    $OutputMS.Close()
                    [System.IO.File]::WriteAllBytes($Ico,$Bytes)
                }
                catch {}
            }
        }

        if ( [System.IO.File]::Exists($Ico) )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Файл найден' }
            Write-Host "   $text`: $Ico`n" -ForegroundColor DarkGreen

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29' -Type ExpandString '%SystemRoot%\Blank.ico'
        }
        else
        {
            $text = if ( $L.s3 ) { $L.s3 } else { 'Нет файла' }
            Write-Host "   $text`: $Ico`n" -ForegroundColor Yellow

            $NeedFix = $true
        }

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Type String ''
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\lnkfile' -Name 'IsShortcut' -Type String ''
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons' -Name '29'

        $Ico = "$env:SystemRoot\Blank.ico"
        Remove-Item -Path $Ico -Force -ErrorAction SilentlyContinue
    }



    $Info = 'Отключить добавление окончания ''— ярлык'' к имени при создании ярлыков'
    $Group = 'Expl-NotAddShortcutSuffix' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\NamingTemplates' -Name 'ShortcutNameTemplate' -Type String '%s.lnk'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\NamingTemplates' -Name 'ShortcutNameTemplate'
    }



    $Info = 'Отключить добавление окончания ''— копия'' к имени при копировании файлов и папок'
    $Group = 'Expl-NotAddCopySuffix' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\NamingTemplates' -Name 'CopyNameTemplate' -Type String '%s'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\NamingTemplates' -Name 'CopyNameTemplate'
    }



    $Info = 'Отображать цвет элементов в заголовках окон'
    $Group = 'Expl-ColorWindowTitles' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\DWM' -Name 'ColorPrevalence' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\DWM' -Name 'ColorPrevalence' -Type DWord 0
    }



    $Info = 'Включить тёмный цвет темы оформления'
    $Group = 'Expl-DarkThemeColor' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'AppsUseLightTheme' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'AppsUseLightTheme' -Type DWord 1
    }



    $Info = 'Отключить эффект прозрачности'
    $Group = 'Expl-ThemeTransparency' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'EnableTransparency' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'EnableTransparency' -Type DWord 1
    }



    $Info = 'Включить светлый цвет Панели задач и Пуска (1903)'
    $Group = 'Expl-SystemLightTheme' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 1903
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) # Для Windows 11 он включен по умолчанию
            {
                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 1
            }
            else
            {
                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 0
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Включить Тёмный цвет Панели задач и Пуска (1903)'
    $Group = 'Expl-SystemDarkTheme' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 1903
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) # Для Windows 11 он включен по умолчанию
            {
                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 1
            }
            else
            {
                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'SystemUsesLightTheme' -Type DWord 0
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не поддерживается в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отображать цвет Панели задач и Пуска'
    $Group = 'Expl-TaskBarColor' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'ColorPrevalence' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize' -Name 'ColorPrevalence' -Type DWord 0
    }



    $Info = 'Настроить Цвет Windows'
    $Group = 'Expl-Colors' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Manage-UI-Colors -Act $Act
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Manage-UI-Colors -Act Default
    }



    $Info = 'Не показывать файлы с Office.com в Быстром доступе Проводника (W11)'
    $Group = 'Expl-HideOfficeInExplorer' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act
        
        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowCloudFilesInQuickAccess' -Type DWord 0
            # Computer Configuration > Administrative Templates > Windows Components > File Explorer​
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableGraphRecentItems' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { 'Не требуется в этой версии Windows' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowCloudFilesInQuickAccess'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer' -Name 'DisableGraphRecentItems'
    }



    $Info = 'Не показывать недавно использовавшиеся файлы и папки только в Быстром доступе Проводника'
    $Group = 'Expl-HideOrNoRecentFile' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowFrequent' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowRecent' -Type DWord 0
    
        [int] $All = 0

        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Sub-Group-Explorer\s*=\s*1\s*=\s*$Group\s*=\s*(?<All>\d+)\s*=" },'First') )
        {
            $All = $Matches.All
        }

        if ( $All )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не хранить историю для всего: Быстрого доступа, меню Пуск и Панели задач' }
            Write-Host "`n    $text`:" -ForegroundColor DarkGray

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'Start_TrackDocs' -Type DWord 0
        }

        $text = if ( $L.s3 ) { $L.s3 } else { 'Очистка' }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        Token-Impersonate -Reset

        # Профили
        $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
        if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

        [array] $Accs = [PSCustomObject] @{
            Name     = $env:USERNAME
            FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
            Root     = 'HKCU:'
            Profile  = $env:USERPROFILE
            SID      = $SID
            Source   = $Source
        }

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

                $Accs += [PSCustomObject] @{
                    Name     = $_.Name
                    FullName = $_.FullName
                    Root     = $_.SID
                    Profile  = $_.Profile
                    SID      = $_.SID
                    Source   = $_.Source
                }
            })
        }

        if ( $Act -eq 'Check' ) { $Color = 'Yellow' } else { $Color = 'Cyan' }

        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Profile )
            {
                $text = if ( $L.s4 ) { $L.s4 } else { 'Профиль' }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Acc.Name) " -ForegroundColor White -NoNewline
                Write-Host "| $($Acc.Profile) | $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

                if ( $Acc.Root -eq 'HKCU:' )
                {
                    $RegRoot = [Microsoft.Win32.Registry]::CurrentUser
                    $SubKey  = 'Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs'
                    $isRoot  = $Acc.Root
                }
                else
                {
                    $RegRoot = [Microsoft.Win32.Registry]::Users
                    $SubKey  = "$($Acc.Root)\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs"
                    $isRoot  = 'Registry::HKU'
                }

                $Folder = "$($Acc.Profile)\AppData\Roaming\Microsoft\Windows\Recent"
                
                [int] $N = 0

                Get-ChildItem -File -LiteralPath $Folder,"$Folder\automaticdestinations" -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -notmatch '^(5f7b5f1e01b83767|f01b4d95cf55d32a)' } | ForEach-Object {

                    $N++
                    
                    if ( $Act -eq 'Check' )
                    {
                        Write-Host '     Del: ' -ForegroundColor Yellow -NoNewline
                        Write-Host "$($_.FullName)" -ForegroundColor DarkGray

                        $NeedFix = $true
                    }
                    else
                    {
                        Write-Host '     Del: ' -ForegroundColor Cyan -NoNewline
                        Write-Host "$($_.FullName)" -ForegroundColor DarkGray

                        Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                    }
                }

                if ( $N ) { Write-Host }

                try { $OpenSubKey = $RegRoot.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                catch { $OpenSubKey = $null }

                if ( $OpenSubKey )
                {
                    foreach ( $SubKeyName in $OpenSubKey.GetSubKeyNames() )
                    {
                        $N++

                        if ( $Act -eq 'Check' )
                        {
                            Write-Host '     Del: ' -ForegroundColor $Color -NoNewline
                            Write-Host "$isRoot\$SubKey\" -ForegroundColor DarkGray -NoNewline
                            Write-Host "$SubKeyName" -ForegroundColor Gray
                            
                            $NeedFix = $true
                        }
                        else
                        {
                            $Path = "$isRoot\$SubKey\$SubKeyName"

                            Set-Reg Remove-Item -Path $Path -OnlyThisPath
                        }
                    }
                    
                    foreach ( $Name in $OpenSubKey.GetValueNames() )
                    {
                        $N++

                        if ( $Act -eq 'Check' )
                        {
                            Write-Host '     Del: ' -ForegroundColor $Color -NoNewline
                            Write-Host "$isRoot\$SubKey | " -ForegroundColor DarkGray -NoNewline
                            Write-Host "$Name" -ForegroundColor Gray

                            $NeedFix = $true
                        }
                        else
                        {
                            $Path = "$isRoot\$SubKey"
                            Set-Reg Remove-ItemProperty -Path $Path -Name $Name -OnlyThisPath
                        }
                    }

                    $OpenSubKey.Close()
                }

                if ( -not $N )
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { 'Нет сохранённой истории' }
                    Write-Host "     $text | $($Acc.Name)" -ForegroundColor DarkGray 
                }
            }
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowFrequent'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShowRecent'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'Start_TrackDocs'

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoRecentDocsHistory'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoRecentDocsHistory'
    }



    $Info = 'Отключить автоматическую очистку кэша миниатюр файлов'
    $Group = 'Expl-ThumbnailCache' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache' -Name 'Autorun' -Type DWord 0

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache' -Name 'Autorun' -Type DWord 0
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache' -Name 'Autorun' -Type DWord 3

        if ( $is64 )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\Thumbnail Cache' -Name 'Autorun' -Type DWord 3
        }
    }



    $Info = 'Увеличить размер кэша Иконок до 8мб'
    $Group = 'Expl-MaxCachedIcons' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'Max Cached Icons' -Type String '8192'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'Max Cached Icons'
    }



    $Info = 'Отключение ''Автоопределение типа папки по содержимому'' в Проводнике'
    $Group = 'Expl-FolderType' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType' -Type String 'NotSpecified'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType' -Type String 'NotSpecified'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType' -Type String 'NotSpecified'
        Set-Reg -Do:$Act New-ItemProperty -Path 'Registry::HKU\.DEFAULT\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType' -Type String 'NotSpecified'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType'
        Set-Reg Remove-ItemProperty -Path 'Registry::HKU\.DEFAULT\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags\AllFolders\Shell' -Name 'FolderType'
    }



    $Info = 'Отключить Кэширование эскизов изображений'
    $Group = 'Expl-NoThumbnailCache' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # ГП: Компоненты Windows/Проводник
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoThumbnailCache' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoThumbnailCache'
    }



    $Info = 'Отключить Кэширование эскизов в скрытых файлах thumbs.db в сетевых папках'
    $Group = 'Expl-ThumbsDBOnNetwork' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # ГП: Пользователь: Компоненты Windows/Проводник
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableThumbsDBOnNetworkFolders' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'DisableThumbsDBOnNetworkFolders'
    }



    $Info = 'Включить запрос подтверждения удаления (для Корзины)'
    $Group = 'Expl-DeleteConfirmation' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [byte[]] $Value = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer','ShellState',$null)

        if ( $Value.Count -ge 5 )
        {
            $Value[4] = 51  # (0x33)

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShellState' -Type Binary $Value
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Пропуск, параметр неверный' }
            Write-Host "   $text`: $($Value.Count)" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        [byte[]] $Value = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer','ShellState',$null)

        if ( $Value.Count -ge 5 )
        {
            $Value[4] = 55  # (0x37)

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer' -Name 'ShellState' -Type Binary $Value
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Пропуск, параметр неверный' }
            Write-Host "   $text`: $($Value.Count)" -ForegroundColor DarkGray
        }
    }



    $Info = 'Включить открытие папок Проводника в отдельных процессах'
    $Group = 'Expl-SeparateProcess' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'SeparateProcess' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'SeparateProcess' -Type DWord 0
    }



    $Info = 'Отключить рекламу OneDrive в проводнике (уведомления поставщика синхронизации)'
    $Group = 'Expl-OneDrive-Ads' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowSyncProviderNotifications' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowSyncProviderNotifications'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowSyncProviderNotifications'
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$InfoThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { 'Необходимо перезагрузиться!' }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen

        Get-Pause
    }
}
