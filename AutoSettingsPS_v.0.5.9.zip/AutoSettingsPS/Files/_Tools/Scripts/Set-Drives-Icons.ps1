﻿
<#
.SYNOPSIS
 Установка индивидуальных иконок для дисков в системе.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Drives_Icons.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра,
 с проверкой и выводом результата. Независимо от доступа, если не блокируется драйвером.
 Используется функция Write-HostColor для вывода текста с цветом.
 Используется функция Get-CpuID для Получения типа ОС (Virtual/Physical) из инструкции процессора CPUID (по 31 биту)
 Используется функция Get-List-Presets

 Установка иконок делается "с хитростью":
 Всем дискам глобально заменяется иконка для USB, таким образом все диски,
 подключенные уже или потом, как угодно, будут иметь иконку флешки. В том числе и локальные диски.

 А так как локальные и RAM диски стационарные, т.е. буква не меняется, то
 на основе дисков в системе заменяются иконки индивидуально под букву, для RAM дисков своя, для Локальных дисков своя.
 Индивидуальная иконка на букву имеет приоритет, поэтому эти диски будут с нужной иконкой. Остальные все с иконкой USB.
 Другие иконки это не затрагивает, например, смартфоны будут со своей иконкой как обычно.
 Для системного диска также ставится иконка локальных дисков, так как в некоторых случаях для него
 начинает подхватываться глобальная иконка флешки, если для него ничего не назначено.

.EXAMPLE
    Set-Drives-Icons -CheckState ShowAllDrives

    Описание
    --------
    Показать все диски в системе, кроме CD/DVD/Floppy/Без букв, так как они не нужны.

.EXAMPLE
    Set-Drives-Icons -Act Set

    Описание
    --------
    Установить иконки согласно дискам в системе.

.EXAMPLE
    Set-Drives-Icons -Act Default

    Описание
    --------
    Восстановить иконки всех дисков по умолчанию.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  23-04-2019
 ===============================================

#>
Function Set-Drives-Icons {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут 'Check' не используется, оставлено, чтобы было по стандарту и не выкидывало ошибок, если будет использовано.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ShowAllDrives', 'ShowDrivesTypes',
                      'PresetIconForSystemDrive', 'PresetIconForLocalDrives', 'PresetIconForRamDrives', 'PresetIconForUsbDrives',
                      'GlobalIconForAllDrives', 'GlobalIconForFlashDrives', 'DrivesWithIcons' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [string] $Smartctl = $SmartctlExe
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    if ( -not [System.IO.File]::Exists($Smartctl) )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Не указана или не найдена утилита Smartctl.exe' }
        Write-Warning "`n$NameThisFunction`: $text`: '$Smartctl'"

        Return    # Выход из функции.
    }

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    # Внутренняя Функция получения всех дисков в системе, кроме CD/DVD/Floppy/Без букв.
    Function Get-All-Drives {

        <#
        DriveType

        Unknown          0  The type of drive is unknown.
        NoRootDirectory  1  The drive does not have a root directory.
        Removable        2  The drive is a removable storage device, such as a USB flash drive.
        Fixed            3  The drive is a fixed disk. (Local Disk)
        Network          4  The drive is a network drive.
        CDRom            5  The drive is an optical disc device, such as a CD or DVD-ROM.
        Ram              6  The drive is a RAM disk.

        MediaType
        Определяет точный тип носителя логического диска. Существует 22 значения данного параметра

        Unknown    0   Неизвестный формат
        Removable  11  Съемные носители (кроме дискет Floppy)
        Fixed      12  Фиксированный жесткий диск (Fixed hard disk media, Local Disk)

        Остальные значения MediaType относятся к различным форматам гибких дисков Floppy.
        #>

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param()

        try { [bool] $isVirtual = $false ; $isVirtual = $(Get-CpuID isVirtual) } catch { $isVirtual = $false }

        [hashtable] $TableDrives = @{}

        try { $GetPhysicalDisk = Get-PhysicalDisk } catch { Return $null }

        # Получение информации по дискам из командлета Get-PhysicalDisk и далее из Get-Partition
        # и добавление этих данных в таблицу $TableDrives
        $GetPhysicalDisk | ForEach-Object {

            [string] $MediaType  = $_.MediaType
            [string] $DeviceName = $_.FriendlyName
            [string] $BusType    = $_.BusType
            [string] $DiskNumber = $_.DeviceId

            if (( $_.SpindleSpeed -eq 0 ) -and ( $BusType -like '*USB*' )) { $MediaType = 'Flash' }

            Get-Partition -DiskNumber $DiskNumber -ErrorAction SilentlyContinue | ForEach-Object {

                if ( -not $_.DriveLetter ) { Return } # Если нет буквы у диска, переход к следующей итерации

                <#
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'Unknown' )) { $MediaType = 'RAM' ; $BusType = 'RAM' }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'SCSI'    )) { $MediaType = 'RAM' ; $BusType = 'RAM' }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'RAID'    )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'SATA'    )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'ATA'     )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -ne 'Unknown' ) -and ( $BusType -ne 'RAID' ) -and ( $BusType -ne 'SATA' ) -and ( $BusType -ne 'ATA' )) { $MediaType = 'VirtualHDD' }
                #>

                if ( $MediaType -like '*Unspecified*' )
                {
                    if ( $BusType -match 'Unknown|SCSI'  )
                    {
                        $MediaType = 'RAM' ; if ( $BusType -like '*Unknown*' ) { $BusType = 'RAM' }
                    }
                    else
                    {
                        $MediaType = 'HDD'
                    }
                }

                if ( $MediaType -match 'HDD|SSD' )
                {
                    if ( $isVirtual )
                    {
                        if ( $MediaType -like '*HDD*' ) { $MediaType = 'VirtualHDD' } else { $MediaType = 'VirtualSSD' }
                    }
                }

                $TableDrives[$TableDrives.Count] = @{

                    DiskNumber  = $DiskNumber
                    MediaType   = $MediaType
                    DeviceName  = $DeviceName
                    BusType     = $BusType

                    DriveLetter = "$($_.DriveLetter):"
                    Size        = $_.Size
                }
            }
        }

        # Получение дополнительных данных о дисках из WMI через командлет Get-CimInstance
        # И добавление в таблицу $TableDrives дополнительной инфы, к уже добавленным данным о дисках, либо добавление новых дисков
        Get-CimInstance -Class win32_logicaldisk -Filter 'DriveType=0 or DriveType=2 or DriveType=3 or DriveType=6' | ForEach-Object {

            if ( -not $_.DeviceID ) { Return }  # Если нет буквы у диска, переход к следующей итерации

            [string] $DriveLetter = $_.DeviceID
            [string] $VolumeName  = $_.VolumeName
            [string] $FileSystem  = $_.FileSystem

            if     (    12 -eq $_.MediaType ) { [string] $MediaType = 'RAM'        }
            elseif ( $null -eq $_.MediaType ) { [string] $MediaType = 'Flash'      }
            else                              { [string] $MediaType = $_.MediaType }

            if     (     2 -eq $_.DriveType ) { [string] $BusType   = 'USB'        }
            else                              { [string] $BusType   = 'RAM'        }

            if ( $TableDrives.Values.DriveLetter -like $DriveLetter )
            {
                # Если Диск уже есть в таблице, дополняем его информацией.
                $TableDrives.Values.Where({

                    if ( $_.DriveLetter -eq $DriveLetter )
                    {
                        $_.VolumeName = $VolumeName
                        $_.FileSystem = $FileSystem
                    }
                })
            }
            else
            {
                # Иначе добавляем новый диск в таблицу.
                $TableDrives[$TableDrives.Count] = @{

                    DriveLetter = $DriveLetter
                    Size        = $_.Size
                    MediaType   = $MediaType
                    BusType     = $BusType

                    VolumeName  = $VolumeName
                    FileSystem  = $FileSystem
                }
            }
        }

        # Сопоставление дисков и разделов через Win32_DiskDriveToDiskPartition и Win32_LogicalDiskToPartition
        # для понимания большего количества типов дисков, включая SoftRaid
        Get-WmiObject Win32_DiskDrive -ErrorAction SilentlyContinue | ForEach-Object {

            $DiskDrive = $_
            $DriveToPartitions = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($DiskDrive.DeviceID)'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"

            Get-WmiObject -Query $DriveToPartitions -ErrorAction SilentlyContinue | ForEach-Object {

                $Partition = $_
                $LogicalToPartitions = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($Partition.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition"

                Get-WmiObject -Query $LogicalToPartitions -ErrorAction SilentlyContinue | ForEach-Object {

                    $DiskDriveAdv = @($GetPhysicalDisk).Where({ $_.DeviceId -eq $DiskDrive.Index },'First')

                    $MediaType   = $DiskDriveAdv.MediaType
                    $BusType     = $DiskDriveAdv.BusType
                    $DeviceName  = $DiskDriveAdv.FriendlyName
                    $DriveNumber = $DiskDriveAdv.DeviceId

                    if     ( $DiskDriveAdv.PhysicalLocation -like '*.vhd'  ) { $BusType = 'VHD'  }
                    elseif ( $DiskDriveAdv.PhysicalLocation -like '*.vhdx' ) { $BusType = 'VHDX' }

                    if ( $MediaType -like '*Unspecified*' )
                    {
                        if ( $BusType -match 'Unknown|SCSI'  )
                        {
                            $MediaType = 'RAM' ; if ( $BusType -like '*Unknown*' ) { $BusType = 'RAM' }
                        }
                        else
                        {
                            $MediaType = 'HDD'
                        }
                    }

                    if ( $MediaType -match 'HDD|SSD' )
                    {
                        if ( $isVirtual )
                        {
                            if ( $MediaType -like '*HDD*' ) { $MediaType = 'VirtualHDD' } else { $MediaType = 'VirtualSSD' }
                        }
                    }

                    $DriveLetter = $_.DeviceID
                    $VolumeName  = $_.VolumeName
                    $FileSystem  = $_.FileSystem

                    $DiskMediaTypeInt = $_.MediaType
                    $DiskDriveTypeInt = $_.DriveType

                    if ( $TableDrives.Values.DriveLetter -like $DriveLetter )
                    {
                        # Если Диск уже есть в таблице, дополняем его информацией.
                        $TableDrives.Values.Where({

                            if ( $_.DriveLetter -eq $DriveLetter )
                            {
                                $_.VolumeName = $VolumeName
                                $_.FileSystem = $FileSystem
                                $_.DeviceName = $DeviceName

                                # Если у одной буквы несколько дисков = RAID
                                if ( $DriveNumber -ne $_.DiskNumber )
                                {
                                    $BusType = 'RAID'

                                    [string[]] $DiskNumbers = @()

                                    if ( $_.DiskNumber )
                                    {
                                        $DiskNumbers = $_.DiskNumber.ToString().Split('+')
                                    }

                                    $DiskNumbers += $DriveNumber

                                    $_.DiskNumber = ($DiskNumbers.Where({$_}) | Sort-Object) -join '+'
                                }

                                # Если фиксированный диск, обновить/заменить тип диска
                                if ( $DiskDriveTypeInt -eq 3 -and $DiskMediaTypeInt -eq 12 )
                                {
                                    $_.MediaType = $MediaType
                                    $_.BusType   = $BusType
                                }
                            }
                        })
                    }
                    else
                    {
                        # Иначе добавляем новый диск в таблицу.
                        $TableDrives[$TableDrives.Count] = @{

                            DiskNumber  = $DriveNumber
                            DriveLetter = $DriveLetter
                            Size        = $_.Size
                            MediaType   = $MediaType
                            BusType     = $BusType

                            VolumeName  = $VolumeName
                            FileSystem  = $FileSystem
                            DeviceName  = $DeviceName
                        }
                    }
                }
            }
        }

        # Перепроверяем более точно все диски, определённые ранее как HDD, с помощью утилиты Smartctl.exe
        # Диски могут не определиться как SSD, так как с помощью PS это сделать гарантированно не возможно.
        $TableDrives.Values.Where({

            if ( $_.MediaType -like '*HDD*' )
            {
                # Для всех возможных типов подключения.
                foreach ( $Type in 'sat,auto','auto','nvme','ata','scsi','sat' )
                {
                    $DiskNumber = $_.DiskNumber
                    [string[]] $DeviceInfo = & $Smartctl -d $Type -i /dev/pd$DiskNumber

                    # Если диск определился как SSD.
                    if ( $DeviceInfo -match 'Rotation\s*Rate:\s*Solid' )
                    {
                        # Переименовываем его МедиаТип HDD в МедиаТип SSD, и прерываем дальнейшее определение этого диска.
                        if ( $_.MediaType -like '*VirtualHDD*' ) { $_.MediaType = 'VirtualSSD' }
                        else                                     { $_.MediaType = 'SSD'        }

                        break
                    }
                    elseif ( $DeviceInfo -match 'Rotation\s*Rate:\s*\d+\s*rpm' )
                    {
                        break  # определена скорость вращения, диск HDD, прерываем дальнейшее определение этого диска
                    }
                }
            }
        })

        # Глобальная переменная со всеми локальными дисками в системе.
        [string[]] $Global:AllLocalDrives = $TableDrives.Values.Where({ $_.MediaType -match 'HDD|SSD' }).DriveLetter | Sort-Object

        # Глобальная переменная со всеми дисками RAM в системе.
        [string[]] $Global:AllRamDrives = $TableDrives.Values.Where({ $_.MediaType -like '*RAM*' }).DriveLetter | Sort-Object

        $TableDrives
    }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'ShowAllDrives' )
        {
            Write-Host '  ' -NoNewline

            $text = if ( $L.s2 ) { $L.s2 } else { '    Диск Размер       Метка тома       Ф/с     Тип         Шина   Устройство                            ' }
            Write-Host "$text" -ForegroundColor Black -BackgroundColor DarkGray

            # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
            [hashtable] $AllDrivesTable = Get-All-Drives

            if ( $AllDrivesTable.Values.Count )
            {
                ($AllDrivesTable.Values | Sort-Object { $_.DriveLetter }).ForEach({

                    [string] $DriveLetter = $_.DriveLetter
                    [string] $Size        = ( $_.Size / 1gb ).ToString('F2')
                    [string] $FileSystem  = $_.FileSystem
                    [string] $MediaType   = $_.MediaType
                    [string] $BusType     = $_.BusType
                    [string] $DeviceName  = $_.DeviceName
                    [string] $VolumeName  = $_.VolumeName
                    [string] $DiskNumber  = $_.DiskNumber

                    if ( -not $VolumeName ) { $VolumeName = '---------------' }

                    [string] $Color = 'Gray'
                    if     ( $MediaType -like '*SSD*' ) { $Color = 'Green'   }
                    elseif ( $MediaType -like '*HDD*' ) { $Color = 'Yellow'  }
                    elseif ( $MediaType -like '*RAM*' ) { $Color = 'Magenta' }

                    if ( $MediaType -ne 'RAM' ) { $Disks = "(Disk: $DiskNumber)" } else { $Disks = "" }
                    if ( $BusType -like '*vhd*' ) { $BusColor = 'DarkCyan' } else { $BusColor = 'DarkGray' }

                    [string] $DiskInfo = "      #$Color#$DriveLetter#    {0}  #DarkGray#{1}#  {2}  #$Color#{3}  #$BusColor#{4} #DarkGray#$DeviceName $Disks" -f
                        ($Size.PadRight(8,' ') -Replace('\d+,\d+','$0 #DarkGray#гб#')),
                        $VolumeName.PadRight(15,' ').Substring(0,15),
                        $FileSystem.PadRight(6,' ').Substring(0,6),
                        $MediaType.PadRight(10,' ').Substring(0,10),
                        $BusType.PadRight(6,' ').Substring(0,6)

                    # Вывод полученной информации для каждого диска.
                    Write-HostColor $DiskInfo
                })
            }
            else
            {
                Write-Host 'Get-PhysicalDisk: Error' -ForegroundColor Red
            }
        }
        elseif ( $CheckState -eq 'ShowDrivesTypes' )
        {
            if ( $Global:AllLocalDrives )
            {
                if ( $Global:AllRamDrives )
                {
                    if ( $L.s3 )
                    {
                        "$($L.s3): #Green#$($Global:AllLocalDrives -join ' ') #DarkGray#|# RAM: #Magenta#$($Global:AllRamDrives -join ' ') #DarkGray#|# $($L.s3_1) #Yellow#USB#"
                    }
                    else
                    {
                        "Локальные: #Green#$($Global:AllLocalDrives -join ' ') #DarkGray#|# RAM: #Magenta#$($Global:AllRamDrives -join ' ') #DarkGray#|# Остальные #Yellow#USB#"
                    }
                }
                else
                {
                    if ( $L.s3 )
                    {
                        "$($L.s3): #Green#$($Global:AllLocalDrives -join ' ') #DarkGray#|# $($L.s3_1) #Yellow#USB#"
                    }
                    else
                    {
                        "Локальные: #Green#$($Global:AllLocalDrives -join ' ') #DarkGray#|# Остальные #Yellow#USB#"
                    }
                }
            }
            else { '#Red#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Ошибка, диски не найдены' }) }
        }
        elseif ( $CheckState -eq 'PresetIconForSystemDrive' )
        {
            # Пропускаются пути с запрещёнными символами.
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-System\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $PresetIconForSystemDrive = $Matches.IconPath.Trim()
            }
            else { [string] $PresetIconForSystemDrive = '' }

            if ( $PresetIconForSystemDrive ) { "#DarkGray#$PresetIconForSystemDrive#" }
            else { '#Red#{0}#' -f $(if ( $L.s5 ) { $L.s5 } else { 'Не задана иконка для Системного диска в пресете' }) }
        }
        elseif ( $CheckState -eq 'PresetIconForLocalDrives' )
        {
            # Пропускаются пути с запрещёнными символами.
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-Local\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $PresetIconForLocalDrives = $Matches.IconPath.Trim()
            }
            else { [string] $PresetIconForLocalDrives = '' }

            if ( $PresetIconForLocalDrives ) { "#DarkGray#$PresetIconForLocalDrives#" }
            else { '#Red#{0}#' -f $(if ( $L.s5_1 ) { $L.s5_1 } else { 'Не задана иконка для Локальных дисков в пресете' }) }
        }
        elseif ( $CheckState -eq 'PresetIconForRamDrives' )
        {
            # Пропускаются пути с запрещёнными символами.
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-RAM\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $PresetIconForRamDrives = $Matches.IconPath.Trim()
            }
            else { [string] $PresetIconForRamDrives = '' }

            if ( $PresetIconForRamDrives ) { "#DarkGray#$PresetIconForRamDrives#" }
            else { '#Red#{0}#' -f $(if ( $L.s6 ) { $L.s6 } else { 'Не задана иконка для RAM дисков в пресете' }) }
        }
        elseif ( $CheckState -eq 'PresetIconForUsbDrives' )
        {
            # Пропускаются пути с запрещёнными символами.
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-USB\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
            {
                [string] $PresetIconForUsbDrives = $Matches.IconPath.Trim()
            }
            else { [string] $PresetIconForUsbDrives = '' }

            if ( $PresetIconForUsbDrives ) { "#DarkGray#$PresetIconForUsbDrives#" }
            else { '#Red#{0}#' -f $(if ( $L.s7 ) { $L.s7 } else { 'Не задана иконка для USB дисков в пресете' }) }
        }
        elseif ( $CheckState -eq 'GlobalIconForAllDrives' )
        {
            [string] $GlobalIconForAllDrives = ''

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons','ReadSubTree','QueryValues')
                $GlobalIconForAllDrives = $OpenSubKey.GetValue('8',$null,'DoNotExpandEnvironmentNames')
                $OpenSubKey.Close()
            }
            catch { $GlobalIconForAllDrives = '' }

            if ( $GlobalIconForAllDrives ) {  "#Green#{0} #DarkGray#| #Yellow#$GlobalIconForAllDrives#" -f $(if ( $L.s9 ) { $L.s9 } else { 'Настроено' }) }
            else                           { '#Yellow#{0} #DarkGray#{1}#' -f $(if ( $L.s8 ) { $L.s8, $L.s8_1 } else { 'Не настроено', '(По умолчанию)' }) }
        }
        elseif ( $CheckState -eq 'GlobalIconForFlashDrives' )
        {
            [string] $GlobalIconForFlashDrives = ''

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons','ReadSubTree','QueryValues')
                $GlobalIconForFlashDrives = $OpenSubKey.GetValue('7',$null,'DoNotExpandEnvironmentNames')
                $OpenSubKey.Close()
            }
            catch {}

            if ( $GlobalIconForFlashDrives ) {  "#Green#{0} #DarkGray#| #Yellow#$GlobalIconForFlashDrives#" -f $(if ( $L.s9 ) { $L.s9 } else { 'Настроено' }) }
            else                             { '#Yellow#{0} #DarkGray#{1}#' -f $(if ( $L.s8 ) { $L.s8, $L.s8_1 } else { 'Не настроено', '(По умолчанию)' }) }
        }
        elseif ( $CheckState -eq 'DrivesWithIcons' )
        {
            [string[]] $DrivesIcons = [string[]] @()

            try
            {
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons')
                $DrivesIcons = $OpenSubKey.GetSubKeyNames()
                $OpenSubKey.Close()
            }
            catch {}

            [string[]] $DrivesWithIcons = [string[]] @()

            [string] $Icon = ''

            foreach ( $Drive in $DrivesIcons )
            {
                try { $Icon = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons\$Drive\DefaultIcon",'',$null)
                } catch { $Icon = '' }

                if ( $Icon ) { $DrivesWithIcons += "$Drive`:" }
            }

            if ( $DrivesWithIcons ) {  "#Green#{0} #DarkGray#| #Yellow#$($DrivesWithIcons -join ' ')#" -f $(if ( $L.s10 ) { $L.s10 } else { 'Настроены' }) }
            else                    { '#Yellow#{0} #DarkGray#{1}#' -f $(if ( $L.s11 ) { $L.s11, $L.s11_1 } else { 'Не настроены', '(По умолчанию)' }) }
        }

        Return
    }

    $text = if ( $L.s12 ) { $L.s12 } else { 'Настройка Иконок Дисков' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s13 ) { $L.s13 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Act -eq 'Set' )
    {
        # Получаем информацию по всем дискам в системе, и задаем глобальные переменные. Пропускаются пути с запрещёнными символами.
        [hashtable] $AllDrivesTable = Get-All-Drives

        if ( -not $AllDrivesTable.Values.Count )
        {
            Write-Host 'Get-PhysicalDisk: Error' -ForegroundColor Red
            Get-Pause ; Return
        }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-USB\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
        {
            [string] $PresetIconForUsbDrives = $Matches.IconPath.Trim()
        }
        else { [string] $PresetIconForUsbDrives = '' }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-System\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
        {
            [string] $PresetIconForSystemDrive = $Matches.IconPath.Trim()
        }
        else { [string] $PresetIconForSystemDrive = '' }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-Local\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
        {
            [string] $PresetIconForLocalDrives = $Matches.IconPath.Trim()
        }
        else { [string] $PresetIconForLocalDrives = '' }

        if ( $Global:AllLocalDrives -and $PresetIconForUsbDrives -and $PresetIconForLocalDrives -and $PresetIconForSystemDrive )
        {
            $text = if ( $L.s14 ) { $L.s14 } else { 'Установка' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s14_1 ) { $L.s14_1 } else { 'глобальных параметров иконок' }
            Write-Host "$text " -ForegroundColor Gray -NoNewline
            Write-Host '| ' -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s14_2 ) { $L.s14_2 } else { 'Для всех дисков' }
            Write-Host "$text" -ForegroundColor Green

            $text = if ( $L.s15 ) { $L.s15 } else { 'Иконка' }
            Write-Host "   $text USB: $PresetIconForUsbDrives`n" -ForegroundColor DarkGray

            [string] $Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons'
            [string] $Value = $PresetIconForUsbDrives
            Set-Reg New-ItemProperty -Path $Path -Name '7' -Type ExpandString $Value
            Set-Reg New-ItemProperty -Path $Path -Name '8' -Type ExpandString $Value

            if ( $is64 )
            {
                $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons'
                Set-Reg New-ItemProperty -Path $Path -Name '7' -Type ExpandString $Value
                Set-Reg New-ItemProperty -Path $Path -Name '8' -Type ExpandString $Value
            }

            $text = if ( $L.s16 ) { $L.s16 } else { 'Установка' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'индивидуальных иконок' }
            Write-Host "$text " -ForegroundColor Gray -NoNewline

            $text = if ( $L.s16_2 ) { $L.s16_2 } else { 'Локальным дискам' }
            Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($Global:AllLocalDrives.Where({ $_ -match '^[a-z]:$' }) -join ' ')" -ForegroundColor Green

            $text = if ( $L.s15 ) { $L.s15 } else { 'Иконка' }
            Write-Host "   $text System: $PresetIconForSystemDrive" -ForegroundColor DarkGray
            Write-Host "   $text Local:  $PresetIconForLocalDrives`n" -ForegroundColor DarkGray

            $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons\*'
            Set-Reg Remove-Item -Path $Path

            foreach ( $Drive in ( $Global:AllLocalDrives.Where({ $_ -match '^[a-z]:$' }) | Sort-Object ))
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Иконка для' }

                if ( $Drive -eq $env:SystemDrive )
                {
                    Write-Host "`n   $text System " -ForegroundColor DarkGray -NoNewline
                    $Value = $PresetIconForSystemDrive
                }
                else
                {
                    Write-Host "`n   $text Local " -ForegroundColor DarkGray -NoNewline
                    $Value = $PresetIconForLocalDrives
                }

                Write-Host "$Drive`n" -ForegroundColor Green

                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons\$($Drive.Trim(':'))\DefaultIcon"

                Set-Reg New-ItemProperty -Path $Path -Name '' -Type ExpandString $Value
            }

            if ( $Global:AllRamDrives )
            {
                # Пропускаются пути с запрещёнными символами.
                if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Drives-Icon-RAM\s*=\s*1\s*=\s*(?<IconPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' },'First') )
                {
                    [string] $PresetIconForRamDrives = $Matches.IconPath.Trim()
                }
                else { [string] $PresetIconForRamDrives = '' }

                if ( $PresetIconForRamDrives )
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { 'Установка' }
                    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                    $text = if ( $L.s18_1 ) { $L.s18_1 } else { 'индивидуальных иконок' }
                    Write-Host "$text " -ForegroundColor Gray -NoNewline

                    $text = if ( $L.s18_2 ) { $L.s18_2 } else { 'RAM дискам' }
                    Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($Global:AllRamDrives.Where({ $_ -match '^[a-z]:$' }) -join ' ')" -ForegroundColor Green

                    $text = if ( $L.s15 ) { $L.s15 } else { 'Иконка' }
                    Write-Host "   $text RAM: $PresetIconForRamDrives" -ForegroundColor DarkGray

                    $Value = $PresetIconForRamDrives

                    foreach ( $Drive in ( $Global:AllRamDrives.Where({ $_ -match '^[a-z]:$' }) ))
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { 'Иконка для' }
                        Write-Host "`n   $text RAM " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$Drive`n" -ForegroundColor Green

                        $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons\$($Drive.Trim(':'))\DefaultIcon"

                        Set-Reg New-ItemProperty -Path $Path -Name '' -Type ExpandString $Value
                    }
                }
                else
                {
                    $text = if ( $L.s6 ) { $L.s6 } else { 'Не задана иконка для RAM дисков в пресете' }
                    Write-Warning "`n$NameThisFunction`: $text"
                }
            }
        }
        else
        {
            $text = if ( $L.s19 ) { $L.s19 } else { 'Не найдены Локальные диски или не заданы иконки для Локальных/USB дисков' }
            Write-Warning "`n$NameThisFunction`: $text"
        }
    }
    elseif ( $Act -eq 'Default' )
    {
        $text = if ( $L.s20 ) { $L.s20 } else { 'Восстановление' }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s20_1 ) { $L.s20_1 } else { 'иконок' }
        Write-Host "$text " -ForegroundColor Gray -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s20_2 ) { $L.s20_2 } else { 'Для всех дисков' }
        Write-Host "$text`n" -ForegroundColor Green

        $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons'
        Set-Reg Remove-Item -Path $Path

        if ( $is64 )
        {
            $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\Shell Icons'
            Set-Reg Remove-Item -Path $Path
        }

        $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\DriveIcons\*'
        Set-Reg Remove-Item -Path $Path
    }
    else
    {
        $text = if ( $L.s21 ) { $L.s21 } else { '''Check'' не предусмотрен для ''Настройки иконок дисков''' }
        Write-Host "   $text" -ForegroundColor DarkGray
    }

    $text = if ( $L.s22 ) { $L.s22 } else { 'Все выполнено' }
    Write-Host "`n   $text " -ForegroundColor Green -NoNewline
    Write-Host '| ' -ForegroundColor DarkGray -NoNewline

    $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'Нужен перезапуск Проводника' }
    Write-Host "$text" -ForegroundColor White

    Get-Pause
}
