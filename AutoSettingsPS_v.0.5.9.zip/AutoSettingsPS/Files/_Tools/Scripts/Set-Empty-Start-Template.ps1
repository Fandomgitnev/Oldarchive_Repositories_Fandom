﻿
<#
.SYNOPSIS
 Установка Пустого макета Пуска

.DESCRIPTION
.EXAMPLE
.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  18.04.2023
 ===============================================

#>
Function Set-Empty-Start-Template {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
       ,
        [Parameter( Mandatory = $false )]
        [switch] $OnlyDefault
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Проверка' }
    }
    elseif ( $Act -eq 'Set' )
    {
        $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'Установка' }
    }
    else
    {
        $text = if ( $L.s1_2 ) { $L.s1_2 } else { 'Удаление' }
    }

    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s2 ) { $L.s2 } else { 'Пустой шаблон Пуска без ярлыков' }
    Write-Host "| $text " -ForegroundColor DarkCyan -NoNewline

    $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    [string] $FileBin = "$FileFolderGlobal\start.bin"

    if ( [System.Environment]::OSVersion.Version.Build -lt 22000 )
    {
        $text = if ( $L.s3 ) { $L.s3 } else { 'Не поддерживается в этой версии Windows' }
        Write-Host "`n   $text" -ForegroundColor DarkGray
            
        Return
    }

    # Профили
    [array] $Accs = @()

    @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' -and $_.SID },'First')).ForEach({

        $Accs = [PSCustomObject] @{
            Name     = $_.Name
            FullName = '{0}\{1}' -f $env:USERDOMAIN, $_.Name
            Root     = 'Registry::HKU\{0}' -f $_.SID
            Profile  = $_.Profile
            SID      = $_.SID
            Source   = 'Local'
        }
    })

    if ( $Act -ne 'Default' )
    {
        if ( -not [System.IO.File]::Exists($FileBin) )
        {
            Write-Host "`n   Error: Not found '$FileBin'" -ForegroundColor Red

            Return
        }

        if ( -not $OnlyDefault )
        {
            Token-Impersonate -Reset

            $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
            if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

            $Accs += [PSCustomObject] @{
                Name     = $env:USERNAME
                FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
                Root     = 'HKCU:'
                Profile  = $env:USERPROFILE
                SID      = $SID
                Source   = $Source
            }

            if ( $Global:DataAllUsers.Redirects.Value )
            {
                @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

                    $Accs += [PSCustomObject] @{
                        Name     = $_.Name
                        FullName = $_.FullName
                        Root     = $_.SID
                        Profile  = $_.Profile
                        SID      = $_.SID
                        Source   = $_.Source
                    }
                })
            }
        }

        if ( $Act -eq 'Check' ) { $Color = 'Yellow' } else { $Color = 'Red' }

        foreach ( $Acc in $Accs )
        {
            $NameUser = $Acc.Name
            $Profile  = $Acc.Profile

            Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
            Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

            [string] $Path = '{0}\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\LocalState' -f $Profile

            Write-Host "   Copy: $FileBin" -ForegroundColor DarkGray
            Write-Host "   Dest: $Path\start.bin" -ForegroundColor DarkGray

            if ( $Act -ne 'Check' )
            {
                if ( -not [System.IO.Directory]::Exists($Profile) )
                {
                    Write-Host "   Error: Profile folder not found: '$Profile'" -ForegroundColor Red
                
                    Continue
                }

                try
                {
                    if ( -not [System.IO.Directory]::Exists($Path) )
                    {
                        New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop > $null
                    }
                    else
                    {
                        Remove-Item -Path \\?\$Path\* -Recurse -Force -ErrorAction SilentlyContinue
                    }

                    Copy-Item -Path $FileBin -Destination $Path -Force -ErrorAction Continue

                    [System.IO.File]::WriteAllText("$Path\88000530",'{"content":[{"items":[{}]}]}',[System.Text.UTF8Encoding]::new($false)) # UTF-8 без BOM в 1 строку
                }
                catch
                {
                    Write-Host "   Error: folder: '$Path'" -ForegroundColor Red
                }
            }

            if ( -not [System.IO.File]::Exists("$Path\start.bin") )
            {
                $text = if ( $L.s4 ) { $L.s4 } else { 'Шаблон пуска не установлен' }
                Write-Host "   $text" -ForegroundColor $Color

                $NeedFix = $true
            }
            else
            {
                $text = if ( $L.s5 ) { $L.s5 } else { 'Шаблон пуска установлен' }
                Write-Host "   $text" -ForegroundColor Green

                if (( $Act -eq 'Set' ) -and ( $Acc.Root -eq 'HKCU:' ))
                {
                    Stop-Process -Name StartMenuExperienceHost -Force -ErrorAction SilentlyContinue
                }
            }
        }
    }
    else
    {
        # Удаление только у дефолтного аккаунта

        $NameUser = $Accs[0].Name
        $Profile  = $Accs[0].Profile

        Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
        Write-Host "| $($Accs[0].Source): $($Accs[0].FullName) ($($Accs[0].SID))`n" -ForegroundColor DarkGray

        [string] $Path = '{0}\AppData\Local\Packages\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy' -f $Profile

        Write-Host "   Remove: $Path" -ForegroundColor DarkGray

        if ( [System.IO.Directory]::Exists($Path) )
        {
            Remove-Item -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    $text = if ( $L.s6 ) { $L.s6 } else { 'Завершено' }
    Write-Host "`n   $text" -ForegroundColor DarkGray
}
