﻿
<#
.SYNOPSIS
 Отображение данных или Установка обновлений из файлов CAB
 на текущую рабочую систему.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Используется функция Write-HostColor, для вывода информации.
 Используется утилита 7-zip для распаковки и получения данных из CAB без распаковки.

 Если обновление будет найдено в системе, то будет ожидание нажатия клавиши с цифрой "1"
 в течении 20 секунд, для подтверждения повторной установки обновления, либо будет пропуск установки.
 Также для пропуска установки можно нажать любую другую клавишу.

 Происходит распаковка файла CAB/ESD/WIM во временную папку, и далее его Установка.

 Есть возможность обновить интегрированные в EnterpriseS/EnterpriseSN (LTSC) пакеты из полных редакций,
 которые не обновляются кумулятитвными обновлениями, так как не входят в комплект редакции и так же исключены из обновлений.
 Не все пакеты исключены из обновлений. Например исключён Классик Edge UWP, он нужен для использования режима киоска на LTSC.
 Накопительные обновления при установке обновляют существующие на данный момент пакеты, которые подходят для редакции.
 И пропускают если они исключены из обновлений либо уже обновлены этим или более новым кумулятивом.
 Если добавится компонент в системе, то кумулятив при повторной установке обновит только его.
 Это же происходит когда ЦО ставит обновление повторно и не один раз, это связано с добавленными компонентами,
 включёнными, изменёнными, добавленными языковыми файлами, или интегрированными просле установки кумулятива.

 Суть обновления исключённых компонентов заключается в правильной временной регистрации полного пакета CBS, как в Enterprise/Pro
 Далее обычная установка кумулятива поверх, он обновит только исключенные пакеты,
 так как только они будут не обновлены после обычной установки. И удалении временной регистрации CBS от полной редакции. Всё.

 Если после этого поставить в обычном режиме ещё раз этот же кумулятив или более новый,
 то исключённые компоненты будут восстановлены к изначальной версии.
 Поэтому нужно их обновлять каждый раз после обычной установки кумулятива!

.PARAMETER UpdatesFolder
 Папка где лежат файлы CAB/ESD/WIM, ищет файлы без рекурсии.
 По умолчанию указана глобальная переменная с путём.
 Необходимый параметр!

.PARAMETER DismScratchDir
 Временная папка для Dism.
 По умолчанию указана глобальная переменная.

.PARAMETER Install
 Указывает выполнить установку.

.PARAMETER ShowHotFix
 Указывает вывести установленные обновления в системе.

.EXAMPLE
    Install-Offline-UpdateFilesCAB -UpdatesFolder D:\Updates

    Описание
    --------
    Ищет все файлы CAB/ESD/WIM в указанной папке без рекурсии и выводит информацию о них.

.EXAMPLE
    Install-Offline-UpdateFilesCAB -UpdatesFolder D:\Updates -Install

    Описание
    --------
    Ищет все файлы CAB/ESD/WIM в указанной папке, выводит информацию о них.
    Если разрядность и версия подходит, то устанавливает.
    Если уже было установлено, то будет запрос на подтверждение повторной установки.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  28.03.2019
 ===============================================

#>
Function Install-Offline-UpdateFilesCAB {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, ParameterSetName = 'Cab', Position = 0 )]
        [string] $UpdatesFolder = $UpdatesFolderGlobal
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Cab', Position = 1 )]
        [string] $DismScratchDir = $DismScratchDirGlobal
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Cab', Position = 2 )]
        [switch] $Install   # Выполнить установку.
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Cab', Position = 3 )]
        [switch] $UpdateFullPkg  # Обновить интегрированные пакеты из полных редакций
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'ShowHotFix' )]
        [switch] $ShowHotFix
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Проверка папки для обновлений.
    $text = if ( $L.s1 ) { $L.s1 } else { 'Папка для обновлений не существует' }
    if ( -not [System.IO.Directory]::Exists($UpdatesFolder) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$UpdatesFolder'" ; Return }  # Выход из функции.

    $text = if ( $L.s2 ) { $L.s2 } else { 'Не указан или не найден файл 7z.exe' }
    if ( -not [System.IO.File]::Exists($7z) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$7z'" ; Return }  # Выход из функции.

    [string] $Dism = 'Dism.exe'

    # Проверка временной папки для dism.
    $text = if ( $L.s3 ) { $L.s3 } else { 'Не указана или не найдена временная папка для Dism.exe' }
    if ( -not [System.IO.Directory]::Exists($DismScratchDir) )
    { Write-Warning "`n$NameThisFunction`: $text`: '$DismScratchDir'" ; Return }  # Выход из функции.

    [string] $BuildOS = [System.Environment]::OSVersion.Version.Build
    if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $ArchOS = 'x64' } else { [string] $ArchOS = 'x86' }

    [string[]] $MUILangsOS = $null

    try
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\MUI\UILanguages')
        $MUILangsOS = $OpenSubKey.GetSubKeyNames()
        $OpenSubKey.Close()
    }
    catch {}

    # Если указано вывести список установленных обновлений системы.
    if ( $ShowHotFix )
    {
        $text = if ( $L.s4 ) { $L.s4 } else { 'Не установлено' }

        [int] $N = 0
        foreach ( $Fix in ( Get-Hotfix | Sort-Object HotFixID ))
        {
            $N++
            Write-Host "$N. kb".PadLeft(13,' ') -ForegroundColor DarkGray -NoNewline
            Write-Host "$( try { $Fix.HotFixID.Replace('KB','') } catch { '-------' } )" -ForegroundColor Green -NoNewline
            Write-Host " | $( try { $Fix.InstalledOn.ToShortDateString().PadRight(10,' ').Substring(0,10) } catch { "--.--.---- | $text" } ) | $($Fix.Description)" -ForegroundColor DarkGray
        }

        Return   # Выход из функции.
    }

    # Функция для ожидания получения нажатия клавиши, указанного количества секунд (только для консоли).
    Function Wait-PressKey ( [string] $Text, [int] $SecondsToWait ) {

        [int] $Seconds = 0 ; [int] $ms = 0 ; $Host.UI.RawUI.FlushInputBuffer()
        Write-Host "$Text " -NoNewline
        while ( $Seconds -lt $SecondsToWait )
        {
            if ( $host.UI.RawUI.KeyAvailable )
            {
                $Pressedkey = ($host.ui.RawUI.ReadKey('NoEcho,IncludeKeyUp')).Character
                break
            }
            Start-Sleep -Milliseconds 100 ; $ms += 100
            if ( $ms -eq 1000 ) { $Seconds++ ; $ms = 0 ; Write-Host '.' -ForegroundColor Yellow -NoNewline }
        }
        $Pressedkey
    }


    if ( $Install )
    {
        $text = if ( $L.s5 ) { $L.s5 } else { 'Начало установки файлов CAB/ESD/WIM' }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s5_1 ) { $L.s5_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }


    Function Get-ProPackageData {

        [int] $Build = [System.Environment]::OSVersion.Version.Build

        [array] $PkgInfo = @()

        if ( $Build -ge 17763 )
        {
            try
            {
                  [string] $RegKey     = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'
                [psobject] $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $ArchPkg = 'amd64' } else { [string] $ArchPkg = 'x86' }

                  [string] $PkgData         = ''
                  [string] $ProPkgName      = ''
                  [string] $PkgVers         = ''
                [psobject] $InstallTimeHigh = $null
                [psobject] $InstallTimeLow  = $null

                # Поиск раздела
                foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                {
                    #if ( $SubKey -match "^Microsoft-Windows-EnterpriseS[N]?Edition~(?<PkgData>[^~]+~$ArchPkg~~[0-9.]+)$" )
                    if ( $SubKey -match "^Microsoft-Windows-EnterpriseS[N]?Edition~(?<PkgData>[^~]+~$ArchPkg)~~(?<Version>[0-9.]+)$" )
                    {
                        [psobject] $OpenSubKey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                        $PkgData = $Matches.PkgData
                        $PkgVers = $Matches.Version

                        if ( $OpenSubKey )
                        {
                            if ( $OpenSubKey.GetValue('CurrentState',$null) -like 112 )
                            {
                                $ProPkgName      = "Microsoft-Windows-ProfessionalEdition~$PkgData"
                                $InstallTimeHigh = $OpenSubKey.GetValue('InstallTimeHigh',0)
                                $InstallTimeLow  = $OpenSubKey.GetValue('InstallTimeLow',0)

                                $OpenSubKey.Close()

                                break
                            }

                            $OpenSubKey.Close()
                        }
                    }
                }

                $OpenRegKey.Close()
            }
            catch {}

            if ( $ProPkgName -and $PkgVers -and $InstallTimeHigh -and $InstallTimeLow )
            {
                $PkgInfo = New-Object PsObject -Property @{

                    'ProPkgName'      = $ProPkgName
                    'Version'         = $PkgVers
                    'InstallTimeHigh' = $InstallTimeHigh
                    'InstallTimeLow'  = $InstallTimeLow
                }
            }
        }

        $PkgInfo
    }


        # Временный показ надписи про ожидание
      [char] $Escape          = 27
       [int] $StringsExcl     = 2              # Количество последних строк для затирания.
    [string] $HideCursor      = "$Escape[?25l"
    [string] $ShowCursor      = "$Escape[?25h"
    [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
    [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

    $text = if ( $L.s29 ) { $L.s29 } else { 'Получение данных у файлов обновлений ...' }
    Write-Host "        $text `n" -ForegroundColor DarkCyan



    # Получение информации обо всех файлах CAB/ESD/WIM из их внутренних файлов update.mum, без распаковки.
    [hashtable] $CabFilesData = @{}
    [int] $CabNumber = 0
    (Get-ChildItem -File -LiteralPath \\?\$UpdatesFolder -Force -ErrorAction SilentlyContinue).Where({ $_.Name -match '[.](cab|esd|wim)$' }).Name | Sort-Object | ForEach-Object {

        $CabFile = "$UpdatesFolder\$_"
        $CabArch = ''
        [xml] $MumFile = ''
        $PSFXv2 = $false

        # Извлекаем данные из файла update.mum из текущего архива без распаковки.
        try { [xml] $MumFile = & $7z e "$CabFile" update.mum -so -sccUTF-8 2> $null } catch {}

        if ( $MumFile )
        {
            # Получение всех версий из XML, затем получение только одной первой, которая подходит под шаблон.
            $Versions = @()
            $Versions += $MumFile.GetElementsByTagName('package').customInformation.version
            $Versions += $MumFile.GetElementsByTagName('assemblyIdentity').version

            $CabVers = $Versions.Where({ $_ -match '\d+\.(\d\d+)\.' },'First')

            # Получение разрядности CAB/ESD/WIM файла.
            $CabArch     = $MumFile.GetElementsByTagName('assemblyIdentity').processorArchitecture | Select-Object -First 1
            $CabArchOrig = $CabArch

            if ( $CabArch -eq 'amd64' ) { $CabArch = 'x64' }

            $CabName = [System.IO.Path]::GetFileName($CabFile)
            $FileExt = [System.IO.Path]::GetExtension($CabFile).Trim('.').ToUpperInvariant()

            $CabType = $MumFile.assembly.package.identifier
            $CabLang = $MumFile.assembly.assemblyIdentity.language
            $CabIdentName = $MumFile.assembly.assemblyIdentity.name
            $CabIdentVers = $MumFile.assembly.assemblyIdentity.version
            $CabCU   = $( if ( $CabIdentName -eq 'Package_for_RollupFix' ) { 'CU' } else { '' } )  # Cumulative Update
            $CabStac = $( if ( $MumFile.assembly.package.permanence -eq 'permanent' ) { 'ServiceStack' } else { '' } )
        }
        else
        {
            try
            {
                $Build   = 0
                $CabInfo = & $7z l "$CabFile" -so -sccUTF-8 2> $null
                $Build   = @([regex]::Match($CabInfo,'SSU-(?<Build>[\d]+)').Groups).Where({ $_.Name -eq 'Build'}).Value
            }
            catch {}

            if ( $Build -ge 22000 )
            {
                foreach ( $i in ( $CabInfo -like '*KB*.cab' ))
                {
                    if ( $i -match '^(?<date>[\d.\/-]{10})[^\r\n]+KB(?<KB>[\d]{7})-(?<Arch>x[\d]{2})[.]cab$' )
                    {
                        $Date    = $Matches.date
                        $KB      = $Matches.KB
                        $CabArch = $Matches.Arch

                        break
                    }
                }

                if ( $KB -and $CabArch )
                {
                    if     ( $CabArch -eq 'x64' ) { $CabArchOrig = 'amd64'  }
                    elseif ( $CabArch -eq 'x86' ) { $CabArchOrig = 'x86'    }
                    else                          { $CabArchOrig = $CabArch }

                    $CabName = [System.IO.Path]::GetFileName($CabFile)
                    $FileExt = [System.IO.Path]::GetExtension($CabFile).Trim('.').ToUpperInvariant()

                    $CabType = "KB$KB"
                    $CabLang = 'neutral'

                    try
                    {
                        $ExtractFolder = "$UpdatesFolder\$KB`_tempCab"
                        & $7z e "$CabFile" -o"$ExtractFolder" *Metadata.cab -aoa -bso0 -bse0 -bsp0
                        & $7z e "$ExtractFolder\*Metadata.cab" -o"$ExtractFolder" LCU*.xml.cab -aoa -bso0 -bse0 -bsp0
                        [xml] $CabXML = & $7z e "$ExtractFolder\LCU*.xml.cab" LCU*.xml -so -sccUTF-8 2> $null
                    }
                    catch {}

                    $CabIdentName = $CabXML.CompDB.Packages.package.ID
                    $CabIdentVers = @($CabXML.CompDB.Packages.package.version).Where({$_},'First')
                    $CabVers      = @($CabXML.CompDB.TargetOSVersion).Where({$_},'First')

                    $CabCU   = 'CU' # Cumulative Update
                    $CabStac = ''
                    $PSFXv2 = $true

                    Remove-Item -LiteralPath $ExtractFolder -Force -Recurse -ErrorAction SilentlyContinue
                }
            }
        }


        # Если XML данные получены, добавляем в хэштаблицу из текущего CAB/ESD/WIM, хэштаблицу с полным путем к файлу CAB/ESD/WIM и его данными в XML.
        # иначе уменьшаем порядковый номер CAB/ESD/WIM на 1, для пропуска неправильного файла CAB/ESD/WIM.
        if ( $CabArch )
        {
            $CabNumber++

            $CabTypeReName = $CabType
            $isInstall     = $false
            $isSuperseded  = $false
            $isPending     = $false
            $isFits        = $false
            $GiveChoice    = $false

            # Переименование названий CAB/ESD/WIM для отображения, и проверка наличия в системе.

            if (( $CabType -like '*NET Framework 3*' ) -and ( $CabIdentName -like '*OnDemand*' ))
            {
                $CabTypeReName = 'NetFx3 OnDemand'

                $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'

                if ( $CabLang -ne 'neutral' )
                {
                    $CabTypeReName = 'NetFx3 OnDemand Lang'
                    $isNetFx3Lang = $null

                    try
                    {
                        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages)
                        $isNetFx3Lang = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like "Microsoft-Windows-NetFx3-OnDemand-Package~*~$CabArchOrig~$CabLang~$CabVers" })
                        $OpenSubKey.Close()
                    }
                    catch {}

                    if ( $isNetFx3Lang ) { $isInstall = $true }
                }
                else
                {
                    $isNetFx3 = $null

                    try
                    {
                        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages)
                        $isNetFx3 = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like "Microsoft-Windows-NetFx3-OnDemand-Package~*~$CabArchOrig~~$CabVers" })
                        $OpenSubKey.Close()
                    }
                    catch {}

                    if ( $isNetFx3 ) { $isInstall = $true }
                }
            }
            elseif ( $CabType -eq 'Language Pack' )
            {
                $CabTypeReName = '{0}' -f $(if ( $L.s10 ) { $L.s10 } else { 'Языковой пакет' })

                if ( $MUILangsOS -like $CabLang ) { $isInstall = $true }
            }
            elseif ( $CabCU )
            {
                # Если кумулятивное обновление

                try
                {
                    [string] $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing'

                    $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKeyPackages\Packages",'ReadSubTree','QueryValues,EnumerateSubKeys')

                    if ( $OpenKey )
                    {
                        $SubKeyName = @($OpenKey.GetSubKeyNames()).Where({ $_ -like "*$CabType*" },'First')

                        if ( $SubKeyName )
                        {
                            $OpenSubKey = $OpenKey.OpenSubKey("$SubKeyName\Owners",'ReadSubTree','QueryValues')

                            if ( $OpenSubKey )
                            {
                                $RollupFixName = @($OpenSubKey.GetValueNames()).Where({ $_ -like '*Package_for_RollupFix*' },'First')

                                if ( $RollupFixName )
                                {
                                    if ( [string][Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKeyPackages\PackagesPending\$RollupFixName",'','NoParam') )
                                    {
                                        $isPending = $true
                                    }
                                    else
                                    {
                                        $CurrentState = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKeyPackages\Packages\$RollupFixName",'CurrentState',0)

                                        if ( $CurrentState -eq 112 )
                                        {
                                            $isInstall = $true
                                        }
                                        elseif ( $CurrentState -eq 80 )
                                        {
                                            $isSuperseded = $true
                                        }
                                    }
                                }

                                $OpenSubKey.Close()
                            }
                        }

                        $OpenKey.Close()
                    }
                }
                catch {}
            }
            elseif ( $CabType -match 'KB\d{7}' )
            {
                # Если тип архива - Обновление, и просто с номером KB, то проверяем наличие в системе по номеру.

                $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'
                $isExist = $null

                try
                {
                    $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages)
                    $isExist = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like "*$CabType*" })
                    $OpenSubKey.Close()
                }
                catch {}

                if ( $isExist ) { $isInstall = $true }
            }
            elseif (( "$CabType".Length ) -and ( "$CabVers".Length ) -and ( -not ( "$CabLang" -like '*-*' )))
            {
                # Если тип архива - Обновление, и просто имеет название, то проверяем наличие в системе по имени и версии.

                $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'
                $isExist = $null

                try
                {
                    $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages)
                    $isExist = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like "*$CabType*~$CabArchOrig~~$CabVers" })
                    $OpenSubKey.Close()
                }
                catch {}

                if ( $isExist ) { $isInstall = $true }
            }
            elseif ( "$CabIdentName".Length -and "$CabLang" -like '*-*' -and "$CabVers".Length )
            {
                # Если тип архива - языковой пакет для другого пакета, то проверяем наличие в системе по описанию + языку.

                $SubKeyPackages = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages'

                $isExist = $null

                try
                {
                    $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKeyPackages)
                    $isExist = @($OpenSubKey.GetSubKeyNames()).Where({ $_ -like "*$CabIdentName*~$CabArchOrig~$CabLang~$CabVers" })
                    $OpenSubKey.Close()
                }
                catch {}

                if ( $isExist ) { $isInstall = $true }
            }


            # Далее анализ данных файлов CAB/ESD/WIM и вывод на экран ...

            try
            {
                [int64] $BuildLab = 9999999999 # Если версия билдлаб не будет, чтобы не совпадало
                $BuildLab = [regex]::Match([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion',
                    'BuildLab',$BuildLab),'^\d+','IgnorePatternWhitespace').Value
            }
            catch { [int64] $BuildLab = 9999999999 }

            # Определение подходит ли CAB/ESD/WIM к системе.
            # Версия у NET 4.8 занижена, но подходит для RS5, поэтому добавлено понимание, так как по версии не совпадает.
            if ( $CabType -like '*4486153*' )
            {
                $CabTypeReName = '.NET Framework 4.8'

                if (( $CabArch -eq $ArchOS ) -and ( 17763 -eq $BuildOS )) { $isFits = $true }
            }
            elseif ( $CabType -like '*4486174*' )
            {
                $CabTypeReName = '.NET Fw Language 4.8'

                if (( $CabArch -eq $ArchOS ) -and ( 17763 -eq $BuildOS )) { $isFits = $true }
            }
            elseif (( $CabVers -match "$BuildOS|$BuildLab" ) -and ( $CabArch -eq $ArchOS )) { $isFits = $true }



            if ( $CabLang -eq 'neutral' ) { $CabLang = '•••••••' ; $ColorLang = 'DarkGray' } else { $ColorLang = 'White' }

            if ( $CabArch -eq 'x64' ) { $ArchColor = 'Green' } else { $ArchColor = 'Yellow' }

            $ColorState = 'DarkGray'

            if ( $isFits -and $isPending )
            {
                $ColorState = 'DarkYellow'

                $State = "#$ColorState#{0} #DarkGray#| #Mage#{1}" -f $(if ( $L.s6 ) { $L.s6, $L.s6_1 } else     { 'В ожидании ', 'Запрос   ' })

                $GiveChoice = $true
            }
            elseif ( $isFits -and $isSuperseded )
            {
                $ColorState = 'DarkGreen'

                $State = "#$ColorState#{0} #DarkGray#| #Mage#{1}" -f $(if ( $L.s6_2 ) { $L.s6_2, $L.s6_1 } else { 'Заменён    ', 'Запрос   ' })

                $GiveChoice = $true
            }
            elseif ( $isFits -and $isInstall )
            {
                $ColorState = 'Green'

                $State = "#$ColorState#{0} #DarkGray#| #Mage#{1}" -f $(if ( $L.s7 ) { $L.s7, $L.s7_1 } else     { 'Установлен ', 'Запрос   ' })

                $GiveChoice = $true
            }
            elseif ( $isFits )
            {
                $ColorState = 'Blue'

                $State = "#$ColorState#{0} #DarkGray#| #Gray#{1}" -f $(if ( $L.s8 ) { $L.s8, $L.s8_1 } else     { 'Подходит   ', 'Установка' })
            }
            else
            {
                $ColorState  = 'Red'

                $State = "#$ColorState#{0} #DarkGray#| {1}"       -f $(if ( $L.s9 ) { $L.s9, $L.s9_1 } else     { 'Не подходит', 'Пропуск  ' })
            }

            $NameColor = 'DarkGray'
            $CU = ''

            $text = if ( $L.s11 ) { $L.s11 } else { 'Накопительное обновление CU' }
            if ( $CabCU ) { $CU = "#DarkGray#| #DarkCyan#$text" ; $NameColor = 'DarkCyan' }

            # часть результата для вывода на экран.
            [string] $ResultInfo = "#$ColorState#$FileExt#DarkGray#: #White#{0} #DarkGray#|#$ArchColor# $CabArch #DarkGray#| #$ColorLang#{1} #DarkGray#| {2} #DarkGray#| $State #DarkGray#| {3} | $CabIdentName | $CabType | #$NameColor#$CabName $CU#"

            $ResultInfo = $ResultInfo -f
                $CabTypeReName.PadRight(20,' ').Substring(0,20),
                $CabLang.PadRight(7,' ').Substring(0,7),
                $CabVers.PadRight(16,' '),
                $CabIdentVers.PadRight(16,' ')

            if ( $CabCU )
            {
                # Затемнение букв 'KB' заменой у $CabTypeName с KB0000000 на буквы 'kb' темно-серого цвета. И добавление метки накопительного обновления.
                $ResultInfo = $ResultInfo -Replace (':\s#White#KB(\d{7})   ',': #DarkGray#kb#DarkCyan#$1 #Cyan#CU')
            }
            elseif ( $CabStac )
            {
                # Затемнение букв 'KB' заменой у $CabTypeName с KB0000000 на буквы 'kb' темно-серого цвета. И добавление метки Service Stack.
                $ResultInfo = $ResultInfo -Replace (':\s#White#KB(\d{7})          ',': #DarkGray#kb#DarkCyan#$1 #Cyan#ServStack')
            }
            else
            {
                # Затемнение букв 'KB' заменой у $CabTypeName с KB0000000 на буквы 'kb' темно-серого цвета.
                $ResultInfo = $ResultInfo -Replace ('\|\s#White#KB(\d{7})','| #DarkGray#kb#White#$1')
            }

            # Добавляем в хэштаблицу данные из текущего CAB/ESD/WIM.
            $CabFilesData[$CabNumber] = @{
                CabFile    = $CabFile
                CabName    = $CabName
                CabType    = $CabType
                CabCU      = $CabCU
                IdentName  = $CabIdentName
                IdentVers  = $CabIdentVers
                ServStack  = $CabStac
                isFits     = $isFits
                isInstall  = $isInstall
                isPending  = $isPending
                GiveChoice = $GiveChoice
                ResultInfo = $ResultInfo
                PSFXv2    = $PSFXv2
            }
        }
    }


    # Сортировка cab
    try
    {
        # Создаем временную таблицу с накопительными обновлениями (CU - Cumulative Update), отсортированными между собой по номеру обновления,
        # и языковыми файлами LIP, и Stack заданными начиная с -6000, -4000 и -2000 номера списка,
        # чтобы быть в итоге Stack был в начале, затем все LIP, затем CU, и далее все остальные.
        [hashtable] $CabFilesCU   = @{}
        [hashtable] $CabFilesLang = @{}
        [hashtable] $CabServStack = @{}
        ($CabFilesData.Values | Sort-Object { $_.CabName }).Foreach({
             if     ( $_['ServStack'] )                   { $CabServStack[$CabServStack.Count + -6000] = $_ }
             elseif ( $_['CabType'] -eq 'Language Pack' ) { $CabFilesLang[$CabFilesLang.Count + -4000] = $_ }
             elseif ( $_['CabCU'] )                       { $CabFilesCU[$CabFilesCU.Count + -2000] = $_ }
        })

        # Создаем временную таблицу с обновлениями, кроме накопительных, без сортировки, то есть с полученной сортировкой по имени файла.
        # Чтобы оставить возможность указания сортировки по имени файлов для всех остальных обновлений.
        # Для этого обновления задаются под теми же полученными номерами списка таблицы.
        [hashtable] $CabFilesDataTemp = @{}
        $CabFilesData.Keys.Foreach({
             if ( -not ( $CabFilesData[$_]['CabCU'] -or ( $CabFilesData[$_]['CabType'] -eq 'Language Pack' ) -or $CabFilesData[$_]['ServStack'] ))
             { $CabFilesDataTemp[$_ + 2000] = $CabFilesData[$_] }
        })
        # Создаем полную временную таблицу с отсортированными по имени обновлениями и своим порядком в списке
        $CabFilesDataTemp += $CabServStack # № 0+ | обычные № -6000+
        $CabFilesDataTemp += $CabFilesLang # № -4000+
        $CabFilesDataTemp += $CabFilesCU   # № -2000+

        # Обнуляем итоговую таблицу.
        $CabFilesData = @{}

        # Сортируем временную полную таблицу, и назначаем нормальную последовательность списку обновлений в итоговой таблице: 1,2,3, ...
        # Накопительные будут в конце списка и отсортированы между собой по номеру обновления,
        # остальные будут в той же последовательности в начале общего списка.
        $CabFilesDataTemp.Keys | Sort-Object | ForEach-Object { $CabFilesData[$CabFilesData.Count + 1] = $CabFilesDataTemp[$_] }
    }
    catch {}


    Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

    [bool] $isInstalled = $false

    foreach ( $CabN in ( $CabFilesData.Keys | Sort-Object ))
    {
        # Если порядковый номер файла меньше 10, добавление пробела перед номером.
        if ( $CabN -lt 10 ) { $Space = ' ' } else { $Space = '' }

        [string] $ResultInfo2 = "       $Space#DarkGray#$CabN. $($CabFilesData[$CabN].ResultInfo)"

        if ( -not $Install ) { Write-HostColor $ResultInfo2 }
        else
        {
            $ResultInfo2 = "   $Space#DarkGray#$CabN. $($CabFilesData[$CabN].ResultInfo)"

            $CabFile = $CabFilesData[$CabN].CabFile
            $CabName = $CabFilesData[$CabN].CabName

            if ( -not $CabFilesData[$CabN].isFits )
            {
                $text = if ( $L.s11_1 ) { $L.s11_1 } else { 'Файл Не подходит' }
                Write-Host "`n██  $text " -ForegroundColor DarkYellow -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                Write-Host "$CabName`n" -ForegroundColor DarkYellow

                Write-HostColor $ResultInfo2

                Continue  # Переход к следующей итерации foreach
            }
            elseif ( $UpdateFullPkg -and ( -not $CabFilesData[$CabN].CabCU ))
            {
                $text = if ( $L.s11_2 ) { $L.s11_2 } else { 'Файл не накопительное обновление' }
                Write-Host "`n██  $text " -ForegroundColor DarkYellow -NoNewline
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                Write-Host "$CabName`n" -ForegroundColor DarkYellow

                Write-HostColor $ResultInfo2

                Continue  # Переход к следующей итерации foreach
            }

            $text = if ( $L.s12 ) { $L.s12 } else { 'Установка' }
            Write-Host "`n██  $text " -ForegroundColor Cyan -NoNewline
            Write-Host '| ' -ForegroundColor DarkGray -NoNewline
            Write-Host "$CabName`n" -ForegroundColor DarkCyan

            Write-HostColor $ResultInfo2

            # Если нужно дать выбор повторной установки файла.
            if ( $CabFilesData[$CabN].GiveChoice -and ( -not $UpdateFullPkg ))
            {
                $text = if ( $L.s13 ) { $L.s13 } else { 'Для повторной установки обновления' }
                Write-Host "`n    $text " -ForegroundColor Yellow -NoNewline

                $text = if ( $L.s13_1 ) { $L.s13_1 } else { 'нажмите клавишу с цифрой' }
                Write-Host "$text`: " -ForegroundColor DarkGray  -NoNewline
                Write-Host '1' -ForegroundColor Cyan

                $text = if ( $L.s14 ) { $L.s14 } else { 'Для пропуска любую другую' }
                Write-Host "    $text`n" -ForegroundColor DarkGray

                $text = if ( $L.s15 ) { $L.s15 } else { 'Пропуск через 20 секунд' }
                Write-Host "    $text`n" -ForegroundColor White

                if ( $host.Name -eq 'ConsoleHost' )
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Ожидание' }
                    $ReadKey = Wait-PressKey -Text "    $text`: " -SecondsToWait 20
                }
                else
                {
                    $text = if ( $L.s17 ) { $L.s17 } else { 'Ваш выбор' }
                    $ReadKey = Read-Host "    $text " ; Write-Host
                }

                if ( $ReadKey -eq '1' )
                {
                    Write-Host "  ► " -ForegroundColor Green -NoNewline

                    $text = if ( $L.s18 ) { $L.s18 } else { 'Нажата клавиша' }
                    Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host '1 ' -ForegroundColor Cyan -NoNewline
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s18_1 ) { $L.s18_1 } else { 'Установить' }
                    Write-Host "$text" -ForegroundColor Green

                    $text = if ( $L.s19 ) { $L.s19 } else { 'Повторная установка' }
                    Write-Host "`n    $text" -ForegroundColor Cyan
                }
                else
                {
                    $text = if ( $L.s20 ) { $L.s20 } else { 'Пропуск установки' }
                    Write-Host "  ► $text" -ForegroundColor DarkGray

                    Continue  # Переход к следующей итерации foreach
                }
            }

            $isInstalled = $true

            if ( $UpdateFullPkg -and $CabFilesData[$CabN].CabCU -and $CabFilesData[$CabN].isInstall )
            {
                [array] $PkgInfo = Get-ProPackageData

                if ( $PkgInfo.ProPkgName )
                {
                    $text = if ( $L.s12_1 ) { $L.s12_1 } else { 'С Обновлением интегрированных пакетов из полных редакций' }
                    Write-Host "    $text" -ForegroundColor DarkCyan

                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\$($PkgInfo.ProPkgName)~~0.0.0.0"
                    Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 0 -NoCheck

                    $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\Product'
                    Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 0 -NoCheck

                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)"
                    Set-Reg New-ItemProperty -Path $Path -Name 'CurrentState' -Type DWord 112 -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallClient' -Type String 'DISM Package Manager Provider' -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallLocation' -Type String "\\?\$env:SystemDrive\Temp\Packages\" -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallName' -Type String "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version).mum" -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallTimeHigh' -Type DWord $PkgInfo.InstallTimeHigh -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallTimeLow' -Type DWord $PkgInfo.InstallTimeLow -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'InstallUser' -Type String 'S-1-5-18' -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'SelfUpdate' -Type DWord 0 -NoCheck
                    Set-Reg New-ItemProperty -Path $Path -Name 'Visibility' -Type DWord 1 -NoCheck

                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)\Owners"
                    Set-Reg New-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -Type DWord 131184 -NoCheck
                }
                else
                {
                    $text = if ( $L.s12_2 ) { $L.s12_2 } else { 'Нет необходимости обновлять интегрированне пакеты из полных редакций' }
                    Write-Host "    $text" -ForegroundColor DarkGray

                    Continue  # Переход к следующей итерации foreach
                }
            }
            elseif ( $UpdateFullPkg -and $CabFilesData[$CabN].CabCU -and $CabFilesData[$CabN].isPending )
            {
                $text = if ( $L.s12_3 ) { $L.s12_3 } else { 'Накопительное обновление ожидает завершения установки, перезагрузитесь!' }
                Write-Host "`n    $text`n" -ForegroundColor Yellow

                Continue  # Переход к следующей итерации foreach
            }
            elseif ( $UpdateFullPkg -and $CabFilesData[$CabN].CabCU )
            {
                $text = if ( $L.s12_4 ) { $L.s12_4 } else { 'Сначала установите последнее накопительное обновление в обычном режиме!' }
                Write-Host "`n    $text`n" -ForegroundColor Yellow

                Continue  # Переход к следующей итерации foreach
            }



            if ( -not $CabFilesData[$CabN].ServStack )
            {
                if ( $CabFilesData[$CabN].PSFXv2 )
                {
                    $CabFileToMsuExt = "$CabFile.msu"
                    Rename-Item -LiteralPath $CabFile -NewName $CabFileToMsuExt -Force -ErrorAction SilentlyContinue

                    $text = if ( $L.s23 ) { $L.s23 } else { 'Выполнение установки' }
                    Write-Host "`n    $text PSFXv2`:" -ForegroundColor Magenta

                    $text = if ( $L.s24 ) { $L.s24 } else { 'Команда' }
                    Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package /PackagePath:$CabFileToMsuExt" -ForegroundColor DarkGray

                    & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package /PackagePath:"$CabFileToMsuExt"

                    Start-Sleep -Milliseconds 200
                    Rename-Item -LiteralPath $CabFileToMsuExt -NewName ($CabFileToMsuExt.Replace('.msu','')) -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    # Временная папка для распаковки.
                    [string] $TempFolder = "$UpdatesFolder\UnPack_$([System.IO.Path]::GetFileNameWithoutExtension($CabName))"

                    $text = if ( $L.s21 ) { $L.s21 } else { 'Создание временной папки' }
                    Write-Host "`n    $text`: '$TempFolder'" -ForegroundColor DarkGray

                    if ( Test-Path -LiteralPath \\?\$TempFolder -PathType Any -ErrorAction SilentlyContinue )
                    { Remove-Item -LiteralPath \\?\$TempFolder -Recurse -Force -ErrorAction SilentlyContinue }
                    New-Item -ItemType Directory -Path $TempFolder -Force -ErrorAction SilentlyContinue > $null

                    $text = if ( $L.s22 ) { $L.s22 } else { 'Распаковка файла в' }
                    Write-Host "    $text '$TempFolder'" -ForegroundColor DarkGray

                    & $7z x "$CabFile" -o"$TempFolder" -x!"WSUSSCAN.cab" -x!"*Deployment*.cab" -x!"*Metadata*.cab" -aoa -bso0 -bse0 -bsp0

                    $text = if ( $L.s23 ) { $L.s23 } else { 'Выполнение установки' }
                    Write-Host "    $text`:" -ForegroundColor Magenta

                    $text = if ( $L.s24 ) { $L.s24 } else { 'Команда' }
                    Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package:$TempFolder\update.mum" -ForegroundColor DarkGray

                    & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package:"$TempFolder\update.mum"
                }
            }
            else
            {
                $text = if ( $L.s23 ) { $L.s23 } else { 'Выполнение установки' }
                Write-Host "    $text`:" -ForegroundColor Magenta

                $text = if ( $L.s26_1 ) { $L.s26_1 } else { 'Команда' }
                Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package:$($CabFile.Replace('\\?\',''))" -ForegroundColor DarkGray

                & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package:"$CabFile"
            }

            $text = if ( $L.s25 ) { $L.s25 } else { 'Установка' }
            Write-Host "`n    $text`: " -ForegroundColor DarkGray -NoNewline

            if ( $Global:LastExitCode -eq 3010 )
            {
                $text = if ( $L.s25_1 ) { $L.s25_1 } else { 'Необходима перезагрузка' }
                Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
            }
            elseif ( $Global:LastExitCode )
            {
                try { $err = '0x{0}' -f [System.Convert]::ToString($Global:LastExitCode, 16) } catch { $err = $Global:LastExitCode }

                $text = if ( $L.s25_2 ) { $L.s25_2 } else { 'Ошибка' }
                Write-Host "  $text`: $err  " -BackgroundColor DarkRed -ForegroundColor White
            }
            else
            {
                $text = if ( $L.s25_3 ) { $L.s25_3 } else { 'Выполнена' }
                Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
            }

            if ( $Global:LastExitCode -and ( $Global:LastExitCode -ne 3010 ) -and ( -not $CabFilesData[$CabN].ServStack ) -and ( -not $CabFilesData[$CabN].PSFXv2 ))
            {
                $text = if ( $L.s26 ) { $L.s26 } else { 'Повторное выполнение установки' }
                Write-Host "`n    $text`:" -ForegroundColor Magenta

                $text = if ( $L.s26_1 ) { $L.s26_1 } else { 'Команда' }
                Write-Host "    $text`: Dism.exe /Online /NoRestart`n             /ScratchDir:$DismScratchDir`n             /Add-Package:$($CabFile.Replace('\\?\',''))" -ForegroundColor DarkGray

                Start-Sleep -Milliseconds 200

                & $Dism /Online /NoRestart /ScratchDir:"$DismScratchDir" /Add-Package:"$CabFile"

                $text = if ( $L.s27 ) { $L.s27 } else { 'Повторная установка' }
                Write-Host "`n    $text`: " -ForegroundColor DarkGray -NoNewline

                if ( $Global:LastExitCode -eq 3010 )
                {
                    $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Необходима перезагрузка' }
                    Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
                }
                elseif ( $Global:LastExitCode )
                {
                    $text = if ( $L.s27_2 ) { $L.s27_2 } else { 'Ошибка' }
                    Write-Host "  $text`: $Global:LastExitCode  " -BackgroundColor DarkRed -ForegroundColor White
                }
                else
                {
                    $text = if ( $L.s27_3 ) { $L.s27_3 } else { 'Выполнена' }
                    Write-Host "  $text  " -BackgroundColor DarkGreen -ForegroundColor White
                }
            }

            Start-Sleep -Milliseconds 1000


            if ( $UpdateFullPkg -and $CabFilesData[$CabN].CabCU -and $PkgInfo.ProPkgName )
            {
                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\$($PkgInfo.ProPkgName)~~0.0.0.0"
                Set-Reg Remove-Item -Path $Path -NoCheck
                $Path = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackageIndex\Product'
                Set-Reg Remove-ItemProperty -Path $Path -Name "$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)" -NoCheck
                $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\Packages\$($PkgInfo.ProPkgName)~~$($PkgInfo.Version)"
                Set-Reg Remove-Item -Path $Path -NoCheck
            }


            if ( Test-Path -LiteralPath \\?\$TempFolder -PathType Any -ErrorAction SilentlyContinue )
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Удаление временной папки' }
                Write-Host "`n    $text`: '$TempFolder'" -ForegroundColor DarkGray

                Remove-Item -LiteralPath \\?\$TempFolder -Recurse -Force -ErrorAction SilentlyContinue
            }

            Start-Sleep -Milliseconds 500
        }
    }


    if ( -not $Install )
    {
        if ( -not $CabNumber )
        {
            $text = if ( $L.s29_1 ) { $L.s29_1 } else { 'Подходящие файлы обновлений CAB/ESD/WIM Не найдены' }
            Write-Host "           $text" -ForegroundColor DarkYellow
        }
    }
    else
    {
        if ( -not $CabNumber )
        {
            $text = if ( $L.s29_1 ) { $L.s29_1 } else { 'Подходящие файлы обновлений CAB/ESD/WIM Не найдены' }
            Write-Host "`n██  $NameThisFunction`: $text`n" -ForegroundColor DarkYellow
        }
        else
        {
            # Если было выполнение установки.
            if ( $isInstalled )
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Выполнено' }
                Write-Host "`n██ $text" -ForegroundColor Green

                $text = if ( $L.s31 ) { $L.s31 } else { 'После установки обновлений необходима перезагрузка!' }
                Write-Host "   $text" -ForegroundColor DarkGreen
            }
            else
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Выполнено' }
                Write-Host "`n██ $text`n" -ForegroundColor Green
            }
        }

        Get-Pause
    }
}
