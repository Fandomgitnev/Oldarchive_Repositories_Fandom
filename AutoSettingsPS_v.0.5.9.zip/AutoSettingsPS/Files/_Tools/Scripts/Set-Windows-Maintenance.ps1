﻿
<#
.SYNOPSIS
 Настройка или выполнение обслуживания системы отдельными действиями,
 или запуск стандартного обслуживания системы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Windows_Maintenance.

 Используется функция Get-List-Presets
 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-Tsk для создания/пересоздания задач, с проверкой и выводом результата.
 Используется функция Test-Internet
 Используется функция Get-Task-FullPaths поиск задач
 Используется функция Write-HostColor для вывода информации


.EXAMPLE
    Set-Windows-Maintenance -Options RunNgen,RunTimeSync -Act Set

    Описание
    --------
    Выполнить генерацию образов .NET и синхронизацию времени.


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  06-03-2023
 =================================================

#>
Function Set-Windows-Maintenance {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'MaintenanceDisable', 'WakeUpMaintDisable', 'RunNgen', 'RunClearWinSxS',
                      'RunDiskClean', 'RunTimeSync', 'RunStandartMaint', 'StopStandartMaint', 'CreateTaskCleanUp' )]
        [string[]] $Options = 'WakeUpMaintDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Maintenance', 'WakeUpForMaint', 'PresetTimeServers', 'PresetResetBase', 'TaskCleanUp' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $GetPause
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    if ( $CheckState )
    {
        if ( 'Maintenance' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            try { [psobject] $Maintenance = [Microsoft.Win32.Registry]::GetValue($Key,'MaintenanceDisabled',$null)
            } catch { [psobject] $Maintenance = $null }

            if ( 1 -eq $Maintenance ) {  '#Green#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'Запрещено' }) }
            else                      { '#Yellow#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Разрешено' }) } # Дефолт
        }
        elseif ( 'WakeUpForMaint' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            try { [psobject] $WakeUpForMaint = [Microsoft.Win32.Registry]::GetValue($Key,'WakeUp',$null)
            } catch { [psobject] $WakeUpForMaint = $null }

            if ( 0 -eq $WakeUpForMaint ) {  '#Green#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'Запрещено' }) }
            else                         { '#Yellow#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Разрешено' }) } # Дефолт
        }
        elseif ( 'PresetTimeServers' -eq $CheckState )
        {
            [string[]] $PresetServers = $null

            foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Time-NTP-Servers\s*=\s*1' ))
            {
                if ( $Line -match '^\s*Time-NTP-Servers\s*=\s*1\s*=\s*(?<Servers>[^\r\n=]+)=' )
                {
                    $PresetServers += ($Matches.Servers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" })
                }
            }

            if ( $PresetServers.Count ) { "#Magenta#$($PresetServers.Count) #DarkGray#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { 'шт' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s3_1 ) { $L.s3_1 } else { 'Нет' }) }
        }
        elseif ( 'PresetResetBase' -eq $CheckState )
        {
            [bool] $UseResetBase = $false

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Use-Dism-ResetBase\s*=\s*1\s*=' },'First') )
            {
                $UseResetBase = $true
            }

            if ( $UseResetBase ) { '#Blue#~80 {0} #DarkGray#[ #Magenta#{1} #DarkGray#]#' -f $(if ( $L.s3_2 ) { $L.s3_2, $L.s3_3 } else { 'мин', '/ResetBase' }) }
            else {                 '#Blue#~40 {0} #DarkGray#[ {1} ]#'                    -f $(if ( $L.s3_2 ) { $L.s3_2, $L.s3_4 } else { 'мин', 'Без /ResetBase' }) }
        }
        elseif ( 'TaskCleanUp' -eq $CheckState )
        {
            [int] $Count = @(Get-Task-FullPaths -LikeName \Microsoft\Windows\DiskCleanup\CleanUp* -CompareFullPath).Count

            if ( $Count ) { '#Green#{0}#' -f $Count }
            else          { '#DarkGray#0#'          }
        }

        Return
    }

    if (( $Options -like 'MaintenanceDisable' ) -or ( $Options -like 'WakeUpMaintDisable' ))
    {
        $text = if ( $L.s4 ) { $L.s4 } else { 'Настройка Обслуживания Windows' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s4_1 ) { $L.s4_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Options -like 'MaintenanceDisable' )
        {
            if ( $Act -ne 'Default' )
            {
                $text = if ( $L.s5 ) { $L.s5 } else { 'Запрещение' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s5_1 ) { $L.s5_1 } else { 'Обслуживания' }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'MaintenanceDisabled' -Type DWord 1

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'MaintenanceDisabled' -Type DWord 1
                }
            }
            else
            {
                $text = if ( $L.s6 ) { $L.s6 } else { 'Включение' }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s6_1 ) { $L.s6_1 } else { 'Разрешения Обслуживания' }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'
                }
            }
        }

        if ( $Options -like 'WakeUpMaintDisable' )
        {
            if ( $Act -ne 'Default' )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Запрещение' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Пробуждения для Обслуживания' }
                Write-Host "$text `n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 0

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 0
                }
            }
            else
            {
                $text = if ( $L.s8 ) { $L.s8 } else { 'Включение' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s8_1 ) { $L.s8_1 } else { 'Разрешения Пробуждения для Обслуживания' }
                Write-Host "$text`n" -ForegroundColor White

                [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                Set-Reg New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 1

                if ( $is64 )
                {
                    [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

                    Set-Reg New-ItemProperty -Path $Path -Name 'WakeUp' -Type DWord 1
                }
            }
        }
    }

    if ( $Options -like 'CreateTaskCleanUp' )
    {
        $text = if ( $L.s4 ) { $L.s4 } else { 'Настройка Обслуживания Windows' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s4_1 ) { $L.s4_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s38 ) { $L.s38 } else { 'Создание' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s38_1 ) { $L.s38_1 } else { 'Задач очистки папок при загрузке Windows' }
            Write-Host "$text " -ForegroundColor White -NoNewline

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s38_2 ) { $L.s38_2 } else { 'Проверка' }
                Write-Host "$text " -ForegroundColor Cyan
            }
            else { Write-Host }

            [bool] $EveryBoot = $false
            [bool] $ByDay     = $false
             [int] $Days = 0

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Task-Config-CleanUpByDay\s*=\s*1\s*=\s*(?<Days>\d+)\s*==' },'First') )
            {
                try { $Days = $Matches.Days } catch { $Days = 1 }

                if ( $Days -le 1 ) { $Days = 1 ; $EveryBoot = $true }
                else
                {
                    if ( $Days -gt 360 ) { $Days = 360 }
                    $ByDay = $true
                }
            }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Task-CleanUpEveryBoot\s*=\s*1\s*=' },'First') )
            {
                $EveryBoot = $true
            }

            $CleanUpPathsByDay = [System.Collections.Generic.List[string]]::new()
            $CleanUpPaths      = [System.Collections.Generic.List[string]]::new()
            $PathSkips         = [System.Collections.Generic.List[string]]::new()
            [string] $Path = ''

            # Если указали по ошибке системную папку, пропустить
            [array] $ExcludeFolders = "$env:SystemDrive\Documents and Settings",${env:ProgramFiles(x86)},$env:ProgramFiles,$env:ProgramData,"$env:SystemDrive\Users",$env:windir
             [bool] $isByDay = $false

            if ( $ByDay -or $EveryBoot )
            {
                foreach ( $Line in ( $ListPresetsGlobal -match '^\s*(Path-ToClean-ByDay|ToClean-EveryBoot)\s*=\s*1\s*=' ))
                {
                    if ( $Line -match '^\s*(?<Type>(Path-ToClean-ByDay|ToClean-EveryBoot))\s*=\s*1\s*=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' )
                    {
                        $Path = [System.Environment]::ExpandEnvironmentVariables($Matches.Path.Trim('\. '))

                        if ( $Matches.Type -eq 'Path-ToClean-ByDay' ) { $isByDay = $true } else { $isByDay = $false }

                        if ( $Path -like '?:\?*' -and -not ( $Path -like '*—*' )) # Длинное тире (Em dash): Alt+0151 заменяется на дефис при передаче на cmd не в батнике, портит путь
                        {
                            $Path = [System.IO.Path]::GetFullPath($Path.TrimEnd('\ '))

                            if ( -not ( $ExcludeFolders -eq $Path ))
                            {
                                $Path = $Path -replace $env:SystemDrive,'%SystemDrive%'

                                if ( $isByDay )
                                {
                                    if ( -not ( $CleanUpPathsByDay -eq $Path ))
                                    {
                                        if ( $Path -eq '%SystemDrive%\Windows\Temp' )
                                        {
                                            $CleanUpPathsByDay.Insert(0,$Path)
                                        }
                                        else
                                        {
                                            $CleanUpPathsByDay.Add($Path)
                                        }
                                    }
                                }
                                else
                                {
                                    if ( -not ( $CleanUpPaths -eq $Path ))
                                    {
                                        if ( $Path -eq '%SystemDrive%\Windows\Temp' )
                                        {
                                            $CleanUpPaths.Insert(0,$Path)
                                        }
                                        else
                                        {
                                            $CleanUpPaths.Add($Path)
                                        }
                                    }
                                }
                            }
                            else  { $PathSkips.Add($Path) }
                        }
                        else { $PathSkips.Add($Path) }
                    }
                }
            }

            if ( $CleanUpPathsByDay -eq '%SystemDrive%\Windows\Temp' )
            {
                foreach ( $Path in (Get-ChildItem -Directory -Path "$env:SystemDrive\Users\*\AppData\Local\Temp" -ErrorAction 0).FullName )
                {
                    $Path = $Path -replace $env:SystemDrive,'%SystemDrive%'

                    if ( -not ( $CleanUpPathsByDay -eq $Path ))
                    {
                        $CleanUpPathsByDay.Add($Path)
                    }
                }

                $Path = '%SystemDrive%\Windows\ServiceProfiles\LocalService\AppData\Local\Temp'
                if ( -not ( $CleanUpPathsByDay -eq $Path ))
                {
                    $CleanUpPathsByDay.Add($Path)
                }

                $Path = '%SystemDrive%\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp'
                if ( -not ( $CleanUpPathsByDay -eq $Path ))
                {
                    $CleanUpPathsByDay.Add($Path)
                }

                $Path = '%SystemDrive%\ProgramData\Temp'
                if ( -not ( $CleanUpPathsByDay -eq $Path ))
                {
                    $CleanUpPathsByDay.Add($Path)
                }
            }

            if ( $CleanUpPaths -eq '%SystemDrive%\Windows\Temp' )
            {
                foreach ( $Path in (Get-ChildItem -Directory -Path "$env:SystemDrive\Users\*\AppData\Local\Temp" -ErrorAction 0).FullName )
                {
                    $Path = $Path -replace $env:SystemDrive,'%SystemDrive%'

                    if ( -not ( $CleanUpPaths -eq $Path ))
                    {
                        $CleanUpPaths.Add($Path)
                    }
                }

                $Path = '%SystemDrive%\Windows\ServiceProfiles\LocalService\AppData\Local\Temp'
                if ( -not ( $CleanUpPaths -eq $Path ))
                {
                    $CleanUpPaths.Add($Path)
                }

                $Path = '%SystemDrive%\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp'
                if ( -not ( $CleanUpPaths -eq $Path ))
                {
                    $CleanUpPaths.Add($Path)
                }

                $Path = '%SystemDrive%\ProgramData\Temp'
                if ( -not ( $CleanUpPaths -eq $Path ))
                {
                    $CleanUpPaths.Add($Path)
                }
            }

            # тогда одна задача на каждую загрузку для всех путей, объединение массива путей
            if ( $EveryBoot -and $Days -eq 1 )
            {
                foreach ( $Path in $CleanUpPathsByDay )
                {
                    if ( -not ( $CleanUpPaths -eq $Path ))
                    {
                        if ( $Path -eq '%SystemDrive%\Windows\Temp' )
                        {
                            $CleanUpPaths.Insert(0,$Path)
                        }
                        else
                        {
                            $CleanUpPaths.Add($Path)
                        }
                    }
                }

                $CleanUpPathsByDay = @()
            }

            if ( -not $EveryBoot )
            {
                $CleanUpPaths = @()
            }

            if ( $EveryBoot -and -not $ByDay )
            {
                $CleanUpPathsByDay = @()
            }

            # Удаление путей дубликатов из задачи для очистки по дням, оставив только в задаче для каждого дня, так как нет смысла 2 задачами чистить одну папку.
            if ( $CleanUpPathsByDay.Count -and $CleanUpPaths.Count -and $ByDay )
            {
                foreach ( $P in $CleanUpPaths )
                {
                    $Path = $CleanUpPathsByDay.Where({ $_ -eq $P },'First')

                    if ( $Path )
                    {
                        $CleanUpPathsByDay.Remove($Path) > $null
                    }
                }
            }

            # Далее вывод результата и создание задач

            [ciminstance] $NewTaskSettings = New-ScheduledTask
            $NewTaskSettings.Author = 'westlife | forum.ru-board.com'
            $NewTaskSettings.Source = 'forum.ru-board.com'
            $NewTaskSettings.Principal = New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -RunLevel Highest -Id 'LocalSystem' -LogonType ServiceAccount
            $NewTaskSettings.Settings  = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -Priority 7 -Compatibility Win8
            $NewTaskSettings.Triggers  = New-ScheduledTaskTrigger -AtStartup
            $NewTaskSettings.Settings.DisallowStartIfOnBatteries = $false
            $NewTaskSettings.Settings.StopIfGoingOnBatteries = $false
            $NewTaskSettings.Settings.AllowHardTerminate = $true
            $NewTaskSettings.Settings.StartWhenAvailable = $false
            $NewTaskSettings.Settings.RunOnlyIfNetworkAvailable = $false
            $NewTaskSettings.Settings.IdleSettings.WaitTimeout = ''
            $NewTaskSettings.Settings.IdleSettings.IdleDuration = ''
            $NewTaskSettings.Settings.IdleSettings.StopOnIdleEnd = $false
            $NewTaskSettings.Settings.IdleSettings.RestartOnIdle = $false
            $NewTaskSettings.Settings.AllowDemandStart = $true
            $NewTaskSettings.Settings.RunOnlyIfIdle = $false
            $NewTaskSettings.Settings.DisallowStartOnRemoteAppSession = $false
            $NewTaskSettings.Settings.UseUnifiedSchedulingEngine = $true
            $NewTaskSettings.Settings.WakeToRun = $false
            $NewTaskSettings.Settings.ExecutionTimeLimit = 'PT5M'
            $NewTaskSettings.Settings.Enabled = $true
            $NewTaskSettings.Settings.Hidden = $true
            $NewTaskSettings.Settings.Priority = 4

            $SystemTaskPath = '\Microsoft\Windows\DiskCleanup'

            [int] $Count = 2

            $SystemTaskName = 'CleanUpEveryBoot'

            if ( $CleanUpPaths.Count )
            {
                $text = if ( $L.s39 ) { $L.s39 } else { 'Очистка папок каждый день' }
                Write-Host "`n   $text`:" -ForegroundColor Gray

                foreach ( $Path in $CleanUpPaths )
                {
                    Write-Host "    +++ | $Path" -ForegroundColor DarkCyan
                }

                Write-Host

                [string] $ArgCmd = @"
/u /d /q /e:on /v:off /c "chcp 65001 >nul&cd /d "%SystemDrive%\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"2>nul
&&(for %I in ("$($CleanUpPaths -join '","')") do if "%~I" NEQ "" (chcp 65001 >nul|@echo off&for /f "delims=" %W in (
' dir /b /a:d "%~I" 2^^^>nul ') do (rmdir /s /q "%~I\%W" >nul 2>&1))&(del /f /q /a "%~I" >nul 2>&1))"
"@.Split("`r`n").Trim() -join ''

                $NewTaskSettings.Actions = New-ScheduledTaskAction -Execute '%SystemRoot%\System32\cmd.exe' -Argument $ArgCmd
                $NewTaskSettings.Description = "{0}: `n$($CleanUpPaths -join "; `n");" -f $(if ( $L.s40 ) { $L.s40 } else { 'Эта задача при каждой загрузке Windows выполняет очистку папок' })

                [Hashtable] $SystemAppsTask = @{
                    'TaskPath'    = $SystemTaskPath
                    'TaskName'    = $SystemTaskName
                    'InputObject' = $NewTaskSettings
                }

                Set-Tsk -Do:$Act Register-ScheduledTask @SystemAppsTask
            }
            else
            {
                $Count--
                $text = if ( $L.s41 ) { $L.s41 } else { 'В пресете не настроены пути или задача очистки папок каждый день' }
                Write-Host "`n   $text " -ForegroundColor DarkGray

                Get-Task-FullPaths -LikeName \Microsoft\Windows\DiskCleanup\$SystemTaskName -CompareFullPath | ForEach-Object {

                    Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_
                }
            }

            $SystemTaskName = 'CleanUpByDay'

            if ( $CleanUpPathsByDay.Count -and $Days -ge 2 )
            {
                $text = if ( $L.s42 ) { $L.s42 } else { 'Очистка папок каждый' }
                Write-Host "`n   $text " -ForegroundColor Gray -NoNewline

                $text = if ( $L.s42_1 ) { $L.s42_1 } else { 'день' }
                Write-Host "$Days $text`:" -ForegroundColor Blue

                foreach ( $Path in $CleanUpPathsByDay )
                {
                    Write-Host "    +++ | $Path" -ForegroundColor Blue
                }

                Write-Host

                [string] $ArgCmd = @"
/u /d /q /e:on /v:off /c "chcp 65001 >nul&cd /d "%SystemDrive%\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"2>nul
&&(for %I in ("$($CleanUpPathsByDay -join '","')") do if "%~I" NEQ "" (chcp 65001 >nul|@echo off&for /f "delims=" %W in (
' dir /b /a:d "%~I" 2^^^>nul ') do (rmdir /s /q "%~I\%W" >nul 2>&1))&(del /f /q /a "%~I" >nul 2>&1))
&SCHTASKS /Change /TN "$SystemTaskPath\$SystemTaskName" /Disable >nul 2>&1"
"@.Split("`r`n").Trim() -join ''

                $NewTaskSettings.Actions = New-ScheduledTaskAction -Execute '%SystemRoot%\System32\cmd.exe' -Argument $ArgCmd
                $NewTaskSettings.Description = "{0}: `n$($CleanUpPathsByDay -join "; `n");" -f $(if ( $L.s43 ) { $L.s43 } else { 'Эта задача при загрузке Windows выполняет очистку папок, затем отключается' })

                [Hashtable] $SystemAppsTask = @{
                    'TaskPath'    = $SystemTaskPath
                    'TaskName'    = $SystemTaskName
                    'InputObject' = $NewTaskSettings
                }

                Set-Tsk -Do:$Act Register-ScheduledTask @SystemAppsTask

                # Для включения первой
                $ArgCmd = @"
/u /d /q /e:on /v:off /c "@echo off&chcp 65001 >nul&SCHTASKS /Change /TN "$SystemTaskPath\$SystemTaskName" /Enable >nul 2>&1"
"@.Split("`r`n").Trim() -join ''

                $NewTaskSettings.Actions = New-ScheduledTaskAction -Execute '%SystemRoot%\System32\cmd.exe' -Argument $ArgCmd
                $NewTaskSettings.Description = "{0}: $SystemTaskName" -f $(if ( $L.s44 ) { $L.s44 } else { 'Эта задача периодически включает задачу' })
                $SystemTaskName = 'CleanUpByDayEnable'
                $NewTaskSettings.Settings.StartWhenAvailable = $true
                $NewTaskSettings.Settings.Priority = 7
                $NewTaskSettings.Triggers = New-ScheduledTaskTrigger -Daily -DaysInterval $Days -At $([datetime]::Today.AddHours(6))

                [Hashtable] $SystemAppsTask = @{
                    'TaskPath'    = $SystemTaskPath
                    'TaskName'    = $SystemTaskName
                    'InputObject' = $NewTaskSettings
                }

                Set-Tsk -Do:$Act Register-ScheduledTask @SystemAppsTask
            }
            else
            {
                $Count--
                $text = if ( $L.s45 ) { $L.s45 } else { 'В пресете не настроены пути или задача очистки папок по дням' }
                Write-Host "`n   $text " -ForegroundColor DarkGray

                Get-Task-FullPaths -LikeName \Microsoft\Windows\DiskCleanup\$SystemTaskName* -CompareFullPath | ForEach-Object {

                    Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_
                }
            }

            if ( $Count -and $PathSkips.Count )
            {
                $text = if ( $L.s46 ) { $L.s46 } else { 'Пропущены пути в пресете' }
                Write-Host "`n   $text`:" -ForegroundColor DarkGray
                foreach ( $Path in $PathSkips )
                {
                    if ( $Path -like '*—*' )
                    {
                        $Path = $Path -replace '—','#White:Red#—#DarkGray#'
                    }

                    Write-HostColor "    #DarkGray#--- | $Path"
                }
            }
        }
        else
        {
            $text = if ( $L.s47 ) { $L.s47 } else { 'Удаление' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s47_1 ) { $L.s47_1 } else { 'Задач очистки папок' }
            Write-Host "$text `n" -ForegroundColor White

            [int] $N = 0

            Get-Task-FullPaths -LikeName \Microsoft\Windows\DiskCleanup\CleanUp* -CompareFullPath | ForEach-Object {

                $N++
                Set-Tsk Unregister-ScheduledTask -TaskName $_
            }

            if ( $N )
            {
                $text = if ( $L.s48 ) { $L.s48 } else { 'Удалены' }
                Write-Host "`n   $text `n" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s48_1 ) { $L.s48_1 } else { 'Задачи не найдены' }
                Write-Host "$text `n" -ForegroundColor DarkGray
            }
        }
    }

    if (( $Options -match '^(Run|Stop)' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s9 ) { $L.s9 } else { 'Выполнение обслуживания Windows' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s9_1 ) { $L.s9_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    if (( $Options -like 'RunNgen' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s10 ) { $L.s10 } else { 'Выполнение' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s10_1 ) { $L.s10_1 } else { 'проверки и/или генерации образов .NET Framework' }
        Write-Host "$text " -ForegroundColor White -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline
        Write-Host "x86`n" -ForegroundColor Yellow

        [string] $NetPath = "$env:SystemDrive\Windows\Microsoft.NET\Framework"
        [string] $NGen40  = (Get-ChildItem -File -LiteralPath $NetPath -Recurse -Depth 1).FullName.Where({ $_ -like '*\v4.0*\ngen.exe' },'First')

        $text = if ( $L.s11 ) { $L.s11 } else { 'Команда' }
        Write-Host "   $text`: $NGen40 update`n" -ForegroundColor DarkGray

        #& $NGen40 ExecuteQueuedItems
        & $NGen40 update

        if ( $is64 )
        {
            $text = if ( $L.s10 ) { $L.s10 } else { 'Выполнение' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s10_1 ) { $L.s10_1 } else { 'проверки и/или генерации образов .NET Framework' }
            Write-Host "$text " -ForegroundColor White -NoNewline
            Write-Host '| ' -ForegroundColor DarkGray -NoNewline
            Write-Host "x64`n" -ForegroundColor Green

            $NetPath = "$env:SystemDrive\Windows\Microsoft.NET\Framework64"
            $NGen40  = (Get-ChildItem -File -LiteralPath $NetPath -Recurse -Depth 1).FullName.Where({ $_ -like '*\v4.0*\ngen.exe' },'First')

            $text = if ( $L.s11 ) { $L.s11 } else { 'Команда' }
            Write-Host "   $text`: $NGen40 update`n" -ForegroundColor DarkGray

            #& $NGen40 ExecuteQueuedItems
            & $NGen40 update
        }
    }

    if (( $Options -like 'RunClearWinSxS' ) -and ( $Act -eq 'Set' ))
    {
        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Use-Dism-ResetBase\s*=\s*1\s*=' },'First') )
        {
            [bool] $UseResetBase = $true
        }
        else { [bool] $UseResetBase = $false }

        $text = if ( $L.s12 ) { $L.s12 } else { 'Выполнение' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s12_1 ) { $L.s12_1 } else { 'Очистки и сжатия папки WinSxS' }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s12_2 ) { $L.s12_2 } else { 'Команда' }

        if ( $UseResetBase )
        {
            Write-Host "   $text`: Dism /Online /Cleanup-Image /StartComponentCleanup /ResetBase" -ForegroundColor DarkGray

            & Dism.exe /Online /Cleanup-Image /StartComponentCleanup /ResetBase
        }
        else
        {
            Write-Host "   $text`: Dism /Online /Cleanup-Image /StartComponentCleanup" -ForegroundColor DarkGray

            & Dism.exe /Online /Cleanup-Image /StartComponentCleanup
        }

        $text = if ( $L.s13 ) { $L.s13 } else { 'При завершении на 20.0% - очистка WinSxS не требовалась' }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        $text = if ( $L.s14 ) { $L.s14 } else { 'Бывает ''Ошибка: 2'' - это небольшой недочет Dism.exe или makecab.exe' }
        Write-Host "   $text" -ForegroundColor DarkGray

        $text = if ( $L.s15 ) { $L.s15 } else { "Не находят файл $env:SystemDrive\Windows\Logs\CBS\CbsPersist_***.log после его архивации и удаления утилитой makecab.exe" }
        Write-Host "   $text" -ForegroundColor DarkGray
    }

    if (( $Options -like 'RunDiskClean' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s16 ) { $L.s16 } else { 'Выполнение' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'Очистки папок Temp и указанных в пресете' }
        Write-Host "$text`:`n" -ForegroundColor White

        $CleanUpPaths = [System.Collections.Generic.List[string]]::new()
        $PathSkips    = [System.Collections.Generic.List[string]]::new()
        [string] $Path = ''

        # Если указали по ошибке системную папку, пропустить
        [array] $ExcludeFolders = "$env:SystemDrive\Documents and Settings",${env:ProgramFiles(x86)},$env:ProgramFiles,$env:ProgramData,"$env:SystemDrive\Users",$env:windir

        foreach ( $Line in ( $ListPresetsGlobal -match '^\s*(Path-ToClean-ByDay|ToClean-EveryBoot)\s*=\s*1\s*=' ))
        {
            if ( $Line -match '^\s*(Path-ToClean-ByDay|ToClean-EveryBoot)\s*=\s*1\s*=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==' )
            {
                $Path = [System.Environment]::ExpandEnvironmentVariables($Matches.Path.Trim('\. '))

                if ( $Path -like '?:\?*' )
                {
                    $Path = [System.IO.Path]::GetFullPath($Path.TrimEnd('\ '))

                    if ( -not ( $ExcludeFolders -eq $Path ))
                    {
                        if ( -not ( $CleanUpPaths -eq $Path ))
                        {
                            if ( $Path -eq "$env:SystemDrive\Windows\Temp" )
                            {
                                $CleanUpPaths.Insert(0,$Path)
                            }
                            else
                            {
                                $CleanUpPaths.Add($Path)
                            }
                        }
                    }
                    else
                    {
                        $PathSkips.Add($Path)
                    }
                }
            }
        }

        foreach ( $Path in (Get-ChildItem -Directory -Path "$env:SystemDrive\Users\*\AppData\Local\Temp" -ErrorAction 0).FullName )
        {
            if ( -not ( $CleanUpPaths -eq $Path ))
            {
                $CleanUpPaths.Add($Path)
            }
        }

        $Path = "$env:SystemDrive\Windows\Temp"
        if ( -not ( $CleanUpPaths -eq $Path ))
        {
            $CleanUpPaths.Insert(0,$Path)
        }

        $Path = "$env:SystemDrive\Windows\ServiceProfiles\LocalService\AppData\Local\Temp"
        if ( -not ( $CleanUpPaths -eq $Path ))
        {
            $CleanUpPaths.Add($Path)
        }

        $Path = "$env:SystemDrive\Windows\ServiceProfiles\NetworkService\AppData\Local\Temp"
        if ( -not ( $CleanUpPaths -eq $Path ))
        {
            $CleanUpPaths.Add($Path)
        }

        $Path = "$env:ProgramData\Temp"
        if ( -not ( $CleanUpPaths -eq $Path ))
        {
            $CleanUpPaths.Add($Path)
        }

        Token-Impersonate -Token SYS

        [string] $SubDir = ''

        foreach ( $Path in $CleanUpPaths )
        {
            Write-Host "   +++ | $Path " -ForegroundColor DarkCyan -NoNewline

            if ( [System.IO.Directory]::Exists($Path) )
            {
                Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                Write-Host '●' -ForegroundColor Green

                # Командами cmd чтобы не делать предварительные поочередные удаления символчисеских ссылок, снятий режимов только для чтения и т.д.
                # Встроенные командлеты  и .Net не могут удалить всё сразу у каждого из них есть свое ограничение, которое помешает удалить.
                try { & cmd.exe /u /d /q /c "del /f /q /a ""$Path"" >nul 2>&1" } catch {}
                try
                {
                    (Get-ChildItem -Directory -LiteralPath $Path -Force -ErrorAction 0) | ForEach-Object {
                        $SubDir = $_.FullName
                        try { & cmd.exe /u /d /q /c "rmdir /s /q ""$SubDir"" >nul 2>&1" } catch {}
                    }
                }
                catch {}
            }
            else
            {
                Write-Host '| ○' -ForegroundColor DarkGray
            }
        }

        Token-Impersonate -Reset

        foreach ( $Path in $PathSkips )
        {
            Write-Host "   --- | $Path" -ForegroundColor DarkGray
        }

        $text = if ( $L.s16 ) { $L.s16 } else { 'Выполнение' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_2 ) { $L.s16_2 } else { 'Очистки системного диска' }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s17 ) { $L.s17 } else { 'Будет пропуск: Папка Загрузки, Корзина, Обновления, Кэш иконок, BranchCache' }
        Write-Host "   $text`n" -ForegroundColor DarkGray

        # https://learn.microsoft.com/en-us/windows/win32/lwef/disk-cleanup
        [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches'

        [string[]] $AllElements = $null

        try
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            $AllElements = $OpenSubKey.GetSubKeyNames()
            $OpenSubKey.Close()
        }
        catch {}

        [string[]] $ElementsOff = 'DownloadsFolder', 'Recycle Bin', 'Update Cleanup', 'Service Pack Cleanup',
                                  'Thumbnail Cache', 'BranchCache' # , 'User file versions'
        [string] $Path = ''
        [string] $Name = ''
        [int] $Autorun = 0
        [int] $AutorunTemp = 0

        $CleanOff = [System.Collections.Generic.List[string]]::new()
        $Clean    = [System.Collections.Generic.List[string]]::new()
        $NoClean  = [System.Collections.Generic.List[string]]::new()

        # Исключаем хэндлеры очистки для cleanmgr.exe /autoclean
        foreach ( $Element in $AllElements )
        {
            $Autorun = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\$Element",'Autorun',-1)
            $Name    = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\$Element",'Name','')

            if ( $Autorun -eq 1 -or $Name ) # чистит через /autoclean при Autorun = 1 и спец параметрах для файлов предыдущих установок Windows
            {
                if ( -not $Name -and $ElementsOff -eq $Element )
                {
                    $Path = "HKLM:\$SubKey\$Element"

                    $text = if ( $L.s18 ) { $L.s18 } else { 'Исключение из очистки' }
                    Write-Host "   $text`: $Element" -ForegroundColor White
                    Set-Reg New-ItemProperty -Path $Path -Name 'Autorun' -Type DWord 0
                    Set-Reg New-ItemProperty -Path $Path -Name 'AutorunTemp' -Type DWord 1

                    $CleanOff.Add($Element)
                }
                else
                {
                    $Clean.Add($Element)
                }
            }
            else
            {
                $NoClean.Add($Element)
            }
        }

        if ( $CleanOff.Count ) { Write-Host }

        $text = if ( $L.s22 ) { $L.s22 } else { 'Настроено' }
        Write-Host "   $text`: " -ForegroundColor Gray -NoNewline

        $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'Очистить' }
        Write-Host "$text " -ForegroundColor DarkCyan -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s22_2 ) { $L.s22_2 } else { 'Исключено' }
        Write-Host "$text " -ForegroundColor White -NoNewline
        Write-Host '| ' -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s22_3 ) { $L.s22_3 } else { 'Уже исключено' }
        Write-Host "$text `n" -ForegroundColor DarkGray

        foreach ( $i in $Clean )
        {
            Write-Host "   +++ | $i" -ForegroundColor DarkCyan
        }

        foreach ( $i in $CleanOff )
        {
            Write-Host "   --- | $i | set Autorun: 0" -ForegroundColor White
        }

        foreach ( $i in $NoClean )
        {
            Write-Host "   --- | $i" -ForegroundColor DarkGray
        }

        $text = if ( $L.s19 ) { $L.s19 } else { 'Запуск' }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s19_1 ) { $L.s19_1 } else { 'очистки' }
        Write-Host "$text" -ForegroundColor White

        $text = if ( $L.s20 ) { $L.s20 } else { 'Команда: Сleanmgr.exe /autoclean /d %systemdrive%' }
        Write-Host "   $text" -ForegroundColor DarkGray

        $text = if ( $L.s21 ) { $L.s21 } else { 'Ожидание' }
        Write-Host "   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s21_1 ) { $L.s21_1 } else { 'завершения процесса Сleanmgr.exe ...' }
        Write-Host "$text" -ForegroundColor White

        ReStart-Explorer -LockSetForeground

        $StartInfo = [System.Diagnostics.ProcessStartInfo]::new("$env:windir\system32\cleanmgr.exe")
        $StartInfo.WindowStyle = 'Hidden'
        $StartInfo.UseShellExecute = $false
        $StartInfo.Arguments = "/autoclean /d $env:SystemDrive"

        try { $P = [System.Diagnostics.Process]::Start($StartInfo) ; $P.WaitForExit() ; $P.Close() } catch {}

        Write-Host

        foreach ( $Element in $AllElements )
        {
            $AutorunTemp = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches\$Element",'AutorunTemp',0)

            if ( $AutorunTemp )
            {
                $Path = "HKLM:\$SubKey\$Element"

                $text = if ( $L.s18_1 ) { $L.s18_1 } else { 'Возврат параметра' }
                Write-Host "   $text`: $Element" -ForegroundColor White
                Set-Reg New-ItemProperty -Path $Path -Name 'Autorun' -Type DWord 1
                Set-Reg Remove-ItemProperty -Path $Path -Name 'AutorunTemp'
            }
        }
    }

    if (( $Options -like 'RunTimeSync' ) -and ( $Act -eq 'Set' ))
    {
        if ( -not ( Test-Internet -Bool ))
        {
            #$text = if ( $L.s31 ) { $L.s31 } else { 'Пропуск' }
            #Write-Host "`n   $text " -ForegroundColor Yellow -NoNewline

            #$text = if ( $L.s31_1 ) { $L.s31_1 } else { 'Синхронизации времени' }
            #Write-Host "`n   $text " -ForegroundColor White -NoNewline

            $text = if ( $L.s31_2 ) { $L.s31_2 } else { 'Интернет' }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host 'OffLine' -ForegroundColor DarkYellow
        }

        [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time\Parameters'

        # Получаем список серверов настроенный в системе.
        try { [string[]] $SystemServers = [Microsoft.Win32.Registry]::GetValue($Key,'NtpServer',$null) }
        catch { [string[]] $SystemServers = $null }

        [string] $Key = 'SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'

        try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key,'ReadSubTree','QueryValues') }
        catch { [psobject] $OpenSubKey = $null }

        if ( $OpenSubKey )
        {
            foreach ( $Name in ( $OpenSubKey.GetValueNames() ))
            {
                if ( $Name )
                {
                    $SystemServers += $OpenSubKey.GetValue($Name,$null)
                }
            }

            $OpenSubkey.Close()
        }

        # Переводим его в массив, убирая пустые строки, и добавляя ко всем доп. параметр 0х9, после удаления любых доп. параметров.
        [string[]] $SystemServers = ($SystemServers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" }) | Select-Object -Unique

        [string[]] $PresetServers = $null

        # Получаем все сервера из пресета
        [string[]] $PresetServers = @()

        foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Time-NTP-Servers\s*=\s*1' ))
        {
            if ( $Line -match '^\s*Time-NTP-Servers\s*=\s*1\s*=\s*(?<Servers>[^\r\n=]+)=' )
            {
                $PresetServers += ($Matches.Servers.Split().Trim().Where({$_}) -Replace ('(,[^\r\n]*)','')).ForEach({ "$_,0x9" }) | Select-Object -Unique
            }
        }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Replace-Time-NTP-Servers\s*=\s*1\s*=' },'First') ) { [bool] $Replace = $true }
        else { [bool] $Replace = $false }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Sync-From-All-Server\s*=\s*1\s*=' },'First') ) { [bool] $SyncAll = $true }
        else { [bool] $SyncAll = $false }

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Remove-Default-Servers\s*=\s*1\s*=' },'First') ) { [bool] $RemoveDefault = $true }
        else { [bool] $RemoveDefault = $false }


        if ( $Replace )
        {
            # Если есть сервера в пресете, то заменяем на них вместо системных.
            if ( $PresetServers.Count ) { $SystemServers = $PresetServers }
        }
        else
        {
            # Добавляем сервера из пресета к списку серверов из системы, но только которых еще нет в системе.
            $SystemServers += $PresetServers.Where({ -not ( $SystemServers -like $_ ) })
        }

        # Добавление дефолтных серверов к любым указаным или существующим наборам серверов, дубликаты удаляются.
        $SystemServers = ( $SystemServers += 'time.windows.com,0x9', 'time.nist.gov,0x9' ) | Select-Object -Unique

        # Если указано удалить дефолтные сервера MS
        if ( $RemoveDefault )
        {
            # Убираем дефолтные сервера.
            $SystemServers = @($SystemServers.Where({ $_ -notmatch '^(time[.]windows[.]com|time[.]nist[.]gov),0x9$' }))
        }
        else { $RemoveDefault = $false }

        # если нет ни каких в итоге, то вернуть дефолтные.
        if ( -not $SystemServers.Count ) { $SystemServers = 'time.windows.com,0x9', 'time.nist.gov,0x9' }

        $text = if ( $L.s25 ) { $L.s25 } else { 'Выполнение' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s25_1 ) { $L.s25_1 } else { 'Синхронизации времени' }
        Write-Host "$text " -ForegroundColor White -NoNewline

        #$text = if ( $L.s25_2 ) { $L.s25_2 } else { 'Интернет' }
        #Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
        #Write-Host 'OnLine ' -ForegroundColor Green -NoNewline

        $text = if ( $L.s25_3 ) { $L.s25_3 } else { 'Результат может быть с задержкой' }
        Write-Host "| $text`n" -ForegroundColor DarkGray

        $text = if ( $L.s26 ) { $L.s26 } else { 'Команда' }
        Write-Host "   $text`: w32tm.exe /ReSync /Force" -ForegroundColor DarkGray

        $text = if ( $L.s27 ) { $L.s27 } else { 'Итоговый Список и порядок серверов' }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

        if ( $RemoveDefault )
        {
            $text = if ( $L.s27_1 ) { $L.s27_1 } else { 'Удалены' }
            Write-Host "($text`: time.windows.com, time.nist.gov)`n" -ForegroundColor DarkGray
        }
        else { Write-Host "`n" }

        [int] $CountServers = 0
        foreach ( $Server in $SystemServers )
        {
            $CountServers++

            Write-Host "$($CountServers.ToString().PadLeft(9,' ')) | " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($Server -Replace ('(,[^\r\n]*)',''))" -ForegroundColor White
        }

        # Удаление списка серверов, чтобы обеспечить возможность замены на новые параметры из пресета, или снова вернуть старые.
        try
        {
            [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'

            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

            if ( $OpenSubKey )
            {
                foreach ( $Name in ( $OpenSubKey.GetValueNames() ))
                {
                    if ( $Name )
                    {
                        [string] $Path = "HKLM:\$SubKey"

                        Set-Reg -NoCheck Remove-ItemProperty -Path $Path -Name $Name
                    }
                }

                $OpenSubKey.Close()
            }
        }
        catch {}


        if ( $is64 )
        {
            try
            {
                [string] $SubKey = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers'

                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues')

                if ( $OpenSubKey )
                {
                    foreach ( $Name in ( $OpenSubKey.GetValueNames() ))
                    {
                        if ( $Name )
                        {
                            [string] $Path = "HKLM:\$SubKey"

                            Set-Reg -NoCheck Remove-ItemProperty -Path $Path -Name $Name
                        }
                    }

                    $OpenSubKey.Close()
                }
            }
            catch {}
        }

        Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers' -Name '' -Type String 0

        if ( $is64 )
        {
            Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers' -Name '' -Type String 0
        }

        [int] $CountServers = 0

        foreach ( $Server in ( $SystemServers -Replace '(,[^\r\n]*)','' ))
        {
            [string] $Path  = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DateTime\Servers'
            [string] $Name  = $CountServers
            [string] $Value = $Server

            Set-Reg -NoCheck New-ItemProperty -Path $Path -Name $Name -Type String $Value

            if ( $is64 )
            {
                [string] $Path = 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\DateTime\Servers'

                Set-Reg -NoCheck New-ItemProperty -Path $Path -Name $Name -Type String $Value
            }

            $CountServers++
        }

        Set-Reg -NoCheck New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters' -Name 'Type' -Type String 'NTP'

        Set-Service -Name W32Time -StartupType Manual -Status Running -ErrorAction SilentlyContinue

        [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('cp866')

        try
        {
            if ( $SyncAll )
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Синхронизация' }
                Write-Host "`n   $text " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s28_1 ) { $L.s28_1 } else { 'со всеми' }
                Write-Host "$text " -ForegroundColor White -NoNewline

                $text = if ( $L.s28_2 ) { $L.s28_2 } else { 'серверами в списке' }
                Write-Host "$text`n" -ForegroundColor DarkGray

                & w32tm.exe /Config /SyncFromFlags:Manual /ManualPeerList:"$($SystemServers -join ' ')" /Update *>$null
            }
            else
            {
                [string] $FirstServer = ( $SystemServers | Select-Object -First 1 ) -Replace '(,[^\r\n]*)',''

                $text = if ( $L.s29 ) { $L.s29 } else { 'Синхронизация' }
                Write-Host "`n   $text " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s29_1 ) { $L.s29_1 } else { 'с первым' }
                Write-Host "$text " -ForegroundColor White -NoNewline

                $text = if ( $L.s29_2 ) { $L.s29_2 } else { 'сервером в списке' }
                Write-Host "$text | " -ForegroundColor DarkGray -NoNewline
                Write-Host "$FirstServer `n" -ForegroundColor Green

                & w32tm.exe /Config /SyncFromFlags:Manual /ManualPeerList:"$($SystemServers | Select-Object -First 1)" /Update *>$null
            }

            Restart-Service -Name W32Time -Force -ErrorAction SilentlyContinue

            & w32tm.exe /ReSync /Force *>$null
            & w32tm.exe /ReSync /NoWait

            $text = if ( $L.s30 ) { $L.s30 } else { 'Результат Синхронизации от сервера' }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$((& w32tm.exe /Query /Source) -Replace '(,[^\r\n]*)','') " -ForegroundColor White -NoNewline

            $text = if ( $L.s30_1 ) { $L.s30_1 } else { 'Если несколько серверов, то покажет любой из удачных' }
            Write-Host "| $text`n" -ForegroundColor DarkGray
        }
        catch {}

        [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('utf-8')
    }

    if (( $Options -like 'RunStandartMaint' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s32 ) { $L.s32 } else { 'Подготовка' }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s32_1 ) { $L.s32_1 } else { 'к Стандартному обслуживанию Windows' }
        Write-Host "$text`n" -ForegroundColor White

        $text = if ( $L.s33 ) { $L.s33 } else { 'Включение' }
        Write-Host "   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'важных параметров для обслуживания' }
        Write-Host "$text`n" -ForegroundColor White

        [string] $Path = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

        Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'

        if ( $is64 )
        {
            [string] $Path = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            Set-Reg Remove-ItemProperty -Path $Path -Name 'MaintenanceDisabled'
        }

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Diagnosis\Scheduled'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\ApplicationData\CleanupTemporaryState'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Chkdsk\ProactiveScan'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Chkdsk\SyspartRepair'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Plug and Play\Device Install Group Policy'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Servicing\StartComponentCleanup'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Time Synchronization\SynchronizeTime'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Time Synchronization\ForceSynchronizeTime'

        $text = if ( $L.s34 ) { $L.s34 } else { 'Запуск в фоне' }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s34_1 ) { $L.s34_1 } else { 'Стандартного обслуживания Windows' }
        Write-Host "$text`n" -ForegroundColor White

        [string] $MSchedExe = "$env:SystemDrive\Windows\system32\MSchedExe.exe"

        $text = if ( $L.s35 ) { $L.s35 } else { 'Команда' }
        Write-Host "   $text`: $MSchedExe Start`n" -ForegroundColor DarkGray

        try { [System.Diagnostics.Process]::Start($MSchedExe,'Start') > $null } catch {}

        $text = if ( $L.s35_1 ) { $L.s35_1 } else { 'Выполнение в фоне может продлиться до 2 часов' }
        Write-Host "   $text" -ForegroundColor DarkGray

        Start-Sleep -Milliseconds 5000
    }

    if (( $Options -like 'StopStandartMaint' ) -and ( $Act -eq 'Set' ))
    {
        $text = if ( $L.s36 ) { $L.s36 } else { 'Остановка' }
        Write-Host "`n   $text " -ForegroundColor Red -NoNewline

        $text = if ( $L.s36_1 ) { $L.s36_1 } else { 'Стандартного обслуживания Windows' }
        Write-Host "$text`n" -ForegroundColor White

        [string] $MSchedExe = "$env:SystemDrive\Windows\system32\MSchedExe.exe"

        $text = if ( $L.s36_2 ) { $L.s36_2 } else { 'Команда' }
        Write-Host "   $text`: $MSchedExe Stop`n" -ForegroundColor DarkGray

        try { [System.Diagnostics.Process]::Start($MSchedExe,'Stop') > $null } catch {}

        Start-Sleep -Milliseconds 2000
    }

    $text = if ( $L.s37 ) { $L.s37 } else { 'Выполнено' }
    Write-Host "`n   $text" -ForegroundColor Green

    if ( $GetPause )
    {
        Get-Pause
    }
}
