﻿
<#
.SYNOPSIS
 Настройка ограничения обновлений для Центр Обновления Системы.
 Выбор нужных типов (неофициально).
 заготовленными несколькими вариантами.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Update_Restrictions.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-OwnerAndAccess для установки прав на разделы реестра.

 Метод универсальный для любой W10/W11
 
.EXAMPLE
    Set-Update-Restrictions -Act Set -Option SetWuNoDriver -ApplyGP

    Описание
    --------
    Отключение поиска и обновления драйверов, неофициально.


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  24-02-2023
 =================================================

#>
Function Set-Update-Restrictions {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'DisableDriverGP', 'SetWuNoDriver', 'SetWuSecure', 'SetWuOnlyStoreUWP', 'SetWuNothing', 'SetWuDefault' )]
        [string] $Option
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $NoHeader
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'DriversLoad', 'DriversSearch', 'DriversPriority', 'MetaDataLoad', 'SearchOrder', 'DriversReports',
                      'WuStateNoDriver', 'WuStateSecure', 'WuStateOnlyUWP', 'WuStateNothing', 'WuStateDefault',
                      'StateDriver', 'StateCU', 'StateDefender', 'StateNETSecure', 'StateAppX' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [hashtable] $WU  = @{}
    [string] $Subkey = ''
    [string] $dll    = ''

    Function Get-Wu-Data
    {
        [hashtable] $WUdata = @{

           AppXE   = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\AppX'
                        Dll2    = ''
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           AppX    = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\AppX'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           AppXS   = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\SingleStageAppX'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           BaseE   = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Base'
                        Dll2    = ''
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           CbsE    = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\CBS'
                        Dll2    = ''
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           Cbs     = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Cbs'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           CmdLine = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\CmdLine'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           DriverE = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\Driver'
                        Dll2    = ''
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           Driver  = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           MSIE    = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\ExpressionEvaluators\MSI'
                        Dll2    = ''
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           MSI     = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Msi'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           OSDepl  = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\OSDeployment'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }

           WSetup  = @{ Subkey  = $Subkey = 'SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\WindowsSetup'
                        Dll2    = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule','') } catch {''})
                        Dll     = $dll = $(try { [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL','') } catch {''})
                        isLock  = $dll.StartsWith('1') -or -not $dll }
        }

        return $WUdata
    }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'DriversLoad' )
        {
            try { [int] $DriversLoad = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null)
            } catch { $DriversLoad = $null }

            if ( 1 -eq $DriversLoad )   {  '#Green#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { 'Отключена загрузка' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'DriversSearch' )
        {
            try { [int] $DriversSearch = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DriverSearching','DontSearchWindowsUpdate',$null)
            } catch { $DriversSearch = $null }

            if ( 1 -eq $DriversSearch ) {  '#Green#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { 'Отключен          ' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'DriversPriority' )
        {
            try { [int] $Priority = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','AllSigningEqual',$null)
            } catch { $Priority = $null }

            if ( 1 -eq $Priority )      {  '#Green#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Равный            ' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'MetaDataLoad' )
        {
            try { [int] $MetaDataLoad = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Device Metadata','PreventDeviceMetadataFromNetwork',$null)
            } catch { $MetaDataLoad = $null }

            if ( 1 -eq $MetaDataLoad )  {  '#Green#{0}#' -f $(if ( $L.s5 ) { $L.s5 } else { 'Запрещено         ' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'SearchOrder' )
        {
            try { $SearchOrder = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DriverSearching','SearchOrderConfig',$null)
            } catch { $SearchOrder = $null }

            if ( 0 -eq $SearchOrder )   {  '#Green#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { 'Отключен          ' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'DriversReports' )
        {
            $Reports = $Reports1 = $Reports2 = $null

            try { [int] $Reports1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','DisableSendRequestAdditionalSoftwareToWER',$null) } catch {}
            try { [int] $Reports2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings','DisableSendGenericDriverNotFoundToWER',$null) } catch {}

            try { [int] $Reports = $Reports1 + $Reports2 } catch { [int] $Reports = 0 }

            if     ( 2 -eq $Reports )   {  '#Green#{0}#' -f $(if ( $L.s6 ) { $L.s6 } else { 'Отключена отправка' }) }
            elseif ( 1 -eq $Reports )   { '#Yellow#{0}#' -f $(if ( $L.s7 ) { $L.s7 } else { 'Отключено частично' }) }
            else                        { '#Yellow#{0}#' -f $(if ( $L.s1 ) { $L.s1 } else { 'По умолчанию      ' }) }
        }
        elseif ( $CheckState -eq 'StateDriver' )
        {
            [string] $Dll = $null

            try { $Dll = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Driver','DLL',$null) } catch {}

            if ( $dll -like '1*' -or $dll -eq '' ) { '#Red#○#' } else { '#Green#●#' }
        }
        elseif ( $CheckState -eq 'StateCU' )
        {
            [string] $Dll = $null

            try { $Dll = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\OSDeployment','DLL',$null) } catch {}

            if ( $dll -like '1*' -or $dll -eq '' ) { '#Red#○#' } else { '#Green#●#' }
        }
        elseif ( $CheckState -eq 'StateDefender' )
        {
            [string] $Dll = $null

            try { $Dll = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\CmdLine','DLL',$null) } catch {}

            if ( $dll -like '1*' -or $dll -eq '' ) { '#Red#○#' } else { '#Green#●#' }
        }
        elseif ( $CheckState -eq 'StateNETSecure' )
        {
            [string] $Dll = $null

            try { $Dll = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\Cbs','DLL',$null) } catch {}

            if ( $dll -like '1*' -or $dll -eq '' ) { '#Red#○#' } else { '#Green#●#' }
        }
        elseif ( $CheckState -eq 'StateAppX' )
        {
            [string] $Dll = $null

            try { $Dll = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\WindowsUpdate\UpdateHandlers\AppX','DLL',$null) } catch {}

            if ( $dll -like '1*' -or $dll -eq '' ) { '#Red#○#' } else { '#Green#●#' }
        }
        elseif ( $CheckState -eq 'WuStateNoDriver' )
        {
            $WU = Get-Wu-Data

            if (@($WU.Values.isLock -eq $false).Count -eq 11 -and $WU.Driver.isLock -and $WU.DriverE.isLock) { '#Green#●#' } else { '#DarkGray#○#' }
        }
        elseif ( $CheckState -eq 'WuStateSecure' )
        {
            $WU = Get-Wu-Data

            if (@($WU.Values.isLock -eq $false).Count -eq 7  -and $WU.MSIE.isLock -and $WU.MSI.isLock -and $WU.DriverE.isLock `
             -and $WU.Driver.isLock -and $WU.OSDepl.isLock -and $WU.WSetup.isLock ) { '#Green#●#' } else { '#DarkGray#○#' }
        }
        elseif ( $CheckState -eq 'WuStateOnlyUWP' )
        {
            $WU = Get-Wu-Data

            if (@($WU.Values.isLock -eq $true ).Count -eq 9  -and -not $WU.AppXE.isLock -and -not $WU.AppX.isLock `
                -and -not $WU.AppXS.isLock -and -not $WU.BaseE.isLock ) { '#Green#●#' } else { '#DarkGray#○#' }
        }
        elseif ( $CheckState -eq 'WuStateNothing' )
        {
            $WU = Get-Wu-Data

            if (@($WU.Values.isLock -eq $true ).Count -eq 13) { '#Green#●#' } else { '#DarkGray#○#' }
        }
        elseif ( $CheckState -eq 'WuStateDefault' )
        {
            $WU = Get-Wu-Data

            if (@($WU.Values.isLock -eq $false).Count -eq 13) { '#Green#●#' } else { '#DarkGray#○#' }
        }

        Return
    }

    Function Set-Wu-Config ([hashtable] $WuData, [string[]] $ToOff)
    {
        [string] $SddlOrig = 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
            G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
            D:PAI(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
            (A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
            (A;;KR;;;SY)(A;CIIO;GR;;;SY)(A;;KR;;;BA)(A;CIIO;GR;;;BA)(A;;KR;;;BU)(A;CIIO;GR;;;BU)(A;;KR;;;AC)(A;CIIO;GR;;;AC)
            (A;;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)
            (A;CIIO;GR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'

        [string] $SddlLock = 'O:LSG:LSD:PAI(D;CI;DCLCWPSDWDWO;;;WD)(A;CI;KR;;;SY)(A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)
            (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'

        [string] $SddlAccess = 'O:BAG:BAD:PAI(A;CI;KA;;;WD)'

        foreach ( $type in $WuData.Keys )
        {
            if ( $WuData[$type].Dll )
            {
                if ( $ToOff -ceq $type )
                {
                    if ( -not $WuData[$type].isLock )
                    {
                        $Subkey = $WuData[$type].Subkey
                        $WuData[$type].Dll = $WuData[$type].Dll -replace '.+','1${0}'

                        Set-OwnerAndAccess -Path "HKLM:\$Subkey" -RecoverySDDL $SddlAccess

                        try
                        {
                            [Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\$Subkey",'DLL', $WuData[$type].Dll, 'String')
                            
                            if ( $WuData[$type].Dll2 )
                            {
                                $WuData[$type].Dll2 = $WuData[$type].Dll2 -replace '.+','1${0}'
                                [Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\$Subkey",'DeploymentModule', $WuData[$type].Dll2, 'String')
                            }

                            if ( $type -ceq 'CbsE' )
                            {
                                $SubkeyBaseE = $WuData['BaseE'].Subkey
                                Set-OwnerAndAccess -Path "HKLM:\$SubkeyBaseE" -RecoverySDDL $SddlAccess
                                [Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\$SubkeyBaseE",'Prefixes', ([string[]]@('AppX')), 'MultiString')
                                Set-OwnerAndAccess -Path "HKLM:\$SubkeyBaseE" -RecoverySDDL $SddlLock
                            }

                            $WuData[$type].isLock = $true
                        }
                        catch {}

                        Set-OwnerAndAccess -Path "HKLM:\$Subkey" -RecoverySDDL $SddlLock
                    }
                }
                else
                {
                    if ( $WuData[$type].isLock )
                    {
                        $Subkey = $WuData[$type].Subkey
                        $WuData[$type].Dll = $WuData[$type].Dll.Trim('1')

                        Set-OwnerAndAccess -Path "HKLM:\$Subkey" -RecoverySDDL $SddlAccess

                        try
                        {
                            $OpenSubkey = $null
                            $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Subkey,'ReadWriteSubTree')
                            $OpenSubkey.SetValue('DLL', $WuData[$type].Dll, 'String')

                            if ( $WuData[$type].Dll2 )
                            {
                                $WuData[$type].Dll2 = $WuData[$type].Dll2.Trim('1')
                                $OpenSubkey.SetValue('DeploymentModule', $WuData[$type].Dll2, 'String')
                            }

                            $WuData[$type].isLock = $false

                            if ( $type -ceq 'DriverE' )  # + снять старый вариант блокировки, вдруг есть
                            {
                                try
                                {
                                    [string[]] $Value = ($OpenSubkey.GetValue('Prefixes','')).Replace('1','')
                                    if ( $Value ) { $OpenSubkey.SetValue('Prefixes', $Value, 'MultiString') }
                                }
                                catch {}
                            }
                            elseif ( $type -ceq 'Driver' )
                            {
                                try
                                {
                                    [string] $Value = $OpenSubkey.GetValue('URI','') -replace '(//)ss|ccc|mmm','${1}' -replace '/Windows$','/WindowsDriver'
                                    if ( $Value )
                                    {
                                        $OpenSubkey.SetValue('URI', $Value, 'String')
                                        $OpenSubkey.SetValue('LocalOnly', 0, 'Dword')
                                    }
                                }
                                catch {}
                            }
                            elseif ( $type -ceq 'CbsE' )
                            {
                                $OpenSubkey.Close()

                                $SubkeyBaseE = $WuData['BaseE'].Subkey
                                Set-OwnerAndAccess -Path "HKLM:\$SubkeyBaseE" -RecoverySDDL $SddlAccess
                                [Microsoft.Win32.Registry]::SetValue("HKEY_LOCAL_MACHINE\$SubkeyBaseE",'Prefixes', ([string[]]@('b.')), 'MultiString')
                                Set-OwnerAndAccess -Path "HKLM:\$SubkeyBaseE" -RecoverySDDL $SddlOrig
                            }
                        }
                        catch {}
                        finally { if ($OpenSubkey) { $OpenSubkey.Close() } }

                        if ( $type -ceq 'BaseE' -and $ToOff -ceq 'CbsE' )
                        {
                            Set-OwnerAndAccess -Path "HKLM:\$Subkey" -RecoverySDDL $SddlLock
                        }
                        else
                        {
                            Set-OwnerAndAccess -Path "HKLM:\$Subkey" -RecoverySDDL $SddlOrig
                        }
                    }
                }
            }
        }

        Write-Host
        Set-Svc Set-Service -Name 'wuauserv' -Status Stopped
    }

    Function Telemetry-Data-Collection-Disable {
        
        # Чтобы не собирала данные по отключению, и не адартировали защиту (уменьшить шансы) 
        Set-Svc -Do:$Act Set-Service -Name 'DiagTrack' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'diagnosticshub.standardcollector.service' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'InventorySvc' -StartupType Disabled -Status Stopped  # CompatTelRunner

        if ( $Act -eq 'Set' )
        {
            Stop-Service -Name PcaSvc -ErrorAction 0 -WarningAction 0  # CompatTelRunner
            Stop-Process -Name CompatTelRunner,diagtrackrunner -Force -ErrorAction 0 -WarningAction 0
        }

        [string[]] $tasks = '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
                            '\Microsoft\Windows\Application Experience\PcaPatchDbTask',
                            '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
                            '\Microsoft\Windows\Application Experience\SdbinstMergeDbTask',
                            '\Microsoft\Windows\Application Experience\StartupAppTask',
                            '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
                            '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'

        foreach ( $task in $tasks )
        {
            if ( -not ( Check-State-Task $task -Need Disabled -Return Bool ))
            {
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $task
                
                if ( $task -eq '\Microsoft\Windows\Application Experience\PcaPatchDbTask' )
                {
                    Set-TaskAccess -Do:$Act -TaskName $task -Access Lock
                }
            }
        }
    }

    if ( $Act -ne 'Default' )
    {
        if ( -not $NoHeader )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s8 ) { $L.s8 } else { 'Проверка ограничения обновлений для ЦО' }
                Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
            }
            else
            {
                $text = if ( $L.s9 ) { $L.s9 } else { 'Настройка ограничения обновлений для ЦО' }
                Write-Host "`n██ $text " -ForegroundColor Green -NoNewline
            }

            $text = if ( $L.s8_1 ) { $L.s8_1 } else { 'Функция' }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
        }

        if ( $Option -eq 'DisableDriverGP' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s10 ) { $L.s10 } else { 'Проверка Автоустановки драйверов | Групповая политика' }
                Write-Host "`n   $text`:`n" -ForegroundColor Cyan
            }
            else
            {
                $text = if ( $L.s11 ) { $L.s11 } else { 'Отключение Автоустановки драйверов | Групповая политика' }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan
            }

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не включать драйвера в обновления Windows" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить поиск драйверов устройств в Центре обновления Windows" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DontSearchWindowsUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Задать порядок поиска ... драйверов" (Включена, не искать)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 0

            # Комп\Адм. Шабл\Система\Установка устройства\ "Устанавливать одинаковый приоритет для драйверов с цифровой подписью" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'AllSigningEqual' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках при запросе доп. програмного обеспечения ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendRequestAdditionalSoftwareToWER' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках если установлен универсальный драйвер ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendGenericDriverNotFoundToWER' -Type DWord 1

            # Комп\Адм. Шабл\Система\Установка устройства\ "Запретить получение метаданных устройств из Интернета" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 1

            # Отключение поиска и скачивания приложений и значков для ваших устройства
            # Эти настройки в: Свойства системы -> Оборудование -> параметры установки устройств
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 0
        }
        elseif ( $Option -eq 'SetWuNoDriver' )
        {
            $WU = Get-Wu-Data

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s12 ) { $L.s12 } else { 'Проверка настройки ограничений: Без Драйверов' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                if (@($WU.Values.isLock -eq $false).Count -eq 11 -and $WU.Driver.isLock -and $WU.DriverE.isLock)
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Green
                }
                else
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s13 ) { $L.s13 } else { 'Настройка ограничений: Без Драйверов' }
                Write-Host "`n   $text" -ForegroundColor DarkCyan

                Write-Host
                Telemetry-Data-Collection-Disable

                Set-Wu-Config $WU @('Driver','DriverE')
            }
        }
        elseif ( $Option -eq 'SetWuSecure' )
        {
            $WU = Get-Wu-Data

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s14 ) { $L.s14 } else { 'Проверка настройки ограничений: Только Безопасность' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline


                if (@($WU.Values.isLock -eq $false).Count -eq 7  -and $WU.MSIE.isLock -and $WU.MSI.isLock -and $WU.DriverE.isLock `
                   -and $WU.Driver.isLock -and $WU.OSDepl.isLock -and $WU.WSetup.isLock )
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Green
                }
                else
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s15 ) { $L.s15 } else { 'Настройка ограничений: Только Безопасность' }
                Write-Host "`n   $text" -ForegroundColor DarkCyan

                Write-Host
                Telemetry-Data-Collection-Disable

                Set-Wu-Config $WU @('Driver','DriverE','MSI','MSIE', 'OSDepl','WSetup')
            }
        }
        elseif ( $Option -eq 'SetWuOnlyStoreUWP' )
        {
            $WU = Get-Wu-Data

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s16 ) { $L.s16 } else { 'Проверка настройки ограничений: Без обновлений' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                if (@($WU.Values.isLock -eq $true).Count -eq 9  -and -not $WU.AppXE.isLock -and -not $WU.AppX.isLock `
                   -and -not $WU.AppXS.isLock -and -not $WU.BaseE.isLock )
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Green
                }
                else
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Настройка ограничений: Без обновлений' }
                Write-Host "`n   $text" -ForegroundColor DarkCyan

                Write-Host
                Telemetry-Data-Collection-Disable

                Set-Wu-Config $WU @('Cbs', 'CbsE', 'CmdLine', 'Driver', 'DriverE', 'MSI', 'MSIE', 'OSDepl', 'WSetup')
            }
        }
        elseif ( $Option -eq 'SetWuNothing' )
        {
            $WU = Get-Wu-Data

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s18 ) { $L.s18 } else { 'Проверка настройки ограничений: Без обновлений и AppX' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                if (@($WU.Values.isLock -eq $true).Count -eq 13)
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Green
                }
                else
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Настройка ограничений: Без обновлений и AppX' }
                Write-Host "`n   $text" -ForegroundColor DarkCyan

                Write-Host
                Telemetry-Data-Collection-Disable

                Set-Wu-Config $WU $WU.Keys
            }
        }
        elseif ( $Option -eq 'SetWuDefault' )
        {
            $WU = Get-Wu-Data

            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s20 ) { $L.s20 } else { 'Проверка настройки ограничений: По умолчанию' }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                if (@($WU.Values.isLock -eq $false).Count -eq 13)
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Green
                }
                else
                {
                    Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                    Write-Host '●' -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Восстановление ограничений: По умолчанию' }
                Write-Host "`n   $text" -ForegroundColor Magenta

                Write-Host
                Telemetry-Data-Collection-Disable

                Set-Wu-Config $WU $null
            }
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        if ( -not $Option -or $Option -eq 'DisableDriverGP' )
        {
            $text = if ( $L.s22 ) { $L.s22 } else { "Восстановление обновлений драйверов | ГП (По умолчанию)" }
            Write-Host "`n   $text`:`n" -ForegroundColor Magenta

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не включать драйвера в обновления Windows" (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate'

            # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить поиск драйверов устройств в Центре обновления Windows" (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'DontSearchWindowsUpdate'

            # Комп\Адм. Шабл\Система\Установка устройства\ "Задать порядок поиска ... драйверов" (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching' -Name 'SearchOrderConfig'

            # Комп\Адм. Шабл\Система\Установка устройства\ "Устанавливать одинаковый приоритет для драйверов с цифровой подписью" (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'AllSigningEqual'

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках при запросе доп. програмного обеспечения ..." (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendRequestAdditionalSoftwareToWER'

            # Комп\Адм. Шабл\Система\Установка устройства\ "Не отправлять отчет об ошибках если установлен универсальный драйвер ..." (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeviceInstall\Settings' -Name 'DisableSendGenericDriverNotFoundToWER'

            # Комп\Адм. Шабл\Система\Установка устройства\ "Запретить получение метаданных устройств из Интернета" (Не задана)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork'

            # Отключение поиска и скачивания приложений и значков для ваших устройства
            # Эти настройки в: Свойства системы -> Оборудование -> параметры установки устройств
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Device Metadata' -Name 'PreventDeviceMetadataFromNetwork' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' -Name 'SearchOrderConfig' -Type DWord 1
        }

        if ( -not $Option )
        {
            Set-Update-Restrictions -Act Set -Option SetWuDefault -NoHeader
        }
        elseif ( $Option -ne 'DisableDriverGP' )
        {
            Set-Update-Restrictions -Act Set -Option SetWuDefault
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        if ( $Act -eq 'Default' -or $Option -eq 'DisableDriverGP' )
        {
            $text = if ( $L.s23 ) { $L.s23 } else { 'Необходимо перезагрузиться!' }
            Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen
        }

        Get-Pause
    }
}
