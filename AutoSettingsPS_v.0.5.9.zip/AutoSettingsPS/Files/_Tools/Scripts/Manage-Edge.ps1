﻿
<#
.SYNOPSIS
 Установка Edge или Edge WebView2, или Полное удаление всех Edge или WebView2

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется внешняя функция Set-Reg для установки/удаления параметров реестра, с проверкой и выводом результата.
 Используется внешняя функция Set-Tsk для настройки/удаления задач, с проверкой и выводом результата.
 Используется внешняя функция Get-Task-FullPaths для получения полных путей ко всем задачам, по совпадениям с указанным именем
 Используется внешняя функция Test-Internet для проверки состояния интернета и доступа для скрипта (консоли PS) в интернет
 Используется внешняя функция Get-ContentWebPage
 Используется внешняя функция Download-File для загрузки файлов по прямым линкам
 Используется внешняя функция Set-Apps-Management для удаления Системных/Store Apps от Edge
 Используется внешняя функция Get-ExeArch

 Удаляет Edge/WebView2, в том числе версии 111 и выше. Понимает установки MSI.
 Удаляет все UWP, включая системные. (Системные можно установить обратно через меню [2] > [14] > [9!0])

.EXAMPLE
    Manage-Edge -Remove -Act Check
    Manage-Edge -Remove -Act Check -Components Edge
    Manage-Edge -Remove -Act Check -Components EdgeWebView
    Manage-Edge -Remove -Act Check -Components Edge,EdgeWebView

    Manage-Edge -Remove -Act Set -Components EdgeWebView
    Manage-Edge -Remove -Act Set -Components Edge

    Manage-Edge -Install -Act Check -Components Edge

    Manage-Edge -Install -Act Set -Components Edge
    Manage-Edge -Install -Act Set -Components EdgeWebView
    Manage-Edge -Install -Act Set -Components Edge,EdgeWebView


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  12-04-2023
 =================================================

#>
Function Manage-Edge {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Install' )]
        [switch] $Install
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Remove'  )]
        [switch] $Remove
       ,
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Edge', 'EdgeWebView' )]
        [string[]] $Components = 'Edge'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' ) { $Act = 'Set' }
    if ( $Act -eq 'Check'   ) { $Color = 'Yellow' } else { $Color = 'Cyan' }

    if ( $Install )
    {
        if ( $Act -eq 'Check' )
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Проверка Установки' }
            Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
            Write-Host ($Components -join ', ') -ForegroundColor DarkCyan -NoNewline
        }
        else
        {
            $text = if ( $L.s7 ) { $L.s7 } else { 'Установка' }
            Write-Host "`n██ $text`: " -ForegroundColor Magenta -NoNewline
            Write-Host ($Components -join ', ') -ForegroundColor DarkCyan -NoNewline
        }

        $text = if ( $L.s8 ) { $L.s8 } else { 'Функция' }
        Write-Host " | $text`: $NameThisFunction`n" -ForegroundColor DarkGray


        [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                              'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

        [psobject] $OpenSubKey = $null
        [array] $Installed = @()
        [bool] $MSI = $false

        foreach ( $RegKey in $RegKeys )
        {
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

            if ( $OpenSubKey )
            {
                foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                {
                    $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                    $DisplayVersion  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayVersion',$null)
                    $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                    if (( $DisplayName -like '*Microsoft*Edge*' ) -and $DisplayVersion -and -not ( $DisplayName -like '*Update*' ))
                    {
                        if ( $UninstallString -like '*MsiExec*' ) { $MSI = $true } else { $MSI = $false }

                        $Installed += [PSCustomObject] @{
                            DisplayName    = $DisplayName
                            DisplayVersion = $DisplayVersion
                            MSI            = $MSI
                        }
                    }
                }

                $OpenSubKey.Close()
            }
        }


        if ( $Components -like 'Edge' )
        {
            if ( $Installed.Where({ $_.DisplayName -notlike '*WebView*' }) )
            {
                foreach ( $InstalledEdge in ( $Installed.Where({ $_.DisplayName -notlike '*WebView*' }) ))
                {
                    $text = if ( $L.s9 ) { $L.s9 } else { 'Уже Установлен' }
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$($InstalledEdge.DisplayName) " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "| $($InstalledEdge.DisplayVersion) | MSI: $($InstalledEdge.MSI)" -ForegroundColor DarkGray
                }
            }
            else
            {
                if ( $Act -eq 'Set' )
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Загрузка и установка Microsoft Edge Chromium' }
                    Write-Host "   $text" -ForegroundColor Cyan

                    # Enterprise offline json 'https://edgeupdates.microsoft.com/api/products'

                    [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))
                    [string] $FileExe  = "$TempPath\MicrosoftEdgeEnterpriseX86.msi"
                    [string] $URL      = 'https://go.microsoft.com/fwlink/?linkID=2093505' # x86 msi
                    [string] $Arch     = 'x86'

                    if ( [System.Environment]::Is64BitOperatingSystem )
                    {
                        $Arch    = 'x64'
                        $FileExe = "$TempPath\MicrosoftEdgeEnterpriseX64.msi"
                        $URL     = 'https://go.microsoft.com/fwlink/?linkID=2093437' # x64 msi
                    }

                    Write-Host "   File: $FileExe" -ForegroundColor DarkGray
                    Write-Host "    URL: $URL | $Arch" -ForegroundColor DarkGray

                    if ( -not ( Test-Internet -Bool -Access ))
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { 'Нет доступа в Интернет для PS' }
                        Write-Host "   $text" -ForegroundColor DarkYellow

                        $NeedFix = $true
                    }
                    else
                    {
                        Remove-Item -LiteralPath $FileExe -Force -ErrorAction SilentlyContinue

                        #$CurLang = [System.Globalization.CultureInfo]::CurrentUICulture.TwoLetterISOLanguageName
                        #$ResultDownload = Download-File "https://go.microsoft.com/fwlink/?linkid=2108834&Channel=Stable&language=$CurLang" $FileExe  # web install
                        $ResultDownload = Download-File -FileUrl $URL -DestFile $FileExe

                        Start-Sleep -Milliseconds 200

                        if ( [System.IO.File]::Exists($FileExe) )
                        {
                            # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
                            $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
                            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                            if ( $OpenSubKey )
                            {
                                foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
                                {
                                    if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                                    {
                                        $Path = "HKLM:\$SubKey\$Name"
                                        Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                                    }
                                }

                                $OpenSubkey.Close()
                            }

                            try
                            {
                                #$P = [System.Diagnostics.Process]::Start($FileExe,'/silent /install')
                                $P = [System.Diagnostics.Process]::Start('msiexec.exe'," /i ""$FileExe"" /passive /norestart")  #  allusers=1  DONOTCREATEDESKTOPSHORTCUT=TRUE
                                $P.WaitForExit()

                                Write-Host "   ExitCode: $($P.ExitCode)" -ForegroundColor DarkGray
                            }
                            catch { Write-Host "   Setup Error: $FileExe" -ForegroundColor Red }

                            Start-Sleep -Milliseconds 200

                            [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                                  'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

                            [psobject] $OpenSubKey = $null
                            $Installed = @()
                            foreach ( $RegKey in $RegKeys )
                            {
                                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                                if ( $OpenSubKey )
                                {
                                    foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                                    {
                                        $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                                        $DisplayVersion  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayVersion',$null)
                                        $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                                        if (( $DisplayName -like '*Microsoft*Edge*' ) -and $DisplayVersion -and -not ( $DisplayName -match 'webview|Update' ))
                                        {
                                            if ( $UninstallString -like '*MsiExec*' ) { $MSI = $true } else { $MSI = $false }

                                            $Installed += [PSCustomObject] @{
                                                DisplayName    = $DisplayName
                                                DisplayVersion = $DisplayVersion
                                                MSI            = $MSI
                                            }
                                        }
                                    }

                                    $OpenSubKey.Close()
                                }
                            }

                            if ( $Installed.Count )
                            {
                                $text = if ( $L.s18 ) { $L.s18 } else { 'Установился' }
                                Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                                Write-Host "$($Installed.DisplayName) " -ForegroundColor DarkCyan -NoNewline
                                Write-Host "| $($Installed.DisplayVersion) | MSI: $($Installed.MSI)" -ForegroundColor DarkGray

                                $MSedgeExe = (Get-Item -Path "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
                                "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe" -ErrorAction SilentlyContinue).Where({$_},'First').Fullname

                                if ( $MSedgeExe )
                                {
                                    if ( [System.IO.Directory]::Exists("$env:PUBLIC\Desktop") )
                                    {
                                        [bool] $Exist = $false

                                        # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
                                        (Get-ChildItem -File -LiteralPath "$env:PUBLIC\Desktop" -ErrorAction SilentlyContinue).Where({ $_.Extension -eq '.lnk' }).Foreach({
                                            if ( (Get-Content -Encoding UTF8 "$($_.FullName)" -ErrorAction SilentlyContinue) -like "*$MSedgeExe*" ) { $Exist = $true }
                                        })

                                        if ( -not $Exist )
                                        {
                                            $text = if ( $L.s13 ) { $L.s13 } else { 'Создание Ярлыка' }
                                            Write-Host "   $text`: $env:PUBLIC\Desktop\Microsoft Edge.lnk" -ForegroundColor DarkGray

                                            $WScriptShell = New-Object -ComObject WScript.Shell
                                            $Shortcut = $WScriptShell.CreateShortcut("$env:PUBLIC\Desktop\Microsoft Edge.lnk")
                                            $Shortcut.TargetPath   = "$MSedgeExe"
                                            $shortcut.IconLocation = "$MSedgeExe,0"
                                            $Shortcut.Description  = 'Microsoft Edge'
                                            $Shortcut.Save()
                                        }
                                    }
                                }
                            }
                            else
                            {
                                $text = if ( $L.s14 ) { $L.s14 } else { 'Не удалось установить' }
                                Write-Host "   $text " -ForegroundColor Yellow

                                $NeedFix = $true
                            }
                        }
                        else
                        {
                            $text = if ( $L.s19 ) { $L.s19 } else { 'Не удалось загрузить' }
                            Write-Host "   $text " -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { 'Microsoft Edge Chromium не установлен' }
                    Write-Host "   $text" -ForegroundColor Yellow

                    $NeedFix = $true
                }
                
            }
        }

        if ( $Components -like 'EdgeWebView' )
        {
            if ( $Installed.Where({ $_.DisplayName -like '*WebView*' }) )
            {
                foreach ( $InstalledEdge in ( $Installed.Where({ $_.DisplayName -like '*WebView*' }) ))
                {
                    $text = if ( $L.s9 ) { $L.s9 } else { 'Уже Установлен' }
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$($InstalledEdge.DisplayName) " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "| $($InstalledEdge.DisplayVersion) | MSI: $($InstalledEdge.MSI)" -ForegroundColor DarkGray
                }
            }
            else
            {
                if ( $Act -eq 'Set' )
                {
                    $text = if ( $L.s20 ) { $L.s20 } else { 'Загрузка и установка Microsoft Edge WebView' }
                    Write-Host "   $text" -ForegroundColor Cyan

                    if ( -not ( Test-Internet -Bool -Access ))
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { 'Нет доступа в Интернет для PS' }
                        Write-Host "   $text" -ForegroundColor DarkYellow

                        $NeedFix = $true
                    }
                    else
                    {
                        [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                        $FileExe = "$TempPath\MicrosoftEdgeWebview2Setup.exe"
                        Remove-Item -LiteralPath $FileExe -Force -ErrorAction SilentlyContinue

                        $ResultDownload = Download-File "https://go.microsoft.com/fwlink/?LinkId=2124703" $FileExe

                        if ( [System.IO.File]::Exists($FileExe) )
                        {
                            # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
                            $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
                            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                            if ( $OpenSubKey )
                            {
                                foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
                                {
                                    if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                                    {
                                        $Path = "HKLM:\$SubKey\$Name"
                                        Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                                    }
                                }

                                $OpenSubkey.Close()
                            }

                            try
                            {
                                $P = [System.Diagnostics.Process]::Start($FileExe,' /silent /install')
                                $P.WaitForExit()

                                Write-Host "   ExitCode: $($P.ExitCode)" -ForegroundColor DarkGray
                            }
                            catch { Write-Host "   Setup Error: $FileExe" -ForegroundColor Red }

                            Start-Sleep -Milliseconds 200

                            [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                                                  'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

                            [psobject] $OpenSubKey = $null
                            $Installed = @()
                            foreach ( $RegKey in $RegKeys )
                            {
                                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                                if ( $OpenSubKey )
                                {
                                    foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
                                    {
                                        $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                                        $DisplayVersion  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayVersion',$null)
                                        $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                                        if ( $DisplayName -like '*Microsoft*Edge*Webview*' -and $DisplayVersion )
                                        {
                                            if ( $UninstallString -like '*MsiExec*' ) { $MSI = $true } else { $MSI = $false }

                                            $Installed += [PSCustomObject] @{
                                                DisplayName    = $DisplayName
                                                DisplayVersion = $DisplayVersion
                                                MSI            = $MSI
                                            }
                                        }
                                    }

                                    $OpenSubKey.Close()
                                }
                            }

                            if ( $Installed.Count )
                            {
                                $text = if ( $L.s12 ) { $L.s12 } else { 'Установился' }
                                Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                                Write-Host "$($Installed.DisplayName) " -ForegroundColor DarkCyan -NoNewline
                                Write-Host "| $($Installed.DisplayVersion) | MSI: $($Installed.MSI)" -ForegroundColor DarkGray
                            }
                            else
                            {
                                $text = if ( $L.s14 ) { $L.s14 } else { 'Не удалось установить' }
                                Write-Host "   $text " -ForegroundColor Yellow

                                $NeedFix = $true
                            }
                        }
                        else
                        {
                            $text = if ( $L.s19 ) { $L.s19 } else { 'Не удалось загрузить' }
                            Write-Host "   $text " -ForegroundColor Yellow

                            $NeedFix = $true
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s21 ) { $L.s21 } else { 'Microsoft Edge WebView не установлен' }
                    Write-Host "   $text" -ForegroundColor Yellow

                    $NeedFix = $true
                }
            }
        }

        Return
    }

    # Далее если Удаление

    #region remove

    Function Extract-Setup {

        [CmdletBinding( SupportsShouldProcess = $false )]
        [OutputType([string])]
        param(
            [Parameter( Mandatory = $true, Position = 0 )]
            [String]$BasisFile
           ,
            [Parameter( Mandatory = $true, Position = 1 )]
            [String]$Archive
        )

        [string] $FileArch = 'x86'

        if ( [System.Environment]::Is64BitOperatingSystem )
        {
            $FileArch = Get-ExeArch $BasisFile
        }

        [string] $File = "$DismScratchDirGlobal\setup$FileArch.exe"

        if ( [System.IO.File]::Exists($File) )
        {
            Return $File
        }
        else
        {
            & $7z e "$Archive" -o"$DismScratchDirGlobal" "-i!setup$FileArch.exe" -aoa -bso0 -bse0 -bsp0

            if ( [System.IO.File]::Exists($File) )
            {
                Return $File
            }
            else { Return '' }
        }
    }

    Function Fix-Setup {

        [CmdletBinding( SupportsShouldProcess = $false )]
        [OutputType([bool])]
        param(
            [Parameter( Mandatory = $true, Position = 0 )]
            [String] $File
        )

        [bool] $Result = $false

        if ( [System.IO.File]::Exists($File) )
        {
            [string] $FileArch = 'x86'

            if ( [System.Environment]::Is64BitOperatingSystem )
            {
                $FileArch = Get-ExeArch $File
            }

            if ( $FileArch -eq 'x64' )
            {
                $Pattern = '(?<bytes>,255,132,192,(116|117),34,64,182,1,(\d{1,3},){9}255,72,139,76,36,72),' # x64
            }
            else
            {
                $Pattern = '(?<bytes>,255,132,192,(117|116),88,161,(\d{1,3},){9}0,100,139,21,44,0,0,0),'    # x86
            }

            [Byte[]] $FileBytes   = [System.IO.File]::ReadAllBytes($File)
            [string] $StringBytes = [string]::join(',',$FileBytes)

            # 4 = ExplicitCapture (группировать только явно именованные или нумерованные группы в форме (?<name>...))
            $G = @([regex]::Matches($StringBytes,$Pattern,4).Groups).Where({$_.Name -eq 'bytes'})

            if ( $G.Count -eq 1 )
            {
                 [int] $Offset = $StringBytes.Remove($G.Index).Split(',').Count + 3   #[regex]::Replace($StringBytes,"$($G.Value).*",'').Split(',').Count + 3

                 [int] $B = $FileBytes[$Offset]
                [bool] $fix = $false

                if ( $FileArch -eq 'x64' )
                {
                    if ( $B -eq 116 ) { $FileBytes[$Offset] = 117 ; $fix = $true }
                }
                else
                {
                    if ( $B -eq 117 ) { $FileBytes[$Offset] = 116 ; $fix = $true }
                }

                if ( $fix )
                {
                    try
                    {
                        [System.IO.File]::WriteAllBytes($File, $FileBytes)

                        [FileUtility.Tool]::Unsign($File)

                        $Result = $true
                    }
                    catch {}
                }
            }
        }

        Return $Result
    }

    $UnsignTool = @'
using System;

namespace FileUtility
{
    public static class Tool
    {
        [System.Runtime.InteropServices.DllImport("Imagehlp.dll")]
        private static extern bool ImageRemoveCertificate(IntPtr handle, int index);

        private static void UnsignFile(string file)
        {
            using (System.IO.FileStream fs = new System.IO.FileStream(file, System.IO.FileMode.Open, System.IO.FileAccess.ReadWrite))
            {
                ImageRemoveCertificate(fs.SafeFileHandle.DangerousGetHandle(), 0);
                fs.Close();
            }
        }

        public static void Unsign(string[] files)
        {
            foreach (string file in files)
            {
                try { UnsignFile(file); } catch (Exception) {}
            }
        }
    }
}
'@
    if ( -not ( 'FileUtility.Tool' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new(@('System.dll'))
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $UnsignTool -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s22 ) { $L.s22 } else { 'Проверка Удаления' }
        Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
        Write-Host ($Components -join ', ') -ForegroundColor DarkCyan -NoNewline
    }
    else
    {
        $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
        Write-Host "`n██ $text`: " -ForegroundColor White -NoNewline
        Write-Host ($Components -join ', ') -ForegroundColor DarkCyan -NoNewline
    }

    $text = if ( $L.s8 ) { $L.s8 } else { 'Функция' }
    Write-Host " | $text`: $NameThisFunction`n" -ForegroundColor DarkGray

    if ( -not $7z ) { Write-Host '   No 7z.exe' -ForegroundColor Red ; Return }

    # Карта-шаблон, пока не используется для действий
    [hashtable] $EdgeGuids = @{

        'Microsoft Edge'          = '{56EB18F8-B008-4CBD-B6D2-8C97FE7E9062}'  # Stable
        'Microsoft Edge Beta'     = '{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}'
        'Microsoft Edge Canary'   = '{65C35B14-6C1D-4122-AC46-7148CC9D6497}'
        'Microsoft Edge Dev'      = '{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}'
        'Microsoft Edge WebView2' = '{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
        'Microsoft Edge Update'   = '{F3C4FE00-EFD5-403B-9569-398A20F1BA4A}'
    }

    [int] $FoundEdge = 0

    [bool] $RemoveEdge        = $false
    [bool] $RemoveEdgeWebView = $false
    [bool] $RemoveEdgeUpdate  = $false
    [bool] $MSI               = $false

    if ( $Components -like 'Edge'            ) { $RemoveEdge        = $true }
    if ( $Components -like 'EdgeWebView'     ) { $RemoveEdgeWebView = $true }
    if ( $RemoveEdge -and $RemoveEdgeWebView ) { $RemoveEdgeUpdate  = $true }

    [string] $All = ''
    [string] $Exe = ''
    [string] $Name  = ''
    [string] $DisplayName = ''
    [string] $UninstallArgs = ''
    [string] $UninstallArgsMsi = ''
    [string] $Version = ''
    [string] $SetupExe = ''
    [bool] $NeedSpecFile = $false

    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    [psobject] $OpenSubKey = $null

    [System.Collections.Generic.List[PSObject]] $Installed = @()

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
            {
                $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                $DisplayVersion  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayVersion',$null)
                $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                if ( $UninstallString -like '*MsiExec*' ) { $MSI = $true } else { $MSI = $false }

                if ( $DisplayName -like '*Microsoft*Edge*WebView*' -and $DisplayVersion )
                {
                    if ( $Components -like 'EdgeWebView' )
                    {
                        $text = if ( $L.s24 ) { $L.s24 } else { 'Установлен' }
                        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                        Write-Host "$DisplayName " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "| $DisplayVersion | MSI: $MSI" -ForegroundColor DarkGray

                        $Installed.Add( [PSCustomObject]@{
                            Name      = 'Microsoft Edge WebView2'
                            Version   = $DisplayVersion
                            Location  = $InstallLocation
                            Uninstall = $UninstallString

                            MSI       = $MSI
                            GUID      = $EdgeGuids['Microsoft Edge WebView2']
                            RegUninst = "$RegKey\$SubKey"
                        })
                    }
                }
                elseif (( $DisplayName -like '*Microsoft*Edge*' ) -and $DisplayVersion )
                {
                    if ( $DisplayName -like '*Edge*Update*' ) { Continue }

                    if ( $Components -like 'Edge' )
                    {
                        $text = if ( $L.s24 ) { $L.s24 } else { 'Установлен' }
                        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                        Write-Host "$DisplayName " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "| $DisplayVersion | MSI: $MSI" -ForegroundColor DarkGray

                        $Installed.Add( [PSCustomObject]@{
                            Name      = $DisplayName
                            Version   = $DisplayVersion
                            Location  = $InstallLocation
                            Uninstall = $UninstallString

                            MSI       = $MSI
                            GUID      = $EdgeGuids[$DisplayName]
                            RegUninst = "$RegKey\$SubKey"
                        })
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    if ( -not $Installed.Count )
    {
        $text = if ( $L.s25 ) { $L.s25 } else { 'Не установлен' }
        Write-Host "   $text`: " -ForegroundColor Green -NoNewline
        Write-Host ($Components -join ', ') -ForegroundColor DarkCyan
    }


    $text = if ( $L.s26 ) { $L.s26 } else { 'Проверка файлов и параметров Microsoft Edge' } # Checking Edge files and settings
    Write-Host "   $text" -ForegroundColor DarkGray

    [string[]] $RegKeys = 'SOFTWARE\Microsoft\EdgeUpdate\ClientState',
                          'SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\ClientState'

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
            {
                try { $Openkey = $OpenSubKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                catch { $Openkey = $null }

                if ( $Openkey )
                {
                    foreach ( $Name in ( $Openkey.GetValueNames() -like '*experiment*' ))
                    {
                        $Path = "HKLM:\$RegKey\$SubKey"

                        $FoundEdge++

                        if ( $Act -eq 'Check' )
                        {
                            $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                            Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                            Write-Host "$Path | Name: $Name" -ForegroundColor DarkGray

                            $NeedFix = $true
                        }
                        else
                        {
                            Set-Reg Remove-ItemProperty -Path $Path -Name $Name
                        }
                    }

                    $Openkey.Close()
                }
            }

            $OpenSubKey.Close()
        }
    }

    Get-ChildItem -Directory -Path "$env:USERPROFILE\AppData\Local\Microsoft\Edge*", "${env:ProgramFiles(x86)}\Microsoft\Edge*",
    "$env:ProgramFiles\Microsoft\Edge*" -ErrorAction SilentlyContinue | ForEach-Object {
        
        $NeedSpecFile = $false
        
        $Exe = (Get-ChildItem -File -Path "$($_.FullName)\Application\*\Installer\*" -ErrorAction SilentlyContinue).Where({$_.Name -like '*.exe'},'Last').FullName

        $Name = '' ; $UninstallArgs = '' ; $All = "| ({0})" -f $(if ( $L.s27 ) { $L.s27 } else { 'Все пользователи' })

        if ( $Exe -like '*\Program Files*\Edge SxS\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Canary'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-sxs --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge SxS\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Canary' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-sxs'
        }
        elseif ( $Exe -like '*\Program Files*\Edge Dev\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Dev'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-dev --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge Dev\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Dev' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-dev'
        }
        elseif ( $Exe -like '*\Program Files*\Edge Beta\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Beta'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-beta --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge Beta\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $Name = 'Microsoft Edge Beta' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge-beta'
        }
        elseif ( $Exe -like '*\Program Files*\Edge\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $NeedSpecFile = $true

            $Name = 'Microsoft Edge'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge --system-level'
        }
        elseif ( $Exe -like '*\Users\*\Edge\Application\*' )
        {
            if ( -not $RemoveEdge ) { Return } # Пропуск итерации

            $NeedSpecFile = $true

            $Name = 'Microsoft Edge' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --delete-profile --msedge'
        }
        elseif ( $Exe -like '*\Program Files*\EdgeWebView\Application\*' )
        {
            if ( -not $RemoveEdgeWebView ) { Return } # Пропуск итерации

            $NeedSpecFile = $true

            $Name = 'Microsoft Edge WebView2'
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --msedgewebview --system-level'
        }
        elseif ( $Exe -like '*\Users\*\EdgeWebView\Application\*' )
        {
            if ( -not $RemoveEdgeWebView ) { Return } # Пропуск итерации

            $NeedSpecFile = $true

            $Name = 'Microsoft Edge WebView2' ; $All = ''
            $UninstallArgs = ' --uninstall --force-uninstall --verbose-logging --msedgewebview'
        }

        if ( $Exe )
        {
            if ( $UninstallArgs )
            {
                $Version  = $Exe -replace '.+\\(\d+[.]\d+[.]\d+[.]\d+)\\.+','$1'
                $UninstEdgeData = $Installed.Where({( $_.Name -eq $Name ) -and ( $_.Version -eq $Version )},'First')

                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                Write-Host "`n   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Name " -ForegroundColor White -NoNewline
                Write-Host "| $Version " -ForegroundColor DarkGray -NoNewline

                if ( $UninstEdgeData.MSI )
                {
                    Write-Host "| MSI: True $All" -ForegroundColor DarkGray
                    $UninstallArgsMsi = '{0} {1}' -f '/passive', $($UninstEdgeData.Uninstall -replace '\s*MsiExec(.exe)?\s*','')

                    Write-Host "   MsiExec.exe $UninstallArgsMsi" -ForegroundColor DarkGray
                }
                else
                {
                    Write-Host "| MSI: false $All" -ForegroundColor DarkGray
                    Write-Host "   $Exe $UninstallArgs" -ForegroundColor DarkGray
                }

                $FoundEdge++

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    $Path = 'HKLM:\{0}' -f $UninstEdgeData.RegUninst

                    if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$($UninstEdgeData.RegUninst)",'NoRemove',$null) )
                    {
                        Set-Reg Remove-ItemProperty -Path $Path -Name 'NoRemove'
                    }

                    if ( $UninstEdgeData.MSI )
                    {
                        $StartInfo = [System.Diagnostics.ProcessStartInfo]::new("$env:windir\system32\MsiExec.exe")
                        $StartInfo.Arguments   = $UninstallArgsMsi
                    }
                    else
                    {
                        $StartInfo = [System.Diagnostics.ProcessStartInfo]::new($Exe)
                        $StartInfo.WindowStyle = 'Hidden'
                        $StartInfo.Arguments   = $UninstallArgs
                    }

                    $StartInfo.UseShellExecute = $false

                    [version] $v = '0.0.0.0' ; if ( $NeedSpecFile -and [version]::TryParse($Version, [ref] $v) -and $v.Major -lt 110 )  { $NeedSpecFile = $false }

                    if ( $NeedSpecFile )
                    {
                        [string] $Dir  = [System.IO.Path]::GetDirectoryName($Exe)
                        [string] $FileName = [System.IO.Path]::GetFileName($Exe)
                        [string] $FileNameNew = '{0}_0' -f $FileName

                        Stop-Process -Name '*Edge*','Widgets','Setup' -Force -ErrorAction SilentlyContinue

                        # выводим установочный файл из жёсткой ссылки (чтобы не влиять на другие установки эджа)
                        Copy-Item   -LiteralPath $Exe -Destination $Dir\$FileNameNew -Force -ErrorAction SilentlyContinue
                        Remove-Item -LiteralPath $Exe -Force -ErrorAction SilentlyContinue
                        Move-Item   -LiteralPath $Dir\$FileNameNew -Destination $Exe -Force -ErrorAction Continue

                        # пробуем пофиксить exe
                        if ( Fix-Setup -File $Exe )
                        {
                            $text = '| F+'

                            try
                            {
                                $P = [System.Diagnostics.Process]::Start($StartInfo)
                                $P.WaitForExit()

                                Start-Sleep -Milliseconds 200

                                if ( -not [System.IO.File]::Exists($Exe) )
                                {
                                    Write-Host "   ExitCode +: $($P.ExitCode) | S:$NeedSpecFile $text" -ForegroundColor DarkGray
                                }
                                else
                                {
                                    Write-Host "   ExitCode -: $($P.ExitCode) | S:$NeedSpecFile $text" -ForegroundColor DarkGray
                                }

                                $P.Close()
                            }
                            catch { Write-Host "   Uninstall Error: $Exe | S:$NeedSpecFile $text" -ForegroundColor Red }
                        }
                        else
                        {
                            $text = '| F-'
                        }

                        # Если удаление не выполнилось, заменяем exe из архива.
                        if ( [System.IO.File]::Exists($Exe) )
                        {
                            [string] $SetupExe = Extract-Setup -BasisFile $Exe -Archive $FileFolderGlobal\Edge.7z

                            if ( $SetupExe )
                            {
                                $text = '{0} | R+' -f $text

                                Stop-Process -Name '*Edge*','Widgets','Setup' -Force -ErrorAction SilentlyContinue

                                Remove-Item -LiteralPath $Exe -Force -ErrorAction SilentlyContinue
                                Copy-Item -LiteralPath $SetupExe -Destination $Exe -Force -ErrorAction SilentlyContinue

                                try
                                {
                                    $P = [System.Diagnostics.Process]::Start($StartInfo)
                                    $P.WaitForExit()

                                    Start-Sleep -Milliseconds 200

                                    if ( -not [System.IO.File]::Exists($Exe) )
                                    {
                                        Write-Host "   ExitCode +: $($P.ExitCode) | S:$NeedSpecFile $text" -ForegroundColor DarkGray
                                    }
                                    else
                                    {
                                        Write-Host "   ExitCode -: $($P.ExitCode) | S:$NeedSpecFile $text" -ForegroundColor DarkGray
                                    }

                                    $P.Close()
                                }
                                catch { Write-Host "   Uninstall Error: $Exe | S:$NeedSpecFile $text" -ForegroundColor Red }
                            }
                        }
                    }
                    else
                    {
                        try
                        {
                            Stop-Process -Name '*Edge*','Widgets','Setup' -Force -ErrorAction SilentlyContinue

                            $P = [System.Diagnostics.Process]::Start($StartInfo)
                            $P.WaitForExit()

                            Start-Sleep -Milliseconds 200

                            if ( -not [System.IO.File]::Exists($Exe) )
                            {
                                Write-Host "   ExitCode +: $($P.ExitCode) | S:$NeedSpecFile" -ForegroundColor DarkGray
                            }
                            else
                            {
                                Write-Host "   ExitCode -: $($P.ExitCode) | S:$NeedSpecFile" -ForegroundColor DarkGray
                            }

                            $P.Close()
                        }
                        catch { Write-Host "   Uninstall Error: $Exe | S:$NeedSpecFile" -ForegroundColor Red }
                    }

                    if ( -not [System.IO.File]::Exists($Exe) )
                    {
                        Write-Host "   Uninstall: true" -ForegroundColor DarkGreen

                        if ( $Path )
                        {
                            # Удаление раздела в Uninstall, бывает остается, приводит к проблемам: невозможности повторной установки, особенно от msi
                            Set-Reg Remove-Item -Path $Path
                        }
                    }
                    else
                    {
                        Write-Host "   Uninstall: false" -ForegroundColor Red
                    }
                }
            }
            else
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Не известный Microsoft Edge' }
                Write-Host "   $text`: " -ForegroundColor DarkGray
                Write-Host "   $Exe" -ForegroundColor DarkGray
            }
        }
    }

    Start-Sleep -Milliseconds 200

    [psobject] $OpenSubKey = $null

    [System.Collections.Generic.List[PSObject]] $Installed = @()
    [array] $InstalledNamesAll = @()

    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in ( $OpenSubKey.GetSubKeyNames() ))
            {
                $DisplayName     = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)
                $DisplayVersion  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayVersion',$null)
                $InstallLocation = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'InstallLocation',$null)
                $UninstallString = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'UninstallString',$null)

                if ( $UninstallString -like '*MsiExec*' ) { $MSI = $true } else { $MSI = $false }

                if ( $DisplayName -like '*Microsoft*Edge*WebView*' -and $DisplayVersion )
                {
                    $InstalledNamesAll += 'Microsoft Edge WebView2'

                    if ( $Components -like 'EdgeWebView' )
                    {
                        if ( $Act -eq 'Set' )
                        {
                            $text = if ( $L.s24 ) { $L.s24 } else { 'Установлен' }
                            Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                            Write-Host "$DisplayName " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "| $DisplayVersion | MSI: $MSI" -ForegroundColor DarkGray
                        }

                        $Installed.Add( [PSCustomObject]@{
                            Name      = 'Microsoft Edge WebView2'
                            Version   = $DisplayVersion
                            Location  = $InstallLocation
                            Uninstall = $UninstallString

                            MSI       = $MSI
                            GUID      = $EdgeGuids['Microsoft Edge WebView2']
                            RegUninst = "$RegKey\$SubKey"
                        })
                    }
                }
                elseif (( $DisplayName -like '*Microsoft*Edge*' ) -and $DisplayVersion )
                {
                    if ( $DisplayName -like '*Edge*Update*' ) { Continue }

                    $InstalledNamesAll += $DisplayName

                    if ( $Components -like 'Edge' )
                    {
                        if ( $Act -eq 'Set' )
                        {
                            $text = if ( $L.s24 ) { $L.s24 } else { 'Установлен' }
                            Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                            Write-Host "$DisplayName " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "| $DisplayVersion | MSI: $MSI" -ForegroundColor DarkGray
                        }

                        $Installed.Add( [PSCustomObject]@{
                            Name      = $DisplayName
                            Version   = $DisplayVersion
                            Location  = $InstallLocation
                            Uninstall = $UninstallString

                            MSI       = $MSI
                            GUID      = $EdgeGuids[$DisplayName]
                            RegUninst = "$RegKey\$SubKey"
                        })
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    if ( $Installed.Count )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s29 ) { $L.s29 } else { 'Не все Microsoft Edge удалились' }
            Write-Host "   $text`: " -ForegroundColor Yellow -NoNewline
            Write-Host ($Installed.Name -join ', ') -ForegroundColor DarkYellow
        }

        $NeedFix = $true
        $FoundEdge++
    }

    # Удаление всех Edge Apps
    if ( $RemoveEdge )
    {
        [string[]] $AppNames = 'Microsoft.MicrosoftEdge.Stable', 'Microsoft.MicrosoftEdge.Beta', 'Microsoft.MicrosoftEdge.Dev', 'Microsoft.MicrosoftEdge.Canary',
                               'Microsoft.MicrosoftEdge', 'Microsoft.MicrosoftEdgeDevToolsClient'

        if ( $Act -eq 'Check' ) { [bool] $OnlyCheck = $true } else { [bool] $OnlyCheck = $false }

        Set-Apps-Management -Option RunUninstallApps -RemoveSpecifiedPackNames $AppNames -CheckSpecApps:$OnlyCheck

        Write-Host
    }

    if ( $RemoveEdge        -and -not ( $InstalledNamesAll -like '*WebView*'                                 )) { $RemoveEdgeUpdate = $true }
    if ( $RemoveEdgeWebView -and -not ( $InstalledNamesAll.Where({ $_ -notlike '*WebView*' }) -like '*Edge*' )) { $RemoveEdgeUpdate = $true }

    # Удаление Служб
    [array] $Services = @()

    if ( $RemoveEdge       ) { $Services += 'MicrosoftEdgeElevationService' }
    if ( $RemoveEdgeUpdate ) { $Services += 'edgeupdate','edgeupdatem'      }

    [int] $N = 0

    foreach ( $Name in $Services )
    {
        try
        {
            if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\$Name",'ImagePath',$null) )
            {
                $N++ ; if ( $N -eq 1 ) { Write-Host }

                $FoundEdge++

                Set-Svc -Do:$Act Set-Service -Name $Name -StartupType Disabled -Status Stopped -OrigCmdlet

                if ( $Act -eq 'Set' )
                {
                    try { (Get-WmiObject win32_service -Filter "name='$Name'").delete() > $null } catch {}
                }

                $Path = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name"
                Set-Reg -Do:$Act Remove-Item -Path $Path
            }
        }
        catch {}
    }

    [int] $N = 0

    if ( $RemoveEdgeUpdate )
    {
        # Удаление всех найденных задач
        Get-Task-FullPaths -LikeName *MicrosoftEdge* | ForEach-Object {
            
            $N++ ; if ( $N -eq 1 ) { Write-Host }

            Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_

            $FoundEdge++
        }
    }

    Token-Impersonate -Reset

    # Профили
    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    [array] $Accs = [PSCustomObject] @{
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source

        UserDesktopFolder = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders','Desktop',$null)
    }

    if ( $Global:DataAllUsers.Redirects.Value )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source

                UserDesktopFolder = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($_.SID)\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",'Desktop',$null)
            }
        })
    }


    if ( $Act -eq 'Set' ) { Stop-Process -Name '*Edge*','Widgets','Setup' -Force -ErrorAction SilentlyContinue }


    [array] $Paths = "${env:ProgramFiles(x86)}\Microsoft\Edge*", "$env:ProgramFiles\Microsoft\Edge*"

    foreach ( $Acc in $Accs )
    {
        if ( $Acc.Profile ) { $Paths += "$($Acc.Profile)\AppData\Local\Microsoft\Edge*" }
    }

    # Удаление папок
    [string] $Folder = ''
     [array] $FolderNames = @()

    if ( $RemoveEdge        ) { $FolderNames += 'Edge','Edge SxS','Edge Dev','Edge Beta' }
    if ( $RemoveEdgeWebView ) { $FolderNames += 'EdgeWebView'                            }
    if ( $RemoveEdgeUpdate  ) { $FolderNames += 'EdgeUpdate','EdgeCore'                  } # EdgeUpdate и EdgeCore может быть и от Edge и от WebView

    $N = 0

    @(Get-ChildItem -Directory -Path $Paths -Force -ErrorAction SilentlyContinue).Where({ $FolderNames -like $_.Name }).Foreach({

        $N++ ; if ( $N -eq 1 ) { Write-Host }

        $Folder = $_.FullName

        $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
        Write-Host "$Folder" -ForegroundColor DarkGray

        $FoundEdge++

        if ( $Act -eq 'Check' )
        {
            $NeedFix = $true
        }
        else
        {
            Remove-Item -LiteralPath $Folder -Recurse -Force -ErrorAction SilentlyContinue
        }
    })

    # Удаление папки EdgeBho, если в ней есть файлы. Её иногда создаёт винда пустую или с пустыми папками.
    if ( $RemoveEdge )
    {
        foreach ( $Acc in $Accs )
        {
            if ( $Acc.Profile )
            {
                $Folder = "$($Acc.Profile)\AppData\Local\Microsoft\EdgeBho"

                if ( @(Get-ChildItem -File -Path $Folder -Recurse -Force -ErrorAction SilentlyContinue).Count )
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Folder" -ForegroundColor DarkGray

                    $FoundEdge++

                    if ( $Act -eq 'Check' )
                    {
                        $NeedFix = $true
                    }
                    else
                    {
                        Remove-Item -LiteralPath $Folder -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
            }
        }
    }

    # Очистка реестра

    Write-Host

    foreach ( $Acc in $Accs )
    {
        if ( $Acc.Root -eq 'HKCU:' )
        {
            $RegRoot = [Microsoft.Win32.Registry]::CurrentUser
            $SubKey  = 'Software\Microsoft\Windows\CurrentVersion\Uninstall'
            $isRoot  = $Acc.Root
            $FullKey = "HKEY_CURRENT_USER\$SubKey"
        }
        else
        {
            $RegRoot = [Microsoft.Win32.Registry]::Users
            $SubKey  = "$($Acc.Root)\Software\Microsoft\Windows\CurrentVersion\Uninstall"
            $isRoot  = 'Registry::HKU'
            $FullKey = "HKEY_USERS\$SubKey"
        }

        try { $OpenSubKey = $RegRoot.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
        catch { $OpenSubKey = $null }

        if ( $OpenSubKey )
        {
            [array] $Paths = @()

            foreach ( $SubKeyName in $OpenSubKey.GetSubKeyNames() )
            {
                $DisplayName = [Microsoft.Win32.Registry]::GetValue("$FullKey\$SubKeyName",'DisplayName',$null)

                if ( $DisplayName -like '*Microsoft*Edge*' )
                {
                    if (( $DisplayName -like '*Edge*Update*' -and $RemoveEdgeUpdate ) -or ( $DisplayName -like '*Edge*WebView*' -and $RemoveEdgeWebView ) -or
                        ( $DisplayName -notmatch 'WebView|Update' -and $RemoveEdge ))
                    {
                        $FoundEdge++

                        $Paths += "$isRoot\$SubKey\$SubKeyName"
                    }
                }
            }

            $OpenSubKey.Close()

            foreach ( $Path in $Paths )
            {
                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-Item -Path $Path -OnlyThisPath
                }
            }
        }

        if ( $RemoveEdge )
        {
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $SubKey = 'Software\Classes'
            }
            else
            {
                $SubKey = "$($Acc.Root)_Classes"
            }

            $isSubkey = "$SubKey\AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9"

            try { $OpenSubKey = $RegRoot.OpenSubKey($isSubkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
            catch { $OpenSubKey = $null }

            if ( $OpenSubKey )
            {
                $OpenSubKey.Close()

                $FoundEdge++

                $Path = "$isRoot\$isSubkey"

                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-Item -Path $Path -OnlyThisPath
                }
            }

            [array] $Paths = @()

            foreach ( $Ext in ( '.html','.htm' ))
            {
                $isSubkey = "$SubKey\$Ext\OpenWithProgids"

                try { $OpenSubKey = $RegRoot.OpenSubKey($isSubkey,'ReadSubTree','QueryValues,EnumerateSubKeys') }
                catch { $OpenSubKey = $null }

                if ( $OpenSubKey )
                {
                    if ( $OpenSubKey.GetValueNames() -like 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9' )
                    {
                        $Paths += "$isRoot\$isSubkey"
                    }

                    $OpenSubKey.Close()
                }
            }

            foreach ( $Path in $Paths )
            {
                $FoundEdge++

                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                Write-Host "$Path -Name 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9'" -ForegroundColor DarkGray

                if ( $Act -eq 'Check' ) { $NeedFix = $true }
                else
                {
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'AppX4hxtad77fbk3jkkeerkrm0ze94wjf3s9' -OnlyThisPath
                }
            }
        }
    }


    [string[]] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
                          'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall'

    foreach ( $RegKey in $RegKeys )
    {
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in $OpenSubKey.GetSubKeyNames() )
            {
                $DisplayName = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\$SubKey",'DisplayName',$null)

                if ( $DisplayName -like '*Microsoft*Edge*' )
                {
                    if (( $DisplayName -like '*Edge*Update*' -and $RemoveEdgeUpdate ) -or ( $DisplayName -like '*Edge*WebView*' -and $RemoveEdgeWebView ) -or
                        ( $DisplayName -notmatch 'WebView|Update' -and $RemoveEdge ))
                    {
                        $Path = "HKLM:\$RegKey\$SubKey"

                        $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                        Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                        Write-Host "$Path" -ForegroundColor DarkGray

                        $FoundEdge++

                        if ( $Act -eq 'Check' ) { $NeedFix = $true }
                        else
                        {
                            Set-Reg Remove-Item -Path $Path
                        }
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    # Удаление данных от MSI установщика Edge. Если было удаление некорректное, запись и др. остаётся. Иначе не установить снова.
    if ( $RemoveEdge )
    {
        $RegKey = 'SOFTWARE\Classes\Installer'
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$RegKey\Products",'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $SubKey in $OpenSubKey.GetSubKeyNames() )
            {
                $DisplayName = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$RegKey\Products\$SubKey",'ProductName',$null)

                if (( $DisplayName -like '*Microsoft*Edge*' ) -and -not ( $DisplayName -match 'WebView|Update' ))
                {
                    $Path = "HKLM:\$RegKey\Products\$SubKey"

                    $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Path" -ForegroundColor DarkGray

                    $FoundEdge++

                    if ( $Act -eq 'Check' ) { $NeedFix = $true }
                    else
                    {
                        Set-Reg Remove-Item -Path $Path

                        $Path = "HKLM:\$RegKey\Features\$SubKey"
                        Set-Reg Remove-Item -Path $Path
                    }
                }
            }

            $OpenSubKey.Close()
        }
    }

    if ( $RemoveEdgeUpdate -and ( $Act -eq 'Set' ))
    {
        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\EdgeUpdate'
        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate'
    }

    if ( $RemoveEdge )
    {
        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\Edge'
        Set-Reg -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Edge'
    }

    if ( $RemoveEdge )
    {
        [string] $File  = ''
        [string[]] $Paths = @()

        foreach ( $Acc in $Accs )
        {
            $Paths = @()

            if ( $Acc.Profile )
            {
                $Paths = "$($Acc.Profile)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch",
                         "$($Acc.Profile)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar",
                         "$($Acc.Profile)\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Tombstones",
                         "$($Acc.Profile)\AppData\Roaming\Microsoft\Windows\Start Menu\Programs"
            }

            if ( $Acc.UserDesktopFolder )
            {
                $Paths += $Acc.UserDesktopFolder
            }

            $Paths += "$env:PUBLIC\Desktop"

            # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
            (Get-ChildItem -File -LiteralPath $Paths -ErrorAction SilentlyContinue).Where({ $_.Extension -eq '.lnk' }).Foreach({

                $File = $_.FullName

                if ( (Get-Content -Encoding UTF8 $File -ErrorAction SilentlyContinue) -like "*\msedge.exe*" )
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { 'Удаление' }
                    Write-Host "   $text`: "  -ForegroundColor $Color -NoNewline
                    Write-host "$File" -ForegroundColor DarkGray

                    $FoundEdge++

                    if ( $Act -eq 'Check' ) { $NeedFix = $true }
                    else
                    {
                        Remove-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue
                    }
                }
            })
        }
    }

    if ( $Act -eq 'Set' ) { Remove-Item -Path "$DismScratchDirGlobal\setup*.exe" -Force -ErrorAction SilentlyContinue }

    if ( -not $FoundEdge )
    {
        $text = if ( $L.s30 ) { $L.s30 } else { 'Не найдены файлы и параметры Microsoft Edge Chromium' }
        Write-Host "`n   $text"  -ForegroundColor DarkGreen
    }

    #endregion remove
}
