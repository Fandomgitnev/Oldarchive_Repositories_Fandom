﻿
<#
.SYNOPSIS
 Выполнение функций, указанных в файле пресетов,
 для проверки, выполнения или восстановления параметров.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Run_Configs.ps1.

 Используется функция Get-Pause для установки паузы.
 Используется функция Write-HostColor для раскраски вывода.
 Используется функция Set-LGP, тут для применения Групповых Политик, записанных в переменную.
 Используется функция Get-List-Presets

 Функции написаны под один стандарт,
 чтобы принимали одинаковые аргументы для указания проверок, выполнения или восстановления.

.EXAMPLE
    Run-Configs -Action Set

    Описание
    --------
    Выполнить все функции в пресете, с указанием аргумента для применения параметров.
    Указанные в пресете аргументы функций подхватываются.

.EXAMPLE
    Run-Configs -Action Check -Select

    Описание
    --------
    Выполнить все функции в пресете, с указанием аргумента для проверки параметров.
    Указанные в пресете аргументы функций подхватываются.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  07-03-2019
 ===============================================

#>
Function Run-Configs {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Action', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Action
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Action', Position = 1 )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ShowScripts', 'CurrentPreset' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    if ( -not $ListPresetsGlobal.Count )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны группы в файле пресетов' }
        Write-Warning "`n  $NameThisFunction`: $text`: '$FilePresets'"

        Get-Pause ; Return    # Выход из функции.
    }

    [int] $Number = 0
    [hashtable] $Configs = @{}

    # Получаем список наборов параметров из файла пресетов. И заполняем таблицу $Configs.
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Use-In-Configs-Checks\s*=\s*1\s*=.+' ))
    {
        if ( $Line -match '^\s*Use-In-Configs-Checks\s*=\s*1\s*=\s*(?<FuncName>[^#=\s]+)(?<Args>[^#=\n\r]+)?=((?<Note>[^#\n\r]+)=)?' )
        {
            $Number++
            [string] $FunctionName = $Matches.FuncName
            try { [string] $FunctionArgs = $Matches.Args.Trim() } catch { [string] $FunctionArgs = '' }
            try { [string] $FunctionNote = $Matches.Note.Trim() } catch { [string] $FunctionNote = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Нет описания' }) }
            if ( -not $FunctionNote ){ [string] $FunctionNote = '{0}' -f $(if ( $L.s3 ) { $L.s3 } else { 'Нет описания' }) }

            $Configs[$Number] = @{}

            $Configs[$Number]['FunctionName'] = $FunctionName
            $Configs[$Number]['FunctionArgs'] = $FunctionArgs
            $Configs[$Number]['FunctionNote'] = $FunctionNote

            # Если функция не существует (группы параметров).
            if ( -not ( Get-Command -CommandType Function -Name $FunctionName -ErrorAction SilentlyContinue ))
            {
                $Configs[$Number]['FuncResult'] = '#Red#{0}#' -f $(if ( $L.s4 ) { $L.s4 } else { 'Не существует' })

                Continue  # Переход к следующей итерации foreach.
            }

            # Для Поиска по имени в таблице, состоящей из имени и аргументов, необходимо, когда несколько строк с одной функцией, но разными аргументами.
            [string] $FuncNameArgs = "$FunctionName$FunctionArgs"

            # Заполняем остальные данные по функциям (наборам параметров).
            if ( $Global:VerifySettings -and $Global:VerifySettings[$FuncNameArgs] -and $Global:VerifySettings[$FuncNameArgs]['Fix'] )
            {
                $Configs[$Number]['FuncResult'] = '#Yellow#{0}#' -f $(if ( $L.s5 ) { $L.s5 } else { 'Есть проблема' })
            }
            elseif ( $Global:VerifySettings -and $Global:VerifySettings[$FuncNameArgs] -and $Global:VerifySettings[$FuncNameArgs]['Default'] )
            {
                $Configs[$Number]['FuncResult'] = '#Green#{0}#'  -f $(if ( $L.s6 ) { $L.s6 } else { 'Восстановлено' })
            }
            elseif ( $Global:VerifySettings -and $Global:VerifySettings[$FuncNameArgs] )
            {
                $Configs[$Number]['FuncResult'] = '#Green#{0}#'    -f $(if ( $L.s7 ) { $L.s7 } else { 'Проверено ' })
            }
            else
            {
                $Configs[$Number]['FuncResult'] = '#DarkCyan#{0}#' -f $(if ( $L.s8 ) { $L.s8 } else { 'Нет данных' })
            }
        }
    }

    # Если указано только вывести информацию, затем выходим из этой функции.
    if ( $CheckState )
    {
        if ( 'ShowScripts' -eq $CheckState )
        {
            [int] $NumShow = 0

            # Выводим информацию по всем функциям (наборам параметров).
            foreach ( $Number in $Configs.Keys | Sort-Object )
            {
                $NumShow++

                [string] $FuncName = $Configs[$Number]['FunctionName']
                [string] $FuncArgs = $Configs[$Number]['FunctionArgs']

                # Для Поиска по имени в таблице, состоящей из имени и аргументов, необходимо, когда несколько строк с одной функцией, но разными аргументами.
                [string] $FuncNameArgs = "$FuncName$FuncArgs"

                if ( $FuncArgs ) { $FuncArgs = " #DarkGray#| {0}: #White#$FuncArgs" -f $(if ( $L.s9 ) { $L.s9 } else { 'арг' }) }

                [string] $NameColor   = 'White'
                [string] $NoteColor   = 'DarkGray'
                [string] $NumberColor = 'DarkGray'

                try
                {
                    if ( $Global:VerifySettings[$FuncNameArgs]['Fix'] )
                    {
                        $NumberColor = $NameColor = $NoteColor = 'Yellow'
                    }
                }
                catch {}

                [string] $ResultShow = "#$NumberColor#{0}#DarkGray#. #$NameColor#{1} #DarkGray#| #$NoteColor#{2} #DarkGray#| {3}$FuncArgs#" -f
                    $Number.ToString().PadLeft(5,' '),
                    $Configs[$Number]['FunctionName'].ToString().PadRight(24,' '),
                    $Configs[$Number]['FunctionNote'].ToString().PadRight(47,' ').Substring(0,47),
                    $Configs[$Number]['FuncResult']

                Write-HostColor $ResultShow
            }

            if ( -not $NumShow )
            {
                $text = if ( $L.s1 ) { $L.s1 } else { 'Не указаны группы в файле пресетов' }
                Write-Host "         $text" -ForegroundColor Yellow
            }
        }
        elseif ( 'CurrentPreset' -eq $CheckState )
        {
            try { $CurrentPresetsFile.Replace($CurrentRoot,'') } catch {}
        }

        Return      # Выход из функции.
    }


    # Далее, если выполнение ...


    [string] $RefreshExplorer = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class RefreshExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult);
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        public static void Refresh()
        {
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);

            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);

            // Update taskbar
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");
        }

        private static readonly IntPtr hWnd = new IntPtr(65535);
        private const int Msg = 273;

        // Virtual key ID of the F5 in File Explorer
        private static readonly UIntPtr UIntPtr = new UIntPtr(41504);

        [DllImport("user32.dll", SetLastError=true)]
        public static extern int PostMessageW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);
        public static void PressF5Key()
        {
            // F5 pressing simulation to refresh the desktop
            PostMessageW(hWnd, Msg, UIntPtr, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.RefreshExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $RefreshExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    # Переменная для запускаемых функций, указать что выполняются группы настроек
    Set-Variable -Name MenuConfigsQuickSettings -Value $true -Option AllScope -Force


    # Если указана необходимость выбрать нужные группы параметров.
    if ( $Select )
    {
        # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
          [char] $Escape          = 27
           [int] $StringsExcl     = 3              # Количество последних строк для затирания.
        [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
        [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

        Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline

        # Ждем ввода пользователя.
        $text = if ( $L.s10 ) { $L.s10 } else { 'Введите номера групп через пробел и/или диапазон через дефис' }

        Write-Host "   $text"

        $text = if ( $L.s10_1 ) { $L.s10_1 } else { 'Номера' }

        [string] $Choice = Read-Host -Prompt "   $text"

        [Uint16[]] $SelectedGroups = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedGroups, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            [array] $arr = @()

            # Добавление групп указанных через дефис
            foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

            $arr | ForEach-Object {

                try
                {
                    [Uint16] $GroupNumber = $_

                    if (( $GroupNumber -gt 0 ) -and ( $GroupNumber -le $Configs.Count ) -and ( $SelectedGroups -notcontains $GroupNumber ))
                    { [Uint16[]] $SelectedGroups += $GroupNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedGroups )
        {
            $text = if ( $L.s11 ) { $L.s11 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s12 ) { $L.s12 } else { 'Выбранные группы' }
        Write-HostColor "`n     $text`: #DarkGray#[ #White#$SelectedGroups #DarkGray#]#`n"
    }

    if ( $Action -eq 'Default' )
    {
        $text = if ( $L.s13 ) { $L.s13 } else { 'Восстановление параметров по умолчанию' }
        Write-Host "`n██ $text" -ForegroundColor Magenta
    }
    elseif ( $Action -eq 'Check' )
    {
        $text = if ( $L.s14 ) { $L.s14 } else { 'Проверка параметров' }
        Write-Host "`n██ $text" -ForegroundColor Cyan
    }
    else
    {
        $text = if ( $L.s15 ) { $L.s15 } else { 'Применение параметров' }
        Write-Host "`n██ $text" -ForegroundColor Green
    }

    [int] $NumVerify = 0

    foreach ( $Number in $Configs.Keys | Sort-Object )
    {
        $NumVerify++

        if ( $Select -and ( -not ( $SelectedGroups -like $Number ) )) { Continue }

        [string] $FunctionName = $Configs[$Number]['FunctionName']
        [string] $FunctionArgs = $Configs[$Number]['FunctionArgs']
        [string] $FunctionNote = $Configs[$Number]['FunctionNote']

        # Проверяем существование функции.
        if ( -not ( Get-Command -CommandType Function -Name $FunctionName -ErrorAction SilentlyContinue ))
        {
            $text = if ( $L.s16 ) { $L.s16 } else { 'Функция для настройки Не существует' }

            Write-HostColor "`n#Red#██  $text`: #White#$FunctionName #DarkGray#| $FunctionNote#"

            Continue   # Переход к следующей итерации foreach.
        }
        else
        {
            $NeedFix = $false

            if ( $Action -eq 'Default' )
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Восстановление' }
                Write-Host "`n██ $text`: " -ForegroundColor Magenta -NoNewline
            }
            elseif ( $Action -eq 'Check' )
            {
                $text = if ( $L.s18 ) { $L.s18 } else { 'Проверка' }
                Write-Host "`n██ $text`: " -ForegroundColor Cyan -NoNewline
            }
            else
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Применение' }
                Write-Host "`n██ $text`: " -ForegroundColor Green -NoNewline
            }

            Write-Host "$FunctionName " -ForegroundColor White -NoNewline
            Write-Host "| $FunctionNote" -ForegroundColor DarkGray -NoNewline

            # Если есть аргументы.
            if ( $FunctionArgs )
            {
                $text = if ( $L.s9 ) { $L.s9 } else { 'арг' }
                Write-Host " | $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$FunctionArgs" -ForegroundColor White

                [psobject] $FuncScriptBlock = [scriptblock]::Create( "$FunctionName -Act:$Action $FunctionArgs" )

                try { & $FuncScriptBlock }
                catch
                {
                    $text = if ( $L.s20 ) { $L.s20 } else { "Проблема запуска функции!`n`tКоманда" }
                    Write-Warning "$NameThisFunction`: $text`: $FuncScriptBlock`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                }
            }
            else
            {
                Write-Host

                try { & $FunctionName -Act:$Action }
                catch
                {
                    $text = if ( $L.s20 ) { $L.s20 } else { "Проблема запуска функции!`n`tКоманда" }
                    Write-Warning "$NameThisFunction`: $text`: $FunctionName -Act:$Action`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                }
            }

            if ( $NeedFix )
            {
                $text = if ( $L.s5 ) { $L.s5 } else { 'Есть проблемы' }
                Write-HostColor "`n     #White#$FunctionName #DarkGray#| #Yellow#$text#"

                # Добавление функции в глобальную таблицу $Global:VerifySettings, что были несоответствия.
                Set-VerifySettings -FuncName $FunctionName -FuncArgs $FunctionArgs -Add Fix
            }
            else
            {
                if ( $Action -eq 'Default' )
                {
                    if ( -not $noDefault )
                    {
                        $text = if ( $L.s21 ) { $L.s21 } else { 'Параметры восстановлены (По умолчанию)' }
                        Write-HostColor "`n     #White#$FunctionName #DarkGray#| #DarkMagenta#$text#"
                    }
                    else { $noDefault = $false }

                    # Добавление функции в глобальную таблицу $Global:VerifySettings, что было восстановление и не было ошибок.
                    Set-VerifySettings -FuncName $FunctionName -FuncArgs $FunctionArgs -Default
                }
                else
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { 'Все параметры верные' }
                    Write-HostColor "`n     #White#$FunctionName #DarkGray#| #Green#$text#" -ForegroundColor Green

                    # Добавление функции в глобальную таблицу $Global:VerifySettings, что была проверка и не было ошибок.
                    Set-VerifySettings -FuncName $FunctionName -FuncArgs $FunctionArgs -Add Check
                }
            }
        }
    }

    # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
    Set-LGP -ApplyGP

    if ( -not $NumVerify )
    {
        $text = if ( $L.s23 ) { $L.s23 } else { 'Нет параметров' }
        Write-Host "`n   $text" -ForegroundColor Yellow
    }
    elseif ( $Action -ne 'Check' )
    {
        [WinAPI.RefreshExplorer]::Refresh()
        Start-Sleep -Milliseconds 500
        [WinAPI.RefreshExplorer]::PressF5Key()
    }

    Get-Pause
}
