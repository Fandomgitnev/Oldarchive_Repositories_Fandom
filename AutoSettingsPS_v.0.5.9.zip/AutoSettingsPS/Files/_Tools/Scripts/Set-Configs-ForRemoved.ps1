﻿
# Группы параметров, которые желательно должны быть применены, если компонент системы удалён.
# Если компонент системы не удалён, то параметры для него пропускаются.
Function Set-Configs-ForRemoved {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''   # Для любого текста
    [string] $Info = ''   # Для описания группы

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem

    # Этот скрипт Только для 1809
    if ( [System.Environment]::OSVersion.Version.Build -ne 17763 )
    {
        $text = if ( $L.s0 ) { $L.s0 } else { 'Пропуск настройки. Скрипт только для версии Windows 10 1809 (17763)' }
        Write-Host "`n   $text" -ForegroundColor DarkGray

        Return
    }

    # Далее сами настройки ...

    # Настройка параметров для удалённых компонентов из системы.
    # При удалении компонентов удаляются и шаблоны ГП admx, и настрйоки не будут отображены в оснастке Групповых Политик.



    $Info = 'Защитник'

    if ( -not ( [System.IO.File]::Exists("$env:ProgramFiles\Windows Defender\MsMpEng.exe") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s3 -Action $Act -Deleted

            # Комп\Адм. Шабл\Компоненты Windows\Защитник ...\ "Отключить Защитник Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1

            "Скрытие окна параметров из настроек: Параметры -> Обновление и безопасность -> Безопасность Windows" | Show-Info -Shift $L.s4

            Set-SettingsPageVisibility -Act:$Act -Names 'windowsdefender'
        }
        else
        {
            $Info | Show-Info -Shift $L.s3 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware'

            Set-SettingsPageVisibility -Names 'windowsdefender' -Remove
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'MRT'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\mrt_map.dll") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s5 -Action $Act -Deleted

            # Этих параметров нет в редакторе ГП
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontOfferThroughWUAU' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontReportInfectionInformation' -Type DWord 1
        }
        else
        {
            $Info | Show-Info -Shift $L.s5 -Action $Act -Deleted

            # Этих параметров нет в редакторе ГП
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontOfferThroughWUAU'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontReportInfectionInformation'
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'SmartScreen'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\smartscreen.exe") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s6 -Action $Act -Deleted

            # Комп\Адм. Шабл\Компоненты Windows\Проводник "Настроить Windows SmartScreen" (отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled' -Type String 'Off'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled' -Type String 'Anywhere'
        }
        else
        {
            $Info | Show-Info -Shift $L.s6 -Action $Act -Deleted

            # Комп\Адм. Шабл\Компоненты Windows\Проводник "Настроить Windows SmartScreen"
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled'
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'Кортана'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\SystemApps\Microsoft.Windows.Cortana_cw5n1h2txyewy\SearchUI.exe") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s7 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortana' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortanaAboveLock' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Experience' -Name 'AllowCortana' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\AboveLock' -Name 'AllowCortanaAboveLock' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaConsent' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 0

            'Скрытие окна параметров из настроек: Параметры -> Поиск' | Show-Info -Shift $L.s8

            Set-SettingsPageVisibility -Act:$Act -Names 'cortana','cortana-permissions','cortana-notifications',
                                                        'cortana-moredetails','cortana-language'
        }
        else
        {
            $Info | Show-Info -Shift $L.s7 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortana'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' -Name 'AllowCortanaAboveLock'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Experience' -Name 'AllowCortana'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\AboveLock' -Name 'AllowCortanaAboveLock'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'CortanaConsent'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode'

            Set-SettingsPageVisibility -Names 'cortana','cortana-permissions','cortana-notifications',
                                              'cortana-moredetails','cortana-language' -Remove
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }




    $Info = 'Content Delivery Manager | Windows spotlight on lock screen'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\SystemApps\Microsoft.Windows.ContentDeliveryManager_cw5n1h2txyewy\AppxManifest.xml") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s9 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SilentInstalledAppsEnabled' -Type DWord 0

            # Скрытие из-за 'DisableWindowsConsumerFeatures'
            'Скрытие окна параметров из настроек: Параметры -> Телефон' | Show-Info -Shift $L.s10

            Set-SettingsPageVisibility -Act:$Act -Names 'mobile-devices', 'mobile-devices-addphone'
        }
        else
        {
            $Info | Show-Info -Shift $L.s9 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' -Name 'DisableWindowsConsumerFeatures'

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'PreInstalledAppsEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager' -Name 'SilentInstalledAppsEnabled'

            Set-SettingsPageVisibility -Names 'mobile-devices', 'mobile-devices-addphone' -Remove
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'Unifed Telemetry Client'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\diagtrack.dll") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s11 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'AITEnable' -Type DWord 0

            try { [string] $WindowsEdition = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','EditionID',$null)
            } catch { [string] $WindowsEdition = $null }

            if (( $WindowsEdition -like '*Enterprise*' ) -or ( $WindowsEdition -like '*Education*' ))
            {
                # Этого параметра нет в ГП, но предлагается для использования самой MS в описании: Configure Windows telemetry in your organization от 04.05.2017
                # Включение режима сбора телеметрии на "Безопасность" ("Security"), если редакция Корпоративная или для Образовательных учреждений.
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry' -Type DWord 0
            }
            else
            {
                # Включение режима сбора телеметрии на "Базовый" ("Basic"), для остальных редакций.
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry' -Type DWord 1
            }

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\System' -Name 'AllowExperimentation' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\System\AllowTelemetry' -Name 'value' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'InsightsEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Settings' -Name 'InsightsEnabled' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TraceManager' -Name 'MiniTraceSlotEnabled' -Type DWord 0

            # Если раздел удалён, то не выполнять его настройку и проверку
            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\DiagTrack','000',$true) )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\DiagTrack' -Name 'Start' -Type DWord 4
            }

            if ( [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener','000',$true) )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener' -Name 'Start' -Type DWord 0
            }

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel' -Name 'Start' -Type DWord 0

            'Скрытие окна параметров из настроек: Параметры -> Конфиденциальность -> Отзывы и диагностика' | Show-Info -Shift $L.s12

            Set-SettingsPageVisibility -Act:$Act -Names 'privacy-feedback'
        }
        else
        {
            $Info | Show-Info -Shift $L.s11 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'AITEnable'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\System' -Name 'AllowExperimentation'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\System\AllowTelemetry' -Name 'value'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'InsightsEnabled'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Settings' -Name 'InsightsEnabled'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TraceManager' -Name 'MiniTraceSlotEnabled'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\DiagTrack' -Name 'Start'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener' -Name 'Start'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel' -Name 'Start'

            Set-SettingsPageVisibility -Names 'privacy-feedback' -Remove
        }

    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'Windows Error Reporting'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\WerFault.exe") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s13 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1
        }
        else
        {
            $Info | Show-Info -Shift $L.s13 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled'
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'Xbox'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\gamemode.dll") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s14 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' -Name 'AllowGameDVR' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\ApplicationManagement' -Name 'AllowGameDVR' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Type DWord 0

            'Скрытие окна параметров из настроек: Параметры -> Игры' | Show-Info -Shift $L.s15

            Set-SettingsPageVisibility -Act:$Act -Names 'gaming-broadcasting', 'gaming-gamebar', 'gaming-gamedvr',
                                                        'gaming-gamemode', 'gaming-trueplay', 'gaming-xboxnetworking'
        }
        else
        {
            $Info | Show-Info -Shift $L.s14 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' -Name 'AllowGameDVR' -Type DWord 0

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\ApplicationManagement' -Name 'AllowGameDVR' -Type DWord 0
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' -Name 'AppCaptureEnabled' -Type DWord 0
            Set-Reg Remove-ItemProperty -Path 'HKCU:\System\GameConfigStore' -Name 'GameDVR_Enabled' -Type DWord 0

            Set-SettingsPageVisibility -Names 'gaming-broadcasting', 'gaming-gamebar', 'gaming-gamedvr',
                                              'gaming-gamemode', 'gaming-trueplay', 'gaming-xboxnetworking' -Remove
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'People Experience Host'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\SystemApps\Microsoft.Windows.PeopleExperienceHost_cw5n1h2txyewy\PeopleExperienceHost.exe") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s16 -Action $Act -Deleted

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'HidePeopleBar' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People' -Name 'PeopleBand' -Type DWord 0
        }
        else
        {
            $Info | Show-Info -Shift $L.s16 -Action $Act -Deleted

            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' -Name 'HidePeopleBar'
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced\People' -Name 'PeopleBand'
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    $Info = 'Карты. Maps'

    if ( -not ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\MapsStore.dll") ))
    {
        if ( $Act -ne 'Default' )
        {
            $Info | Show-Info -Shift $L.s17 -Action $Act -Deleted

            'Скрытие окна параметров из настроек: Параметры -> Приложения -> Карты' | Show-Info -Shift $L.s18

            Set-SettingsPageVisibility -Act:$Act -Names 'maps'
        }
        else
        {
            $Info | Show-Info -Shift $L.s17 -Action $Act -Deleted

            Set-SettingsPageVisibility -Names 'maps' -Remove
        }
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Компонент не удалён' }
        Write-Host "`n   $Info | $text" -ForegroundColor DarkGray
    }



    # Восстановление файла библиотеки телеметрии, без него ЦО не предлагает накопительные обновления после 09.2019,
    # и есть проблема даже после их ручной установки или интеграции!
    [string] $File = "$env:WinDir\System32\utcutil.dll"
    if (( -not [System.IO.File]::Exists($File) ) -and ( [System.Environment]::OSVersion.Version.Build -eq 17763 ))
    {
        $text = if ( $L.s19 ) { $L.s19 } else { 'Восстановление файла' }
        Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline
        Write-Host "| $File" -ForegroundColor DarkGray

        [string] $Target  = '{0}\utcutil.dll' -f (Get-ChildItem -Path "$env:WinDir\WinSxS\*u..ed-telemetry-client*" -ErrorAction SilentlyContinue).Where({ $_.Name -notlike 'wow64_*' },'Last',1).FullName
        [string] $Version = (Get-ItemProperty -LiteralPath $Target -ErrorAction SilentlyContinue).VersionInfo.ProductVersion

        if ( [System.IO.File]::Exists($Target) -and $Version )
        {
            Token-Privileges -Enable -Privileges 'SeRestorePrivilege'
            New-Item -ItemType HardLink -Path $File -Target $Target -Force -ErrorAction SilentlyContinue > $null
        }
        else
        {
            $text = if ( $L.s20 ) { $L.s20 } else { 'Оригинал файла utcutil.dll в WinSxS не найден или испорчен' }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            [string] $Archive = "$CurrentRoot\Files\utcutil_dll.7z"

            if ( [System.IO.File]::Exists($Archive) )
            {
                $text = if ( $L.s21 ) { $L.s21 } else { 'Восстановление оригинала из архива' }
                Write-Host "   $text`: $Archive" -ForegroundColor DarkCyan

                # Расскрываем короткие имена в пути
                [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                if ( $is64 ) { & $7z e "$Archive" -o"$TempPath" '-i!x64\utcutil.dll' -aoa -bso0 -bse0 -bsp0 }
                else         { & $7z e "$Archive" -o"$TempPath" '-i!x86\utcutil.dll' -aoa -bso0 -bse0 -bsp0 }

                Move-Item -LiteralPath $TempPath\utcutil.dll -Destination $File -Force -ErrorAction SilentlyContinue
            }
            else
            {
                $text = if ( $L.s22 ) { $L.s22 } else { 'Архив с оригиналом файла не найден' }
                Write-Host "   $text`: $Archive" -ForegroundColor Red
            }
        }

        if ( [System.IO.File]::Exists($File) )
        {
            $text = if ( $L.s23 ) { $L.s23 } else { 'Восстановлен' }
            Write-Host "`n   $text" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s24 ) { $L.s24 } else { 'Не восстановлен' }
            Write-Host "`n   $text" -ForegroundColor Red
        }
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s2 ) { $L.s2 } else { 'Необходимо перезагрузиться!' }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor DarkGreen

        Get-Pause
    }
}

