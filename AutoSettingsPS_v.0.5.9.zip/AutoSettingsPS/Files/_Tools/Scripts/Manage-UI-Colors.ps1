﻿
<#
.SYNOPSIS
 Настройка цвета Windows: Проводника, Настроек, Панели задач и Пуска.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Используется функция ReStart-Explorer
 Используется функция RegHives-User-LoadUnload
 Используется функция Get-List-Presets

 Может настроить/восстановить для всех аккаунтов, включая дефолтный, настройка согласно переменной: $Global:DataAllUsers
 Для дефолтного аккаунта делается батник с настройками, который скрыто запускается при первом входе через RunOnce
 Если была настройка своих цветов через AccentPalette, то в батник добавляется перезагрузка проводника
 Батник формируется из всех настроенных параметров цвета: Сами цвета и их отображение в элементах оформления.
 После выполнения батник удаляется.

.EXAMPLE

    Manage-UI-Colors -Act Check
    Manage-UI-Colors -Act Set
    Manage-UI-Colors -Act Default


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  10-02-2022
 ===============================================

#>
Function Manage-UI-Colors {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    [hashtable] $PresetsColors = @{
        AccentColor          = $null
        AccentColorInactive  = $null

        clrSettingsTextLinks = $null
        clrUwpBtnBgUnderline = $null
        clrTileTextLinks     = $null
        clrStartButtonHover  = $null
        clrStartBackground   = $null
        clrTaskbarTrans      = $null
        clrTaskbar           = $null
    }

    # Получаем список и заполняем таблицу
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Expl-Colors-[\w]+\s*=\s*1\s*=' ))
    {
        # Берем заданный цвет
        if ( $Line -match '^\s*Expl-Colors-AccentColor\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.AccentColor = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-AccentColorInactive\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.AccentColorInactive = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-SettingsTextLinks\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrSettingsTextLinks = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-UwpBtnBgUnderline\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrUwpBtnBgUnderline = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-TileTextLinks\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrTileTextLinks = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-StartButtonHover\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrStartButtonHover = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-StartBackground\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrStartBackground = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-TaskbarTrans\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrTaskbarTrans = $Matches.Color.Trim()
        }
        elseif ( $Line -match '^\s*Expl-Colors-Taskbar\s*=\s*1\s*=\s*(?<Color>#[a-f0-9]{6})\s*=' )
        {
            $PresetsColors.clrTaskbar = $Matches.Color.Trim()
        }
    }

    [string] $Code = @'
using System;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace WinAPI
{
    public class DwmManager
    {
        //// 1. AccentColor
        [StructLayout(LayoutKind.Sequential)]
        public struct IMMERSIVE_COLOR_PREFERENCE
        {
            public uint crStartColor;
            public uint crAccentColor;
            public uint dwColorSetIndex;
        }

        [DllImport("uxtheme.dll")]
        private static extern void GetUserColorPreference(out IMMERSIVE_COLOR_PREFERENCE pcpPreference, bool fForceReload);

        [DllImport("uxtheme.dll", EntryPoint = "#122", CallingConvention = CallingConvention.StdCall)]
        private static extern void SetUserColorPreference(ref IMMERSIVE_COLOR_PREFERENCE cpcpPreference, bool fForceCommit);

        // BGRA to BGRA color (Win32 BGRA-format color to a .NET color)
        public static Color BgraToColor(uint bgra)
        {
            return Color.FromArgb(Int32.Parse(bgra.ToString("X"), NumberStyles.HexNumber)); // to BGRA color (HEX: #BBGGRRAA)
        }

        // BGRA to RGBA color (смена местами R и B)  Переворот цвета в нормальный вид.
        public static Color BgraToRgbaColor(uint bgra)
        {
            Color c = BgraToColor(bgra); // to BGRA color (HEX: #BBGGRRAA)

            return Color.FromArgb(c.A, c.B, c.G, c.R); // to RGBA color  (HEX: #AARRGGBB | R >< B)
        }

        public static uint ColorToRgba(Color color)
        {
            return (uint)(color.R | (color.G << 8) | (color.B << 16) | (color.A << 24));
        }

        public static Color AccentColor
        {
            get
            {
                IMMERSIVE_COLOR_PREFERENCE pcpPreference;
                GetUserColorPreference(out pcpPreference, false);

                // Переворот цвета в нормальный вид
                return BgraToRgbaColor(pcpPreference.crAccentColor);
            }
            set
            {
                IMMERSIVE_COLOR_PREFERENCE pcpPreference;
                GetUserColorPreference(out pcpPreference, false);
                pcpPreference.crAccentColor = ColorToRgba(value);

                SetUserColorPreference(ref pcpPreference, true);
            }
        }

        //// 2. AccentPalette Color
        public struct PALETTE_COLOR_PREFERENCE
        {
            public uint clrSettingsTextLinks;  // W11: Цвет текстовых ссылок в Настройках и Фона Пуска (при Светлой теме Панели задач и Пуска) | Только W11
            public uint clrUwpBtnBgUnderline;  // W11: Цвет фона кнопок, переключателей, подчеркиваний в Настройках/Пуске/Панели задач и Фон Панели задач (при Светлой теме Панели задач и Пуска) | Только W11
            public uint clrStartButtonHover;   // W10: Цвет Фона кнопки Пуск при наведении курсора | Только W10
            public uint clrTileTextLinks;      // W10: цвет текстовых cсылок и векторных иконок в настройках и кнопки "Файл" в проводнике (и активных вкладок на Панели задач при Включенной прозрачности) | W11: цвет векторных иконок в Настройках, цвет подчеркиваний, текста помощи в Пуске и Поиске

            public uint clrStartBackground;    // W10: Цвет Фона Пуска и уведомлений (и активных вкладок на Панели задач при Отключенной прозрачности) | W11: Цвет фона кнопок, переключателей, подчеркиваний в Настройках/Пуске (при Светлой теме Панели задач и Пуска)
            public uint clrTaskbar;            // W10: Цвет Фона Панели задач при Отключенной прозрачности | W11: Фон Панели задач + фон Пуска (при Темной теме Панели задач и Пуска)
            public uint clrTaskbarTrans;       // W10: Цвет Фона Панели задач при Включенной  прозрачности | Только W10
            public uint clrSpecial;            // не известно
        }

        private static byte[] binary = new byte[0];

        private static void GetPaletteBinary()
        {
            using (RegistryKey Key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent"))
            {
                if (Key != null)
                {
                    try
                    {
                        byte[] Val = (byte[]) Key.GetValue("AccentPalette");

                        if (Val != null && Val.Length >= 32)
                        {
                            binary = Val;  // ссылка на полученный массив
                        }
                        else { binary = new byte[0]; }
                    }
                    catch (Exception) {}
                    finally { Key.Close(); }
                }
            }
        }

        private static void GetUserAccentPaletteColors(out PALETTE_COLOR_PREFERENCE PalettePreference)
        {
            GetPaletteBinary();

            if (binary.Length == 0)
            {
                PalettePreference = new PALETTE_COLOR_PREFERENCE();
            }
            else
            {
                PalettePreference.clrSettingsTextLinks  = BytesToUintRGBA(binary, 0);
                PalettePreference.clrUwpBtnBgUnderline  = BytesToUintRGBA(binary, 4);
                PalettePreference.clrStartButtonHover   = BytesToUintRGBA(binary, 8);
                PalettePreference.clrTileTextLinks      = BytesToUintRGBA(binary, 12);
                PalettePreference.clrStartBackground    = BytesToUintRGBA(binary, 16);
                PalettePreference.clrTaskbar            = BytesToUintRGBA(binary, 20);
                PalettePreference.clrTaskbarTrans       = BytesToUintRGBA(binary, 24);
                PalettePreference.clrSpecial            = BytesToUintRGBA(binary, 28);
            }
        }

        public static uint BytesToUintRGBA(byte[] arr, int start)
        {
            int result = 0;
            int end = start + 4;
            for (int i = start; i < end; i++)
            {
                result |= (arr[i] << (i * 8));
            }
            return (uint)result;
        }

        public static byte[] UintToBytesRGBA(UInt32 value)
        {
            byte r = (byte)(value & 255);
            byte g = (byte)(value >> 8 & 255);
            byte b = (byte)(value >> 16 & 255);
            byte a = (byte)(value >> 24 & 255);

            return new byte[] { r, g, b, a };
        }

        // #RRGGBB/#AARRGGBB to uint (для ps1)
        public static uint HexToUintBGRA(string argb)
        {
            uint num;
            bool parse = UInt32.TryParse(argb.TrimStart('#'), NumberStyles.HexNumber, NumberFormatInfo.InvariantInfo, out num);

            if ( parse )
            {
                byte[] b = UintToBytesRGBA(num);

                return BytesToUintRGBA((new byte[] { b[2], b[1], b[0], b[3] }), 0);
            }
            else
            {
            	return (uint)14120960; // Синий по умолчанию #0078d7
            }
        }

        // #RRGGBB/#AARRGGBB to Color (для ps1)
        public static Color HexToColor(string argb)
        {
            int num;
            bool parse = Int32.TryParse(argb.TrimStart('#'), NumberStyles.HexNumber, NumberFormatInfo.InvariantInfo, out num);

            if ( parse )
            {
                return Color.FromArgb(num);
            }
            else
            {
            	return Color.FromArgb(0xff,0x00,0x78,0xd7); // Синий по умолчанию #0078d7
            }
        }

        static void PrefToBinary(PALETTE_COLOR_PREFERENCE p)
        {
            for (int i = 0; i < 31; i += 4)
            {
                byte[] b;
                switch (i)
                {
                    case 0:
                        b = UintToBytesRGBA(p.clrSettingsTextLinks);
                        break;
                    case 4:
                        b = UintToBytesRGBA(p.clrUwpBtnBgUnderline);
                        break;
                    case 8:
                        b = UintToBytesRGBA(p.clrStartButtonHover);
                        break;
                    case 12:
                        b = UintToBytesRGBA(p.clrTileTextLinks);
                        break;
                    case 16:
                        b = UintToBytesRGBA(p.clrStartBackground);
                        break;
                    case 20:
                        b = UintToBytesRGBA(p.clrTaskbar);
                        break;
                    case 24:
                        b = UintToBytesRGBA(p.clrTaskbarTrans);
                        break;
                    case 28:
                        b = UintToBytesRGBA(p.clrSpecial);
                        break;
                    default:
                        return;
                }

                binary[i+0] = b[0];
                binary[i+1] = b[1];
                binary[i+2] = b[2];
                binary[i+3] = 0;
            }
        }

        private static bool SetUserAccentPalette(PALETTE_COLOR_PREFERENCE param)
        {
            if (binary.Length < 32)
            {
                Console.WriteLine("Error: AccentPalette binary Length < 32");
                return false;
            }
            else
            {
                PrefToBinary(param);

                try
                {
                    using (RegistryKey Key = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent", true))
                    {
                        if (Key != null)
                        {
                            Key.SetValue("AccentPalette", binary, RegistryValueKind.Binary);
                            Key.Close();

                            Registry.SetValue("HKEY_CURRENT_USER\\Control Panel\\Desktop", "AutoColorization", 0, RegistryValueKind.DWord);

                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                catch (Exception) { return false; }
            }
        }

        public static PALETTE_COLOR_PREFERENCE GetAccentPalette
        {
            get
            {
                PALETTE_COLOR_PREFERENCE parameters;
                GetUserAccentPaletteColors(out parameters);

                return parameters;
            }
        }

        public static bool SetAccentPalette(PALETTE_COLOR_PREFERENCE value)
        {
            PALETTE_COLOR_PREFERENCE parameters;
            GetUserAccentPaletteColors(out parameters);
            parameters = value;

            return SetUserAccentPalette(parameters);
        }
    }
}
'@

    if ( -not ( 'WinAPI.DwmManager' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new(@('System.dll','System.Drawing.dll'))
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $Code -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Настройка Цвета Windows' }
        Write-Host "   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'Проверка только AccentColor' }
        Write-Host "| $text " -ForegroundColor DarkCyan -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        try { $AColor = [WinAPI.DwmManager]::AccentColor.Name.Substring(2,6) } catch { $AColor = '------' }

        if ( $PresetsColors.AccentColor ) { $AColorPreset = $PresetsColors.AccentColor.Trim('#') } else { $AColorPreset = '------' }

        if ( $AColorPreset -ne '------' )
        {
            if ( $AColor -eq $AColorPreset ) { $fg = 'Green' } else { $fg = 'Yellow' ; $NeedFix = $true }

            Write-Host '    Presets AccentColor: ' -ForegroundColor DarkGray -NoNewline
            Write-Host "$AColorPreset" -ForegroundColor $fg

            Write-Host '   Registry AccentColor: ' -ForegroundColor DarkGray -NoNewline
            Write-Host "$AColor" -ForegroundColor $fg
        }
        else
        {
            Write-Host "    Presets AccentColor: $AColorPreset" -ForegroundColor DarkGray
        }

        $text = if ( $L.s3 ) { $L.s3 } else { 'Выполнено' }
        Write-Host "`n   $text" -ForegroundColor Green

        Return
    }

    # Далее настройка

    if ( $Act -eq 'Default' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Настройка Цвета Windows' }
        Write-Host "   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s1_3 ) { $L.s_3 } else { 'по умолчанию' }
        Write-Host "| $text`: #0078d7 " -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        [WinAPI.DwmManager]::AccentColor = [WinAPI.DwmManager]::HexToColor('#0078d7') # синий по умолчанию
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\DWM' -Name 'AccentColorInactive'
    }
    else
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Настройка Цвета Windows' }
        Write-Host "   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s1_2 ) { $L.s1_2 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        if ( -not @($PresetsColors.Keys.Where({ $PresetsColors[$_] },'First')).Count )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Пресет не настроен' }
            Write-Host "   $text " -ForegroundColor DarkGray

            Return
        }

        Write-Host   '       AccentColor: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.AccentColor)" -ForegroundColor DarkCyan
        Write-Host   '  AccentColorInact: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.AccentColorInactive)" -ForegroundColor DarkCyan

        Write-Host "`n SettingsTextLinks: " -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrSettingsTextLinks)" -ForegroundColor DarkCyan
        Write-Host   ' UwpBtnBgUnderline: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrUwpBtnBgUnderline)" -ForegroundColor DarkCyan
        Write-Host   '     TileTextLinks: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrTileTextLinks)" -ForegroundColor DarkCyan
        Write-Host   '  StartButtonHover: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrStartButtonHover)" -ForegroundColor DarkCyan

        Write-Host "`n   StartBackground: " -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrStartBackground)" -ForegroundColor DarkCyan
        Write-Host   '           Taskbar: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrTaskbar)" -ForegroundColor DarkCyan
        Write-Host   '      TaskbarTrans: ' -ForegroundColor DarkGray -NoNewline; Write-Host "$($PresetsColors.clrTaskbarTrans)" -ForegroundColor DarkCyan

        [psobject] $value = $null

        if ( $PresetsColors.AccentColor )
        {
            [WinAPI.DwmManager]::AccentColor = [WinAPI.DwmManager]::HexToColor($PresetsColors.AccentColor)
        }

        if ( $PresetsColors.AccentColorInactive )
        {
            $value = [int32] ('0xff{0}' -f ([WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.AccentColorInactive)).ToString('x6'))

            [Microsoft.Win32.Registry]::SetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\DWM','AccentColorInactive', $value, 'Dword')
        }

        if ( @($PresetsColors.Keys.Where({ $_ -like 'clr*' -and $PresetsColors[$_] },'First')).Count )
        {
            $AccentPalette = [WinAPI.DwmManager]::GetAccentPalette

            if ( $PresetsColors.clrSettingsTextLinks ) { $AccentPalette.clrSettingsTextLinks = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrSettingsTextLinks) }
            if ( $PresetsColors.clrUwpBtnBgUnderline ) { $AccentPalette.clrUwpBtnBgUnderline = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrUwpBtnBgUnderline) }
            if ( $PresetsColors.clrTileTextLinks     ) { $AccentPalette.clrTileTextLinks     = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrTileTextLinks)     }
            if ( $PresetsColors.clrStartButtonHover  ) { $AccentPalette.clrStartButtonHover  = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrStartButtonHover)  }

            if ( $PresetsColors.clrStartBackground   ) { $AccentPalette.clrStartBackground   = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrStartBackground)   }
            if ( $PresetsColors.clrTaskbar           ) { $AccentPalette.clrTaskbar           = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrTaskbar)           }
            if ( $PresetsColors.clrTaskbarTrans      ) { $AccentPalette.clrTaskbarTrans      = [WinAPI.DwmManager]::HexToUintBGRA($PresetsColors.clrTaskbarTrans)      }

            [WinAPI.DwmManager]::SetAccentPalette($AccentPalette) > $null

            ReStart-Explorer
        }
    }

    [array] $Accs   = $null
    [array] $DefAcc = $null

    # Добавить все другие акки, указаные для настройки
    @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.SID })).ForEach({

        $Accs += [PSCustomObject] @{
            Name     = $_.Name
            FullName = $_.FullName
            Root     = "Registry::HKU\$($_.SID)"
            SID      = $_.SID
            Source   = $_.Source
        }
    })

    # Добавить дефолтный акк, только если указано его полная настройка.
    @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'DefaultAccount' -and $_.SID },'First')).ForEach({

        $DefAcc = [PSCustomObject] @{
            Name    = $_.Name
            Root    = "Registry::HKU\$($_.SID)"
            Profile = $_.Profile
        }
    })

    [System.Collections.Generic.List[psobject]] $Data = @()

    # Если указано настроить другие аккаунты и они есть. Получаем все параметры по цвету из реестра, включая настройки по отображению
    # Чтобы их повторить на других аккаунтах
    if ( $Accs.Count -or $DefAcc.Count )
    {
        $SubKey = 'Software\Microsoft\Windows\DWM'
        $OpenSubKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
        if ( $OpenSubKey )
        {
            foreach ( $name in 'AccentColor','AccentColorInactive','ColorizationColor','ColorPrevalence')
            {
                if ( $null -ne ($value = $OpenSubKey.GetValue($Name)) )
                {
                    $value = '0x{0}'-f ($value).ToString('x')
                    $Data.Add(@{ $Name = @{ SubKey = $SubKey ; Name = $Name ; Type = 'DWord' ; Value = $value }})

                    if ( $name -eq 'ColorizationColor' )
                    {
                        $Data.Add(@{ 'ColorizationAfterglow' = @{ SubKey = $SubKey ; Name = 'ColorizationAfterglow' ; Type = 'DWord' ; Value = $value }})
                    }
                }
            }

            $OpenSubKey.Close()
        }

        $SubKey = 'Software\Microsoft\Windows\CurrentVersion\Explorer\Accent'
        $OpenSubKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $name in 'AccentColorMenu','AccentPalette','StartColorMenu')
            {
                if ( $null -ne ($value = $OpenSubKey.GetValue($Name)) )
                {
                    if ( $name -eq 'AccentPalette' ) { $value = @($value).ForEach({$_.ToString('x2')}) -join '' ; $type = 'Binary' }
                    else                             { $value = '0x{0}'-f ($value).ToString('x') ; $type = 'DWord' }

                    $Data.Add(@{ $Name = @{ SubKey = $SubKey ; Name = $Name ; Type = $type ; Value = $value }})
                }
            }

            $OpenSubKey.Close()
        }

        $SubKey = 'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
        $OpenSubKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

        if ( $OpenSubKey )
        {
            foreach ( $name in 'AppsUseLightTheme','SystemUsesLightTheme','ColorPrevalence','EnableTransparency')
            {
                if ( $null -ne ($value = $OpenSubKey.GetValue($Name)) )
                {
                    $value = '0x{0}'-f ($value).ToString('x')
                    $Data.Add(@{ $Name = @{ SubKey = $SubKey ; Name = $Name ; Type = 'DWord' ; Value = $value }})
                }
            }

            $OpenSubKey.Close()
        }
    }

    foreach ( $Acc in $Accs )
    {
        $NameUser = $Acc.Name
        $Root     = $Acc.Root

        Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
        Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

        foreach ( $D in $Data.Values )
        {
            $Path  = "$Root\$($D.SubKey)"
            $Name  = $D.Name
            $Type  = $D.Type
            $Value = $D.Value

            Set-Reg New-ItemProperty -Path $Path -Name $Name -Type $Type $Value -OnlyThisPath
        }
    }

    # Далее настройка только для дефолтного профиля

    if ( $DefAcc.Count )
    {
        $NameUser = $DefAcc.Name
        $Path     = "$($DefAcc.Root)\Software\Microsoft\Windows\CurrentVersion\RunOnce"
        $Profile  = $DefAcc.Profile
        $BatFile  = 'SetColors.bat'
        $BatPath  = "$($DefAcc.Profile)\$BatFile"

        Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$NameUser`n" -ForegroundColor DarkCyan

        if ( $Act -eq 'Set' -and ( $Value = $Data.'ColorizationColor'.value ))
        {
            # такие параметры ping для микро задержек между командами, чтобы проводник считал их настроенными без использования Api. Не поможет на W11, нужен перезапуск проводника.
            [System.Collections.Generic.List[string]] $Bat = @"
::&cls&::
@echo off
chcp 65001 >nul
reg add "HKCU\Control Panel\Desktop" /v "AutoColorization" /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "AccentColor" /t REG_DWORD /d "$($Data.'AccentColor'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "ColorizationAfterglow" /t REG_DWORD /d "$($Data.'ColorizationAfterglow'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "ColorizationColor" /t REG_DWORD /d "$($Data.'ColorizationColor'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Accent" /v "AccentColorMenu" /t REG_DWORD /d "$($Data.'AccentColorMenu'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Accent" /v "AccentPalette" /t REG_BINARY /d "$($Data.'AccentPalette'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Accent" /v "StartColorMenu" /t REG_DWORD /d "$($Data.'StartColorMenu'.value)" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
"@

            if ( $Value = $Data.'AccentColorInactive'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "AccentColorInactive" /t REG_DWORD /d "$Value" /f >nul 2>&1
"@)         }

            if ( $Value = $Data.Where({$_.'ColorPrevalence'.SubKey -like '*DWM'}).'ColorPrevalence'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\DWM" /v "ColorPrevalence" /t REG_DWORD /d "$Value" /f >nul 2>&1
"@)         }

            if ( $Value = $Data.'AppsUseLightTheme'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "AppsUseLightTheme" /t REG_DWORD /d "$Value" /f >nul 2>&1
"@)         }

            if ( $Value = $Data.'SystemUsesLightTheme'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "SystemUsesLightTheme" /t REG_DWORD /d "$Value" /f >nul 2>&1
"@)         }

            if ( $Value = $Data.Where({$_.'ColorPrevalence'.SubKey -like '*Personalize'}).'ColorPrevalence'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "ColorPrevalence" /t REG_DWORD /d "$Value" /f >nul 2>&1
"@)         }

            if ( $Value = $Data.'EnableTransparency'.value ) { $Bat.Add(@"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v "EnableTransparency" /t REG_DWORD /d "$Value" /f >nul 2>&1
ping 0.0.0.0 -n 1 >nul & ping 0.0.0.0 -n 1 >nul
"@)         }

            if (( @($PresetsColors.Keys.Where({ $_ -like 'clr*' -and $PresetsColors[$_] },'First')).Count ) -or ( [System.Environment]::OSVersion.Version.Build -ge 22000 ))
            {
                [int] $Sec = 3
                if ( [System.Environment]::OSVersion.Version.Build -ge 22000 ) { $Sec = 7 }

                $Bat.Add(':: Restarting the explorer, because there was a color setting in AccentPalette or W11:
taskkill /f /IM sihost.exe >nul&ping 0.0.0.0 -n {0} >nul' -f ($Sec + 1))
                
                $text = if ( $L.s3_1 ) { $L.s3_1 } else { 'Цвет настроен, Проводник перезапущен' }
            }
            else
            {
                $text = if ( $L.s3_2 ) { $L.s3_2 } else { 'Цвет настроен' }
            }

            $Bat.Add(@"
mshta.exe vbscript:createobject("wscript.shell").Popup("$text",15,"AutoSettingsPS",64)(close)
:: Deleting this bat:
del /f /q "%0"
"@)
            try
            {
                Write-Host "   Bat file: $BatPath" -ForegroundColor DarkGray
                Out-File -LiteralPath $BatPath -InputObject $Bat -Encoding utf8 -Force -ErrorAction Stop

                $Value = @"
mshta.exe vbscript:execute("f=""%UserProfile%\$BatFile"":if not CreateObject(""Scripting.FileSystemObject"").FileExists(f) then close:else CreateObject(""wscript.shell"").run(chr(34)&f&chr(34)),0,false:close")
"@
                # Подгрузить куст дефолтного профиля, если еще не подгружен
                # бэкап проверяется и создается при необходимости
                RegHives-User-LoadUnload -DefaultProfile -Load

                Set-Reg New-ItemProperty -Path $Path -Name 'SetColors' -Type ExpandString $Value -OnlyThisPath
            }
            catch
            {
                Write-Host "   Error save bat file: $BatPath" -ForegroundColor DarkYellow
            }
        }
        elseif ( $Act -eq 'Set' )
        {
            Write-Host '   Not ColorizationColor' -ForegroundColor DarkGray
        }
        else
        {
            Write-Host "   Remove: $BatPath" -ForegroundColor DarkGray
            Remove-Item -LiteralPath $BatPath -Force -ErrorAction SilentlyContinue

            # Подгрузить куст дефолтного профиля, если еще не подгружен
            # бэкап проверяется и создается при необходимости
            RegHives-User-LoadUnload -DefaultProfile -Load

            Set-Reg Remove-ItemProperty -Path $Path -Name 'SetColors' -OnlyThisPath
        }
    }

    $text = if ( $L.s3 ) { $L.s3 } else { 'Выполнено' }
    Write-Host "`n   $text" -ForegroundColor Green
}
