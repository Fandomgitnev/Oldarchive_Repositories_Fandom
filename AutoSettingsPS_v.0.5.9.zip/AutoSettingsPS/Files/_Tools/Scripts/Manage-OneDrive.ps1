﻿
<#
.SYNOPSIS
 Установка или Полное удаление OneDrive на Windows 10 x64/x86 от v.17763 (1809)

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется функция Set-Reg для установки/удаления параметров реестра, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки/удаления задач, с проверкой и выводом результата.
 Используется функция Get-Task-FullPaths для получения полных путей ко всем задачам, по совпадениям с указанным именем
 Используется функция ReStart-Explorer для корректного перезапуска проводника
 Используется функция Token-Impersonate, тут для получения/отмены на лету прав Системы
 Используется функция Token-Privileges, для включения привилегии создания символических ссылок, на всякий случай.

 После Удаления выполняется очистка от остатков OneDrive в реестре и файлов, для каждого профиля по очереди,
 настроенных в пресете в переменой $Global:DataAllUsers.
 И восстановление жёсткой ссылки на системный ярлык в папке Default User, который удаляет установщик OneDrive при удалении,
 что приводит к нарушению целостности Windows, поэтому её лучше восстановить.
 Очистка и проверка очистки происходит независимо от удаления OneDrive.

 При Установке восстанавливаются параметры для синхронизации и интеграции в Проводник OneDrive
 Установка только для текущего пользователя, для всех пользователей не подходит!
 Так же восстанавливается жёсткая ссылка на системный ярлык, если отсутствует.

 Удаление в других аккаунтах происходит по алгоритму напрямую в реестре и их папках. Полноценное удаление.

 .EXAMPLE
     Manage-OneDrive -Install -Act Check
     Manage-OneDrive -Install -Act Set
     Manage-OneDrive -Remove  -Act Check
     Manage-OneDrive -Remove  -Act Set

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  22-07-2021
 ===============================================

#>
Function Manage-OneDrive {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Install' )]
        [switch] $Install
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Install' )]
        [switch] $AllUsers
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Remove'  )]
        [switch] $Remove
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' ) { $Act = 'Set' }

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem

    # глобальное отключение перенаправления настройки реестра, чтобы выполнить действия с каждым пользователем индивидуально, если выбраны и другие пользователи.
    [bool] $Redirects = $false
    @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $Redirects = $_.Redirects.Value ; $_.Redirects.Value = $false })

    # Проверка установки OneDrive у текущего Пользователя
    [string[]] $RegKeys = 'HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\OneDriveSetup.exe',
                          'HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\OneDriveSetup.exe',
                          'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\OneDriveSetup.exe'

      [string] $InstallPath = ''
      [string] $UserFolder  = ''
    [string[]] $UninstallString = $null

    foreach ( $RegKey in $RegKeys )
    {
        $UninstallString = [Microsoft.Win32.Registry]::GetValue($RegKey,'UninstallString',$null)

        if ( $UninstallString )
        {
            [string] $UnInstallPath = ( $UninstallString -Replace ('\\[^\\]+$','') )

            if ( [System.IO.File]::Exists("$UnInstallPath\OneDriveSetup.exe") ) { $InstallPath = ( $UnInstallPath -Replace ('\\[^\\]+$','') ) }

            $UninstallString = $UninstallString.Replace('/',',/').Split(',').Trim()

            $UserFolder = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Environment','OneDrive',$null) # Нельзя удалять если есть что-то внутри!

            break
        }
    }

    Function Fix-Bag {

        [array] $CLSIDs = @()

        try { $OpenRegKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Classes\CLSID', 'ReadSubTree','QueryValues,EnumerateSubKeys') }
        catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $CLSID in $OpenRegKey.GetSubKeyNames() )
            {
                if ( $CLSID -eq '{018D5C66-4533-4307-9B53-224DE2ED1FE6}' ) { Continue }

                try { $Openkey = $OpenRegKey.OpenSubKey($CLSID,'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                if ( $Openkey )
                {
                    if ( $Openkey.GetValue('',$null) -like '*OneDrive*' )
                    {
                        $CLSIDs += $CLSID
                    }

                    $Openkey.Close()
                }
            }

            $OpenRegKey.Close()
        }

        if ( $CLSIDs.Count ) { Write-Host '   Fix Bag:' -ForegroundColor DarkGray }

        foreach ( $CLSID in $CLSIDs )
        {
            $Path = "HKCU:\Software\Classes\CLSID\$CLSID"
            Set-Reg -Do:$Act Remove-Item -Path $Path

            $Path = "HKCU:\Software\Classes\WOW6432Node\CLSID\$CLSID"
            Set-Reg -Do:$Act Remove-Item -Path $Path

            $Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\$CLSID"
            Set-Reg -Do:$Act Remove-Item -Path $Path

            $Name = $CLSID
            Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name $Name
        }

        if ( $CLSIDs.Count ) { Write-Host ; Return 1 } else { Return 0 }
    }

    if ( $Install )
    {
        if ( $Act -eq 'Check' )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Проверка Установки OneDrive' }
            Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Установка OneDrive' }
            Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline
        }

        $text = if ( $L.s3 ) { $L.s3 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        Fix-Bag > $null

        if ( $UninstallString.Count -and $InstallPath )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { 'OneDrive уже Установлен' }
            Write-Host "   $text`n" -ForegroundColor Green
        }
        else
        {
            #  old info: https://go.microsoft.com/fwlink/?linkid=2159604 | 'https://go.microsoft.com/fwlink/?linkid=2181064' # old x64

            # Pre last info: https://support.microsoft.com/en-us/office/onedrive-release-notes-845dcf18-f921-435e-bf28-4e24b95e5fc0
            #   x64-x86: https://hansbrender.com/all-onedrive-versions/#tabwin
            #   x64-x86: https://stealthpuppy.com/apptracker/#microsoftonedrive  https://github.com/aaronparker/evergreen/blob/main/Evergreen/Manifests/MicrosoftOneDrive.json
            #  last xml data x64/x86/Arm64: https://g.live.com/1rewlive5skydrive/OneDriveProductionV2 (oneclient.sfx.ms)

            if ( $is64 )
            {
                $DistrPath = "$env:SystemDrive\Windows\System32\OneDriveSetup_x64.exe"

                $URL  = 'https://go.microsoft.com/fwlink/?linkid=844652'  # x64 release
                $Arch = 'x64'
            }
            else
            {
                $DistrPath = "$env:SystemDrive\Windows\System32\OneDriveSetup_x86.exe"

                $URL  = 'https://go.microsoft.com/fwlink/p/?LinkID=2182910' # old x86  https://www.microsoft.com/en-us/microsoft-365/onedrive/download
                $Arch = 'x86'
            }

            [string] $OneDriveSetup = ''

            if ( [System.IO.File]::Exists($DistrPath) )
            {
                $OneDriveSetup = $DistrPath
            }

            if ( -not $OneDriveSetup -and $Act -eq 'Set' )
            {
                $text = if ( $L.s5_1 ) { $L.s5_1 } else { 'Установщик OneDrive не найден, выполнение загрузки с сайта MS' }
                Write-Host "   $text | $Arch `n" -ForegroundColor DarkGray

                Write-Host "   File EXE: $DistrPath" -ForegroundColor DarkGray
                Write-Host "   Base URL: $URL" -ForegroundColor DarkGray

                if ( -not ( Test-Internet -Bool -Access ))
                {
                    $text = if ( $L.s6_1 ) { $L.s6_1 } else { 'Нет доступа в Интернет для PS' }
                    Write-Host "   $text" -ForegroundColor DarkYellow

                    $NeedFix = $true
                }
                else
                {
                    try
                    {
                        [XML] $xml = Download-File 'https://g.live.com/1rewlive5skydrive/OneDriveProductionV2' -GetString

                        $throttle = 0 ; $throttle = [int[]]$xml.root.update.throttle -ge 50 | Sort-Object | Select-Object -First 1

                        if ( $throttle )
                        {
                            $OD = @($xml.root.update).Where({ $_.throttle -eq $throttle },'First')
                            $ODVers = $OD.currentversion

                            if ( $Arch -eq 'x64' ) { $ODUrl = $OD.amd64binary.url }
                            else                   { $ODUrl = $OD.binary.url      }

                            if ( $ODVers -and $ODUrl )
                            {
                                $URL = $ODUrl

                                Write-Host "`n   Data URL: https://g.live.com/1rewlive5skydrive/OneDriveProductionV2" -ForegroundColor DarkGray
                                Write-Host "   Last URL: $URL" -ForegroundColor DarkGray
                                Write-Host "   Last Ver: " -ForegroundColor DarkGray -NoNewline
                                Write-Host "$ODVers " -ForegroundColor Green -NoNewline
                                Write-Host '| ' -ForegroundColor DarkGray -NoNewline
                                Write-Host "$Arch " -ForegroundColor White
                            }
                        }
                    }
                    catch {}

                    $ResultDownload = Download-File $URL $DistrPath

                    Start-Sleep -Milliseconds 200

                    if ( [System.IO.File]::Exists($DistrPath) )
                    {
                        $OneDriveSetup = $DistrPath
                    }
                    else
                    {
                        $NeedFix = $true
                    }
                }
            }

            if ( -not $OneDriveSetup )
            {
                $text = if ( $L.s5 ) { $L.s5 } else { 'Установщик OneDrive не найден и не загружен' }
                Write-Host "   $text | $Arch `n" -ForegroundColor Yellow

                if ( $Act -eq 'Check' )
                {
                    Write-Host '   URL: ' -ForegroundColor DarkGray -NoNewline
                    Write-Host "$URL" -ForegroundColor Gray

                    Write-Host '   EXE: ' -ForegroundColor DarkGray -NoNewline
                    Write-Host "$DistrPath" -ForegroundColor Gray
                }

                $NeedFix = $true
            }
            elseif ( $Act -eq 'Check' )
            {
                $text = if ( $L.s6 ) { $L.s6 } else { 'OneDrive не Установлен' }
                Write-Host "   $text`n" -ForegroundColor Yellow

                $NeedFix = $true
            }
            else
            {
                if ( $AllUsers )
                {
                    $text = if ( $L.s7_2 ) { $L.s7_2 } else { 'Установка OneDrive для всех Пользователей' }
                    Write-Host "   $text | $Arch " -ForegroundColor Magenta -NoNewline
                }
                else
                {
                    $text = if ( $L.s7 ) { $L.s7 } else { 'Установка OneDrive для текущего Пользователя' }
                    Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                    Write-Host "$env:USERNAME | $Arch " -ForegroundColor White -NoNewline
                }

                $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Подождите' }
                Write-Host "| $text ..." -ForegroundColor DarkGray

                try
                {
                    # Удаление запретов запуска этих Exe файлов, если они есть
                    [string[]] $Paths = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\OneDriveSetup.exe',
                                        'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\OneDrive.exe',
                                        'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\OneDriveStandaloneUpdater.exe'

                    foreach ( $Path in $Paths )
                    {
                        if ( [Microsoft.Win32.Registry]::GetValue($Path.Replace('HKLM:','HKEY_LOCAL_MACHINE'),'Debugger',$null) )
                        {
                            Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                        }
                    }

                    #Start-Process -FilePath $OneDriveSetup -Wait -ErrorAction SilentlyContinue  # wait не завершается, из-за запуска нескольких процессов OneDrive с одним именем, баг Start-Process

                    $Global:LastExitCode = 0

                    if ( $AllUsers )
                    {
                        $InstallArg  = '/silent /allusers'
                        $InstallDir  = "$env:ProgramFiles\Microsoft OneDrive"
                    }
                    else
                    {
                        $InstallArg  = '/silent'
                        $InstallDir  = "$env:USERPROFILE\AppData\Local\Microsoft\OneDrive"
                    }

                    $UpdateEXE   = "$InstallDir\OneDriveStandaloneUpdater.exe"
                    $OneDriveEXE = "$InstallDir\OneDrive.exe"

                    Write-Host "   InstallDir: $InstallDir`n" -ForegroundColor DarkGray

                    # Тихая Установка
                    try { [System.Diagnostics.Process]::Start($OneDriveSetup, $InstallArg).WaitForExit() }
                    catch { Write-Host "   Setup Error: $OneDriveSetup" -ForegroundColor Red }
                }
                catch {}

                if ( -not $Global:LastExitCode )
                {
                    if ( [System.IO.File]::Exists($UpdateEXE) )
                    {
                        if ( $AllUsers ) { $Path = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce' }
                        else             { $Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce' }

                        $Value = """$UpdateEXE"""

                        Set-Reg New-ItemProperty -Path $Path -Name 'OneDriveUpdate' -Type String $Value -OnlyThisPath
                    }

                    # Восстановление автозагрузки и интеграции в Проводник, так как установщик это не делает.
                    $Value = """$OneDriveEXE"" /background"
                    Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' -Name 'OneDrive' -Type String $Value
                    Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'OneDrive'

                    Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel' -Name '{018D5C66-4533-4307-9B53-224DE2ED1FE6}' -Type DWord 1
                    Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{018D5C66-4533-4307-9B53-224DE2ED1FE6}' -Name '' -Type String 'OneDrive'

                      [string] $Path     = ''
                    [string[]] $RegPaths = 'HKCU:\Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}',
                                           'HKCU:\Software\Classes\WOW6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}'

                    foreach ( $RegPath in $RegPaths )
                    {
                        if ( $RegPath -like '*\WOW6432Node\*' -and -not [System.Environment]::Is64BitOperatingSystem ) { break }

                        $Path = $RegPath
                        Set-Reg New-ItemProperty -Path $Path -Name '' -Type String 'OneDrive'
                        Set-Reg New-ItemProperty -Path $Path -Name 'SortOrderIndex' -Type DWord 66
                        Set-Reg New-ItemProperty -Path $Path -Name 'System.IsPinnedToNameSpaceTree' -Type DWord 1

                        $Path  = "$RegPath\DefaultIcon"
                        $Value = "$OneDriveEXE,0"
                        # Для этого параметра не нужны кавычки при пробелах
                        Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                        $Path = "$RegPath\InProcServer32"
                        Set-Reg New-ItemProperty -Path $Path -Name '' -Type ExpandString '%systemroot%\system32\shell32.dll'

                        $Path = "$RegPath\Instance"
                        Set-Reg New-ItemProperty -Path $Path -Name 'CLSID' -Type String '{0E5AAE11-A475-4c5b-AB00-C66DE400274E}'

                        $Path = "$RegPath\Instance\InitPropertyBag"
                        Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 17
                        Set-Reg New-ItemProperty -Path $Path -Name 'TargetKnownFolder' -Type String '{a52bba46-e9e1-435f-b3d9-28daa648c0f6}'

                        $Path = "$RegPath\ShellFolder"
                        Set-Reg New-ItemProperty -Path $Path -Name 'Attributes' -Type DWord 4034920525
                        Set-Reg New-ItemProperty -Path $Path -Name 'FolderValueFlags' -Type DWord 40
                    }

                    # Восстановление параметров для ручного выполнения синхронизации с OneDrive, некоторые установщики не восстанавливают эти параметры

                    $Path = 'HKCU:\Software\Classes\grvopen'
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String 'URL: OneDrive Client Protocol'
                    Set-Reg New-ItemProperty -Path $Path -Name 'URL Protocol' -Type String ''
                    Set-Reg New-ItemProperty -Path $Path -Name 'UseOriginalUrlEncoding' -Type DWord 1

                    $Path  = 'HKCU:\Software\Classes\grvopen\DefaultIcon'
                    $Value = $OneDriveEXE
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                    $Path  = 'HKCU:\Software\Classes\grvopen\shell\open\command'
                    $Value = """$OneDriveEXE"" /url:""%1"""
                    Set-Reg New-ItemProperty -Path $Path -Name '' -Type String $Value

                    # Создание ярлыков в классический пуск/Программы и на рабочий стол
                    try
                    {
                        [string] $UserKey = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'
                        [string] $DesktopPath = [Microsoft.Win32.Registry]::GetValue("$UserKey\Shell Folders",'Desktop','')

                        $WScriptShell = New-Object -ComObject WScript.Shell

                        [string[]] $Paths = $DesktopPath, "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs"

                        foreach ( $Path in $Paths )
                        {
                            if ( [System.IO.Directory]::Exists($Path) -and ( -not [System.IO.File]::Exists("$Path\OneDrive.lnk") ))
                            {
                                $Shortcut = $WScriptShell.CreateShortcut("$Path\OneDrive.lnk")
                                $Shortcut.TargetPath   = $OneDriveEXE
                                $shortcut.IconLocation = "$OneDriveEXE,0"
                                $Shortcut.Description  = 'OneDrive'
                                $Shortcut.Save()
                            }
                        }
                    }
                    catch {}

                    [string] $Lnk = "$env:SystemDrive\Users\Default\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"

                    if ( -not [System.IO.File]::Exists($Lnk) )
                    {
                        $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\wow64_microsoft-windows-onedrive-setup*","$env:SystemDrive\Windows\WinSxS\amd64_microsoft-windows-onedrive-setup*" -ErrorAction SilentlyContinue
                        ).Foreach({ Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -like '*.lnk'},'Last')

                        if ( $Target.FullName )
                        {
                            $text = if ( $L.s8 ) { $L.s8 } else { 'Восстановление системного ярлыка' }
                            Write-Host "   $text`: " -ForegroundColor DarkCyan
                            Write-Host "   $Lnk" -ForegroundColor DarkGray

                            Token-Privileges -Enable -Privileges 'SeRestorePrivilege'
                            New-Item -ItemType HardLink -Path $Lnk -Target $Target.FullName -Force -ErrorAction SilentlyContinue > $null
                        }
                    }

                    $text = if ( $L.s9 ) { $L.s9 } else { 'Завершены все действия' }
                    Write-Host "`n   $text`n" -ForegroundColor Green
                }
                else
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { 'Ошибка при установке OneDrive' }
                    Write-Host "`n   $text`:" -ForegroundColor Yellow -NoNewline
                    Write-Host "LastExitCode: $Global:LastExitCode" -ForegroundColor White
                    Write-Host "   Setup Command: ""$OneDriveSetup"" $InstallArg`n" -ForegroundColor DarkGray
                }
            }
        }

        # Возврат глобального перенаправления настройки реестра, которое было до запуска функции
        if ( $Redirects ) { @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.Value = $true }) }

        Return
    }

    #region Remove

    Token-Impersonate -Reset

    # Профили
    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    [array] $Accs = [PSCustomObject] @{
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source

        UserOneDriveFolder           = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Environment','OneDrive',$null)           # Нельзя удалять если есть что-то внутри!
        UserOneDriveConsumerFolder   = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Environment','OneDriveConsumer',$null)   # Нельзя удалять если есть что-то внутри!
        UserOneDriveCommercialFolder = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Environment','OneDriveCommercial',$null) # Нельзя удалять если есть что-то внутри!

        UserDesktopFolder  = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders','Desktop',$null)
        UserInstallPath    = $InstallPath
    }

    # Если глобально разрешено перенаправлять
    if ( $Redirects )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({

            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source

                UserOneDriveFolder           = ''
                UserOneDriveConsumerFolder   = ''
                UserOneDriveCommercialFolder = ''

                UserDesktopFolder  = ''
                UserInstallPath    = ''
            }
        })
    }

    if ( $Act -eq 'Set' )
    {
        $text = if ( $L.s11 ) { $L.s11 } else { 'Удаление OneDrive' }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline
    }
    else
    {
        $text = if ( $L.s11_1 ) { $L.s11_1 } else { 'Проверка Удаления OneDrive' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
    }

    $text = if ( $L.s11_2 ) { $L.s11_2 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray


    if ( -not $UninstallString.Count )
    {
        $text = if ( $L.s12 ) { $L.s12 } else { 'OneDrive уже Удалён' }
        Write-Host "   $text`n" -ForegroundColor Green
    }
    elseif ( $Act -eq 'Check' )
    {
        $text = if ( $L.s12_1 ) { $L.s12_1 } else { 'OneDrive не Удалён' }
        Write-Host "   $text`n" -ForegroundColor Yellow

        $NeedFix = $true
    }
    else
    {
	    Stop-Process -Name 'OneDrive*','FileCoAuth','UserOOBEBroker' -Force -ErrorAction SilentlyContinue

        # Закрытие всех окон проводника в расположениях OneDrive, чтобы они не открылись после перезапуска проводника и не мешали удалению
        ReStart-Explorer -OnlyCloseWindows

        $text = if ( $L.s13 ) { $L.s13 } else { 'Папка пользователя' }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$UserFolder" -ForegroundColor Gray

        $text = if ( $L.s14 ) { $L.s14 } else { 'Установлен в папку' }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$InstallPath" -ForegroundColor Gray

        $text = if ( $L.s15 ) { $L.s15 } else { '  Команда удаления' }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$( $UninstallString -join ' ' )" -ForegroundColor Gray

        $text = if ( $L.s16 ) { $L.s16 } else { 'Выполняется удаление OneDrive ...' }
        Write-Host "`n   $text" -ForegroundColor DarkCyan

        try
        {
            # Удаление запретов запуска этих Exe файлов, если они есть
            [string[]] $Paths = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\OneDriveSetup.exe',
                                'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\OneDrive.exe'

            foreach ( $Path in $Paths )
            {
                if ( [Microsoft.Win32.Registry]::GetValue($Path.Replace('HKLM:','HKEY_LOCAL_MACHINE'),'Debugger',$null) )
                {
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                }
            }

            # Удаление
            $StartInfo = [System.Diagnostics.ProcessStartInfo]::new("$($UninstallString[0])")
            $StartInfo.WindowStyle = 'Hidden'
            $StartInfo.UseShellExecute = $false
            $StartInfo.Arguments = "$($UninstallString[1..10] -join ' ')"

            try { $P = [System.Diagnostics.Process]::Start($StartInfo) ; $P.WaitForExit() ; $P.Close() }
            catch { Write-Host "   Uninstall Error: '$($StartInfo.FileName)' $($StartInfo.Arguments)" -ForegroundColor Red }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
            {
                [string] $Value = $Matches.Debugger.Trim()
            }
            else { [string] $Value = 'dllhost.exe' }

            # Возврат запретов запуска
            foreach ( $Path in $Paths )
            {
                if ( [Microsoft.Win32.Registry]::GetValue($Path.Replace('HKLM:','HKEY_LOCAL_MACHINE'),'Debugger',$null) )
                {
                    Set-Reg New-ItemProperty -Path $Path -Name 'Debugger' -Type String $Value
                }
            }
        }
        catch {}

        $text = if ( $L.s17 ) { $L.s17 } else { 'Завершено удаление OneDrive' }
        Write-Host "   $text`n" -ForegroundColor DarkGray
    }

    #endregion Remove

    if ( $Act -eq 'Set' )
    {
        $text = if ( $L.s18 ) { $L.s18 } else { 'Очистка Windows от OneDrive' }

	    Stop-Process -Name 'OneDrive*','FileCoAuth','UserOOBEBroker' -Force -ErrorAction SilentlyContinue
    }
    else
    {
        $text = if ( $L.s19 ) { $L.s19 } else { 'Проверка Очистки Windows от OneDrive' }
    }

    Write-Host "   $text`:" -ForegroundColor DarkCyan

    #region Clean Registry

    [psobject] $OpenRegKey = $null
    [psobject] $Openkey    = $null

    [int] $AllRegKeys = 0
    [int] $N = 0

    # HKLM
    [array] $RegKeys = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers',
                       'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Explorer\ShellIconOverlayIdentifiers'

    [array] $RegPaths = @()

    foreach ( $RegKey in $RegKeys )
    {
        if ( $RegKey -like '*\WOW6432Node\*' -and -not [System.Environment]::Is64BitOperatingSystem ) { continue }

        try { $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') }
        catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $IdentPath in $OpenRegKey.GetSubKeyNames() )
            {
                if ( $IdentPath -like '*OneDrive*' )
                {
                    $RegPaths += "HKLM:\$RegKey\$IdentPath"
                }
            }

            $OpenRegKey.Close()
        }
    }

    foreach ( $Path in $RegPaths )
    {
        Set-Reg -Do:$Act Remove-Item -Path $Path
    }

    if ( $RegPaths.Count ) { Write-Host }

    foreach ( $Acc in $Accs )
    {
        $AllRegKeys = 0

        $SID = $Acc.SID

        if ( $Acc.Root -eq 'HKCU:' )
        {
            $RegRoot = [Microsoft.Win32.Registry]::CurrentUser
            $isRoot  = $Acc.Root
        }
        else
        {
            $RegRoot = [Microsoft.Win32.Registry]::Users
            $SubRoot = $Acc.Root
            $isRoot  = 'Registry::HKU'

            try { $Acc.UserOneDriveFolder           = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$SID\Environment",'OneDrive',          $null) } catch {}
            try { $Acc.UserOneDriveConsumerFolder   = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$SID\Environment",'OneDriveConsumer',  $null) } catch {}
            try { $Acc.UserOneDriveCommercialFolder = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$SID\Environment",'OneDriveCommercial',$null) } catch {}

            try { $Acc.UserDesktopFolder  = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$SID\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",'Desktop',$null) } catch {}

            [string[]] $UninstallString = @()

            try
            {
                [string] $RegKey = "HKEY_USERS\$SID\Software\Microsoft\Windows\CurrentVersion\Uninstall\OneDriveSetup.exe"
                $UninstallString = [Microsoft.Win32.Registry]::GetValue($RegKey,'UninstallString',$null)

                if ( $UninstallString )
                {
                    [string] $UnInstallPath = ( $UninstallString -Replace ("\\[^\\]+$",'') )

                    if ( [System.IO.File]::Exists("$UnInstallPath\OneDriveSetup.exe") )
                    {
                        $Acc.UserInstallPath = $UnInstallPath -Replace ("\\[^\\]+$",'')
                    }
                }
            }
            catch {}
        }

        $text = if ( $L.s20 ) { $L.s20 } else { 'Профиль' }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$($Acc.Name) " -ForegroundColor White -NoNewline
        Write-Host "| $($Acc.Profile) | $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

        # Удаление всех найденных задач OneDrive
        Get-Task-FullPaths -LikeName *OneDrive*$SID* | ForEach-Object {

            $AllRegKeys++

            Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName $_
        }

        #region 0

        [string] $RegKey = 'Software\Microsoft\OneDrive'
        [string] $Path   = ''

        try { $OpenRegKey = $RegRoot.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            if ( $OpenRegKey.GetValueNames() )
            {
                $Path = "$isRoot\$RegKey"
            }

            $OpenRegKey.Close()
        }

        if ( $Path )
        {
            $AllRegKeys++

            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        #endregion 0
        #region 1

        [array] $RegKeys = 'Software\Microsoft\SkyDrive',
        'Software\Classes\grvopen',
        'Software\Classes\odopen',
        'Software\Classes\msnucleus',
        'Software\SyncEngines\Providers\OneDrive',
        'Software\Classes\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}',
        'Software\Classes\WOW6432Node\CLSID\{018D5C66-4533-4307-9B53-224DE2ED1FE6}',
        'Software\Microsoft\Windows\CurrentVersion\Explorer\Desktop\NameSpace\{018D5C66-4533-4307-9B53-224DE2ED1FE6}',
        'Software\Microsoft\Windows\CurrentVersion\Explorer\AutoplayHandlers\Handlers\OneDriveAutoPlay',
        'Software\Microsoft\Windows\CurrentVersion\App Paths\OneDriveFileLauncher.exe',
        'Software\Microsoft\Windows\CurrentVersion\Uninstall\OneDriveSetup.exe'

        [array] $RegPaths = @()

        foreach ( $RegKey in $RegKeys )
        {
            if ( $isRoot -ne 'HKCU:' )
            {
                if ( $RegKey -like 'Software\Classes\*' ) { $isRegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
                else { $isRegKey = "$SubRoot\$RegKey" }
            }
            else { $isRegKey = $RegKey }

            try { $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues') } catch { $OpenRegKey = $null }

            if ( $OpenRegKey )
            {
                $OpenRegKey.Close()

                $RegPaths += "$isRoot\$isRegKey"
            }
        }

        foreach ( $Path in $RegPaths )
        {
            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $RegPaths.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 1
        #region 2

        [string] $RegKey = 'Software\Classes\TypeLib'

        if ( $isRoot -ne 'HKCU:' )
        {
            if ( $RegKey -like 'Software\Classes\*' ) { $RegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
            else { $RegKey = "$SubRoot\$RegKey" }
        }

        try { $OpenRegKey = $RegRoot.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

        [array] $TypeLibs = @()

        if ( $OpenRegKey )
        {
            foreach ( $Lib in $OpenRegKey.GetSubKeyNames() )
            {
                try { $Openkey = $OpenRegKey.OpenSubKey("$Lib\1.0\HELPDIR",'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                if ( $Openkey )
                {
                    if ( $Openkey.GetValue('',$null) -like '*OneDrive*' )
                    {
                        $TypeLibs += $Lib
                    }

                    $Openkey.Close()
                }
            }

            $OpenRegKey.Close()
        }

        foreach ( $TypeLib in $TypeLibs )
        {
            $Path = "$isRoot\$RegKey\$TypeLib"

            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $TypeLibs.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 2
        #region 3

        [array] $RegKeys = 'Software\Classes\CLSID','Software\Classes\WOW6432Node\CLSID'

        [array] $CLSIDs = @()

        foreach ( $RegKey in $RegKeys )
        {
            if ( $RegKey -like '*\WOW6432Node\*' -and -not [System.Environment]::Is64BitOperatingSystem ) { continue }

            if ( $isRoot -ne 'HKCU:' )
            {
                if ( $RegKey -like 'Software\Classes\*' ) { $isRegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
                else { $isRegKey = "$SubRoot\$RegKey" }
            }
            else { $isRegKey = $RegKey }

            [array] $CLSIDsTemp = @()

            try { $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

            if ( $OpenRegKey )
            {
                foreach ( $CLSID in $OpenRegKey.GetSubKeyNames() )
                {
                    try { $Openkey = $OpenRegKey.OpenSubKey("$CLSID\InprocServer32",'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                    if ( $Openkey )
                    {
                        if ( $Openkey.GetValue('',$null) -like '*OneDrive*' )
                        {
                            $CLSIDsTemp += $CLSID

                            $Openkey.Close()

                            Continue
                        }

                        $Openkey.Close()
                    }

                    try { $Openkey = $OpenRegKey.OpenSubKey("$CLSID\LocalServer32",'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                    if ( $Openkey )
                    {
                        if ( $Openkey.GetValue('',$null) -like '*OneDrive*' )
                        {
                            $CLSIDsTemp += $CLSID
                        }

                        $Openkey.Close()
                    }
                }

                $OpenRegKey.Close()
            }

            $CLSIDs += $CLSIDsTemp

            foreach ( $CLSID in $CLSIDsTemp )
            {
                $Path = "$isRoot\$isRegKey\$CLSID"

                Set-Reg -Do:$Act Remove-Item -Path $Path
            }
        }

        $CLSIDs = $CLSIDs | Sort-Object -Unique

        if ( $CLSIDs.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 3
        #region 4

        [array] $RegKeys = 'Software\Classes\Interface','Software\Classes\WOW6432Node\Interface'

        $N = 0

        if ( $TypeLibs.Count -or $CLSIDs.Count )
        {
            foreach ( $RegKey in $RegKeys )
            {
                if ( $RegKey -like '*\WOW6432Node\*' -and -not [System.Environment]::Is64BitOperatingSystem ) { continue }

                if ( $isRoot -ne 'HKCU:' )
                {
                    if ( $RegKey -like 'Software\Classes\*' ) { $isRegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
                    else { $isRegKey = "$SubRoot\$RegKey" }
                }
                else { $isRegKey = $RegKey }

                try { $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

                [array] $Interfaces = @()

                if ( $OpenRegKey )
                {
                    foreach ( $Interface in $OpenRegKey.GetSubKeyNames() )
                    {
                        if ( $TypeLibs.Count )
                        {
                            try { $Openkey = $OpenRegKey.OpenSubKey("$Interface\TypeLib",'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $TypeLibs -like ( $Openkey.GetValue('',$null) ))
                                {
                                    $Interfaces += "$isRoot\$isRegKey\$Interface"

                                    $Openkey.Close()

                                    Continue
                                }

                                $Openkey.Close()
                            }
                        }

                        if ( $CLSIDs.Count )
                        {
                            try { $Openkey = $OpenRegKey.OpenSubKey("$Interface\ProxyStubClsid32",'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                            if ( $Openkey )
                            {
                                if ( $CLSIDs -like ( $Openkey.GetValue('',$null) ))
                                {
                                    $Interfaces += "$isRoot\$isRegKey\$Interface"
                                }

                                $Openkey.Close()
                            }
                        }
                    }

                    $OpenRegKey.Close()
                }

                foreach ( $Path in $Interfaces )
                {
                    $N++

                    Set-Reg -Do:$Act Remove-Item -Path $Path
                }
            }
        }

        if ( $N ) { Write-Host ; $AllRegKeys++ }

        #endregion 4
        #region 5

        [array] $RegKeys = 'Software\Classes\*\shellex\ContextMenuHandlers',
        'Software\Classes\Directory\Background\shellex\ContextMenuHandlers',
        'Software\Classes\Directory\shellex\ContextMenuHandlers',
        'Software\Classes\IE.AssocFile.URL\shellex\ContextMenuHandlers',
        'Software\Classes\lnkfile\shellex\ContextMenuHandlers'

        [array] $RegPaths = @()

        if ( $CLSIDs.Count )
        {
            foreach ( $RegKey in $RegKeys )
            {
                if ( $isRoot -ne 'HKCU:' )
                {
                    if ( $RegKey -like 'Software\Classes\*' ) { $isRegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
                    else { $isRegKey = "$SubRoot\$RegKey" }
                }
                else { $isRegKey = $RegKey }

                try { $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        try { $Openkey = $OpenRegKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues') } catch { $Openkey = $null }

                        if ( $Openkey )
                        {
                            if ( $CLSIDs -like ( $Openkey.GetValue('',$null) ))
                            {
                                $RegPaths += "$isRoot\$isRegKey\$SubKey"
                            }

                            $Openkey.Close()
                        }
                    }

                    $OpenRegKey.Close()
                }
            }
        }

        foreach ( $Path in $RegPaths )
        {
            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $RegPaths.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 5
        #region 6

        [string] $RegKey = 'Software\Classes\AppID'

        if ( $isRoot -ne 'HKCU:' )
        {
            if ( $RegKey -like 'Software\Classes\*' ) { $RegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
            else { $RegKey = "$SubRoot\$RegKey" }
        }

        try { $OpenRegKey = $RegRoot.OpenSubKey("$RegKey\OneDrive.EXE", 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

        [array] $RegPaths = @()

        if ( $OpenRegKey )
        {
            $RegPaths = "$isRoot\$RegKey\OneDrive.EXE"

            $AppID = $OpenRegKey.GetValue('AppID',$null)

            $OpenRegKey.Close()

            if ( $AppID )
            {
                try { $OpenRegKey = $RegRoot.OpenSubKey("$RegKey\$AppID", 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    $RegPaths += "$isRoot\$RegKey\$AppID"
                    $OpenRegKey.Close()
                }
            }
        }

        foreach ( $Path in $RegPaths )
        {
            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $RegPaths.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 6
        #region 7

        [string] $RegKey = 'Software\Google\Chrome\NativeMessagingHosts'

        if ( $isRoot -ne 'HKCU:' )
        {
            if ( $RegKey -like 'Software\Classes\*' ) { $RegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
            else { $RegKey = "$SubRoot\$RegKey" }
        }

        [array] $RegPaths = @()

        try { $OpenRegKey = $RegRoot.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
            {
                if ( $SubKey -like '*OneDrive*' )
                {
                    $RegPaths += "$isRoot\$RegKey\$SubKey"
                }
            }

            $OpenRegKey.Close()
        }

        foreach ( $Path in $RegPaths )
        {
            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $RegPaths.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 7
        #region 8

        [string] $RegKey = 'Software\Classes'

        [array] $Names = 'SyncEngineCOMServer.SyncEngineCOMServer',
        'BannerNotificationHandler.BannerNotificationHandler',
        'SyncEngineStorageProviderHandlerProxy.SyncEngineStorageProviderHandlerProxy',
        'SyncEngineFileInfoProvider.SyncEngineFileInfoProvider',
        'FileSyncClient.FileSyncClient',
        'FileSyncClient.AutoPlayHandler',
        'OOBERequestHandler.OOBERequestHandler',
        'NucleusToastActivator.NucleusToastActivator',
        'NucleusNativeMessaging.NucleusNativeMessaging'

        if ( $isRoot -ne 'HKCU:' )
        {
            if ( $RegKey -eq 'Software\Classes' ) { $RegKey = $RegKey.Replace('Software\Classes',"$SubRoot`_Classes") }
            else { $RegKey = "$SubRoot\$RegKey" }
        }

        [array] $RegPaths = @()

        try { $OpenRegKey = $RegRoot.OpenSubKey($RegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

        if ( $OpenRegKey )
        {
            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
            {
                if ( $Names.Where({ $SubKey -like "$_*" },'First') )
                {
                    $RegPaths += "$isRoot\$RegKey\$SubKey"
                }
            }

            $OpenRegKey.Close()
        }

        foreach ( $Path in $RegPaths )
        {
            Set-Reg -Do:$Act Remove-Item -Path $Path
        }

        if ( $RegPaths.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 8
        #region 9

        [array] $RegKeys = 'Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel',
        'Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION',
        'Software\Microsoft\Windows\CurrentVersion\Run',
        'Environment'

        [array] $Names = 'OneDriveConsumer','OneDriveCommercial','OneDrive','OneDrive.exe',
                         '{018D5C66-4533-4307-9B53-224DE2ED1FE6}','{04271989-C4D2-CF51-3598-A085E2BE504F}' # 'Microsoft.Lists'

        [array] $DataKeys = @()

        foreach ( $RegKey in $RegKeys )
        {
            if ( $isRoot -ne 'HKCU:' )
            {
                if ( $RegKey -like 'Software\Classes\*' ) { $isRegKey = $RegKey.Replace('Software\Classes\',"$SubRoot`_Classes\") }
                else { $isRegKey = "$SubRoot\$RegKey" }
            }
            else { $isRegKey = $RegKey }

            try { $OpenRegKey = $RegRoot.OpenSubKey($isRegKey, 'ReadSubTree','QueryValues,EnumerateSubKeys') } catch { $OpenRegKey = $null }

            if ( $OpenRegKey )
            {
                foreach ( $ValueName in $OpenRegKey.GetValueNames() )
                {
                    if ( $Names -like $ValueName )
                    {
                        $DataKeys += [PSCustomObject] @{
                            Path = "$isRoot\$isRegKey"
                            Name = $ValueName
                        }
                    }
                }

                $OpenRegKey.Close()
            }
        }

        foreach ( $DataKey in $DataKeys )
        {
            $Path = $DataKey.Path
            $Name = $DataKey.Name

            Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name $Name
        }

        if ( $DataKeys.Count ) { Write-Host ; $AllRegKeys++ }

        #endregion 9

        try { $AllRegKeys += Fix-Bag } catch {}

        if ( -not $AllRegKeys )
        {
            $text = if ( $L.s21 ) { $L.s21 } else { 'Параметры в реестре не найдены' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    #endregion Clean Registry
    #region Clean Files

    # Системные файлы не затрагиваются, чтобы не нарушать целостности.
    if ( $Act -eq 'Set' )
    {
        $text = if ( $L.s22 ) { $L.s22 } else { 'Очистка Файлов OneDrive' }

	    Stop-Process -Name 'OneDrive*','FileCoAuth','UserOOBEBroker' -Force -ErrorAction SilentlyContinue
    }
    else
    {
        $text = if ( $L.s23 ) { $L.s23 } else { 'Проверка Файлов OneDrive' }
    }

    Write-Host "`n   $text`:" -ForegroundColor DarkCyan

    foreach ( $Acc in $Accs )
    {
        $text = if ( $L.s20 ) { $L.s20 } else { 'Профиль' }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$($Acc.Name)" -ForegroundColor White

        if ( $Act -eq 'Set' ) { [string] $Color = 'DarkCyan' } else { [string] $Color = 'Yellow' }

        [array] $UserFolders = @()

        foreach ( $folder in @( $Acc.UserOneDriveFolder, $Acc.UserOneDriveConsumerFolder, $Acc.UserOneDriveCommercialFolder ).Where({$_}) )
        {
            $UserFolders += $folder
        }

        $UserFolders += "$($Acc.Profile)\OneDrive"

        foreach ( $UserFolder in ( $UserFolders | Sort-Object -Unique ))
        {
            if ( [System.IO.Directory]::Exists($UserFolder) )
            {
                if ( (Get-ChildItem -LiteralPath \\?\$UserFolder -ErrorAction SilentlyContinue).FullName.Count )
                {
                    if ( $Act -eq 'Set' )
                    {
                        $text = if ( $L.s24 ) { $L.s24 } else { 'Пропущено удаление папки OneDrive с файлами пользователя' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$UserFolder" -ForegroundColor DarkGray
                    }
                    else
                    {
                        $text = if ( $L.s25 ) { $L.s25 } else { 'Не будет удаляться папка OneDrive с файлами пользователя' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$UserFolder" -ForegroundColor DarkGray
                    }
                }
                else
                {
                    $text = if ( $L.s26 ) { $L.s26 } else { 'Удаление пустой папки OneDrive пользователя' }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$UserFolder" -ForegroundColor DarkGray

                    if ( $Act -eq 'Set' )
                    {
                        Remove-Item -LiteralPath \\?\$UserFolder -Recurse -Force -ErrorAction SilentlyContinue
                    }
                    else { $NeedFix = $true }
                }
            }
            else
            {
                $text = if ( $L.s27 ) { $L.s27 } else { 'Папка OneDrive пользователя не найдена' }

                if ( $UserFolder )
                {
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$UserFolder" -ForegroundColor DarkGray
                }
                else
                {
                    Write-Host "   $text" -ForegroundColor DarkGreen
                }
            }
        }

          [string] $UserProfile  = $Acc.Profile
          [string] $DesktopPath  = $Acc.UserDesktopFolder
        [string[]] $InstallPaths = $Acc.UserInstallPath

        if ( -not $InstallPaths ) { $InstallPaths = "$UserProfile\AppData\Local\Microsoft\OneDrive" }
        else
        {
            $InstallPaths += "$UserProfile\AppData\Local\Microsoft\OneDrive"
        }

        $InstallPaths += "${env:ProgramFiles(x86)}\Microsoft OneDrive"
        $InstallPaths += "$env:ProgramFiles\Microsoft OneDrive"

        $InstallPaths = $InstallPaths | Sort-Object -Unique

        if ( $Act -eq 'Set' )
        {
            Stop-Process -Name 'UserOOBEBroker' -Force -ErrorAction SilentlyContinue

            [bool] $RestartExplorer = $false

            foreach ( $InstallPath in $InstallPaths )
            {
                # Все файлы dll для интеграции OneDrive в проводник в его установленной папке
                [string[]] $FileSyncShelldlls = (Get-ChildItem -File -Path "$InstallPath\FileSyncShell*.dll" -Force -Recurse -ErrorAction SilentlyContinue).FullName

                # Если нет доступа к файлу, отменяем регистрацию dll до перезапуска проводника, чтобы снять блокировку с файла и всей его папки
                foreach ( $FileSyncShelldll in $FileSyncShelldlls )
                {
                    try
                    {
                        Remove-Item -LiteralPath \\?\$FileSyncShelldll -Force -ErrorAction Stop
                    }
                    catch
                    {
                        $RestartExplorer = $true

                        break
                    }
                }

                if ( $RestartExplorer ) { break }
            }

            if ( $RestartExplorer )
            {
                $text = if ( $L.s28 ) { $L.s28 } else { 'Перезапуск проводника' }
                Write-Host "`n   $text`n" -ForegroundColor DarkGray

                ReStart-Explorer
            }
        }

        [string[]] $Paths = $InstallPaths +
                           "$env:ProgramData\Microsoft OneDrive",
                           "$UserProfile\OneDriveTemp",
                           "$UserProfile\AppData\Local\OneDrive",
                           "$DesktopPath\OneDrive.lnk",
                           "$UserProfile\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"

        Token-Impersonate -Token SYS

        $N = 0

        foreach ( $Path in $Paths )
        {
            if ( $Path )
            {
                if ( [System.IO.Directory]::Exists($Path) )
                {
                    $text = if ( $L.s29 ) { $L.s29 } else { 'Удаление папки' }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Path" -ForegroundColor DarkGray

                    if ( $Act -eq 'Set' )
                    {
                        Remove-Item -LiteralPath "\\?\$Path" -Recurse -Force -ErrorAction SilentlyContinue

                        if ( [System.IO.Directory]::Exists($Path) )
                        {
                            $N++

                            if ( -not $RestartExplorer -and $N -eq 1 )
                            {
                                ReStart-Explorer -Stop

                                Remove-Item -LiteralPath "\\?\$Path" -Recurse -Force -ErrorAction SilentlyContinue
                            }

                            if ( [System.IO.Directory]::Exists($Path) )
                            {
                                $text = if ( $L.s29_1 ) { $L.s29_1 } else { 'Не получилось удалить папку' }
                                Write-Host "   $text`: " -ForegroundColor DarkYellow -NoNewline
                                Write-Host "$Path" -ForegroundColor DarkYellow
                            }
                        }
                    }
                    else { $NeedFix = $true }
                }
                elseif ( [System.IO.File]::Exists($Path) )
                {
                    $text = if ( $L.s30 ) { $L.s30 } else { 'Удаление файла' }
                    Write-Host "   $text`: " -ForegroundColor $Color -NoNewline
                    Write-Host "$Path" -ForegroundColor DarkGray

                    if ( $Act -eq 'Set' )
                    {
                        Remove-Item -LiteralPath "\\?\$Path" -Force -ErrorAction SilentlyContinue
                    }
                    else { $NeedFix = $true }
                }
                else
                {
                    $text = if ( $L.s31 ) { $L.s31 } else { 'Не существует' }
                    Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "$Path" -ForegroundColor DarkGray
                }
            }
        }

        Token-Impersonate -Reset

        ReStart-Explorer -OnlyOpenWindows
    }

    #endregion Clean Files

    # Восстановление системного ярлыка в дефолтном профиле, если его нет
    [string] $DefProfile = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile
    if ( -not $DefProfile ) { $DefProfile = "$env:SystemDrive\Users\Default" }

    [string] $Lnk = "$DefProfile\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"

    if ( [System.IO.Directory]::Exists($DefProfile) )
    {
        if ( -not [System.IO.File]::Exists($Lnk) )
        {
            if ( [System.Environment]::Is64BitOperatingSystem )
            {
                $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\wow64_microsoft-windows-onedrive-setup*",
                            "$env:SystemDrive\Windows\WinSxS\amd64_microsoft-windows-onedrive-setup*" -ErrorAction SilentlyContinue
                            ).Foreach({ Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -like '*.lnk'},'Last')
            }
            else
            {
                $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\x86_microsoft-windows-onedrive-setup*" -ErrorAction SilentlyContinue
                            ).Foreach({ Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -like '*.lnk'},'Last')
            }

            if ( $Target.FullName )
            {
                $text = if ( $L.s32 ) { $L.s32 } else { 'Восстановление системного ярлыка' }
                Write-Host "`n   $text`: " -ForegroundColor $Color
                Write-Host "   $Lnk" -ForegroundColor DarkGray

                if ( $Act -eq 'Set' )
                {
                    Token-Privileges -Enable -Privileges 'SeRestorePrivilege'
                    New-Item -ItemType HardLink -Path $Lnk -Target $Target.FullName -Force -ErrorAction SilentlyContinue > $null
                }
                else { $NeedFix = $true }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Cистемный ярлык "OneDrive.lnk" не требуется восстанавливать из WinSxS' }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$env:SystemDrive\Windows\WinSxS\...microsoft-windows-onedrive-setup..." -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s34 ) { $L.s34 } else { 'Ярлык существует' }
            Write-Host "`n   $text`: " -ForegroundColor DarkGreen -NoNewline
            Write-Host "$Lnk" -ForegroundColor DarkGray
        }
    }
    else
    {
        $text = if ( $L.s35 ) { $L.s35 } else { 'Папка Профиля ''DefaultAccount'' не найдена' }
        Write-Host "`n   $text`: " -ForegroundColor DarkYellow -NoNewline
        Write-Host "$DefProfile" -ForegroundColor DarkGray
    }

    if ( $Act -eq 'Set' )
    {
        $text = if ( $L.s9 ) { $L.s9 } else { 'Завершены все действия' }
    }
    else
    {
        $text = if ( $L.s36 ) { $L.s36 } else { 'Проверка завершена' }
    }

    Write-Host "   $text`n" -ForegroundColor Green

    # Возврат глобального перенаправления настройки реестра, которое было до запуска функции
    if ( $Redirects ) { @($Global:DataAllUsers.Where({ $_.Redirects },'First')).ForEach({ $_.Redirects.Value = $true }) }
}
