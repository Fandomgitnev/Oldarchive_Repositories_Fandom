﻿
<#
.SYNOPSIS
 Настройка Групповых политик с помощью утилиты LGPO.exe v2.2 от MS.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Group_Policy.
 Нужны права администратора.

 При настройке через LGPO.exe параметры добавляются к уже настроенным,
 заменяя параметры, которые уже настроенны.
 Параметры отображаются в оснастке ГП, так же, если бы вы настраивали их вручную.

 LGPO.exe для настройки нужен готовый файл с параметрами в своем формате.

 Можно сгенерировать свой файл,
 на основе уже настроенных ГП в системе: LGPO-Machine-User-My.txt

 Есть возможность проверить настроены ли ГП, или наличие файла с параметрами,
 или сбросить ГП в системе.

 Если есть ваши комментарии ГП рядом с файлом LGPO-Machine-User-My.txt,
 то они будут скопированы в системные папки: comment_Machine.cmtx или comment_User.cmtx
 При генерации своего файла с параметрами, если есть комментарии ГП в системе,
 будут скопированы к файлу LGPO-Machine-User-My.txt

 Если при генерации своего файла, уже есть файл настроек или файлы комментариев,
 то они будут сохранены под сгенерированными названиями с добавлением к имени полной текущей даты.

.EXAMPLE
    Set-Group-Policy -ApplyGP MyFileLGPO

    Описание
    --------
    Применить настройки ГП из своего файла LGPO-Machine-User-My.txt

.EXAMPLE
    Set-Group-Policy -CreateFile

    Описание
    --------
    Создание своего файла LGPO-Machine-User-My.txt с параметрами для ГП.

.EXAMPLE
    Set-Group-Policy -CheckState User

    Описание
    --------
    Проверка наличия настроенных ГП для конфигурации Пользователя.

.EXAMPLE
    Set-Group-Policy -Reset

    Описание
    --------
    Сброс ГП в системе, удаляются только файлы .pol, если есть,
    затем обновление параметров ГП.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  16-11-2018
 ===============================================

 #>
Function Set-Group-Policy {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true, ParameterSetName = 'Apply', Position = 0 )]
        [ValidateSet( 'FileLGPO', 'MyFileLGPO' )]
        [string] $ApplyGP
       ,
        [Parameter( Mandatory = $true, ParameterSetName = 'CheckFile' )]
        [ValidateSet( 'FileLGPO', 'MyFileLGPO' )]
        [string] $CheckFile
       ,
        [Parameter( Mandatory = $true, ParameterSetName = 'CheckState' )]
        [ValidateSet( 'Machine', 'User' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $true, ParameterSetName = 'Create' )]
        [switch] $CreateFile
       ,
        [Parameter( Mandatory = $true, ParameterSetName = 'Reset' )]
        [switch] $Reset
       ,
        [Parameter( Mandatory = $false )]
        [string] $GPfolder = $GPfolderGlobal   # Папка для сохранения своих параметров Групповых Политик. По умолчанию задана глобальная переменная.
       ,
        [Parameter( Mandatory = $false )]
        [string] $LGPOExe = $LGPOExeGlobal     # Утилита LGPO.exe
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Проверка возможности применения Групповых политик.
    if ( -not ( [System.IO.File]::Exists($LGPOExe) ))
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Не задана или не найдена утилита LGPO.exe' }
        Write-Warning "`n   $NameThisFunction`: $text`: '$LGPOExe'!`n "

        Return      # Выходим из функции.
    }
    elseif ( -not ( [System.IO.File]::Exists("$env:SystemRoot\System32\gpedit.msc") ))
    {
        $text = if ( $L.s2 ) { $L.s2 } else { 'Нет оснастки управления Групповыми Политиками в Windows, пропуск выполнения' }
        Write-Warning "`n   $NameThisFunction`: $text"

        Return      # Выходим из функции.
    }

    # Проверка и создание папки для файлов настроек Групповой Политики.
    if ( $GPfolder )
    {
        if ( -not [System.IO.Directory]::Exists($GPfolder) )
        {
            try { New-Item -ItemType Directory -Path $GPfolder -Force -ErrorAction Stop > $null }
            catch
            {
                $text = if ( $L.s3 ) { $L.s3 } else { 'Ошибка при создании папки' }
                Write-Warning "`n   $NameThisFunction`: $text`: '$GPfolder'`n`t$($_.exception.Message)"

                Get-Pause ; Exit
            }
        }
    }
    else
    {
        $text = if ( $L.s4 ) { $L.s4 } else { 'Не указан путь для файлов настроек Групповых Политик' }
        Write-Warning "`n   $NameThisFunction`: $text`: `$GPfolder`n"

        Get-Pause ; Exit
    }

    # Если указано применить Групповые политики из файла для LGPO.exe
    if ( $ApplyGP )
    {
        # Задаем файл для LGPO.exe
        if ( $ApplyGP -eq 'FileLGPO' ) { [string] $My = '' } else { [string] $My = '-My' }
        [string] $FileGP = "$GPfolder\LGPO-Machine-User$My.txt"

        if ( -not ( [System.IO.File]::Exists($FileGP) ))
        {
            $text = if ( $L.s5 ) { $L.s5 } else { 'Не найден файл с настройками ГП' }
            Write-Host "`n   $NameThisFunction`: $text`: '$FileGP'`n " -ForegroundColor DarkGray

            Get-Pause

            Return     # Выходим из функции.
        }

        $text = if ( $L.s6 ) { $L.s6 } else { 'Настраиваем Групповые политики' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s6_1 ) { $L.s6_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        # Запущенная Консоль управления ГП помешает настроить параметры ГП.
        $text = if ( $L.s7 ) { $L.s7 } else { 'Закрываем все окна оснасток управления MMC' }
        Write-Host "   $text" -ForegroundColor DarkGray
        Get-Process -Name 'mmc' -ErrorAction SilentlyContinue | Where-Object { try { $_.CloseMainWindow() > $null ; Start-Sleep -Milliseconds 500 } catch {} }

        # Если есть свои файлы коментариев для ГП, копируем их в системные настройки.
        [string] $MyCommentMachine = "$GPfolder\comment_Machine.cmtx"
        [string] $MyCommentUser    = "$GPfolder\comment_User.cmtx"

        [string] $CommentMachine   = "$env:SystemRoot\System32\GroupPolicy\Machine\comment.cmtx"
        [string] $CommentUser      = "$env:SystemRoot\System32\GroupPolicy\User\comment.cmtx"

        if ( [System.IO.File]::Exists($MyCommentMachine) )
        {
            $text = "   {0}: '$MyCommentMachine'`n   {1}: '$CommentMachine'" -f $(if ( $L.s8 ) { $L.s8, $L.s8_1 } else { 'Копируем файл','            в' })

            Write-Host "$text" -ForegroundColor DarkGray

            Copy-Item -LiteralPath \\?\$MyCommentMachine -Destination \\?\$CommentMachine -Force -ErrorAction SilentlyContinue
        }

        if ( [System.IO.File]::Exists($MyCommentUser) )
        {
            $text = "   {0}: '$MyCommentUser'`n   {1}: '$CommentUser'" -f $(if ( $L.s8 ) { $L.s8, $L.s8_1 } else { 'Копируем файл','            в' })

            Write-Host "$text" -ForegroundColor DarkGray

            Copy-Item -LiteralPath \\?\$MyCommentUser -Destination \\?\$CommentUser -Force -ErrorAction SilentlyContinue
        }

        $text = if ( $L.s9 ) { $L.s9 } else { 'Применяем' }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s9_1 ) { $L.s9_1 } else { 'настройки ГП' }
        Write-Host "$text " -NoNewline

        $text = if ( $L.s9_2 ) { $L.s9_2 } else { 'из файла' }
        Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$FileGP`n" -ForegroundColor Green

        # Применяем настройки ГП из выбранного файла.
        try { & $LGPOExe /t $FileGP /q 2> $null } catch {}

        # Если была ошибка при применении файла настроек Групповых политик.
        if ( -not $? )
        {
            $text = if ( $L.s10 ) { $L.s10 } else { "Не удалось применить параметры Групповой политики.`n   Ошибка в файле" }
            Write-Warning  "`n   $NameThisFunction`: $text`: '$FileGP'"
        }
        else
        {
            $text = if ( $L.s11 ) { $L.s11 } else { 'Выполнено' }
            Write-Host "   $text" -ForegroundColor Green

            $text = if ( $L.s12 ) { $L.s12 } else { 'Параметры вступят в силу сразу, но лучше перезагрузится!' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }

        Get-Pause
    }
    elseif ( $CheckFile )
    {
        # Если указано проверить существование файла с параметрами ГП, по одному файлу за раз.

        # Задаем файл для LGPO.exe
        if ( $CheckFile -eq 'FileLGPO' ) { [string] $My = '' ; [string] $Space = '   ' } else { [string] $My = '-My' ; [string] $Space = '' }
        [string] $FileGP = "$GPfolder\LGPO-Machine-User$My.txt"

        if ( [System.IO.File]::Exists($FileGP) )
        { "#DarkGray#| Files\GP\#LGPO-Machine-User$My.txt #DarkGray#$Space| #Green#{0}#" -f $(if ( $L.s13 ) { $L.s13 } else { 'Найден' }) }
        else
        { "#DarkGray#| Files\GP\#LGPO-Machine-User$My.txt #DarkGray#$Space| #Yellow#{0}#" -f $(if ( $L.s13_1 ) { $L.s13_1 } else { 'Не найден' }) }
    }
    elseif ( $CheckState )
    {
        # Если указано проверить наличие настроенных параметров ГП в системе, по одному файлу за раз.

        # Задаем файл для проверки настроенных ГП.
        [string] $FileGP = "$env:SystemRoot\System32\GroupPolicy\$CheckState\Registry.pol"

        # Если файл существует, и размер больше 99 байт.
        if ( [System.IO.FileInfo]::new($FileGP).Length -gt 99 )
        { '#Green#{0}#' -f $(if ( $L.s14 ) { $L.s14 } else { 'Найдены применённые параметры' }) }
        else
        { '#Yellow#{0}#' -f $(if ( $L.s14_1 ) { $L.s14_1 } else { 'Не настроена' }) }
    }
    elseif ( $CreateFile )
    {
        # Если указано создать свой файл для LGPO.exe, с уже настроенными параметрами ГП в системе.

        $text = if ( $L.s15 ) { $L.s15 } else { 'Создание файла' }
        Write-Host "`n $text`: \Files\GP\LGPO-Machine-User-My.txt`n " -ForegroundColor Cyan

        # Задаем файлы ГП в системе.
        [string] $SystemGPMachine = "$env:SystemRoot\System32\GroupPolicy\Machine\Registry.pol"
        [string] $SystemGPUser    = "$env:SystemRoot\System32\GroupPolicy\User\Registry.pol"
        [string] $MyGPfile        = "$GPfolder\LGPO-Machine-User-My.txt"

        # Если ни одного файла не существует, или размер у них не больше 99 байт, значит нет насторенных ГП.
        if ( -not ( [System.IO.FileInfo]::new($SystemGPMachine).Length -gt 99 )) { $SystemGPMachine = $null }
        if ( -not ( [System.IO.FileInfo]::new($SystemGPUser).Length -gt 99 )) { $SystemGPUser = $null }
        if (( -not $SystemGPMachine ) -and ( -not $SystemGPUser ))
        {
            $text = if ( $L.s16 ) { $L.s16 } else { 'Нет настроенных Групповых Политик, пропуск!' }
            Write-Host "   $text" -ForegroundColor Yellow ; Return    # Выходим из функции.
        }
        else
        {
            if ( [System.IO.File]::Exists($MyGPfile) )
            {
                $text = if ( $L.s17 ) { $L.s17 } else { 'Найдены свои настройки ГП' }
                Write-Host "   $text`:" -ForegroundColor Green

                [string] $MyGPfileBackUP = "$GPfolder\LGPO-Machine-User-My_$((Get-Date -Format 'yyyyMMdd-HHmmss')).txt"

                $text = if ( $L.s18 ) { $L.s18 } else { 'Бэкап своих настроек ГП в' }
                Write-Host "   $text`: '$MyGPfileBackUP'" -ForegroundColor DarkGray
                Copy-Item -LiteralPath \\?\$MyGPfile -Destination \\?\$MyGPfileBackUP -Force -ErrorAction SilentlyContinue

                $text = if ( $L.s19 ) { $L.s19 } else { 'Удаление файла' }
                Write-Host "   $text`: '$MyGPfile'" -ForegroundColor DarkGray
                Remove-Item -LiteralPath \\?\$MyGPfile -Force -ErrorAction SilentlyContinue
            }
        }

        # Если есть настроенные ГП для Компьютера.
        if ( $SystemGPMachine )
        {
            # файл перезаписывается.
            $text = if ( $L.s20 ) { $L.s20 } else { 'Получаем параметры ГП из конфигурации для Компьютера' }
            Write-Host "   $text`:" -ForegroundColor Green
            try { & $LGPOExe /parse /q /m $SystemGPMachine > $MyGPfile } catch {}

            # Если есть файл коментариев ГП в системе, то копирование его себе в папку.
            [string] $Comment         = "$env:SystemRoot\System32\GroupPolicy\Machine\comment.cmtx"
            [string] $MyComment       = "$GPfolder\comment_Machine.cmtx"
            [string] $MyCommentBackUP = "$GPfolder\comment_Machine_$((Get-Date -Format 'yyyyMMdd-HHmmss')).cmtx"

            if ( [System.IO.File]::Exists($Comment) )
            {
                if ( [System.IO.File]::Exists($MyComment) )
                {
                    $text = if ( $L.s21 ) { $L.s21 } else { 'Сохраняем Бэкап своего файла в' }
                    Write-Host "   $text`: '$MyCommentBackUP'" -ForegroundColor DarkGray
                    Copy-Item -LiteralPath \\?\$MyComment -Destination \\?\$MyCommentBackUP -Force -ErrorAction SilentlyContinue
                }

                $text = if ( $L.s22 ) { $L.s22 } else { 'Копируем себе файл из папки Windows' }
                Write-Host "   $text`: '$Comment'" -ForegroundColor DarkGray
                Copy-Item -LiteralPath \\?\$Comment -Destination \\?\$MyComment -Force -ErrorAction SilentlyContinue
            }
        }
        else
        {
            $text = if ( $L.s23 ) { $L.s23 } else { 'Нет настроенных ГП с конфигурацией для Компьютера!' }
            Write-Host "   $text" -ForegroundColor Yellow
        }

        # Если есть настроенные ГП для Пользователя.
        if ( $SystemGPUser )
        {
            # Добавление параметров в файл, так как могли быть добавлены параметры из конфигурации для компьютера.
            $text = if ( $L.s24 ) { $L.s24 } else { 'Получаем параметры ГП из конфигурации для Пользователя' }
            Write-Host "   $text`:" -ForegroundColor Green
            try { & $LGPOExe /parse /q /u $SystemGPUser >> $MyGPfile } catch {}

            # Если есть файл коментариев ГП в системе, то копирование его себе в папку.
            [string] $Comment         = "$env:SystemRoot\System32\GroupPolicy\User\comment.cmtx"
            [string] $MyComment       = "$GPfolder\comment_User.cmtx"
            [string] $MyCommentBackUP = "$GPfolder\comment_User_$(Get-Date -Format 'yyyyMMdd-HHmmss').cmtx"

            if ( [System.IO.File]::Exists($Comment) )
            {
                if ( [System.IO.File]::Exists($MyComment) )
                {
                    $text = if ( $L.s21 ) { $L.s21 } else { 'Сохраняем Бэкап своего файла в' }
                    Write-Host "   $text`: '$MyCommentBackUP'" -ForegroundColor DarkGray
                    Copy-Item -LiteralPath \\?\$MyComment -Destination \\?\$MyCommentBackUP -Force -ErrorAction SilentlyContinue
                }

                $text = if ( $L.s22 ) { $L.s22 } else { 'Копируем себе файл из папки Windows' }
                Write-Host "   $text`: '$Comment'" -ForegroundColor DarkGray
                Copy-Item -LiteralPath \\?\$Comment -Destination \\?\$MyComment -Force -ErrorAction SilentlyContinue
            }
        }
        else
        {
            $text = if ( $L.s25 ) { $L.s25 } else { 'Нет настроенных ГП с конфигурацией для Пользователя!' }
            Write-Host "   $text" -ForegroundColor Yellow
        }

        $text = if ( $L.s11 ) { $L.s11 } else { 'Завершено' }
        Write-Host "   $text" -ForegroundColor Green

        Get-Pause
    }
    elseif ( $Reset )
    {
        # Если указано сбросить все параметры ГП.

        $text = if ( $L.s26 ) { $L.s26 } else { 'Сбрасываем все Групповые политики' }
        Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s26_1 ) { $L.s26_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

        # Запущенная Консоль управления ГП помешает настроить параметры ГП.
        $text = if ( $L.s7 ) { $L.s7 } else { 'Закрываем все окна оснасток управления MMC' }
        Write-Host "   $text" -ForegroundColor DarkGray
        Get-Process -Name 'mmc' -ErrorAction SilentlyContinue | Where-Object { try { $_.CloseMainWindow() > $null ; Start-Sleep -Milliseconds 500 } catch {} }

        # Задаем файлы ГП в системе.
        [string] $SystemGPMachine = "$env:SystemRoot\System32\GroupPolicy\Machine\Registry.pol"
        [string] $SystemGPUser    = "$env:SystemRoot\System32\GroupPolicy\User\Registry.pol"

        # Если хоть один файл существует, значит есть или были насторенные ГП.
        if ( [System.IO.File]::Exists($SystemGPMachine) -or [System.IO.File]::Exists($SystemGPUser) )
        {
            if ( [System.IO.File]::Exists($SystemGPMachine) )
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Удаление файла' }
                Write-Host "   $text`: '$SystemGPMachine'" -ForegroundColor DarkGray
                Remove-Item -LiteralPath \\?\$SystemGPMachine -Force -ErrorAction SilentlyContinue
            }

            if ( [System.IO.File]::Exists($SystemGPUser) )
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Удаление файла' }
                Write-Host "   $text`: '$SystemGPUser'" -ForegroundColor DarkGray
                Remove-Item -LiteralPath \\?\$SystemGPUser -Force -ErrorAction SilentlyContinue
            }

            $text = if ( $L.s27 ) { $L.s27 } else { 'Обновление параметров ГП ...' }
            Write-Host "`n   $text`n" -ForegroundColor DarkGreen
            try { gpupdate.exe /force 2> $null } catch {}

            $text = if ( $L.s11 ) { $L.s11 } else { 'Завершено' }
            Write-Host "   $text" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s28 ) { $L.s28 } else { 'Нет настроенных Групповых политик' }
            Write-Host "   $text" -ForegroundColor DarkYellow
        }

        # Так как производился сброс Групповых Политик, устанавливаем глобальную переменную, сообщающую об этом,
        # чтобы не применялись параметры Групповых Политик в функции Быстрых настроек, по завершении всех настроек.
        Set-Variable -Name GroupPoliciesReset -Value $true -Scope Global -Option AllScope -Force

        # Обнуляем глобальные параметры ГП и параметры для исключения из Registry.pol файла
        $Global:SettingsGP = @()
        $Global:RemoveValuesGP = @()

        Get-Pause
    }
}
