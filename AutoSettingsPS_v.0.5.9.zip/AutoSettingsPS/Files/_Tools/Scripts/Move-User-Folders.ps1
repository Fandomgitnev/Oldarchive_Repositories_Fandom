﻿
<#
.SYNOPSIS
 Изменение расположения папок пользователя, таких как:
 Видео, Документы, Загрузки, Изображения, Музыка, Рабочий стол.
 Все сразу или только необходимые.
 И создание символических ссылок в расположении по умолчанию указывающих на новое расположение.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Move_User_Folders.
 Используется функция Set-OwnerAndAccess для настройки параметров безопасности через SDDL.
 Используется функция Token-Impersonate для подключения и сброса повышения прав.
 Используется функция ReStart-Explorer для корректного завершения процесса проводника и переоткрытия окон.
 Используется функция Get-Pause для установки паузы.
 Используется функция Get-List-Presets
 Используется утилита MS Handle.exe для получения блокирующих папку процессов,
 необходимо для завершения этих процессов, чтобы была возможность удалить заблокированную папку.
 Используется WinAPI для корректного изменения расположения папок, без внесения напрямую параметров в реестр и перезапуска проводника.
 Для выполнения всех действий нужны эти функции и утилита и права администратора.

 Получает из файла пресетов 'Presets.txt' заданные пути для папок,
 получает из реестра текущее местоположение, и если путь получен и папка есть,
 копирует с помощью Robocopy.exe в новое расположение все файлы и папки,
 и если копирование без критических ошибок, удаляет папку-источник.

 Задает в реестре необходимые параметры.
 Создает папку, если нету, пересоздает оригинальные файлы desktop.ini
 Настраивает при необходимости параметры безопасности и атрибуты у папки и desktop.ini.

 С помощью этой функции можно восстановить все эти папки и их параметры,
 даже если нет ни папок ни параметров в реестре.

 Для каждой папки в файле пресетов 'Presets.txt' можно указать свой путь:
 Пример для рабочего стола: User-Folder-Desktop   =D:\User=

.PARAMETER Folders
 Массив с нужными папками: Videos, Documents, Downloads, Pictures, Music, Desktop, SavedGames

.PARAMETER Default
 Указывает восстановить расположение по умолчанию.

.PARAMETER CheckPreset
 Указывает вывести путь из пресета для указанной только одной папки.

.PARAMETER CheckState
 Указывает вывести текущее состояние для указанной только одной папки.

.PARAMETER ClearFastAccess
 Указывает очистить из быстрого доступа закрепленные элементы пользователем.

.EXAMPLE
    Move-User-Folders -Folders Videos,Music

    Описание
    --------
    Изменение расположение папок Видео и Музыка.
    Если есть файлы в папках, все будет перемещено в новый путь.

.EXAMPLE
    Move-User-Folders -Folders Videos,Music -Default

    Описание
    --------
    Восстановление расположения папок Видео и Музыка по умолчанию.
    Если есть файлы в папках, все будет перемещено в расположение по умолчанию.

.EXAMPLE
    Move-User-Folders -CheckPreset Videos

    Описание
    --------
    Вывод пути из пресета для папки Видео, форматировано для меню.

.EXAMPLE
    Move-User-Folders -CheckState Videos

    Описание
    --------
    Вывод состояния для папки Видео, форматировано для меню.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  14-11-2018
 ===============================================

#>
Function Move-User-Folders {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false, ParameterSetName = 'Set',    Position = 0 )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Preset', Position = 0 )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'State',  Position = 0 )]
        [ValidateSet( 'Videos', 'Documents', 'Downloads', 'Pictures', 'Music', 'Desktop', 'SavedGames' )]
        [System.Collections.Generic.List[string]] $Folders
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set'    )]
        [switch] $Default
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Preset' )]
        [switch] $CheckPreset
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Preset' )]
        [switch] $CheckReturnOnlyValue
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'State'  )]
        [switch] $CheckState
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Clear'  )]
        [switch] $ClearFastAccess
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если указана очистка Быстрого доступа от закрепленных элементов пользователем, при невозможности их удалить после переноса папок.
    if ( $ClearFastAccess )
    {
        $text = if ( $L.s2 ) { $L.s2 } else { 'Очистка Быстрого доступа от закрепленных элементов пользователем' }
        Write-Host "`n $text" -ForegroundColor Cyan

        # Закрываем все окна проводника, чтобы проводник не блокировал папки.
        ReStart-Explorer -OnlyCloseWindows

        if ( @($Global:OpenedFolders).Count )
        {
            $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Все окна Explorer временно закрыты' }
            Write-Host "   $text" -ForegroundColor DarkGray
        }

        # Удаление всех файлов в папке.
        $text = if ( $L.s3 ) { $L.s3 } else { 'Удаление элементов' }
        Write-Host "   $text" -ForegroundColor Magenta

        [string] $Path = "$env:USERPROFILE\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations"

        foreach ( $File in (Get-ChildItem -File -LiteralPath \\?\$Path -Force -ErrorAction SilentlyContinue).FullName )
        { try { Remove-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue } catch {} }

        $text = if ( $L.s4 ) { $L.s4 } else { 'Выполнено' }
        Write-Host "   $text" -ForegroundColor Green

        # Открытие всех ранее закрытых окон
        ReStart-Explorer -OnlyOpenWindows

        Get-Pause

        Return  # Выход из функции.
    }

    # Обновление данных из пресета в глобальной переменной: $ListPresetsGlobal, которая используется в других функциях
    $ListPresetsGlobal = Get-List-Presets -File $FilePresets

    # для QuickPresets при запуске без указания папок
    if ( -not $Folders )
    {
        $Folders = @()

        # Получаем список параметров в пресете
        foreach ( $Line in ( $ListPresetsGlobal -match '^\s*User-Folder-[a-z\s]+=\s*1\s*=' ))
        {
            # Берем заданные параметры
            if     ( $Line -match '^\s*User-Folder-Videos\s*='      ) { $Folders.Add('Videos')      }
            elseif ( $Line -match '^\s*User-Folder-Documents\s*='   ) { $Folders.Add('Documents')   }
            elseif ( $Line -match '^\s*User-Folder-Downloads\s*='   ) { $Folders.Add('Downloads')   }
            elseif ( $Line -match '^\s*User-Folder-Pictures\s*='    ) { $Folders.Add('Pictures')    }
            elseif ( $Line -match '^\s*User-Folder-Music\s*='       ) { $Folders.Add('Music')       }
            elseif ( $Line -match '^\s*User-Folder-Desktop\s*='     ) { $Folders.Add('Desktop')     }
            elseif ( $Line -match '^\s*User-Folder-Saved Games\s*=' ) { $Folders.Add('Saved Games') }
        }

        if ( -not $Folders.Count )
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Параметры не указаны' }
            Write-Host "`n   $NameThisFunction`: $text`n" -ForegroundColor DarkGray

            Return
        }
    }
    else
    {
        # Замена имени папки на правильное название
        for ( $i = 0 ; $i -lt $Folders.count ; $i++ )
        {
           if ( $Folders[$i] -eq 'SavedGames' ) { $Folders[$i] = 'Saved Games' }
        }
    }

    # Карта-шаблон параметров реестра для получения места расположения папок и настройки.
    [hashtable] $FolderDataMap = @{

        'Videos'      = 'My Video',                              '{35286A68-3C57-41A1-BBB1-0EAE73D76C95}'
        'Documents'   = 'Personal',                              '{F42EE2D3-909F-4907-8871-4C22FC0BF756}'
        'Downloads'   = '{374DE290-123F-4565-9164-39C4925E467B}','{7D83EE9B-2244-4E70-B1F5-5393042AF1E4}'
        'Pictures'    = 'My Pictures',                           '{0DDD015D-B06C-45D5-8C4C-F59713854639}'
        'Music'       = 'My Music',                              '{A0C69A99-21C8-4671-8703-7934162FCF1D}'
        'Desktop'     = 'Desktop',                               '{754AC886-DF64-4CBA-86B5-F7FBF4FBCEF5}'
        'Saved Games' = '{4C5C32FF-BB9D-43B0-B5B4-2D72E54EAAA4}','{4C5C32FF-BB9D-43B0-B5B4-2D72E54EAAA4}'
    }

    # Карта-шаблон параметров реестра для настройки папок через WinAPI C# функцию SHSetKnownFolderPath.
    [hashtable] $KnownFoldersMap = @{

        'Videos'      = '18989B1D-99B5-455B-841C-AB7C74E4DDFC', '35286a68-3c57-41a1-bbb1-0eae73d76c95'
        'Documents'   = 'FDD39AD0-238F-46AF-ADB4-6C85480369C7', 'f42ee2d3-909f-4907-8871-4c22fc0bf756'
        'Downloads'   = '374DE290-123F-4565-9164-39C4925E467B', '7d83ee9b-2244-4e70-b1f5-5393042af1e4'
        'Pictures'    = '33E28130-4E1E-4676-835A-98395C3BC3BB', '0ddd015d-b06c-45d5-8c4c-f59713854639'
        'Music'       = '4BD8D571-6D19-48D3-BE97-422220080E43', 'a0c69a99-21c8-4671-8703-7934162fcf1d'
        'Desktop'     = 'B4BFCC3A-DB2C-424C-B029-7FE99A87C641'
        'Saved Games' = '4C5C32FF-BB9D-43B0-B5B4-2D72E54EAAA4'
    }

    # Карта-шаблон параметров файлов desktop.ini, для каждой папки, для возможности их создания.
    [hashtable] $FolderINIMap = @{

        'Videos'      = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21791',
                        'InfoTip=@%SystemRoot%\system32\shell32.dll,-12690','IconResource=%SystemRoot%\system32\imageres.dll,-189',
                        'IconFile=%SystemRoot%\system32\shell32.dll','IconIndex=-238'
        'Documents'   = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21770',
                        'IconResource=%SystemRoot%\system32\imageres.dll,-112','IconFile=%SystemRoot%\system32\shell32.dll','IconIndex=-235'
        'Downloads'   = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21798',
                        'IconResource=%SystemRoot%\system32\imageres.dll,-184'
        'Pictures'    = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21779',
                        'InfoTip=@%SystemRoot%\system32\shell32.dll,-12688','IconResource=%SystemRoot%\system32\imageres.dll,-113',
                        'IconFile=%SystemRoot%\system32\shell32.dll','IconIndex=-236'
        'Music'       = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21790',
                        'InfoTip=@%SystemRoot%\system32\shell32.dll,-12689','IconResource=%SystemRoot%\system32\imageres.dll,-108',
                        'IconFile=%SystemRoot%\system32\shell32.dll','IconIndex=-237'
        'Desktop'     = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21769',
                        'IconResource=%SystemRoot%\system32\imageres.dll,-183'
        'Saved Games' = '','[.ShellClassInfo]','LocalizedResourceName=@%SystemRoot%\system32\shell32.dll,-21814',
                        'IconResource=%SystemRoot%\system32\imageres.dll,-186'
    }

    # Защищаемые папки OneDrive, параметр KfmFoldersProtectedNow HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive\Accounts\Personal и/или Business1
    [Flags()] enum ProtectOD
    {
        Desktop   = 512
        Documents = 1024
        Pictures  = 2048
    }

    [ProtectOD] $Protect1 = 0
    [ProtectOD] $Protect2 = 0

    try { $Protect1 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive\Accounts\Personal', 'KfmFoldersProtectedNow',0) }
    catch {}
    try { $Protect2 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\OneDrive\Accounts\Business1','KfmFoldersProtectedNow',0) }
    catch {}

    [ProtectOD] $ProtectOD = $Protect1 -bor $Protect2 # Объединение в один enum: 1 + 2; -bxor удаление* > (1 -bor 2) -bxor 2

    # Если вызвана проверка указанного в пресете расположения для папки.
    if ( $CheckPreset )
    {
        $text = if ( $L.s5 ) { $L.s5 } else { 'Для проверки пресета можно указать только одну папку!' }
        if ( $Folders.Count -ne 1 ) { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return }  # Выход из функции.
        else { [string] $Folder = "$Folders" }

        [bool] $isCopy = $true
        [string] $PathFolder = ''

        # Берем заданный путь в пресете для указанной папки, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*User-Folder-$Folder\s*(=([\d\s]+))?=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)(=(?<Copy>[yn\s]+))?==" },'First') )
        {
            $PathFolder = "$($Matches.Path.Trim(' \/'))\"

            try { if ($Matches.Copy.Trim() -eq 'N' ) { $isCopy = $false } } catch {}
        }
        else {}

        [string] $isPath = ''

        # Если не под защитой OneDrive
        if ( -not ([System.Enum]::GetNames([ProtectOD]) -eq $Folder -and $ProtectOD.HasFlag([ProtectOD]$Folder) ))
        {
            # Проверка и исправление указанного в пресете пути, на всякий случай, если ошибка, то обнуление пути.
            # Задаем результат расположения, с параметрами цвета. Максимальное видимое количество символов у пути в меню будет = 47.
            if ( $PathFolder )
            {
                try
                {
                    # Раскрываем системные переменные, могут быть указаны в пути в пресете и получаем чистый полный путь с правильными разделителями.
                    $PathFolder = [System.Environment]::ExpandEnvironmentVariables($PathFolder)

                    if ( $PathFolder -like '?:\*' )
                    {
                        # нельзя передавать "?:", иначе добавляет текущую дирректорию, если диск пути отличается от диска текущей дирректории - подстава!
                        $PathFolder = [System.IO.Path]::GetFullPath($PathFolder)
                    }
                    else { $PathFolder = '' }
                }
                catch { $PathFolder = '' }

                # Если путь начинается на букву и двоеточие и имеет в конце \, и указанный диск существует в системе.
                if (( $PathFolder -match '^[a-z]:\\' ) -and ( [System.IO.DriveInfo]::GetDrives().Where({ $_.DriveType -eq 'Fixed' }).Name -like [System.IO.Path]::GetPathRoot($PathFolder) ))
                {
                    [string] $isPath = '{0}\{1}' -f $PathFolder.TrimEnd('\'), $Folder

                    if ( $isCopy ) { $Copy = '#DarkGray#| #Green#Y' } else { $Copy = '#DarkGray#| #Magen#N' }

                    [string] $isPathResult = "$isPath $Copy"

                    $isPathResult = '#White#{0}' -f $isPathResult.PadRight(67,' ')
                }
                else { [string] $isPathResult = '#Red#{0}#' -f $(if ( $L.s7 ) { $L.s7 } else { 'Путь неверный или не подходит!' }).PadRight(50,' ').Substring(0,50) }
            }
            else { [string] $isPathResult = '#Red#{0}#' -f $(if ( $L.s8 ) { $L.s8 } else { 'Путь неверный или не указан!' }).PadRight(50,' ').Substring(0,50) }
        }
        else { [string] $isPathResult = '#Red#{0}#' -f $(if ( $L.s8_1 ) { $L.s8_1 } else { 'Пропуск: Папка под защитой OneDrive' }).PadRight(50,' ').Substring(0,50) }

        if ( $CheckReturnOnlyValue ) { $isPath } else { $isPathResult }  # Вывод результата.

        Return  # Выход из функции
    }

    # Если указана проверка текущего расположения и состояния папки.
    if ( $CheckState )
    {
        $text = if ( $L.s9 ) { $L.s9 } else { 'Для проверки состояния можно указать только одну папку!' }
        if ( $Folders.Count -ne 1 ) { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return }  # Выход из функции.
        else { [string] $Folder = "$Folders" }

        # Родительский раздел реестра для настройки параметров для расположения папок.
        [string] $Key = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'

        [string] $FoundPath  = ''
        [string] $FolderType = ''

        [hashtable] $FolderDataPath = @{}

        [int] $maxL = 0 ; [int] $L = 0
        foreach ( $F in $FolderDataMap.Keys )
        {
            # Берем имя для параметра реестра для текущей папки из шаблона.
            $FolderType = $FolderDataMap[$F][0]

            # Получаем установленное в данный момент расположение в реестре для текущей папки.
            $FoundPath = [Microsoft.Win32.Registry]::GetValue("$Key\Shell Folders",$FolderType,'')
            if ( -not $FoundPath ) { $FoundPath = [Microsoft.Win32.Registry]::GetValue("$Key\User Shell Folders",$FolderType,'') }

            if ( $FoundPath.Length -gt $maxL ) { $maxL = $FoundPath.Length }

            $FolderDataPath[$F] = [PSCustomObject] @{
                Path   = $FoundPath
                Length = [int] $FoundPath.Length
            }
        }

        $FoundPath = $FolderDataPath[$Folder].Path

        [string] $DefaultPath     = '{0}\{1}' -f $env:USERPROFILE.TrimEnd('\'), $Folder
          [bool] $LocationChanged = $false

        # Создаем строку с цветовыми параметрами для вывода через функцию Write-HostColor, в зависимости от результата.
        if ( $FoundPath )
        {
            if ( $FoundPath -eq "$env:USERPROFILE\$Folder" )
            {
                [string] $isPath = "#Yellow#{0,-$maxL}#" -f $FoundPath
                [string] $def = '(Def)'
            }
            else
            {
                [string] $isPath =  "#Green#{0,-$maxL}#" -f $FoundPath
                [string] $def = '(---)'
                
                $LocationChanged = $true 
            }

            [psobject] $FoundPathInfo = Get-Item -LiteralPath FileSystem::$FoundPath -Force -ErrorAction SilentlyContinue

            # Проверка существования папки по найденому пути в реестре, и ее размера, если есть. Parent существует только если это не корень диска, а папка.
            if (( $FoundPathInfo.Attributes -like '*Directory*' ) -and ( -not $FoundPathInfo.LinkType ) -and ( $FoundPathInfo.Parent ))
            {
                [array] $Items = Get-ChildItem -LiteralPath \\?\$FoundPath -Recurse -Force -ErrorAction SilentlyContinue
                [int64] $FolderSize = ($Items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum

                # Если папка больше 300мб, то свободное место на диске расчитывается так,
                # чтобы после копирования на диске осталось не меньше 200мб свободного места, иначе будет пропуск копирования.
                if ( $FolderSize -lt 300mb ) { [int64] $NeedFreeSpace = $FolderSize }
                else { [int64] $NeedFreeSpace = $FolderSize + 200mb }

                if ( $Folder -eq 'Saved Games' ) { $Folder = 'SavedGames' }

                [string] $FolderPresetPath = Move-User-Folders -CheckPreset $Folder -CheckReturnOnlyValue

                # Получаем размер свободного пространства на диске, куда планируется перенести папку.
                try
                {
                    [string] $PathRoot = "$(([string][System.IO.Path]::GetPathRoot($FolderPresetPath)).Trim('\'))\"

                    [int64] $FreeSpace = [System.IO.DriveInfo]::GetDrives().Where({
                        $_.RootDirectory -like $PathRoot
                    }).AvailableFreeSpace
                }
                catch { [int64] $FreeSpace = -1 }

                if ( -not $FolderPresetPath )
                {
                    [string] $Attention = ' #DarkGray#| #Red#{0}#' -f $(if ( $L.s11 ) { $L.s11 } else { 'Пропуск изменения!' })
                }
                elseif (( $FreeSpace -le 0 ) -or ( $FreeSpace -lt $NeedFreeSpace ))
                {
                    [string] $Attention = " #DarkGray#| #Yellow#{0} #DarkGray#| {1}: $PathRoot | {2}: $NeedFreeSpace | {3}: $FreeSpace#" -f
                        $( if ( $L.s12 ) { $L.s12, $L.s12_1, $L.s12_2, $L.s12_3 }
                        else { 'Без Копирования!', 'Не хватает или мало осталось места на диске назначения', 'Нужно', 'Всего' })
                }

                if ( $FolderSize -gt 1gb )
                {
                    [string] $FolderSize = ( $FolderSize / 1gb ).ToString('N2')
                    [string] $Unit = '#DarkYellow#{0}#' -f $(if ( $L.s13_1 ) { $L.s13_1 } else { 'Гб' })
                    [string] $ColorSize = 'Yellow'
                }
                elseif ( $FolderSize -gt 1mb )
                {
                    [string] $FolderSize = ( $FolderSize / 1mb ).ToString('N2')
                    [string] $Unit = '#DarkGray#{0}#' -f $(if ( $L.s13_2 ) { $L.s13_2 } else { 'Мб' })
                    [string] $ColorSize = 'DarkMagenta'
                }
                else
                {
                    [string] $FolderSize = ( $FolderSize / 1kb ).ToString('N2')
                    [string] $Unit = '#DarkGray#{0}#' -f $(if ( $L.s13_3 ) { $L.s13_3 } else { 'Кб' })
                    [string] $ColorSize = 'DarkMagenta'
                }

                [string] $isFolder = "#DarkGray#| #Green#{0} #DarkGray#$def | $Unit#DarkGray#: #$ColorSize#{1,-6}$Attention" -f $(if ( $L.s13 ) { $L.s13 } else { 'Папка есть' }), $FolderSize
            }
            else { [string] $isFolder = '#DarkGray#| #Red#{0}#' -f $(if ( $L.s14 ) { $L.s14 } else { 'Папка не существует!' }) }
        }
        else
        {
            [string] $isPath = '#Red#{0}' -f $(if ( $L.s15 ) { $L.s15 } else { 'Путь не найден в реестре!' })
        }

        [string] $isSymLink = ''

        # Проверка существования символической ссылки в расположении По умолчанию, должна вести по новому пути после переноса папки.
        if ( $LocationChanged )
        {
            if ( [System.IO.Directory]::Exists($DefaultPath) )
            {
                [psobject] $FoundFolder = [System.IO.DirectoryInfo]::new($DefaultPath)

                if ( $FoundFolder.LinkType -eq 'SymbolicLink' )
                {
                    [string] $isTarget = $FoundFolder.Target

                    if ( $FoundPath -eq $isTarget ) { [string] $ColorTarget = 'White' ; [string] $Info = '' }
                    else { [string] $ColorTarget = 'Red' ; [string] $Info = ' #Red#| {0}' -f $(if ( $L.s16 ) { $L.s16 } else { 'Ссылка ведёт не туда!' }) }

                    $isSymLink = " #DarkGray#| #Blue#Link#DarkGray#: #$ColorTarget#$isTarget#$Info"
                }
                else { $isSymLink = ' #DarkGray#| {0}#' -f $(if ( $L.s17 ) { $L.s17 } else { 'Ссылка Не создана' }) }
            }
            else { $isSymLink = ' #DarkGray#| {0}#' -f $(if ( $L.s17 ) { $L.s17 } else { 'Ссылка Не создана' }) }
        }

        [string] $PathWarnings = $null

        # Если скрипт расположен в папке для переноса, будет отображено в меню, работает проверка только для скрипта.
        if ( $FoundPath -and $PSScriptRoot )
        {
            if ( $PSScriptRoot -like "$FoundPath*" )
            {
                $PathWarnings = " #DarkGray#| #Red#{0}: $PSScriptRoot#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Будет пропущено. Скрипт в папке для перемещения' })
            }
        }

        Return "$isPath $isFolder$PathWarnings$isSymLink"  # Выход из функции с выводом результата.
    }

    # Далее если выполнение действия ...

    $text = if ( $L.s1 ) { $L.s1 } else { 'Изменение расположения папок Пользователя' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction`n" -ForegroundColor DarkGray

    $text = if ( $L.s50 ) { $L.s50 } else { 'Функция ''Set-OwnerAndAccess'' не подгружена!' }
    # Проверка наличия функции Set-OwnerAndAccess, используется для настройки параметров безопасности через SDDL.
    if ( -not ( Get-Command -CommandType Function -Name 'Set-OwnerAndAccess' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.


    $text = if ( $L.s51 ) { $L.s51 } else { 'Функция ''ReStart-Explorer'' не подгружена!' }
    # Проверка наличия функции ReStart-Explorer, используется для корректной остановки и затем запуска проводника.
    if ( -not ( Get-Command -CommandType Function -Name 'ReStart-Explorer' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.

    # Проверка существования утилиты MS Handle.exe для получения блокирующих объект процессов,
    # необходимо для завершения этих процессов, чтобы была возможность удалить заблокированную папку.
    if ( -not [System.IO.File]::Exists($HandleExe) )
    { Write-Warning "  $NameThisFunction`: Not found Handle.Exe: $HandleExe" }


    # Функция SHSetKnownFolderPath (WinAPI C#) для корректного изменения пути для специальных папок KnownFolder в разделе реестра "Shell Folders" и "User Shell Folders".
    [string] $SetKnownFolderAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class SetKnownFolder
    {
        [DllImport( "shell32.dll", SetLastError = true )]
        public extern static int SHSetKnownFolderPath(
            Guid folderId, uint flags, IntPtr token, [MarshalAs(UnmanagedType.LPWStr)] string path
        );
    }
}
'@
    if ( -not ( 'WinAPI.SetKnownFolder' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $SetKnownFolderAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    # Код C# для обновления оболочки проводника.
    [string] $UpdateEnvExplorerAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class UpdateEnvExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport( "user32.dll", CharSet = CharSet.Auto, SetLastError = false )]
        private static extern IntPtr SendMessageTimeout(
            IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult
        );

        [DllImport( "user32.dll", CharSet = CharSet.Auto, SetLastError = false )]
        static extern bool SendNotifyMessage(
            IntPtr hWnd, uint Msg, IntPtr wParam, string lParam
        );

        [DllImport( "shell32.dll", CharSet = CharSet.Auto, SetLastError = false )]
        private static extern int SHChangeNotify(
            int eventId, int flags, IntPtr item1, IntPtr item2
        );

        public static void Refresh()
        {
            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
            // Update taskbar
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x0, IntPtr.Zero, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.UpdateEnvExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $UpdateEnvExplorerAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    Token-Impersonate -Reset

    # Профили
    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    [array] $Accs = [PSCustomObject] @{
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source
    }

    if ( $Global:DataAllUsers.Redirects.Value )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID -and $_.NTUSER_Load })).ForEach({

            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source
            }
        })
    }

    # Закрытие всех открытых окон Проводника, чтобы не блокировало папки.
    ReStart-Explorer -OnlyCloseWindows

    if ( @($Global:OpenedFolders).Count )
    {
        $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Все окна Explorer временно закрыты' }
        Write-Host "   $text" -ForegroundColor DarkGray
    }

   [psobject] $OpenRegKey  = $null
     [string] $UserProfile = ''

     [string] $NewDestFolder = ''
     [string] $PathFolder = ''
     [string] $FolderType = ''
     [string] $FoundPath  = ''
       [bool] $isCopy = $true

    foreach ( $Acc in $Accs )
    {
        $UserName    = $Acc.Name
        $UserProfile = $Acc.Profile

        if ( $Acc.Root -eq 'HKCU:' )
        {
            $RegRoot = [Microsoft.Win32.Registry]::CurrentUser
            $SubKey  = 'Software\Microsoft\Windows\CurrentVersion\Explorer'
        }
        else
        {
            $RegRoot = [Microsoft.Win32.Registry]::Users
            $SubKey  = "$($Acc.Root)\Software\Microsoft\Windows\CurrentVersion\Explorer"
        }

        # Параметры безопасности для настройки папок по стандарту, после изменения расположения,
        # с добавлением права на удаление самой папки только с правами администратора.
        [string] $UserSID = $Acc.SID
        # [string] $SDDL = "O:$UserSID`G:$UserSID`D:PAI(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;$UserSID)" # Параметры по дефолту.
        [string] $SDDL = "O:$UserSID`G:$UserSID`D:PAI(A;OICI;FA;;;SY)(A;OICIIO;FA;;;BA)(A;;0x1e01ff;;;BA)(A;;0x1e01ff;;;$UserSID)(A;OICIIO;FA;;;$UserSID)"

        $text = if ( $L.s20_1 ) { $L.s20_1 } else { 'Профиль' }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$UserName " -ForegroundColor White -NoNewline
        Write-Host "| $UserProfile | $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

        [ProtectOD] $Protect1 = 0
        [ProtectOD] $Protect2 = 0

        try { $Protect1 = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($Acc.SID)\SOFTWARE\Microsoft\OneDrive\Accounts\Personal", 'KfmFoldersProtectedNow',0) }
        catch {}
        try { $Protect2 = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($Acc.SID)\SOFTWARE\Microsoft\OneDrive\Accounts\Business1",'KfmFoldersProtectedNow',0) }
        catch {}

        [ProtectOD] $ProtectOD = $Protect1 -bor $Protect2 # Объединение в один enum

        # Выполнение действий для каждой указанной папки.
        foreach ( $Folder in $Folders ) {

            # Сброс переменных перед каждым действием.
            $NewDestFolder = ''
            $PathFolder = ''
            $FolderType = ''
            $FoundPath  = ''
            $isCopy = $true

            # Если под защитой OneDrive
            if ( [System.Enum]::GetNames([ProtectOD]) -eq $Folder -and $ProtectOD.HasFlag([ProtectOD]$Folder) )
            {
                $text = "`n   $NameThisFunction`: '$Folder' | {0}" -f $(if ( $L.s8_1 ) { $L.s8_1 } else { 'Пропуск: Папка под защитой OneDrive' })
                Write-Host "$text" -ForegroundColor Red

                Continue
            }

            # Берем заданный путь в пресете для указанной папки, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $ListPresetsGlobal.Where({ $_ -match "^\s*User-Folder-$Folder\s*(=([\d\s]+))?=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)(=(?<Copy>[yn\s]+))?==" },'First') )
            {
                $PathFolder = "$($Matches.Path.Trim(' \/'))\"

                try { if ($Matches.Copy.Trim() -eq 'N' ) { $isCopy = $false } } catch {}
            }
            else {}

            # Если восстановление по умолчанию, задаем расположение для папок в текущем расположении профиля.
            if ( $Default )
            {
                $text = if ( $L.s19 ) { $L.s19 } else { 'Восстанавливаем размещение ''По умолчанию'' для папки' }
                Write-Host "`n   $text`: '$Folder'" -ForegroundColor Cyan

                $PathFolder = '{0}\' -f $UserProfile.TrimEnd('\')
            }
            else
            {
                # Иначе берем заданный путь в пресете для обрабатываемой в данный момент папки.
                $text = if ( $L.s20 ) { $L.s20 } else { 'Изменяем расположение папки' }
                Write-Host "`n   $text`: '$Folder'" -ForegroundColor Cyan

                # Если путь не задан, пропускаем выполнение для этой папки.
                if ( -not $PathFolder )
                {
                    $text = "`n  $NameThisFunction`: {0} '$Folder'`n  {1}: '$FilePresets'" -f
                        $(if ( $L.s21 ) { $L.s21, $L.s21_1 } else { 'Не задан или неверный путь для', 'в файле пресетов' })
                    Write-Warning "$text"

                    Continue
                }
            }

            try
            {
                [string] $PathFolderForError = $PathFolder

                if ( $Acc.Root -ne 'HKCU:' )
                {
                    if ( $PathFolder -like '*%UserName%\' )
                    {
                        $PathFolder = $PathFolder -replace ('%UserName%',$UserName)
                    }
                    else
                    {
                        if ( -not $Default )
                        {
                            $text = if ( $L.s23_1 ) { $L.s23_1 } else { 'Для поддержки настройки других профилей указанный путь должен заканчиваться на переменную' }
                            Write-Host "   $text`: %UserName%" -ForegroundColor DarkYellow

                            $text = if ( $L.s23_2 ) { $L.s23_2 } else { 'Указанный Путь' }
                            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host $PathFolder -ForegroundColor DarkYellow

                            Continue
                        }
                    }
                }

                # Раскрываем системные переменные, могут быть указаны в пути в пресете и получаем чистый полный путь с правильными разделителями.
                $PathFolder = [System.Environment]::ExpandEnvironmentVariables($PathFolder)

                if ( $PathFolder -like '?:\*' )
                {
                    # нельзя передавать "?:", иначе добавляет текущую дирректорию, если диск пути отличается от диска текущей дирректории - подстава!
                    $PathFolder = [System.IO.Path]::GetFullPath($PathFolder)
                }
                else { $PathFolder = '' }
            }
            catch { $PathFolder = '' }

            # Проверка указанного в пресете пути, на всякий случай, если не подходит, то пропуск выполнения.
            # Путь должен начинаться на букву и двоеточие с \, и указанный локальный диск должен существовать в системе.
            if ( -not (( $PathFolder -match '^[a-z]:\\' ) -and ( [System.IO.DriveInfo]::GetDrives().Where({ $_.DriveType -eq 'Fixed' }).Name -like [System.IO.Path]::GetPathRoot($PathFolder) )))
            {
                $text = "`n  $NameThisFunction`: {0}: '$PathFolderForError'`n  {1}: '$FilePresets'" -f
                    $(if ( $L.s23 ) { $L.s23, $L.s22_1 } else { 'Путь неверный или не может быть создан', 'указан в файле пресетов' })
                Write-Warning "$text"

                Continue
            }

            # Берем имя для параметра реестра для текущей папки из шаблона.
            [string] $FolderType = $FolderDataMap[$Folder][0]
            [string] $FolderID   = $FolderDataMap[$Folder][1]

            try { $OpenRegKey = $RegRoot.OpenSubKey("$SubKey\Shell Folders", 'ReadSubTree','QueryValues') }
            catch { $OpenRegKey = $null }

            if ( $OpenRegKey )
            {
                # Получаем установленное в данный момент расположение в реестре для текущей папки.
                [string] $FoundPath = $OpenRegKey.GetValue($FolderType,$null,'DoNotExpandEnvironmentNames')

                $OpenRegKey.Close()

                # На всякий случай
                if ( $FoundPath -like '*%USERPROFILE%*' ) { $FoundPath = $FoundPath -replace('%USERPROFILE%',$UserProfile) }
                elseif ( $FoundPath -like '*%SystemDrive%*' ) { $FoundPath = $FoundPath -replace('%SystemDrive%',$env:SystemDrive) }
            }


            [bool] $NotFoundPath = $false

            if ( -not $FoundPath )
            {
                $NotFoundPath = $true

                $FoundPath =  '{0}\{1}' -f  $UserProfile.TrimEnd('\'), $Folder
            }

            # Если скрипт расположен в папке для переноса, пропуск действий с этой папкой, работает проверка только для скрипта.
            if ( $FoundPath -and $PSScriptRoot )
            {
                if ( $PSScriptRoot -like "$FoundPath*" )
                {
                    $text = "   {0}: '$FoundPath', {1}" -f $(if ( $L.s24 ) { $L.s24, $L.s24_1 } else { 'Скрипт расположен в папке для переноса', 'пропуск!' })
                    Write-Warning "$text"

                    Continue
                }
            }


            # Полный путь нового расположения
            $NewDestFolder = '{0}\{1}' -f $PathFolder.TrimEnd('\'), $Folder

            # Получение данных объекта по новому пути.
            [psobject] $PathFolderItemNew = Get-Item -LiteralPath FileSystem::$NewDestFolder -Force -ErrorAction SilentlyContinue

            # Если объект любая ссылка или не папка, удаляем его.
            if ( $PathFolderItemNew.Exists -and (( $PathFolderItemNew.LinkType ) -or ( -not $PathFolderItemNew.PSIsContainer ) ))
            {
                $text = if ( $L.s25 ) { $L.s25 } else { 'Удаляем ссылку или файл' }

                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "'$NewDestFolder'" -ForegroundColor DarkGray

                try { $PathFolderItemNew.Attributes = 'Normal' ; $PathFolderItemNew.Delete() }
                catch
                {
                    $text = if ( $L.s26 ) { $L.s26 } else { 'Невозможно удалить ссылку или файл' }
                    Write-Warning "`n  $NameThisFunction`: $text`: '$NewDestFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"

                    Continue
                }

                $PathFolderItemNew.Refresh()
            }

            # Если нет папки назначения, создаем и настраиваем правильные параметры безопасности.
            # Но если восстановление, просто создание папки, параметры безопасности унаследуются.
            if ( -not $PathFolderItemNew.Exists )
            {
                $text = if ( $L.s29 ) { $L.s29 } else { 'Создаём отсутствующую папку назначения' }

                Write-Host "   $text " -ForegroundColor Magenta -NoNewline
                Write-Host "'$NewDestFolder'" -ForegroundColor White

                try { New-Item -ItemType Directory -Path $NewDestFolder -Force -ErrorAction Stop > $null }
                catch
                {
                    $text = if ( $L.s28 ) { $L.s28 } else { 'Невозможно переместить папку в' }
                    Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"

                    Continue
                }
            }

            # Если не восстановление, то настройка правильных параметров безопасности.
            if ( -not $Default )
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Настраиваем права доступа' }

                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                Write-Host "'$NewDestFolder'" -ForegroundColor White

                Set-OwnerAndAccess -Path $NewDestFolder -RecoverySDDL $SDDL
            }

            # Если нет desktop.ini файла, создание оригинального по шаблону.
            if ( -not ( [System.IO.File]::Exists("$NewDestFolder\desktop.ini") ))
            {
                $text = if ( $L.s31 ) { $L.s31 } else { 'Создаём отсутствующий INI файл' }

                Write-Host "   $text " -ForegroundColor Magenta -NoNewline
                Write-Host "'$NewDestFolder\desktop.ini'" -ForegroundColor White

                try { Out-File -InputObject $FolderINIMap[$Folder] -LiteralPath "$NewDestFolder\desktop.ini" -Encoding unicode -Force -ErrorAction Stop }
                catch
                {
                    Write-Warning "`n  $NameThisFunction`: Out-File: '$NewDestFolder\desktop.ini'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                }
            }

            Start-Sleep -Milliseconds 200

            Write-Host "   $(if ( $L.s32 ) { $L.s32 } else { 'Настройка атрибутов' }) " -ForegroundColor Magenta  -NoNewline
            Write-Host "$(if ( $L.s32_1 ) { $L.s32_1 } else { 'у' }) "                  -ForegroundColor DarkGray -NoNewline
            Write-Host "'$NewDestFolder' "                                              -ForegroundColor White    -NoNewline
            Write-Host "$(if ( $L.s32_2 ) { $L.s32_2 } else { 'и' }) "                  -ForegroundColor DarkGray -NoNewline
            Write-Host 'desktop.ini'                                                    -ForegroundColor White

            (Get-Item -LiteralPath $NewDestFolder -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'

            [psobject] $IniItem = Get-Item -LiteralPath "$NewDestFolder\desktop.ini" -Force -ErrorAction SilentlyContinue

            if ( $IniItem.Exists )
            {
                $IniItem.Attributes = 'Hidden', 'System', 'Archive'
                $IniItem.Refresh()

                if ( $IniItem.Attributes -like 'Hidden, System, Archive' )
                {
                    $text = if ( $L.s33 ) { $L.s33 } else { 'Настройка атрибутов INI файла' }
                    Write-Host "   $text " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'завершена' }
                    Write-Host "$text" -ForegroundColor Green
                }
            }

            # Если текущий путь был найден в реестре
            if ( -not $NotFoundPath )
            {
                # Если полученный путь равен уже установленному, пропуск дальнейших действий для текущей папки.
                if ( $NewDestFolder -eq $FoundPath )
                {
                    $text = if ( $L.s34 ) { $L.s34 } else { 'Папка в реестре уже настроена на' }
                    Write-Host "   $text '$NewDestFolder'" -ForegroundColor Green

                    # Если не восстановление По умолчанию, создание символчической ссылки в расположении по Умолчанию.
                    if ( -not $Default )
                    {
                        [string] $DefaultPath = "$UserProfile\$Folder"

                        # Получения данных объекта по пути По умолчанию.
                        [psobject] $DefaultPathItem = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

                        # Если объект любая ссылка или не папка, удаляем его.
                        if ( $DefaultPathItem.Exists -and (( $DefaultPathItem.LinkType ) -or ( -not $DefaultPathItem.PSIsContainer ) ))
                        {
                            $text = if ( $L.s25 ) { $L.s25 } else { 'Удаляем ссылку или файл' }
                            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "'$DefaultPath'" -ForegroundColor DarkGray

                            try { $DefaultPathItem.Attributes = 'Normal' ; $DefaultPathItem.Delete() } catch {}
                            $DefaultPathItem.Refresh()
                        }

                        if ( -not $DefaultPathItem.Exists )
                        {
                            $text = if ( $L.s35 ) { $L.s35 } else { 'Создание символической ссылки' }
                            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                            $text = if ( $L.s35_1 ) { $L.s35_1 } else { 'вместо' }
                            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "'$UserProfile\$Folder'" -ForegroundColor White

                            Token-Impersonate -Reset

                            New-Item -ItemType SymbolicLink -Path $DefaultPath -Value $NewDestFolder -Force > $null

                            if ( [System.IO.Directory]::Exists($DefaultPath) )
                            {
                                (Get-Item -LiteralPath $DefaultPath -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                            }
                            else
                            {
                                Write-Host '   Error: No SymbolicLink' -ForegroundColor Red
                            }
                        }
                        else
                        {
                            $text = if ( $L.s36 ) { $L.s36 } else { 'Папка существует в расположении по умолчанию, ссылка не будет создана' }
                            Write-Host "   $text" -ForegroundColor DarkGray
                        }
                    }

                    Continue
                }
            }

            # Далее, если все соответствует и было подготовлено к смене расположения ...

            # Если текущий аккаунт, иначе подключённый реестр
            if ( $Acc.Root -eq 'HKCU:' )
            {
                $text = if ( $L.s37 ) { $L.s37 } else { 'Изменяем расположение папки в реестре и через WinAPI' }
            }
            else
            {
                $text = if ( $L.s37_1 ) { $L.s37_1 } else { 'Изменяем расположение папки только в реестре' }
            }

            Write-Host "   $text" -ForegroundColor Magenta

            # Настройка непосредственно в реестре, помогает настроить, когда нет параметров в реестре, WinAPI в этом случае не срабатывает полностью.
            if ( $Default )
            {
                try { $OpenRegKey = $RegRoot.CreateSubKey("$SubKey\Shell Folders") } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    try { $OpenRegKey.SetValue($FolderType,$NewDestFolder,'String') } catch {}
                    $OpenRegKey.Close()
                }

                try { $OpenRegKey = $RegRoot.CreateSubKey("$SubKey\User Shell Folders") } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    try { $OpenRegKey.DeleteValue($FolderID,$false) } catch {}
                    try { $OpenRegKey.SetValue($FolderType,"%USERPROFILE%\$Folder",'ExpandString') } catch {}
                    $OpenRegKey.Close()
                }
            }
            else
            {
                try { $OpenRegKey = $RegRoot.CreateSubKey("$SubKey\Shell Folders") } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    try { $OpenRegKey.SetValue($FolderType,$NewDestFolder,'String') } catch {}
                    $OpenRegKey.Close()
                }

                try { $OpenRegKey = $RegRoot.CreateSubKey("$SubKey\User Shell Folders") } catch { $OpenRegKey = $null }

                if ( $OpenRegKey )
                {
                    try { $OpenRegKey.SetValue($FolderType,$NewDestFolder,'ExpandString') } catch {}
                    try { $OpenRegKey.SetValue($FolderID,  $NewDestFolder,'ExpandString') } catch {}
                    $OpenRegKey.Close()
                }
            }

            # Если текущий аккаунт, дополнительно использовать WinAPI
            if ( $Acc.Root -eq 'HKCU:' )
            {
                # Установка значений в разделе реестра "Shell Folders" и "User Shell Folders" через WinAPI,
                # эти изменения видит Проводник без перезапуска, после обновления его оболочки.
                foreach ( $Guid in $KnownFoldersMap[$Folder] )
                {
                    [WinAPI.SetKnownFolder]::SHSetKnownFolderPath($Guid, 0, 0, $NewDestFolder) > $null
                }

                Start-Sleep -Milliseconds 200

                # Если запуск не из меню быстрых настроек
                if ( -not $MenuConfigsQuickSettings )
                {
                    # Обновление оболочки Проводника.
                    [WinAPI.UpdateEnvExplorer]::Refresh()
                }
            }

              [string] $DefaultPath   = '{0}\{1}' -f $UserProfile.TrimEnd('\'), $Folder
                [bool] $NotCopied     = $false
                [bool] $SkipCopy      = $false
                [bool] $NoDefaultPath = $false
            [string[]] $CopyPaths     = $FoundPath
            [string[]] $ErrCode       = @()

            # Если не восстановление по умолчанию и указанный путь не является путем по умолчанию
            if ( -not $Default -and ( $FoundPath -ne $DefaultPath ))
            {
                # Получения данных объекта
                [psobject] $Item = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

                # Если исходная папка существует и она не сим ссылка, добавляем ее к папкам для копирования в первую очередь,
                # так как там могут быть устаревшые файлы, относительно файлов в текущем назначенном расположении
                if ( $Item.PSIsContainer -and ( -not $Item.LinkType ))
                {
                    $CopyPaths = $DefaultPath, $FoundPath
                }
            }

            if ( $FoundPath -eq $NewDestFolder ) { $CopyPaths = @() }

            [int64] $FolderSize = 0

            # Проверка размера всех папок для копирования и сравнивание со свободным местом на диске назначения
            foreach ( $Path in $CopyPaths )
            {
                # Получения данных объекта найденного пути.
                [psobject] $PathItem = Get-Item -LiteralPath FileSystem::$Path -Force -ErrorAction SilentlyContinue

                # Если исходная папка существует. Parent существует только если это не корень диска, а папка.
                if ( $PathItem.PSIsContainer -and ( -not $PathItem.LinkType ) -and ( $PathItem.Parent ))
                {
                    # Получаем размер исходной папки для переноса, для получения необходимого места на диске перед копированием.
                    [array] $Items = Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue
                    # Добавляем размер к общему размеру для копирования
                    $FolderSize += ($Items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum

                    # Если папка больше 300мб, то свободное место на диске расчитывается так,
                    # чтобы после копирования на диске осталось не меньше 200мб свободного места, иначе будет пропуск копирования.
                    if ( $FolderSize -lt 300mb ) { [int64] $NeedFreeSpace = $FolderSize }
                    else { [int64] $NeedFreeSpace = $FolderSize + 200mb }

                    # Получаем размер свободного пространства на диске, куда планируется перенести папку.
                    try
                    {
                        [string] $PathRoot = "$(([string][System.IO.Path]::GetPathRoot($PathFolder)).Trim('\'))\"

                        # Получаем свободное место на диске из пути для переноса папки.
                        [int64] $FreeSpace = [System.IO.DriveInfo]::GetDrives().Where({
                            $_.RootDirectory -like $PathRoot
                        }).AvailableFreeSpace
                    }
                    catch { [int64] $FreeSpace = -1 }

                    if (( $FreeSpace -le 0 ) -or ( $FreeSpace -lt $NeedFreeSpace ))
                    {
                        Write-Host -ForegroundColor Yellow $("   {0}: '$Path', {1}: $PathRoot" -f $(if ( $L.s38 ) { $L.s38, $L.s38_1 } else { 'Пропуск копирования файлов из', 'Не хватает или мало осталось места на диске назначения' }))
                        Write-Host -ForegroundColor Yellow $("   {0}: '$FreeSpace' {1}"        -f $(if ( $L.s39 ) { $L.s39, $L.s39_1 } else { '  Свободное место на диске', 'байт' }))
                        Write-Host -ForegroundColor Yellow $("   {0}: '$NeedFreeSpace' {1}"    -f $(if ( $L.s40 ) { $L.s39, $L.s39_1 } else { 'Необходимое место на диске', 'байт' }))

                        # Continue
                        # Размер для копирования превышает объём свободного места у диска назначения
                        $SkipCopy = $true
                    }
                }
                else
                {
                    # Иначе папки нет, и если этот путь равен папке по умолчанию, указать, что папки по умолчанию нет
                    if ( $Path -eq $DefaultPath ) { $NoDefaultPath = $true }
                }
            }

            # Если не хватает свободного места для копирования, пропустить вообще дальнейшие действия
            if ( $SkipCopy ) { Continue }

            # Если папка по умолчанию не существует
            if ( $NoDefaultPath )
            {
                $text = "   {0}: '$FoundPath', {1}" -f $(if ( $L.s41 ) { $L.s41, $L.s41_1 } else { 'Исходная папка не существует', 'копировать нечего' })
                Write-Host "   $text" -ForegroundColor DarkGray

                # Если не восстановление По умолчанию, создание символчической ссылки в расположении по Умолчанию.
                if ( -not $Default )
                {
                    [string] $DefaultPath = "$UserProfile\$Folder"

                    # Получения данных объекта по пути По умолчанию.
                    [psobject] $DefaultPathItem = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

                    # Если объект любая ссылка или файл, удаляем его.
                    if (( $DefaultPathItem.Exists ) -and (( $DefaultPathItem.LinkType ) -or ( -not $DefaultPathItem.PSIsContainer )))
                    {
                        $text = if ( $L.s25 ) { $L.s25 } else { 'Удаляем ссылку или файл' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "'$DefaultPath'" -ForegroundColor DarkGray

                        try { $DefaultPathItem.Attributes = 'Normal' ; $DefaultPathItem.Delete() } catch {}
                        $DefaultPathItem.Refresh()
                    }

                    if ( -not $DefaultPathItem.Exists )
                    {
                        $text = if ( $L.s35 ) { $L.s35 } else { 'Создание символической ссылки' }
                        Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                        $text = if ( $L.s35_1 ) { $L.s35_1 } else { 'вместо' }
                        Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "'$DefaultPath'" -ForegroundColor White

                        Token-Impersonate -Reset

                        New-Item -ItemType SymbolicLink -Path $DefaultPath -Value $NewDestFolder -Force > $null

                        if ( [System.IO.Directory]::Exists($DefaultPath) )
                        {
                            (Get-Item -LiteralPath $DefaultPath -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                        }
                        else
                        {
                            Write-Host '   Error: No SymbolicLink' -ForegroundColor Red
                        }
                    }
                    else
                    {
                        $text = if ( $L.s36 ) { $L.s36 } else { 'Папка существует в расположении по умолчанию, ссылка не будет создана' }
                        Write-Host "   $text" -ForegroundColor DarkGray
                    }
                }

                Continue
            }

            if ( -not $isCopy )
            {
                $text = if ( $L.s38_2 ) { $L.s38_2 } else { 'Копирование запрещено' }
                Write-Host "   $text" -ForegroundColor DarkCyan

                Continue
            }


            # Далее, если можно выполнять копирование в новое расположение ...

            ReStart-Explorer -OnlyCloseWindows

            # Копируем со всех папок в место назначения
            foreach ( $Path in $CopyPaths )
            {
                # Удаление всех системных junction link перед копированием (у всех папок на всякий случай), чтобы исключить баг:
                # Удаление проводником файлов desktop.ini из папок Видео, Музыка, Изображения при скрытии папок из проводника после переноса папки Мои документы!
                Get-ChildItem -LiteralPath \\?\$Path -Force -Directory -Attributes ReparsePoint -ErrorAction SilentlyContinue |
                    Where-Object { $_.Attributes -like '*System, Directory, ReparsePoint*' } |
                        ForEach-Object {

                            Write-Host '   Delete junction link: ' -ForegroundColor DarkCyan -NoNewline
                            Write-Host "$($_.FullName.Replace('\\?\','')) " -ForegroundColor DarkGray

                            try { $_.Attributes = 'Normal' } catch {}
                            try { $_.Delete() } catch {}
                        }

                # Копируем файлы в новое расположение, и если не будет критичных ошибок, удаление исходной папки.
                Write-Host "   $(if ( $L.s42 ) { $L.s42 } else { 'Robocopy: Копируем файлы' }) " -ForegroundColor Magenta  -NoNewline
                Write-Host "$(if ( $L.s42_1 ) { $L.s42_1 } else { 'из' }) "                      -ForegroundColor DarkGray -NoNewline
                Write-Host "'$Path' "                                                            -ForegroundColor White    -NoNewline
                Write-Host "$(if ( $L.s42_2 ) { $L.s42_2 } else { 'в' }) "                       -ForegroundColor DarkGray -NoNewline
                Write-Host "'$NewDestFolder'"                                               -ForegroundColor Green    -NoNewline
                Write-Host ", $(if ( $L.s42_3 ) { $L.s42_3 } else { 'ждите ...' })"              -ForegroundColor DarkGray

                $Global:LastExitCode = $null
                # Параметры Копирования: все сведения о файле; вложенные папки, включая пустые; Данные, Атрибуты, Метки времени для папок и фйлов;
                # пропуск символических ссылок и др. точек соединения внутри источника; 2 попытки скопировать объект при ошибке.
                # Только Нельзя допускать указание ссылки как источника, в этом сценарии это учтено!
                robocopy.exe "$Path" "$NewDestFolder" /E /COPY:DATSOU /DCOPY:DAT /XJ /R:2 /W:2 > $null

                # Если была любая ошибка копирования, указать, что не скопировалось
                if ( $Global:LastExitCode -ge 8 ) { $NotCopied = $true ; $ErrCode += $Global:LastExitCode }
            }

            # Если была любая ошибка копирования, то не удалять папки
            if ( $NotCopied )
            {
                $text = "   {0}: '$($ErrCode -join ', ')',`n   {1}" -f
                    $(if ( $L.s43 ) { $L.s43, $L.s43_1 } else { 'Проблема при копировании, код ошибки','исходная папка не будет удалена!' })

                Write-Host "$text" -ForegroundColor Magenta
            }
            else
            {
                Token-Privileges -Enable4Privileges
                
                # Раз всё было скопировано без ошибок, то удалить все исходные папки, завершая процессы мешающие это сделать.
                foreach ( $Path in $CopyPaths )
                {
                    $text = if ( $L.s44 ) { $L.s44 } else { 'Скопировано без ошибок. Удаление исходной папки' }
                    Write-Host "   $text`: '$Path'" -ForegroundColor DarkGray

                    Token-Impersonate -Token SYS

                    # Удаление папки через cmd: быстрее, удаляет с любыми типами/параметрами объектов, остальное доделает код ниже, если что.
                    $StartInfo = [System.Diagnostics.ProcessStartInfo]::new("$env:windir\system32\cmd.exe")
                    $StartInfo.WindowStyle = 'Hidden'
                    $StartInfo.CreateNoWindow = $true
                    $StartInfo.UseShellExecute = $false
                    $StartInfo.Arguments = '/d /q /c "rmdir /s /q ""\\?\{0}"""' -f $Path
                    try { $P = [System.Diagnostics.Process]::Start($StartInfo) ; $P.WaitForExit() ; $P.Close() } catch {}

                    @(Get-Item -LiteralPath \\?\$Path -Force -ErrorAction SilentlyContinue).ForEach({ $_.Attributes = 'Normal' })

                    # Поиск удаление всех ссылок в папке, так как Remove-Item их не может удалить, а $_.Delete($true) не может при атрибуте "Только чтение"

                    # удаление всех символических ссылок на папки, чтобы внутрь не заходило
                    Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                        if ( $_.LinkType -eq 'SymbolicLink' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} }
                    }

                    # Получить все объекты
                    $Items = Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue

                    # удаление всех файлов любых, включая NTFS Reparse points (Точки повторной обработки)
                    $Items | ForEach-Object { if ( $_.Attributes -notlike '*Directory*' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }

                    # удаление всех папок, включая NTFS Reparse points (Точки повторной обработки)
                    $Items | ForEach-Object { if ( $_.Attributes -like '*Directory*'    ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }

                    # удаление последней папки с рекурсией
                    try { Remove-Item -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue } catch {}

                    # ещё попытка удаления последней папки, так как Remove-Item не может удалять ReparsePoint
                    $Item = Get-Item \\?\$Path -ErrorAction SilentlyContinue
                    if ( $Item.Exists ) { try { $Item.Attributes = 'Normal' ; $Item.Delete() } catch {} }

                    Start-Sleep -Milliseconds 500

                    if ( [System.IO.Directory]::Exists($Path) )
                    {
                        $text = if ( $L.s45 ) { $L.s45 } else { 'Папка заблокирована. Завершаем корректно процесс' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "Explorer.exe" -ForegroundColor White

                        ReStart-Explorer -Stop

                        $text = if ( $L.s46 ) { $L.s46 } else { 'Повторная попытка удаления папки' }
                        Write-Host "   $text`: '$Path'" -ForegroundColor DarkGray

                        [int] $N = 0

                        do
                        {
                            $N++

                            # Получаем список процессов, которые используют данную папку.
                            $FolderHandles = $null
                            try { $FolderHandles = (& $HandleExe -AcceptEula $Path).Where({ $_ -match '[.]exe' }) } catch { $FolderHandles = $null }

                            if ( $FolderHandles )
                            {
                                [hashtable] $FoundPocess = @{}

                                # Добавляем все процессы в таблицу, перезаписывая повторные ID.
                                foreach ( $Handle in $FolderHandles )
                                {
                                    if ( $Handle -match '(^.+[.]exe)\s+pid:\s+([\d]+)' ) { $FoundPocess[$Matches[2]] = $Matches[1] }
                                }

                                # Для всех уникальных ID выполнение принудительного завершения работы.
                                foreach ( $ProcessPID in $FoundPocess.Keys )
                                {
                                    $text = if ( $L.s47_1 ) { $L.s47_1 } else { 'Завершаем процесс' }
                                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                                    Write-Host "$($FoundPocess[$ProcessPID])" -ForegroundColor White -NoNewline
                                    Write-Host '; PID: ' -ForegroundColor DarkGray -NoNewline
                                    Write-Host "$ProcessPID" -ForegroundColor Magenta

                                    try { (Get-Process -Id $ProcessPID -ErrorAction SilentlyContinue).Kill() } catch {}
                                }
                            }
                        }
                        until (( -not $FolderHandles ) -or ( $N -ge 10 ))

                        # удаление всех символических ссылок на папки, чтобы внутрь не заходило
                        Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                            if ( $_.LinkType -eq 'SymbolicLink' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} }
                        }

                        # Получаем полный доступ на папку со всеми файлами и папками.
                        Set-OwnerAndAccess -Path $Path -SetFullAccess -Recurse

                        # Получить все объекты
                        $Items = Get-ChildItem -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue

                        # удаление всех файлов любых, включая NTFS Reparse points (Точки повторной обработки)
                        $Items | ForEach-Object { if ( $_.Attributes -notlike '*Directory*' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }

                        # удаление всех папок, включая NTFS Reparse points (Точки повторной обработки)
                        $Items | ForEach-Object { if ( $_.Attributes -like '*Directory*'    ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }

                        # удаление последней папки с рекурсией
                        try { Remove-Item -LiteralPath \\?\$Path -Recurse -Force -ErrorAction SilentlyContinue } catch {}

                        # ещё попытка удаления последней папки, так как Remove-Item не может удалять ReparsePoint
                        $Item = Get-Item \\?\$Path -ErrorAction SilentlyContinue
                        if ( $Item.Exists ) { try { $Item.Attributes = 'Normal' ; $Item.Delete() } catch {} }

                        $text = if ( $L.s47 ) { $L.s47 } else { 'Запускаем процесс' }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host 'Explorer.exe' -ForegroundColor White

                        Token-Impersonate -Reset

                        ReStart-Explorer -DoNotOpenWindows
                    }

                    Token-Impersonate -Reset
                }

                foreach ( $Path in $CopyPaths )
                {
                    if ( [System.IO.Directory]::Exists($Path) )
                    {
                        $text = if ( $L.s48 ) { $L.s48 } else { 'Удалить исходную папку не удалось' }
                        Write-Host "   $text`: '$Path'" -ForegroundColor Yellow
                    }
                }

                # Если не восстановление По умолчанию, создание символчической ссылки в расположении по Умолчанию.
                if ( -not $Default )
                {
                    [string] $DefaultPath = '{0}\{1}' -f  $UserProfile.TrimEnd('\'), $Folder

                    # Получения данных объекта по пути По умолчанию.
                    [psobject] $DefaultPathItem = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

                    # Если это не папка, а симлинк, файл, или нет ни чего
                    if ( -not ( $DefaultPathItem.PSIsContainer -and -not $DefaultPathItem.LinkType ))
                    {
                        # Если объект любая ссылка или файл, удаляем его.
                        if ( $DefaultPathItem.Exists )
                        {
                            $text = if ( $L.s25 ) { $L.s25 } else { 'Удаляем ссылку или файл' }
                            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "'$DefaultPath'" -ForegroundColor DarkGray

                            try { $DefaultPathItem.Attributes = 'Normal' ; $DefaultPathItem.Delete() } catch {}
                            $DefaultPathItem.Refresh()
                        }

                        if ( -not $DefaultPathItem.Exists )
                        {
                            $text = if ( $L.s35 ) { $L.s35 } else { 'Создание символической ссылки' }
                            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                            $text = if ( $L.s35_1 ) { $L.s35_1 } else { 'вместо' }
                            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "'$DefaultPath'" -ForegroundColor White

                            Token-Impersonate -Reset

                            New-Item -ItemType SymbolicLink -Path $DefaultPath -Value $NewDestFolder -Force > $null

                            if ( [System.IO.Directory]::Exists($DefaultPath) )
                            {
                                (Get-Item -LiteralPath $DefaultPath -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                            }
                            else
                            {
                                Write-Host '   Error: No SymbolicLink' -ForegroundColor Red
                            }
                        }
                        else
                        {
                            $text = if ( $L.s26 ) { $L.s26 } else { 'Не получилось удалить ссылку или файл' }
                            Write-Host "   $text" -ForegroundColor DarkYellow
                        }
                    }
                    else
                    {
                        $text = if ( $L.s36 ) { $L.s36 } else { 'Папка существует в расположении по умолчанию, ссылка не будет создана' }
                        Write-Host "   $text" -ForegroundColor DarkYellow
                    }
                }

                Token-Impersonate -Reset
            }

            # Пересоздание оригинального desktop.ini для текущей папки, на всякий случай, после копирования, сохраняя локализованные строки внутри файла.

            $text = if ( $L.s49 ) { $L.s49 } else { 'Пересоздание файла desktop.ini и настройка атрибутов после копирования' }
            Write-Host "   $text" -ForegroundColor DarkGray

            [string[]] $ini = @()

            try
            {
                [string] $FileINI = "$NewDestFolder\desktop.ini"

                (Get-Item -LiteralPath $FileINI -Force -ErrorAction SilentlyContinue).Attributes = 'Archive'

                [string[]] $Content = Get-Content -LiteralPath \\?\$FileINI -Encoding Unicode -Delimiter '\n' -Force -ErrorAction SilentlyContinue

                if ( $Content.Count ) { Write-Host "   Get-Content: $true " -ForegroundColor DarkGray   }
                else                  { Write-Host "   Get-Content: $false" -ForegroundColor DarkYellow }

                # Получение строк для локализации названий ярлыков для восстановления этих строк при пересоздании файла, если такие строки есть.
                [string] $ini = [regex]::Matches($Content,'\[LocalizedFileNames\]\s*(?<LnkLang>[^\f]+)','IgnorePatternWhitespace').Groups.Where({$_.Name -eq 'LnkLang'}).Value

                [int] $N = 0

                do
                {
                    $N++
                    Remove-Item -LiteralPath \\?\$FileINI -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Milliseconds 100
                }
                until (( -not [System.IO.File]::Exists($FileINI) ) -or ( $N -ge 10 ))
            }
            catch {}

            if ( [System.IO.File]::Exists($FileINI) ) { Write-Host "   Remove-Item: $false" -ForegroundColor DarkYellow }
            else                                      { Write-Host "   Remove-Item: $true " -ForegroundColor DarkGray   }

            if ( $ini )
            {
                Write-Host "   LocalizedFileNames: $true " -ForegroundColor DarkGray

                [string[]] $FileContent = $FolderINIMap[$Folder] + '[LocalizedFileNames]' + ($ini.Split("`n`r").Where({$_ -like '*=@*'}))
            }
            else
            {
                Write-Host "   LocalizedFileNames: $false" -ForegroundColor DarkGray

                [string[]] $FileContent = $FolderINIMap[$Folder]
            }

            try
            {
                [int] $N = 0

                do
                {
                    $N++
                    Out-File -InputObject $FileContent -LiteralPath $FileINI -Encoding unicode -Force -ErrorAction SilentlyContinue
                    Start-Sleep -Milliseconds 100
                }
                until (( [System.IO.File]::Exists($FileINI) ) -or ( $N -ge 10 ))
            }
            catch
            {
                Write-Warning "`n  $NameThisFunction`: Out-File: '$FileINI'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
            }

            [psobject] $IniItem = Get-Item -LiteralPath $FileINI -Force -ErrorAction SilentlyContinue

            if ( $IniItem.Exists )
            {
                $IniItem.Attributes = 'Hidden', 'System', 'Archive'
                $IniItem.Refresh()

                if ( $IniItem.Attributes -like 'Hidden, System, Archive' )
                {
                    $text = if ( $L.s33 ) { $L.s33 } else { 'Настройка атрибутов INI файла' }
                    Write-Host "   $text " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'завершена' }
                    Write-Host "$text" -ForegroundColor Green
                }
            }
            else
            {
                Write-Host "   Error. Not Exist: $FileINI" -ForegroundColor Yellow
            }

            $text = if ( $L.s4 ) { $L.s4 } else { 'Выполнено' }
            Write-Host "   $text" -ForegroundColor Green
        }
    }

    Start-Sleep -Milliseconds 300

    # Открыть закрытые окна обратно, если не были ещё открыты (запускает оболочку проводника (трей/рабстол), если не запущена)
    ReStart-Explorer -OnlyOpenWindows

    Get-Pause
}
