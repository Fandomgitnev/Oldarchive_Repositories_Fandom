﻿
<#
.SYNOPSIS
 Установка win32 калькулятора (Классического) x64/x86

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 
 Используется внешняя функция Token-Impersonate
 Используется внешняя функция Token-Privileges
 Используется внешняя функция Set-Reg
 Используется глобальная переменная с данными на все аккаунты $Global:DataAllUsers
 Используется 7zip
 Используется архив с файлами калькулятора ~600кб

 Файлы калькулятора из Windows 10 LTSB 2016 (14621)
 Хоткеи работают и при установленном UWP калькуляторе. можно удалить и будет как было до.
 Все языки mui.
 Создается ярлык в папке Программы для пуска, для всех пользователй.
 С записями локализованной строки в desktop.ini, если не существует записи. Проставляются атрибуты.
 Если нет папки, будет пропуск такой папки. Специально не сделано создание.

 Устанавливается/Удаляется только если нет встроенного в Windows
 Устанавливается в \Program Files\Win32calc\... намеренно, можно было сделать и для системной папки.

.EXAMPLE
 Install-Win32-Calculator -Act Set

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  20.04.2023
 ===============================================

#>
Function Install-Win32-Calculator {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [Parameter( Mandatory = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act = 'Set'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Check' )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { 'Проверка' }
    }
    elseif ( $Act -eq 'Set' )
    {
        $text = if ( $L.s1_1 ) { $L.s1_1 } else { 'Установка' }
    }
    else
    {
        $text = if ( $L.s1_2 ) { $L.s1_2 } else { 'Удаление' }
    }

    Write-Host "   $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s2 ) { $L.s2 } else { 'win32 Калькулятор' }
    Write-Host "| $text " -ForegroundColor DarkCyan -NoNewline

    $text = if ( $L.s2_1 ) { $L.s2_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    [string] $Archive = "$FileFolderGlobal\win32calc.7z"

    if (( -not $7z ) -or ( -not [System.IO.File]::Exists($Archive) )) { Write-Host "   No 7z.exe or $Archive" -ForegroundColor Red ; Return }

    [bool] $isCalc = $true
    try { if ( -not @([System.IO.Directory]::EnumerateFiles("$env:windir\System32\CatRoot\{F750E6C3-38EE-11D1-85E5-00C04FC295EE}",'*win32calc*.cat')).Length ) { $isCalc = $false } } catch {}

    if ( $isCalc )
    {
        $text = if ( $L.s3 ) { $L.s3 } else { 'Win32calc уже встроен в Windows' }
        Write-Host "`n   $text" -ForegroundColor DarkGray
            
        Return
    }
   
    <# Не понадобилось
    # Профили
    [array] $Accs = @()

    @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' -and $_.SID },'First')).ForEach({  # $_.Use -and 

        $Accs = [PSCustomObject] @{
            Name     = $_.Name
            FullName = '{0}\{1}' -f $env:USERDOMAIN, $_.Name
            Root     = 'Registry::HKU\{0}' -f $_.SID
            Profile  = $_.Profile
            SID      = $_.SID
            Source   = 'Local'
        }
    })

    Token-Impersonate -Reset

    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    $Accs += [PSCustomObject] @{
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source
    }

    #if ( $Global:DataAllUsers.Redirects.Value )  # для всех в любом случае
    #{
        @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID })).ForEach({  # $_.Use -and 

            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source
            }
        })
    #}
    #>

    [string] $InstallDir = "$env:ProgramFiles\Win32calc"

    if ( [System.Environment]::Is64BitOperatingSystem ) { $ExclArch = 'x86' } else { $ExclArch = 'x64' }

    Function Insert-Localized-To-DesktopIni ( [string[]] $ContentIni, [array] $Localized, [switch] $PreserveNonData = $true )
    {
        [System.Collections.Specialized.OrderedDictionary] $ini = [ordered]@{}
        [int] $CommentCount = 0

        # Первая нулевая секция, в неё добавляются пустые строки для начального отступа, если его нет
        $section = 'NO_SECTION'
        $ini[$section] = [ordered]@{}

        switch -regex ($ContentIni)
        {    
            '^\s*\[(.+)\]\s*$'
            {
                $section = $matches[1].Trim()
                $ini[$section] = [ordered]@{}
            }

            '^\s*(.+?)\s*=\s*(.*)' 
            {
                $name,$value = $matches[1..2]
                $ini[$section][$name] = $value.Trim()
            }

            default
            {
                # Если строка без =, то записать ее как пустую строку отступ, если ещё нет. Пропускает все лишние отступы (пустые строки). Count нужен для уникального имени хэш таблицы
                if ( -not ( $ini[$section].Keys -like '<*' )) { $ini[$section]["<$('{0:d4}' -f $CommentCount++)>"] = '' } # $_
            }
        }

        if ( -not ( $ini.Keys -eq 'LocalizedFileNames' )) { 
        
            if ( $ini.Keys -eq '.ShellClassInfo' )
            {
                if ( -not ( $ini['.ShellClassInfo'].Keys -like '<*' )) { $ini['.ShellClassInfo']["<$('{0:d4}' -f $CommentCount++)>"] = '' }
            }
            elseif (-not ($ini['NO_SECTION'].Keys -like '<*' )) { $ini['NO_SECTION']["<$('{0:d4}' -f $CommentCount++)>"] = '' }
        
            $ini['LocalizedFileNames'] = [ordered]@{} 
        }

        foreach ( $L in $Localized ) {
            try { $ini.LocalizedFileNames.insert($ini.LocalizedFileNames.Keys.Where({ -not $_.StartsWith('<')}).Count, $L.Lnk, $L.Lang) } catch {}
        }

        $ContentIni = @()
        foreach ($Category in $ini.Keys)
        {
            if ( $Category -notlike 'NO_SECTION' )
            {
                $ContentIni += "[$Category]";
            }

            foreach ($Key in $ini.$Category.Keys)
            {           
                if ( $Key.StartsWith('<') )
                {
                    if ($PreserveNonData)
                    {
                        $ContentIni += $ini.$Category.$Key
                    }
                }
                else
                {
                    $ContentIni += "$Key={0}" -f $ini.$Category.$Key
                }
            }
        }

        Return $ContentIni
    }

    [string[]] $Content = @()
    [System.IO.DirectoryInfo] $Dir = $null
    [System.IO.FileInfo] $IniItem = $null

    Function Add-Calc-Shortcut ([string] $Sourcelnk, [string] $Path, [switch] $Remove = $false) {

        $Content = @()
        $Dir = Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
        
        try
        {
            if (( -not $Remove ) -and ( $Dir.Exists ) -and ( -not [System.IO.File]::Exists("$Path\desktop.ini") )) { [System.IO.File]::WriteAllLines("$Path\desktop.ini",'') }
            $IniItem = $Dir.GetFiles('desktop.ini')[0] 
        }
        catch { $IniItem = $null }

        if ( $IniItem.Exists )
        {
            $Content = Get-Content -LiteralPath $Path\desktop.ini -ErrorAction SilentlyContinue # -Encoding Unicode  -Force 

            if ( -not $Remove )
            {
                $text = if ( $L.s4 ) { $L.s4 } else { 'Добавление ярлыка' }
                Write-Host "   $text`: $Path\Calculator.lnk" -ForegroundColor DarkGray

                if ( -not ( $Content -like 'Calculator.lnk*' ))
                {
                    [array] $Localized = [PSCustomObject]@{
                        Lnk  = 'Calculator.lnk'
                        Lang = '@%SystemRoot%\system32\shell32.dll,-22019'
                    }

                    $Content = Insert-Localized-To-DesktopIni $Content $Localized

                    Write-Host "   Add Localized data to desktop.ini" -ForegroundColor DarkGray

                    $IniItem.Attributes = 'Archive'

                    try { Out-File -InputObject $Content -LiteralPath $Path\desktop.ini -Encoding unicode -Force -ErrorAction SilentlyContinue } catch {}
                }

                Copy-Item -LiteralPath $Sourcelnk -Destination $Path\ -Container -Force -ErrorAction SilentlyContinue
            }
            else
            {
                $text = if ( $L.s5 ) { $L.s5 } else { 'Удаление ярлыка' }
                Write-Host "   $text`: $Path\Calculator.lnk" -ForegroundColor DarkMagenta

                if ( $Content -like 'Calculator.lnk*' )
                {
                    $Content = $($Content).Where({ $_ -notlike 'Calculator.lnk*' })

                    Write-Host "   Remove Localized data from desktop.ini" -ForegroundColor DarkGray

                    $IniItem.Attributes = 'Archive'

                    try { Out-File -InputObject $Content -LiteralPath $Path\desktop.ini -Encoding unicode -Force -ErrorAction SilentlyContinue } catch {}
                }

                $Sourcelnk = "$Path\Calculator.lnk"
                Write-Host "   Remove: $Sourcelnk" -ForegroundColor DarkGray
                Remove-Item -LiteralPath $Sourcelnk -Force -ErrorAction SilentlyContinue
            }

            $text = if ( $L.s6 ) { $L.s6 } else { 'Настройка атрибутов INI файла' }
            Write-Host "   $text " -ForegroundColor DarkGray -NoNewline

            $Dir.Attributes = 'ReadOnly'

            $IniItem.Attributes = 'Hidden', 'System', 'Archive'
            $IniItem.Refresh()

            if ( $IniItem.Attributes -like 'Hidden, System, Archive' )
            {
                $text = if ( $L.s6_1 ) { $L.s6_1 } else { 'завершена' }
                Write-Host "$text" -ForegroundColor DarkGreen
            }
            else
            {
                $text = if ( $L.s6_2 ) { $L.s6_2 } else { 'не завершена' }
                Write-Host "$text" -ForegroundColor Red
            }
        }
    }

    if ( $Act -ne 'Default' )
    {
        <# App Paths имеет приоритет над этими, когда в них нет путей точно.
        Write-Host

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator' -Name '' -Type String 'URL:calculator'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator' -Name 'URL Protocol' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator\DefaultIcon' -Name '' -Type ExpandString '%ProgramFiles%\Win32calc\win32calc.exe,0'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator\shell\open\command' -Name '' -Type ExpandString '%ProgramFiles%\Win32calc\win32calc.exe'
    
        Write-Host
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator' -Name '' -Type String 'URL:calculator'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator' -Name 'URL Protocol' -Type String ''
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator\DefaultIcon' -Name '' -Type ExpandString '%ProgramFiles%\Win32calc\win32calc.exe,0'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator\shell\open\command' -Name '' -Type ExpandString '%ProgramFiles%\Win32calc\win32calc.exe'
        #>

        Write-Host

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\calc.exe' -Name '' -Type ExpandString '%ProgramFiles%\Win32calc\win32calc.exe'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\calc.exe' -Name 'Path' -Type ExpandString '%ProgramFiles%\Win32calc\'

        Write-Host

        if ( $Act -eq 'Check' ) { $Color = 'Yellow' } else { $Color = 'Red' }

        if ( $Act -eq 'Set' )
        {
            Token-Privileges -Enable4Privileges

            try
            {
                if ( -not [System.IO.Directory]::Exists($InstallDir) )
                {
                    New-Item -ItemType Directory -Path $InstallDir -Force -ErrorAction Stop > $null
                }

                & $7z x "$Archive" -o"$InstallDir" "-x!*_$ExclArch.exe" -aoa -bso0 -bse0 -bsp0
                Move-Item -Path $InstallDir\win32calc_*.exe -Destination $InstallDir\win32calc.exe -Force -ErrorAction SilentlyContinue
            }
            catch
            {
                Write-Host "   Error: folder: '$InstallDir'" -ForegroundColor Red
            }
        }

        if ( -not [System.IO.File]::Exists("$InstallDir\win32calc.exe") )
        {
            $text = if ( $L.s7 ) { $L.s7 } else { 'Калькулятор не установлен' }
            Write-Host "   $text" -ForegroundColor $Color

            $NeedFix = $true
        }
        else
        {
            $text = if ( $L.s8 ) { $L.s8 } else { 'Калькулятор установлен' }
            Write-Host "   $text" -ForegroundColor Green
        }

        Write-Host "   InstallDir: $InstallDir\win32calc.exe" -ForegroundColor DarkGray

        if ( $Act -eq 'Set' )
        {
            Write-Host

            #[string] $Path = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Accessories" # Не видит W11 Пуск
            [string] $Path = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs" # Эту видит для всех юзеров
            Add-Calc-Shortcut -Sourcelnk $InstallDir\Calculator.lnk -Path $Path

            <#
            foreach ( $Acc in $Accs )
            {
                $NameUser = $Acc.Name
                $Profile  = $Acc.Profile

                Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
                Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

                $Path = '{0}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Accessories' -f $Profile
                Add-Calc-Shortcut -Sourcelnk $InstallDir\Calculator.lnk -Path $Path
            }#>
        }
    }
    else
    {
        # Восстановление по умолчанию (удаление)

        Write-Host

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator' -Name '' -Type String 'URL:calculator'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\calculator' -Name 'URL Protocol' -Type String ''
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\calculator\DefaultIcon'
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\calculator\shell'
    
        Write-Host
        
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator' -Name '' -Type String 'URL:calculator'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\ms-calculator' -Name 'URL Protocol' -Type String ''
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\ms-calculator\DefaultIcon'
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\ms-calculator\shell'

        Write-Host

        Set-Reg New-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\calc.exe'

        Write-Host

        Token-Privileges -Enable4Privileges

        Write-Host "   Remove: $InstallDir" -ForegroundColor DarkMagenta
        Remove-Item -LiteralPath \\?\$InstallDir -Recurse -Force -ErrorAction SilentlyContinue

        #[string] $Path = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs\Accessories"
        [string] $Path = "$env:SystemDrive\ProgramData\Microsoft\Windows\Start Menu\Programs" 

        Add-Calc-Shortcut -Remove -Path $Path

        <#
        foreach ( $Acc in $Accs )
        {
            $NameUser = $Acc.Name
            $Profile  = $Acc.Profile

            Write-Host "`n   User: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$NameUser " -ForegroundColor DarkCyan -NoNewline
            Write-Host "| $($Acc.Source): $($Acc.FullName) ($($Acc.SID))`n" -ForegroundColor DarkGray

            [string] $Path = '{0}\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Accessories' -f $Profile

            Add-Calc-Shortcut -Remove -Path $Path
        }#>
    }

    $text = if ( $L.s9 ) { $L.s9 } else { 'Завершено' }
    Write-Host "`n   $text" -ForegroundColor DarkGray
}
