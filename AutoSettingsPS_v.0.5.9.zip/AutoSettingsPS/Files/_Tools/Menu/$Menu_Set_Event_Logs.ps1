﻿
$Menu_Set_Event_Logs = @{

    Info =  @{

        1 = ' #DarkGray#======================================================================================================================#'
        2 = "   #Yellow#$($L.s1) #DarkGray#| Set-Event-Logs | $($L.s1_1)#" # Журналы событий | Set-Event-Logs | Отключение Журналов уменьшает нагрузку на диск и процессор
        3 = "   #DarkGray#$($L.s2)#"                       # Системные Журналы будут оставлены: Безопасность, Установка, Система и др. Но журнал PowerShell будет отключён
        4 = "   #DarkGray#$($L.s3)#"                       # Вместе с журналами будут отключены их сборщики (Autologger), если сборщик не нужен другим работающим журналам
        5 = "   #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Для пропуска журналов и/или их отдельной настройки указывать в пресете, текущий файл: \Presets...
        6 = " #DarkGray#======================================================================================================================#`n"
    }

    Status = @{

        1 = "      $($L.s5): ", '& Check-State-Service | -ServiceName EventLog -Default Automatic -Need Disabled' #   Служба EventLog: ...

      2 = "`n      $($L.s6): ", '& Set-Event-Logs | -CheckState EventLogs', " #DarkGray#| $($L.s6_1)#"            #           Журналы: ... Системные журналы не учитываются
        3 = "      $($L.s7): ", '& Set-Event-Logs | -CheckState ExcludedLogs'                                     # Журналы в пресете: ...

      4 = "`n      #DarkGray#$($L.s8):#`n"  # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s9 ) #DarkGray#| $($L.s9_1 )#"                    #  [1] = Отключение всех журналов | Кроме Системных, а указанные в пресете будут включены, если отключены
        2 = "#Cyan#  [2]# = $($L.s10) #DarkGray#| $($L.s10_1)#"                    #  [2] = Очистка всех журналов    | С записями, для отключенных будут удалены и файлы
        3 = "#Cyan#  [3]# = $($L.s11) #DarkGray#| $($L.s11_1)#"                    #  [3] = Выполнить все действия   | Отключить и Очистить

  4 = "`n#DarkCyan#  [4]# = $($L.s12) #DarkGray#| $($L.s12_1)    #DarkCyan#◄#Cyan# [41]# = $($L.s12_2)#" #  [4] = Вывести список Включённых Журналов | Без Системных, с проверкой Autologger    ◄ [41] = С исправлением
    5 = "#DarkCyan#  [5]# = $($L.s13) #DarkGray#| $($L.s13_1)#"                    #  [5] = Вывести список Журналов в пресете  | В файле пресетов Presets*.txt

      6 = "`n#Mage# [10]# = #Mage#$($L.s14)# $($L.s14_1) #DarkGray#| $($L.s14_2)#" # [10] = Включить  Журналы из пресета | Подходящих под шаблоны имён в Presets*.txt и не включенных
        7 = "#Cyan# [20]# = #Cyan#$($L.s15)# $($L.s15_1) #DarkGray#| $($L.s15_2)#" # [20] = Отключить Журналы из пресета | Подходящих под шаблоны имён в Presets*.txt и не отключенных

   8 = "`n#Magenta# [999]# = #Magenta#$($L.s16) #DarkGray#| $($L.s16_1)#"           # [99] = Включить все журналы | Которые включены по умолчанию (~330 шт)

      9 = "`n#Cyan# [$($L.s17)]# = #DarkGray#$($L.s17_1)#`n"    # Без ввода = Возврат в меню Личных Настроек
    }

    Selection = @{

        1 = '& Set-Event-Logs | -Options EventLogsDisable                -Act Set'
        2 = '& Set-Event-Logs | -Options CleanEventLogs                  -Act Set'
        3 = '& Set-Event-Logs | -Options EventLogsDisable,CleanEventLogs -Act Set'

        4 = '& Set-Event-Logs | -Options ShowEnabledLogs  -Act Check'
        5 = '& Set-Event-Logs | -Options ShowExcludedLogs -Act Check'

       41 = '& Set-Event-Logs | -Options ShowEnabledLogs -FixEnabledLogs -Act Set'

       10 = '& Set-Event-Logs | -Options ExcludedLogsEnable  -Act Set'
       20 = '& Set-Event-Logs | -Options ExcludedLogsDisable -Act Set'

      999 = '& Set-Event-Logs | -Options EventLogsDisable -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
