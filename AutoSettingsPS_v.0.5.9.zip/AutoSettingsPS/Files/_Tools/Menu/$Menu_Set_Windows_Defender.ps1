﻿
$Menu_Set_Windows_Defender = @{

    Info =  @{

        1 = ' #DarkGray#======================================================================================================================#'
        2 = "     #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Защитник Windows и Центр Безопасности | Добавить в Исключения или Отключить
        3 = "     #DarkGray#$($L.s2)#"                       # Центр Безопасности контролирует состояние (Брандмауера, Антивируса, Обновления Windows, UAC и др.),
        4 = "     #DarkGray#$($L.s3)#"                       # запускает поиск вирусов, обеспечивает передачу данных для анализа безопасности и др.
       #5 = "     #DarkGray#$($L.s4)#"                       # 
        6 = "     #Blue#$($L.s5)#"                           # Для отключения Защитника может потребоваться вручную отключить 'Защиту от Подделки' в его настройках
        7 = "     $($L.s6): ", '#White#& Run-Configs | -CheckState CurrentPreset#', ' #DarkGray#| & Set-Windows-Defender | -CheckState PresetExclusions'  # Папка скрипта будет добавлена в исключения. В файле Пресетов: \Presets  1.txt | Указано исключений: 6 шт
        8 = " #DarkGray#======================================================================================================================#`n"
    }

    Status = @{

        1 = " $($L.s7   ): ", '& Set-Windows-Defender | -CheckState Exclusion'             # Исключение папки

      2 = "`n $($L.s8   ): ", '& Set-Windows-Defender | -CheckState Defender',             # Защитник
            " $($L.s8_1 ): ", '& Check-State-Task     | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance" -Default Enabled -Need Disabled', # Задача 1  (Windows Defender Cache Maintenance)
            " $($L.s8_2 ): ", '& Set-Windows-Defender | -CheckState ContextMenu'           # Контекстное меню
 
        3 = " $($L.s9   ): ", '& Set-Windows-Defender | -CheckState RealtimeMon',          # Защита в реальном времени
            " $($L.s9_1 ): ", '& Check-State-Task     | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Cleanup" -Default Enabled -Need Disabled',           # Задача 2  (Windows Defender Cleanup)
            " $($L.s9_2 ): ", '& Set-Windows-Defender | -CheckState LockMpCmdRun'          # MpCmdRun.exe
               
        4 = " $($L.s10  ): ", '& Set-Windows-Defender | -CheckState TamperProtection',     # Защита от подделки   
            " $($L.s10_1): ", '& Check-State-Task     | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan" -Default Enabled -Need Disabled',    # Задача 3  (Windows Defender Scheduled Scan)
            " $($L.s10_2): ", '& Set-Windows-Defender | -CheckState SmartScreen'           # SmartScreen

        5 = " $($L.s11  ): ", '& Set-Windows-Defender | -CheckState SmartAppControl',      # Интеллект. управл
            " $($L.s11_1): ", '& Check-State-Task     | -TaskName "\Microsoft\Windows\Windows Defender\Windows Defender Verification" -Default Enabled -Need Disabled',      # Задача 4  (Windows Defender Verification)
            " $($L.s11_2): ", '& Set-Windows-Defender | -CheckState VBS'                   # VBS   Безопасность на основе виртуализации


      6 = "`n $($L.s12  ): ", '& Check-State-Driver   | -DriverName WdFilter -Default Boot -Need Disabled',        # Драйвер WdFilter
                              '& Check-State-Driver   | -DriverName WdFilter -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -DriverName WdFilter -Act Check -ForMenu',                 # Не дает настроить сразу блокировку на 19045.3086
            " $($L.s12_1): ", '& Check-State-Service  | -ServiceName WinDefend -Default Automatic -Need Disabled', # Служба WinDefend
                              '& Check-State-Service  | -ServiceName WinDefend -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -ServiceName WinDefend -Act Check -ForMenu'

        7 = " $($L.s13  ): ", '& Check-State-Driver   | -DriverName WdBoot -Default Boot -Need Disabled',          # Драйвер WdBoot
                              '& Check-State-Driver   | -DriverName WdBoot -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -DriverName WdBoot -Act Check -ForMenu', 
            " $($L.s13_1): ", '& Check-State-Service  | -ServiceName WdNisSvc -Default Manual -Need Disabled',     # Служба WdNisSvc
                              '& Check-State-Service  | -ServiceName WdNisSvc -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -ServiceName WdNisSvc -Act Check -ForMenu'
    
        8 = " $($L.s14  ): ", '& Check-State-Driver   | -DriverName WdNisDrv -Default Manual -Need Disabled',      # Драйвер WdNisDrv
                              '& Check-State-Driver   | -DriverName WdNisDrv -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -DriverName WdNisDrv -Act Check -ForMenu', 
            " $($L.s14_1): ", '& Check-State-Service  | -ServiceName Sense -Default Manual -Need Disabled',        # Служба Sense
                              '& Check-State-Service  | -ServiceName Sense -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -ServiceName Sense -Act Check -ForMenu'
    
        9 = " $($L.s15  ): ", '& Check-State-Driver   | -DriverName MsSecFlt -Default Manual -Need Disabled',      # Драйвер MsSecFlt
                              '& Check-State-Driver   | -DriverName MsSecFlt -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -DriverName MsSecFlt -Act Check -ForMenu', 
            " $($L.s15_1): ", '& Check-State-Service  | -ServiceName webthreatdefsvc -Default Manual -Need Disabled', # Служба webthreatdefsvc
                              '& Check-State-Service  | -ServiceName webthreatdefsvc -CheckStatus -Return Result'
    
       10 = " $($L.s16  ): ", '& Check-State-Driver   | -DriverName wtd -Default Automatic -Need Disabled',        # Драйвер wtd
                              '& Check-State-Driver   | -DriverName wtd -CheckStatus -Return Result',
            " $($L.s16_1): ", '& Check-State-Service  | -ServiceName webthreatdefusersvc -Default Automatic -Need Disabled',   # Служба webthreatdefusersvc
                              '& Check-State-Service  | -ServiceName webthreatdefusersvc -CheckStatus -Return Result'
    
     11 = "`n #DarkGray#$($L.s17): #",                                                                                      # Центр Безопасности
            " $($L.s17_1): ", '& Check-State-Service  | -ServiceName SecurityHealthService -Default Manual -Need Disabled', # Служба SecurityHealthService
                              '& Check-State-Service  | -ServiceName SecurityHealthService -CheckStatus -Return Result',
                              '& Set-Svc-AccessDeny   | -ServiceName SecurityHealthService -Act Check -ForMenu'
        
       12 = " $($L.s18  ): ", '& Set-Windows-Defender | -CheckState Run',                                        # Автозагрузка
            " $($L.s18_1): ", '& Check-State-Service  | -ServiceName wscsvc -Default Manual -Need Disabled',     # Служба wscsvc
                              '& Check-State-Service  | -ServiceName wscsvc -CheckStatus -Return Result'

       13 = " $($L.s19  ): ", '& Set-Windows-Defender | -CheckState HideSecurityCenter',                         # В Настройках
            " $($L.s19_1): ", '& Check-State-Service  | -ServiceName SgrmBroker -Default Manual -Need Disabled', # Служба SgrmBroker
                              '& Check-State-Service  | -ServiceName SgrmBroker -CheckStatus -Return Result'


       14 = " $($L.s20  ): ", '& Set-Windows-Defender | -CheckState SecurityCenterNotifications',                # Уведомления
            " $($L.s20_1): ", '& Check-State-Driver   | -DriverName SgrmAgent -Default Manual -Need Disabled',   # Драйвер SgrmAgent
                              '& Check-State-Driver   | -DriverName SgrmAgent -CheckStatus -Return Result'
    }

    Options = @{

      1 = "`n#Cyan# [1]# = $($L.s21) #DarkGray#| $($L.s21_1)#"                                                                                 # [1] = Добавить в Исключения        | Только Исключения для Защитника
        2 = "#Cyan# [2]# = $($L.s22) #DarkGray#| $($L.s22_1)   #DarkMagenta#◄#Magenta# [21]# = #Magenta#$($L.s22_2) #DarkGray#| $($L.s22_3)#"  # [2] = Отключить Защитник           | Отключить все компоненты + Исключения   ◄ [21] = Восстановить | [2] и [5] пункт
        3 = "#Cyan# [3]# = $($L.s23) #DarkGray#| $($L.s23_1)   #DarkMagenta#◄#Magenta# [31]# = #Magenta#$($L.s23_2)#"                          # [3] = Отключить SmartScreen        | Полностью                               ◄ [31] = Включить
        4 = "#Cyan# [4]# = $($L.s24) #DarkGray#| $($L.s24_1)   #DarkMagenta#◄#Magenta# [41]# = #Magenta#$($L.s24_2)#"                          # [4] = Отключить VBS                | Безопасность на основе виртуализации    ◄ [41] = Включить
        5 = "#Cyan# [5]# = $($L.s25) #DarkGray#| $($L.s25_1)   #DarkMagenta#◄#Magenta# [51]# = #Magenta#$($L.s25_2)#`n"                        # [5] = Отключить Центр Безопасности | Уведомления/настройки/службы            ◄ [51] = Включить

        6 = "#Cyan# [$($L.s26)]# = #DarkGray#$($L.s26_1)   #Blue# [200]# = #Blue#$($L.s26_2) #DarkGray#| $($L.s26_3)#`n"                         # [Без ввода] = Возврат в меню Личных Настроек      [200] = 2 параметра защиты | Открыть окно настроек
    }

    Selection = @{                                                  # ApplyGP для вызова паузы при запуске из меню, чтобы через быстрые настройки не было паузы

        1 = '& Set-Windows-Defender | -Act Set -Option AddExclusions -ApplyGP'
        
        2 = '& Set-Windows-Defender | -Act Set     -Option DefenderDisable -ApplyGP'
       21 = '& Set-Windows-Defender | -Act Default -Option DefenderDisable -ApplyGP' # Восстановит вместе с SecurityCenterDisable
        
        3 = '& Set-Windows-Defender | -Act Set     -Option SmartScreenDisable -ApplyGP'
       31 = '& Set-Windows-Defender | -Act Default -Option SmartScreenDisable -ApplyGP'

        4 = '& Set-Windows-Defender | -Act Set     -Option VBSDisable -ApplyGP'
       41 = '& Set-Windows-Defender | -Act Default -Option VBSDisable -ApplyGP'

        5 = '& Set-Windows-Defender | -Act Set     -Option SecurityCenterDisable -ApplyGP'
       51 = '& Set-Windows-Defender | -Act Default -Option SecurityCenterDisable -ApplyGP'

      200 = '& Set-Windows-Defender | -Act Check   -Option OpenThreatSettings'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
