﻿
$Menu_Run_QuickSettings = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#Quick Settings#DarkGray#: #Green#$($L.s1)# $($L.s1_1) #DarkGray#$($L.s1_2)#"       # Быстрое Применение Параметров. Список групп параметров можно изменить в файле пресетов
        3 = "       #DarkGray#$($L.s1_3): #",'& Show-Selected-Users' # Для текущего аккаунта
        4 = "       #DarkGray#$($L.s2): #", '#White#& Run-QuickSettings | -CheckState CurrentPreset -Act Set#' # Текущий файл пресетов быстрой настройки
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s3):#`n"   # Все группы Параметров

        1 = '& Run-QuickSettings | -CheckState Configs       -Act Set'
        2 = '& Run-QuickSettings | -CheckState MySettingsPS  -Act Set'
        3 = '& Run-QuickSettings | -CheckState MySettingsCMD -Act Set'
        4 = '& Run-QuickSettings | -CheckState MySettingsREG -Act Set'

        8 = ''
    }

    Options = @{

          1 = "#Cyan#   [1]# = #White#$($L.s4)# $($L.s4_1) #DarkGray#| $($L.s4_2)#`n" # Применить всё сразу | Применить все отображённые группы параметров и найденные файлы

          2 = "#Cyan#   [2]# = $($L.s5) #White#$($L.s5_1) #DarkGray#| $($L.s5_2)#"                             # Применить Только Параметры | Применить только отображённые группы параметров
          3 = "#Cyan#   [3]# = $($L.s6) #White#$($L.s6_1) #Magenta#ps1 #DarkGray#| $($L.s6_2) #Gray#\Files\CustomFiles#"   # Применить Только файлы ps1 | Применить только найденные файлы ps1 в папке:
          4 = "#Cyan#   [4]# = $($L.s7) #White#$($L.s7_1) #Magenta#cmd #DarkGray#| $($L.s7_2) #Gray#\Files\CustomFiles#"   # Применить Только файлы cmd | Применить только найденные файлы cmd в папке:
          5 = "#Cyan#   [5]# = $($L.s8) #White#$($L.s8_1) #Magenta#reg #DarkGray#| $($L.s8_2) #Gray#\Files\CustomFiles#`n" # Применить Только файлы reg | Применить только найденные файлы reg в папке:

       6 = "#Magenta# [999]# = #Magenta#$($L.s9) #DarkGray#| $($L.s9_1)#"   # Восстановление | Меню Восстановления всех настроек разом По умолчанию

        7 = "`n#Cyan# [$($L.s10)]# = #DarkGray#$($L.s10_1)#`n"  # Без ввода = Возврат в Главное Меню
    }

    Selection = @{

        1 = '& Run-QuickSettings | -Options SetConfigs,SetMySettingsPS,SetMySettingsCMD,SetMySettingsREG -Act Set'

        2 = '& Run-QuickSettings | -Options SetConfigs       -Act Set'
        3 = '& Run-QuickSettings | -Options SetMySettingsPS  -Act Set'
        4 = '& Run-QuickSettings | -Options SetMySettingsCMD -Act Set'
        5 = '& Run-QuickSettings | -Options SetMySettingsREG -Act Set'

      999 = "    ► $($L.s9)", '$Menu_Run_QuickSettingsDefault'  # Восстановление

   'Exit' = "  ◄◄◄ $($L.s10_1)", '$MainMenu' # Возврат в Главное Меню

    }
}
