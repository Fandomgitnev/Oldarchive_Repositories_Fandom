﻿
$Menu_Set_Network_Local = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#|# $($L.s1_1)#" # Локальная Сеть | Настройка минимально необходимых сетевых параметров общего доступа и других условий
        3 = "      #DarkGray#$($L.s2)#"                       # Автоматизация действий, выполняющихся при ручной настройке в параметрах общего доступа, + доп. настройки
        4 = "      #DarkGray#$($L.s3)#"                       # Настройку IP, расшаривание своих папок, настройку доступов для них нужно делать самостоятельно
        5 = ' #DarkGray#======================================================================================================================#'
        6 = ''
    }

    Status = @{

     1 = "   $($L.s4 ): ", '& Check-State-Service | -ServiceName BFE -Default Automatic -Need Automatic',        # Служба BFE
                           '& Check-State-Service | -ServiceName BFE -CheckStatus -Return Result',
                           "   $($L.s4_1 ): ", '& Set-Network-Local | -CheckState PrNetworkDiscovery'            # Обнаружение (Частная)
     2 = "   $($L.s5 ): ", '& Check-State-Service | -ServiceName mpssvc -Default Automatic -Need Automatic',     # Служба mpssvc
                           '& Check-State-Service | -ServiceName mpssvc -CheckStatus -Return Result',
                           "   $($L.s5_1 ): ", '& Set-Network-Local | -CheckState PrivateSharing'                # Общий доступ (Частная)
     3 = "   $($L.s6 ): ",  '& Check-State-Driver | -DriverName mpsdrv -Default Manual -Need Manual',            # Драйвер mpsdrv
                            '& Check-State-Driver | -DriverName mpsdrv -CheckStatus -Return Result',
                           "   $($L.s6_1 ): ", '& Set-Network-Local | -CheckState PubNetworkDiscovery'           # Обнаружение (Публичная)

     4 = "   $($L.s7 ): ", '& Check-State-Service | -ServiceName SSDPSRV -Default Manual -Need Automatic',       # Служба SSDPSRV
                           '& Check-State-Service | -ServiceName SSDPSRV -CheckStatus -Return Result',
                           "   $($L.s7_1 ): ", '& Set-Network-Local | -CheckState PublicSharing'                 # Общий доступ (Публичная)

     6 = "   $($L.s8 ): ", '& Check-State-Service | -ServiceName upnphost -Default Manual -Need Manual',         # Служба upnphost
                           '& Check-State-Service | -ServiceName upnphost -CheckStatus -Return Result',
                           "   $($L.s8_1 ): ", '& Set-Network-Local | -CheckState DomNetworkDiscovery'           # Обнаружение (Домен)

     7 = "   $($L.s9 ): ", '& Check-State-Service | -ServiceName Dnscache -Default Automatic -Need Automatic',   # Служба Dnscache
                           '& Check-State-Service | -ServiceName Dnscache -CheckStatus -Return Result',
                           "   $($L.s9_1 ): ", '& Set-Network-Local | -CheckState DomainSharing'                 # Общий доступ (Домен)

   8 = "`n   $($L.s10): ",   '& Set-Network-Local | -CheckState SMB1',                                                            # Протокол SMB1
                           "   $($L.s10_1): ", '& Check-State-Driver | -DriverName mrxsmb10 -Default Automatic -Need Automatic',  # Драйвер mrxsmb10
                                               '& Check-State-Driver | -DriverName mrxsmb10 -CheckStatus -Return Result'

     9 = "   $($L.s11): ",   '& Set-Network-Local | -CheckState UnsafeGuest',                                                     # Небезоп. гостевые входы
                           "   $($L.s11_1): ", '& Check-State-Driver | -DriverName mrxsmb20 -Default Manual -Need Manual',        # Драйвер mrxsmb20
                                               '& Check-State-Driver | -DriverName mrxsmb20 -CheckStatus -Return Result'
    10 = "   $($L.s12): ",   '& Set-Network-Local | -CheckState PrivateAutoConfig',                                               # Автоматическая настройка
                           "   $($L.s12_1): ", '& Check-State-Service | -ServiceName FDResPub -Default Manual -Need Automatic',   # Служба FDResPub
                                               '& Check-State-Service | -ServiceName FDResPub -CheckStatus -Return Result'
    11 =                   "   $($L.s13  ): ", '& Check-State-Service | -ServiceName fdPHost -Default Manual -Need Automatic',    # Служба fdPHost
                                               '& Check-State-Service | -ServiceName fdPHost -CheckStatus -Return Result'

    12 =                   "   $($L.s14  ): ", '& Check-State-Service | -ServiceName LanmanWorkstation -Default Automatic -Need Automatic', # Служба LanmanWorkstation
                                               '& Check-State-Service | -ServiceName LanmanWorkstation -CheckStatus -Return Result',
                                               '#DarkGray#| ', '& Set-Network-Local | -CheckState LmWksDependOnService'                     # Bowser

    13 = "   $($L.s15): ", '& Set-Network-Local | -CheckState AllPublicFolders'         # Общие папки (Все)
    14 = "   $($L.s16): ", '& Set-Network-Local | -CheckState AllPasswordProtect'       # Парольная защита (Все)

   #15 = "`n      #DarkGray#$($L.s19):#`n"  # Варианты для выбора

    }

    Options = @{

      1 = "`n#Cyan#  [1]# = $($L.s20) #White#$($L.s20_1) #DarkGray#| $($L.s20_2)  #DarkMagenta#◄ #Magenta#[11]# = #Magenta#$($L.s20_3)#"  #   [1] = Включить:  Протокол SMBv1                      | Нужно для сединения к прошлым Windows   ◄ [11] = Отключить
        2 = "#Cyan#  [2]# = $($L.s21) #White#$($L.s21_1) #DarkGray#| $($L.s21_2)  #DarkMagenta#◄ #Magenta#[12]# = #Magenta#$($L.s21_3)#"  #   [2] = Включить:  Небезопасные входы                  | Нужно для сединения к прошлым Windows   ◄ [12] = Отключить
        3 = "#Cyan#  [3]# = $($L.s22) #White#$($L.s22_1) #DarkGray#| $($L.s22_2)  #DarkMagenta#◄ #Magenta#[13]# = #Magenta#$($L.s22_3)#"  #   [3] = Включить:  Поддержку SMBv1                     | Драйвер и настройки                     ◄ [13] = Отключить
        4 = "#Cyan#  [4]# = $($L.s23) #White#$($L.s23_1) #DarkGray#| $($L.s23_2)  #DarkMagenta#◄ #Magenta#[14]# = #Magenta#$($L.s23_3)#"  #   [4] = Отключить: Поддержку SMBv2/3                   | Драйвер и Настройки                     ◄ [14] = Включить

      5 = "`n#Cyan#  [5]# = $($L.s24) #White#$($L.s24_1) #DarkGray#| $($L.s24_2)  #DarkMagenta#◄ #Magenta#[15]# = #Magenta#$($L.s24_3)#"  #   [5] = Включить:  Сетевое Обнаружение+Cлужбы/Драйвера | Для Частной Сети + Cлужбы/Драйвера      ◄ [15] = Восстановить
        6 = "#Cyan#  [6]# = $($L.s25) #White#$($L.s25_1) #DarkGray#| $($L.s25_2)  #DarkMagenta#◄ #Magenta#[16]# = #Magenta#$($L.s25_3)#"  #   [6] = Включить:  Общий доступ к файлам и принтерам   | Для Частной Сети                        ◄ [16] = Отключить
        7 = "#Cyan#  [7]# = $($L.s26) #White#$($L.s26_1) #DarkGray#| $($L.s26_2)  #DarkMagenta#◄ #Magenta#[17]# = #Magenta#$($L.s26_3)#"  #   [7] = Включить:  Общий доступ к общедоступным папкам | Все Сети                                ◄ [17] = Отключить
        8 = "#Cyan#  [8]# = $($L.s27) #White#$($L.s27_1) #DarkGray#| $($L.s27_2)  #DarkMagenta#◄ #Magenta#[18]# = #Magenta#$($L.s27_3)#"  #   [8] = Отключить: Общий доступ с парольной защитой    | Все Сети                                ◄ [18] = Включить
        9 = "#Cyan#  [9]# = $($L.s28) #White#$($L.s28_1) #DarkGray#| $($L.s28_2)  #DarkMagenta#◄ #Magenta#[19]# = #Magenta#$($L.s28_3)#"  #   [9] = Включить:  Сетевое Обнаружение                 | Для Публичной Сети                      ◄ [19] = Отключить
       10 = "#Cyan# [10]# = $($L.s29) #White#$($L.s29_1) #DarkGray#| $($L.s29_2)  #DarkMagenta#◄ #Magenta#[20]# = #Magenta#$($L.s29_3)#"  #  [10] = Включить:  Общий доступ к файлам и принтерам   | Для Публичной Сети                      ◄ [20] = Отключить

    11 = "`n#Green# [22]# = #Green#$($L.s30) #White#$($L.s30_1) #DarkGray#| $($L.s30_2) #Magenta# [30]# = #Magenta#$($L.s30_3) #DarkGray#| $($L.s30_4)#"  #  [22] = Выполнить 1-3,5,6 настройки сразу | 5 пунктов   [30] = Сбросить все правила Брандмауэра Windows | По умолчанию (Дополнительная возможность)
       14 = "#Cyan# [$($L.s31)]# = #DarkGray#$($L.s31_1) #Magenta# [99]# = #Magenta#$($L.s31_2) #DarkGray#| $($L.s31_3)#`n"                               #  [Без ввода] = Возврат в меню Личных Настроек           [99] = Восстановить Все параметры | По умолчанию (Откл. SMBv1)

    }

    Selection = @{

        1 = '& Set-Network-Local | -Act Set -Options SetProtocolSMB1        -ApplyGP'  # Всем ApplyGP, чтобы пауза срабатывала только через меню.
        2 = '& Set-Network-Local | -Act Set -Options SetUnsafeGuest         -ApplyGP'
        3 = '& Set-Network-Local | -Act Set -Options SetSupportSMB1         -ApplyGP'
        4 = '& Set-Network-Local | -Act Set -Options DisableSupportSMB23    -ApplyGP'

        5 = '& Set-Network-Local | -Act Set -Options SetPrNetworkDiscovery  -ApplyGP'
        6 = '& Set-Network-Local | -Act Set -Options SetPrivateSharing      -ApplyGP'
        7 = '& Set-Network-Local | -Act Set -Options SetAllPublicFolders    -ApplyGP'
        8 = '& Set-Network-Local | -Act Set -Options SetAllPasswordProtect  -ApplyGP'

        9 = '& Set-Network-Local | -Act Set -Options SetPubNetworkDiscovery -ApplyGP'
       10 = '& Set-Network-Local | -Act Set -Options SetPublicSharing       -ApplyGP'

       22 = '& Set-Network-Local | -Act Set -Options SetProtocolSMB1,SetUnsafeGuest,SetSupportSMB1,SetPrNetworkDiscovery,SetPrivateSharing -ApplyGP'

       11 = '& Set-Network-Local | -Act Default -Options SetProtocolSMB1        -ApplyGP'
       12 = '& Set-Network-Local | -Act Default -Options SetUnsafeGuest         -ApplyGP'
       13 = '& Set-Network-Local | -Act Default -Options SetSupportSMB1         -ApplyGP'
       14 = '& Set-Network-Local | -Act Default -Options DisableSupportSMB23    -ApplyGP'

       15 = '& Set-Network-Local | -Act Default -Options SetPrNetworkDiscovery  -ApplyGP'
       16 = '& Set-Network-Local | -Act Default -Options SetPrivateSharing      -ApplyGP'
       17 = '& Set-Network-Local | -Act Default -Options SetAllPublicFolders    -ApplyGP'
       18 = '& Set-Network-Local | -Act Default -Options SetAllPasswordProtect  -ApplyGP'

       19 = '& Set-Network-Local | -Act Default -Options SetPubNetworkDiscovery -ApplyGP'
       20 = '& Set-Network-Local | -Act Default -Options SetPublicSharing       -ApplyGP'

       30 = '& Set-Network-Local | -Act Default -Options ResetAllFirewallRules  -ApplyGP'

       99 = '& Set-Network-Local | -Act Default -Options SetProtocolSMB1,SetUnsafeGuest,SetSupportSMB1,DisableSupportSMB23,SetPrNetworkDiscovery,SetPrivateSharing,SetAllPublicFolders,SetAllPasswordProtect,SetPubNetworkDiscovery,SetPublicSharing -ApplyGP'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
