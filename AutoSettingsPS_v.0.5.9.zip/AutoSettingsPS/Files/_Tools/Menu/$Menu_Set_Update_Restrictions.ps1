﻿
$Menu_Set_Update_Restrictions = @{

    Info =  @{

        1 = ' #DarkGray#======================================================================================================================#'
        2 = "     #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Меню ограничения обновлений для ЦО | Выбор нужных типов (неофициально)
        3 = "     #DarkGray#$($L.s2) #White#$($L.s2_1)#`n"   # Первый пункт меню [1] официальный (ГП): ЦО может принудительно установить драйвер, при необходимости!

        4 = "     #DarkGray#$($L.s3)#"                       # Пункты ограничения обновлений для установки через ЦО, изменением системных параметров и прав на их изменение
        5 = "     #DarkGray#$($L.s4)#"                       # После восстановления обновления драйверов через ЦО надо удалить или обновить драйвер устройства вручную
        6 = " #DarkGray#======================================================================================================================#`n"
    }

    Status = @{

  1 = "   #DarkGray#$($L.s5   ): ", " #DarkGray#$($L.s5_1):"                                   #    Групповая политика:                                         Возможности ЦО:
            2 = "   $($L.s6   ): ", '& Set-Update-Restrictions | -CheckState DriversLoad',     #  Обновление драйверов: Отключена загрузка                Обновление драйверов: ● |
                "   $($L.s6_1 ): ", '& Set-Update-Restrictions | -CheckState StateDriver', ' #DarkGray#|#' 

            3 = "   $($L.s7   ): ", '& Set-Update-Restrictions | -CheckState DriversSearch' ,  #       Поиск драйверов: Отключен                                    Кумулятивы: ● | И для включения компонентов
                "   $($L.s7_1 ): ", '& Set-Update-Restrictions | -CheckState StateCU', " #DarkGray#| $($L.s7_2)#"

            4 = "   $($L.s8   ): ", '& Set-Update-Restrictions | -CheckState DriversPriority', #   Приоритет Установки: Равный                      Критические для процессора: ● |
                "   $($L.s8_1 ): ", '& Set-Update-Restrictions | -CheckState StateCU', ' #DarkGray#|#' 
        
            5 = "   $($L.s9   ): ", '& Set-Update-Restrictions | -CheckState MetaDataLoad',    #  Получение метаданных: Запрещено                          Защитник и его базы: ● | Может сам обновляться
                "   $($L.s9_1 ): ", '& Set-Update-Restrictions | -CheckState StateDefender', " #DarkGray#| $($L.s9_2)" 
        
            6 = "   $($L.s10  ): ", '& Set-Update-Restrictions | -CheckState SearchOrder',     #        Порядок поиска: Отключен                     Обновления .NET Framework: ● |
                "   $($L.s10_1): ", '& Set-Update-Restrictions | -CheckState StateNETSecure', ' #DarkGray#|#'
        
            7 = "   $($L.s11  ): ", '& Set-Update-Restrictions | -CheckState DriversReports',  #                Отчеты: Отключена отправка             Обновления безопасности: ● |
                "   $($L.s11_1): ", '& Set-Update-Restrictions | -CheckState StateNETSecure', ' #DarkGray#|#' 
       
            8 = "   $($L.s12  ): ", '& Set-Update-Restrictions | -CheckState StateAppX', " #DarkGray#| $($L.s12_1)#"  #                                Загрузка/Обновления UWP: ● | Через MS Store

            9 = "   #DarkGray#$($L.s13):#`n" # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s14) #DarkGray#| $($L.s14_1) #DarkMagenta#◄#Magenta# [100]# = #Magenta#$($L.s14_2) #DarkGray#| $($L.s14_3)#"         #  [1] = Отключить Автоустановку драйверов | ГП       ◄ [100] = Включить | По умолчанию

      2 = "`n#Cyan# [10]# = $($L.s15) #DarkGray#| ",          '& Set-Update-Restrictions | -CheckState WuStateNoDriver', " #DarkGray#| $($L.s15_1)#"  # [10] = Без Драйверов        | ○ | ЦО обновляет: Всё, кроме драйверов
        3 = "#Cyan# [20]# = $($L.s16) #DarkGray#| ",          '& Set-Update-Restrictions | -CheckState WuStateSecure',   " #DarkGray#| $($L.s16_1)#"  # [20] = Только Безопасность  | ○ | ЦО обновляет: Защитника и базы, .NET, Обновления безопасности 
        4 = "#Cyan# [30]# = $($L.s17) #DarkGray#| ",          '& Set-Update-Restrictions | -CheckState WuStateOnlyUWP',  " #DarkGray#| $($L.s17_1)#"  # [30] = Без обновлений       | ○ | ЦО обновляет: Ничего (MS Store загружает/обновляет UWP) 
        5 = "#Cyan# [40]# = $($L.s18) #DarkGray#| ",          '& Set-Update-Restrictions | -CheckState WuStateNothing',  " #DarkGray#| $($L.s18_1)#"  # [40] = Без обновлений и UWP | ○ | ЦО обновляет: Ничего (MS Store не cможет загрузить/обновить UWP)
     6 = "#Magenta# [50]# = #Magenta#$($L.s19) #DarkGray#| ", '& Set-Update-Restrictions | -CheckState WuStateDefault',  " #DarkGray#|#"              # [50] = По умолчанию         | ● |

      7 = "`n#Cyan# [$($L.s20)]# = #DarkGray#$($L.s20_1)   #Magenta# [999]# = #Magenta#$($L.s20_2) #DarkGray#| $($L.s20_3)#`n"                        # [Без ввода] = Возврат в Меню Центр Обновления         [999] = Восстановить всё | По умолчанию
    }

    Selection = @{

        1 = '& Set-Update-Restrictions | -Act Set     -Option DisableDriverGP -ApplyGP'
      100 = '& Set-Update-Restrictions | -Act Default -Option DisableDriverGP -ApplyGP'

       10 = '& Set-Update-Restrictions | -Act Set -Option SetWuNoDriver     -ApplyGP'
       20 = '& Set-Update-Restrictions | -Act Set -Option SetWuSecure       -ApplyGP'
       30 = '& Set-Update-Restrictions | -Act Set -Option SetWuOnlyStoreUWP -ApplyGP'
       40 = '& Set-Update-Restrictions | -Act Set -Option SetWuNothing      -ApplyGP'
       50 = '& Set-Update-Restrictions | -Act Set -Option SetWuDefault      -ApplyGP'

      999 = '& Set-Update-Restrictions | -Act Default -ApplyGP'

   'Exit' = "  ◄◄◄ $($L.s20_1)", '$Menu_Set_Update_Windows' # Возврат в Меню Центр Обновления

    }
}
