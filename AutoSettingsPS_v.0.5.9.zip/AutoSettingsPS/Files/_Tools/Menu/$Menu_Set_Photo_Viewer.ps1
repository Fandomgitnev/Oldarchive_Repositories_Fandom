﻿
$Menu_Set_Photo_Viewer = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#Windows Photo Viewer #DarkGray#| $($L.s1): #",'& Show-Selected-Users | -OnlyUsers'  # Windows Photo Viewer | Возврат Стандартного просмотрщика Фото для
        3 = "      #DarkGray#$($L.s2)#"                                                         # Восстановление поддержки графических файлов и добавление в меню для их открытия
        4 = "      $($L.s3)#"                                                                   # Корректная настройка на открытие указанных графических файлов, с генерацией Hash
        5 = "      #DarkGray#$($L.s4): #", "#White#& Run-Configs | -CheckState CurrentPreset#"  # Изменить список расширений можно в файле пресетов, текущий файл:
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s5):#"
        1 = "      $($L.s6): ", '& Set-Photo-Viewer | -CheckState SystemSettings'
        2 = ''
        3 = "      #DarkGray#$($L.s7)  #White#bmp#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions bmp'
        4 = "      #DarkGray#$($L.s7)  #White#dib#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions dib'
        5 = "      #DarkGray#$($L.s7)  #White#jpg#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions jpg'
        6 = "      #DarkGray#$($L.s7)  #White#jpe#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions jpe'
        7 = "      #DarkGray#$($L.s7) #White#jpeg#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions jpeg'
        8 = "      #DarkGray#$($L.s7) #White#jfif#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions jfif'
        9 = "      #DarkGray#$($L.s7)  #White#png#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions png'
       10 = "      #DarkGray#$($L.s7)  #White#wdp#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions wdp'
       11 = "      #DarkGray#$($L.s7)  #White#jxr#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions jxr'
       12 = "      #DarkGray#$($L.s7)  #White#tif#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions tif'
       13 = "      #DarkGray#$($L.s7) #White#tiff#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions tiff'
       14 = "      #DarkGray#$($L.s7)  #White#nef#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions nef'
       15 = "      #DarkGray#$($L.s7)  #White#orf#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions orf'
       16 = "      #DarkGray#$($L.s7)  #White#arw#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions arw'
       17 = "      #DarkGray#$($L.s7)  #White#cr2#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions cr2'
       18 = "      #DarkGray#$($L.s7)  #White#gif#DarkGray#: ", '& Set-Photo-Viewer | -CheckState Extension -Extensions gif'
       19 = ''
       20 = "      #DarkGray#$($L.s8):#"
       21 = ''
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s9 ) #DarkGray#| $($L.s9_1 )#"                                               # [1] = Вернуть только Поддержку | Восстанавливает все параметры Windows Photo Viewer
        2 = "#Cyan#  [2]# = $($L.s10) #DarkGray#| $($L.s10_1): #", '& Set-Photo-Viewer | -CheckState Preset'  # [2] = Вернуть Поддержку + Назначить на открытие:
     
   3 = "`n#Magenta# [99]# = #Magenta#$($L.s11) #DarkGray#| $($L.s11_1)#"                                     # [99] = Сбросить | Удалить поддержку и назначения (по умолчанию)

        4 = ''
        5 = "#Cyan#  [$($L.s12)]# = #DarkGray#$($L.s12_1)#"
        6 = ''
    }

    Selection = @{

        1 = '& Set-Photo-Viewer | -Option OnlyRestore -Act Set'
        2 = '& Set-Photo-Viewer | -Option SetToOpen   -Act Set'

       99 = '& Set-Photo-Viewer | -Act Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
