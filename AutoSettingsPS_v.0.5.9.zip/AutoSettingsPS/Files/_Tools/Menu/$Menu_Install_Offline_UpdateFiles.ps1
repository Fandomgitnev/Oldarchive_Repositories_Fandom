﻿
$Menu_Install_Offline_UpdateFiles = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#$($L.s1) #DarkGray#$($L.s1_1): #White#\Files\Update #DarkGray#$($L.s1_2): #White#MSU#DarkGray#/#White#CAB #DarkGray#| $($L.s1_3)#" # Установка обновлений из папки: \Files\Update файлами: MSU/CAB | Драйверы пропускаются
        3 = "       #DarkGray#$($L.s2)#" # Центр обновлений Windows не нужен, так как используется DISM. Названия файлов влияют только на сортировку
        4 = "       #DarkGray#$($L.s3)#" # Задаётся необходимая очередность для обновлений: Накопительных (PSFX), Service Stack и Языковых (LIP)
        5 = "       #DarkGray#$($L.s4)#" # PSFX обновление нужно ставить последним и после Service Stack, оба в одном экземпляре!
        6 = "       $($L.s5) #White#CAB#, $($L.s5_1): #Yellow#1# #DarkGray#| $($L.s5_2)#"  # Для повторной установки CAB, для каждого файла нужно нажать клавишу с цифрой: 1 | На выбор 20 секунд
        7 = ' #DarkGray#======================================================================================================================#'
        8 = ''
    }

    Status = @{

        0 = "       #DarkGray#$($L.s6):#"  # Установленные обновления
        1 = '& Install-Offline-UpdateFilesCAB | -ShowHotFix'

      2 = "`n       $($L.s7)#DarkGray#:#"  # Файлы CAB/ESD/WIM в папке \Files\Updates
        3 = '& Install-Offline-UpdateFilesCAB'

      4 = "`n       $($L.s8)#DarkGray#:#"  # Файлы MSU в папке \Files\Updates
        5 = '& Install-Offline-UpdateFilesMSU'

        6 = ''
    }

    Options = @{

        1 = "#Cyan# [111]# = #Magenta#$($L.s9 )# CAB #DarkGray#| $($L.s9_1        )   #DarkCyan#◄#Cyan# [1!1]# = #Magenta#$($L.s9 )# CU CAB #DarkGray#| $($L.s9_2)#" #  [111] = Установить CAB | Подходящие   ◄ [1!1] = Установить CAB | + Обновить пакеты Professional Edition (из PSFX Для LTSC)
        2 = "#Cyan# [222]# = #Magenta#$($L.s10)# MSU #DarkGray#| $ArchOS$($L.s10_1)   #DarkCyan#◄#Cyan# [2!2]# = #Magenta#$($L.s10)# CU MSU #DarkGray#| $($L.s9_2)#" #  [222] = Установить MSU | x64 или x86  ◄ [2!2] = Установить MSU | + Обновить пакеты Professional Edition (из PSFX Для LTSC)

      3 = "`n#Cyan# [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n"    # [Без ввода] = Возврат в Меню Обслуживания
    }

    Selection = @{

      111 = '& Install-Offline-UpdateFilesCAB | -Install'
      222 = '& Install-Offline-UpdateFilesMSU | -Install'

    '1!1' = '& Install-Offline-UpdateFilesCAB | -Install -UpdateFullPkg'
    '2!2' = '& Install-Offline-UpdateFilesMSU | -Install -UpdateFullPkg'

   'Exit' = "  ◄◄◄ $($L.s11_1)", '$Menu_Set_Windows_Maintenance' # Возврат в Меню Обслуживания

    }
}
