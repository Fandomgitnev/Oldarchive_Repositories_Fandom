﻿
$Menu_Set_Update_Windows = @{

    Info =  @{

        1 = ' #DarkGray#======================================================================================================================#'
        2 = "     #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Центр Обновления Windows | Сокращение: ЦО
        3 = "     #DarkGray#$($L.s2)#"                       # Иногда требуется повторное отключение ЦО после перезагрузки, так как не сразу принимаются параметры
        4 = "     #Blue#$($L.s3)#"                           # Служба ЦО нужна для обновления Store UWP, включения компонентов и HWID активации Windows (не нужна KMS/KMS38)!
        5 = " #DarkGray#======================================================================================================================#`n"
    }

    Status = @{

        1 = "  #White#$($L.s4   ): ", '& Set-Update-Windows  | -CheckState Update',         # Режим Обновлений
                   "  $($L.s4_1 ): ", '& Set-Update-Windows  | -CheckState HideUpdate'      # ЦО в настройках
        2 = "  #White#$($L.s5   ): ", '& Set-Update-Windows  | -CheckState OtherMS',        # Обновлять продукты MS
                   "  $($L.s5_1 ): ", '& Set-Update-Windows  | -CheckState UpgradeOSver',   # Не повышать версию
                   "  $($L.s5_2 ): ", '& Set-Update-Windows  | -CheckState HideDelivery'    # Доставка в настройках
               3 = "  $($L.s6   ): ", '& Set-Update-Windows  | -CheckState Delivery'        # Режим Доставки
   
               4 = "  $($L.s7   ): ", '& Check-State-Service | -ServiceName wuauserv -Default Manual -Need Disabled',  # Служба wuauserv
                                      '& Check-State-Service | -ServiceName wuauserv -CheckStatus -Return Result',
                                      '& Set-Svc-AccessDeny  | -ServiceName wuauserv -Act Check -ForMenu'      
               5 = "  $($L.s8   ): ", '& Check-State-Service | -ServiceName UsoSvc -Default DelayedAuto -Need Disabled',
                                      '& Check-State-Service | -ServiceName UsoSvc -CheckStatus -Return Result',
                                      '& Set-Svc-AccessDeny  | -ServiceName UsoSvc -Act Check -ForMenu',           # Служба UsoSvc
                   "  $($L.s8_1 ): ", '& Set-Update-Windows  | -CheckState StubFile'                               # Файл-заглушка
   
               6 = "  $($L.s9   ): ", '& Check-State-Service | -ServiceName DoSvc -Default Manual -Need Disabled',
                                      '& Check-State-Service | -ServiceName DoSvc -CheckStatus -Return Result',
                                      '& Set-Svc-AccessDeny  | -ServiceName DoSvc -Act Check -ForMenu',            # Служба DoSvc Доставки
                   "  $($L.s9_1 ): ", '& Set-Update-Windows  | -CheckState WaaSMedicAgent'                         # WaaSMedicAgent.exe

               7 = "  $($L.s10  ): ", '& Check-State-Service | -ServiceName WaaSMedicSvc -Default Manual -Need Disabled',
                                      '& Check-State-Service | -ServiceName WaaSMedicSvc -CheckStatus -Return Result',
                                      '& Set-Svc-AccessDeny  | -ServiceName WaaSMedicSvc -Act Check -ForMenu',     # Служба WaaSMedicSvc  
                   "  $($L.s10_1): ", '& Set-Update-Windows  | -CheckState upfc'                                   # upfc.exe
   
               8 = "  $($L.s11  ): ", '& Check-State-Service | -ServiceName BITS -Default Manual -Need Disabled',  # Служба BITS          
                                      '& Check-State-Service | -ServiceName BITS -CheckStatus -Return Result',
                   "  $($L.s11_1): ", '& Set-Update-Windows  | -CheckState HealthUtility'                          # Health Tools

               9 = "  $($L.s12  ): ", '& Check-State-Service | -ServiceName uhssvc -Default DelayedAuto -Need Disabled',   # Служба uhssvc
                                      '& Check-State-Service | -ServiceName uhssvc -CheckStatus -Return Result'

      10 = "  #DarkGray#$($L.s13): #"  # Задачи ЦО
       11 = "        Scheduled Start: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\WindowsUpdate\Scheduled Start" -Default Enabled -Need Disabled',
             "          USO_UxBroker: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker" -Default Enabled -Need Disabled',
            "     PerformRemediation: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\WaaSMedic\PerformRemediation" -Default Enabled -Need Disabled', '#DarkGray# ◄ WaaS'

       12 = "          Schedule Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan" -Default Enabled -Need Disabled',
             "   Schedule Retry Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan" -Default Enabled -Need Disabled',
            "            Backup Scan: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Backup Scan" -Default Enabled -Need Disabled'

       13 = "   Schedule Scan Static: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task" -Default Enabled -Need Disabled',
             "       UpdateModelTask: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask" -Default Enabled -Need Disabled',
            "    Maintenance Install: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Maintenance Install" -Default Disabled -Need Disabled'

       14 = "      AC Power Download: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\AC Power Download" -Default Enabled -Need Disabled',
             "      AC Power Install: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\AC Power Install" -Default Enabled -Need Disabled',
            "        Report policies: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Report policies" -Default Enabled -Need Disabled'

       15 = "          Schedule Work: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Work" -Default Enabled -Need Disabled',
             " Schedule Wake To Work: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Wake To Work" -Default Disabled -Need Disabled',
            " Schedule Mainten. Work: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Schedule Maintenance Work" -Default Disabled -Need Disabled'

       16 = "                 Reboot: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Reboot" -Default Disabled -Need Disabled',
             "             Reboot_AC: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Reboot_AC" -Default Disabled -Need Disabled',
            "         Reboot_Battery: ",'& Check-State-Task | -TaskName "\Microsoft\Windows\UpdateOrchestrator\Reboot_Battery" -Default Disabled -Need Disabled'
    }

    Options = @{

      1 = "`n#Cyan#   [1]# = $($L.s14) #DarkGray#| $($L.s14_1) #Cyan#[11]# = $($L.s14_2) #DarkGray#| $($L.s14_3) #DarkMagenta#◄#Magenta# [12]# = #Magenta#$($L.s14_4) #DarkGray#| $($L.s14_5)#"  # [1] = Отключить ЦО | Через ГП (и Store)       [11] = Отключить ЦО | Полностью          ◄ [12] = Отменить | По умолчанию
        2 = "#Cyan#   [2]# = $($L.s15) #DarkGray#| $($L.s15_1) #"                                                                                                                                # [2] = Отключить ЦО | Через ГП (кроме Store)
        3 = "#Cyan#   [3]# = $($L.s16) #DarkGray#| $($L.s16_1) #Cyan#[31]# = $($L.s16_2) #DarkMagenta#◄#Magenta# [32]# = #Magenta#$($L.s16_3) #DarkGray#| $($L.s16_4)#"                          # [3] = Ручной режим | Скрытая проверка         [31] = Блокировать запуск утилит WaaS    ◄ [32] = Отменить | По умолчанию
        4 = "#Cyan#   [4]# = $($L.s17) #DarkGray#| $($L.s17_1) #Cyan#[41]# = $($L.s17_2) #DarkMagenta#◄#Magenta# [42]# = #Magenta#$($L.s17_3) #DarkGray#| $($L.s17_4)#"                          # [4] = Ручной режим | Проверять и сообщать     [41] = Блокировать доступ к службам ЦО   ◄ [42] = Отменить | wuauserv/UsoSvc/DoSvc/WaaSMedicSvc По умолчанию

      5 = "`n#Cyan#   [5]# = $($L.s18) #DarkMagenta#◄#Magenta# [51]# = #Magenta#$($L.s18_1) #DarkGray#$($L.s18_2): #"                                                                            # [5] = Отключить обновления языков           ◄ [51] = Включить             Обновление языков:
        6 = "#Cyan#   [6]# = $($L.s19) #DarkMagenta#◄#Magenta# [61]# = #Magenta#$($L.s19_1) #$($L.s19_2): #",                                                                                    # [6] = Включить обновления продуктов MS      ◄ [61] = Отключить                Служба LxpSvc: Вручную     ◄ Stopped
                            '& Check-State-Service | -ServiceName LxpSvc -Default Manual -Need Disabled',                                                                                        # [7] = Не повышать версию ОС до конца срока  ◄ [71] = Разрешить          Задача Installation: Включена
                            '& Check-State-Service | -ServiceName LxpSvc -CheckStatus -Return Result'
        7 = "#Cyan#   [7]# = $($L.s20) #DarkMagenta#◄#Magenta# [71]# = #Magenta#$($L.s20_1) #$($L.s20_2): #", 
                            '& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\Installation" -Default Enabled -Need Disabled'                                       #                                                                         Задача Installation:
        
        8 = "$($L.s21): #",'& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation" -Default Enabled -Need Disabled'                                      #                                                                       Задача Uninstallation:

      9 = "#Yellow# [700]# = #Yellow#$($L.s22) #$($L.s22_1): #",                                                                                                                                 #  [700] = Меню ограничения обновлений для ЦО                           Задача ReconcileLang~: Включена
                           '& Check-State-Task | -TaskName "\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources" -Default Enabled -Need Disabled' 

     10 = "`n#Cyan# [$($L.s23)]# = #DarkGray#$($L.s23_1)   #DarkCyan# [801]# = #DarkCyan#$($L.s23_2) #$($L.s23_3) #DarkGray#| $($L.s23_4) #DarkCyan# ◄ [802]# = #DarkCyan#$($L.s23_5) #$($L.s23_6) #DarkGray#| $($L.s23_7)#"    #  [Без ввода] = Возврат в Главное Меню          [801] = Очистить Кэш ЦО  | Кроме Журнала  ◄ [802] = Очистить полностью (При проблемах обновления)
       
      11 = "$($L.s24)#Magenta# [999]# = #Magenta#$($L.s24_1) #DarkGray#| $($L.s24_2)#"    #  [999] = Восстановить все | По умолчанию
    }

    Selection = @{

        1 = '& Set-Update-Windows | -Act Set     -Option DisableWuGPOnly        -ApplyGP'  # -ApplyGP везде в том числе для паузы при запуске из этого меню
       11 = '& Set-Update-Windows | -Act Set     -Option DisableWu              -ApplyGP'
       12 = '& Set-Update-Windows | -Act Default -Option DisableWu              -ApplyGP'
        
        2 = '& Set-Update-Windows | -Act Set     -Option DisableWuGPExceptStore -ApplyGP'
        3 = '& Set-Update-Windows | -Act Set     -Option ManualWu               -ApplyGP'
        4 = '& Set-Update-Windows | -Act Set     -Option NotifyWu               -ApplyGP'
       
       31 = '& Set-Update-Windows | -Act Set     -Option BlockWaaSdelTools -ApplyGP'  # Блокировать запуск утилит WaaS
       32 = '& Set-Update-Windows | -Act Default -Option BlockWaaSdelTools -ApplyGP'

       41 = '& Set-Update-Windows | -Act Set     -Option BlockServices -ApplyGP'    # < wuauserv/UsoSvc/DoSvc/WaaSMedicSvc
       42 = '& Set-Update-Windows | -Act Default -Option BlockServices -ApplyGP'

        5 = '& Set-Update-Windows | -Act Set     -Option DisableLangUpdate -ApplyGP'
       51 = '& Set-Update-Windows | -Act Default -Option DisableLangUpdate -ApplyGP'

        6 = '& Set-Update-Windows | -Act Set     -Option EnableOtherMS -ApplyGP'
       61 = '& Set-Update-Windows | -Act Default -Option EnableOtherMS -ApplyGP'

        7 = '& Set-Update-Windows | -Act Set     -Option NotUpgradeOSver -ApplyGP'  # Не повышать версию ОС до конца срока
       71 = '& Set-Update-Windows | -Act Default -Option NotUpgradeOSver -ApplyGP'

      700 = "    ► $($L.s22)", '$Menu_Set_Update_Restrictions'  # Меню ограничения обновлений для ЦО

      801 = '& Set-Update-Windows | -Act Set -Option ClearCache'
      802 = '& Set-Update-Windows | -Act Set -Option ClearCacheAll'

      999 = '& Set-Update-Windows | -Act Default -ApplyGP'

   'Exit' = "  ◄◄◄ $($L.s23_1)", '$MainMenu'  # Возврат в Главное Меню

    }
}
