﻿
$Menu_SelfMenu = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "       #Yellow#SelfMenu#DarkGray#: #$($L.s1)"                                      # SelfMenu: Личные настройки Windows для опытных!
        3 = "       #DarkGray#$($L.s2): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Настраиваемые параметры можно изменить в файле пресетов, текущий файл:
        4 = ' #DarkGray#======================================================================================================================#'
        5 = ''
    }

    Options = @{

        1 = "#Cyan#   [1]# = $($L.s3)#DarkGray#$($L.s3_1)| #", '& Set-Windows-Defender | -CheckState Defender -CheckSelfMenu',#  [1] = Защитник · · · · · · · · | Удален и Отключен | Защита от Подделки: Отсутствует
                                   " #DarkGray#| $($L.s3_2): #", '& Set-Windows-Defender | -CheckState TamperProtection -CheckSelfMenu', # Защита от Подделки
                                   " #DarkGray#| $($L.s3_3): #", '& Check-State-Service | -ServiceName wscsvc -Default DelayedAuto -Need Disabled' # Служба wscsvc

        2 = "#Cyan#   [2]# = $($L.s4)#DarkGray#$($L.s4_1)| $($L.s4_2):# ",
                                                                 '& Set-Boot-Optimization | -CheckState Hibernate -SelfMenu', #  [2] = Оптимизация загрузки · · | Гибернация: Отключена | Быстрая загрузка: Отключена | Служба Оптимизации: Авто
                                   " #DarkGray#| $($L.s4_3):# ", '& Set-Boot-Optimization | -CheckState FastBoot',  # Быстрая загрузка
                                   " #DarkGray#| $($L.s4_4):# ", '& Check-State-Service | -ServiceName SysMain -Default Automatic -Need Disabled' # Служба Оптимизации

        3 = "#Cyan#   [3]# = $($L.s5)#DarkGray#$($L.s5_1)| $($L.s5_2): #", '& Set-Windows-Search | -CheckState Cortana',      #  [3] = Поиск, Кортана, Индекс · | Кортана: Удалена и Отключена | Компонент индексирования: Отключён
                                   " #DarkGray#| $($L.s5_3): #", '& Set-Windows-Search | -CheckState IndexPackage' # Компонент индекс-ия

      4 = "`n#Cyan#   [4]# = $($L.s6)#DarkGray#$($L.s6_1)| $($L.s6_2)#"                                                       #  [4] = Сеть · · · · · · · · · · | Меню настройки параметров сети
        5 = "#Cyan#   [5]# = $($L.s7)#DarkGray#$($L.s7_1)| $($L.s7_2)#"                                                       #  [5] = Проводник  · · · · · · · | Меню настройки отображения элементов Проводника

      6 = "`n#Cyan#   [6]# = $($L.s8)#DarkGray#$($L.s8_1)| $($L.s8_2): #", '& Set-Photo-Viewer | -CheckState SystemSettings'  #  [6] = Просмотр фотографий  · · | Поддержка: Восстановлена | Вероятно
        7 = "#Cyan#   [7]# = $($L.s9)#DarkGray#$($L.s9_1)| $($L.s9_2): #", '& Set-Event-Logs | -CheckState EventLogs',        #  [7] = Журналы событий  · · · · | Журналы: Включено 310 шт | Служба: Авто
                                   " #DarkGray#| $($L.s9_3): #", '& Check-State-Service | -ServiceName EventLog -Default Automatic -Need Disabled' # | Служба

        8 = "#Cyan#   [8]# = $($L.s10)#DarkGray#$($L.s10_1)| UAC: #", '& Set-UAC | -CheckState UAC'                           #  [8] = Контроль учётных записей | UAC: АвтоСоглашение | Настроен через панель управления
        9 = "#Cyan#   [9]# = $($L.s11)#DarkGray#$($L.s11_1)| $($L.s11_2) MyRegIdleBackup: #",                                 #  [9] = Резервирование Реестра · | Задача MyRegIdleBackup: Включена
                                       '& Check-State-Task | -TaskName "\Microsoft\Windows\Registry\MyRegIdleBackup" -Default Enabled -Need Enabled'


     10 = "`n#Cyan#  [10]# = $($L.s12)#DarkGray#$($L.s12_1)| $($L.s12_2)#"                                                    # [10] = Папки пользователя · · · | Меню изменения расположения (Мои Документы, Музыка и т.д.)
       11 = "#Cyan#  [11]# = $($L.s13)#DarkGray#$($L.s13_1)|# ", '& Move-Temp-Folders | -CheckState User',                    # [11] = Папка Temp: Пользователя | Изменена | C:\Temp2 | Папка существует, Ссылка: Создана | C:\Temp2
                                     "#DarkGray#, $($L.s13_2): #", '& Move-Temp-Folders | -CheckSymLink User'   # Ссылка
       12 = "#Cyan#  [12]# = $($L.s14)#DarkGray#$($L.s14_1)|# ", '& Move-Temp-Folders | -CheckState System',                  # [12] = Папка Temp: Системы  · · | По умолчанию | %SystemRoot%\TEMP | Папка существует, Ссылка: Не нужна
                                     "#DarkGray#, $($L.s14_2): #", '& Move-Temp-Folders | -CheckSymLink System' # Ссылка
       13 = "#Cyan#  [13]# = $($L.s15)#DarkGray#$($L.s15_1)| $($L.s15_2): #",                                                 # [13] = Запрет запуска Exe · · · | Заблокировано файлов: 2
                                      '& Set-Lock-FilesExe | -CheckState LockedCount'

     14 = "`n#Cyan#  [14]# = $($L.s16)#DarkGray#$($L.s16_1)| $($L.s16_2)#"                                                    # [14] = Управление Apps/Appx · · | Скачивание/Установка/Перерегистрация/Удаление Модерн Приложений
       15 = "#Cyan#  [15]# = $($L.s17)#DarkGray#$($L.s17_1)| $($L.s17_2): #",                                                 # [15] = Звуковой профиль · · · · | Профиль: По умолчанию
                                        '& Set-Sound-VolumeDown | -CheckState AudioProfile'
       16 = "#Cyan#  [16]# = $($L.s18)#DarkGray#$($L.s18_1)| $($L.s18_2)#"                                                    # [16] = Компоненты/Возможности · | Настройка Дополнительных Компонентов и Возможностей

     17 = "`n#Cyan#  [17]# = $($L.s19)#DarkGray#$($L.s19_1)| $($L.s19_2)#"                                                    # [17] = Файловые ассоциации  · · | Настройка файловых ассоциаций, протоколов и регистрация Portable программ

     20 = "`n#Cyan#  [$($L.s30)]# = #DarkGray#$($L.s30_1)#`n"   # Без ввода = Возврат в Главное Меню
    
    }

    Selection = @{

        1 = "    ► $($L.s3)",    '$Menu_Set_Windows_Defender'    # Защитник
        2 = "    ► $($L.s4)",    '$Menu_Set_Boot_Optimization'   # Оптимизация загрузки
        3 = "    ► $($L.s5)",    '$Menu_Set_Windows_Search'      # Поиск, Кортана, Индексирование

        4 = "    ► $($L.s6)",    '$Menu_Set_Network_Settings'    # Сеть
        5 = "    ► $($L.s7)",    '$Menu_Set_Explorer_Settings'   # Проводник

        6 = "    ► $($L.s8)",    '$Menu_Set_Photo_Viewer'        # Просмотр фотографий Windows
        7 = "    ► $($L.s9)",    '$Menu_Set_Event_Logs'          # Журналы событий
        8 = "    ► UAC",         '$Menu_Set_UAC'                 # Контроль учётных записей
        9 = "    ► $($L.s11)",   '$Menu_Set_Registry_BackUp'     # Задача резервного копирования реестра

       10 = "    ► $($L.s12)",   '$Menu_Move_User_Folders'       # Папки пользователя
       11 = "    ► $($L.s13)",   '$Menu_Move_Temp_User'          # Папка Temp Пользователя
       12 = "    ► $($L.s14)",   '$Menu_Move_Temp_System'        # Папка Temp Системная
       13 = "    ► $($L.s15)",   '$Menu_Set_Lock_FilesExe'       # Запрет запуска Exe файлов

       14 = "    ► $($L.s16)",   '$Menu_Set_Apps_Management'     # Управление Apps/Appx
       15 = "    ► $($L.s17)",   '$Menu_Set_Sound_VolumeDown'    # Управление Звуковым профилем
       16 = "    ► $($L.s18)",   '$Menu_Features_Capabilities'   # Настройка Дополнительных Компонентов и Возможностей

       17 = "    ► $($L.s19)",   '$Menu_Set_Program_Association' # Настройка файловых ассоциаций

   'Exit' = "  ◄◄◄ $($L.s30_1)", '$MainMenu'                     # Возврат в Главное Меню

    }
}