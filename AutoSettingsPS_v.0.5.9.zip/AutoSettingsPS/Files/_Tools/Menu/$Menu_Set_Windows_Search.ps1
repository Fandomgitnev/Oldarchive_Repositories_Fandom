﻿
$Menu_Set_Windows_Search = @{

    Info =  @{

        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1) | #Yellow#$($L.s1_2) #DarkGray#| $($L.s1_3)#" # Поиск, Индексирование | Ускоряет поиск в Windows | Кортана | Поиск в Интернет и Cинхронизация
        3 = "      #DarkGray#$($L.s2)#"   # Индексирование собирает и обновляет локальный каталог всех ваших файлов. Кортана собирает все в 'Облаке'
        4 = "      #Blue#$($L.s3)#"       # Служба поиска нужна для Архивации файлов и Службы общих сетевых ресурсов проигрывателя Windows Media
        5 = "      #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#' # Список настроек можно изменить в файле пресетов, текущий файл:
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        1 = "      $($L.s5  ): ", '& Check-State-Service | -ServiceName WSearch -Default DelayedAuto -Need Disabled', # Служба Поиска WSearch
            "      $($L.s5_1): ", '& Set-Windows-Search  | -CheckState Cortana'        # Кортана

        2 = "      $($L.s6  ): ", '& Set-Windows-Search  | -CheckState IndexPackage',  # Компонент индекс-ия
            "      $($L.s6_1): ", '& Set-Windows-Search  | -CheckState CortanaWeb'     # Поиск в Сети

        3 = "      $($L.s7  ): ", '& Check-State-Task    | -TaskName "\Microsoft\Windows\Shell\IndexerAutomaticMaintenance" -Default Enabled -Need Disabled', # Задача индекс-ия
            "      $($L.s7_1): ", '& Set-Windows-Search  | -CheckState CortanaTaskBar'                                  # Иконка на таскбаре
        4 = "                                           $($L.s8_1): ", '& Set-Windows-Search | -CheckState HideCortana' # Отображение в Настройках

      5 = "`n      #DarkGray#$($L.s9):#`n" # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s10) #DarkGray#| $($L.s10_1)   #DarkMagenta#◄#Magenta# [11]# = #Magenta#$($L.s10_2) #DarkGray#| $($L.s10_3)#" # [1] = Отключить индексирование | Только Компонент              ◄ [11] = Включить | По умолчанию
        2 = "#Cyan#  [2]# = $($L.s11) #DarkGray#| $($L.s11_1)   #DarkMagenta#◄#Magenta# [12]# = #Magenta#$($L.s11_2) #DarkGray#| $($L.s11_3)#" # [2] = Отключить службу поиска  | Только службу WSearch         ◄ [12] = Включить | По умолчанию
        3 = "#Cyan#  [3]# = $($L.s12) #DarkGray#| $($L.s12_1)   #DarkMagenta#◄#Magenta# [13]# = #Magenta#$($L.s12_2) #DarkGray#| $($L.s12_3)#" # [3] = Отключить Кортану        | И скрыть иконку на таскбаре   ◄ [13] = Включить | По умолчанию
        4 = "#Cyan#  [4]# = $($L.s13) #DarkGray#| $($L.s13_1)   #DarkMagenta#◄#Magenta# [14]# = #Magenta#$($L.s13_2) #DarkGray#| $($L.s13_3)#" # [4] = Настроить Индекс Windows | Согласно файлу пресета        ◄ [14] = Включить | По умолчанию

   5 = "`n#Magenta#  [99]# = #Magenta#$($L.s14) #DarkGray#| $($L.s14_1)#" # [99] = Восстановить всё | По умолчанию

      6 = "`n#Cyan#  [$($L.s15)]# = #DarkGray#$($L.s15_1)#`n"             # [Без ввода] = Возврат в меню Личных Настроек
    }

    Selection = @{

        1 = '& Set-Windows-Search | -Options IndexDisable   -Act Set -ApplyGP'
        2 = '& Set-Windows-Search | -Options WSearchDisable -Act Set -ApplyGP'
        3 = '& Set-Windows-Search | -Options CortanaDisable -Act Set -ApplyGP'
        4 = '& Set-Windows-Search | -Options IndexSettings  -Act Set -ApplyGP'

       11 = '& Set-Windows-Search | -Options IndexDisable   -Act Default -ApplyGP'
       12 = '& Set-Windows-Search | -Options WSearchDisable -Act Default -ApplyGP'
       13 = '& Set-Windows-Search | -Options CortanaDisable -Act Default -ApplyGP'
       14 = '& Set-Windows-Search | -Options IndexSettings  -Act Default -ApplyGP'

       99 = '& Set-Windows-Search | -Options IndexDisable,WSearchDisable,CortanaDisable -Act Default -ApplyGP'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
