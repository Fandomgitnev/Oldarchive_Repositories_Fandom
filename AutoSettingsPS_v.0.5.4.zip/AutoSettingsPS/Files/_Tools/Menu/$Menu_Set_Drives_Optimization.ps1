﻿
$Menu_Set_Drives_Optimization = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      $($L.s1) #Yellow#$($L.s1_1) #Green#SSD# $($L.s1_2) #Cyan#HDD# $($L.s1_3) #DarkGray#$($L.s1_4)#" # Настройка Раздельной Оптимизации SSD и HDD дисков. Для предотвращения дефрагментации SSD
        3 = "      #DarkGray#$($L.s2) #White#$($L.s2_1)#"                       # Раздельные задачи будут выполняться вместо задачи ScheduledDefrag, при Автообслуживании Windows
        4 = "      #DarkGray#$($L.s3) #Blue#$($L.s3_1)#DarkGray#: $($L.s3_2)#"  # Или Самостоятельно: TRIM для SSD дисков раз в 3 дня, а дефрагментация HDD дисков раз в неделю
        5 = "      #DarkGray#$($L.s4)#"                                         # Определение дисков может идти медленно, если они отключаются при простое
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s5): #"  # Задачи
        1 = '      ScheduledDefrag#DarkGray#: #', '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\ScheduledDefrag" -CheckMaintenance',
                                                  '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\ScheduledDefrag" -Default Enabled -Need Disabled',

                 '        SSD-Trim#DarkGray#: #', '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\SSD-Trim" -CheckMaintenance',
                                                  '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\SSD-Trim" -Default Enabled -Need Enabled',

               '        HDD-Defrag#DarkGray#: #', '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\HDD-Defrag" -CheckMaintenance',
                                                  '& Check-State-Task | -TaskName "\Microsoft\Windows\Defrag\HDD-Defrag" -Default Enabled -Need Enabled'

      2 = "`n      #DarkGray#$($L.s6):#"  # Локальные диски

        3 = '& Set-Drives-Optimization | -CheckState ShowLocalDrives'

        4 = ''
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s7 ): #Green#SSD-Trim# + #Cyan#HDD-Defrag #DarkGray#| $($L.s7_1)#"  # Создать раздельные задачи оптимизации дисков: SSD-Trim + HDD-Defrag | Только при Автообслуживании
        2 = "#Cyan#  [2]# = $($L.s8 ): #Green#SSD-Trim#              #DarkGray#| $($L.s8_1)#"          # Создать одну отдельную задачу для SSD дисков: SSD-Trim              | Только при Автообслуживании

      3 = "`n#Cyan#  [3]# = $($L.s9 ): #Green#SSD-Trim# + #Cyan#HDD-Defrag #DarkGray#| #Blue#$($L.s9_1) #DarkGray#$($L.s9_2)#"  # Создать раздельные задачи оптимизации дисков: SSD-Trim + HDD-Defrag | Независимые от Автообслуживания
        4 = "#Cyan#  [4]# = $($L.s10): #Green#SSD-Trim#              #DarkGray#| #Blue#$($L.s10_1) #DarkGray#$($L.s10_2)#"        # Создать одну отдельную задачу для SSD дисков: SSD-Trim              | Независимую от Автообслуживания

   5 = "`n#Magenta#  [5]# = #Magenta#$($L.s11) #DarkGray#| $($L.s11_1)#" #  Восстановить | По умолчанию. Включить/Создать задачу 'ScheduledDefrag' и удалить остальные

      6 = "`n#Cyan#  [6]# = $($L.s12) #White#dfrgui.exe #DarkGray#| $($L.s12_1)#" # Запустить системную утилиту: dfrgui.exe  | Ручная оценка и/или оптимизация дисков
        7 = "#Cyan#  [7]# = $($L.s13) #White#defrag.exe #DarkGray#| $($L.s13_1)#" # Журнал обслуживания дисков:  defrag.exe  | Выводит историю обслуживания дисков для информации

      8 = "`n#Cyan#  [8]# = #Magenta#$($L.s14) #White#$($L.s14_1)# #Green#$($L.s14_2)# $($L.s14_3) #DarkGray#| #", '& Set-Drives-Optimization | -CheckState ShowSSD' # Выполнить TRIM SSD дисков
        9 = "#Cyan#  [9]# = #Magenta#$($L.s15) #White#$($L.s15_1)# #Cyan#$($L.s15_2 )# $($L.s15_3) #DarkGray#| #", '& Set-Drives-Optimization | -CheckState ShowHDD' # Выполнить Дефрагментацию HDD дисков

   #  7 = "`n#Cyan# [20]# = Включить задачу #White#SSD-Trim           #Magenta# [120]# = #Magenta#Отключить# задачу #White#SSD-Trim#"
   #    8 = '#Cyan# [21]# = Включить задачу #White#HDD-Defrag         #Magenta# [121]# = #Magenta#Отключить# задачу #White#HDD-Defrag#'
   #    9 = '#Cyan# [22]# = Включить задачу #White#ScheduledDefrag    #Magenta# [122]# = #Magenta#Отключить# задачу #White#ScheduledDefrag#'

     10 = "`n#Cyan#  [$($L.s16)]# = #DarkGray#$($L.s16_1)#`n"  # Без ввода = Возврат в меню Обслуживания
    }

    Selection = @{

        1 = '& Set-Drives-Optimization | -Option CreateTasks -Act Set'
        2 = '& Set-Drives-Optimization | -Option CreateTasks -Act Set -TaskOnlySSD'

        3 = '& Set-Drives-Optimization | -Option CreateTasks -Act Set -WithoutMaintenance'
        4 = '& Set-Drives-Optimization | -Option CreateTasks -Act Set -TaskOnlySSD -WithoutMaintenance'

        5 = '& Set-Drives-Optimization | -Option CreateTasks -Act Default'

        6 = '& Set-Drives-Optimization | -Option RunDfrGui    -Act Set'
        7 = '& Set-Drives-Optimization | -Option ShowEventLog -Act Set'

        8 = '& Set-Drives-Optimization | -Option RunTRIM   -Act Set'
        9 = '& Set-Drives-Optimization | -Option RunDefrag -Act Set'

  #    20 = '& Set-Drives-Optimization | -Option EnableTaskTRIM       -Act Set'
  #    21 = '& Set-Drives-Optimization | -Option EnableTaskDefrag     -Act Set'
  #    22 = '& Set-Drives-Optimization | -Option EnableOrigTaskDefrag -Act Set'

  #   120 = '& Set-Drives-Optimization | -Option DisableTaskTRIM       -Act Set'
  #   121 = '& Set-Drives-Optimization | -Option DisableTaskDefrag     -Act Set'
  #   122 = '& Set-Drives-Optimization | -Option DisableOrigTaskDefrag -Act Set'

   'Exit' = "  ◄◄◄ $($L.s16_1)", '$Menu_Set_Windows_Maintenance'  # Возврат в меню Обслуживания

    }
}
