﻿
$Menu_Get_AutoSettingsPS_Update = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "     #Yellow#$($L.s1) #DarkGray#| #Yellow#$($L.s1_1)#"  # Скачать скрипт AutoSettingsPS | Пресеты HARD
        3 = "     #DarkGray#$($L.s2)#"    # Сохраняет в папку "Загрузки" текущего пользователя. Закачка по доступности с Google drive и/или Yandex Disk
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "     #DarkGray#$($L.s3): #white#$AutoSettingsVersion#",               # 0.5.0
                      "#DarkGray#$($L.s3_1): #", '& Test-Internet | -Access -Menu' # Интернет: OnLine (+ PS Доступ)

      1 = "`n     #DarkGray#$($L.s4):#"   # Варианты для выбора
        2 = ''
    }

    Options = @{

        1 = "#Cyan# [1]# = $($L.s5) #DarkGray#| $($L.s5_1)     #DarkCyan#◄#Cyan# [10]# = $($L.s5_2)#"   # [1] = Скачать новую версию | AutoSettingsPS*.zip                            ◄ [10] = Скачать последнюю версию
        2 = "#Cyan# [2]# = $($L.s6) #DarkGray#| $($L.s6_1)#"                                            # [2] = Скачать Пресеты      | QuickPresets_Hard*.txt / Presets_Hard*.txt
        
      3 = "`n#Cyan# [3]# = $($L.s7) #DarkGray#| $($L.s7_1)#"                                            # [3] = Проверить все файлы  | AutoSettingsPS*.zip / QuickPresets_Hard*.txt / Presets_Hard*.txt

      4 = "`n#Cyan# [$($L.s8)]# = #DarkGray#$($L.s8_1)#`n"     # [Без ввода] = Возврат в Главное Меню
    }

    Selection = @{

        1 = '& Get-AutoSettingsPS-Update'
        2 = '& Get-AutoSettingsPS-Update | -Presets'
       10 = '& Get-AutoSettingsPS-Update | -LatestASPS'

        3 = '& Get-AutoSettingsPS-Update | -OnlyCheck -NoPause', '& Get-AutoSettingsPS-Update | -OnlyCheck -Presets'

   'Exit' = "  ◄◄◄ $($L.s8_1)", '$MainMenu'           # Возврат в Главное Меню

    }
}
