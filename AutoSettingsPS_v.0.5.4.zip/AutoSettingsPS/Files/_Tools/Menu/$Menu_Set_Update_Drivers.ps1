﻿
$Menu_Set_Update_Drivers = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1) #DarkGray#| $($L.s1_1)#"  # Обновления Драйверов | Отключить или Заблокировать
        3 = "      #DarkGray#$($L.s2) #White#$($L.s2_1)#"     # Первый пункт меню [1] официальный и действует только при Автообновлении Windows!
        4 = "      #Blue#$($L.s3)"                            # И драйвера обновятся, если нажать кнопку 'Проверка наличия обновлений' или если MS считает необходимым!
        5 = ''
        6 = "      #DarkGray#$($L.s4)#"                       # Блокировка возможности у ЦО на поиск драйверов, изменением системных параметров и прав на их изменение
        7 = "      #DarkGray#$($L.s5)#"                       # После разблокировки, для поиска драйвера через ЦО надо удалить или обновить драйвер устройства вручную
        8 = ' #DarkGray#======================================================================================================================#'
        9 = ''
    }

    Status = @{

        1 = "      $($L.s6): ", '& Set-Update-Drivers | -CheckState DriversLoad',          # Драйвера
                    "   $($L.s6_1): ", '& Set-Update-Drivers | -CheckState MetaDataLoad'   # Получение Метаданных

        2 = "      $($L.s7): ", '& Set-Update-Drivers | -CheckState DriversSearch',        # Поиск Драйверов
                    "   $($L.s7_1): ", '& Set-Update-Drivers | -CheckState SearchOrder'    # Порядок Поиска

        3 = "      $($L.s8): ", '& Set-Update-Drivers | -CheckState DriversPriority',      # Приоритет Установки
                    "   $($L.s8_1): ", '& Set-Update-Drivers | -CheckState DriversReports' # Отчеты

      # 4 = "      $($L.s9): ", '& Set-Update-Drivers | -CheckState MasterUpdate'          # Мастер Обновления устаревший

      5 = "`n      $($L.s10): ", '& Set-Update-Drivers | -CheckState DriversIdentifyLock'  # Возможность Определения
        6 = "      $($L.s11): ", '& Set-Update-Drivers | -CheckState DriversSearchLock'    # Возможность Поиска

      7 = "`n      #DarkGray#$($L.s12):#`n" # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s13) #White#$($L.s13_1) #DarkGray#| $($L.s13_2)#"  #  [1] = Отключить Автоустановку драйверов    | Не влияет, если MS считает установку необходимой
        2 = "#Cyan#  [2]# = $($L.s14) #Green#$($L.s14_1) #DarkGray#| $($L.s14_2)#"  #  [2] = Отключить Автоустановку + Блокировка | Отключить + Заблокировать возможность поиска и обновления

   3 = "`n#Magenta# [99]# = #Magenta#$($L.s15) #DarkGray#| $($L.s15_1)#"            # [99] = Восстановить всё | По умолчанию

      4 = "`n#Cyan# [$($L.s16)]# = #DarkGray#$($L.s16_1)#`n"                        # [Без ввода] = Возврат в Меню Центр Обновления
    }

    Selection = @{

        1 = '& Set-Update-Drivers | -Act Set -Option Disable -ApplyGP'
        2 = '& Set-Update-Drivers | -Act Set -Option Lock -ApplyGP'

       99 = '& Set-Update-Drivers | -Act Default -ApplyGP'

   'Exit' = "  ◄◄◄ $($L.s16_1)", '$Menu_Set_Update_Windows' # Возврат в Меню Центр Обновления

    }
}
