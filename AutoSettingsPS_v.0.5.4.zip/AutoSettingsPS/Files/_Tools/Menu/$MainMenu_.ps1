﻿
# $MainMenu - Главное меню, с которого все начинается. Перевод из $Lang.$MainMenu.s[]

$MainMenu = @{

    Info =  @{

      # 0 = ''
        1 = '#DarkGray# ══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════#'
        2 = "#DarkGray#        $($L.s1): #White#Windows 10 #DarkGray#| #Green#x64#DarkGray#/#Green#x86 #DarkGray#| #Gray#1809 - 2009 #DarkGray#| v17763 - v22622#" # Настройка Windows 10 | x64/x86 | 1809 - 2009 | v17763 - v22622
        3 = '#DarkGray# ══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════#'
        4 = ''
    }

    Status = @{

        1 = "        $($L.s2): #Green#$ArchOS", '#DarkGray# | #Green# & Get-LangOS',       # Ваша Windows ...
                                '#DarkGray# | #Green# & Get-VersOS', '.#white# & Get-RevisionOS', '#DarkGray# | #Green# & Get-NameOS#'

      2 = "`n        #DarkGray#$($L.s3): ", '& Highlight-Problem-Symbols | $CurrentRoot'   # Папка

      3 = "`n        #DarkGray#$($L.s3_1): #white#$([System.IO.Path]::GetFileName($(Get-Preset -File $FilePresetsGlobal)))#"        # Presets
        4 = "        #DarkGray#$($L.s3_2): #white#$([System.IO.Path]::GetFileName($(Get-Preset -File $FileQuickPresetsGlobal)))#"   # QuickPresets
        5 = "        #DarkGray#$($L.s3_3): $(Get-HtmlLog)#"            # Log
        6 = "        #DarkGray#$($L.s3_4): #", '& Show-Selected-Users' # Аккаунт

      7 = "`n        #DarkGray#$($L.s4):        $UnsupportedOS#`n"     # Варианты для выбора
    }

    Options = @{

        0 = "#Cyan#    [0]# = #Yellow#Quick Settings #DarkGray#| $($L.s5)#`n"  #   [0] = Quick Settings | Меню Применения или Восстановления всех настроек По умолчанию | QuickPresets*.txt

        1 = "#Cyan#    [1]# = #Yellow#Configs-Checks #DarkGray#| $($L.s6)#`n"  #   [1] = Configs-Checks | Меню Применения, Проверки или Восстановления всех Важных настроек  | Presets*.txt

        2 = "#Cyan#    [2]# = #Yellow#SelfMenu #DarkGray#| $($L.s7)#`n"        #   [2] = SelfMenu | Меню Личных настроек Windows

        3 = "#Cyan#    [3]# = #Yellow#$($L.s8) #DarkGray#| $($L.s8_1)#"        #   [3] = Групповые Политики | Меню Применения или сброса Групповых Политик
        4 = "#Cyan#    [4]# = #Yellow#$($L.s9) #DarkGray#| $($L.s9_1)#"        #   [4] = Центр Обновления   | Меню Управления Центром Обновления Windows и драйверов
        5 = "#Cyan#    [5]# = #Yellow#$($L.s10) #DarkGray#| $($L.s10_1)#"      #   [5] = Обслуживание       | Меню Управления и выполнения Обслуживания Windows

      6 = "`n#Blue#  [100]# = #Blue#$($L.s11) #DarkGray#| $($L.s11_1)#"        # [100] = Перезагрузить Windows | Принудительно

   7 = "`n#Magenta#  [999]# = #Magenta#$($L.s20) #DarkGray#| $($L.s20_1)#"     # [999] = Восстановление | Меню Восстановления всех настроек разом По умолчанию

      8 = "`n#Cyan#  [$($L.s30)]# = #DarkGray#$($L.s30_1) #DarkCyan#[+]# = #DarkCyan#$($L.s30_2) #DarkGray#| $($L.s30_3) $(Get-Presets-Version)#`n"   # [Без ввода] = Выход          [+] = Скачать ASPS | Версия ...
    }

    Selection = @{

         0 = '    ► Quick Settings', '$Menu_Run_QuickSettings'

         1 = '    ► Configs-Checks', '$Menu_Run_Configs'

         2 = '    ► SelfMenu',       '$Menu_SelfMenu'

         3 = "    ► $($L.s8)",       '$Menu_Set_Group_Policy'           # Групповые Политики
         4 = "    ► $($L.s9)",       '$Menu_Set_Update_Windows'         # Центр Обновления
         5 = "    ► $($L.s10)",      '$Menu_Set_Windows_Maintenance'    # Обслуживание

       100 = "    ► $($L.s11)",      '& Restart-Computer | -Force'      # Перезагрузить Windows

       999 = "    ► $($L.s20)",      '$Menu_Run_QuickSettingsDefault'   # Восстановление

       '+' = "    ► $($L.s30_2)",    '$Menu_Get_AutoSettingsPS_Update'  # Скачать ASPS/Пресеты

    'Exit' = "$($L.s30_1)", 'Exit'  # Выход

    }
}
