﻿
$Menu_Move_Temp_User = @{

    Info =  @{

      # 0 = ''
        1 = ' #DarkGray#======================================================================================================================#'
        2 = "      #Yellow#$($L.s1)# $($L.s1_1) #DarkGray#$($L.s1_2) #White#$($L.s1_3): #",'& Show-Selected-Users | -OnlyUsers'  # Изменение расположения папки Temp для текущего пользователя
        3 = "      #DarkGray#$($L.s2) #Blue#$($L.s2_1)#DarkGray#$($L.s2_2)#"                                    # Возможность создания символической ссылки, вместо папки по умолчанию, для совместимости
        4 = "      #Magenta#$($L.s3) #DarkGray#$($L.s3_1)#"                                                     # Завершите все программы перед выполнением! Можно указать одно расположение с системной папкой Temp
        5 = "      #DarkGray#$($L.s4): #", '#White#& Run-Configs | -CheckState CurrentPreset#'                  # Свое расположение можно задать в файле пресетов, текущий файл
        6 = ' #DarkGray#======================================================================================================================#'
        7 = ''
    }

    Status = @{

        0 = "      #DarkGray#$($L.s5):#"     # В данный момент
        1 = "      $($L.s6): ", '& Move-Temp-Folders | -CheckState User'   # Папка Temp
        2 = "      $($L.s7): ", '& Move-Temp-Folders | -CheckSymLink User' # Символ. ссылка

      3 = "`n      #DarkGray#$($L.s8):#`n"   # Варианты для выбора
    }

    Options = @{

        1 = "#Cyan#  [1]# = $($L.s9) #DarkGray#$($L.s9_1): ", '& Move-Temp-Folders | -CheckPreset User'  # Изменить на
        2 = "#Cyan#  [2]# = $($L.s9) #DarkGray#$($L.s9_1): ", '& Move-Temp-Folders | -CheckPreset User', # Изменить на
                            " #DarkGray#| $($L.s9_2) #Blue#$($L.s9_3) #DarkGray#$($L.s9_4): #Yellow#%USERPROFILE%\AppData\Local\#Blue#Temp#"  # И сделать ссылку вместо

   3 = "`n#Magenta#  [3]# = #Magenta#$($L.s10) #DarkGray#| $($L.s10_1) #White#%USERPROFILE%\AppData\Local\Temp #DarkGray#| $($L.s10_2)#"  # Восстановить | в ... | По умолчанию

      4 = "`n#Cyan#  [$($L.s11)]# = #DarkGray#$($L.s11_1)#`n"  # Без ввода, Возврат в меню Личных Настроек
    }

    Selection = @{

        1 = '& Move-Temp-Folders | -Target User'
        2 = '& Move-Temp-Folders | -Target User -SymLink'
        3 = '& Move-Temp-Folders | -Target User -Default'

   'Exit' = '  ◄◄◄ SelfMenu', '$Menu_SelfMenu'

    }
}
