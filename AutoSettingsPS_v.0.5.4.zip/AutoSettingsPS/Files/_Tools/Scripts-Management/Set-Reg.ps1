﻿
<#
.SYNOPSIS
 Внесение параметров в реестр и/или их проверка.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.

 Используется функция Token-Impersonate для олицетворения за System/TrustedInstaller, если нет доступа для выполнения.
 Используется функция Set-OwnerAndAccess для получения и возврата доступа, если не помогло олицетворение и нет разрешающих правил.
 Восстановления доступа не будет, если нет доступа на чтение параметров доступа, тогда будет получен и оставлен доступ.
 Используется функция RegHives-User-LoadUnload для подгрузки кустов других юзеров при необходимости.

 Выполняет команды или делает проверку параметра,
 через методы в RegistryKey [Microsoft.Win32.Registry] из .NET,
 так как это быстрее минимум в 28 раз, чем стандартными командлетами и есть дополнительные возможности.
 После выполнения действия открытые разделы закрываются, чтобы не блокировало выгрузку кустов.

 Функция интерпретирует параметры для командлетов:
 "Set-Item", "Set-ItemProperty", "New-Item", "New-ItemProperty", "Remove-Item", "Remove-ItemProperty",
 "Rename-ItemProperty"

 Сохранена возможность исключения родительского раздела через '\*' для Remove-Item.
 Но в других случаях нельзя использовать маски *, будет понят буквально,
 и все фильтры и т.д.
 Любые хитрые варианты используем оригинальными командлетами, или вызываем функцию в нужных местах в своем алгоритме.

 Добавлено понимание создания или удаления параметра (По умолчанию) в разделах.
 Если указать имя с пустой строкой '', или вообще не указать имя,
 то будет интерпретировано как необходимость выполнения действия над параметром (По умолчанию).

 Добавлено понимание создания правильных значений параметров, при указании пустых строк у значений.
 или без значений вообще, для каждого типа свой.
 Например, если указать тип None или Binary, а значение для него с пустой строкой или не указать его вообще,
 то будет создано "Двоичное значение нулевой длины".
 Для MultiString можно просто указать значения для -Value через запятую, и т.д.
 То есть, если значения не приведены к типу, то будут приведены к правильному типу.

 Значения параметров из реестра выводятся в Десятичной системе исчисления (Decimal)!
 В реестре REG_BINARY записываются в Шестнадцатеричном виде (HEX) и также отображены в Редакторе реестра!
 Поэтому удобнее вносить параметры BINARY в виде HEX,
 пример: -Value ([byte[]]@(0x0,0x8e,0x8f))
    или: -Value 0x0,0x8e,0x8f  (будет преобразован тут в массив байт)

 Если передать 'строку' для Binary или None, она будет преобразована в массив по 2 символа с добавлением к ним '0x..' (формат HEX)
 Такой формат в .reg, то есть можно просто скопировать любое значение hex: из .reg файла.
 Или можно слитые HEX символы без запятых. С любыми переносами строк.
 То есть будет понимание .reg формата (hex:) с запятыми или '\', или пробелами с переносами строк.
 Эти 6 вариантов приведут к одному результату: (каждый может быть с переносами строк)
 Вариант 1: -value '14,00,8b,\
                    00,02'             # .reg hex:  с переносом строк и с '\'
 Вариант 2: -value '14,00,8b,\ 00,02'  # .reg hex:  с убранным переносом и с '\'
 Вариант 3: -value '14,00,8b,00,02'    # .reg hex:  без '\'
 Вариант 4: -value '14008b0002'        # слитые символы hex
 Вариант 5: -value 0x14,0x00,0x8b,0x00,0x02    # массив hex значений
 Вариант 6: [byte[]] $Value = 0x14,0x00,0x8b,0x00,0x02 ; -value $Value

 Для параметра Dword можно указывать в таком виде: 555, -555, '-555', 0xffffffff, '0xffffffff', ffffffff, ([Uint32]::MaxValue) <- это макс число

 Если раздела нет, то он будет создан, если нет доступа то будет выполнено олицетворение или получен временный доступ,
 если доступа нет ни какого, то будет получен и оставлен доступ.
 При любых вариантах будет создан параметр, исходя из переданных данных.
 Кроме случаев с блокированием разделов драйверами в системе.
 При создании раздела, если раздел уже существует, то раздел не будет заменяться, ни в каких случаях, кроме удаления.
 Все пути будут поняты буквально! Кроме указания пропуска дочернего раздела '\*'.

 Добавлены возможности: Применить, а затем проверить или только проверить.

 Понимает любой правильный тип раздела в $Path: ...Core\Registry::HK...\, Registry::HK...\, HKLM:\, HKCU:\

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать, не обязательный.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.PARAMETER NoCheck
 Указывает не делать проверку.
 Не будет вывода на экран результата, только выполнение действия.

.PARAMETER OnlyThisPath
 Запрещает перенаправления в другие кусты акканутов, настраивает только текущий указанный путь,
 даже если глобально задано настраивать другие аккаунты.
 
.INPUTS
 Строка с командой для стандартных определенных командлетов.

.EXAMPLE
    Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\0\111" -Name 'Вася' -Type None -Value ([byte[]]@(0x11,0x12))

    Описание
    --------
    Если $Act = 'Set', то попытается выполнить указанную команду,
    и при необходимости попытается решить проблему с доступом, при отсутствии раздела, создаст его.
    Создание параметра Binary REG_NONE
    С выводом результата, и скрытием ошибок при выполнении.
    Одинаковое поведение для New-ItemProperty и Set-ItemProperty

.EXAMPLE
    Set-Reg New-ItemProperty -Path "HKLM:\SOFTWARE\0\111" -Type Dword -Value 55

    Описание
    --------
    Попытается выполнить указанную команду, создание значения в разделе для параметра "По умолчанию" = '(default)'
    и при необходимости попытается решить проблему с доступом, а при отсутствии раздела, создаст его.
    С выводом результата, и скрытием ошибок при выполнении.
    Одинаковое поведение для New-ItemProperty и Set-ItemProperty

.EXAMPLE
    Set-Reg -Do Set New-Item -Path "Registry::HKEY_CLASSES_ROOT\0\111"

    Описание
    --------
    Попытается выполнить указанную команду,
    и при необходимости попытается решить проблему с доступом к этому разделу или родительскому разделу.
    С выводом результата, и скрытием ошибок при выполнении.
    Если раздел существует, не будет его пересоздавать.

.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 1.0
       Дата:  02-10-2018
 ==================================================

#>
Function Set-Reg {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 0 )]
        [ValidateSet( 'Set-Item', 'Set-ItemProperty', 'New-Item', 'New-ItemProperty',
                      'Remove-Item', 'Remove-ItemProperty', 'Rename-ItemProperty' )]
        [string] $Cmdlet
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, Position = 1 )]
        [Alias( 'LiteralPath' )]
        [string] $Path
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 2 )]
        $Name   # Без типа, чтобы была возможность наличия и $null и пустой строки '' и др.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 3)]
        [ValidateSet( 'String', 'ExpandString', 'MultiString', 'DWord', 'QWord', 'Binary', 'None', 'Unknow' )]
        [Alias( 'PropertyType', 'ItemType' )]
        [string] $Type = 'Unknow'
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 4 )] $Value, # Без типа, чтобы была возможность наличия и $null и пустой строки '' и др.
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )] [string] $NewName,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )] [switch] $Recurse,  # Ни на что не влияет, только чтобы не выкидывало ошибки.
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )] [switch] $Force     # Ни на что не влияет, но выполняется как с ним.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $NoCheck
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [string] $ShowAction
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $OnlyThisPath
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( $Do -eq 'Default' ) { $Do = 'Set' }

        # Перехват ошибок, только прерываемых исключений, в блоке Begin, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionREG'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Если передана строка с переданными параметрами для отображения, то выводить её, чтобы был один вид отображения при одновременной настройке разных акков 
        if ( $ShowAction )
        {
            $ActionREG    = $ShowAction
            $OnlyThisPath = $true

            if ( $ActionREG -like '*#DarkCyan#*' ) { [int] $Length = 278 } else { [int] $Length = 258 }
        }
        else
        {
            # Получение команды действия для отображения через функцию Show-Result, или при необходимости в Verbose.
            # Выполняется чистка лишних данных, и замена переданных переменных на значения из этих переменных. Для $Value отображение ограничено 60 символами.
            [hashtable] $Params = $MyInvocation.BoundParameters

            [string] $GetValueForDisplay = $Params['Value'] -replace '[\r\n]',''
            
            [string] $ActionREG = ($MyInvocation.Line.Replace($NameThisFunction,'').Replace('-Cmdlet', '') -Replace '(\s*-Do[:]?\s*[^\s]*\s*)',' '
                      ).Replace('$Path', "'$Path'"
                      ).Replace('$Name', "'$Name'"
                      ).Replace('$Type', "$Type"
                      ).Replace('$Value',"'$GetValueForDisplay'").Trim()

            if ( $OnlyThisPath )
            {
                # Сокращение SID и выделение его цветом 
                $PathShow = ($Path -replace ('Registry::HKU\\S-1-5-21-[\d]+-[\d]+-[\d]+([^\\]+)(.+)','#DarkCyan#HKU\*$1#DarkGray#$2')).Replace('HKU\*-5','HKU\**-5')
                $ActionREG = $ActionREG.Replace($Path,$PathShow).Replace(' -OnlyThisPath', '')
            }

            if ( $ActionREG -like '*#DarkCyan#*' ) { [int] $Length = 278 } else { [int] $Length = 258 }
        }

        if ( $ActionREG.Length -gt $Length ) { $ActionREG = "$($ActionREG.Substring(0,$Length)) ...'" }


        Write-Verbose "Команда:`n $ActionREG"

        if ( -not $NoCheck )
        {
            # Создаем хэш-таблицу $ShowResult,
            # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
            Set-Variable -Name ShowResult -Value ([hashtable] @{}) -Force
            $ShowResult['Do']   = $Do
            $ShowResult['Type'] = '{0}' -f $(if ( $L.s2 ) { $L.s2 } else { "Реестр" })
            $ShowResult['Info'] = $ActionREG
        }

        # Обработка, получение, проверка и/или применение параметров разделены на 3 части,
        # так общая скорость выполнения в среднем быстрее в 2,5 раза. З часть - это само применение и/или проверка.

        # Первая часть
        # Обработка переданных параметров

        # Обнуляем важные дополнительные переменные, на всякий случай
        [psobject] $isAccessDenied = $isOpenKey = $isValue = $isType = $isZerolength = $ValueExist = $Zerolength = $ChildPath = $Exit = $null ; $OFS = ' '

        # Если передано имя '(default)', то имеется в виду параметр "По умолчанию" в разделе, тогда обнуление имени для указания функции на этот параметр
        if ( $Name -eq '(default)' ) { $Name = $null }

        if (( $Cmdlet -eq 'Rename-ItemProperty' ) -and ( $Name -eq $NewName ))
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Нельзя указывать одинаковые имена при переименовке!" }
            Write-Warning "$NameThisFunction`: $text" ; $Exit = $true ; Return   # Выходим из функции, переходя по всем блокам
        }

        # Если для командлета New-Item передали имя, то соединяем его с путем и очищаем имя, так как оно создает раздел
        # А для Remove-Item нет параметра Name, имя будет проигнорировано для исправления критической ошибки написания, если будет указано имя
        if     (( $Cmdlet -eq 'New-Item'    ) -and  $Name ) { $Path = "$Path\$Name" ; $Name = $null }
        elseif (( $Cmdlet -eq 'Remove-Item' ) -and  $Name ) { $Name = $null }

        # Получение корневого раздела и поддиректории для методов RegistryKey (.NET), таких как OpenSubKey.
        # Понимает любой тип правильного пути.
        if ( $Path -match "(?<Root>Registry::HK[\w]+\\|HKLM:\\|HKCU:\\)(?<Subkey>[^\s][^\r\n]+[^\s])" )
        {
            [string] $Root   = $matches.Root
            [string] $SubKey = $matches.Subkey

            if     ( $Root -like "*HKCU*" -or $Root -like "*HKEY_CURRENT_USER*"   ) { $RootKey = [Microsoft.Win32.Registry]::CurrentUser   ; $RegRoot = "Registry::HKCU\" }
            elseif ( $Root -like "*HKLM*" -or $Root -like "*HKEY_LOCAL_MACHINE*"  ) { $RootKey = [Microsoft.Win32.Registry]::LocalMachine  ; $RegRoot = "Registry::HKLM\" }
            elseif ( $Root -like "*HKCR*" -or $Root -like "*HKEY_CLASSES_ROOT*"   ) { $RootKey = [Microsoft.Win32.Registry]::ClassesRoot   ; $RegRoot = "Registry::HKCR\" }
            elseif ( $Root -like "*HKU*"  -or $Root -like "*HKEY_USERS*"          ) { $RootKey = [Microsoft.Win32.Registry]::Users         ; $RegRoot = "Registry::HKU\"  }
            elseif ( $Root -like "*HKCC*" -or $Root -like "*HKEY_CURRENT_CONFIG*" ) { $RootKey = [Microsoft.Win32.Registry]::CurrentConfig ; $RegRoot = "Registry::HKCC\" }
            else
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Раздел реестра неверный!`n   Раздел" }
                Write-Warning "$NameThisFunction`: $text`: '$Path'"

                $Exit = $true ; Return     # Выходим из функции, переходя по всем блокам.
            }
        }
        else
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Раздел реестра неверный!`n   Раздел" }
            Write-Warning "$NameThisFunction`: $text`: '$Path'"

            $Exit = $true ; Return     # Выходим из функции, переходя по всем блокам.
        }

        # Если для проверки передано значение параметра.
        # IsFixedSize отпределяется только на массивах или коллекциях, а 'двоичное значение нулевой длины' является пустым массивом @() для Binary или None.
        # Пустой массив - это не '$null', не пустая строка '' и не значение. Операторы сравнения его не понимают.
        if (( $Value ) -or ( 0 -eq $Value ) -or ( $Value.IsFixedSize -is [bool] ))
        {
            # Параметр передан.
            [bool] $ValueExist = $true

            # Если переданный параметр является пустым массивом.
            if ( $Value.Count -eq 0 ) { $Zerolength = '{0}' -f $(if ( $L.s5 ) { $L.s5 } else { "Двоичное значение нулевой длины" }) }
        }

        # Если передан тип параметра, так как если не передавать, будет указан по умолчанию 'Unknow'.
        # Для возможности создания параметров, включая 'двоичное значение нулевой длины' для Binary или None,
        # если не указаны значения или указаны пустые строки '', недопустимые для определенных типов, или тип не указан вообще,
        # задаем правильные значения.
        if ( $Type -ne 'Unknow' )
        {
            if ( -not $ValueExist )
            {
                if     ( $Type -match "Binary|None"          ) {   [byte[]] $Value = ([byte[]]@())   }
                elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = ([string[]]@()) }
                elseif ( $Type -like "?word"                 ) {    [int32] $Value = 0               }
                elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = ''              }
            }
            else
            {
                if ( $Type -match "Binary|None" )
                {
                   # Если передать строку для Binary или None, она будет преобразована в массив по 2 символа с добавлением к ним '0x..' (формат HEX)
                   # Такой формат в .reg, или слитый. С любыми переносами строк.
                   if ( $Value.GetType().Name -eq 'String' )
                   {
                       [byte[]] $Value = ($Value -replace ('[\s\\]','') -replace ('([\w]{1,2}),?','0x$1;')).Split(';').Where({$_})
                   }
                   else                                        {   [byte[]] $Value = $Value }
                }
                elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = $Value }
                elseif ( $Type -eq "Dword"                   )
                {
                    if     (  [int32]::TryParse("$Value",[ref]$null) ) { [int32] $Value = [int32] $Value }
                    elseif ( [Uint32]::TryParse("$Value",[ref]$null) ) { [int32] $Value = "0x$([Convert]::ToString($Value, 16))" } # Uint to Hex to Int
                    else                                               { try { [int32] $Value = $Value } catch { [int32] $Value = "0x$Value" } }
                }
                elseif ( $Type -eq "Qword"                   ) {    [int64] $Value = [int64] $Value }
                elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = $Value }
            }
        }
        else
        {
            if ( -not $ValueExist ) { [string] $Value = '' }
            else
            {
                if     ( $Value.GetType().Name -eq 'Byte[]'      ) { [string] $Type = 'Binary'      ;   [byte[]] $Value = $Value }
                elseif ( $Value.GetType().IsArray                ) { [string] $Type = 'MultiString' ; [string[]] $Value = $Value }
                elseif ( $Value.GetType().Name -eq 'String'      ) { [string] $Type = 'String'      ;   [string] $Value = $Value }
                elseif (  [int32]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Dword'       ;    [int32] $Value = [int32] $Value }
                elseif ( [Uint32]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Dword'       ;    [int32] $Value = "0x$([Convert]::ToString($Value, 16))" } # Uint to Hex to Int
                elseif (  [int64]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Qword'       ;    [int64] $Value = [int64] $Value }
                else                                               { [string] $Type = 'String'      ;   [string] $Value = $Value }
            }
        }

        # Вторая часть.
        # Получение параметров из реестра. Если нет ни какого доступа, будет получен и оставлен полный доступ.

        # Если передан командлет Remove-Item и в пути указано исключение родительского раздела '\*'.
        if (( $Cmdlet -eq 'Remove-Item' ) -and ( $SubKey -match "\\[*]\s*$" ))
        {
            [string] $ChildPath = ' дочерний'  # Наличие - указывает оставить родительский раздел.

            # Убираем с конца пути '\*'.
            $SubKey = $SubKey.TrimEnd("\* ")

            # Открываем раздел в режиме только для чтения.
            # И если ловим ошибку доступа к разделу, получаем полный доступ к этому и всем вложенным подразделам.
            try { $isOpenKey = $RootKey.OpenSubKey($SubKey) }
            catch
            {
                Write-Verbose "Нет доступа к разделу: '$Path'"
                Write-Verbose "Получаем полный доступ"
                Set-OwnerAndAccess -Path $Path -Recurse -SetFullAccess

                try {
                    Write-Verbose "Открываем раздел еще раз в режиме чтения: '$Path'"
                    $isOpenKey = $RootKey.OpenSubKey($SubKey)
                }
                catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }
            }

            # Если количество подразделов 0 или $null, укзываем отсутствие раздела (в данном случае подразделов).
            if ( -not $isOpenKey.SubKeyCount ) { $isOpenKey = $null }
        }
        else
        {
            # Иначе, открываем раздел в режиме только для чтения. И если ловим ошибку доступа к разделу, получаем полный доступ.
            # Если раздела нет, то переменная будет пустая, и раздел будет создан при необходимости во время выполнения.
            try { $isOpenKey = $RootKey.OpenSubKey($SubKey) }
            catch
            {
                Write-Verbose "Нет доступа к разделу: '$Path'"
                Write-Verbose "Получаем полный доступ"
                Set-OwnerAndAccess -Path $Path -SetFullAccess

                try {
                    Write-Verbose "Открываем раздел еще раз в режиме чтения: '$Path'"
                    $isOpenKey = $RootKey.OpenSubKey($SubKey)
                }
                catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }
            }
        }

        try
        {
            # Получаем значение у параметра.
            # не раскрывая системные переменные в значениях, такие как %Temp% и т.д. у параметров с типом ExpandString (REG_EXPAND_SZ).
            # Если параметра не существует, то результат будет указанный $null.
            # Если имя будет $null или '', то проверит параметр (По умолчанию) у раздела.
            $isValue = $isOpenKey.GetValue($Name,$null,'DoNotExpandEnvironmentNames')

            # Получаем тип параметра, если будет получен, значит и параметр существует.
            # Если имя будет $null или '', то проверит тип у параметра (По умолчанию) в разделе.
            $isType  = $isOpenKey.GetValueKind($Name)
        }
        catch {}

        # Если тип параметра получен, значит и параметр существует.
        if ( $isType )
        {
            # Если значение полученного параметра является пустым массивом.
            if (( $isValue.IsFixedSize ) -and ( $isValue.Count -eq 0 )) { $isZerolength = '{0}' -f $(if ( $L.s5 ) { $L.s5 } else { "Двоичное значение нулевой длины" }) }
        }
    }

    Process
    {
        # Перехват ошибок, только прерываемых исключений, в блоке Process, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s6 ) { $L.s6 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionREG'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Если нужно выйти или выполнить только проверку, переходим в End.
        if ( $Exit ) { Return }
        elseif ( $Do -eq 'Check' ) { $isAct = '(Только проверено)' ; Return } else { $isAct = "(Выполнено, затем проверено)" }

        Write-Verbose "Выполняем настройку '$Do'"

        # "Set-Item", "Set-ItemProperty", "New-Item", "New-ItemProperty", "Remove-Item", "Remove-ItemProperty", "Rename-ItemProperty"

        [string] $SddlBackUP = ''

        # Функция по поиску существующего родительского раздела без доступа,
        # так как создаваемый раздел может оказаться внутри этого раздела на любой "глубине".
        # Необходимо, чтобы была возможность изменения и восстановления параметров доступа именно у этого раздела.
        Function Search-SubKey {

            $SubKeyTest = $SubKey ; $isSubKeyFound = $null ; $TrySearch = 0
            if ( -not ( Test-Path -LiteralPath $RegRoot$SubKeyTest -PathType Container -ErrorAction SilentlyContinue ))
            {
                do
                {
                    # Удаление дочернего раздела с конца пути, то есть получить родительский раздел. Пошаговый переход "вверх".
                    # Проверка существования, добавление номера шага. Выход из функции после нахождения раздела, или после 50 шагов, если чтото пошло не так.
                    $SubKeyTest = $SubKeyTest -Replace ("\\[^\\]+$",'')
                    Write-Verbose "Проверка раздела: '$RegRoot$SubKeyTest'"
                    if ( Test-Path -LiteralPath $RegRoot$SubKeyTest -PathType Container -ErrorAction SilentlyContinue ) { $isSubKeyFound = $SubKeyTest }
                    $TrySearch++
                }
                until ( $isSubKeyFound -or ( $TrySearch -eq 50 ))
            }
            else { $isSubKeyFound = $SubKey }

            # Передаем результат - найденный раздел без доступа.
            $isSubKeyFound
        }

        if ( $Cmdlet -eq 'Set-Item' )
        {
            Write-Verbose "Создание параметра '(default)' [$Type] {$Value$Zerolength}"

            try { $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type) }
            catch
            {
                Write-Verbose "Нет доступа"

                # Подключаем токен от TrustedInstaller
                Token-Impersonate -Token TI

                Write-Verbose "Выполняем еще раз под олицетворением"

                try { $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type) }
                catch
                {
                    Write-Verbose "Нет доступа всё равно"

                    # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                    Token-Impersonate -Token SYS

                    Write-Verbose "Выполняем, получив временный доступ, к найденному разделу без доступа на запись"
                    Write-Verbose "Ищем раздел без доступа"
                    $SubKeyFound = Search-SubKey

                    Write-Verbose "Сохраняем SDDL у '$Root$SubKeyFound'"
                    $SddlBackUP = $RootKey.OpenSubKey($SubKeyFound,'ReadSubTree','QueryValues').GetAccessControl().sddl

                    $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                    # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                    if ( -not ( $SddlBackUP -match $MatchSddl ))
                    {
                        Write-Verbose "Получаем полный доступ к '$Root$SubKeyFound'"
                        Set-OwnerAndAccess -Path $Root$SubKeyFound -SetFullAccess

                        try {
                            Write-Verbose "Выполняем команду еще раз"
                            $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type)
                        }
                        catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                        Write-Verbose "Востанавливаем SDDL у '$Root$SubKeyFound'"
                        Set-OwnerAndAccess -Path $Root$SubKeyFound -RecoverySDDL $SddlBackUP
                    }
                    else
                    {
                        # Доступа нет, так как блокировка не правами
                        Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                    }
                }
                finally { Token-Impersonate -Reset }
            }
        }
        elseif ( $Cmdlet -eq 'New-Item' )
        {
            if ( $ValueExist )
            {
                Write-Verbose "Создание параметра '(default)' [$Type] {$Value$Zerolength}"

                try { $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type) }
                catch
                {
                    Write-Verbose "Нет доступа"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Выполняем еще раз под олицетворением"

                    try { $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type) }
                    catch
                    {
                        Write-Verbose "Нет доступа всё равно"

                        # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                        Token-Impersonate -Token SYS

                        Write-Verbose "Выполняем, получив временный доступ, к найденному разделу без доступа на запись"
                        Write-Verbose "Ищем раздел без доступа"
                        $SubKeyFound = Search-SubKey

                        Write-Verbose "Сохраняем SDDL у '$Root$SubKeyFound'"
                        $SddlBackUP = $RootKey.OpenSubKey($SubKeyFound,'ReadSubTree','QueryValues').GetAccessControl().sddl

                        $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                        # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                        if ( -not ( $SddlBackUP -match $MatchSddl ))
                        {
                            Write-Verbose "Получаем полный доступ к '$Root$SubKeyFound'"
                            Set-OwnerAndAccess -Path $Root$SubKeyFound -SetFullAccess

                            try {
                                Write-Verbose "Выполняем команду еще раз"
                                $RootKey.CreateSubKey($SubKey).SetValue('',$Value,$Type)
                            }
                            catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                            Write-Verbose "Востанавливаем SDDL у '$Root$SubKeyFound'"
                            Set-OwnerAndAccess -Path $Root$SubKeyFound -RecoverySDDL $SddlBackUP
                        }
                        else
                        {
                            # Доступа нет, так как блокировка не правами
                            Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                        }
                    }
                    finally { Token-Impersonate -Reset }
                }
            }
            else
            {
                Write-Verbose "Создание раздела '$Path'"

                try { $RootKey.CreateSubKey($SubKey) > $null }
                catch
                {
                    Write-Verbose "Нет доступа"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Выполняем еще раз под олицетворением"

                    try { $RootKey.CreateSubKey($SubKey) > $null }
                    catch
                    {
                        Write-Verbose "Нет доступа всё равно"

                        # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                        Token-Impersonate -Token SYS

                        Write-Verbose "Выполняем, получив временный доступ, к найденному разделу без доступа на запись"
                        Write-Verbose "Ищем раздел без доступа"
                        $SubKeyFound = Search-SubKey

                        Write-Verbose "Сохраняем SDDL у '$Root$SubKeyFound'"
                        $SddlBackUP = $RootKey.OpenSubKey($SubKeyFound,'ReadSubTree','QueryValues').GetAccessControl().sddl

                        $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                        # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                        if ( -not ( $SddlBackUP -match $MatchSddl ))
                        {
                            Write-Verbose "Получаем полный доступ к '$Root$SubKeyFound'"
                            Set-OwnerAndAccess -Path $Root$SubKeyFound -SetFullAccess

                            try {
                                Write-Verbose "Выполняем команду еще раз"
                                $RootKey.CreateSubKey($SubKey) > $null
                            }
                            catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                            Write-Verbose "Востанавливаем SDDL у '$Root$SubKeyFound'"
                            Set-OwnerAndAccess -Path $Root$SubKeyFound -RecoverySDDL $SddlBackUP
                        }
                        else
                        {
                            # Доступа нет, так как блокировка не правами
                            Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                        }
                    }
                    finally { Token-Impersonate -Reset }
                }
            }
        }
        elseif (( $Cmdlet -eq 'New-ItemProperty' ) -or ( $Cmdlet -eq 'Set-ItemProperty' ))
        {
            if ( -not $Name ) { Write-Verbose "Создание параметра '(default)' [$Type] {$Value$Zerolength}" }
            else { Write-Verbose "Создание параметра '$Name' [$Type] {$Value$Zerolength}" }

            try { $RootKey.CreateSubKey($SubKey).SetValue($Name,$Value,$Type) }
            catch
            {
                Write-Verbose "Нет доступа"

                # Подключаем токен от TrustedInstaller
                Token-Impersonate -Token TI

                Write-Verbose "Выполняем еще раз под олицетворением"

                try { $RootKey.CreateSubKey($SubKey).SetValue($Name,$Value,$Type) }
                catch
                {
                    Write-Verbose "Нет доступа всё равно"

                    # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                    Token-Impersonate -Token SYS

                    Write-Verbose "Выполняем, получив временный доступ, к найденному разделу без доступа на запись"
                    Write-Verbose "Ищем раздел без доступа"
                    $SubKeyFound = Search-SubKey

                    Write-Verbose "Сохраняем SDDL у '$Root$SubKeyFound'"
                    $SddlBackUP = $RootKey.OpenSubKey($SubKeyFound,'ReadSubTree','QueryValues').GetAccessControl().sddl

                    $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                    # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                    if ( -not ( $SddlBackUP -match $MatchSddl ))
                    {
                        Write-Verbose "Получаем полный доступ к '$Root$SubKeyFound'"
                        Set-OwnerAndAccess -Path $Root$SubKeyFound -SetFullAccess

                        try {
                            Write-Verbose "Выполняем команду еще раз"
                            $RootKey.CreateSubKey($SubKey).SetValue($Name,$Value,$Type)
                        }
                        catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                        Write-Verbose "Востанавливаем SDDL у '$Root$SubKeyFound'"
                        Set-OwnerAndAccess -Path $Root$SubKeyFound -RecoverySDDL $SddlBackUP
                    }
                    else
                    {
                        # Доступа нет, так как блокировка не правами
                        Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                    }
                }
                finally { Token-Impersonate -Reset }
            }
        }
        elseif ( $Cmdlet -eq 'Remove-Item' )
        {
            if ( $ChildPath )
            {
                [string[]] $ChildNames = ''

                # Получаем имена подразделов, с минимально необходимым доступом.
                try { $ChildNames = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys').GetSubKeyNames() }
                catch
                {
                    Write-Verbose "Нет доступа к получению списка подразделов"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Выполняем еще раз под олицетворением"

                    # Получаем имена еще раз подразделов.
                    try { $ChildNames = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys').GetSubKeyNames() }
                    catch
                    {
                        Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true
                    }
                    finally { Token-Impersonate -Reset }
                }

                if ( $ChildNames )
                {
                    Write-Verbose "Родительский раздел исключен"

                    foreach ( $KeyName in $ChildNames )
                    {
                        Write-Verbose "Удаление дочернего раздела '$Root$SubKey\$KeyName'"

                        try { $RootKey.DeleteSubKeyTree("$SubKey\$KeyName",$true) }
                        catch
                        {
                            Write-Verbose "Нет доступа"

                            # Подключаем токен от TrustedInstaller
                            Token-Impersonate -Token TI

                            Write-Verbose "Выполняем еще раз под олицетворением"

                            try { $RootKey.DeleteSubKeyTree("$SubKey\$KeyName",$true) }
                            catch
                            {
                                Write-Verbose "Нет доступа всё равно"

                                # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                                Token-Impersonate -Token SYS

                                Write-Verbose "Выполняем, получив полный доступ, включая его подразделы"
                                Write-Verbose "Получаем полный доступ к '$Root$SubKey\$KeyName'"

                                Set-OwnerAndAccess -Path "$Root$SubKey\$KeyName" -Recurse -SetFullAccess

                                try {
                                    Write-Verbose "Выполняем команду еще раз"
                                    $RootKey.DeleteSubKeyTree("$SubKey\$KeyName",$true)
                                }
                                catch { Write-Verbose "Нет доступа к '$Root$SubKey\$KeyName'" ; [bool] $isAccessDenied = $true }
                            }
                            finally { Token-Impersonate -Reset }
                        }
                    }
                }
                else { Write-Verbose "Нет подразделов для удаления в '$Path'" }
            }
            else
            {
                # Если раздел существует.
                if ( $isOpenKey )
                {
                    Write-Verbose "Удаление всех подразделов включая этот: '$Path'"

                    try { $RootKey.DeleteSubKeyTree($SubKey,$true) }
                    catch
                    {
                        Write-Verbose "Нет доступа"

                        # Подключаем токен от TrustedInstaller
                        Token-Impersonate -Token TI

                        Write-Verbose "Выполняем еще раз под олицетворением"

                        try { $RootKey.DeleteSubKeyTree($SubKey,$true) }
                        catch
                        {
                            Write-Verbose "Нет доступа всё равно"

                            # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                            Token-Impersonate -Token SYS

                            Write-Verbose "Выполняем, получив полный доступ, включая все подразделы"
                            Write-Verbose "Получаем полный доступ к '$Path'"

                            Set-OwnerAndAccess -Path $Path -Recurse -SetFullAccess

                            try {
                                Write-Verbose "Выполняем команду еще раз"
                                $RootKey.DeleteSubKeyTree($SubKey,$true)
                            }
                            catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }
                        }
                        finally { Token-Impersonate -Reset }
                    }
                }
                else
                {
                    Write-Verbose "Раздела не существует: '$Path'"
                }
            }
        }
        elseif ( $Cmdlet -eq 'Remove-ItemProperty' )
        {
            # Если тип параметра был получен, значит параметр существует.
            if ( $isType )
            {
                if ( -not $Name ) { Write-Verbose "Удаление параметра '(default)' [$isType] {$isValue$isZerolength}" }
                else { Write-Verbose "Удаление параметра '$Name' [$isType] {$isValue$isZerolength}" }

                try { $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree').DeleteValue($Name,$false) }
                catch
                {
                    Write-Verbose "Нет доступа"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Выполняем еще раз под олицетворением"

                    try { $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree').DeleteValue($Name,$false) }
                    catch
                    {
                        Write-Verbose "Нет доступа всё равно"

                        # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                        Token-Impersonate -Token SYS

                        Write-Verbose "Выполняем, получив временный доступ"
                        Write-Verbose "Сохраняем SDDL у '$Path'"

                        $SddlBackUP = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetAccessControl().sddl

                        $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                        # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                        if ( -not ( $SddlBackUP -match $MatchSddl ))
                        {
                            Write-Verbose "Получаем полный доступ к '$Path'"
                            Set-OwnerAndAccess -Path $Path -SetFullAccess

                            try {
                                Write-Verbose "Выполняем команду еще раз"
                                $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree').DeleteValue($Name,$false)
                            }
                            catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                            Write-Verbose "Востанавливаем SDDL у '$Path'"
                            Set-OwnerAndAccess -Path $Path -RecoverySDDL $SddlBackUP
                        }
                        else
                        {
                            # Доступа нет, так как блокировка не правами
                            Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                        }
                    }
                    finally { Token-Impersonate -Reset }
                }
            }
            else { Write-Verbose "Нет раздела или параметра!" }
        }
        else    # "Rename-ItemProperty"
        {
            # Если тип параметра был получен, значит параметр существует.
            if ( $isType )
            {
                Write-Verbose "Переименовка параметра из '$Name' в '$NewName' ([$isType] {$isValue$isZerolength})"

                try
                {
                    $OpenSubKeyRW = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree')
                    $OpenSubKeyRW.SetValue($NewName,$isValue,$isType)
                    $OpenSubKeyRW.DeleteValue($Name,$false)
                }
                catch
                {
                    Write-Verbose "Нет доступа"

                    # Подключаем токен от TrustedInstaller
                    Token-Impersonate -Token TI

                    Write-Verbose "Выполняем еще раз под олицетворением"

                    try
                    {
                        $OpenSubKeyRW = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree')
                        $OpenSubKeyRW.SetValue($NewName,$isValue,$isType)
                        $OpenSubKeyRW.DeleteValue($Name,$false)
                    }
                    catch
                    {
                        Write-Verbose "Нет доступа всё равно"

                        # Меняем олицетворение на Систему, так как применять sddl запрещено при TI.
                        Token-Impersonate -Token SYS

                        Write-Verbose "Выполняем, получив временный доступ"
                        Write-Verbose "Сохраняем SDDL у '$Path'"

                        $SddlBackUP = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetAccessControl().sddl

                        $MatchSddl = '^(?!.+\(D;).+(\(A;CI(ID)?;(K|G)A;;;(WD|BA|SY|S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)\)|\(A;CIIO;GA;;;BA\)\(A;;KA;;;BA\)|\(A;CIIO;GA;;;SY\)\(A;;KA;;;SY\)|\(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\)\(A;;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464\))'

                        # Если есть блокирующее любое правило или нет полного доступа указанного или унаследованного для WD, BA, SY, TI и указанного любым типом, то есть заблокировано правами
                        if ( -not ( $SddlBackUP -match $MatchSddl ))
                        {
                            Write-Verbose "Получаем полный доступ к '$Path'"
                            Set-OwnerAndAccess -Path $Path -SetFullAccess

                            try {
                                Write-Verbose "Выполняем команду еще раз"
                                $OpenSubKeyRW = $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree')
                                $OpenSubKeyRW.SetValue($NewName,$isValue,$isType)
                                $OpenSubKeyRW.DeleteValue($Name,$false)
                            }
                            catch { Write-Verbose "Нет доступа к '$Path'" ; [bool] $isAccessDenied = $true }

                            Write-Verbose "Востанавливаем SDDL у '$Path'"
                            Set-OwnerAndAccess -Path $Path -RecoverySDDL $SddlBackUP
                        }
                        else
                        {
                            # Доступа нет, так как блокировка не правами
                            Write-Verbose "Нет доступа, но права есть к '$Path'" ; [bool] $isAccessDenied = $true
                        }
                    }
                    finally { Token-Impersonate -Reset }
                }
            }
            else { Write-Verbose "Нет раздела или параметра!" ; Return }   # Переходим в блок End.
        }
    }

    End
    {
        # Перехват ошибок, только прерываемых исключений, в блоке End, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s7 ) { $L.s7 } else { "Ошибка в End" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionREG'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Закрываем открытый раздел, для возможности выгрузки подключенных разделов.
        if ( $isOpenKey ) { $isOpenKey.Close() }

        # Выйти при ошибке или если не нужна проверка.
        if ( $Exit -or $NoCheck )
        {
            Return  # выходим из функции
        }

        Write-Verbose "Начало проверки. Действие: '$Do'"

        # Если не указан параметр действий, значит было выполнено действие, и теперь будет проверка результата выполнения,
        # по этому выполняем получение параметров из реестра еще раз.
        if ( $Do -eq 'Set' )
        {
            # Обнуляем значения, полученные в самом начале.
            $isOpenKey = $isValue = $isType = $isZerolength = $null

            # Открываем раздел в режиме только для чтения.
            try { $isOpenKey = $RootKey.OpenSubKey($SubKey) } catch {}

            # Если передан командлет Remove-Item и в пути указано исключение родительского раздела '\*'.
            if ( $ChildPath )
            {
                # Если количество подразделов 0 или $null, укзываем отсутствие раздела (в данном случае подразделов).
                if ( -not $isOpenKey.SubKeyCount ) { $isOpenKey = $null }
            }

            try
            {
                # Получаем значение у параметра.
                # Если имя будет $null или '', то проверит параметр (По умолчанию) у раздела.
                $isValue = $isOpenKey.GetValue($Name,$null,'DoNotExpandEnvironmentNames')

                # Получаем тип параметра, если будет получено, значит и параметр существует.
                # Если имя будет $null или '', то проверит тип у параметра (По умолчанию) в разделе.
                $isType  = $isOpenKey.GetValueKind($Name)
            }
            catch {}

            # Если тип параметра получен, значит и параметр существует.
            if ( $isType )
            {
                # Если значение полученного параметра является пустым массивом.
                if (( $isValue.IsFixedSize ) -and ( $isValue.Count -eq 0 )) { $isZerolength = '{0}' -f $(if ( $L.s5 ) { $L.s5 } else { "Двоичное значение нулевой длины" }) }
            }
        }

        [bool] $ResultFunc = $false

        # Если раздел существует.
        if ( $isOpenKey )
        {
            # Если значение параметра передано.
            if ( $ValueExist )
            {
                # Если тип параметра получен, значит параметр существует, и передан тип параметра для проверки.
                if ( $isType -and ( $Type -ne 'Unknow' ))
                {
                    # "Проверка: Value и Type"

                    # Если имя параметра не передали или передали пустую строку ''.
                    if ( -not $Name ) { $Name = '(default)' }

                    # Если передали имя, даже с пустой строкой '', значение и тип параметра, и они совпали с полученным именем, его значением и типом.
                    # Включая пустые массивы - 'двоичное значение нулевой длины' и пустые строки ''.
                    if (( "$Value" -eq "$isValue" ) -and ( $Type -eq $isType ))
                    {
                        # Выводим полностью совпавшие полученные: 'Имя параметра' [тип параметра] {значение}.
                        Write-Verbose "Все совпадает с '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $true
                    }
                    else
                    {
                        # Иначе, выводим переданные и не совпавшие полученные значения.
                        Write-Verbose "Не совпадает:`n   Проверили: '$Name' [$Type] {$Value$Zerolength}`n    Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $false
                    }
                }
                elseif ( $isType )
                {
                    # Иначе, если тип параметра получен, но тип параметра не передан для проверки,
                    # проверяем только значение параметра.
                    # "Проверка: только Value"

                    # Если имя параметра не передали или передали имя с пустой строкой ''.
                    if ( -not $Name ) { $Name = '(default)' }

                    if ( "$Value" -eq "$isValue" )
                    {
                        # Если переданное значение совпадает с полученым значением,
                        # Включая пустые массивы - 'двоичное значение нулевой длины' и пустые строки ''.

                        Write-Verbose "Значение Cовпадает: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $true
                    }
                    else
                    {
                        # Иначе значения не совпадают. Выводим все переданные и все полученные параметры.

                        Write-Verbose "Значение не совпадает:`n  Проверили: '$Name' [-] {$Value$Zerolength}`n   Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $false
                    }
                }
                else
                {
                    # Иначе, тип параметра не получен, а значит и имя параметра не существует,
                    # Выводится, если переданно для проверки имя параметра и значение, без типа параметра.

                    if ( -not $Name )
                    {
                        # Если имя параметра не передано, или передано имя с пустой строкой ''.

                        Write-Verbose "Параметр отсутствует: '(default)'"

                        $ResultFunc = $false
                    }
                    else
                    {
                        # Иначе имя параметра было передано. Выводим переданное имя параметра, из-за отсутствия.

                        Write-Verbose "Параметр отсутствует: '$Name'"

                        $ResultFunc = $false
                    }
                }
            }
            else
            {
                # Иначе, значение параметра не передано для проверки, но раздел существует.
                # "Проверка: Name". Все варианты.

                if ( $null -eq $Name )
                {
                    # Если имя и значение не передано. Значит хотим проверить только раздел.

                    Write-Verbose "Раздел$ChildPath существует: '$($isOpenKey.Name)'"

                    $ResultFunc = $true

                }
                elseif (( $Name -eq '' ) -and $isType )
                {
                    # Иначе, Если Имя параметра передано с пустой строкой '', без значения параметра, а тип параметра получен.
                    # Значит хотели проверить параметр (По умолчанию).

                    Write-Verbose "Параметр существует: '(default)' [$isType] {$isValue$isZerolength}"

                    $ResultFunc = $true

                }
                elseif ( $isType )
                {
                    # Иначе, Если Имя параметра передали и тип параметра получили.

                    Write-Verbose "Параметр существует: '$Name' [$isType] {$isValue$isZerolength}"

                    $ResultFunc = $true
                }
                elseif ( $Name )
                {
                    # Иначе, Если Имя параметра передали, а тип параметра не получили.

                    Write-Verbose "Параметр отсутствует: '$Name'"

                    $ResultFunc = $false
                }
                else
                {
                    # Иначе, раз все выше проверенное не подошло, остается только,
                    # что Имя параметра передали с пустой строкой '', а тип параметра не получили,
                    # значит хотели проверить параметр (По умолчанию).

                    Write-Verbose "Параметр отсутствует: '(default)'"

                    $ResultFunc = $false
                }
            }
        }
        else
        {
            # Иначе, раз раздела не существует, выводим переданный раздел, из-за его отсутствия.
            # "Проверка: Path"
            Write-Verbose "Раздел$ChildPath отсутствует: '$Path'"

            $ResultFunc = $false
        }

        # Закрываем открытый раздел, для возможности выгрузки подключенных разделов, после очистки.
        if ( $isOpenKey ) { $isOpenKey.Close() }

        # Для командлетов, которые удаляют или изменяют параметр, результат делаем противоположным.
        # Так как совпадение с заданным параметром значит, что действие не выполнено.
        # "Set-Item", "Set-ItemProperty", "New-Item", "New-ItemProperty" = True - параметр соответствует результату выполняемого действия, значит все верно.
        # "Remove-Item", "Remove-ItemProperty",  "Rename-ItemProperty"   = True - Для удаляющих командлетов наличие параметра для выполнения имеет противоположное значение, значит неверно.
        if ( $Cmdlet -match "Remove-|Rename-ItemProperty" ) { if ( $ResultFunc ) { $ResultFunc = $false } else { $ResultFunc = $true } }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo   [Параметр правильный]  $isAct"

            $ShowResult['Result'] = '+'

            if ( $Do -eq 'Set' ) { $ShowResult['Status'] = '{0}' -f $(if ( $L.s8 ) { $L.s8 } else { "Выполнено" }) }
            else                 { $ShowResult['Status'] = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { "Верно"     }) }
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр не совпадает]  $isAct"

            $ShowResult['Result'] = '!!!'
            if ( $isAccessDenied ) { $ShowResult['Status'] = '{0}' -f $(if ( $L.s10 ) { $L.s10 } else { "Нет Доступа" }) }
            else                   { $ShowResult['Status'] = '{0}' -f $(if ( $L.s11 ) { $L.s11 } else { "Неверно"     }) }
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult

        # Внесение параметров в подключенные кусты других аккаунтов, если существует переменная с нужными данными
        if ( $Global:DataAllUsers.Redirects.Value -and -not $OnlyThisPath )
        {
            foreach ( $User in $Global:DataAllUsers )
            {
                if ( $User.SID )
                {
                    if (( -not $Global:DataAllUsers.Redirects.DefaultAccount ) -and ( $User.ProfileType -eq 'DefaultAccount' )) { Continue } # Пропуск перенаправления на дефолтный пррофиль, если не указано перенаправлять на него

                    if ( "$RegRoot$SubKey" -like "Registry::HKCU\Software\Classes\?*" )
                    {
                        # Если куст был подгружен в глобальной переменной (происходит при запуске скрипта, если в пресете разрешено)
                        if ( $true -like $User.UsrClass_Load ) 
                        {
                            $RootNew = "Registry::HKU\$($User.SID)_Classes"

                            # проверка существования подгруженного раздела на всякий случай
                            $RootNewIn = [Microsoft.Win32.Registry]::Users.GetSubKeyNames() -like $RootNew

                            # Если куст выгрузился
                            if ( -not $RootNewIn )
                            {
                                # Попытка повторной загрузки кустов этого юзера
                                $TestUser = RegHives-User-LoadUnload $User -Silent -Load
                                
                                # Если куст не подгрузился по любой причине, исключить из обработки куст этого юзера в глобальной переменной и перейти к следующему юзеру
                                if ( -not $TestUser.UsrClass_Load ) { $User.UsrClass_Load = $false ; continue }
                            }

                            $PathNew  = "$RootNew\$($SubKey -replace 'Software\\Classes\\','')"
                            $PathShow = ($PathNew -replace ('Registry::HKU\\S-1-5-21-[\d]+-[\d]+-[\d]+([^\\]+)(.+)','#DarkCyan#HKU\*$1#DarkGray#$2')).Replace('HKU\*-5','HKU\**-5')
                            
                            Set-Reg -Do:$Do -Cmdlet:$Cmdlet -Path:$PathNew -Name:$Name -Type:$(if(-not$Type){'Unknow'}else{$Type}) -Value:$Value -NewName:$NewName -NoCheck:$NoCheck -ShowAction $ActionREG.Replace($Path,$PathShow)
                        }
                    }
                    elseif ( "$RegRoot$SubKey" -like "Registry::HKCU\?*" )
                    {
                        if ( $true -like $User.NTUSER_Load )
                        {
                            $RootNew = "Registry::HKU\$($User.SID)"
                            $RootNewIn = [Microsoft.Win32.Registry]::Users.GetSubKeyNames() -like $RootNew

                            if ( -not $RootNewIn )
                            {
                                $TestUser = RegHives-User-LoadUnload $User -Silent -Load
                                
                                if ( -not $TestUser.NTUSER_Load ) { $User.NTUSER_Load = $false ; continue }
                            }

                            $PathNew  = "$RootNew\$SubKey"
                            $PathShow = ($PathNew -replace ('Registry::HKU\\S-1-5-21-[\d]+-[\d]+-[\d]+([^\\]+)(.+)','#DarkCyan#HKU\*$1#DarkGray#$2')).Replace('HKU\*-5','HKU\**-5')

                            Set-Reg -Do:$Do -Cmdlet:$Cmdlet -Path:$PathNew -Name:$Name -Type:$(if(-not$Type){'Unknow'}else{$Type}) -Value:$Value -NewName:$NewName -NoCheck:$NoCheck -ShowAction $ActionREG.Replace($Path,$PathShow)
                        }
                    }
                }
            }
        }
    }
}
