﻿
<#
.SYNOPSIS
 Настройка с пересозданием правил фаервола для параметров Общего доступа и Сетевого обнаружения.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Корректная настройка правил для:
 FPS = File and Printer Sharing (Общий доступ к файлам и принтерам)
 NETDIS = Network Discovery (Сетевое Обнаружение)

 Настраивает и восстанавливает все правила общего доступа, из системного дефолтного шаблона.
 Независимо от наличия этих правил или их настроек.
 Необходимо, так как правильные настройки задать по другому не возможно,
 без общего сброса всех правил вообще! Если были какие сделаны изменения.
 И потому, что легальных способов настроить правильно не существует,
 именно по тому принципу, как это делает Windows, при настройке через аплет Дополнительных параметров общего доступа.

 Все предлагаемые настройки Microsoft и которыми завален интернет, портят настройки всех профилей!
 И восстановить их можно только сбросив все правила фаервола! А эта функция справляется в любых случаях.

 Каждое правило пересоздаётся и перерегистрируется каждый раз,
 для того, чтобы при любом раскладе получить в итоге корректные и рабочие правила!

 Сценарий независимый от языка Windows, универсальный, так как все решения принимаются
 на основе дефолтных правил Windows + учитывается состояние текущих настроек правил.

 Определение уже включённых профилей правил определяется по состоянию только общих правил с именем LLMNR.
 Чтобы при пересоздании задать всем правилам этого профиля такое же состояние: Включено или Отключено,
 если в данный момент настраиваются правила из другого профиля.

 Настройка одного профиля и одной группы за один раз.
 Делать возможность настройки сразу всех профилей и групп не было необходимо.

.EXAMPLE
    Set-Sharing-Profile -GroupName FPS -Profile Public -Enabled true

    Описание
    --------
    Включение правил для профиля Публичный у группы Общий доступ к файлам и принтерам

.EXAMPLE
    Set-Sharing-Profile -GroupName NETDIS -Reset

    Описание
    --------
    Сброс всех правил для всех профилей по умолчанию для группы Сетевое Обнаружение

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  11.06.2020
 ===============================================

#>
Function Set-Sharing-Profile {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [parameter( Mandatory = $true, ParameterSetName = 'Set',   Position = 0 )]
        [parameter( Mandatory = $true, ParameterSetName = 'Reset', Position = 0 )]
        [ValidateSet( 'FPS','NETDIS' )]
        [string] $GroupName
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Set',   Position = 1 )]
        [ValidateSet( 'Domain', 'Public', 'Private' )]
        [string] $Profile
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Set',   Position = 2 )]
        [ValidateSet( 'true', 'false' )]
        [string] $Enabled
       ,
        [parameter( Mandatory = $true, ParameterSetName = 'Reset' )]
        [switch] $Reset
    )

    Begin
    {
        # Получение имени этой функции.
        $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        trap { break }

        # Открытие раздела реестра по умолчанию для возможности пересоздания правил по дефолтному шаблону
        [string] $SubKey_Def = 'SYSTEM\CurrentControlSet\Services\SharedAccess\Defaults\FirewallPolicy\FirewallRules'
        try { $OpenPath_Def = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey_Def,'ReadSubTree,QueryValues') }
        catch
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Нет доступа к разделу реестра Фаервола Windows' }
            Write-Warning "`n  $NameThisFunction`: $text`: `n  HKLM\$SubKey_Def"

            $Exit = $true ; Return    # Выход из функции.
        }

        # Раздел для настройки правил
        [string] $SubKey = 'SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\FirewallRules'
        try { $OpenPath = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree') }
        catch
        {
            $text = if ( $L.s1 ) { $L.s1 } else { 'Нет доступа к разделу реестра Фаервола Windows' }
            Write-Warning "`n  $NameThisFunction`: $text`: `n  HKLM\$SubKey"

            $Exit = $true ; Return    # Выход из функции.
        }

        [string[]] $LLMNR_IDs = @()
          [string] $Group_ID  = ''
         [string] $ValueRule  = ''

        # Получаем названия элементов (имен) у всех LLMNR, будут использоваться как метка для принятия решения включены ли правила у профиля
        if ( $OpenPath_Def.ValueCount )
        {
            foreach ( $Name in ( $OpenPath_Def.GetValueNames().Where({ $_ -like "$GroupName-LLMNR-*" }) ))
            {
                $ValueRule = $OpenPath_Def.GetValue($Name,$null)
                $LLMNR_IDs += [regex]::Matches($ValueRule,'Name=@FirewallAPI\.dll,-[0-9]+','IgnorePatternWhitespace').Value
                if ( -not $Group_ID ) { $Group_ID = [regex]::Matches($ValueRule,'EmbedCtxt=@FirewallAPI\.dll,-[0-9]+','IgnorePatternWhitespace').Value }
            }
        }

        if ( -not ( $Group_ID -and $LLMNR_IDs ))
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Не найдены дефолтные правила LLMNR для группы' }
            Write-Warning "`n  $NameThisFunction`: $text`: $GroupName"

            $Exit = $true ; Return     # Выход из функции.
        }

          [string] $ActiveDomain  = 'FALSE'
          [string] $ActivePrivate = 'FALSE'
          [string] $ActivePublic  = 'FALSE'

        [string[]] $Profiles = @()
        [string]   $Active   = ''

        # Получение влючены ли правила для профилей, определяется по правилам для LLMNR для каждого профиля отдельно
        if ( $OpenPath.ValueCount )
        {
            foreach ( $Name in ( $OpenPath.GetValueNames() ))
            {
                $ValueRule = $OpenPath.GetValue($Name,$null).Where({$_ -match ($LLMNR_IDs -join '|')})

                if ( $ValueRule )
                {
                    $Profiles = [regex]::Matches($ValueRule,'Profile=(?<Profile>Domain|Private|Public)','IgnorePatternWhitespace').Groups.Where({$_.Name -eq 'Profile'}).Value
                    if ( -not $Profiles ) { $Profiles = 'Domain','Private','Public' }

                    $Active = [regex]::Matches($ValueRule,'Active=(?<Active>FALSE|TRUE)','IgnorePatternWhitespace').Groups.Where({$_.Name -eq 'Active'}).Value

                    if ( 'TRUE' -eq $Active )
                    {
                        if ( $Profiles -like 'Domain'  ) { $ActiveDomain  = 'TRUE' }
                        if ( $Profiles -like 'Private' ) { $ActivePrivate = 'TRUE' }
                        if ( $Profiles -like 'Public'  ) { $ActivePublic  = 'TRUE' }
                    }
                }
            }
        }
    }

    Process
    {
        trap { break }

        if ( $Exit ) { Return }

        if ( $Reset )
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Восстановление правил параметров общего доступа" }
            Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline
        }
        else
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Настройка правил параметров общего доступа" }
            Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline
        }

        $text = if ( $L.s5 ) { $L.s5 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $GroupName -eq 'FPS' )
        {
            $GroupNameDisplay = '{0}' -f $(if ( $L.s6 ) { $L.s6 } else { "Общий доступ к файлам и принтерам" })
        }
        else
        {
            $GroupNameDisplay = '{0}' -f $(if ( $L.s7 ) { $L.s7 } else { "Сетевое Обнаружение" })
        }

        if ( -not $Reset )
        {
            $text = if ( $L.s8 ) { $L.s8 } else { "Настройка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Правил" }
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline

            Write-Host "$GroupNameDisplay | $Profile | $Enabled`n" -ForegroundColor White

            $text = if ( $L.s8_2 ) { $L.s8_2 } else {   "Текущее состояние Профиля" }
            Write-Host  "   $text`: Domain  | $ActiveDomain" -ForegroundColor DarkGray
            Write-Host  "   $text`: Private | $ActivePrivate" -ForegroundColor DarkGray
            Write-Host  "   $text`: Public  | $ActivePublic`n" -ForegroundColor DarkGray

            # Переназначение режима правила из указанного функции
            if     ( $Profile -eq 'Domain'  ) { $ActiveDomain  = $Enabled.ToUpper() }
            elseif ( $Profile -eq 'Private' ) { $ActivePrivate = $Enabled.ToUpper() }
            elseif ( $Profile -eq 'Public'  ) { $ActivePublic  = $Enabled.ToUpper() }
        }
        else
        {
            $text = if ( $L.s9 ) { $L.s9 } else { "Восстановление" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Правил" }
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline

            Write-Host "$GroupNameDisplay`n" -ForegroundColor White
        }

        [string[]] $GuidNames = @()

        # Удаление всех присутствующих правил фаервола Windows для указанной группы правил, которые создаются дополнительно при настройке с именами {GUID}
        if ( $Group_ID -and $OpenPath.ValueCount )
        {
            foreach ( $Name in ( $OpenPath.GetValueNames() ))
            {
                $ValueRule = $OpenPath.GetValue($Name,$null).Where({$_ -like "*$Group_ID*" -and $Name -like '{*}'})

                if ( $ValueRule )
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { "Удаление правила" }

                    Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                    Write-Host "| $Name | $GroupNameDisplay | ID: $($Group_ID.Replace('EmbedCtxt=',''))"

                    $GuidNames += $Name
                }
            }

            # Удаление отдельно сразу всех имен с одним запуском командлета, так гораздо быстрее, чем для всех имен по очереди каждый раз запускать командлет.
            # Удаление нужно для возможности создать правило с нужным профилем на базе дефолтных правил, с гарантированными правильными настройками.
            if ( $GuidNames )
            {
                Remove-NetFirewallRule -Name $GuidNames -ErrorAction SilentlyContinue
                Write-Host
            }
        }

        [string[]] $DefaultNames = @()

        if ( $Reset )
        {
            # Получаем имена правил из группы дефолтного шаблона
            [string[]] $DefaultNames = $OpenPath_Def.GetValueNames().Where({ $_ -like "$GroupName-*" })

            $text = if ( $L.s11 ) { $L.s11 } else { "Удаление правил " }

            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

            $text = "| {0} | $GroupNameDisplay | ID: $($Group_ID.Replace('EmbedCtxt=',''))" -f "$GroupName-*".ToString().PadRight(38,' ').Substring(0,38)

            Write-Host "$text`n"

            # Попытка удаления правил обязательна, чтобы удалить правило из базы wmi при наличии, если даже нет в реестре.
            # Удаление нужно для возможности создать дефолтное правило с нужным профилем на базе дефолтных правил, с гарантированными правильными настройками.
            Remove-NetFirewallRule -Name $DefaultNames -ErrorAction SilentlyContinue

            # Создание всех правил для указанной группы по дефолтному системному шаблону.
            foreach ( $Name in $DefaultNames )
            {
                $ValueRule = $OpenPath_Def.GetValue($Name,$null)

                # Временное имя для получения настроек правила через Get-NetFirewallRule, и для последующей передачи его на Copy-NetFirewallRule
                $TempName = "{$([Guid]::NewGuid().ToString().ToUpper())}"

                # Создание временного правила только в реесте для Get-NetFirewallRule
                try { $OpenPath.SetValue($TempName,$ValueRule,'String') } catch {}

                $Rule = Get-NetFirewallRule -Name $TempName -ErrorAction SilentlyContinue

                $text = if ( $L.s12 ) { $L.s12 } else { "Создание правила" }

                Write-Host "   $text " -ForegroundColor Cyan -NoNewline

                $text =  "| {0} | {1} | {2} | {3}" -f
                    $Rule.Profile.ToString().PadRight(15,' ').Substring(0,15),
                    $Rule.Enabled.ToString().PadRight(5,' ').Substring(0,5),
                    $Name.PadRight(38,' ').Substring(0,38),
                    $($Rule.DisplayName)

                Write-Host "$text"

                # Регистрация правила в базе WMI и реестре, с правильным именем на основе временного правила, через копирование.
                $Rule | Copy-NetFirewallRule -NewName $Name -ErrorAction SilentlyContinue

                # Удаление временного правила из реестра
                try { $OpenPath.DeleteValue($TempName,$false) } catch {}
            }
        }
        else
        {
            # Получаем имена правил из группы дефолтного шаблона
            [string[]] $DefaultNames = $OpenPath_Def.GetValueNames().Where({ $_ -like "$GroupName-*" })

            $text = if ( $L.s11 ) { $L.s11 } else { "Удаление правил " }

            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

            $text = "| {0} | $GroupNameDisplay | ID: $($Group_ID.Replace('EmbedCtxt=',''))" -f "$GroupName-*".ToString().PadRight(38,' ').Substring(0,38)

            Write-Host "$text`n"

            # Попытка удаления правил обязательна, чтобы удалить правило из базы wmi при наличии, если даже нет в реестре.
            # Удаление нужно для возможности создать дефолтное правило с нужным профилем на базе дефолтных правил, с гарантированными правильными настройками.
            Remove-NetFirewallRule -Name $DefaultNames -ErrorAction SilentlyContinue

            # Создание всех правил для указанной группы по дефолтному системному шаблону, но разделенных по отдельности.
            foreach ( $Name in $DefaultNames )
            {
                $ValueRule = $OpenPath_Def.GetValue($Name,$null)
                $Profiles = [regex]::Matches($ValueRule,'Profile=(?<Profile>Domain|Private|Public)','IgnorePatternWhitespace').Groups.Where({$_.Name -eq 'Profile'}).Value

                if ( -not $Profiles ) { $Profiles = 'Domain','Private','Public' }

                [int] $N = 0

                foreach ( $SetProfile in $Profiles )
                {
                    $N++

                    # Получение результата состояния для профилей
                    if     ( $SetProfile -eq 'Domain'  ) { $SetActive = $ActiveDomain  }
                    elseif ( $SetProfile -eq 'Private' ) { $SetActive = $ActivePrivate }
                    elseif ( $SetProfile -eq 'Public'  ) { $SetActive = $ActivePublic  }

                    if ( $N -eq 1 )
                    {
                        # Правила Teredo у группы Сетевое Обнаружение для профиля Public включены по умолчанию вместе с обнаружением для частного профиля (Private)
                        # Поэтому если режим для правил с профилем 'Private' включается или включён, то и Teredo (он только Public) включить, даже при отключении Public!
                        if ( $GroupName -eq 'NETDIS' -and $Name -like '*Teredo*' )
                        {
                            if ( $ActivePrivate -eq 'TRUE' )
                            {
                                $SetActive = 'TRUE'  # для Teredo (Public) в текущий момент
                            }
                        }

                        # Замена у настроек дефолтного правила на нужный профиль и состояние для создания правила
                        $ValueRule = $ValueRule -Replace('(.*Dir=(In|Out)(\|Protocol=[0-9]+)*)(\|Profile=(Domain|Private|Public))*(.*)',"`$1|Profile=$SetProfile`$6") -Replace('Active=(FALSE|TRUE)',"Active=$SetActive")

                        # Временное имя для получения настроек правила через Get-NetFirewallRule, и для последующей передачи его на Copy-NetFirewallRule
                        $TempName = "{$([Guid]::NewGuid().ToString().ToUpper())}"

                        # Создание временного правила только в реесте для Get-NetFirewallRule
                        try { $OpenPath.SetValue($TempName,$ValueRule,'String') } catch {}

                        # Получение временного правила
                        $Rule = Get-NetFirewallRule -Name $TempName -ErrorAction SilentlyContinue

                        $text = if ( $L.s12 ) { $L.s12 } else { "Создание правила" }

                        Write-Host "   $text " -ForegroundColor Cyan -NoNewline

                        $text = "| {0} | {1} | {2} | {3}" -f
                            $SetProfile.PadRight(15,' ').Substring(0,15),
                            $SetActive.PadRight(5,' ').Substring(0,5),
                            $Name.PadRight(38,' ').Substring(0,38),
                            $($Rule.DisplayName)

                        Write-Host "$text"

                        # Регистрация правила в базе WMI и реестре, с правильным именем на основе временного правила, через копирование.
                        $Rule | Copy-NetFirewallRule -NewName $Name -ErrorAction SilentlyContinue

                        # Удаление временного правила из реестра
                        try { $OpenPath.DeleteValue($TempName,$false) } catch {}
                    }
                    else
                    {
                        # Создание нового правила со сгенерированным именем на базе дефолтного с нужным профилем и состоянием.

                        $Rule = Get-NetFirewallRule -Name $Name -ErrorAction SilentlyContinue

                        $NewName = "{$([Guid]::NewGuid().ToString().ToUpper())}"

                        $text = if ( $L.s12 ) { $L.s12 } else { "Создание правила" }

                        Write-Host "   $text " -ForegroundColor Cyan -NoNewline

                        $text = "| {0} | {1} | {2} | {3}" -f
                            $SetProfile.PadRight(15,' ').Substring(0,15),
                            $SetActive.PadRight(5,' ').Substring(0,5),
                            $NewName.PadRight(38,' ').Substring(0,38),
                            $($Rule.DisplayName)

                        Write-Host "$text"

                        $Rule | Copy-NetFirewallRule -NewName $NewName -ErrorAction SilentlyContinue
                        Set-NetFirewallRule -Name $NewName -Enabled $SetActive -Profile $SetProfile -ErrorAction SilentlyContinue
                    }
                }
            }
        }

        if ( $Reset )
        {
            $text = if ( $L.s13 ) { $L.s13 } else { "Все Правила восстановлены" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline
        }
        else
        {
            $text = if ( $L.s14 ) { $L.s14 } else { "Все Правила пересозданы" }
            Write-Host "`n   $text " -ForegroundColor Green -NoNewline
        }

        $text = if ( $L.s15 ) { $L.s15 } else { "На основе дефолтных шаблонов правил Фаервола Windows" }
        Write-Host "| $text" -ForegroundColor DarkGray
    }
}