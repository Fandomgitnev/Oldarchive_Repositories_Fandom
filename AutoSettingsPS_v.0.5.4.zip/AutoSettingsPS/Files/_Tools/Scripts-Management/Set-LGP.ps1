﻿
<#
.SYNOPSIS
 Настройка Групповых Политик утилитой LGPO.exe v2.2

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Внесение параметров в реестр и/или их проверка для разделов реестра Групповых Политик.
 И настройка самих Групповых политик утилитой LGPO.exe, настройки будут отображены в оснастке ГП.

 Выполняет команды или делает проверку параметра,
 через методы в RegistryKey [Microsoft.Win32.Registry] из .NET,
 так как это быстрее минимум в 28 раз, чем стандартными командлетами и есть дополнительные возможности.

 Параметр в любом случае вносится в реестр без LGPO.exe,
 но в то же время наполняет переменную с параметрами для LGPO.exe,
 чтобы потом, после вызова применения групповых политик, применить их уже как полагается,
 но только в том случае, если в системе есть групповые политики.
 В противном случае действие будет выполнено только в реестре, стандартно.

 Функция принимает командлеты с командами:
 'Set-ItemProperty', 'New-ItemProperty', 'Remove-ItemProperty', 'New-Item', 'Remove-Item'.

 Добавлено понимание создания правильных значений параметров, при указании пустых строк у значений.
 или без значений вообще, для каждого типа свой.
 Например, если указать тип None или Binary, а значение для него с пустой строкой или не указать его вообще,
 то будет создано "Двоичное значение нулевой длины".
 Для MultiString можно просто указать -Value через запятую, и т.д.
 То есть, если значения не приведены к типу, то будут приведены к правильному типу.

 Значения параметров из реестра выводятся в Десятичной системе исчисления (Decimal)!
 В реестре REG_BINARY записываются в Шестнадцатеричном виде (HEX) и также отображены в Редакторе реестра!
 Поэтому удобнее вносить параметры BINARY в виде HEX,
 пример: -Value ([byte[]]@(0x0,0x8e,0x8f))
    или: -Value 0x0,0x8e,0x8f  (будет преобразован тут в массив байт)

 Если передать 'строку' для Binary или None, она будет преобразована в массив по 2 символа с добавлением к ним '0x..' (формат HEX)
 Такой формат в .reg, то есть можно просто скопировать любое значение hex: из .reg файла.
 Или можно слитые HEX символы без запятых. С любыми переносами строк.
 То есть будет понимание .reg формата (hex:) с запятыми или '\', или пробелами с переносами строк.
 Эти 6 вариантов приведут к одному результату: (каждый может быть с переносами строк)
 Вариант 1: -value '14,00,8b,\
                    00,02'             # .reg hex:  с переносом строк и с '\'
 Вариант 2: -value '14,00,8b,\ 00,02'  # .reg hex:  с убранным переносом и с '\'
 Вариант 3: -value '14,00,8b,00,02'    # .reg hex:  без '\'
 Вариант 4: -value '14008b0002'        # слитые символы hex
 Вариант 5: -value 0x14,0x00,0x8b,0x00,0x02    # массив hex значений
 Вариант 6: [byte[]] $Value = 0x14,0x00,0x8b,0x00,0x02 ; -value $Value

 Нельзя использовать маски *, будет понят буквально,
 и все фильтры и т.д. Любые хитрые варианты не для ГП!

 Если раздела нет, то он будет создан. Если раздел существует, раздел не будет заменяться при создании.
 Все пути будут поняты буквально!

 Добавлены возможности: Применить, а затем проверить или только проверить.

 Понимает любой правильный тип раздела в $Path: ...Core\Registry::HK...\, Registry::HK...\, HKLM:\, HKCU:\

 Для определения места ошибки можно указать вывод подробных действий: -Verbose.

.PARAMETER Do
 Указывает, что нужно сделать.
 Варианты:
 1. Set    = Выполнить и проверить (по умолчанию).
 2. Check  = Только проверить.

.PARAMETER IgnoreWrongPath
 Указывает, что нужно игнорировать раздел реестра не для Групповой Политики
 Есть некоторые специальные параметры в ГП, которые настраивают параметры не в разделах ГП
 и не удаляют параметр при установке на "Не задано", их надо после настройки ГП удалять дополнительно.
 Эта функция и так выполняет действия в реестре до применения ГП.

.PARAMETER WriteToRegistryPol
 Влияет только на удаление параметра (Value). Указывает, что нужно внести запись на "Удаление параметра" в файл Registry.pol
 По умолчанию такие записи не вносятся и убираются при наличии из Registry.pol, если было удаление параметр.
 Так как такая запись в Registry.pol может приводить к неправильной интерпретации программой и соответственно к проблеме (Настройки ЦО багуют)

.PARAMETER OnlyThisPath
 Запрещает перенаправления в другие кусты акканутов, настраивает только текущий указанный путь,
 даже если глобально задано настраивать другие аккаунты.

.INPUTS
 Строка с командой для стандартных определенных командлетов.

.EXAMPLE
    Set-LGP -Do:Set New-ItemProperty -Path "HKLM:\SOFTWARE\0\Policies\0" -Name 'Test' -Type String -Value 0

    Описание
    --------
    Попытается выполнить указанную команду, при отсутствии раздела, создаст его.
    Затем добавит в глобальный массив $Global:SettingsGP параметры для LGPO.exe для настройки ГП.
    С выводом результата, и скрытием ошибок при выполнении.
    Одинаковое поведение для New-ItemProperty и Set-ItemProperty.

.EXAMPLE
    Set-LGP -ApplyGP

    Описание
    --------
    Выполнит настройку Групповых политик согласно параметрам в глобальном массиве $Global:SettingsGP,
    через временный файл, если массив будет наполнен. При ошибке выполнения файл настройки будет сохранен.
    После настройки, массив будет обнулен.

.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия:  1.1
       Дата:  28-04-2021
 ==================================================
#>
Function Set-LGP {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'New-ItemProperty', 'Set-ItemProperty', 'Remove-ItemProperty', 'New-Item', 'Remove-Item' )]
        [string] $Cmdlet
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'Set', Position = 1 )]
        [Alias( 'LiteralPath' )]
        [string] $Path
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set', Position = 2 )]
        [string] $Name
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set', Position = 3 )]
        [ValidateSet( 'String', 'ExpandString', 'MultiString', 'DWord', 'QWord', 'Binary' )]
        [Alias( 'PropertyType' )]
        [string] $Type
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set', Position = 4 )]
        $Value  # Без типа, чтобы была возможность наличия массивов, $null и пустой строки ''.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set' )] [switch] $Force # Не важен, используется по умолчанию.
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set' )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Do = 'Set'
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set' )]
        [switch] $IgnoreWrongPath
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set' )]
        [switch] $WriteToRegistryPol
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'Set' )]
        [switch] $OnlyThisPath
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false, ParameterSetName = 'ApplyGP' )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, ParameterSetName = 'ApplyGP' )]
        [string] $LGPOExe = $LGPOExeGlobal     # Утилита LGPO.exe
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        if ( $Do -eq 'Default' ) { $Do = 'Set' }

        # Перехват ошибок, только прерываемых исключений, в блоке Begin, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionLGP'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }


        # Получение команды действия для отображения через функцию Show-Result, или при необходимости в Verbose.
        # Выполняется чистка лишних данных, и замена переданных переменных на значения из этих переменных. Для $Value отображение ограничено 60 символами.
        [hashtable] $Params = $MyInvocation.BoundParameters

        [string] $GetValueForDisplay = $Params['Value'] -replace '[\r\n]',''
            
        [string] $ActionLGP = ($MyInvocation.Line.Replace($NameThisFunction,'').Replace('-Cmdlet', '') -Replace '(\s*-Do[:]?\s*[^\s]*\s*)',' '
                    ).Replace('$Path', "'$Path'"
                    ).Replace('$Name', "'$Name'"
                    ).Replace('$Value',"'$GetValueForDisplay'").Replace(' -OnlyThisPath', '').Trim()
        
        if ( $ActionLGP.Length -gt 258 ) { $ActionLGP = "$($ActionLGP.Substring(0,258)) ...'" }
        

        Write-Verbose "Команда:`n $ActionLGP"

        [bool] $Exit = $false

        # Если указано применить подготовленные параметры ГП.
        if ( $ApplyGP )
        {
            # Если существуют подготовленные параметры Групповых политик для LGPO.exe или надо исключить записи с удалением параметров из Registry.pol
            if ( $Global:SettingsGP -or $Global:RemoveValuesGP )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Не указана или не найдена утилита LGPO.exe" }
                if ( -not ( [System.IO.File]::Exists($LGPOExe) ))
                { Write-Warning "`n  $NameThisFunction`: $text`: '$LGPOExe'!`n " ; $Exit = $true ; Return } # Выходим из функции

                # Задаем временный файл для сохранения параметров ГП перед применением. С Расскрытием коротких имен в пути
                [string] $TempFileGP = $([System.IO.Path]::GetFullPath("$env:TEMP\SettingsGP_LGPO.txt"))

                # Если существует в системе Редактор Локальных Групповых Политик
                if ( [System.IO.File]::Exists("$env:SystemRoot\System32\gpedit.msc") )
                {
                    $text = if ( $L.s3 ) { $L.s3 } else { "Применяем настройки Групповых Политик" }
                    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

                    $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Функция" }
                    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

                    # Запущенная Консоль управления ГП мешает настроить параметры ГП!

                    $text = if ( $L.s4 ) { $L.s4 } else { "Закрываем все окна оснасток управления MMC" }
                    Write-Host "`n   $text " -ForegroundColor DarkGray
                    Get-Process -Name 'mmc' -ErrorAction SilentlyContinue | Where-Object { try { $_.CloseMainWindow() > $null ; Start-Sleep -Milliseconds 500 } catch {} }

                    [System.Collections.Generic.List[string]] $ResultGP = @()

                    [string] $MachinePol = "$env:SystemRoot\System32\GroupPolicy\Machine\Registry.pol"
                    [string] $UserPol    = "$env:SystemRoot\System32\GroupPolicy\User\Registry.pol"

                    # Получаем текущие настройки ГП и удаляем текущие файлы, чтобы настроить заново новым набором парметров, без записей на удаление параметров
                    if ( [System.IO.File]::Exists($MachinePol)  )
                    {
                        try { $ResultGP = & $LGPOExe /parse /q /m $MachinePol 2> $null } catch {}
                        
                        # Удаляем Machine Registry.pol
                        try { Remove-Item -LiteralPath \\?\$MachinePol -Force -ErrorAction SilentlyContinue } catch {}
                    }

                    if ( [System.IO.File]::Exists($UserPol)  )
                    {
                        try { $ResultGP += & $LGPOExe /parse /q /u $UserPol 2> $null } catch {}
                       
                        # Удаляем User Registry.pol
                        try { Remove-Item -LiteralPath \\?\$UserPol -Force -ErrorAction SilentlyContinue } catch {}
                    }

                    # Добавляем в конец подготовленные параметры, чтобы результат ГП был как у подготовленных, а не текущих
                    $ResultGP += $Global:SettingsGP

                    if ( $Global:RemoveValuesGP )
                    {
                        # Затираем все записи с настройкой параметров (по 4 строки на один), если они добавлены для исключения из Registry.pol
                        [array] $RemValues = @()
                        foreach ( $R in $Global:RemoveValuesGP )
                        {
                            $RemValues = $R.Split('|')

                            for ( $i = 0 ; $i -lt $ResultGP.Count ; $i++ )
                            {
                                if (( $ResultGP[$i] -eq $RemValues[2] ) -and ( $i -ge 2 ))
                                {
                                    if (( $ResultGP[$i-2] -eq $RemValues[0] ) -and ( $ResultGP[$i-1] -eq $RemValues[1] ))
                                    {
                                        try { @(($i-2)..($i+1)).Foreach({ $ResultGP.Item($_) = '' }) } catch {} # Затирание, а не удаление, чтобы номера индексов не изменялись
                                    }
                                }
                            }
                        }
                    }

                    # Сохраняем подготовленные параметры для LGPO.exe из массива во временный файл, с кодировкой Unicode c BOM, с перезаписью.
                    try { Out-File -InputObject $ResultGP -LiteralPath $TempFileGP -Encoding unicode -Force -ErrorAction Stop }
                    catch { Write-Warning "   $NameThisFunction`: Error Save Out-File: '$TempFileGP'!" }

                    Start-Sleep -Milliseconds 600

                    # Применяем настройки ГП из временного файла.
                    try { & $LGPOExe /t $TempFileGP /q 2> $null } catch {}

                    # Если была ошибка при применении файла настроек Групповых политик.
                    if ( -not $? )
                    {
                        # Если не задан файл для сохранения ошибочного файла настроек.
                        if ( -not $ErrorFileGP )
                        {
                            # Задаем файл с текущим временем для сохранения проблемных параметров ГП.
                            # Расскрываем короткие имена в пути
                            [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                            $ErrorFileGP = "$TempPath\Error_LGPO_$((Get-Date -Format 'yyyyMMdd-HHmmss')).txt"
                        }

                        $text = if ( $L.s5 ) { $L.s5 } else { "Ошибка применения параметров Групповой политики.`n   Файл с ошибочными параметрами ГП сохранен в" }
                        Write-Warning  "`n  $NameThisFunction`: $text`:`n   $ErrorFileGP"

                        # Сохраняем проблемные параметры из массива в $ErrorFileGP.
                        try { Out-File -InputObject $ResultGP -LiteralPath $ErrorFileGP -Encoding unicode -Force -ErrorAction Stop }
                        catch
                        {
                            Write-Warning "   $NameThisFunction`: Error Save Out-File: '$ErrorFileGP'!"
                            Start-Sleep -Milliseconds 1000
                        }
                    }
                    else
                    {
                        $text = if ( $L.s6 ) { $L.s6 } else { "Групповые Политики настроены" }
                        Write-Host "`n   $text`n" -ForegroundColor Green -NoNewline
                    }

                    # Удаляем временный файл.
                    try { Remove-Item -LiteralPath \\?\$TempFileGP -Force -ErrorAction SilentlyContinue }
                    catch
                    {
                        Write-Warning "   $NameThisFunction`: Error Remove Out-File: '$TempFileGP'!"
                        Start-Sleep -Milliseconds 1000
                    }
                }
                else
                {
                    $text = if ( $L.s7 ) { $L.s7 } else { "В системе Нет Групповых политик, параметры настроены в реестре" }
                    Write-Host "$NameThisFunction`: $text" -ForegroundColor DarkGreen
                }

                # Обнуляем переменную с параметрами ГП и с параметрами для исключения из Registry.pol файла
                $Global:SettingsGP = @()
                $Global:RemoveValuesGP = @()
            }
            else
            {
                $text = if ( $L.s8 ) { $L.s8 } else { "Нет подготовленных параметров в `$Global:SettingsGP для настройки Групповых политик через 'LGPO.exe'" }
                Write-Verbose "$NameThisFunction`: $text"
            }

            $Exit = $true ; Return   # Выходим из функции, переходя по всем блокам.
        }

        # Если нет глобальной переменной для накопления параметров ГП или она пустая.
        if ( -not $Global:SettingsGP.SyncRoot )
        {
            # Создаем глобальную переменную (строго типизированный список объектов), с возможностью изменения её во всех областях.
            Set-Variable -Name SettingsGP -Value @() -Scope Global -Option AllScope -Force
            [System.Collections.Generic.List[string]] $Global:SettingsGP = @()
        }
        
        # переменная для наполнения строками с "Удалением параметра" для исключения записей из итогового Registry.pol файла
        if ( -not $Global:RemoveValuesGP.SyncRoot )
        {
            Set-Variable -Name RemoveValuesGP -Value @() -Scope Global -Option AllScope -Force
            [System.Collections.Generic.List[string]] $Global:RemoveValuesGP = @()
        }

        # Создаем хэш-таблицу $ShowResult,
        # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
        Set-Variable -Name ShowResult -Value @{} -Force
        $ShowResult['Do']   = $Do
        $ShowResult['Type'] = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { "ГП" })
        $ShowResult['Info'] = $ActionLGP

        # Обработка, получение, проверка и/или применение параметров разделены на 3 части,
        # так общая скорость выполнения в среднем быстрее в 2,5 раза. З часть - это само применение и/или проверка.

        # Первая часть.
        # Обработка переданных параметров.

        # Обнуляем важные дополнительные переменные, на всякий случай.
        [psobject] $isPath = $isValue = $isType = $isZerolength = $ValueExist = $Zerolength = $null ; $OFS = ' '

        # Если для командлета New-Item передали имя, то соединяем его с путем и очищаем имя, так как оно создает раздел
        # А для Remove-Item нет параметра Name, имя будет проигнорировано для исправления критической ошибки написания, если будет указано имя
        if     (( $Cmdlet -eq 'New-Item'    ) -and  $Name ) { $Path = "$Path\$Name" ; $Name = $null }
        elseif (( $Cmdlet -eq 'Remove-Item' ) -and  $Name ) { $Name = $null }

        # Получение корневого раздела и поддиректории для методов RegistryKey (.NET), таких как OpenSubKey.
        # Понимает любой тип правильного пути.
        if ( $Path -match "(?<Root>Registry::HK[\w]+\\|HKLM:\\|HKCU:\\)(?<Subkey>[^\s][^\r\n]+[^\s])" )
        {
            [string] $Root   = $matches.Root
            [string] $SubKey = $matches.Subkey

            if     ( $Root -like "*HKCU*" -or $Root -like "*HKEY_CURRENT_USER*"   ) { $RootKey = [Microsoft.Win32.Registry]::CurrentUser  ; $ConfigGP = 'User'     }
            elseif ( $Root -like "*HKLM*" -or $Root -like "*HKEY_LOCAL_MACHINE*"  ) { $RootKey = [Microsoft.Win32.Registry]::LocalMachine ; $ConfigGP = 'Computer' }
            else
            {
                if ( -not $IgnoreWrongPath )
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { "Раздел реестра не для Групповой политики!`n   Раздел" }
                    Write-Warning "`n  $NameThisFunction`: $text`: '$Path'"

                    $Exit = $true ; Return    # Выходим из функции, переходя по всем блокам.
                }
            }
        }
        else
        {
            $text = if ( $L.s11 ) { $L.s11 } else { "Раздел реестра неверный!`n   Раздел" }
            Write-Warning "`n  $NameThisFunction`: $text`: '$Path'"

            $Exit = $true ; Return     # Выходим из функции, переходя по всем блокам.
        }

        if ( -not $IgnoreWrongPath )
        {
            # Если раздел реестра не для ГП, выходим из функции, переходя по всем блокам.
            if ( $Path -notlike "*\Policies\*" )
            {
                $text = if ( $L.s10 ) { $L.s10 } else { "Раздел реестра не для Групповой политики!`n   Раздел" }
                Write-Warning "`n  $NameThisFunction`: $text`: '$Path'"
                $Exit = $true ; Return   # Выходим из функции, переходя по всем блокам.
            }
        }

        if ( $SubKey -match "\\[*]\s*$" )
        {
            $text = if ( $L.s12 ) { $L.s12 } else { "Исключение родительского раздела нельзя использовать для Групповой политики!`n   Раздел" }
            Write-Warning "`n  $NameThisFunction`: $text`: '$Path'"
            $Exit = $true ; Return   # Выходим из функции, переходя по всем блокам.
        }

        # Если для проверки передано значение параметра.
        # IsFixedSize отпределяется только на массивах или коллекциях, а 'двоичное значение нулевой длины' является пустым массивом @() для Binary или None.
        # Пустой массив - это не '$null', не пустая строка '' и не значение. Операторы сравнения его не понимают.
        if (( $Value ) -or ( 0 -eq $Value ) -or ( $Value.IsFixedSize -is [bool] ))
        {
            # Параметр передан.
            [bool] $ValueExist = $true

            # Если переданный параметр является пустым массивом.
            if ( $Value.Count -eq 0 ) { $Zerolength = '{0}' -f $(if ( $L.s13 ) { $L.s13 } else { "Двоичное значение нулевой длины" }) }
        }

        if (( $Cmdlet -eq 'Remove-ItemProperty' ) -and ( -not $Name ))
        {
            $text = if ( $L.s14 ) { $L.s14 } else { "Не полная команда для Групповой политики!" }

            Write-Warning "`n  $NameThisFunction`: $text`:`n $ActionLGP" ; $Exit = $true ; Return
        }
        elseif ( $Cmdlet -match "New-ItemProperty|Set-ItemProperty" )
        {
            $text = if ( $L.s14 ) { $L.s14 } else { "Не полная команда для Групповой политики!" }

            if ( $Name )
            {
                if (( -not $ValueExist ) -or ( -not $Type ))
                {
                    Write-Warning "`n  $NameThisFunction`: $text`:`n $ActionLGP" ; $Exit = $true ; Return
                }
            }
            else { Write-Warning "`n  $NameThisFunction`: $text`:`n $ActionLGP" ; $Exit = $true ; Return }
        }

        # Если передан тип параметра.
        if ( $Type )
        {
            # Создаем тип параметра для LGPO.exe в правильном формате.
            if     ( $Type -eq 'String'       ) { $TypeGP = 'SZ'      }
            elseif ( $Type -eq 'ExpandString' ) { $TypeGP = 'EXSZ'    }
            elseif ( $Type -eq 'MultiString'  ) { $TypeGP = 'MULTISZ' }
            else { $TypeGP = $Type.ToUpper() }

            # Для возможности создания параметров, включая 'двоичное значение нулевой длины' для Binary,
            # если не указаны значения или указаны пустые строки '', недопустимые для определенных типов.
            if ( -not $ValueExist )
            {
                if     ( $Type -match "Binary|None"          ) {   [byte[]] $Value = ([byte[]]@())   }
                elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = ([string[]]@()) }
                elseif ( $Type -like "?word"                 ) {    [int32] $Value = 0               }
                elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = ''              }
            }
            else
            {
                if ( $Type -match "Binary|None" )
                {
                   # Если передать строку для Binary или None, она будет преобразована в массив по 2 символа с добавлением к ним '0x..' (формат HEX)
                   # Такой формат в .reg, или слитый. С любыми переносами строк.
                   if ( $Value.GetType().Name -eq 'String' )
                   {
                       [byte[]] $Value = ($Value -replace ('[\s\\]','') -replace ('([\w]{1,2}),?','0x$1;')).Split(';').Where({$_})
                   }
                   else                                        {   [byte[]] $Value = $Value }
                }
                elseif ( $Type -eq 'MultiString'             ) { [string[]] $Value = $Value }
                elseif ( $Type -eq "Dword"                   ) {    [int32] $Value = "0x$([Convert]::ToString($Value, 16))" } # Hex
                elseif ( $Type -eq "Qword"                   ) {    [int64] $Value = $Value }
                elseif ( $Type -match "^String|ExpandString" ) {   [string] $Value = $Value }
            }
        }
        else
        {
            if ( -not $ValueExist ) { [string] $Value = '' }
            else
            {
                if     ( $Value.GetType().Name -eq 'Byte[]'      ) { [string] $Type = 'Binary'      ;   [byte[]] $Value = $Value }
                elseif ( $Value.GetType().IsArray                ) { [string] $Type = 'MultiString' ; [string[]] $Value = $Value }
                elseif ( $Value.GetType().Name -eq 'String'      ) { [string] $Type = 'String'      ;   [string] $Value = $Value }
                elseif (  [int32]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Dword'       ;    [int32] $Value = $Value }
                elseif ( [Uint32]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Dword'       ;    [int32] $Value = "0x$([Convert]::ToString($Value, 16))" } # Hex
                elseif (  [int64]::TryParse("$Value",[ref]$null) ) { [string] $Type = 'Qword'       ;    [int64] $Value = $Value }
                else                                               { [string] $Type = 'String'      ;   [string] $Value = $Value }
            }
        }


        # Значения параметров из реестра выводятся в Десятичной системе исчисления (Decimal)!
        # В реестре REG_BINARY записываются в Шестнадцатеричном виде (HEX) и также отображены в Редакторе реестра!
        # Поэтому удобнее вносить параметры BINARY в виде HEX,
        # пример: -Value ([byte[]]@(0x0,0x8e,0x8f))
        #    или: -Value 0x0,0x8e,0x8f  (будет преобразован тут в массив байт)

        # Конвертируем значения для LGPO.exe в правильный формат.
        if ( $Type -eq 'Binary' )
        {
            # Конвертируем каждый элемент массива байт в HEX, и далее соединив их в строку через запятую. Для BINARY.
            [string] $ValueGP = ( & { foreach ( $i in $Value ) { [Convert]::ToString($i, 16) } } ) -join ','
        }
        elseif ( $Type -eq 'MultiString' )
        {
            # Переводим массив строк в одну строку, разделяя элементы через символы '\0'. Для MULTISZ.
            [string] $ValueGP = $Value -join '\0'
        }
        else
        {
            $ValueGP = $Value
        }

        # Вторая часть.

        # Открываем раздел в режиме только для чтения.
        # Если раздела нет, то переменная будет пустая, и раздел будет создан во время выполнения, при необходимости.
        try { $isPath = $RootKey.OpenSubKey($SubKey) } catch {}

        # Если передано имя параметра.
        if ( $Name )
        {
            try
            {
                # Получаем значение у параметра.
                # не раскрывая системные переменные в значениях, такие как %Temp% и т.д. которые бывают у параметров с типом ExpandString (REG_EXPAND_SZ).
                # Если параметра не существует, то результат будет указанный $null.
                $isValue = $isPath.GetValue($Name,$null,'DoNotExpandEnvironmentNames')

                # Получаем тип параметра, если будет получен, значит и параметр существует.
                $isType  = $isPath.GetValueKind($Name)
            }
            catch {}

            # Если тип параметра получен, значит и параметр существует.
            if ( $isType )
            {
                # Если значение полученного параметра является пустым фиксированным массивом.
                if (( $isValue.IsFixedSize ) -and ( $isValue.Count -eq 0 )) { $isZerolength = '{0}' -f $(if ( $L.s13 ) { $L.s13 } else { "Двоичное значение нулевой длины" }) }
            }
        }
    }

    Process
    {
        # Перехват ошибок, только прерываемых исключений, в блоке Process, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s1_1 ) { $L.s1_1 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionLGP'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Если нужно выйти или выполнить только проверку, переходим в End.
        if ( $Exit ) { Return }
        elseif ( $Do -eq 'Check' ) { $isAct = '(Только проверено)' ; Return } else { $isAct = "(Выполнено, затем проверено)" }

        Write-Verbose "Выполняем настройку '$Do'"

        # Параметры создаются в реестре обычным методом для возможности проверки результата,
        # так как применение Групповых политик намеренно сделано не для каждого параметра,
        # а в конце выполнения любого меню, если есть необходимость.

        # "New-ItemProperty", "Set-ItemProperty", "Remove-Item", "Remove-ItemProperty"

        if ( $Cmdlet -eq 'New-Item' )
        {
            Write-Verbose "Создание раздела '$Path'"

            # Создание раздела в реестре. Необходимо для проверки результата, так как применение
            try { $RootKey.CreateSubKey($SubKey) > $null } catch {}

            Write-Verbose "Добавление параметров ГП для LGPO.exe"

            $Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n*`nCREATEKEY")
        }
        elseif ( $Cmdlet -eq 'Remove-Item' )
        {
            # Если раздел существует.
            if ( $isPath )
            {
                Write-Verbose "Удаление всех подразделов включая этот: '$Path'"

                try { $RootKey.DeleteSubKeyTree($SubKey,$true) } catch {}
            }
            else
            {
                Write-Verbose "Раздела не существует: '$Path'"
            }

            Write-Verbose "Добавление параметров ГП для LGPO.exe, даже если нет раздела"

            # Очистка всех параметров в этом разделе, и удаление из политики всех параметров, связанных с этим разделом, подразделы не затрагивает.
            # Но если за ним идет установка параметра в этом разделе, то этот парамтер НЕ сохранится! То есть такое не нужно!
            # $Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n*`nDELETEALLVALUES")

            # Удаление всех параметров из политики, связанных с этим разделом и подразделами.
            # Если за ним идет параметр на установку значения в этом разделе или подразделе, то он остаётся, то есть то что надо!
            $Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n*`nCLEAR")
        }
        elseif (( $Cmdlet -eq 'New-ItemProperty' ) -or ( $Cmdlet -eq 'Set-ItemProperty' ))
        {
            Write-Verbose "Создание параметра '$Name' [$Type] {$Value$Zerolength}"

            try { $RootKey.CreateSubKey($SubKey).SetValue($Name,$Value,$Type) } catch {}

            Write-Verbose "Добавление параметров ГП для LGPO.exe"

            #$Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n$Name`n$TypeGP`:$ValueGP")
            $Global:SettingsGP.AddRange([System.Collections.Generic.List[string]]('',$ConfigGP,$SubKey,$Name,"$TypeGP`:$ValueGP"))

            # Удалить все строки на исключение этого параметра из Registry.pol
            while ( $Global:RemoveValuesGP.Where({ $_ -eq "$ConfigGP|$SubKey|$Name" }) )
            {
                Write-Verbose "Удаление строк на исключение: $ConfigGP|$SubKey|$Name"
                
                [void]$Global:RemoveValuesGP.Remove("$ConfigGP|$SubKey|$Name")
            }
        }
        else     # 'Remove-ItemProperty'
        {
            # Если тип параметра был получен, значит параметр существует.
            if ( $isType )
            {
                Write-Verbose "Удаление параметра '$Name' [$isType] {$isValue$isZerolength}"

                try { $RootKey.OpenSubKey($SubKey,'ReadWriteSubTree').DeleteValue($Name,$false) } catch {}
            }
            else
            {
                Write-Verbose "Нет раздела или параметра!"
            }

            # Проверка существования других параметров в этом разделе, если нет, то указание очистки всех параметров ГП,
            # относящиеся к этому разделу, подразделы не задевает.
            try { [string[]] $FoundValues = $RootKey.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() }
            catch { [string[]] $FoundValues = $null }

            if ( $FoundValues.Count )
            {
                # Если указано внести запись на "Удаление параметра" в Registry.pol, по умолчанию будут убраны из него 
                if ( $WriteToRegistryPol )
                {
                    Write-Verbose "Добавление параметров ГП для LGPO.exe, даже если нет параметра. Значение: DELETE"

                    # Задает параметр в политике, некоторые параметры его воспринимают как "Отключено", а не как "Не задано",
                    # нужно сбрасывать все политики или делать Clear у раздела. Некоторые приложения могу забаговать на таком параметре внутри Registry.pol
                    #$Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n$Name`nDELETE")
                    $Global:SettingsGP.AddRange([System.Collections.Generic.List[string]]('',$ConfigGP,$SubKey,$Name,'DELETE'))

                    # Удалить все строки на исключение этого параметра из Registry.pol
                    while ( $Global:RemoveValuesGP.Where({ $_ -eq "$ConfigGP|$SubKey|$Name" }) )
                    {
                        Write-Verbose "Удаление строк на исключение: $ConfigGP|$SubKey|$Name"
                
                        [void]$Global:RemoveValuesGP.Remove("$ConfigGP|$SubKey|$Name")
                    }
                }
                else
                {
                    Write-Verbose "Добавить в исключение из Registry.pol"
                    
                    # Добавить в исключение этого параметра из Registry.pol (из настройки через ГП), если ещё не добавлен (для исключения проблем)
                    if ( -not $Global:RemoveValuesGP.Where({$_ -eq "$ConfigGP|$SubKey|$Name" }) )
                    {
                        Write-Verbose "Добавление в исключение: $ConfigGP|$SubKey|$Name"
                        
                        $Global:RemoveValuesGP.Add("$ConfigGP|$SubKey|$Name")
                    }
                }
            }
            else
            {
                Write-Verbose "Добавление параметров ГП для LGPO.exe, даже если нет параметра. Значение: CLEAR для раздела, так как больше нет параметров"

                # Удаление всех параметров из политики, связанных с этим разделом, подразделы не затрагивает.
                # Если за ним идёт параметр на установку значения в этом разделе, то он остаётся, то есть то что надо!
                $Global:SettingsGP.Add("`n$ConfigGP`n$SubKey`n*`nCLEAR")
            }
        }
    }

    End
    {
        # Перехват ошибок, только прерываемых исключений, в блоке End, для выхода из функции.
        # И если есть глобальный trap, не отображать ошибку тут, а передать ее ему, для отображения и/или записи в лог.
        trap
        {
            $text = if ( $L.s15 ) { $L.s15 } else { "Ошибка в End" }
            Write-Warning "$NameThisFunction`: $text`: '$ActionLGP'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выйти при ошибке.
        if ( $Exit )
        {
            # Закрываем открытый раздел, для возможности выгрузки подключенных разделов, после очистки.
            if ( $isPath ) { $isPath.Close() }

            Return  # выходим из функции
        }

        Write-Verbose "Проверка $Do"

        # Если не указан параметр действий или указано выполнить, значит было выполнено действие, и теперь будет проверка результата выполнения,
        # поэтому выполняем получение параметров из реестра еще раз.
        if ( $Do -eq 'Set' )
        {
            # Обнуляем значения, полученные в самом начале.
            $isPath = $isValue = $isType = $isZerolength = $null

            # Открываем раздел в режиме только для чтения.
            try { $isPath = $RootKey.OpenSubKey($SubKey) } catch {}

            if ( $Name )
            {
                try
                {
                    # Получаем значение у параметра.
                    $isValue = $isPath.GetValue($Name,$null,'DoNotExpandEnvironmentNames')

                    # Получаем тип параметра, если будет получено, значит и параметр существует.
                    $isType  = $isPath.GetValueKind($Name)
                }
                catch {}

                # Если тип параметра получен, значит и параметр существует.
                if ( $isType )
                {
                    # Если значение полученного параметра является пустым массивом.
                    if (( $isValue.IsFixedSize ) -and ( $isValue.Count -eq 0 )) { $isZerolength = '{0}' -f $(if ( $L.s13 ) { $L.s13 } else { "Двоичное значение нулевой длины" }) }
                }
            }
        }

        $ResultFunc = $false

        # Если раздел существует.
        if ( $isPath )
        {
            # Если значение параметра передано.
            if ( $ValueExist )
            {
                # Если тип параметра получен, значит параметр существует, и передан тип параметра для проверки.
                if ( $isType )
                {
                    # "Проверка: Value и Type"

                    # Если передали имя, даже с пустой строкой '', значение и тип параметра, и они совпали с полученным именем, его значением и типом.
                    # Включая пустые массивы - 'двоичное значение нулевой длины' и пустые строки ''.
                    if (( "$Value" -eq "$isValue" ) -and ( $Type -eq $isType ))
                    {
                        # Выводим полностью совпавшие полученные: 'Имя параметра' [тип параметра] {значение}.
                        Write-Verbose "Все совпадает с '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $true
                    }
                    else
                    {
                        # Иначе, выводим переданные и не совпавшие полученные значения.
                        Write-Verbose "Не совпадает:`n   Проверили: '$Name' [$Type] {$Value$Zerolength}`n    Получили: '$Name' [$isType] {$isValue$isZerolength}"

                        $ResultFunc = $false
                    }
                }
                else
                {
                    # Иначе, тип параметра не получен, а значит и имя параметра не существует.

                    Write-Verbose "Параметр отсутствует: '$Name'"

                    $ResultFunc = $false
                }
            }
            else
            {
                # Иначе, значение параметра не передано для проверки, но раздел существует.
                # "Проверка: Name". Все варианты.

                if ( -not $Name )
                {
                    # Если имя и значение не передано. Значит хотим проверить только раздел.

                    Write-Verbose "Раздел существует: '$($isPath.Name)'"

                    $ResultFunc = $true

                }
                elseif ( $isType )
                {
                    # Иначе, Если Имя параметра передали и тип параметра получили.

                    Write-Verbose "Параметр существует: '$Name' [$isType] {$isValue$isZerolength}"

                    $ResultFunc = $true
                }
                else
                {
                    # Иначе, Если Имя параметра передали, а тип параметра не получили.

                    Write-Verbose "Параметр отсутствует: '$Name'"

                    $ResultFunc = $false
                }
            }
        }
        else
        {
            # Иначе, раз раздела не существует, выводим переданный раздел, из-за его отсутствия.
            # "Проверка: Path"
            Write-Verbose "Раздел отсутствует: '$Path'"

            $ResultFunc = $false
        }

        # Закрываем открытый раздел, для возможности выгрузки подключенных разделов, после очистки.
        if ( $isPath ) { $isPath.Close() }

        # "Set-Item", "Set-ItemProperty", "New-Item", "New-ItemProperty" = True - параметр соответствует результату выполняемого действия, значит все верно.
        # "Remove-Item", "Remove-ItemProperty",  "Rename-ItemProperty"   = True - Для удаляющих командлетов наличие параметра для выполнения имеет противоположное значение, значит неверно.

        # Для командлетов, которые удаляют или изменяют параметр, результат делаем противоположным.
        # Так как совпадение с заданным параметром значит, что действие не выполнено.
        if ( $Cmdlet -match "Remove-|Rename-ItemProperty" ) { if ( $ResultFunc ) { $ResultFunc = $false } else { $ResultFunc = $true } }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo   [Параметр правильный]  $isAct"

            $ShowResult['Result'] = '+'

            if ( $Do -eq 'Set' ) { $ShowResult['Status'] = '{0}' -f $(if ( $L.s16 ) { $L.s16 } else { "Выполнено" }) }
            else                 { $ShowResult['Status'] = '{0}' -f $(if ( $L.s17 ) { $L.s17 } else { "Верно"     }) }
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр не правильный]  $isAct"

            $ShowResult['Result'] = '!!!'
            $ShowResult['Status'] = '{0}' -f $(if ( $L.s18 ) { $L.s18 } else { "Неверно" })
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult

        # Внесение параметров в подключенные кусты других аккаунтов, если существует переменная с нужными данными
        if ( $Global:DataAllUsers.Redirects.Value -and -not $OnlyThisPath )
        {
            foreach ( $User in $Global:DataAllUsers )
            {
                if ( $User.SID )
                {
                    if (( -not $Global:DataAllUsers.Redirects.DefaultAccount ) -and ( $User.ProfileType -eq 'DefaultAccount' )) { Continue } # Пропуск перенаправления на дефолтный пррофиль

                    if ( "$ConfigGP\$SubKey" -like "User\?*" -and -not ( "$ConfigGP\$SubKey" -like "User\Software\Classes\?*" ))
                    {
                        if ( $true -like $User.NTUSER_Load )
                        {
                            $RootNew = "Registry::HKU\$($User.SID)"
                            $RootNewIn = [Microsoft.Win32.Registry]::Users.GetSubKeyNames() -like $RootNew

                            if ( -not $RootNewIn )
                            {
                                $TestUser = RegHives-User-LoadUnload $User -Silent -Load
                                
                                if ( -not $TestUser.NTUSER_Load ) { $User.NTUSER_Load = $false ; continue }
                            }

                            $PathNew  = "$RootNew\$SubKey"
                            $PathShow = ($PathNew -replace ('Registry::HKU\\S-1-5-21-[\d]+-[\d]+-[\d]+([^\\]+)(.+)','#DarkCyan#HKU\*$1#DarkGray#$2')).Replace('HKU\*-5','HKU\**-5')

                            Set-Reg -Do:$Do -Cmdlet:$Cmdlet -Path:$PathNew -Name:$Name -Type:$(if(-not$Type){'Unknow'}else{$Type}) -Value:$Value -ShowAction $ActionLGP.Replace($Path,$PathShow)
                        }
                    }
                }
            }
        }
    }
}
