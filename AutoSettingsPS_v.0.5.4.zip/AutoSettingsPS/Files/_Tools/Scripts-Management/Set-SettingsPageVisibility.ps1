﻿
<#
.SYNOPSIS
 Добавление значений к параметру SettingsPageVisibility, только для hide: !!!
 для скрытия отдельных страниц настроек из "Системные параметры".

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Для выполнения всех действий нужны права администратора.

 Все значения сортируются по алфавиту и убираются дубликаты.

 Эта настройка в оснастке Групповой Политики (gpedit.msc) для компьютера:
 Комп\Адм. Шабл\Панель управления\ "Отображение страницы параметров"

.EXAMPLE
    Set-SettingsPageVisibility -Names 'gaming-broadcasting','gaming-gamebar'

    Описание
    --------
    Добавление значений к параметру SettingsPageVisibility для скрытия этих разделов из Параметров системы.

.EXAMPLE
    Set-SettingsPageVisibility -Names 'gaming-broadcasting;gaming-gamebar'

    Описание
    --------
    Добавление значений к параметру SettingsPageVisibility для скрытия этих разделов из Параметров системы.


.EXAMPLE
    Set-SettingsPageVisibility -Names 'hide:gaming-broadcasting;gaming-gamebar'

    Описание
    --------
    Добавление значений к параметру SettingsPageVisibility для скрытия этих разделов из Параметров системы.

.EXAMPLE
    Set-SettingsPageVisibility -Names 'gaming-broadcasting','gaming-gamebar' -Remove

    Описание
    --------
    Удаление значений из параметра SettingsPageVisibility.

.EXAMPLE
    Set-SettingsPageVisibility -Names 'hide:gaming-broadcasting;gaming-gamebar' -Remove

    Описание
    --------
    Удаление значений из параметра SettingsPageVisibility.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  08-04-2019
 ===============================================

#>
Function Set-SettingsPageVisibility {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string])]
    Param(
        [Parameter( Mandatory = $true,  Position = 0 )]
        [ValidateNotNullOrEmpty()]
        [string[]] $Names
       ,
        [Parameter( Mandatory = $false, Position = 1 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Default чтобы применялось как Set и не было ошибок
        [string] $Act = 'Set'
       ,
        [Parameter( Mandatory = $false )]
        [switch] $CheckOutForMenu
       ,
        [Parameter( Mandatory = $false )]
        [switch] $Remove
       ,
        [Parameter( Mandatory = $false )]
        [switch] $ApplyGP
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -eq 'Default' ) { $Act = 'Set' }

    [string] $Root = 'HKLM:'
    [string] $SubKey = "SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"
    [string] $Path = "$Root\$SubKey"
    $OFS = ' '

    $text = if ( $L.s1 ) { $L.s1 } else { "Использование 'showonly:' не предусмотрено" }
    if ( $Names -like '*showonly:*' ) { Write-Warning "$NameThisFunction`: $text"  ; Return }

    # Удаляем дубликаты и сортируем по алфавиту, разделяем на отдельные элементы, если переданы одной строкой все.
    $Names = $Names | ForEach-Object { $_.Replace('hide:','').Split(';') } | Select-Object -Unique | Sort-Object

    # Создаем строку для добавления в реестр, если параметр не существует.
    [string] $Value = "hide:{0}" -f ($Names -join ';')

    # Открываем раздел.
    try { [psobject] $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues') }
    catch { [psobject] $OpenSubKey = $null }

    if ( $Act -eq 'Set' )
    {
        # Если раздел существует.
        if ( $OpenSubKey )
        {
            # Получаем значение параметра SettingsPageVisibility.
            [string] $GetValue = $OpenSubKey.GetValue('SettingsPageVisibility',$null)

            # Если параметр получен.
            if ( $GetValue )
            {
                # Получаем массив элементов $GetArray, разбивая строку с параметрами по символам ';',
                # и убирая 'hide:' и необходимые элементы для добавления, чтобы не было дубликатов.
                [string[]] $GetArray = $GetValue.Replace('hide:','').Split(';').Where({ $_ -notmatch ($Names -join '|') })

                # Получаем новый массив с именами $isNames, исключая пустые елементы из $GetArray, на всякий случай.
                [string[]] $isNames = $null
                $GetArray | ForEach-Object { if ( $_ ) { [string[]] $isNames += $_ }}

                if ( $isNames -like '*showonly:*' ) { [string[]] $isNames = $null }

                if ( $Remove )
                {
                    # Удаляем дубликаты и сортируем по алфавиту.
                    $isNames = $isNames | Select-Object -Unique | Sort-Object

                    # Если массив не пустой, добавляем необходимые указанные элементы к $Value,
                    # и создаем значение из всех полученных, кроме удаленных указанных элементов.
                    # Иначе, Массив пустой после удаления, создаем пустое значение.
                    if ( $isNames.Count ) { [string] $Value = "hide:{0}" -f ($isNames -join ';') }
                    else { [string] $Value = '' }
                }
                else
                {
                    # Удаляем дубликаты и сортируем по алфавиту.
                    $isNames = ( $isNames += $Names ) | Select-Object -Unique | Sort-Object

                    # Cоздаем значения для $Value с нуля из указанных и полученных (если есть) элементов,
                    # соединяя массив в строку через символы ';' и добавляя в начало 'hide:'.
                    [string] $Value = "hide:{0}" -f ( $isNames -join ';' )
                }
            }
            else { if ( $Remove ) { [string] $Value = '' } }

            # Закрываем открытый раздел.
            $OpenSubKey.Close()
        }

        if ( $Value )
        {
            if ( $Remove )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Возврат скрытых разделов из настроек" }
                Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Функция" }
                Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

                $text = if ( $L.s3 ) { $L.s3 } else { "Возврат" }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Names -join ', ' )`n" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Cкрытие разделов из настроек" }
                Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Функция" }
                Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

                $text = if ( $L.s5 ) { $L.s5 } else { "Скрытие" }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Names -join ', ' )`n" -ForegroundColor DarkCyan
            }

            # Устанавливаем итоговое значение.
            Set-LGP -Do:$Act New-ItemProperty -Path $Path -Name 'SettingsPageVisibility' -Type String -Value $Value
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Возврат скрытых разделов из настроек" }
            Write-Host "`n██ $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Функция" }
            Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

            $text = if ( $L.s3 ) { $L.s3 } else { "Возврат" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($Names -join ', ' )`n" -ForegroundColor DarkCyan

            # Удаляем параметр вообще полностью, так как значение пустое.
            Set-LGP -Do:$Act Remove-ItemProperty -Path $Path -Name 'SettingsPageVisibility'
        }
    }
    else
    {
        [string[]] $isNames      = $null
        [string[]] $FoundNames   = $null
            [bool] $isDifference = $true

        # Если раздел существует.
        if ( $OpenSubKey )
        {
            # Получаем значение параметра SettingsPageVisibility.
            [string] $GetValue = $OpenSubKey.GetValue('SettingsPageVisibility',$null)

            # Если параметр получен.
            if ( $GetValue )
            {
                [string[]] $GetArray = $GetValue.Replace('hide:','').Split(';')

                # Получаем новый массив с именами $isNames, исключая пустые елементы из $GetArray, на всякий случай.
                $GetArray | ForEach-Object { if ( $_ ) { [string[]] $isNames += $_ }}

                if ( $isNames -like '*showonly:*' ) { [string[]] $isNames = $null }

                [string[]] $FoundNames = $Names | Where-Object { -not ( $isNames -like $_ ) }

                if ( -not $FoundNames.Count ) { [bool] $isDifference = $false }
            }

            # Закрываем открытый раздел.
            $OpenSubKey.Close()
        }

        [string] $GetNamesForDisplay = $Names -join "', '"
        [string] $ActionHIDE = "$NameThisFunction -Names '$GetNamesForDisplay'"

        Write-Verbose "Команда:`n $ActionHIDE"

        # Создаем хэш-таблицу $ShowResult, с возможностью изменять ее во внутренних временных функциях.
        # И наполняем полученными данными для вывода в консоль, через фукнцию Show-Result.
        Set-Variable -Name ShowResult -Value @{} -Option AllScope -Force
        $ShowResult['Do']   = $Act
        $ShowResult['Type'] = '{0}' -f $(if ( $L.s6 ) { $L.s6 } else { "Настройки" })
        $ShowResult['Info'] = & { if ( $ActionHIDE.Length -gt 258 ) { "$($ActionHIDE.Substring(0,258)) ...'" } else { $ActionHIDE } }

        if ( $isDifference )
        {
            if ( $CheckOutForMenu )
            {
                "#Yellow#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Не скрыто" })

                Return
            }
            else
            {
                if ( $Remove ) { $ShowResult['Result'] = '+' ; [bool] $ResultFunc = $true } else { $ShowResult['Result'] = '!!!' ; [bool] $ResultFunc = $false }

                $ShowResult['Status'] = '{0}' -f $(if ( $L.s9 ) { $L.s9 } else { "Не скрыто" })
            }
        }
        else
        {
            if ( $CheckOutForMenu )
            {
                "#Green#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { "Скрыто   " })

                Return
            }
            else
            {
                if ( $Remove ) { $ShowResult['Result'] = '!!!' ; [bool] $ResultFunc = $false } else { $ShowResult['Result'] = '+' ; [bool] $ResultFunc = $true }

                $ShowResult['Status'] = '{0}' -f $(if ( $L.s10 ) { $L.s10 } else { "Cкрыто" })
            }
        }

        # Если параметр неверный, специальная глобальная переменная $NeedFix будет установлена в $true.
        if ( $ResultFunc )
        {
            Write-Verbose "   Вернo   [Параметр правильный]  $isAct"
        }
        else
        {
            $NeedFix = $true

            Write-Verbose "   Неверно   [Параметр неверный]  $isAct"
        }

        # Передаем таблицу с итоговыми данными в функцию для форматированного под стандарт вывода в консоль.
        Show-Result @ShowResult

        Return
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings )
        {
            Get-Pause
        }
    }
}
