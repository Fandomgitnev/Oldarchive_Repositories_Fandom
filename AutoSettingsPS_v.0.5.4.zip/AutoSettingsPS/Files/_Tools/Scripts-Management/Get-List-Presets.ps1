﻿
<#
.SYNOPSIS
 Получить список настроек из первого по алфавиту файла пресета, начинающегося с имени указанного файла,
 если таких нет, то открытие указанного файла, если он есть.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS

 Используется для получения пресетов из текущего файла пресетов в глобальную переменную

.EXAMPLE
    Get-List-Presets -FilePresets 'C:\Presets.txt'

    Описание
    --------
    Получить список настроек из первого файла подходящего под шаблон "Presets*.txt".

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  30.09.2020
 ===============================================

#>
Function Get-List-Presets {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false, Position = 1 )]
        [string] $File = $FilePresetsGlobal
    )

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($File)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($File)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($File)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $File = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($File) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$File -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }
}