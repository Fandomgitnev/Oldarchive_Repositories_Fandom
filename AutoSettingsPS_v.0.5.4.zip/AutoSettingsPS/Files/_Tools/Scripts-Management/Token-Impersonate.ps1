﻿
<#
.SYNOPSIS
 Олицетворение (Impersonate) себя за TrustedInstaller или SYSTEM (подключение токена от этих процессов).
 С их доступом и + дополнительно включенными у полученного токена всеми доступными для него привилегиями.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Олицетворение (Impersonate) - "Представиться другим" подменой токена.
 Это легальная возможность через WIN API.
 Берется токен у процесса с необходимым доступом, и подменяется вместо токена у текущей среды.
 Текущая среда получает доступ и привилегии того процесса, оставаясь при этом в своем окружении!
 То есть раздел реестра HKCU остается доступным.

 Подмена токена (Impersonate) у текущей среды осуществляется
 без перезапуска текущего процесса, то есть на лету.
 С возможностью сброса Олицетворения.

 У Токена дополнительно включаются все возможные, но не задействованные привилегии.

 При Олицетворении в системе доступны не все действия, особенно при TrustedInstaller!
 Так как эти токены специально урезанные для разграничения доступов безопасности.
 TrustedInstaller - это права System, но со своими привилегиями и возможностями.
 Для доступа к файловой системе или реестру при любом Олицетворении работает корректно.
 При Олицетворении за TrustedInstaller нет доступа на применение SDDL и некоторые другие.

 Также закрыт доступ в некоторых случаях на изменение к WMI, например не дает доступ к CIM ресурсам через SCHTASKS,
 но через командлеты типа Enable-ScheduledTask дает.
 Настройку планировщика задач Windows можно выполнить через запуск отдельного процесса,
 с нужными правами, или получать доступ на файлы задач и/или реестр.
 Использование DISM под Impersonate за TI также не получится, или whoami.exe и др.

 Если параметр запуска службы TrustedInstaller будет измененный,
 то он будет восстановлен "По умолчанию",
 чтобы была возможность запустить TrustedInstaller для получения его токена.

.PARAMETER Token
 Чьим токеном осуществить олицетворение.
 TI  = токен с правами TrustedInstaller. Берется у службы TrustedInstaller.
 SYS = токен с правами SYSTEM (S-1-5-18). Берется у процесса winlogon.exe.
 Токены берутся только один раз в текущей сессии, далее используются все время сохраненные в переменных.

.PARAMETER Reset
 Сброс Олицетворения, сохраняя возможность повторного олицетворения,
 мгновенно, без получения.

.EXAMPLE
    Token-Impersonate -Token SYS

    Описание
    --------
    Олицетворение текущей среды за System.
    Без вывода подробностей.


.EXAMPLE
    Token-Impersonate -Token TI -Verbose

    Описание
    --------
    Олицетворение текущей среды за TrustedInstaller.
    С выводом подробных действий.

.EXAMPLE
    Token-Impersonate -Reset

    Описание
    --------
    Сброс Олицетворения.
    Без вывода подробностей.


.NOTES
 ================================================
     Автор:  westlife (ru-board)   Версия 1.0
      Дата:  14-04-2019
 ================================================

#>
Function Token-Impersonate {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([bool])]
    Param (
        [parameter( Mandatory = $false, ParameterSetName = 'Token', Position = 0 )]
        [ValidateSet( 'TI', 'SYS' )]
        [string] $Token = 'SYS'
       ,
        [parameter( Mandatory = $true,  ParameterSetName = 'ResetToken' )]
        [switch] $Reset
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Ошибка в Begin" }
            Write-Warning "$NameThisFunction`: $text`:`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        [bool] $Exit = $false

        [string] $GetTokenAPI = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public static class WinBase
    {
        [StructLayout( LayoutKind.Sequential )]
        public struct SECURITY_ATTRIBUTES
        {
            public int nLength;
            public IntPtr lpSecurityDescriptor;
            public int bInheritHandle;
        }

        [StructLayout( LayoutKind.Sequential )]
        public struct STARTUPINFO
        {
            public Int32 cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public Int32 dwX;
            public Int32 dwY;
            public Int32 dwXSize;
            public Int32 dwYSize;
            public Int32 dwXCountChars;
            public Int32 dwYCountChars;
            public Int32 dwFillAttribute;
            public Int32 dwFlags;
            public Int16 wShowWindow;
            public Int16 cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        [StructLayout( LayoutKind.Sequential )]
        public struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public int dwProcessId;
            public int dwThreadId;
        }
    }

    public static class WinNT
    {
        public const Int32 ANYSIZE_ARRAY = 1;
        public const string SE_ASSIGNPRIMARYTOKEN_NAME = "SeAssignPrimaryTokenPrivilege";
        public const string SE_AUDIT_NAME = "SeAuditPrivilege";
        public const string SE_BACKUP_NAME = "SeBackupPrivilege";
        public const string SE_CHANGE_NOTIFY_NAME = "SeChangeNotifyPrivilege";
        public const string SE_CREATE_GLOBAL_NAME = "SeCreateGlobalPrivilege";
        public const string SE_CREATE_PAGEFILE_NAME = "SeCreatePagefilePrivilege";
        public const string SE_CREATE_PERMANENT_NAME = "SeCreatePermanentPrivilege";
        public const string SE_CREATE_SYMBOLIC_LINK_NAME = "SeCreateSymbolicLinkPrivilege";
        public const string SE_CREATE_TOKEN_NAME = "SeCreateTokenPrivilege";
        public const string SE_DEBUG_NAME = "SeDebugPrivilege";
        public const string SE_ENABLE_DELEGATION_NAME = "SeEnableDelegationPrivilege";
        public const string SE_IMPERSONATE_NAME = "SeImpersonatePrivilege";
        public const string SE_INC_BASE_PRIORITY_NAME = "SeIncreaseBasePriorityPrivilege";
        public const string SE_INCREASE_QUOTA_NAME = "SeIncreaseQuotaPrivilege";
        public const string SE_INC_WORKING_SET_NAME = "SeIncreaseWorkingSetPrivilege";
        public const string SE_LOAD_DRIVER_NAME = "SeLoadDriverPrivilege";
        public const string SE_LOCK_MEMORY_NAME = "SeLockMemoryPrivilege";
        public const string SE_MACHINE_ACCOUNT_NAME = "SeMachineAccountPrivilege";
        public const string SE_MANAGE_VOLUME_NAME = "SeManageVolumePrivilege";
        public const string SE_PROF_SINGLE_PROCESS_NAME = "SeProfileSingleProcessPrivilege";
        public const string SE_RELABEL_NAME = "SeRelabelPrivilege";
        public const string SE_REMOTE_SHUTDOWN_NAME = "SeRemoteShutdownPrivilege";
        public const string SE_RESTORE_NAME = "SeRestorePrivilege";
        public const string SE_SECURITY_NAME = "SeSecurityPrivilege";
        public const string SE_SHUTDOWN_NAME = "SeShutdownPrivilege";
        public const string SE_SYNC_AGENT_NAME = "SeSyncAgentPrivilege";
        public const string SE_SYSTEM_ENVIRONMENT_NAME = "SeSystemEnvironmentPrivilege";
        public const string SE_SYSTEM_PROFILE_NAME = "SeSystemProfilePrivilege";
        public const string SE_SYSTEMTIME_NAME = "SeSystemtimePrivilege";
        public const string SE_TAKE_OWNERSHIP_NAME = "SeTakeOwnershipPrivilege";
        public const string SE_TCB_NAME = "SeTcbPrivilege";
        public const string SE_TIME_ZONE_NAME = "SeTimeZonePrivilege";
        public const string SE_TRUSTED_CREDMAN_ACCESS_NAME = "SeTrustedCredManAccessPrivilege";
        public const string SE_UNDOCK_NAME = "SeUndockPrivilege";
        public const string SE_UNSOLICITED_INPUT_NAME = "SeUnsolicitedInputPrivilege";

        public enum TOKEN_TYPE
        {
            TokenPrimary = 1,
            TokenImpersonation
        }

        public enum SECURITY_IMPERSONATION_LEVEL
        {
            SecurityAnonymous,
            SecurityIdentification,
            SecurityImpersonation,
            SecurityDelegation
        }

        [StructLayout( LayoutKind.Sequential )]
        public struct LUID
        {
            public uint LowPart;
            public int HighPart;
        }

        [StructLayout( LayoutKind.Sequential, Pack = 4 )]
        public struct LUID_AND_ATTRIBUTES
        {
            public LUID Luid;
            public UInt32 Attributes;
        }

        public struct TOKEN_PRIVILEGES
        {
            public UInt32 PrivilegeCount;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst=WinNT.ANYSIZE_ARRAY)]
            public LUID_AND_ATTRIBUTES [] Privileges;
        }
    }

    public static class Advapi32
    {
        public const int SE_PRIVILEGE_ENABLED = 0x00000002;
        public const UInt32 STANDARD_RIGHTS_REQUIRED = 0x000F0000;
        public const UInt32 STANDARD_RIGHTS_READ = 0x00020000;
        public const UInt32 TOKEN_ASSIGN_PRIMARY = 0x0001;
        public const UInt32 TOKEN_DUPLICATE = 0x0002;
        public const UInt32 TOKEN_IMPERSONATE = 0x0004;
        public const UInt32 TOKEN_QUERY = 0x0008;
        public const UInt32 TOKEN_QUERY_SOURCE = 0x0010;
        public const UInt32 TOKEN_ADJUST_PRIVILEGES = 0x0020;
        public const UInt32 TOKEN_ADJUST_GROUPS = 0x0040;
        public const UInt32 TOKEN_ADJUST_DEFAULT = 0x0080;
        public const UInt32 TOKEN_ADJUST_SESSIONID = 0x0100;
        public const UInt32 TOKEN_READ = (STANDARD_RIGHTS_READ | TOKEN_QUERY);
        public const UInt32 TOKEN_ALL_ACCESS = (
            STANDARD_RIGHTS_REQUIRED | TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE |
            TOKEN_IMPERSONATE | TOKEN_QUERY | TOKEN_QUERY_SOURCE | TOKEN_ADJUST_PRIVILEGES |
            TOKEN_ADJUST_GROUPS | TOKEN_ADJUST_DEFAULT | TOKEN_ADJUST_SESSIONID
        );

        [Flags]
        public enum CreateProcessFlags : uint
        {
            DEBUG_PROCESS = 0x00000001,
            DEBUG_ONLY_THIS_PROCESS = 0x00000002,
            CREATE_SUSPENDED = 0x00000004,
            DETACHED_PROCESS = 0x00000008,
            CREATE_NEW_CONSOLE = 0x00000010,
            NORMAL_PRIORITY_CLASS = 0x00000020,
            IDLE_PRIORITY_CLASS = 0x00000040,
            HIGH_PRIORITY_CLASS = 0x00000080,
            REALTIME_PRIORITY_CLASS = 0x00000100,
            CREATE_NEW_PROCESS_GROUP = 0x00000200,
            CREATE_UNICODE_ENVIRONMENT = 0x00000400,
            CREATE_SEPARATE_WOW_VDM = 0x00000800,
            CREATE_SHARED_WOW_VDM = 0x00001000,
            CREATE_FORCEDOS = 0x00002000,
            BELOW_NORMAL_PRIORITY_CLASS = 0x00004000,
            ABOVE_NORMAL_PRIORITY_CLASS = 0x00008000,
            INHERIT_PARENT_AFFINITY = 0x00010000,
            INHERIT_CALLER_PRIORITY = 0x00020000,
            CREATE_PROTECTED_PROCESS = 0x00040000,
            EXTENDED_STARTUPINFO_PRESENT = 0x00080000,
            PROCESS_MODE_BACKGROUND_BEGIN = 0x00100000,
            PROCESS_MODE_BACKGROUND_END = 0x00200000,
            CREATE_BREAKAWAY_FROM_JOB = 0x01000000,
            CREATE_PRESERVE_CODE_AUTHZ_LEVEL = 0x02000000,
            CREATE_DEFAULT_ERROR_MODE = 0x04000000,
            CREATE_NO_WINDOW = 0x08000000,
            PROFILE_USER = 0x10000000,
            PROFILE_KERNEL = 0x20000000,
            PROFILE_SERVER = 0x40000000,
            CREATE_IGNORE_SYSTEM_DEFAULT = 0x80000000,
        }

        [DllImport( "advapi32.dll", SetLastError = true )]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool OpenProcessToken(
            IntPtr ProcessHandle,
            UInt32 DesiredAccess,
            out IntPtr TokenHandle
        );

        [DllImport( "advapi32.dll", CharSet = CharSet.Auto, SetLastError = true )]
        public extern static bool DuplicateTokenEx(
            IntPtr hExistingToken,
            uint dwDesiredAccess,
            ref WinBase.SECURITY_ATTRIBUTES lpTokenAttributes,
            WinNT.SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,
            WinNT.TOKEN_TYPE TokenType,
            out IntPtr phNewToken
        );

        [DllImport( "advapi32.dll", CharSet = CharSet.Auto, SetLastError = true )]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool LookupPrivilegeValue(
            string lpSystemName,
            string lpName,
            out WinNT.LUID lpLuid
        );

        [DllImport( "advapi32.dll", SetLastError = true )]
        public static extern bool AdjustTokenPrivileges(
            IntPtr TokenHandle,
            [MarshalAs(UnmanagedType.Bool)]bool DisableAllPrivileges,
            ref WinNT.TOKEN_PRIVILEGES NewState,
            UInt32 Zero,
            IntPtr Null1,
            IntPtr Null2
        );

        [DllImport( "advapi32.dll", SetLastError = true )]
        public static extern bool ImpersonateLoggedOnUser(
            IntPtr hToken
        );

        [DllImport( "advapi32.dll", SetLastError = true )]
        public static extern bool CreateProcessAsUser(
            IntPtr hToken,
            string lpApplicationName,
            string lpCommandLine,
            ref WinBase.SECURITY_ATTRIBUTES lpProcessAttributes,
            ref WinBase.SECURITY_ATTRIBUTES lpThreadAttributes,
            bool bInheritHandles,
            uint dwCreationFlags,
            IntPtr lpEnvironment,
            string lpCurrentDirectory,
            ref WinBase.STARTUPINFO lpStartupInfo,
            out WinBase.PROCESS_INFORMATION lpProcessInformation
        );

        [DllImport( "advapi32.dll", CharSet = CharSet.Auto, SetLastError = true )]
        public static extern bool RevertToSelf();
    }

    public static class Kernel32
    {
        [Flags]
        public enum ProcessAccessFlags : uint
        {
            All = 0x001F0FFF,
            Terminate = 0x00000001,
            CreateThread = 0x00000002,
            VirtualMemoryOperation = 0x00000008,
            VirtualMemoryRead = 0x00000010,
            VirtualMemoryWrite = 0x00000020,
            DuplicateHandle = 0x00000040,
            CreateProcess = 0x000000080,
            SetQuota = 0x00000100,
            SetInformation = 0x00000200,
            QueryInformation = 0x00000400,
            QueryLimitedInformation = 0x00001000,
            Synchronize = 0x00100000
        }

        [DllImport( "kernel32.dll", SetLastError = true )]
        public static extern IntPtr OpenProcess(
            ProcessAccessFlags processAccess,
            bool bInheritHandle,
            int processId
        );
    }

    public static class UserEnv
    {
        [DllImport( "userenv.dll", SetLastError = true )]
        public static extern bool CreateEnvironmentBlock(
            ref IntPtr lpEnvironment,
            IntPtr hToken,
            bool bInherit
        );
    }
}
'@
        if ( -not ( 'WinAPI.WinBase' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $GetTokenAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        # Если не получена еще, то получаем в глобальную переменную идентификацию (личность) у текущей среды (оболочки),
        # для возможности сброса любых Олицетворений (подключенных токенов).
        if ( 'System.Security.Principal.WindowsImpersonationContext' -ne "$Global:CurrentShell" )
        {
            Write-Verbose "Получаем идентификацию текущей оболочки без Олицетворения, для возможности сброса Олицетворения"

            # Сбрасываем олицетворение, чтобы получить доступ к текущей оболочке без олицетворения, оно может уже быть выполнено.
            # Но так как этот сброс полный, то нужно после этого получить идентификацию текущей оболочки обратно.
            # Иначе после этого не будет доступа для некоторых действий с WMI,
            # например для использования командлета Test-Connection, если он был выполнен хотябы раз под чужим олицетворением.
            [WinAPI.Advapi32]::RevertToSelf() > $null

            if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -ne 'Impersonation' )
            {
                # Получаем идентификацию текущей среды, включая олицетворение себя на себя.
                [PSObject] $Global:CurrentShell = [System.Security.Principal.WindowsIdentity]::GetCurrent().Impersonate()

                # Сбрасываем Олицетворение себя на себя после получения идентификации, тем самым восстанавливаем идентификацию после RevertToSelf().
                try { $Global:CurrentShell.Undo()    } catch {}
                try { $Global:CurrentShell.Dispose() } catch {}
            }
            else
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Ошибка, текущая оболочка уже с Олицетворением!" }
                Write-Warning "$NameThisFunction`: $text"

                [bool] $Exit = $true ; Return
            }
        }

        # Если указан Cброс Олицетворения.
        if ( $Reset )
        {
            # Если олцетворение уже выполнено.
            if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -eq 'Impersonation' )
            {
                Write-Verbose "Сбрасываем Олицетворение"

                # На всякий случай, если с первого раза не бедет сброшено Олицетворение, будут дополнительные попытки сброса, но не больше 10 раз.
                [int] $DisposeCount = 0
                while ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -eq 'Impersonation' )
                {
                    try { $Global:CurrentShell.Undo()    } catch {}
                    try { $Global:CurrentShell.Dispose() } catch {}

                    if ( [System.Security.Principal.WindowsIdentity]::GetCurrent().ImpersonationLevel -eq 'Impersonation' )
                    {
                        Start-Sleep -Milliseconds 100 ; $DisposeCount++
                        if ( $DisposeCount -eq 10 )
                        {
                            $text = if ( $L.s3 ) { $L.s3 } else { "Ошибка, Олицетворение не сброшено!" }
                            Write-Warning "$text"

                            [bool] $Exit = $true ; Return
                        }
                    }
                    else { Write-Verbose "Сброшено" }
                }
            }
            else { Write-Verbose "Сброс Олицетворения не требуется." }

            [bool] $Exit = $true ; Return  # Выходим из функции.
        }

        # Внутренняя функция получения дубликата токена.
        Function Duplicate-ProcessToken {

            [CmdletBinding( SupportsShouldProcess = $false )]
            [OutputType([IntPtr],[bool])]
            Param (
                [parameter( Mandatory = $true,  Position = 0 )]
                [int] $ProcessID
               ,
                [parameter( Mandatory = $false, Position = 1 )]
                [ValidateSet( 'Primary', 'Impersonation' )]
                [string] $TokenType = 'Impersonation'
            )

            Write-Verbose "Получение токена у ID процесса: '$ProcessID'"

            [IntPtr] $ProcessHandle = [WinAPI.Kernel32]::OpenProcess( [WinAPI.Kernel32+ProcessAccessFlags]::All, $true, $ProcessID )
            [uint32] $DesiredAccess = [WinAPI.Advapi32]::TOKEN_QUERY -bor [WinAPI.Advapi32]::TOKEN_DUPLICATE -bor [WinAPI.Advapi32]::TOKEN_ASSIGN_PRIMARY
            [IntPtr] $ProcessToken  = New-Object -TypeName System.IntPtr
            [WinAPI.Advapi32]::OpenProcessToken($ProcessHandle, $DesiredAccess, [Ref] $ProcessToken) > $null

            Write-Verbose "Получение дубликата токена с полным доcтупом, с Типом: '$TokenType'"

            [IntPtr] $NewProcessToken = New-Object -TypeName System.IntPtr
            [uint32] $DesiredAccess   = [WinAPI.Advapi32]::TOKEN_ALL_ACCESS

            [PSObject] $SecurityAttributes = New-Object -TypeName WinAPI.WinBase+SECURITY_ATTRIBUTES
                       $SecurityAttributes.nLength = [System.Runtime.InteropServices.Marshal]::SizeOf($SecurityAttributes)
            [PSObject] $ImpersonationLevel = [WinAPI.WinNT+SECURITY_IMPERSONATION_LEVEL]::SecurityImpersonation

            if ( $TokenType -eq 'Impersonation' )
            {      [PSObject] $isTokenType = [WinAPI.WinNT+TOKEN_TYPE]::TokenImpersonation }
            else { [PSObject] $isTokenType = [WinAPI.WinNT+TOKEN_TYPE]::TokenPrimary }

            [WinAPI.Advapi32]::DuplicateTokenEx( $ProcessToken, $DesiredAccess, [Ref] $SecurityAttributes, $ImpersonationLevel, $isTokenType, [Ref] $NewProcessToken ) > $null

            Write-Verbose "Включение всех привилегий у токена (которые отключены у TI и System)"

            [string[]] $Privilages = 'SeAssignPrimaryTokenPrivilege','SeIncreaseQuotaPrivilege','SeLoadDriverPrivilege',
                                     'SeTakeOwnershipPrivilege','SeBackupPrivilege', 'SeRestorePrivilege',
                                     'SeSecurityPrivilege','SeShutdownPrivilege','SeSystemEnvironmentPrivilege','SeManageVolumePrivilege',
                                     'SeTrustedCredmanAccessPrivilege','SeUndockPrivilege','SeSystemTimePrivilege','SeTrustedCredmanAccessPrivilege'

            [PSObject] $NewTokenPrivlege = New-Object -TypeName WinAPI.WinNT+TOKEN_PRIVILEGES
                       $NewTokenPrivlege.PrivilegeCount = 1

            [PSObject] $TokenLUIDAndAttributes = New-Object -TypeName WinAPI.WinNT+LUID_AND_ATTRIBUTES
               [int32] $TokenLUIDAndAttributes.Attributes = [WinAPI.Advapi32]::SE_PRIVILEGE_ENABLED
            [PSObject] $TokenLUID = New-Object -TypeName WinAPI.WinNT+LUID

            foreach ( $Privilage in $Privilages.Where({$_}) )
            {
                [WinAPI.Advapi32]::LookupPrivilegeValue('', $Privilage, [Ref] $TokenLUID ) > $null
                $TokenLUIDAndAttributes.Luid = $TokenLUID
                $NewTokenPrivlege.Privileges = $TokenLUIDAndAttributes
                [WinAPI.Advapi32]::AdjustTokenPrivileges( $NewProcessToken, $false, [Ref] $NewTokenPrivlege, 0, [System.IntPtr]::Zero, [System.IntPtr]::Zero ) > $null
            }

            # Результат [IntPtr] Дубликат токена со всеми привилегиями:
            $NewProcessToken
        }

        # Если не получена еще идентификация от системы, то получаем токен системы у процесса winlogon.exe,
        # и глобальную переменную, с идентификацией на его основе.
        # Токен TrustedInstaller можно получить только с Олицетворением за систему, так как только у системы есть необходимые для этого привилегии.
        if ( 'Impersonation' -ne $Global:Identity_SYS.ImpersonationLevel )
        {
            Write-Verbose "Получаем токен от SYSTEM (winlogon)"

            try
            {
                [IntPtr] $Token_SYS = Duplicate-ProcessToken -ProcessID ((Get-Process -Name winlogon).Id | Select-Object -First 1) -TokenType 'Impersonation'
            }
            catch
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Ошибка получения токена от SYSTEM (winlogon)!" }
                Write-Warning "$NameThisFunction`: $text"

                [bool] $Exit = $true ; Return
            }

            if ( $Token_SYS )
            {
                Write-Verbose "Получаем идентификацию `$Global:Identity_SYS с токеном от SYSTEM (winlogon)"

                try
                {
                    [PSObject] $Global:Identity_SYS = [System.Security.Principal.WindowsIdentity]::new($Token_SYS)
                }
                catch
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { "Ошибка, при создании идентификации с токеном от SYSTEM (winlogon)!" }
                    Write-Warning "$NameThisFunction`: $text"

                    [bool] $Exit = $true ; Return
                }
            }
            else
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Ошибка, токен от SYSTEM (winlogon) не получен!" }
                Write-Warning "$NameThisFunction`: $text"

                [bool] $Exit = $true ; Return
            }
        }

        # Если указано получить токен от TrustedInstaller.
        if ( $Token -eq 'TI' )
        {
            # Если не получена еще идентификация от TrustedInstaller.
            if ( $Global:Identity_TI.ImpersonationLevel -ne 'Impersonation' )
            {
                Write-Verbose "Олицетворяем себя за SYSTEM, для получения токена от TrustedInstaller"

                # Олицетворяем себя за System, со всеми привилегиями.
                try { $Global:Identity_SYS.Impersonate() > $null }
                catch
                {
                    $text = if ( $L.s7 ) { $L.s7 } else { "Ошибка Олицетворения себя за SYSTEM!" }
                    Write-Warning "$NameThisFunction`: $text"

                    [bool] $Exit = $true ; Return
                }

                [string] $SubKey = 'SYSTEM\CurrentControlSet\Services\TrustedInstaller'

                [int] $StartType = 0

                # Получаем параметр типа запуска у службы TrustedInstaller (Установщик модулей Windows).
                try { $StartType = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'Start',$null) } catch {}

                # Если параметр запуска не является 2 (Авто) или 3 (Вручную).
                if (( 3 -ne $StartType ) -and ( 2 -ne $StartType ))
                {
                    Write-Verbose "  Устанавливаем тип запуска у службы TrustedInstaller 'Вручную' (По умолчанию)"

                    # Восстанавливаем доступ по умолчанию.
                    try { $OpenSubKeyTI = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree', 'TakeOwnership') }
                    catch { $OpenSubKeyTI = $null }

                    if ( $OpenSubKeyTI )
                    {
                        $AclTI = [System.Security.AccessControl.RegistrySecurity]::new()
                        $AclTI.SetOwner([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')
                        $AclTI.SetGroup([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')
                        
                        try
                        {
                            $OpenSubKeyTI.SetAccessControl($AclTI)
                            $AclTI.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;KA;;;SY)(A;CIIO;GA;;;SY)(A;;KR;;;BA)(A;CIIO;GXGR;;;BA)(A;;KR;;;BU)(A;CIIO;GXGR;;;BU)')
                            $OpenSubKeyTI.SetAccessControl($AclTI)
                        }
                        catch {}

                        # Задаем параметр запуска по умолчанию.
                        try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree') }
                        catch { [psobject] $OpenSubkey = $null }

                        if ( $OpenSubkey )
                        {
                            $OpenSubkey.SetValue('Start',3,'Dword')

                            $OpenSubkey.Close()
                        }

                        $OpenSubKeyTI.Close()
                    }
                }

                try
                {
                    Write-Verbose "Запускаем службу TrustedInstaller"

                    Start-Service -Name TrustedInstaller -ErrorAction SilentlyContinue

                    [int] $pidTI = ((Get-Process -Name TrustedInstaller -ErrorAction SilentlyContinue).Id | Select-Object -First 1)

                    Write-Verbose "Получаем токен от TrustedInstaller"

                    [IntPtr] $Token_TI = Duplicate-ProcessToken -ProcessID $pidTI -TokenType 'Impersonation'

                    if ( -not (( "$Token_TI" -as [uint64] ) -and ( "$Token_TI" -gt 0 )) )
                    {
                        Write-Verbose "Токен не получен, Запускаем службу TrustedInstaller еще раз"

                        Start-Sleep -Milliseconds 500
                        # Токен не получен, Запускаем TrustedInstaller еще раз.
                        # TrustedInstaller мог быть запущенным и выключиться перед самым получением токена.
                        # 2 раза старт, а не ресстарт потому, что доступ на перезапуск есть не всегда, и его некорректно делать принудительно.
                        # А TrustedInstaller может завершиться в самый не подходящий момент, так как его время простоя равно 2 минутам.
                        Start-Service -Name TrustedInstaller -ErrorAction SilentlyContinue
                        [int] $pidTI = ((Get-Process -Name TrustedInstaller -ErrorAction SilentlyContinue).Id | Select-Object -First 1)

                        Write-Verbose "Получаем токен от TrustedInstaller еще раз"

                        [IntPtr] $Token_TI = Duplicate-ProcessToken -ProcessID $pidTI -TokenType 'Impersonation'
                    }
                }
                catch
                {
                    $text = if ( $L.s8 ) { $L.s8 } else { "Ошибка получения токена от TrustedInstaller!" }
                    Write-Warning "$NameThisFunction`: $text"

                    Write-Verbose "Сбрасываем Олицетворение за SYSTEM"

                    try { $Global:CurrentShell.Undo()    } catch {}
                    try { $Global:CurrentShell.Dispose() } catch {}

                    [bool] $Exit = $true ; Return
                }

                Write-Verbose "Сбрасываем Олицетворение за SYSTEM"

                try { $Global:CurrentShell.Undo()    } catch {}
                try { $Global:CurrentShell.Dispose() } catch {}

                if ( $Token_TI )
                {
                    Write-Verbose "Получаем идентификацию `$Global:Identity_TI с токеном от TrustedInstaller"

                    try
                    {
                        [PSObject] $Global:Identity_TI = [System.Security.Principal.WindowsIdentity]::new($Token_TI)
                    }
                    catch
                    {
                        $text = if ( $L.s9 ) { $L.s9 } else { "Ошибка, при создании идентификации с токеном от TrustedInstaller!" }
                        Write-Warning "$NameThisFunction`: $text"

                        [bool] $Exit = $true ; Return
                    }
                }
                else
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { "Ошибка, токен от TrustedInstaller не получен!" }
                    Write-Warning "$NameThisFunction`: $text"

                    [bool] $Exit = $true ; Return
                }
            }
        }
    }

    Process
    {
        # Перехват ошибок в блоке Process, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap
        {
            $text = if ( $L.s11 ) { $L.s11 } else { "Ошибка в Process" }
            Write-Warning "$NameThisFunction`: $text`:`n   $($_.CategoryInfo.Category): $($_.Exception.Message)"
            break
        }

        # Выход из функции, если была установлена переменная $Exit в блоке Begin.
        if ( $Exit ) { Return }

        if ( $Token -eq 'TI'  )
        {
            Write-Verbose "Олицетворяем себя за TrustedInstaller"

            try { $Global:Identity_TI.Impersonate() > $null }
            catch
            {
                $text = if ( $L.s13 ) { $L.s13 } else { "Ошибка Олицетворения себя за TrustedInstaller!" }
                Write-Warning "$NameThisFunction`: $text" ; Return
            }

            [PSObject] $isCurrentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()

            if (( $isCurrentIdentity.ImpersonationLevel -eq 'Impersonation' ) -and ( $isCurrentIdentity.IsSystem ) -and ( $isCurrentIdentity.Groups.Value -like 'S-1-5-80*' ))
            {
                Write-Verbose "Выполнено Олицетворение себя за TrustedInstaller"
            }
            else
            {
                $text = if ( $L.s14 ) { $L.s14 } else { "Ошибка, Олицетворение себя за TrustedInstaller НЕ выполнено!" }
                Write-Warning "$NameThisFunction`: $text"
            }
        }
        elseif ( $Token -eq 'SYS' )
        {
            Write-Verbose "Олицетворяем себя за SYSTEM"

            try { $Global:Identity_SYS.Impersonate() > $null }
            catch
            {
                $text = if ( $L.s7 ) { $L.s7 } else { "Ошибка Олицетворения себя за SYSTEM!" }
                Write-Warning "$NameThisFunction`: $text" ; Return
            }

            [PSObject] $isCurrentIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()

            if (( $isCurrentIdentity.ImpersonationLevel -eq 'Impersonation' ) -and ( $isCurrentIdentity.IsSystem ) -and ( $isCurrentIdentity.Groups.Value.Count -eq 3 ))
            {
                Write-Verbose "Выполнено Олицетворение себя за SYSTEM"
            }
            else
            {
                $text = if ( $L.s12 ) { $L.s12 } else { "Ошибка. Олицетворение себя за SYSTEM НЕ выполнено!" }
                Write-Warning "$NameThisFunction`: $text"
            }
        }
    }
}
