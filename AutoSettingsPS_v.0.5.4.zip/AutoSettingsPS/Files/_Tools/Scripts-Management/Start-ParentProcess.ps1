﻿
<#
.SYNOPSIS
 Запуск процессов от имени Системы или TrustedInstaller.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Нужны права администратора.

 Используется функция Token-Privileges для включения привилегий,
 если необходимо восстановить параметр запуска для службы TrustedInstaller.

 Используется .NET code для управления запуском процессов.

 Запускает родительский процесс от служб TrustedInstaller или winlogon,
 для получения их прав и привилегий на доступ.

 Если параметр запуска службы TrustedInstaller будет измененный,
 то он будет восстановлен "По умолчанию",
 чтобы была возможность запустить дочерний процесс от нее.

.PARAMETER RunAs
 Принимает необходимый тип доступа для запускаемого процесса:
 TI  = токен с правами TrustedInstaller.  Запускается дочерним процессом от службы TrustedInstaller.
 SYS = токен с правами SYSTEM (S-1-5-18). Запускается дочерним процессом от процесса winlogon.exe.

.PARAMETER CmdLine
 Командная строка для указания запуска приложений с аргументами.

.PARAMETER CurrentDirectory
 Указание запускаемому процессу рабочего каталога, например необходим при запуске ярлыков через cmd.

.PARAMETER Title
 Название для окна консоли. Для приложений не работает.

.PARAMETER NoWindow
 Запуск процесса без окна. Например для скрытия окна cmd при запуске через bat других процессов,
 или что-то выполнить, чтобы не мелькало его окно.
 Не для всех процессов работает.

.PARAMETER Wait
 Ждать завершения процесса.
 После создания процесса передается его ID. Ожидание завершения процесса определяется по этому ID.
 Необходим, если запускаемый процесс должен что-то выполнить, и нужен результат этого выполнения.

.EXAMPLE
    Start-ParentProcess -RunAs SYS -CmdLine "regedit.exe"

    Описание
    --------
    Запуск редактора реестра от имени Системы.

.EXAMPLE
    Start-ParentProcess -RunAs SYS -Title 'Привет' -CmdLine "Cmd.exe /k echo Это я & whoami" -Wait

    Описание
    --------
    Запуск окна cmd от имени Системы, с указанием названия окна и вывода текста в консоль cmd, с ожиданием его завершения.

.EXAMPLE
    Start-ParentProcess -RunAs TI -CmdLine "cmd /c start .\Proga.lnk" -CurrentDirectory 'D:\MyProga' -NoWindow

    Описание
    --------
    Запуск программы через ярлык от имени TrustedInstaller, с помощью cmd, со скрытием окна cmd.
    С указанием рабочего каталога для cmd, которое подхватится ярлыком.
    В данном случае рассчитано на то, что прога и ярлык в одной папке.

.EXAMPLE
    Start-ParentProcess -RunAs SYS -Title 'Мой батник' -CmdLine "D:\MyBat.bat" -Verbose

    Описание
    --------
    Запуск батника от имени Системы, с указанием названия окна и отображением подробных сведений.


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 1.0
       Дата:  11-10-2018
 ==================================================

#>
Function Start-ParentProcess {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param (
        [parameter( Mandatory = $true,  Position = 0 )]
        [ValidateSet( 'TI', 'SYS' )]
        [string] $RunAs
       ,
        [parameter( Mandatory = $true,  Position = 1 )]
        [ValidateNotNullOrEmpty()]
        [string] $CmdLine
       ,
        [parameter( Mandatory = $false, Position = 2 )]
        [string] $CurrentDirectory
       ,
        [parameter( Mandatory = $false, Position = 3 )]
        [string] $Title = ''
       ,
        [parameter( Mandatory = $false )]
        [switch] $NoWindow
       ,
        [parameter( Mandatory = $false )]
        [switch] $Wait
       ,
        [parameter( Mandatory = $false )]
        [Alias( 'ms' )]
        [int] $Milliseconds = 0
    )

    Begin
    {
        # Получение имени этой функции.
        [string] $NameThisFunction = $MyInvocation.MyCommand.Name

        # Получение перевода
        [hashtable] $L = $Lang.$NameThisFunction
        [string] $text = ''

        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        # Подключаем .Net code для создания процессов, нужны права администратора.
        $CreateProcessParentAPI = @'
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class ProcessConfig
    {
        [DllImport("kernel32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool CreateProcess(
            string lpApplicationName, string lpCommandLine, ref SECURITY_ATTRIBUTES lpProcessAttributes,
            ref SECURITY_ATTRIBUTES lpThreadAttributes, bool bInheritHandles, uint dwCreationFlags,
            IntPtr lpEnvironment, string lpCurrentDirectory, [In] ref STARTUPINFOEX lpStartupInfo,
            out PROCESS_INFORMATION lpProcessInformation);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UpdateProcThreadAttribute(
            IntPtr lpAttributeList, uint dwFlags, IntPtr Attribute, IntPtr lpValue,
            IntPtr cbSize, IntPtr lpPreviousValue, IntPtr lpReturnSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool InitializeProcThreadAttributeList(
            IntPtr lpAttributeList, int dwAttributeCount, int dwFlags, ref IntPtr lpSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool DeleteProcThreadAttributeList(IntPtr lpAttributeList);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr hObject);

        [StructLayout(LayoutKind.Sequential)]
        struct STARTUPINFOEX
        {
            public STARTUPINFO StartupInfo;
            public IntPtr lpAttributeList;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct STARTUPINFO
        {
            public Int32 cb;
            public string lpReserved;
            public string lpDesktop;
            public string lpTitle;
            public Int32 dwX;
            public Int32 dwY;
            public Int32 dwXSize;
            public Int32 dwYSize;
            public Int32 dwXCountChars;
            public Int32 dwYCountChars;
            public Int32 dwFillAttribute;
            public Int32 dwFlags;
            public Int16 wShowWindow;
            public Int16 cbReserved2;
            public IntPtr lpReserved2;
            public IntPtr hStdInput;
            public IntPtr hStdOutput;
            public IntPtr hStdError;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct PROCESS_INFORMATION
        {
            public IntPtr hProcess;
            public IntPtr hThread;
            public int dwProcessId;
            public int dwThreadId;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct SECURITY_ATTRIBUTES
        {
            public int nLength;
            public IntPtr lpSecurityDescriptor;
            public int bInheritHandle;
        }

        public static int CreateProcessFromParent(int ppid, string CmdLine, string CurrentDirectory, uint CreateFlag, string SetTitle, bool NoSilent)
        {
            const uint EXTENDED_STARTUPINFO_PRESENT = 0x00080000;
            const int PROC_THREAD_ATTRIBUTE_PARENT_PROCESS = 0x00020000;

            var si = new STARTUPINFOEX();
            var pi = new PROCESS_INFORMATION();
            IntPtr lpValue = IntPtr.Zero;

            si.StartupInfo.cb = Marshal.SizeOf(si);
            if (!(SetTitle == "")) { si.StartupInfo.lpTitle = SetTitle; };
            if (CurrentDirectory == "") { CurrentDirectory = null; };

            try
            {
                Process.EnterDebugMode();

                var lpSize = IntPtr.Zero;
                InitializeProcThreadAttributeList(IntPtr.Zero, 1, 0, ref lpSize);
                si.lpAttributeList = Marshal.AllocHGlobal(lpSize);
                InitializeProcThreadAttributeList(si.lpAttributeList, 1, 0, ref lpSize);
                var phandle = Process.GetProcessById(ppid).Handle;
                lpValue = Marshal.AllocHGlobal(IntPtr.Size);
                Marshal.WriteIntPtr(lpValue, phandle);

                UpdateProcThreadAttribute(
                    si.lpAttributeList,
                    0,
                    (IntPtr)PROC_THREAD_ATTRIBUTE_PARENT_PROCESS,
                    lpValue,
                    (IntPtr)IntPtr.Size,
                    IntPtr.Zero,
                    IntPtr.Zero);

                var pattr = new SECURITY_ATTRIBUTES();
                var tattr = new SECURITY_ATTRIBUTES();
                pattr.nLength = Marshal.SizeOf(pattr);
                tattr.nLength = Marshal.SizeOf(tattr);
                if (NoSilent) { Console.Write("Starting: '" + CmdLine + "' Dir: '" + CurrentDirectory + "' Result: "); };
                var b= CreateProcess(null, CmdLine,  ref pattr, ref tattr, false, EXTENDED_STARTUPINFO_PRESENT | CreateFlag, IntPtr.Zero, CurrentDirectory, ref si, out pi);
                if (NoSilent) { Console.WriteLine(b + " "); };
            }
            finally
            {
                if (si.lpAttributeList != IntPtr.Zero)
                {
                    DeleteProcThreadAttributeList(si.lpAttributeList);
                    Marshal.FreeHGlobal(si.lpAttributeList);
                }
                Marshal.FreeHGlobal(lpValue);

                if (pi.hProcess != IntPtr.Zero)
                {
                    CloseHandle(pi.hProcess);
                }
                if (pi.hThread != IntPtr.Zero)
                {
                    CloseHandle(pi.hThread);
                }
            }

            return pi.dwProcessId;
        }
    }
}
'@
        if ( -not ( 'WinAPI.ProcessConfig' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $CreateProcessParentAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        [int] $CREATE_NO_WINDOW   = 0x08000000
        [int] $CREATE_NEW_CONSOLE = 0x00000010

        if ( $NoWindow )
        {
            Write-Verbose "Запустить без окна (скрыто). Не для всех процессов работает."

            [int] $CreatingFlag = $CREATE_NO_WINDOW

        } else { [int] $CreatingFlag = $CREATE_NEW_CONSOLE }

        if ( $VerbosePreference -eq 'SilentlyContinue' ) { [bool] $NoSilent = $false } else { [bool] $NoSilent = $True }

        if ( $RunAs -eq 'TI' )
        {
            [string] $SubKey = 'SYSTEM\CurrentControlSet\Services\TrustedInstaller'

            [int] $StartType = 0

            # Получаем параметр типа запуска у службы TrustedInstaller (Установщик модулей Windows).
            try { $StartType = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'Start',$null) } catch {}

            # Если параметр запуска не является 2 (Авто) или 3 (Вручную).
            if (( 3 -ne $StartType ) -and ( 2 -ne $StartType ))
            {
                $text = if ( $L.s1 ) { $L.s1 } else { "Устанавливаем тип запуска у службы TrustedInstaller 'Вручную' (По умолчанию)" }
                Write-Host "  $text" -ForegroundColor DarkGray

                # Включаем необходимые привилегии.
                Token-Privileges -Enable -Privileges 'SeTakeOwnershipPrivilege', 'SeRestorePrivilege', 'SeBackupPrivilege'

                # Получаем полный доступ к разделу.
                try { $OpenSubKeyTI = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree', 'TakeOwnership') }
                catch { $OpenSubKeyTI = $null }

                if ( $OpenSubKeyTI )
                {
                    $AclTI = [System.Security.AccessControl.RegistrySecurity]::new()
                    $AclTI.SetOwner([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')
                    $AclTI.SetGroup([System.Security.Principal.SecurityIdentifier]'S-1-5-32-544')
                    
                    try
                    {
                        $OpenSubKeyTI.SetAccessControl($AclTI)
                        $AclTI.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;KA;;;SY)(A;CIIO;GA;;;SY)(A;;KA;;;BA)(A;CIIO;GA;;;BA)(A;;KA;;;BU)(A;CIIO;GA;;;BU)')
                        $OpenSubKeyTI.SetAccessControl($AclTI)
                    }
                    catch {}

                    # Задаем параметр запуска по умолчанию.
                    
                    try { [psobject] $OpenSubkey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadWriteSubTree') }
                    catch { [psobject] $OpenSubkey = $null }

                    if ( $OpenSubkey )
                    {
                        $OpenSubkey.SetValue('Start',3,'Dword')

                        $OpenSubkey.Close()
                    }

                    # Восстанавливаем доступ по умолчанию.
                    $AclTI.SetSecurityDescriptorSddlForm('O:BAG:BAD:PAI(A;;KA;;;SY)(A;CIIO;GA;;;SY)(A;;KR;;;BA)(A;CIIO;GXGR;;;BA)(A;;KR;;;BU)(A;CIIO;GXGR;;;BU)')
                    
                    try { $OpenSubKeyTI.SetAccessControl($AclTI) } catch {}

                    $OpenSubKeyTI.Close()
                }
            }
        }
    }

    Process
    {
        # Перехват ошибок в блоке Begin, для выхода из функции,
        # без отображения ошибки тут, и передача ее в глобальный trap для отображения и записи в лог.
        trap { break }

        $text = if ( $L.s2 ) { $L.s2 } else { "Путь не существует" }
        if ( $CurrentDirectory -and ( -not [System.IO.Directory]::Exists($CurrentDirectory) ))
        { Write-Warning " $NameThisFunction`: $text`: '$CurrentDirectory'" ; $CurrentDirectory = '' ; Return }

        Write-Verbose "Запускаем процесс от '$RunAs'"

        if ( $RunAs -eq 'TI' )
        {
            Start-Service -Name TrustedInstaller -ErrorAction SilentlyContinue

            [int] $ProcessID = (Get-Process -Name TrustedInstaller -ErrorAction SilentlyContinue).Id

            try { [int] $isCreateProcessID = [WinAPI.ProcessConfig]::CreateProcessFromParent($ProcessID,$CmdLine,$CurrentDirectory,$CreatingFlag,$Title,$NoSilent) }
            catch
            {
                Start-Sleep -Milliseconds 500
                # Если ошибка при запуске процесса, может быть из-за проблем с доступом или процесс отсутствует.
                # 2 раза старт, а не ресстарт потому, что доступ на перезапуск есть не всегда, и его некорректно делать принудительно.
                # А TrustedInstaller может завершиться в самый не подходящий момент, так как его время простоя равно 2 минутам.
                Start-Service -Name TrustedInstaller -ErrorAction SilentlyContinue

                [int] $ProcessID = (Get-Process -Name TrustedInstaller -ErrorAction SilentlyContinue).Id

                try { [int] $isCreateProcessID = [WinAPI.ProcessConfig]::CreateProcessFromParent($ProcessID,$CmdLine,$CurrentDirectory,$CreatingFlag,$Title,$NoSilent)
                } catch { [int] $isCreateProcessID = 0 }
            }
        }
        else
        {
            [int] $ProcessID = (Get-Process -Name winlogon -ErrorAction SilentlyContinue).Id

            try { [int] $isCreateProcessID = [WinAPI.ProcessConfig]::CreateProcessFromParent($ProcessID,$CmdLine,$CurrentDirectory,$CreatingFlag,$Title,$NoSilent) }
            catch { [int] $isCreateProcessID = 0 }
        }

        if ( $isCreateProcessID )
        {
            if ( $Wait )
            {
                Write-Verbose "Ждем завершения запущенного процесса с ID: '$isCreateProcessID'"
                try
                {
                    if ( $Milliseconds )
                    {
                        (Get-Process -Id $isCreateProcessID -ErrorAction SilentlyContinue).WaitForExit($Milliseconds) > $null
                    }
                    else
                    {
                        (Get-Process -Id $isCreateProcessID -ErrorAction SilentlyContinue).WaitForExit() > $null
                    }
                }
                catch {}
            }
            else { Write-Verbose "ID запущенного процесса: '$isCreateProcessID'" }
        }
        else
        {
            $text = "$NameThisFunction`: Процесс '$CmdLine' не запущен, проблема в `$CmdLine или нет доступа" -f
                $(if ( $L.s3 ) { $L.s3, $L.s3_1 } else { "Процесс", "не запущен, проблема в `$CmdLine или нет доступа" })

            Write-Host "$text" -ForegroundColor DarkGray
        }
    }
}
