﻿
<#
.SYNOPSIS
 Очистка папок
 Сделана для скрипта AutoSettingsPS

.DESCRIPTION
 Удаляет все подпапки и файлы под правами Системы или TI

 Используется утилита MS Handle.exe для получения блокирующих папку или файл процессов
 Используется функция Token-Impersonate, для получения/отмены на лету прав Системы/TrustedInstaller


.PARAMETER Paths
 Можно указывать шаблон имени: C:\Folder\1*, сами указанные пути не удаляются, если это не файл, только подпапки.

.PARAMETER Excludes
 Исключения имён для подпапок и файлов, только для указаной папки без рекурсии. В подпапках не сравнивает.
 Имя должно соответствовать полному имени подпапки или файлу, независимо от регистра.

.PARAMETER WarningSize
 Указание Размера реагирования предупреждением на превышение в мегабайтах при проверке

.PARAMETER StopProcesses
 Разрешает Завершать процессы, которые блокируют файл или папку. Проверяется с помощью утилиты MS: Handle.exe
 Путь до утилиты должен быть в переменной $HandleExe

.PARAMETER Impersonate
 Использовать права доступа при удалении. По умолчанию: Система, можно указать TrustedInstaller


.EXAMPLE
    CleanUp-Files-Folders -Act Check -Folders "C:\Folder0" -WarningSize 50 -StopProcesses
    
    --------
    Проверка размера "C:\Folder0"

.EXAMPLE
    CleanUp-Files-Folders -Act Set -Folders "C:\Folder1","D:\Folder2" -WarningSize 100 -StopProcesses -Impersonate TI -Excludes '1111','2222'
    
    --------
    Очистка "C:\Folder1" и "D:\Folder2"



.NOTES
 ================================================
     Автор:  westlife (ru-board)   Версия 1.0
      Дата:  04-07-2021
 ================================================

#>
Function CleanUp-Files-Folders {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $false, Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )] # Default Не используется
        [string] $Act = 'Check'
       ,
        [Parameter( Mandatory = $true,  ValueFromPipeline = $false )]
        [string[]] $Paths
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [string[]] $Excludes
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [string] $WarningSize
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [switch] $StopProcesses
       ,
        [Parameter( Mandatory = $false, ValueFromPipeline = $false )]
        [ValidateSet( 'SYS', 'TI' )]
        [string] $Impersonate = 'SYS'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $Act -match 'Default' )
    {
        Write-Host "   $NameThisFunction`: 'Default' Not supported" -ForegroundColor DarkGray
        Return
    }

    [int64] $NeedSize = 0
    [int64]::TryParse($WarningSize,[System.Globalization.NumberStyles]::Any,[System.Globalization.NumberFormatInfo]::InvariantInfo,[ref]$NeedSize) > $null
    if ( $NeedSize -eq 0 ) { $NeedSize = 100 } # Дефолтный размер предупреждений от 100мб

    Token-Impersonate -Token $Impersonate

    if ( $Excludes.Count )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "   Исключения" }
        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
        Write-Host "$($Excludes -join ', ')`n" -ForegroundColor DarkGray
    }

    [int64] $PathsSize = 0

    foreach ( $Path in $Paths.Where({$_}) )
    {
        $Path = [System.Environment]::ExpandEnvironmentVariables($Path)
        
        $text = if ( $L.s2 ) { $L.s2 } else { "      Очистка" }
        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
        Write-Host "$Path\" -ForegroundColor DarkGray

        [int] $F = 0
            
        @(if ( $Excludes.Where({$_}) )
        {
            @(Get-ChildItem -Path $Path -Force -ErrorAction SilentlyContinue
            ).Where({

                $_.Name -notmatch "^($($Excludes.ForEach({[regex]::Escape($_)}) -join '|'))$"
            })
        }
        else
        {
            Get-ChildItem -Path $Path -Force -ErrorAction SilentlyContinue

        }).ForEach({

            $F++

            [string] $Object = $_.FullName

            $text = if ( $L.s3 ) { $L.s3 } else { "     Удаление" }

            if ( $Act -eq 'Check' )
            {
                Write-Host "   $text`: " -ForegroundColor DarkYellow -NoNewline
                Write-Host "$Object" -ForegroundColor DarkGray
            }
            else
            {
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$Object" -ForegroundColor DarkGray

                try
                {
                    if ( $StopProcesses -and [System.IO.File]::Exists($HandleExe))
                    {
                        Remove-Item -LiteralPath "\\?\$Object" -Recurse -Force -ErrorAction Stop
                    }
                    else
                    {
                        try
                        {
                            Remove-Item -LiteralPath "\\?\$Object" -Recurse -Force -ErrorAction Stop
                        }
                        catch
                        {
                            $text = if ( $L.s4 ) { $L.s4 } else { '    Не удалён' }
                            Write-Host "   $text`: " -ForegroundColor DarkYellow -NoNewline
                            Write-Host "$Object"
                        }
                    }
                }
                catch
                {
                    $text = if ( $L.s5 ) { $L.s5 } else { 'Заблокировано' }
                    Write-Host "   $text`: " -ForegroundColor DarkRed -NoNewline
                    Write-Host "$Object" -ForegroundColor DarkYellow

                    [int] $N = 0

                    do
                    {
                        $N++

                        # Получаем список процессов, которые используют данную папку.
                        $FolderHandles = $null

                        if ( $Object )
                        {
                            try { $FolderHandles = ( & $HandleExe -AcceptEula $Object ).Where({ $_ -match "[.]exe" }) } catch { $FolderHandles = $null }
                        }

                        if ( $FolderHandles )
                        {
                            [hashtable] $FoundPocess = @{}

                            # Добавляем все процессы в таблицу, перезаписывая повторные ID.
                            foreach ( $Handle in $FolderHandles )
                            {
                                if ( $Handle -match "(^.+[.]exe)\s+pid:\s+([\d]+)" ) { $FoundPocess[$Matches[2]] = $Matches[1] }
                            }

                            # Для всех уникальных ID выполнение принудительного завершения работы.
                            foreach ( $ProcessPID in $FoundPocess.Keys )
                            {
                                $text = if ( $L.s6 ) { $L.s6 } else { '     Закрытие' }
                                Write-Host "   $text`: " -ForegroundColor DarkMagenta -NoNewline
                                Write-Host "$($FoundPocess[$ProcessPID])" -ForegroundColor White -NoNewline
                                Write-Host "; PID: " -ForegroundColor DarkGray -NoNewline
                                Write-Host "$ProcessPID" -ForegroundColor Magenta

                                try { (Get-Process -Id $ProcessPID -ErrorAction SilentlyContinue).Kill() } catch {}
                            }
                        }
                    }
                    until (( -not $FolderHandles ) -or ( $N -ge 10 ))

                    try
                    {
                        Remove-Item -LiteralPath "\\?\$Object" -Recurse -Force -ErrorAction Stop
                        
                        $text = if ( $L.s7 ) { $L.s7 } else { '       Удалён' }
                        Write-Host "   $text`: " -ForegroundColor DarkGreen -NoNewline
                        Write-Host "$Object" -ForegroundColor DarkGreen
                    }
                    catch
                    {
                        $text = if ( $L.s4 ) { $L.s4 } else { '    Не удалён' }
                        Write-Host "   $text`: " -ForegroundColor DarkRed -NoNewline
                        Write-Host "$Object" -ForegroundColor Red
                    }
                }
            }
        })

        if ( -not $F )
        {
            $text = if ( $L.s8 ) { $L.s8 } else { "        Пусто" }
            Write-Host "   $text " -ForegroundColor DarkGray
        }
        elseif ( $Act -eq 'Check' )
        {
            try
            {
                $PathsSize += (Get-ChildItem -Path $Path -Recurse -Force -ErrorAction SilentlyContinue | 
                                  Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
            }
            catch {}
        }

        Write-Host
    }

    # Вдруг блокировал Проводник и его завершило, чтобы его запустить обратно, если нет процессов Проводника.
    while ( -not ( [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count ))
    {
        Write-Verbose "Запускаем Проводник, пока не будет запущен"
        try { Start-Process -FilePath Explorer -ErrorAction SilentlyContinue } catch {}
        Start-Sleep -Milliseconds 400
    }

    $text = if ( $L.s9 ) { $L.s9 } else { " Общий размер" }

    if ( $Act -eq 'Check' )
    {
        if ( $PathsSize -ne 0 )
        {
            $Color = 'DarkGray'
            if ( $PathsSize -gt "$NeedSize`mb" ) { $NeedFix = $true ; $Color = 'Yellow' }

            if ( $PathsSize -gt 1gb )
            {
                [string] $Size = ( $PathsSize / 1gb ).ToString('N2')
                
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$Size`gb`n" -ForegroundColor $Color
            }
            elseif ( $PathsSize -gt 1mb )
            {
                [string] $Size = ( $PathsSize / 1mb ).ToString('N2')
                
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$Size`mb`n" -ForegroundColor $Color
            }
            else
            {
                [string] $Size = ( $PathsSize / 1kb ).ToString('N2')
                
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$Size`kb`n" -ForegroundColor $Color
            }
        }
        else
        {
            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "0`n" -ForegroundColor DarkGray
        }
    }

    Token-Impersonate -Reset
}
