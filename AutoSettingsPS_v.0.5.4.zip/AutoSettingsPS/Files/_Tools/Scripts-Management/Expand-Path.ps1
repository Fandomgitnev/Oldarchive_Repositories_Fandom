﻿
<#
.SYNOPSIS
 Получение и Раскрытие любых путей в данный момент, а не из окружения текущей среды.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.

 Используется для пропуска через нее любого пути,
 чтобы раскрывать в них любые переменные и специальные папки.

 Переменные '%Temp%', '%Tmp%', '$env:TEMP', '$env:TMP'
 и все специальные папки расскрываются через новый процесс,
 чтобы получить путь из нового окружения, а не текущего,
 так как переменные могут быть изменены после запуска текущей среды,
 а текущее окружение знать этого не будет.

 Понимание системных переменных в виде '$env:' или '%Temp%' и т.д.
 https://en.wikipedia.org/wiki/Environment_variable#Default_values

 Понимание специальных переменных Проводника в виде: 'shell:'
 https://www.winhelponline.com/blog/shell-commands-to-access-the-special-folders/
 http://www.outsidethebox.ms/11103/

 Понимание специальных переменных [System.Environment+SpecialFolder] в виде: 'MyPictures' и т.д.
 Понимание обычных путей и комбинирование их всех вместе.

 При любом варианте путь возвращается или раскрытый,
 или в том же виде, если была ошибка раскрытия, или нечего раскрывать,
 или раскрытие не привело к нужному результату.

 Несколько вариантов Возможных путей, даже если переменные как строки:

  '$env:USERPROFILE'
  '$env:USERPROFILE\'
  '$env:Temp\Папка'
  '$env:USERPROFILE\Папка\Файл.txt'

  'shell:Local Pictures'
  'shell:My Music\'
  'shell:Local Pictures\Desktop\Папка\'
  'shell:Local Pictures\Desktop\Папка\Мой Файл.pdf'

  'MyDocuments'
  'ProgramFiles\'
  'ProgramFilesX86\Папка'
  'StartMenu\Папка\Файл.exe'

  '%Temp%'
  '%Temp%\'
  '%SystemDrive%\Моя Папка'
  '%UserProfile%\Моя папка\Мой файл.zip'

  'D:\'
  'D:\Папка'

   и т.д.

.PARAMETER Target
 Строка с путем.

.EXAMPLE
    Expand-Path 'shell:Local Pictures\Папка\Мой Файл.jpg'

    Описание
    --------
    Раскрытие пути в 'Изображения\Папка\Мой Файл.jpg'.

.EXAMPLE
    'StartMenu\Папка\' | Expand-Path

    Описание
    --------
    Раскрытие пути 'Мои документы\папка'.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  25-04-2019
 ===============================================

#>
Function Expand-Path {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string])]
    Param(
        [Parameter( Mandatory = $false, ValueFromPipeline = $true, Position = 0 )]
        [AllowEmptyString()]
        [string] $Target = ''
    )

    if ( $Target -match '(?<Root>^[^\\\r\n]+)(?<Child>[^\r\n]*)' )
    {
        [string] $Root  = $matches.Root.TrimStart()
        [string] $Child = $matches.Child.TrimEnd()

        if ( $Root -match '^\$env:' )
        {
            if ( $Root -match '^\$env:TEMP$|^\$env:TMP$' )
            {
                $Root = powershell.exe -Command "try { & ([scriptblock]::Create('$([System.IO.Path]::GetFullPath($Root))')) } catch { '$([System.IO.Path]::GetFullPath($Root))' }"
            }
            else
            {
                $Root = try { & ([scriptblock]::Create($Root)) } catch { $Root }
            }
        }
        elseif ( $Root -like '%*%' )
        {
            if ( $Root -match '^%Temp%$|^%Tmp%$' )
            {
                $Root = powershell.exe -Command "try { [System.Environment]::ExpandEnvironmentVariables('$Root') } catch { '$Root' }"
            }
            else
            {
                $Root = [System.Environment]::ExpandEnvironmentVariables($Root)
            }
        }
    }
    else { return }

    if ( $Root -match '^[a-z]:\\' )
    {
        if ( $Child ) { "$Root$Child" } else { "$Root" }
    }
    elseif ( $Root -match '^[a-z]:' )
    {
        if ( $Child ) { "$Root$Child" } else { "$Root\" }
    }
    elseif ( $Root -like 'shell:*' )
    {
        $Root = powershell.exe -NoLogo -NoProfile -Command "try { (New-Object -Com Shell.Application).NameSpace('$Root').Self.Path } catch { '$Root' }"

        if ( $Root -match '^[a-z]:' )
        {
            if ( $Child ) { "$Root$Child" } else { $Root }
        }
        else { $Target }
    }
    elseif (( [enum]::GetValues([System.Environment+SpecialFolder]) ) -like $Root )
    {
        $Root = powershell.exe -Command "try { [System.Environment]::GetFolderPath('$Root') } catch { '$Root' }"

        if ( $Root -match '^[a-z]:' )
        {
            if ( $Child ) { "$Root$Child" } else { $Root }
        }
        else { $Target }
    }
    else { $Target }
}
