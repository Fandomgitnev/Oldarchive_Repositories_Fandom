﻿
<#
.SYNOPSIS
 Получение информации о Процессоре из его инструкции CPUID

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Поддержка от Windows 10 1809 x86/x64 
 
 Получает информацию из инструкции CPUID регистра EAX самого процессора.
 https://en.wikipedia.org/wiki/CPUID
 https://en.wikipedia.org/wiki/ASCII

 В основном нужна для определения: Виртуальный (Гость) или Физический (Хост) Компьютер
 по 31 биту в ECX из EAX = 1 (На физическом процессоре он всегда равен нулю)
 Таким методом определяет Таск Менеджер в Windows 10 
 Эту проверку в том числе предлагают в VMWare: https://kb.vmware.com/s/article/1009458
 
 Есть ещё 2 интересных примера детекта Виртуалки у pafish на языке С: 
 1. Через 64-bit register "Time Stamp Counter" (rdtsc): функция cpu_rdtsc_force_vmexit() https://github.com/a0rtega/pafish/blob/master/pafish/cpu.c
 2. Через hook ShellExecuteExW: https://github.com/a0rtega/pafish/blob/master/pafish/hooks.c
 Но у меня нет знаний по С/С++/C#, чтобы такое повторить на C# для использования в PS.  

 Но 31 бит, rdtsc да и другие методы определения можно отключить/изменить в настройках Виртуальных машин или патчами, чтобы избежать детекта.
 Поэтому 100% гарантированные детекты сделать сложно.

.EXAMPLE
    Get-CpuID -Data isVirtual

.EXAMPLE
    Get-CpuID -Data TypeOS

.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия:  1.0
       Дата:  04-04-2021
 ==================================================
#>
Function Get-CpuID {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'isVirtual', 'isTypeOS', 'TypeOS','HypervisorInfo','Virtualization','CPUBrand','ManufacturerID','ACPI','ThermalMonitor','ThermalMonitor2',
                      'ia64','WakeUp','SpeedStep','MMX','avx2','sse41','sse42' )]
        [string] $Data = 'TypeOS'
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    $CpuID = @'
using System;
using System.Runtime.InteropServices;

namespace Processor
{
    public class CpuID : IDisposable
    {
        [UnmanagedFunctionPointerAttribute(CallingConvention.Cdecl)]
        private delegate void CpuIDDelegate(int level, byte[] buffer);

        [StructLayout(LayoutKind.Sequential, Size = 16)]
        public struct CpuIdResult
        {
            public int EAX;
            public int EBX;
            public int ECX;
            public int EDX;
        
            public CpuIdResult(byte[] b)
            {
                this.EAX = BitConverter.ToInt32(new byte[] { b[0],  b[1],  b[2],  b[3]  }, 0);
                this.EBX = BitConverter.ToInt32(new byte[] { b[4],  b[5],  b[6],  b[7]  }, 0);
                this.ECX = BitConverter.ToInt32(new byte[] { b[8],  b[9],  b[10], b[11] }, 0);
                this.EDX = BitConverter.ToInt32(new byte[] { b[12], b[13], b[14], b[15] }, 0);
            }
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAlloc(
            IntPtr lpAddress,
            UIntPtr dwSize,
            AllocationType flAllocationType,
            MemoryProtection flProtect
        );

        [DllImport("kernel32")]
        private static extern bool VirtualFree(
            IntPtr lpAddress,
            UInt32 dwSize,
            UInt32 dwFreeType
        );

        [Flags()]
        private enum AllocationType : uint
        {
            COMMIT = 0x1000,
            RESERVE = 0x2000,
            RESET = 0x80000,
            LARGE_PAGES = 0x20000000,
            PHYSICAL = 0x400000,
            TOP_DOWN = 0x100000,
            WRITE_WATCH = 0x200000
        }

        [Flags()]
        private enum MemoryProtection : uint
        {
            EXECUTE = 0x10,
            EXECUTE_READ = 0x20,
            EXECUTE_READWRITE = 0x40,
            EXECUTE_WRITECOPY = 0x80,
            NOACCESS = 0x01,
            READONLY = 0x02,
            READWRITE = 0x04,
            WRITECOPY = 0x08,
            GUARD_Modifierflag = 0x100,
            NOCACHE_Modifierflag = 0x200,
            WRITECOMBINE_Modifierflag = 0x400
        }

        private CpuIDDelegate cpuIdDelg;
        private IntPtr codePointer;

        // Basic ASM strategy --
        // void x86CpuId(int level, byte* buffer) 
        // {
        //    eax = level
        //    cpuid
        //    buffer[0] = eax
        //    buffer[4] = ebx
        //    buffer[8] = ecx
        //    buffer[12] = edx
        // }

        private byte[] x86CodeBytes =
        {
            0x55,                   // push        ebp
            0x8B, 0xEC,             // mov         ebp,esp
            0x53,                   // push        ebx
            0x57,                   // push        edi

            0x8B, 0x45, 0x08,       // mov         eax, dword ptr [ebp+8] (move level into eax)
            0x0F, 0xA2,             // cpuid

            0x8B, 0x7D, 0x0C,       // mov         edi, dword ptr [ebp+12] (move address of buffer into edi)
            0x89, 0x07,             // mov         dword ptr [edi+0], eax  (write eax, ... to buffer)
            0x89, 0x5F, 0x04,       // mov         dword ptr [edi+4], ebx
            0x89, 0x4F, 0x08,       // mov         dword ptr [edi+8], ecx
            0x89, 0x57, 0x0C,       // mov         dword ptr [edi+12],edx

            0x5F,                   // pop         edi
            0x5B,                   // pop         ebx
            0x8B, 0xE5,             // mov         esp,ebp
            0x5D,                   // pop         ebp
            0xc3                    // ret
        };

        private byte[] x64CodeBytes =
        {
            0x53,                         // push rbx    this gets clobbered by cpuid

            // rcx is level
            // rdx is buffer.
            // Need to save buffer elsewhere, cpuid overwrites rdx
            // Put buffer in r8, use r8 to reference buffer later.

            // Save rdx (buffer addy) to r8
            0x49, 0x89, 0xd0,             // mov r8,  rdx

            // Move ecx (level) to eax to call cpuid, call cpuid
            0x89, 0xc8,                   // mov eax, ecx
            0xB9, 0x00, 0x00, 0x00, 0x00, // mov ecx, 0
            0x0F, 0xA2,                   // cpuid

            // Write eax et al to buffer
            0x41, 0x89, 0x40, 0x00,       // mov    dword ptr [r8+0],  eax
            0x41, 0x89, 0x58, 0x04,       // mov    dword ptr [r8+4],  ebx
            0x41, 0x89, 0x48, 0x08,       // mov    dword ptr [r8+8],  ecx
            0x41, 0x89, 0x50, 0x0c,       // mov    dword ptr [r8+12], edx

            0x5b,                         // pop rbx
            0xc3                          // ret
        };
       
        public CpuID()
        {
            Compile();
        }

        ~CpuID()
        {
            Dispose(false);
        }
        
        private void Compile()
        {
            byte[] codeBytes;

            if (IntPtr.Size == 4)
            {
                codeBytes = x86CodeBytes;
            }
            else
            {
                codeBytes = x64CodeBytes;
            }

            this.codePointer = VirtualAlloc(
                IntPtr.Zero,
                new UIntPtr((uint)codeBytes.Length),
                AllocationType.COMMIT | AllocationType.RESERVE,
                MemoryProtection.EXECUTE_READWRITE
            );

            Marshal.Copy(codeBytes, 0, this.codePointer, codeBytes.Length);

            this.cpuIdDelg = (CpuIDDelegate)Marshal.GetDelegateForFunctionPointer(this.codePointer, typeof(CpuIDDelegate));
        }

        public CpuIdResult InvokeEAX(int level)
        {
            GCHandle handle = default(GCHandle);
            byte[] buffer = new byte[16];

            try {
                handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
                cpuIdDelg(level, buffer);
            } finally {
                if (handle != default(GCHandle)) {
                    handle.Free();
                }
            }

            CpuIdResult Result = new CpuIdResult(buffer);

            return Result;
        }

        public void Dispose()
        {
            Dispose(true);
        }

        public void Dispose(bool disposing)
        {
            if (this.codePointer != IntPtr.Zero)
            {
                VirtualFree(this.codePointer, 0, 0x8000);
                this.codePointer = IntPtr.Zero;
            }
        }
    }
}
'@

    if ( -not ( 'Processor.CpuID' -as [type] ))
    {
        try
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $CpuID -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }
        catch { Write-Warning "$NameThisFunction`: Error Add-Type: Processor.CpuID" ; Return }
    }

    if (( $Data -eq 'isVirtual' ) -or ( $Data -eq 'isTypeOS' ) -or ( $Data -eq 'TypeOS' ))
    {
        $EAX = 1           # EAX=1: Processor Info and Feature Bit
        $FeatureBit = 31   # Feature Bit 31 in ECX: Hypervisor present (always zero on physical CPUs)
        $isVirtual  = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1

        if ( $Data -eq 'isVirtual' )
        {
            # Если Виртуальная true иначе false
            if ( $isVirtual ) { $true } else { $false }
        }
        elseif ( $Data -eq 'isTypeOS' )
        {
            # Если Виртуальная true иначе false
            if ( $isVirtual ) { 'Virtual Machine' } else { 'Physical Machine' }
        }
        else
        {
            if ( $isVirtual ) { Write-Host 'Virtual Machine' -ForegroundColor Yellow } else { Write-Host 'Physical Machine' -ForegroundColor Cyan }
        }
    }
    elseif ( $Data -eq 'HypervisorInfo' )
    {
        $EAX = 0x40000000  # Hypervisor Info (Reserve for Virtual Info)
        [byte[]] $a = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EBX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
        [byte[]] $b = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).ECX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
        [byte[]] $c = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EDX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')

        $Name = "{0}{1}{2}" -f [Text.Encoding]::ASCII.GetString($a[$a.count..0]),[Text.Encoding]::ASCII.GetString($b[$b.count..0]),[Text.Encoding]::ASCII.GetString($c[$c.count..0])
        
        # Если содержаться не читаемые символы или запрещенные для использования в путях
        if ( $Name -match "[$([regex]::Escape([System.IO.Path]::InvalidPathChars))]" )
        {
            Write-Host $Name -ForegroundColor DarkRed 
        }
        else
        {
            Write-Host $Name -ForegroundColor Green
        }
    }
    elseif ( $Data -eq 'Virtualization' )
    {
        $EAX = 1          # EAX=1: Processor Info and Feature Bit
        $FeatureBit = 5   # Feature Bit 5 in ECX: vmx Virtual Machine eXtensions  (Поддержка Аппаратной Виртуализации процессором) Может быть отключена в BIOS.
        $Bit  = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1

        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'CPUBrand' )
    {
        $BrandCPU = ''
        
        # Если 0x80000000 EAX больше 0x80000004
        if ( [Processor.CpuID]::new().InvokeEAX(0x80000000).EAX -gt [System.Convert]::ToString(0x80000004,10) )
        {
            $EAX = 0x80000002  # 
            [byte[]] $a = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EAX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $b = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EBX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $c = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).ECX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $d = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EDX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')

            $String1 = "{0}{1}{2}{3}" -f [Text.Encoding]::ASCII.GetString($a[$a.count..0]),[Text.Encoding]::ASCII.GetString($b[$b.count..0]),
                                         [Text.Encoding]::ASCII.GetString($c[$c.count..0]),[Text.Encoding]::ASCII.GetString($d[$d.count..0])
            $EAX = 0x80000003  # 
            [byte[]] $a = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EAX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $b = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EBX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $c = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).ECX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $d = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EDX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')

            $String2 = "{0}{1}{2}{3}" -f [Text.Encoding]::ASCII.GetString($a[$a.count..0]),[Text.Encoding]::ASCII.GetString($b[$b.count..0]),
                                         [Text.Encoding]::ASCII.GetString($c[$c.count..0]),[Text.Encoding]::ASCII.GetString($d[$d.count..0])
            $EAX = 0x80000004  # 
            [byte[]] $a = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EAX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $b = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EBX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $c = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).ECX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
            [byte[]] $d = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EDX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')

            $String3 = "{0}{1}{2}{3}" -f [Text.Encoding]::ASCII.GetString($a[$a.count..0]),[Text.Encoding]::ASCII.GetString($b[$b.count..0]),
                                         [Text.Encoding]::ASCII.GetString($c[$c.count..0]),[Text.Encoding]::ASCII.GetString($d[$d.count..0])

            $BrandCPU = "$String1$String2$String3"
        }

        if ( $BrandCPU )
        {
            Write-Host $BrandCPU -ForegroundColor White
        }
        else
        {
            Write-Host "---------" -ForegroundColor DarkGray
        }
    }
    elseif ( $Data -eq 'ManufacturerID' )
    {
        $EAX = 0  # Highest Function Parameter and Manufacturer ID
        [byte[]] $a = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EBX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
        [byte[]] $b = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).EDX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')
        [byte[]] $c = ([System.Convert]::ToString([Processor.CpuID]::new().InvokeEAX($EAX).ECX, 16) -replace ('([\w]{1,2})','0x$1;')).Trim(';').Split(';')

        $Name = "{0}{1}{2}" -f [Text.Encoding]::ASCII.GetString($a[$a.count..0]),[Text.Encoding]::ASCII.GetString($b[$b.count..0]),
                               [Text.Encoding]::ASCII.GetString($c[$c.count..0])
    
        Write-Host $Name -ForegroundColor White
    }
    elseif ( $Data -eq 'ACPI' )
    {
        $EAX = 1 ; $FeatureBit = 21 # in EDX: Onboard thermal control MSRs for ACPI
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EDX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'ThermalMonitor' )
    {
        $EAX = 1 ; $FeatureBit = 29 # in EDX: Thermal monitor automatically limits temperature
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EDX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'ThermalMonitor2' )
    {
        $EAX = 1 ; $FeatureBit = 8 # in ECX: Thermal Monitor 2
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'ia64' )
    {
        $EAX = 1 ; $FeatureBit = 30 # in EDX: IA64 processor emulating x86 (IA-64 Intel Itanium architecture)
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EDX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'WakeUp' )
    {
        $EAX = 1 ; $FeatureBit = 31 # in EDX: pbe 	Pending Break Enable (PBE# pin) wakeup capability
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EDX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'SpeedStep' )
    {
        $EAX = 1 ; $FeatureBit = 7 # in ECX: Enhanced SpeedStep
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'MMX' )
    {
        $EAX = 1 ; $FeatureBit = 23 # in EDX: MMX instructions
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EDX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'avx2' )
    {
        $EAX = 7 ; $FeatureBit = 5 # in EBX: avx2 Advanced Vector Extensions 2
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).EBX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'sse41' )
    {
        $EAX = 1 ; $FeatureBit = 19 # in ECX: SSE4.1 instructions 
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
    elseif ( $Data -eq 'sse42' )
    {
        $EAX = 1 ; $FeatureBit = 20 # in ECX: SSE4.2 instructions 
        $Bit = [Processor.CpuID]::new().InvokeEAX($EAX).ECX -shr $FeatureBit -band 1
        
        if ( $Bit ) { Write-Host "True" -ForegroundColor Green } else { Write-Host "False" -ForegroundColor Red }
    }
}