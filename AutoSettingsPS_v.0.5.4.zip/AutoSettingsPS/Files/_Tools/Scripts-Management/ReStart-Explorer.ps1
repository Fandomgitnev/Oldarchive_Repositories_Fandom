﻿
<#
.SYNOPSIS
 Перезапуск/Запуск или остановка процесса Проводника.

.DESCRIPTION
 Функция написана для скриптов AutoSettingsPS и RepackWIMPS.
 Корректная остановка процесса проводника ("Gracefully" - с сохранением текущих данных)
 Не затрагивает проводники других запущенных аккаунтов.

 Запоминает открытые окна проводника перед их закрытием,
 и открывает их в свёрнутом виде после перезапуска, или остановки и затем запуска.
 Понимает все типы путей открытых окон, с поддержкой в путях кириллицы, спецсимволов и пробелов.

.PARAMETER Stop
 Остановить процесс проводника.

.PARAMETER Retry
 Используется только внутри самой себя, если вдруг процесс не завершился с параметром Stop.
 Для повторной попытки.

.PARAMETER AllSessions
 Закрыть процессы проводника у всех пользователей.

.PARAMETER DoNotOpenWindows
 Не открывать закрытые окна проводника.

.EXAMPLE
    ReStart-Explorer

    Описание
    --------
    Запуск или перезапуск проводника. Зависит от ситуации.

.EXAMPLE
    ReStart-Explorer -Stop -Verbose

    Описание
    --------
    Остановка процесса проводника, если он существует.
    С отображением происходящих действий.


.NOTES
 ==================================================
      Автор:  westlife (ru-board)  Версия: 2.0
       Дата:  27-01-2022
 ==================================================

#>
Function ReStart-Explorer {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    Param (
        [Parameter( Mandatory = $false, ParameterSetName = 'Stop', Position = 0 )]
        [switch] $Stop
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Stop' )]
        [switch] $Retry
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Stop' )]
        [switch] $AllSessions
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'DoNotOpen' )]
        [switch] $DoNotOpenWindows
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Close' )]
        [switch] $OnlyCloseWindows
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Open' )]
        [switch] $OnlyOpenWindows
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    [string] $WinAPIExplorer = @'
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Threading;

namespace WinAPI
{
    public class Explorer
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern uint RealGetWindowClass(IntPtr hWnd, StringBuilder strText, uint maxCount);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern int PostMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        public static Queue<string> CloseOpenWindows(bool outPaths = false)
        {
            Queue<string> ListPaths = new Queue<string>();
            Queue<object> closeWindowItems = new Queue<object>();
            object shellApplication = null;

            try
            {
                Guid CLSID_ShellApplication = new Guid("13709620-C279-11CE-A49E-444553540000");
                Type shellApplicationType = Type.GetTypeFromCLSID(CLSID_ShellApplication, true);

                shellApplication = Activator.CreateInstance(shellApplicationType);

                object windows = shellApplicationType.InvokeMember("Windows", BindingFlags.InvokeMethod, null, shellApplication, new object[] { });

                Type windowsType = windows.GetType();
                int count = (int)windowsType.InvokeMember("Count", BindingFlags.GetProperty, null, windows, null);

                for (int i = 0; i < count; i++)
                {
                    object item = windowsType.InvokeMember("Item", BindingFlags.InvokeMethod, null, windows, new object[] { i });
                    if ( item == null ) { continue; } // Перейти к следующему для пропуска пустого объекта, чтобы не выкидывало из дальнейшего перебора

                    closeWindowItems.Enqueue(item); // add
                    if (!outPaths) { continue; } // Перейти к следующему, если только закрыть окна

                    Type itemType = item.GetType();
                    object document = itemType.InvokeMember("Document", BindingFlags.GetProperty, null, item, null);

                    Type DocumentType = document.GetType();
                    object folder = DocumentType.InvokeMember("Folder", BindingFlags.GetProperty, null, document, null);

                    Type FolderType = folder.GetType();
                    object self = FolderType.InvokeMember("Self", BindingFlags.GetProperty, null, folder, null);

                    Type SelfType = self.GetType();
                    string path = (string)SelfType.InvokeMember("Path", BindingFlags.GetProperty, null, self, null);

                    if (!string.IsNullOrWhiteSpace(path) && !ListPaths.Contains(path)) { ListPaths.Enqueue(path); } // add
                }

                while(closeWindowItems.Count > 0)
                {
                    object item = closeWindowItems.Dequeue(); // берёт первый из очереди и удаляет его
                    item.GetType().InvokeMember("Quit", BindingFlags.InvokeMethod, null, item, null);
                }
            }
            catch (Exception) { }
            finally
            {
                if (shellApplication != null)
                {
                    Marshal.FinalReleaseComObject((object) shellApplication);
                }
            }

            return ListPaths;
        }

        private const uint WM_EXITEXPLORER = 0x5b4; // WM_USER = 0x400; + 0x1b4 = 1460 (0x5b4)
        private static int currentSessionID = Process.GetCurrentProcess().SessionId;

        private static string GetWindowClass(IntPtr hWnd)
        {
            var wndClass = new StringBuilder(255);
            RealGetWindowClass(hWnd, wndClass, 255);

            return (wndClass.ToString());
        }

        private static void CloseExplorer(bool allSessions = false)
        {
            Process[] wndProcesses = GetExplorerProcesses(allSessions);

            IntPtr hWnd = IntPtr.Zero;

            foreach (Process isProcess in wndProcesses)
            {
                hWnd = isProcess.MainWindowHandle;

                var wndClass = GetWindowClass(hWnd);

                if (wndClass == "Shell_TrayWnd")
                {
                    PostMessage(hWnd, WM_EXITEXPLORER, IntPtr.Zero, IntPtr.Zero);

                    isProcess.WaitForExit(1000); // важно! самое долгое, 500-1000мс закрывается процесс
                }
            }

            int n = 0;

            do
            {
                n++;

                wndProcesses = GetExplorerProcesses(allSessions); // важно! после WM_EXITEXPLORER

                foreach (Process isProcess in wndProcesses)
                {
                    hWnd = isProcess.MainWindowHandle;

                    var wndClass = GetWindowClass(hWnd);

                    if (wndClass != "Shell_TrayWnd")
                    {
                        try { isProcess.Kill(); } catch (Exception) {} // при попытке Kill() для завершающегося процесса может выкинуть отказ доступа.
                        isProcess.WaitForExit(100);
                    }
                }
            }
            while ((wndProcesses).Length > 0 && n < 10);
        }

        public static Process[] GetExplorerProcesses(bool allSessions = false)
        {
            Process[] wndProcesses = Process.GetProcessesByName("explorer");

            if (!allSessions)
            {
                wndProcesses = Array.FindAll(wndProcesses, p => p.SessionId == currentSessionID);
            }

            return (wndProcesses);
        }

        public static Queue<string> ExitExplorer(bool outPaths = false, bool allSessions = false)
        {
            Queue<string> WindowsPaths = CloseOpenWindows(outPaths);

            CloseExplorer(allSessions);

            return (WindowsPaths);
        }

        public static void StartExplorerShell()
        {
            if (FindWindow("Shell_TrayWnd", (string) null) == IntPtr.Zero)
            {
                try { Process.Start("explorer.exe"); } catch (Exception) { return; }

                int n = 0;
                while (FindWindow("Progman", (string) null) == IntPtr.Zero && n < 100 ) // 100 * Sleep(30) реально = ~3,6 сек максимального ожидания
                {
                    n++;
                    Thread.Sleep(30);
                }
            }
        }
    }
}
'@
    if ( -not ( 'WinAPI.Explorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $WinAPIExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    if ( -not ( Get-Variable -Name OpenedFolders -Scope Global -ErrorAction SilentlyContinue ))
    {
        Set-Variable -Name OpenedFolders -Value ([System.Collections.Queue] @()) -Scope Global -Option AllScope -Force -ErrorAction SilentlyContinue
    }

    if ( -not $OnlyOpenWindows )  
    {
        # Если есть процессы с именем Explorer.
        if ( @([WinAPI.Explorer]::GetExplorerProcesses($AllSessions)).Length )
        {
            if ( $OnlyCloseWindows )
            {
                Write-Verbose "Только закрываем открытые окна с сохранением путей"

                if ( -not @($Global:OpenedFolders).Count )
                {
                    # Закрыть окна и сохранить их пути
                    try { $Global:OpenedFolders = [WinAPI.Explorer]::CloseOpenWindows($true) } catch {}
                }
                else
                {
                    # Закрыть окна
                    try { [WinAPI.Explorer]::CloseOpenWindows() } catch {}
                }

                Return
            }
            else
            {
                Write-Verbose "Завершаем процесс Проводника"

                if ( -not $Retry )
                {
                    if ( -not @($Global:OpenedFolders).Count )
                    {
                        Write-Verbose "Сохраняем все открытые окна Проводника"

                        # Закрыть окна, Вывести их пути, и Завершить работу проводника, с сохранением данных.
                        try { $Global:OpenedFolders = [WinAPI.Explorer]::ExitExplorer($true, $AllSessions) } catch {}
                    }
                    else
                    {
                        Write-Verbose "Без сохранения открытых окон Проводника"

                        # Закрыть окна и Завершить работу проводника, с сохранением данных.
                        try { [WinAPI.Explorer]::ExitExplorer($false, $AllSessions) } catch {}
                    }
                }
                else
                {
                    Write-Verbose "Retry | Без сохранения открытых окон Проводника"

                    # Закрыть окна и Завершить работу проводника, с сохранением данных.
                    try { [WinAPI.Explorer]::ExitExplorer($false, $AllSessions) } catch {}
                }

                if ( $Stop )
                {
                    # Если процесс проводника все еще существует, вывести предупреждение и еще раз перезапустить, для очень не стандартных ситуаций
                    if ( @([WinAPI.Explorer]::GetExplorerProcesses($AllSessions)).Length )
                    {
                        if ( -not $Retry )
                        {
                            Write-Host "$NameThisFunction`: Explorer process exit error" -ForegroundColor DarkGray

                            # Повторный перезапуск/закрытие проводника при проблеме
                            ReStart-Explorer -Stop -Retry -AllSessions:$AllSessions
                        }
                        else
                        {
                            Write-Host "$NameThisFunction`: Explorer process exit error" -ForegroundColor DarkYellow
                        }
                    }
                }
            }
        }
        else
        {
            Write-Verbose "Нет процессов Проводника"

            if ( $OnlyCloseWindows ) { Return }
        }
    }

    # Если не указано остановить процесс, выполняем запуск проводника, повторяя, пока не запустится.
    if ( -not $Stop )
    {
        Write-Verbose "Указано запустить Проводник после его завершения"
        Write-Verbose "Запускаем Shell Проводника текущего пользователя, пока не будет запущен"
        [WinAPI.Explorer]::StartExplorerShell()  # ждёт не дольше 3,6 сек, и ничего не делает, если оболочка (трей/рабстол) уже запущена

        if ( -not $DoNotOpenWindows -and $Global:OpenedFolders.Count )
        {
            Write-Verbose "Открываем обратно все открытые папки в свёрнутом виде"

            $StartInfo = [System.Diagnostics.ProcessStartInfo]::new('explorer.exe')
            $StartInfo.WindowStyle = 'Minimized'

            while ( $Global:OpenedFolders.Count )
            {
                $OpenedFolder = $Global:OpenedFolders.Dequeue() # Берёт первый из очереди и удаляет его, обнулять переменную не нужно

                if ( $OpenedFolder -like '::{*}' )
                {
                    # Открывает пути вида: Shell:::{GUID}
                    $StartInfo.Arguments = "/n,shell:$OpenedFolder"
                    try { $Process = [System.Diagnostics.Process]::Start($StartInfo) ; $Process.Close() } catch {}
                }
                elseif ( [System.IO.Directory]::Exists($OpenedFolder) )
                {
                    # Открывает пути с поддержкой в путях кириллицы, спецсимволов и пробелов
                    $StartInfo.Arguments = "/n,""$OpenedFolder"""
                    try { $Process = [System.Diagnostics.Process]::Start($StartInfo) ; $Process.Close() } catch {}
                }
            }
        }
    }
    else { Write-Verbose "Процесс Проводника остановлен" }
}
