﻿
<#
.SYNOPSIS
 Выполнение оптимизации дисков SSD и HDD, или создание раздельных задач оптимизации.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Drives_Optimization.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра,
 с проверкой и выводом результата. Независимо от доступа, если не блокируется драйвером.
 Используется функция Write-HostColor для вывода текста с цветом.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Check-State-Task для проверки наличия задачи.
 Используется функция Get-CpuID для Получения типа ОС (Virtual/Physical) из инструкции процессора CPUID (по 31 биту)

 Учитывается наличие или отсутствие дисков.
 Оригинальная задача оптимизации дисков \Microsoft\Windows\Defrag\ScheduledDefrag создается, если была удалена.
 Раздельные задачи создаются на основе оригинальных параметров задачи, и будут использоваться системой.

 Если в системе отключено автообслуживание системы, то создаются задачи с самостоятельным периодическим выполнением.
 Так как стандартная задача имеет скрытый параметр MaintenanceSettings, который запрещает выполнятся при отключенном автообслуживании системы.

.EXAMPLE
    Set-Drives-Optimization -Option CreateTasks -Act Set

    Описание
    --------
    Создать раздельные задачи оптимизации дисков SSD и HDD.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  02-05-2019
 ===============================================

#>
Function Set-Drives-Optimization {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Тут 'Check' не используется, оставлено, чтобы было по стандарту и не выкидывало ошибок, если будет использовано.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'CreateTasks', 'RunDfrGui', 'ShowEventLog', 'RunTRIM', 'RunDefrag',
                      'EnableTaskTRIM', 'DisableTaskTRIM', 'EnableTaskDefrag', 'DisableTaskDefrag', 'EnableOrigTaskDefrag', 'DisableOrigTaskDefrag' )]
        [string] $Option
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $TaskOnlySSD
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 3 )]
        [switch] $WithoutMaintenance  # Сделать задачу независимой от обслуживания
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ShowLocalDrives', 'ShowSSD', 'ShowHDD' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $Smartctl = $SmartctlExe
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    if ( -not [System.IO.File]::Exists($Smartctl) )
    {
        $text = if ( $L.s1 ) { $L.s1 } else { "Не указана или не найдена утилита Smartctl.exe" }
        Write-Warning "`n$NameThisFunction`: $text`: '$Smartctl'"

        Return    # Выход из функции.
    }

    # Внутренняя Функция получения только локальных дисков в системе с буквами, кроме CD/DVD/Floppy.
    Function Get-Local-Drives {

        <#
        DriveType

        Unknown          0  The type of drive is unknown.
        NoRootDirectory  1  The drive does not have a root directory.
        Removable        2  The drive is a removable storage device, such as a USB flash drive.
        Fixed            3  The drive is a fixed disk. (Local Disk)
        Network          4  The drive is a network drive.
        CDRom            5  The drive is an optical disc device, such as a CD or DVD-ROM.
        Ram              6  The drive is a RAM disk.

        MediaType
        Определяет точный тип носителя логического диска. Существует 22 значения данного параметра

        Unknown    0   Неизвестный формат
        Removable  11  Съемные носители (кроме дискет Floppy)
        Fixed      12  Фиксированный жесткий диск (Fixed hard disk media, Local Disk)
    
        Остальные значения MediaType относятся к различным форматам гибких дисков Floppy.
        #>

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param()

        try { [bool] $isVirtual = $false ; $isVirtual = $(Get-CpuID isVirtual) } catch { $isVirtual = $false }
        
        [hashtable] $TableDrives = @{}

        try { $GetPhysicalDisk = Get-PhysicalDisk } catch { Return $null }

        # Получение информации по дискам из командлета Get-PhysicalDisk и далее из Get-Partition
        # и добавление этих данных в таблицу $TableDrives
        $GetPhysicalDisk | ForEach-Object {

            [string] $MediaType  = $_.MediaType
            [string] $DeviceName = $_.FriendlyName
            [string] $BusType    = $_.BusType
            [string] $DiskNumber = $_.DeviceId

            if (( $_.SpindleSpeed -eq 0 ) -and ( $BusType -like '*USB*' )) { $MediaType = 'Flash' }

            Get-Partition -DiskNumber $DiskNumber -ErrorAction SilentlyContinue | ForEach-Object {

                if ( -not $_.DriveLetter ) { Return } # Если нет буквы у диска, переход к следующей итерации
                
                <#
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'Unknown' )) { $MediaType = 'RAM' ; $BusType = 'RAM' }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'SCSI'    )) { $MediaType = 'RAM' ; $BusType = 'RAM' }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'RAID'    )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'SATA'    )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -eq 'ATA'     )) { $MediaType = 'HDD'                    }
                if (( $MediaType -eq 'Unspecified' ) -and ( $BusType -ne 'Unknown' ) -and ( $BusType -ne 'RAID' ) -and ( $BusType -ne 'SATA' ) -and ( $BusType -ne 'ATA' )) { $MediaType = 'VirtualHDD' }
                #>

                if ( $MediaType -like '*Unspecified*' )
                {
                    if ( $BusType -match 'Unknown|SCSI'  )
                    { 
                        $MediaType = 'RAM' ; if ( $BusType -like '*Unknown*' ) { $BusType = 'RAM' }
                    }
                    else
                    {
                        $MediaType = 'HDD'
                    }
                }

                if ( $MediaType -match 'HDD|SSD' )
                {
                    if ( $isVirtual )
                    {
                        if ( $MediaType -like '*HDD*' ) { $MediaType = 'VirtualHDD' } else { $MediaType = 'VirtualSSD' }
                    }
                }

                $TableDrives[$TableDrives.Count] = @{

                    DiskNumber  = $DiskNumber
                    MediaType   = $MediaType
                    DeviceName  = $DeviceName
                    BusType     = $BusType

                    DriveLetter = "$($_.DriveLetter):"
                    Size        = $_.Size
                }
            }
        }

        # Получение дополнительных данных о дисках из WMI через командлет Get-CimInstance
        # И добавление в таблицу $TableDrives дополнительной инфы, к уже добавленным данным о дисках, либо добавление новых дисков
        Get-CimInstance -Class win32_logicaldisk -Filter "DriveType=0 or DriveType=2 or DriveType=3 or DriveType=6" | ForEach-Object {

            if ( -not $_.DeviceID ) { Return }  # Если нет буквы у диска, переход к следующей итерации

            [string] $DriveLetter = $_.DeviceID
            [string] $VolumeName  = $_.VolumeName
            [string] $FileSystem  = $_.FileSystem

            if     (    12 -eq $_.MediaType ) { [string] $MediaType = 'RAM'        }
            elseif ( $null -eq $_.MediaType ) { [string] $MediaType = 'Flash'      }
            else                              { [string] $MediaType = $_.MediaType }

            if     (     2 -eq $_.DriveType ) { [string] $BusType   = 'USB'        }
            else                              { [string] $BusType   = 'RAM'        }

            if ( $TableDrives.Values.DriveLetter -like $DriveLetter )
            {
                # Если Диск уже есть в таблице, дополняем его информацией.
                $TableDrives.Values.Where({

                    if ( $_.DriveLetter -eq $DriveLetter )
                    {
                        $_.VolumeName = $VolumeName
                        $_.FileSystem = $FileSystem
                    }
                })
            }
            else
            {
                # Иначе добавляем новый диск в таблицу.
                $TableDrives[$TableDrives.Count] = @{

                    DriveLetter = $DriveLetter
                    Size        = $_.Size
                    MediaType   = $MediaType
                    BusType     = $BusType

                    VolumeName  = $VolumeName
                    FileSystem  = $FileSystem
                }
            }
        }
        
        # Сопоставление дисков и разделов через Win32_DiskDriveToDiskPartition и Win32_LogicalDiskToPartition
        # для понимания большего количества типов дисков, включая SoftRaid
        Get-WmiObject Win32_DiskDrive -ErrorAction SilentlyContinue | ForEach-Object {
            
            $DiskDrive = $_
            $DriveToPartitions = "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($DiskDrive.DeviceID)'} WHERE AssocClass = Win32_DiskDriveToDiskPartition"
            
            Get-WmiObject -Query $DriveToPartitions -ErrorAction SilentlyContinue | ForEach-Object {
                
                $Partition = $_
                $LogicalToPartitions = "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($Partition.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition"
                
                Get-WmiObject -Query $LogicalToPartitions -ErrorAction SilentlyContinue | ForEach-Object {
        
                    $DiskDriveAdv = @($GetPhysicalDisk).Where({ $_.DeviceId -eq $DiskDrive.Index },'First')

                    $MediaType   = $DiskDriveAdv.MediaType
                    $BusType     = $DiskDriveAdv.BusType
                    $DeviceName  = $DiskDriveAdv.FriendlyName
                    $DriveNumber = $DiskDriveAdv.DeviceId
                    
                    if     ( $DiskDriveAdv.PhysicalLocation -like '*.vhd'  ) { $BusType = 'VHD'  }
                    elseif ( $DiskDriveAdv.PhysicalLocation -like '*.vhdx' ) { $BusType = 'VHDX' }

                    if ( $MediaType -like '*Unspecified*' )
                    {
                        if ( $BusType -match 'Unknown|SCSI'  )
                        { 
                            $MediaType = 'RAM' ; if ( $BusType -like '*Unknown*' ) { $BusType = 'RAM' }
                        }
                        else
                        {
                            $MediaType = 'HDD'
                        }
                    }

                    if ( $MediaType -match 'HDD|SSD' )
                    {
                        if ( $isVirtual )
                        {
                            if ( $MediaType -like '*HDD*' ) { $MediaType = 'VirtualHDD' } else { $MediaType = 'VirtualSSD' }
                        }
                    }

                    $DriveLetter = $_.DeviceID
                    $VolumeName  = $_.VolumeName
                    $FileSystem  = $_.FileSystem

                    $DiskMediaTypeInt = $_.MediaType
                    $DiskDriveTypeInt = $_.DriveType

                    if ( $TableDrives.Values.DriveLetter -like $DriveLetter )
                    {
                        # Если Диск уже есть в таблице, дополняем его информацией.
                        $TableDrives.Values.Where({

                            if ( $_.DriveLetter -eq $DriveLetter )
                            {
                                $_.VolumeName = $VolumeName
                                $_.FileSystem = $FileSystem
                                $_.DeviceName = $DeviceName

                                # Если у одной буквы несколько дисков = RAID
                                if ( $DriveNumber -ne $_.DiskNumber )
                                {
                                    $BusType = 'RAID'

                                    [string[]] $DiskNumbers = @()

                                    if ( $_.DiskNumber )
                                    {
                                        $DiskNumbers = $_.DiskNumber.ToString().Split('+')
                                    }

                                    $DiskNumbers += $DriveNumber
                                    
                                    $_.DiskNumber = ($DiskNumbers.Where({$_}) | Sort-Object) -join '+'
                                }
                                
                                # Если фиксированный диск, обновить/заменить тип диска
                                if ( $DiskDriveTypeInt -eq 3 -and $DiskMediaTypeInt -eq 12 )
                                {
                                    $_.MediaType = $MediaType
                                    $_.BusType   = $BusType
                                }
                            }
                        })
                    }
                    else
                    {
                        # Иначе добавляем новый диск в таблицу.
                        $TableDrives[$TableDrives.Count] = @{
                        
                            DiskNumber  = $DriveNumber
                            DriveLetter = $DriveLetter
                            Size        = $_.Size
                            MediaType   = $MediaType
                            BusType     = $BusType

                            VolumeName  = $VolumeName
                            FileSystem  = $FileSystem
                            DeviceName  = $DeviceName 
                        }
                    }
                }
            }
        } 

        # Перепроверяем более точно все диски, определённые ранее как HDD, с помощью утилиты Smartctl.exe
        # Диски могут не определиться как SSD, так как с помощью PS это сделать гарантированно не возможно.
        $TableDrives.Values.Where({

            if ( $_.MediaType -like '*HDD*' )
            {
                # Для всех возможных типов подключения.
                foreach ( $Type in 'sat,auto','auto','nvme','ata','scsi','sat' )
                {
                    $DiskNumber = $_.DiskNumber
                    [string[]] $DeviceInfo = & $Smartctl -d $Type -i /dev/pd$DiskNumber

                    # Если диск определился как SSD.
                    if ( $DeviceInfo -match 'Rotation\s*Rate:\s*Solid' )
                    {
                        # Переименовываем его МедиаТип HDD в МедиаТип SSD, и прерываем дальнейшее определение этого диска.
                        if ( $_.MediaType -like '*VirtualHDD*' ) { $_.MediaType = 'VirtualSSD' }
                        else                                     { $_.MediaType = 'SSD'        }
                        
                        break
                    }
                    elseif ( $DeviceInfo -match 'Rotation\s*Rate:\s*\d+\s*rpm' )
                    {
                        break  # определена скорость вращения, диск HDD, прерываем дальнейшее определение этого диска
                    }
                }
            }
        })

        [hashtable] $AllDrivesTable = $TableDrives
        $TableDrives = @{}

        foreach ( $Number in $AllDrivesTable.Keys | Sort-Object )
        {
            if ( $AllDrivesTable[$Number].Where({ $_.MediaType -match 'HDD|SSD' }) )
            {
                $TableDrives[$Number] = $AllDrivesTable[$Number]
            }
        }

        # Глобальная переменная со всеми HDD дисками в системе.
        [string[]] $Global:AllDrivesHDD = $TableDrives.Values.Where({ $_.MediaType -like '*HDD*' }).DriveLetter | Sort-Object

        # Глобальная переменная со всеми SDD дисками в системе.
        [string[]] $Global:AllDrivesSSD = $TableDrives.Values.Where({ $_.MediaType -like '*SSD*' }).DriveLetter | Sort-Object

        $TableDrives
    }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'ShowLocalDrives' )
        {
            # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
            [hashtable] $LocalDrivesTable = Get-Local-Drives

            if ( $LocalDrivesTable.Values.Count )
            {
                ($LocalDrivesTable.Values | Sort-Object { $_.DriveLetter }).ForEach({

                    [string] $MediaType   = $_.MediaType
                    [string] $BusType     = $_.BusType
                    [string] $DriveLetter = $_.DriveLetter
                    [string] $Size        = ( $_.Size / 1gb ).ToString('F2')
                    [string] $FileSystem  = $_.FileSystem
                    [string] $VolumeName  = $_.VolumeName
                    [string] $DiskNumber  = $_.DiskNumber


                    if ( -not $VolumeName ) { $VolumeName = '---------------' }

                    if ( $MediaType -like '*SSD*' ) { [string] $Color = 'Green' }
                    else                            { [string] $Color = 'Cyan'  }

                    if ( $BusType -like '*vhd*' ) { $BusColor = 'DarkCyan' } else { $BusColor = 'DarkGray' }

                    [string] $DiskInfo = "#$Color#{0} #DarkGray#>>> #$Color#$DriveLetter #DarkGray#|# {1} #DarkGray#|# {2} #DarkGray#| #$BusColor#{3} #DarkGray#| $VolumeName (Disk: $DiskNumber)#" -f
                        $MediaType.PadLeft(18,' '),
                        ($Size.PadRight(8,' ') -Replace('\d+,\d+','$0 #DarkGray#гб#')),
                        $FileSystem.PadRight(6,' ').Substring(0,6),
                        $BusType.PadRight(6,' ').Substring(0,6)

                    # Вывод полученной информации для каждого диска.
                    Write-HostColor $DiskInfo
                })
            }
            else
            {
                Write-Host "Get-PhysicalDisk: Error" -ForegroundColor Red
            }
        }
        elseif ( $CheckState -eq 'ShowHDD' )
        {
            if ( -not ( Get-Variable -Name AllDrivesHDD -Scope Global -ErrorAction SilentlyContinue ))
            {
                # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
                [hashtable] $LocalDrivesTable = Get-Local-Drives
            }

            if ( $Global:AllDrivesHDD )
            {
                "#Cyan#$($Global:AllDrivesHDD -join ' ')#"
            }
            else
            {
                "#DarkGray#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Нет HDD дисков в системе" })
            }
        }
        elseif ( $CheckState -eq 'ShowSSD' )
        {
            if ( -not ( Get-Variable -Name AllDrivesSSD -Scope Global -ErrorAction SilentlyContinue ))
            {
                # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
                [hashtable] $LocalDrivesTable = Get-Local-Drives
            }

            if ( $Global:AllDrivesSSD )
            {
                "#Green#$($Global:AllDrivesSSD -join ' ')#"
            }
            else
            {
                "#DarkGray#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Нет SSD дисков в системе" })
            }
        }

        Return
    }

    # Внутренняя функция для создания заготовки оригинальных параметров задачи \Microsoft\Windows\Defrag\ScheduledDefrag
    # Позволяет создать ее в оригинальном виде, если она отсутствует. Или на основе этих параметров создать другие задачи оптимизации дисков.
    Function Create-DefragTask-Settings {

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param()

        [psobject] $NewTaskSettings = New-ScheduledTask

        $NewTaskSettings.Author = '{0}' -f $(if ( $L.s4 ) { $L.s4 } else { "Корпорация Майкрософт" })
        $NewTaskSettings.Source = '{0}' -f $(if ( $L.s4 ) { $L.s4 } else { "Корпорация Майкрософт" })
        $NewTaskSettings.SecurityDescriptor = 'D:AI(A;;FA;;;BA)(A;;FA;;;SY)(A;;FRFX;;;LS)(A;;FR;;;AU)'
        $NewTaskSettings.Description = '{0}' -f $(if ( $L.s5 ) { $L.s5 } else { "Эта задача выполняет оптимизацию жестких дисков компьютера." })
        $NewTaskSettings.Actions   = New-ScheduledTaskAction -Execute '%windir%\system32\defrag.exe' -Argument '-c -h -o -$'
        $NewTaskSettings.Principal = New-ScheduledTaskPrincipal -UserID SY -RunLevel Highest -Id 'LocalSystem'
        $NewTaskSettings.Settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -MaintenancePeriod $([timespan]::FromDays(7)) `
                                                                  -MultipleInstances IgnoreNew -Priority 7 -Compatibility Win8
        $NewTaskSettings.Settings.DisallowStartIfOnBatteries = $true
        $NewTaskSettings.Settings.StopIfGoingOnBatteries = $true
        $NewTaskSettings.Settings.AllowHardTerminate = $true
        $NewTaskSettings.Settings.StartWhenAvailable = $true
        $NewTaskSettings.Settings.RunOnlyIfNetworkAvailable = $false
        $NewTaskSettings.Settings.IdleSettings.WaitTimeout = ''
        $NewTaskSettings.Settings.IdleSettings.IdleDuration = ''
        $NewTaskSettings.Settings.IdleSettings.StopOnIdleEnd = $true
        $NewTaskSettings.Settings.IdleSettings.RestartOnIdle = $false
        $NewTaskSettings.Settings.AllowDemandStart = $true
        $NewTaskSettings.Settings.Enabled = $true
        $NewTaskSettings.Settings.Hidden = $false
        $NewTaskSettings.Settings.RunOnlyIfIdle = $false
        $NewTaskSettings.Settings.DisallowStartOnRemoteAppSession = $false
        $NewTaskSettings.Settings.UseUnifiedSchedulingEngine = $true
        $NewTaskSettings.Settings.MaintenanceSettings.Deadline = 'P1M'
        $NewTaskSettings.Settings.MaintenanceSettings.Exclusive = $false
        $NewTaskSettings.Settings.WakeToRun = $false
        $NewTaskSettings.Settings.ExecutionTimeLimit = 'PT72H'

        $NewTaskSettings
    }

    $text = if ( $L.s6 ) { $L.s6 } else { "Настройка или выполнение оптимизации дисков" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s7 ) { $L.s7 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Option -eq 'CreateTasks' )
    {
        if ( $Act -eq 'Set' )
        {
            if ( -not ( Get-Variable -Name AllDrivesSSD -Scope Global -ErrorAction SilentlyContinue ))
            {
                # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
                [hashtable] $LocalDrivesTable = Get-Local-Drives

                if ( -not $LocalDrivesTable.Values.Count )
                {
                    Write-Host "Get-PhysicalDisk: Error" -ForegroundColor Red
                    Get-Pause ; Return
                }
            }

            # Проверка включен ли запрет обслуживания
            [string] $Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\Maintenance'

            try { [psobject] $Maintenance = [Microsoft.Win32.Registry]::GetValue($Key,'MaintenanceDisabled',$null)
            } catch { [psobject] $Maintenance = $null }

            if ( 1 -eq $Maintenance ) { [bool] $MaintenanceDisabled = $true } else { [bool] $MaintenanceDisabled = $false }

            [bool] $OrigTaskOff = $false

            if ( $Global:AllDrivesSSD )
            {
                $text = if ( $L.s8 ) { $L.s8 } else { "Создание раздельных задач оптимизации дисков" }
                Write-Host "`n   $text" -ForegroundColor White

                [string] $DrivesSSD = $Global:AllDrivesSSD -join ' '

                $text = if ( $L.s9 ) { $L.s9 } else { "Создание" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Задачи SSD-Trim по оптимизации SSD дисков" }
                Write-Host "$text " -ForegroundColor Gray -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$DrivesSSD" -ForegroundColor Green

                [psobject] $DefragTaskSettings = Create-DefragTask-Settings
                $DefragTaskSettings.Author = 'westlife | ru-board'
                $DefragTaskSettings.Source = 'ru-board'

                # '-h' = Передаёт defrag.exe, чтобы выполнить операцию с нормальным приоритетом.
                # '-l' = Передаёт defrag.exe, чтобы выполнить Повторную оптимизация выбранных томов (TRIM).

                $DefragTaskSettings.Actions = New-ScheduledTaskAction -Execute '%windir%\system32\defrag.exe' -Argument "$DrivesSSD -h -l"

                if ( $WithoutMaintenance -or $MaintenanceDisabled )
                {
                    $DefragTaskSettings.Settings.MaintenanceSettings = $null
                    $RegTrigger = Get-CimClass -Namespace 'Root/Microsoft/Windows/TaskScheduler' -ClassName 'MSFT_TaskRegistrationTrigger'
                    $DefragTaskSettings.Triggers = @($RegTrigger,(New-ScheduledTaskTrigger -Daily -DaysInterval 3 -At "14:00"))

                    $DefragTaskSettings.Description = "{0}: $DrivesSSD `n{1}" -f
                        $(if ( $L.s10 ) { $L.s10, $L.s10_1 } else { "Эта задача выполняет TRIM для ваших SSD дисков", "Выполняется самостоятельно, без Автообслуживания Windows, раз в 3 дня!" })

                    $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Выполняется самостоятельно, без Автообслуживания Windows, раз в 3 дня!" }
                    Write-Host "            $text`n" -ForegroundColor DarkGray
                }
                else
                {
                    $DefragTaskSettings.Description = "{0}: $DrivesSSD `n{1}" -f
                        $(if ( $L.s10 ) { $L.s10, $L.s10_2 } else { "Эта задача выполняет TRIM для ваших SSD дисков", "Выполняется только при Автообслуживании Windows, если не отключено!" })

                    $text = if ( $L.s10_2 ) { $L.s10_2 } else { "Выполняется только при Автообслуживании Windows, если не отключено!" }
                    Write-Host "            $text`n" -ForegroundColor DarkGray
                }

                [Hashtable] $DefragTaskSSD = @{
                    'TaskName'      = '\Microsoft\Windows\Defrag\SSD-Trim'
                    'InputObject' = $DefragTaskSettings
                }

                Set-Tsk Register-ScheduledTask @DefragTaskSSD

                [bool] $OrigTaskOff = $true
            }
            else
            {
                $text = if ( $L.s11 ) { $L.s11 } else { "Пропуск создания" }
                Write-Host "`n   $text " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s11_1 ) { $L.s11_1 } else { "Отдельной задачи оптимизации SSD дисков" }
                Write-Host "$text" -ForegroundColor Gray

                $text = if ( $L.s3 ) { $L.s3 } else { "Нет SSD дисков в системе" }
                Write-Host "   $text`n" -ForegroundColor DarkGray
            }

            # Если не указано сделать задачу только для SSD.
            if ( -not $TaskOnlySSD )
            {
                # Если есть HDD диски в системе.
                if ( $Global:AllDrivesHDD )
                {
                    [string] $DrivesHDD = $Global:AllDrivesHDD -join ' '

                    $text = if ( $L.s12 ) { $L.s12 } else { "Создание" }
                    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                    $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Задачи HDD-Defrag по дефргментации HDD дисков" }
                    Write-Host "$text " -ForegroundColor Gray -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$DrivesHDD" -ForegroundColor Cyan

                    [psobject] $DefragTaskSettings = Create-DefragTask-Settings
                    $DefragTaskSettings.Author = 'westlife | ru-board'
                    $DefragTaskSettings.Source = 'ru-board'

                    # '-h' = Передаёт defrag.exe, чтобы выполнить операцию с нормальным приоритетом.
                    # '-o' = Передаёт defrag.exe, чтобы выполнить Оптимизацию, с использованием соответствующего типу носителя метода.
                    # '-$' = Передаёт defrag.exe, что запуск идёт из планировщика задач фоновым процессом.

                    $DefragTaskSettings.Actions = New-ScheduledTaskAction -Execute '%windir%\system32\defrag.exe' -Argument "$DrivesHDD -h -o -$"

                    if ( $WithoutMaintenance -or $MaintenanceDisabled )
                    {
                        $DefragTaskSettings.Settings.MaintenanceSettings = $null

                        $DefragTaskSettings.Triggers = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday -At "14:00"

                        $DefragTaskSettings.Settings.RunOnlyIfIdle = $true
                        $DefragTaskSettings.Settings.IdleSettings.IdleDuration = 'PT10M'
                        $DefragTaskSettings.Settings.IdleSettings.WaitTimeout = 'PT2H'
                        $DefragTaskSettings.Settings.IdleSettings.StopOnIdleEnd = $true
                        $DefragTaskSettings.Settings.IdleSettings.RestartOnIdle = $true

                        $DefragTaskSettings.Description = "{0}: $DrivesHDD, `n{1}" -f
                            $(if ( $L.s13 ) { $L.s13, $L.s13_1 } else { "Эта задача выполняет дефрагментацию ваших HDD дисков", "Выполняется самостоятельно, без Автообслуживания Windows, раз в неделю!" })

                        $text = if ( $L.s13_1 ) { $L.s13_1 } else { "Выполняется самостоятельно, без Автообслуживания Windows, раз в неделю!" }
                        Write-Host "            $text`n" -ForegroundColor DarkGray
                    }
                    else
                    {
                        $DefragTaskSettings.Description = "{0}: $DrivesHDD, `n{1}" -f
                            $(if ( $L.s13 ) { $L.s13, $L.s13_2 } else { "Эта задача выполняет дефрагментацию ваших HDD дисков", "Выполняется только при Автообслуживании Windows, если не отключено!" })

                        $text = if ( $L.s13_2 ) { $L.s13_2 } else { "Выполняется только при Автообслуживании Windows, если не отключено!" }
                        Write-Host "            $text`n" -ForegroundColor DarkGray
                    }

                    [Hashtable] $DefragTaskHDD = @{
                        'TaskName'      = '\Microsoft\Windows\Defrag\HDD-Defrag'
                        'InputObject' = $DefragTaskSettings
                    }

                    Set-Tsk Register-ScheduledTask @DefragTaskHDD

                    [bool] $OrigTaskOff = $true
                }
                else
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { "Нет HDD дисков в системе" }
                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
            }

            if ( $OrigTaskOff )
            {
                $text = if ( $L.s14 ) { $L.s14 } else { "Отключение" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Оригинальной Задачи ScheduledDefrag по оптимизации дисков" }
                Write-Host "$text`n" -ForegroundColor Gray

                Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\ScheduledDefrag'
            }
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s15 ) { $L.s15 } else { "Удаление" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s15_1 ) { $L.s15_1 } else { "Раздельных задач оптимизации дисков" }
            Write-Host "$text`n" -ForegroundColor White

            Set-Tsk Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\HDD-Defrag'
            Set-Tsk Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\SSD-Trim'

            # Если задача существует, включаем её, если нет, создаём оригинальную задачу.
            if ( Check-State-Task '\Microsoft\Windows\Defrag\ScheduledDefrag' -CheckExist -Return Bool )
            {
                $text = if ( $L.s16 ) { $L.s16 } else { "Включение" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Оригинальной Задачи ScheduledDefrag по оптимизации дисков" }
                Write-Host "$text`n" -ForegroundColor White

                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\ScheduledDefrag'
            }
            else
            {
                $text = if ( $L.s17 ) { $L.s17 } else { "Создание" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Оригинальной Задачи ScheduledDefrag по оптимизации дисков" }
                Write-Host "$text`n" -ForegroundColor White

                [psobject] $DefragTaskSettings = Create-DefragTask-Settings

                $DefragTask = @{
                    'TaskName'      = '\Microsoft\Windows\Defrag\ScheduledDefrag'
                    'InputObject' = $DefragTaskSettings
                }

                Set-Tsk Register-ScheduledTask @DefragTask
            }
        }
        else
        {
            $text = if ( $L.s18 ) { $L.s18 } else { "'Check' не предусмотрен для 'CreateTasks' Создания задач" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Option -eq 'RunDfrGui' )
    {
        $text = if ( $L.s19 ) { $L.s19 } else { "Запуск" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Утилиты dfrgui.exe ..." }
        Write-Host "$text`n" -ForegroundColor White

        Start-Process -FilePath "$env:SystemDrive\Windows\System32\dfrgui.exe"

        Start-Sleep -Milliseconds 2000

        Return
    }
    elseif ( $Option -eq 'ShowEventLog' )
    {
        $text = if ( $L.s20 ) { $L.s20 } else { "Вывести Журнал" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s20_1 ) { $L.s20_1 } else { "обслуживания дисков" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s20_2 ) { $L.s20_2 } else { "через defrag.exe" }
        Write-Host "$text" -ForegroundColor DarkGray

        $text = if ( $L.s21 ) { $L.s21 } else { "Повторная оптимизация - это TRIM" }
        Write-Host "   $text`:" -ForegroundColor DarkGray

        try
        {
            Get-EventLog -LogName Application -Source "microsoft-windows-defrag" -ErrorAction Stop |
            Sort-Object TimeGenerated -Descending | Format-Table TimeGenerated, Message -HideTableHeaders
        }
        catch { Write-Host "`n   -------- " -ForegroundColor DarkGray }
    }
    else
    {
        if (( $Option -eq 'RunTRIM' ) -and ( $Act -eq 'Set' ))
        {
            if ( -not ( Get-Variable -Name AllDrivesSSD -Scope Global -ErrorAction SilentlyContinue ))
            {
                # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
                [hashtable] $LocalDrivesTable = Get-Local-Drives

                if ( -not $LocalDrivesTable.Values.Count )
                {
                    Write-Host "Get-PhysicalDisk: Error" -ForegroundColor Red
                    Get-Pause ; Return
                }
            }

            if ( $Global:AllDrivesSSD )
            {
                [string] $DrivesSSD = $Global:AllDrivesSSD -join ' '
                [string] $DefragExe = "$env:SystemDrive\Windows\System32\defrag.exe"

                $text = if ( $L.s22 ) { $L.s22 } else { "Выполнение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s22_1 ) { $L.s22_1 } else { "TRIM SSD дисков" }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$DrivesSSD`n" -ForegroundColor Green

                # '/U' = Передаёт defrag.exe, чтобы выводилось Отображение хода выполнения операции на экране.

                $text = if ( $L.s23 ) { $L.s23 } else { "Команда" }
                Write-Host "   $text`: $DefragExe $DrivesSSD /H /L /U`n" -ForegroundColor DarkGray

                [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('cp866')

                & $DefragExe $Global:AllDrivesSSD /H /L /U

                [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('utf-8')
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "Нет SSD дисков в системе" }
                Write-Host "`n   $text" -ForegroundColor DarkGray
            }
        }
        elseif (( $Option -eq 'RunDefrag' ) -and ( $Act -eq 'Set' ))
        {
            if ( -not ( Get-Variable -Name AllDrivesHDD -Scope Global -ErrorAction SilentlyContinue ))
            {
                # Получаем информацию по всем дискам в системе, и задаем глобальные переменные
                [hashtable] $LocalDrivesTable = Get-Local-Drives

                if ( -not $LocalDrivesTable.Values.Count )
                {
                    Write-Host "Get-PhysicalDisk: Error" -ForegroundColor Red
                    Get-Pause ; Return
                }
            }

            if ( $Global:AllDrivesHDD )
            {
                [string] $DrivesHDD = $Global:AllDrivesHDD -join ' '
                [string] $DefragExe = "$env:SystemDrive\Windows\System32\defrag.exe"

                $text = if ( $L.s24 ) { $L.s24 } else { "Выполнение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s24_1 ) { $L.s24_1 } else { "Дефрагментации HDD дисков" }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$DrivesHDD`n" -ForegroundColor Cyan

                $text = if ( $L.s23 ) { $L.s23 } else { "Команда" }
                Write-Host "   $text`: $DefragExe $DrivesHDD /H /O /U`n" -ForegroundColor DarkGray

                [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('cp866')

                & $DefragExe $Global:AllDrivesHDD /H /O /U

                [Console]::OutputEncoding = [System.Text.Encoding]::GetEncoding('utf-8')
            }
            else
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Нет HDD дисков в системе" }
                Write-Host "`n   $text" -ForegroundColor DarkGray
            }
        }
        elseif (( $Option -eq 'EnableTaskTRIM' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s27 ) { $L.s27 } else { "Задачи SSD-Trim" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\SSD-Trim'
        }
        elseif (( $Option -eq 'DisableTaskTRIM' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s26 ) { $L.s26 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s27 ) { $L.s27 } else { "Задачи SSD-Trim" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\SSD-Trim'
        }
        elseif (( $Option -eq 'EnableTaskDefrag' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s28 ) { $L.s28 } else { "Задачи HDD-Defrag" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\HDD-Defrag'
        }
        elseif (( $Option -eq 'DisableTaskDefrag' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s26 ) { $L.s26 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s28 ) { $L.s28 } else { "Задачи HDD-Defrag" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\HDD-Defrag'
        }
        elseif (( $Option -eq 'EnableOrigTaskDefrag' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s25 ) { $L.s25 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s29 ) { $L.s29 } else { "Задачи ScheduledDefrag" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\ScheduledDefrag'

            $text = if ( $L.s26 ) { $L.s26 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s28 ) { $L.s28 } else { "Задачи HDD-Defrag" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\HDD-Defrag'

            $text = if ( $L.s26 ) { $L.s26 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s27 ) { $L.s27 } else { "Задачи SSD-Trim" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\SSD-Trim'
        }
        elseif (( $Option -eq 'DisableOrigTaskDefrag' ) -and ( $Act -eq 'Set' ))
        {
            $text = if ( $L.s26 ) { $L.s26 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s29 ) { $L.s29 } else { "Задачи ScheduledDefrag" }
            Write-Host "$text`n" -ForegroundColor Gray

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\Defrag\ScheduledDefrag'
        }
    }

    $text = if ( $L.s30 ) { $L.s30 } else { "Все выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    Get-Pause
}
