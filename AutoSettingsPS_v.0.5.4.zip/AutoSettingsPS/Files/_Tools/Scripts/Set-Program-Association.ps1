﻿
<#
.SYNOPSIS
 Функция для проверки и назначения файловых ассоциаций.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Set_Program_Association

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-FTAssociation для назначения файловых ассоциаций, с генерацией Hash
 и дополнительными параметрами и действиями.
 Для выполнения всех действий нужны права администратора.

 Получает из файла пресетов 'Presets.txt' список параметров для назначения.

 Эта функция для проверки/подготовки заданных параметров в пресете и вывода их состояния в меню или перед выполнением.
 Неподходящие параметры пропускаются.
 Без использования утилит.
 Поддерживаются системные переменные в пути к файлам, например: %ProgramFiles(x86)% или %SystemDrive%

.EXAMPLE
    Set-Program-Association -CheckState 

.EXAMPLE
    Set-Program-Association


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  18-03-2021
 ===============================================

#>
Function Set-Program-Association {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'First', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Не используется, оставлено чтобы не выкидывало ошибок и пропускало действие при неправильном варианте.
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'First'  )]
        [Parameter( Mandatory = $true,  ParameterSetName = 'Select' )]
        [switch] $Select      # Если указана необходимость выбрать нужные наборы параметров
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [switch] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $Unregister
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    [int] $Number = 0
    [hashtable] $AssoccTypes = @{}

    # Заполняем таблицу $AssoccTypes. Для каждой строки подходящей под шаблон
    foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Set-Assocc-File\s*=\s*1\s*=.+' ))
    {
        # Если строка совпадает с шаблоном, и не содержит все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $Line -match '^\s*Set-Assocc-File\s*=\s*1\s*=\s*(?<String>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|?*``=#]+)(=(?<Type>[^=]+))?==' )
        {
            $Number++
            [string] $String = $Matches.String.Trim()
            if ( $Matches.Type ) { [string] $Type = $Matches.Type.Trim() } else { [string] $Type = '' }

            $AssoccTypes[$Number] = @{}
            $AssoccTypes[$Number]['GenID'] = ''
            $AssoccTypes[$Number]['Icon']  = ''
            $AssoccTypes[$Number]['Skip']  = $false
            $AssoccTypes[$Number]['Note']  = ''

            # Если строка не делится на 2 или 3 подстроки (то есть записана точно не корректно)
            if ( @(($String -Replace ('["''][^"'']+["'']','string')) -Replace ('["'',]','?') -Split ('\s+|[?]')).Count -notmatch '^[23]$' )
            {
                $AssoccTypes[$Number]['Error'] = $String
                $AssoccTypes[$Number]['Skip']  = $true
                $AssoccTypes[$Number]['Note']  = if ( $L.s1 ) { $L.s1 } else { 'Ошибка в строке пресета' }
            }
            else
            {
                # Разбиваем на подстроки
                [string[]] $Params = @(($String -Replace ('[^"''\s]+|["''][^"'']+["'']','$0?')).Trim('?') -Split ('[?]\s+|[?]'))
                $AssoccTypes[$Number]['Ext']    = $Params[0].Trim(' ''"')
                $AssoccTypes[$Number]['ProgID'] = [System.Environment]::ExpandEnvironmentVariables($Params[1].Trim(' ''"'))
                
                if ( $Params[2] ) { $AssoccTypes[$Number]['Icon'] = [System.Environment]::ExpandEnvironmentVariables($Params[2].Trim(' ''"')) }

                $ProgID = $AssoccTypes[$Number]['ProgID']
                $Ext    = $AssoccTypes[$Number]['Ext']

                if ( -not ( $Type -match '^(web|mail)$' ))
                {
                    if ( $Ext -match '^(http|https|ftp|microsoft-edge|[.](htm|html|shtml|xht|xhtml|webp))$' )
                    {
                        $Type = 'Web'
                    }
                    elseif ( $Ext -match '^(mailto|[.](eml|msg|ics|mbox|xpi|vcf))$' )
                    {
                        $Type = 'Mail'
                    }
                    else
                    {
                        $Type = ''
                    }
                }

                $AssoccTypes[$Number]['Type']  = $Type.ToLower()

                if ( $ProgID.Contains(':') -and [System.IO.File]::Exists($ProgID) )
                {
                    $FileEXE  = [System.IO.Path]::GetFileName($ProgID) -Replace ('\s','')
                    $FileEXE  = "{0}{1}" -f $FileEXE.Substring(0, 1).ToUpperInvariant(), $FileEXE.Remove(0, 1)
                    $FileName = [System.IO.Path]::GetFileNameWithoutExtension($FileEXE)

                    if ( $Type -eq 'Web' )
                    {
                        if ( $Ext.Contains('.') ) { $GenID = "$FileName.WEBFILES"     }
                        else                      { $GenID = "$FileName.WEBPROTOCOLS" }
                    }
                    elseif ( $Type -eq 'Mail' )
                    {
                        if ( $Ext.Contains('.') ) { $GenID = "$FileName.MAILFILES"     }
                        else                      { $GenID = "$FileName.MAILPROTOCOLS" }
                    }
                    else
                    {
                        if ( $Ext.Contains('.') ) { $GenID = "$FileName.FILES"     }
                        else                      { $GenID = "$FileName.PROTOCOLS" }
                    }

                    $AssoccTypes[$Number]['GenID'] = $GenID
                }
                elseif ( $ProgID.Contains(':') )
                {
                    if ( -not $Unregister )
                    {
                        # указан путь, но файл не сущестует, пропускать
                        $AssoccTypes[$Number]['Skip'] = $true
                        $AssoccTypes[$Number]['Note'] = if ( $L.s2 ) { $L.s2 } else { 'Файл программы не найден' }
                    }
                }
                else
                {
                    try   { $OpenSubKey = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($ProgID,'ReadSubTree','QueryValues') }
                    catch { $OpenSubKey = $null }
        
                    # Если указанный ProgID не зарегистрирован, то пропускать
                    if ( -not $OpenSubKey.Name )
                    {
                        $AssoccTypes[$Number]['Skip'] = $true
                        $AssoccTypes[$Number]['Note'] = if ( $L.s3 ) { $L.s3 } else { 'ProgID не зарегистрирован' }
                    }
                    else
                    {
                        $OpenSubKey.Close()
                    }
                }
            }
        }
        elseif ( $Line -match '^\s*Set-Assocc-File\s*=\s*1\s*=\s*(?<String>.+)==' )
        {
            # Иначе если строка имеет запрещенные символы, пропускать
            $Number++
            [string] $String = $Matches.String.Trim()
            $AssoccTypes[$Number] = @{}
            $AssoccTypes[$Number]['Error'] = $String
            $AssoccTypes[$Number]['Skip']  = $true
            $AssoccTypes[$Number]['Note']  = if ( $L.s4 ) { $L.s4 } else { 'Запрещённые символы в строке пресета' }
        }
    }

    # Не выводить заголовок, если проверка параметров в пресете или предлагается выбор
    if ( -not $CheckState -and -not $Select )
    {
        if (( $Act -eq 'Check' ) -or ( $Act -eq 'Default' ))
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "'Check/Default' не предусмотрены" }
            Write-Host "`n $NameThisFunction`: $text`n" -ForegroundColor DarkGray

            Return   # Выход из функции
        }

        # Проверка наличия функции Set-FTAssociation
        if ( -not ( Get-Command -CommandType Function -Name 'Set-FTAssociation' -ErrorAction SilentlyContinue ))
        { Write-Warning "`n  $NameThisFunction`: Function not found: Set-FTAssociation" ; Return } # Выход из функции.

        $text = if ( $L.s6 ) { $L.s6 } else { "Настройка" }
        Write-Host "`n██ $text " -ForegroundColor White -NoNewline

        $text = if ( $L.s6_1 ) { $L.s6_1 } else { "Файловых Ассоциаций" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s6_2 ) { $L.s6_2 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    if ( -not $CheckState ) { [int] $Indent = 4 } else { [int] $Indent = 7 }

    # Если указана необходимость выбрать нужные параметры.
    if ( $Select -and $AssoccTypes.Count )
    {
        # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
          [char] $Escape          = 27
           [int] $StringsExcl     = 3              # Количество последних строк для затирания.
        [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
        [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

        Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline

        # Ждем ввода пользователя.
        $text = if ( $L.s7 ) { $L.s7 } else { 'Введите номера через пробел и/или диапазон через дефис' }

        Write-Host "   $text"

        $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Номера' }

        [string] $Choice = Read-Host -Prompt "   $text"

        [Uint16[]] $SelectedParams = $null

        # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
        # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера наборов.
        # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedParams, с выбранными существующми намерами.
        if ( -not ( $Choice.Trim() -eq '' ))
        {
            [array] $arr = @()

            # Добавление групп указанных через дефис
            foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

            $arr | ForEach-Object {
                
                try
                {
                    [Uint16] $ParamNumber = $_

                    if (( $ParamNumber -gt 0 ) -and ( $ParamNumber -le $AssoccTypes.Count ) -and ( $SelectedParams -notcontains $ParamNumber ))
                    { [Uint16[]] $SelectedParams += $ParamNumber }
                }
                catch {}
            }
        }

        if ( -not $SelectedParams )
        {
            $text = if ( $L.s8 ) { $L.s8 } else { 'Неверный выбор!' }
            Write-Host "`n   $text`n" -ForegroundColor Yellow
            Start-Sleep -Milliseconds 1000
            Return
        }

        $text = if ( $L.s9 ) { $L.s9 } else { 'Выбранные параметры' }
        Write-HostColor "`n      $text`: #DarkGray#[ #White#$SelectedParams #DarkGray#]#`n"
    }

    # Выводим информацию по всем строкам.
    foreach ( $Number in $AssoccTypes.Keys | Sort-Object )
    {
        if ( $Select -and ( -not ( $SelectedParams -like $Number ) )) { Continue }  # Пропуск не выбранных номеров, если был выбор

        if ( $AssoccTypes[$Number]['Error'] )
        {
            $State = 'х'
            [string] $ResultShow = "#DarkGray#{0}. #Red#{1} #DarkGray#------ | #Red#{2} #DarkGray#| #Red#{3}#" -f
                $Number.ToString().PadLeft($Indent,' '),
                $State,
                $AssoccTypes[$Number]['Error'].ToString(),
                $AssoccTypes[$Number]['Note']
        }
        else
        {
            $GenID  = $AssoccTypes[$Number]['GenID']
            $ProgID = $AssoccTypes[$Number]['ProgID']
            $Ext    = $AssoccTypes[$Number]['Ext']
            $Icon   = $AssoccTypes[$Number]['Icon']
            $Note   = $AssoccTypes[$Number]['Note']

            $Type   = $AssoccTypes[$Number]['Type']

            if ( $AssoccTypes[$Number]['Skip'] )
            {
                $State = 'х' ; $Color = 'Red' ; $ColorName = 'Red' 
            }
            else
            {
                $State = '○' ; $Color = 'Yellow' ; $ColorName = 'White' 

                if ( $Ext.Contains('.') )
                {
                    [string] $Path = "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\$Ext\UserChoice"
                }
                else
                {
                    [string] $Path = "HKEY_CURRENT_USER\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\$Ext\UserChoice"
                }
                
                [string] $GetProgId = [Microsoft.Win32.Registry]::GetValue($Path,'ProgId',$null)

                if ( $GenID )
                {
                    if ( $GenID -eq $GetProgId )
                    {
                        [string] $GetCommand = [Microsoft.Win32.Registry]::GetValue("HKEY_CLASSES_ROOT\$GenID\shell\open\command",'',$null)
                        [string] $ProgPath   = ''

                        if ( $GetCommand )
                        {
                            $ProgPath = @(($GetCommand.Trim() -Replace ('[^"''\s]+|["''][^"'']+["'']','$0?')).Trim('?') -Split ('[?]\s+|[?]'))[0].ToString().Trim('''"')
                        }

                        if ( $ProgID -eq $ProgPath ) { $State = '●' ; $Color = 'Green' }
                    }
                }
                elseif ( $ProgID -eq $GetProgId ) { $State = '●' ; $Color = 'Green' }
            }

            if ( $GenID ) { $ShowGenID = " #DarkGray#| GenID: #White#$GenID" } else { $ShowGenID = '' }

            if ( $Note ) { $ShowNote = " #DarkGray#| #Red#$Note" } else { $ShowNote = '' }

            if ( $Type ) { $ShowType = " #DarkGray#| #DarkMagenta#$Type" } else { $ShowType = '' }

            if ( $Icon )
            {
                if ( $Icon -eq '%1' -or [System.IO.File]::Exists(@($Icon.ToString().Split(','))[0]) )
                {
                    $IconColor = 'White'
                }
                else
                {
                    $IconColor = 'DarkGray'
                    
                    if ( $Note )
                    {
                        $ShowNote  = " #DarkGray#| #Red#$Note#DarkGray#, {0}" -f $(if ( $L.s10 ) { $L.s10 } else { 'Файл иконки не найден' })
                    }
                    else
                    {
                        $ShowNote  = " #DarkGray#| {0}" -f $(if ( $L.s10 ) { $L.s10 } else { 'Файл иконки не найден' })
                    }
                }

                [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #White#{2} #DarkGray#| #$ColorName#{3} #DarkGray#| Icon: #$IconColor#{4}$ShowType$ShowGenID$ShowNote#" -f
                    $Number.ToString().PadLeft($Indent,' '),
                    $State,
                    $Ext.ToString().PadRight(6,' '),
                    $ProgID,
                    $Icon
            }
            else
            {
                [string] $ResultShow = "#DarkGray#{0}. #$Color#{1} #White#{2} #DarkGray#| #$ColorName#{3}$ShowType$ShowGenID$ShowNote#" -f
                    $Number.ToString().PadLeft($Indent,' '),
                    $State,
                    $Ext.ToString().PadRight(6,' '),
                    $ProgID
            }
        }

        if ( -not $CheckState ) { Write-Host }

        Write-HostColor $ResultShow

        if ( $CheckState ) { Continue }


        # Далее, если выполнение ...

        if ( $AssoccTypes[$Number]['Skip'] )
        {
            $text = if ( $L.s11 ) { $L.s11 } else { 'Пропущено' }
            Write-Host "`n      $text" -ForegroundColor DarkYellow
            
            Continue
        }
        
        Write-Host

        # Выполняем назначение на открытие с генерацией Hash указанного ID и расширения, и установки запрета доступа на изменения на раздел.
        # Так же установка дополнительных параметров для соблюдения основных условий, чтобы в будущем не было сброса расширения на программу по умолчанию

        if ( $Unregister )
        {
            Set-FTAssociation -Extension $Ext -ProgId $ProgID -Unregister
        }
        else
        {
            if ( $Type -eq 'Web' )
            {
                Set-FTAssociation -Extension $Ext -ProgId $ProgID -Icon:$Icon -Web
            }
            elseif ( $Type -eq 'Mail' )
            {
                Set-FTAssociation -Extension $Ext -ProgId $ProgID -Icon:$Icon -Mail
            }
            else
            {
                Set-FTAssociation -Extension $Ext -ProgId $ProgID -Icon:$Icon
            }
        }
    }

    if ( -not $AssoccTypes.Count )
    {
        $text = if ( $L.s12 ) { $L.s12 } else { 'Не указаны Параметры в файле пресетов' }

        if ( $CheckState )
        {
            Write-Host "         $text" -ForegroundColor DarkYellow
        }
        else
        {
            Write-Host "`n   $text`n" -ForegroundColor DarkYellow
        }
    }

    if ( $CheckState )
    {
        Return
    }

    # Если запуск не из главных меню быстрых настроек (0 и 1)
    if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
    {
        Get-Pause
    }

    Return
}
