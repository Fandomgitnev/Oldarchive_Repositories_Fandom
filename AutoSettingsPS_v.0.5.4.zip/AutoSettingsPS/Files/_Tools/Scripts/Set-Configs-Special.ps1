﻿
# Группы параметров для опытных.
Function Set-Configs-Special {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false, Position = 1 )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [string[]] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [Environment]::Is64BitOperatingSystem


    # Далее сами настройки ...



    $Info = "Отключить Трассировку для SleepStudy (Connected Standby, Modern Sleep) - Режим Полу-Сна 'S0'"
    $Group = 'Spec-SleepStudy' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        # Переменная для пропуска отключения SleepStudy, если используется режим сна S0
        try { if ( (powercfg /a 2>$null) -join '#' -match ':(?<Modes>(.*))#.+:' ) { if ( $Matches.Modes -like '*S0*' ) { $SleepS0 = $true } else { $SleepS0 = $false } } } catch {}

        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( -not $SleepS0 )
        {
            # Блокировка трассировки убирает 2 задания трасировки, которые сохраняют логи в C:\Windows\System32\SleepStudy, и иногда приводят к сильному потреблению ресурсов процессора и диска.
            # Задания находятся в Администрирование -> Системный Монитор -> Группа Сборщиков данных -> Сеансы отслеживания событий
            # ScreenOnPowerStudyTraceSession задание создает при старте другая трассировка по имени DiagLog, которая наполняется другой трассировкой: WdiContextLog.
            # Их отключение, как и некоторых других, приводит к проблемам, так как трассировки и их логи используются различными службами и приложениями, не отключать DiagLog и WdiContextLog!

            if ( $Act -eq 'Set' )
            {
                Stop-Trace -SessionName 'ScreenOnPowerStudyTraceSession' -ETS -ErrorAction SilentlyContinue *> $null
                Stop-Trace -SessionName 'UserNotPresentTraceSession' -ETS -ErrorAction SilentlyContinue *> $null
                
                $N = 0
                
                (Get-ChildItem -File -LiteralPath "\\?\$env:SystemDrive\Windows\System32\SleepStudy" -Recurse -Force -ErrorAction SilentlyContinue
                    ).FullName.ForEach({
                        
                        if ( -not $N ) { Write-Host }
                        $N++
                        $log = $_

                        Write-Host "       Del: $log" -ForegroundColor DarkGray

                        Remove-Item -LiteralPath $log -Force -ErrorAction SilentlyContinue
                    })

                "$env:SystemDrive\Windows\System32\SleepStudy",
                "$env:SystemDrive\Windows\System32\SleepStudy\ScreenOn" | ForEach-Object {
                    Set-OwnerAndAccess -Path $_ -RecoverySDDL "
                        O:LSG:LSD:PAI(D;OICI;DCLCRPCR;;;WD)(D;OICI;FA;;;AN)(D;OICI;FA;;;BG)(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;BU)
                        (A;OICI;FA;;;S-1-5-80-2066226495-3997108304-3880305899-3645215860-1263843924)
                        (A;OICI;FA;;;S-1-5-80-2970612574-78537857-698502321-558674196-1451644582)"
                }
            }

            try { [psobject] $Acl = (Get-Acl -LiteralPath "\\?\$env:SystemDrive\Windows\System32\SleepStudy" -ErrorAction SilentlyContinue).Sddl } catch {}

            if ( $Acl -like '*(D;OICI;DCLCRPCR;;;WD)*' )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Блокировка Трасировки Установлена" }
                Write-Host "       $text`n" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "Блокировка Трасировки Не Установлена" }
                Write-Host "       $text`n" -ForegroundColor Yellow

                $NeedFix = $true
            }

            # Отключения журнала ошибок для трасировщика, которое сообщает о не возможности создать задание, при блокировке записи.
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Kernel-EventTracing/Admin' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{b675ec37-bdb6-4648-bc92-f3fdc74d3ca2}' -Name 'Enabled' -Type DWord 0

            # Проблема: При отключении "Современного" режима Полу-Сна S0, принудительно включается Старый Обычный Режим Сна S3,
            # что может привести к разным проблемам при использовании спящего режима из-за "несовместимости" оборудования или драйверов.

            # Включить принудительное использование Старого полноценного Режима Сна "S3":
            # Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'CsEnabled' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s6 ) { $L.s6 } else { 'Пропуск (включен режим S0)' }
            Write-Host "      $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        "$env:SystemDrive\Windows\System32\SleepStudy",
        "$env:SystemDrive\Windows\System32\SleepStudy\ScreenOn" | ForEach-Object {
            Set-OwnerAndAccess -Path $_ -RecoverySDDL "
                O:LSG:LSD:PAI(D;OICI;FA;;;AN)(D;OICI;FA;;;BG)(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)
                (A;OICI;FA;;;S-1-5-80-2066226495-3997108304-3880305899-3645215860-1263843924)
                (A;OICI;FA;;;S-1-5-80-2970612574-78537857-698502321-558674196-1451644582)"
        }

        try { [psobject] $Acl = (Get-Acl -LiteralPath "\\?\$env:SystemDrive\Windows\System32\SleepStudy" -ErrorAction SilentlyContinue).Sddl } catch {}

        if ( $Acl -like '*(D;OICI;DCLCRPCR;;;WD)*' )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Блокировка Трасировки Не Убрана" }
            Write-Host "      $text`n" -ForegroundColor Yellow

            $NeedFix = $true
        }
        else
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Блокировка Трасировки Убрана" }
            Write-Host "      $text`n" -ForegroundColor Green
        }

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Kernel-EventTracing/Admin' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{b675ec37-bdb6-4648-bc92-f3fdc74d3ca2}' -Name 'Enabled' -Type DWord 1

        # Включить использование "Современного" Режима Сна "S0" (S0 - Это ПолуСон, в этом режиме система может быть активна, и делать всё, что захочет)
        # Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Power' -Name 'CsEnabled' -Type DWord 1
    }



    $Info = 'Отключить Трассировку фильтра IPsec Брандмауэра (wfpdiag.etl, Process Hacker включает эту трассировку)'
    $Group = 'Spec-wfpdiag' ; $L = $Lang.$Group

    # Отключение трассировки убирает постоянную запись лога диагностики фильтра IPsec Брандмауэра (WFP-IPsec Diagnostics):
    # C:\ProgramData\Microsoft\Windows\wfp\wfpdiag.etl (~ 1гб за 8ч)
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( $Act -eq 'Set' )
        {
            netsh.exe wfp set options netevents = off

            if (( netsh.exe wfp show options netevents ) -like 'netevents = off' )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "  Выполнено" }
                Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                Write-Host "NetEvents " -ForegroundColor White -NoNewline
                Write-Host "| netsh.exe wfp set options netevents = off" -ForegroundColor DarkGray
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "    Неверно" }
                Write-Host "!!!:   Set: $text " -ForegroundColor Yellow -NoNewline
                Write-Host "NetEvents " -ForegroundColor White -NoNewline
                Write-Host "| netsh.exe wfp set options netevents = off" -ForegroundColor Gray

                $NeedFix = $true
            }
        }
        elseif ( $Act -eq 'Check' )
        {
            if (( netsh.exe wfp show options netevents ) -like 'netevents = off' )
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "      Верно" }
                Write-Host "  +: Check: $text " -ForegroundColor Green -NoNewline
                Write-Host "NetEvents " -ForegroundColor White -NoNewline
                Write-Host "| netsh.exe wfp set options netevents = off" -ForegroundColor DarkGray
            }
            else
            {
                $text = if ( $L.s5 ) { $L.s5 } else { "    Неверно" }
                Write-Host "!!!: Check: $text " -ForegroundColor Yellow -NoNewline
                Write-Host "NetEvents " -ForegroundColor White -NoNewline
                Write-Host "| netsh.exe wfp set options netevents = off" -ForegroundColor Gray

                $NeedFix = $true
            }
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        netsh.exe wfp set options netevents = on
    }



    $Info = 'Отключить Фиксы Meltdown и Spectr'
    $Group = 'Spec-MeltdownSpectr' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Отключение фиксов Meltdown и Spectr:" | Show-Info -Shift $L.s2 -NotIndent

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'FeatureSettingsOverride' -Type DWord 3
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'FeatureSettingsOverrideMask' -Type DWord 3
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'FeatureSettingsOverride'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'FeatureSettingsOverrideMask'
    }



    $Info = 'Запретить отключение сетевых адаптеров для экономии энергии'
    $Group = 'Spec-TurnOffNetDevice' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Отключение вывода прогресс бара
        $Global:ProgressPreference = 'SilentlyContinue'

        $NetAdapters = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Get-NetAdapterPowerManagement -ErrorAction SilentlyContinue |
            Where-Object -FilterScript { $_.AllowComputerToTurnOffDevice -ne 'Unsupported' }

        [int] $N = 0 ; [int] $Count = 0

        foreach ( $NetAdapter in $NetAdapters )
        {
            $Count++

            if ( $Count -ge 2 ) { Write-Host }

            if ( $NetAdapter.AllowComputerToTurnOffDevice -eq 'Enabled' )
            {
                $text = if ( $L.s2 ) { $L.s2 } else { "Запретить отключение" }
                Write-Host "   $text " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Адаптер" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                if ( $Act -eq 'Set' )
                {
                    Write-Host $NetAdapter.Name -ForegroundColor Cyan

                    $NetAdapter.AllowComputerToTurnOffDevice = 'Disabled'
                    $NetAdapter | Set-NetAdapterPowerManagement -ErrorAction SilentlyContinue

                    $N++
                }
                else
                {
                    Write-Host $NetAdapter.Name -ForegroundColor Yellow
                    
                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "Отключение уже запрещено" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Адаптер" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host $NetAdapter.Name -ForegroundColor Cyan
            }
        }

        if ( $Act -eq 'Set' )
        {
            if ( $N )
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Настроено" }
                Write-Host "`n   $text" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s5 ) { $L.s5 } else { "Завершено" }
                Write-Host "`n   $text" -ForegroundColor Green
            }
        }

        # Возврат показа прогресс бара
        $Global:ProgressPreference = 'Continue'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        # Отключение вывода прогресс бара
        $Global:ProgressPreference = 'SilentlyContinue'

        $NetAdapters = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Get-NetAdapterPowerManagement -ErrorAction SilentlyContinue |
            Where-Object -FilterScript { $_.AllowComputerToTurnOffDevice -ne 'Unsupported' }

        [int] $N = 0 ; [int] $Count = 0

        foreach ( $NetAdapter in $NetAdapters )
        {
            $Count++

            if ( $Count -ge 2 ) { Write-Host }

            if ( $NetAdapter.AllowComputerToTurnOffDevice -eq 'Disabled' )
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Разрешить отключение" }
                Write-Host "   $text " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Адаптер" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host $NetAdapter.Name -ForegroundColor Cyan

                $NetAdapter.AllowComputerToTurnOffDevice = 'Enabled'
                $NetAdapter | Set-NetAdapterPowerManagement -ErrorAction SilentlyContinue

                $N++
            }
            else
            {
                $text = if ( $L.s7 ) { $L.s7 } else { "Отключение уже разрешено" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s2_1 ) { $L.s2_1 } else { "Адаптер" }
                Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host $NetAdapter.Name -ForegroundColor Cyan
            }
        }

        if ( $N )
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Настроено" }
            Write-Host "`n   $text" -ForegroundColor Green
        }
        else
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Завершено" }
            Write-Host "`n   $text" -ForegroundColor Green
        }
        
        # Возврат показа прогресс бара
        $Global:ProgressPreference = 'Continue'
    }



    $Info = 'Восстановить поддержку Dolby Digital Decoder (AC3 звук) для LTSC 17763/19041 x64/x86'
    $Group = 'Spec-DolbyDecMFT' ; $L = $Lang.$Group

    # Настройка нужна только для версии Windows 10 версий 17763/19041 x64/x86 (если нет файла, обычно его нет в LTSC)
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string] $Archive    = "$CurrentRoot\Files\DolbyDecMFT.7z"
        [string] $FileDest   = "$env:SystemDrive\Windows\System32\DolbyDecMFT.dll"
        [string] $FileDest64 = "$env:SystemDrive\Windows\SysWOW64\DolbyDecMFT.dll"

        if ( [System.IO.File]::Exists($Archive) )
        {
            if ( -not [System.IO.File]::Exists($FileDest) )
            {
                if ( $Act -eq 'Set' )
                {
                    if ( [System.Environment]::OSVersion.Version.Build -ge 19041 ) { [int] $vers = 19041 } else { [int] $vers = 17763 }

                    $text = if ( $L.s2 ) { $L.s2 } else { "Восстановление файлов из" }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Archive " -ForegroundColor Gray -NoNewline
                    Write-Host "| $vers" -ForegroundColor DarkGray

                    # Расскрываем короткие имена в пути
                    [string] $TempPath = $([System.IO.Path]::GetFullPath($env:TEMP))

                    if ( $is64 )
                    {
                        $text = if ( $L.s3 ) { $L.s3 } else { "Копируем dll файл x64 в" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$FileDest" -ForegroundColor DarkGray

                        & $7z e "$Archive" -o"$TempPath" "-i!$vers\x64\DolbyDecMFT.dll" -aoa -bso0 -bse0 -bsp0

                        Move-Item -LiteralPath $TempPath\DolbyDecMFT.dll -Destination $FileDest -Force -ErrorAction SilentlyContinue

                        if ( [System.IO.File]::Exists($FileDest) )
                        {
                            $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Скопирован" }
                            Write-Host "   $text" -ForegroundColor DarkGreen
                        }
                        else
                        {
                            $text = if ( $L.s3_2 ) { $L.s3_2 } else { "Не скопирован" }
                            Write-Host "   $text" -ForegroundColor Red
                        }

                        if ( -not [System.IO.File]::Exists($FileDest64) )
                        {
                            $text = if ( $L.s3_3 ) { $L.s3_3 } else { "Копируем dll файл x86 в" }
                            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "$FileDest64" -ForegroundColor DarkGray

                            & $7z e "$Archive" -o"$TempPath" "-i!$vers\x86\DolbyDecMFT.dll" -aoa -bso0 -bse0 -bsp0

                            Move-Item -LiteralPath $TempPath\DolbyDecMFT.dll -Destination $FileDest64 -Force -ErrorAction SilentlyContinue

                            if ( [System.IO.File]::Exists($FileDest64) )
                            {
                                $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Скопирован" }
                                Write-Host "   $text" -ForegroundColor DarkGreen
                            }
                            else
                            {
                                $text = if ( $L.s3_2 ) { $L.s3_2 } else { "Не скопирован" }
                                Write-Host "   $text" -ForegroundColor Red
                            }
                        }

                        $text = if ( $L.s4 ) { $L.s4 } else { "Регистрация dll x64 и x86" }
                        Write-Host "   $text" -ForegroundColor DarkCyan

                        Start-Process "$env:SystemDrive\Windows\System32\regsvr32.exe" -ArgumentList "/s $FileDest"   -Wait -ErrorAction SilentlyContinue
                        Start-Process "$env:SystemDrive\Windows\System32\regsvr32.exe" -ArgumentList "/s $FileDest64" -Wait -ErrorAction SilentlyContinue
                    }
                    else
                    {
                        $text = if ( $L.s3_3 ) { $L.s3_3 } else { "Копируем dll файл x86 в" }
                        Write-Host "   $text`: $FileDest" -ForegroundColor DarkCyan

                        & $7z e "$Archive" -o"$TempPath" "-i!$vers\x86\DolbyDecMFT.dll" -aoa -bso0 -bse0 -bsp0

                        Move-Item -LiteralPath $TempPath\DolbyDecMFT.dll -Destination $FileDest -Force -ErrorAction SilentlyContinue

                        $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Регистрация dll x86" }
                        Write-Host "   $text" -ForegroundColor DarkCyan

                        Start-Process "$env:SystemDrive\Windows\System32\regsvr32.exe" -ArgumentList "/s $FileDest" -Wait -ErrorAction SilentlyContinue
                    }

                    try
                    {
                        [string] $SubKey = 'SOFTWARE\Classes\CLSID\{177C0AFE-900B-48D4-9E4C-57ADD250B3D4}\InprocServer32'
                        [string] $DolbyDecReg = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'',$null)
                    } catch {}

                    if ( $DolbyDecReg )
                    {
                        $text = if ( $L.s4_2 ) { $L.s4_2 } else { "Зарегистрировано" }
                        Write-Host "   $text" -ForegroundColor DarkGreen
                    }
                    else
                    {
                        $text = if ( $L.s4_3 ) { $L.s4_3 } else { "Не Зарегистрировано" }
                        Write-Host "   $text" -ForegroundColor Red
                    }

                    $text = if ( $L.s5 ) { $L.s5 } else { "Завершено" }
                    Write-Host "`n   $text" -ForegroundColor Green
                }
                else
                {
                    $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Не восстановлено" }
                    Write-Host "   $text" -ForegroundColor Yellow

                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s5_2 ) { $L.s5_2 } else { "Поддержка уже присутствует" }
                Write-Host "   $text" -ForegroundColor DarkGreen
            }
        }
        else
        {
            $text = if ( $L.s6 ) { $L.s6 } else { "Нет архива" }
            Write-Host "   $text" -ForegroundColor Yellow
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        [string] $FileDest   = "$env:SystemDrive\Windows\System32\DolbyDecMFT.dll"
        [string] $FileDest64 = "$env:SystemDrive\Windows\SysWOW64\DolbyDecMFT.dll"

        $File = Get-Item $FileDest -Force -ErrorAction SilentlyContinue

        if ( $File.Exists -and ( $File.LinkType -like $null ))
        {
            $text = if ( $L.s7 ) { $L.s7 } else { "Удаление поддержки Dolby Digital Decoder" }
            Write-Host "   $text" -ForegroundColor Magenta

            Start-Process "$env:SystemDrive\Windows\System32\regsvr32.exe" -ArgumentList "/s /u $FileDest" -Wait -ErrorAction SilentlyContinue

            Remove-Item $FileDest -Force -ErrorAction SilentlyContinue

            if ( $is64 )
            {
                Start-Process "$env:SystemDrive\Windows\System32\regsvr32.exe" -ArgumentList "/s /u $FileDest64" -Wait -ErrorAction SilentlyContinue

                Remove-Item $FileDest64 -Force -ErrorAction SilentlyContinue
            }

            $text = if ( $L.s5 ) { $L.s5 } else { "Завершено" }
            Write-Host "`n   $text" -ForegroundColor Green
        }
        elseif ( -not $File.Exists )
        {
            $text = if ( $L.s8 ) { $L.s8 } else { "Уже удалена поддержка Dolby Digital Decoder" }
            Write-Host "   $text" -ForegroundColor DarkGreen
        }
        else
        {
            $text = if ( $L.s9 ) { $L.s9 } else { "Пропуск удаления поддержки, является компонентом Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Отключить и удалить зарезервированное хранилище'
    $Group = 'Spec-ReservedStorage' ; $L = $Lang.$Group

    # 19041 (2004); 18363 (1909); 18362 (1903)  Настройка только для версии Windows 10 от 1903
    if ( $Groups -like $Group )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            $Info | Show-Info -Shift $L.s1 -Action $Act

            try { [int] $Reserves = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager','ShippedWithReserves',$null) }
            catch { [int] $Reserves = 0 }

            if ( $Reserves -eq 1 )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'ShippedWithReserves' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'PassedPolicy' -Type DWord 0

                if ( $Act -eq 'Set' )
                {
                    if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
                    {
                        Write-Host "`n   $env:SystemDrive\Windows\system32\Dism.exe /Online /NoRestart /Set-ReservedStorageState /State:Disabled" -ForegroundColor DarkGray

                        #try { Set-WindowsReservedStorageState -State Disabled -ErrorAction SilentlyContinue } catch {} # Виснет иногда на выполнении командлета
                        try { & "$env:SystemDrive\Windows\system32\Dism.exe" /Online /NoRestart /Set-ReservedStorageState /State:Disabled /ScratchDir:"$DismScratchDirGlobal" } catch {}
                    }

                    Write-Host "`n   $env:SystemDrive\Windows\System32\UsoClient.exe StartScan" -ForegroundColor DarkGray

                    # Запуск только поиска обновлений для активации отключения резервирования, удаляет резервирование почти сразу даже без сети
                    try { & "$env:SystemDrive\Windows\System32\UsoClient.exe" StartScan > $null } catch {}

                    $text = if ( $L.s3 ) { $L.s3 } else { "Выполнено" }
                    Write-Host "`n   $text" -ForegroundColor Green
                }
            }
            else
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'ShippedWithReserves' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'PassedPolicy' -Type DWord 0

                $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Уже Отключено" }
                Write-Host "`n   $text" -ForegroundColor Green
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 )
        {
            $Info | Show-Info -Shift $L.s1 -Action Default

            try { [int] $Reserves = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager','ShippedWithReserves',$null) }
            catch { [int] $Reserves = 0 }

            if ( $Reserves -eq 0 )
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'ShippedWithReserves' -Type DWord 1
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'PassedPolicy' -Type DWord 1

                if ( [System.Environment]::OSVersion.Version.Build -ge 19041 )
                {
                    Write-Host "`n   $env:SystemDrive\Windows\system32\Dism.exe /Online /NoRestart /Set-ReservedStorageState /State:Enabled" -ForegroundColor DarkGray

                    # try { Set-WindowsReservedStorageState -State Enabled -ErrorAction SilentlyContinue } catch {} # Виснет иногда на выполнении командлета
                    try { & "$env:SystemDrive\Windows\system32\Dism.exe" /Online /NoRestart /Set-ReservedStorageState /State:Enabled /ScratchDir:"$DismScratchDirGlobal" } catch {}
                }

                $text = if ( $L.s3 ) { $L.s3 } else { "Выполнено" }
                Write-Host "`n   $text" -ForegroundColor Green
            }
            else
            {
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'ShippedWithReserves' -Type DWord 1
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\ReserveManager' -Name 'PassedPolicy' -Type DWord 1

                $text = if ( $L.s3_1 ) { $L.s3_1 } else { "Уже Включено" }
                Write-Host "`n   $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется в этой версии Windows" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    # Отключение всех настроек конфиденциальности для режима OOBE, и в NTUSER.DAT | Вывод перевода внутри функции
    $Group = 'Spec-PrivacySettingsOOBE'

    if ( $Groups -like $Group )
    {
        Set-PrivacySettingsOOBE -Act $Act
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        Set-PrivacySettingsOOBE -Act Default
    }



    $Info = 'Отключить Автономные файлы в Центре синхронизации'
    $Group = 'Spec-OfflineFiles' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'CscService' -StartupType Disabled
        Set-Drv -Do:$Act Set-Driver -Name 'CSC' -StartupType Disabled

        # включать обратно их не нужно, они отключены по умолчанию
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Offline Files\Background Synchronization'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Offline Files\Logon Synchronization'

        # Конфигурация компьютера -> Административные шаблоны -> Сеть -> Автономные файлы -> Разрешить или запретить использование автономных файлов "Отключено" 
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'Enabled' -Type DWord 0
       
        # Конфигурация компьютера -> Административные шаблоны -> Сеть -> Автономные файлы -> Удалить команду "Работать автономно" "Включено" 
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'WorkOfflineDisabled' -Type DWord 1
        
        # Конфигурация компьютера -> Административные шаблоны -> Сеть -> Автономные файлы -> Удалить команду "Сделать доступными автономно" "Включено" 
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'NoMakeAvailableOffline' -Type DWord 1

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
        {
            [string] $Value = $Matches.Debugger.Trim()
        }
        else { [string] $Value = 'dllhost.exe' }

        # Блокировка запуска центра синхронизации, ошибок в журналах нет от этого. Запускается при каждом входе.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\mobsync.exe' -Name 'Debugger' -Type String $Value
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'CscService' -StartupType Manual
        Set-Drv Set-Driver -Name 'CSC' -StartupType System

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'Enabled'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'WorkOfflineDisabled'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetCache' -Name 'NoMakeAvailableOffline'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\mobsync.exe' -Name 'Debugger'
    }



    $Info = 'Включить Доступ к сетевым дискам, независимо от режима привилегий (Пользователь/Админ)'
    $Group = 'Spec-MappedDrivesAccess' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLinkedConnections' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLinkedConnections'
    }



    $Info = 'Отключение Windows Script Host (wscript.exe, cscript.exe, .vbs)'
    $Group = 'Spec-DisableVbs' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Проблема: Если отключить Windows Script Host, выполняющий сценарии VBS (wscript.exe, cscript.exe),
        # то активировать Windows не получится.
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings' -Name 'Enabled' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Script Host\Settings' -Name 'Enabled'
    }



    $Info = 'Исправить Ошибки настроек доступов: DistributedCOM 10016'
    $Group = 'Spec-FixDCOM' ; $L = $Lang.$Group

    # Только для Windows 10 версии 1809
    if (( $Groups -like $Group ) -and ( [System.Environment]::OSVersion.Version.Build -eq 17763 ))
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # RuntimeBroker Разрешения на Локальный запуск и активацию для 'Пользователей'
        Set-DComPermission -Do:$Act -AppID '{15c20b67-12e7-4bb6-92bb-7aff07997402}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-32-545' `
            -AceType 'AccessAllowed' -Permissions 'LocalLaunch','LocalActivation'

        # ShellServiceHost Разрешения на Локальный запуск и активацию для LOCAL SERVICE
        Set-DComPermission -Do:$Act -AppID '{4839DDB7-58C2-48F5-8283-E1D1807D0D7D}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-19' `
            -AceType 'AccessAllowed' -Permissions 'LocalLaunch','LocalActivation'

        # Immersive Shell Разрешения на запуск и активацию для SELF, SYSTEM, LOCAL SERVICE, Администраторы, Пользователи.
        Set-DComPermission -Do:$Act -AppID '{316CDED5-E4AE-4B15-9113-7055D84DCC97}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-10','S-1-5-18','S-1-5-19','S-1-5-32-544','S-1-5-32-545' `
            -AceType 'AccessAllowed' -Permissions 'LocalLaunch','LocalActivation'

        # Immersive Shell Разрешения на Доступ для SELF, SYSTEM, LOCAL SERVICE, Администраторы, Пользователи.
        Set-DComPermission -Do:$Act -AppID '{316CDED5-E4AE-4B15-9113-7055D84DCC97}' -TypePermission 'AccessPermission' -SIDs 'S-1-5-10','S-1-5-18','S-1-5-19','S-1-5-32-544','S-1-5-32-545' `
            -AceType 'AccessAllowed' -Permissions 'LocalAccess'
    }
    elseif (( $Groups -like "$Group-Default" ) -and ( [System.Environment]::OSVersion.Version.Build -eq 17763 ))
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-DComPermission -AppID '{15c20b67-12e7-4bb6-92bb-7aff07997402}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-32-545' -AceType 'AccessAllowed' -Remove
        Set-DComPermission -AppID '{4839DDB7-58C2-48F5-8283-E1D1807D0D7D}' -TypePermission 'LaunchPermission' -SIDs 'S-1-5-19' -AceType 'AccessAllowed' -Remove

        Set-Reg Remove-ItemProperty -Path 'Registry::HKCR\AppID\{316CDED5-E4AE-4B15-9113-7055D84DCC97}' -Name 'LaunchPermission'
        Set-Reg Remove-ItemProperty -Path 'Registry::HKCR\AppID\{316CDED5-E4AE-4B15-9113-7055D84DCC97}' -Name 'AccessPermission'
    }



    $Info = 'Включить ASLR для всех программ | Address Space Layout Randomization (Защита от эксплойтов)'
    $Group = 'Spec-ASLR' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name 'MoveImages' -Type DWord 4294967295
        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -Name 'MitigationOptions' -Type Binary '00010100000000000000000000000000'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" -Name 'MoveImages'
        Set-Reg Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\kernel" -Name 'MitigationOptions'
    }



    $Info = 'Убрать всплывающее меню при смене языка ввода (по умолчанию Alt + Shift) (1903)'
    $Group = 'Spec-PopupSwitchLang' ; $L = $Lang.$Group
    
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 ) # От версии 1903
        {
            $OrigFile = "$env:SystemDrive\Windows\system32\InputSwitch.dll"
            $BackFile = "$OrigFile`_back"
            $OrigFileItem = Get-Item -Path $OrigFile -Force -ErrorAction SilentlyContinue

            Function Patch-InputSwitch {
    
                [CmdletBinding()]
                Param ()

                Token-Impersonate -Token TI

                [int] $Err = 0 
                [int] $N   = 0
                
                do
                {
                    if ($N) { $BackFile = "$BackFile$N" }
                    $N++
                }
                until ( -not [System.IO.File]::Exists($BackFile) )

                try
                {
                    $text = if ( $L.s3 ) { $L.s3 } else { 'Переименование' }
                    Write-Host "   $text`: $OrigFile -> $BackFile" -ForegroundColor DarkGray
                
                    Rename-Item -Path $OrigFile -NewName $BackFile -Force -ErrorAction Stop
                }
                catch
                {
                    $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                    Write-Host "   $text" -ForegroundColor Yellow
                    $Err = 1
                    $NeedFix = $true
                }

                if ( -not $Err )
                {
                    try
                    {
                        $text = if ( $L.s4 ) { $L.s4 } else { 'Cоздание файла' }

                        Write-Host "   $text`: $OrigFile" -ForegroundColor DarkGray
                        # Затирание нужных байтов и создание пропатченого файла
                        $Offset = @(($StringBytes -replace "$BytesGroups.*",'').split(',')).Count - 1
                        @($Offset..($Offset+($NumberGroups-1))).ForEach({$FileBytes.Set($_,144)})
                        [System.IO.File]::WriteAllBytes($OrigFile, $FileBytes)
                        
                        $text = if ( $L.s5 ) { $L.s5 } else { 'Файл пропатчен' }
                        Write-Host "   $text" -ForegroundColor Green -NoNewline

                        $text = if ( $L.s20 ) { $L.s20 } else { 'Нужен перезапуск проводника' }
                        Write-Host ": $text" -ForegroundColor DarkGray
                    }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                        Write-Host "`n   $text" -ForegroundColor Yellow

                        try
                        {
                            $text = if ( $L.s3 ) { $L.s3 } else { 'Переименование' }
                            Write-Host "   $text`: $BackFile -> $OrigFile" -ForegroundColor DarkGray
                            Rename-Item -Path $BackFile -NewName $OrigFile -Force -ErrorAction Stop
                        }
                        catch
                        {
                            $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                            Write-Host "   $text" -ForegroundColor Yellow
                        }

                        $NeedFix = $true
                    }

                    Token-Impersonate -Reset

                    Get-ChildItem -File -Path "$OrigFile`_*" -ErrorAction SilentlyContinue | ForEach-Object {
                        
                        $DeleteFile = $_.FullName
                        
                        $text = if ( $L.s6 ) { $L.s6 } else { 'Отложенное удаление' }
                        Write-Host "   $text`: $DeleteFile" -ForegroundColor DarkGray
                        
                        Set-Delayed-MoveDeletion -Targets $DeleteFile
                    }
                }

                Token-Impersonate -Reset
            }

            if ( $OrigFileItem )
            {
                if ( [System.Environment]::Is64BitOperatingSystem ) { $NumberGroups = 33 } else { $NumberGroups = 24 }

                if ( $OrigFileItem.LinkType -eq 'HardLink' )
                {
                    $text = if ( $L.s7 ) { $L.s7 } else { 'Файл оригинальный' }
                    Write-Host "   $text`: $OrigFile (HardLink)" -ForegroundColor DarkGray

                    $text = if ( $L.s8 ) { $L.s8 } else { 'Проверка файла' }
                    Write-Host "   $text`: " -NoNewline

                    $FileBytes   = [System.IO.File]::ReadAllBytes($OrigFile)
                    $StringBytes = [string]::join(',',$FileBytes)

                    if ( $StringBytes -match ",255,131,248,255,(?<Bytes>(\d{1,3},){$NumberGroups})51,192,(72|139)," )
                    {
                        $BytesGroups = $Matches.Bytes

                        if ( $BytesGroups -match "^(144,){$NumberGroups}$" )
                        {
                            $text = if ( $L.s9 ) { $L.s9 } else { 'Файл уже пропатчен' }
                            Write-Host "$text" -ForegroundColor Green 
                        }
                        else
                        {
                            if ( $BytesGroups -like '116,*,0,0,' )
                            {
                                if ( $Act -eq 'Set' )
                                {
                                    $text = if ( $L.s10 ) { $L.s10 } else { 'Можно пропатчить' }
                                    Write-Host "$text" -ForegroundColor Cyan
                    
                                    Patch-InputSwitch
                                }
                                else
                                {
                                    $text = if ( $L.s11 ) { $L.s11 } else { 'Файл не пропатчен' }
                                    Write-Host "$text" -ForegroundColor Yellow

                                    $NeedFix = $true
                                }
                            }
                            else
                            {
                                $text = if ( $L.s12 ) { $L.s12 } else { 'Байты не найдены' }
                                Write-Host "$text." -ForegroundColor DarkGray
                            }
                        }
                    }
                    else
                    {
                        $text = if ( $L.s12 ) { $L.s12 } else { 'Байты не найдены' }
                        Write-Host "$text" -ForegroundColor DarkYellow
                    }
                }
                else
                {
                    $text = if ( $L.s13 ) { $L.s13 } else { 'Файл не оригинальный' }
                    Write-Host "   $text`: $OrigFile (Not HardLink)" -ForegroundColor DarkGray
                    
                    $text = if ( $L.s8 ) { $L.s8 } else { 'Проверка файла' }
                    Write-Host "   $text`: " -NoNewline

                    $FileBytes   = [System.IO.File]::ReadAllBytes($OrigFile)
                    $StringBytes = [string]::join(',',$FileBytes)

                    if ( $StringBytes -match ",255,131,248,255,(?<Bytes>(\d{1,3},){$NumberGroups})51,192,(72|139)," )
                    {
                        $BytesGroups = $Matches.Bytes

                        if ( $BytesGroups -match "^(144,){$NumberGroups}$" )
                        {
                            $text = if ( $L.s9 ) { $L.s9 } else { 'Файл уже пропатчен' }
                            Write-Host "$text" -ForegroundColor Green 
                        }
                        else
                        {
                            if ( $BytesGroups -like '116,*,0,0,' )
                            {
                                if ( $Act -eq 'Set' )
                                {
                                    $text = if ( $L.s10 ) { $L.s10 } else { 'Можно пропатчить' }
                                    Write-Host "$text" -ForegroundColor Cyan
                    
                                    Patch-InputSwitch
                                }
                                else
                                {
                                    $text = if ( $L.s11 ) { $L.s11 } else { 'Файл не пропатчен' }
                                    Write-Host "$text" -ForegroundColor Yellow

                                    $NeedFix = $true
                                }
                            }
                            else
                            {
                                $text = if ( $L.s12 ) { $L.s12 } else { 'Байты не найдены' }
                                Write-Host "$text." -ForegroundColor DarkGray
                            }
                        }
                    }
                    else
                    {
                        $text = if ( $L.s12 ) { $L.s12 } else { 'Байты не найдены' }
                        Write-Host "$text" -ForegroundColor DarkGray
                    }
                }
            }
            else
            {
                $text = if ( $L.s14 ) { $L.s14 } else { 'Файл InputSwitch.dll не найден' }
                Write-Host "   $text" -ForegroundColor DarkYellow
            }
        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 18362 ) # От версии 1903
        {
            $OrigFile = "$env:SystemDrive\Windows\system32\InputSwitch.dll"
            $BackFile = "$OrigFile`_back"
            $OrigFileItem = Get-Item -Path $OrigFile -Force -ErrorAction SilentlyContinue

            if ( $OrigFileItem.LinkType -eq 'HardLink' )
            {
                $text = if ( $L.s7 ) { $L.s7 } else { 'Файл оригинальный' }
                Write-Host "   $text`: " -ForegroundColor Green -NoNewline
                Write-Host "$OrigFile (HardLink)"
            }
            else
            {
                $text = if ( $L.s15 ) { $L.s15 } else { 'Восстановление' }
                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                Write-Host "$OrigFile (HardLink)"

                if ( [System.Environment]::Is64BitOperatingSystem )
                {
                    $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\amd64_microsoft-windows-inputswitch_*" -ErrorAction SilentlyContinue
                              ).Foreach({Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -eq 'inputswitch.dll'},'Last')
                }
                else
                {
                    $Target = (Get-ChildItem -Path "$env:SystemDrive\Windows\WinSxS\x86_microsoft-windows-inputswitch_*" -ErrorAction SilentlyContinue
                              ).Foreach({Get-ChildItem -File -Path $_ -ErrorAction SilentlyContinue }).Where({$_.Name -eq 'inputswitch.dll'},'Last')
                }

                if ( $Target.FullName )
                {
                    Token-Impersonate -Token TI

                    [int] $Err = 0 

                    if ( [System.IO.File]::Exists($OrigFile) )
                    {
                        [int] $N = 0
                
                        do
                        {
                            if ($N) { $BackFile = "$BackFile$N" }
                            $N++
                        }
                        until ( -not [System.IO.File]::Exists($BackFile) )

                        try
                        {
                            $text = if ( $L.s3 ) { $L.s3 } else { 'Переименование' }
                            Write-Host "   $text`: $OrigFile -> $BackFile" -ForegroundColor DarkGray
                
                            Rename-Item -Path $OrigFile -NewName $BackFile -Force -ErrorAction Stop
                        }
                        catch
                        {
                            $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                            Write-Host "   $text" -ForegroundColor Yellow
                            $Err = 1
                            $NeedFix = $true
                        }
                    }

                    if ( -not $Err )
                    {
                        try
                        {
                            Token-Impersonate -Token SYS

                            $text = if ( $L.s16 ) { $L.s16 } else { 'Создание HardLink' }
                            Write-Host "   $text`: $OrigFile" -ForegroundColor DarkGray
                            $text = if ( $L.s17 ) { $L.s17 } else { 'Цель' }
                            Write-Host "   $text`: $($Target.FullName)" -ForegroundColor DarkGray

                            #Token-Privileges -Enable -Privileges 'SeRestorePrivilege'
                            New-Item -ItemType HardLink -Path $OrigFile -Target $Target.FullName -Force -ErrorAction Stop > $null
                            
                            $text = if ( $L.s18 ) { $L.s18 } else { 'HardLink Создан' }
                            Write-Host "   $text" -ForegroundColor Green -NoNewline

                            $text = if ( $L.s20 ) { $L.s20 } else { 'Нужен перезапуск проводника' }
                            Write-Host ": $text" -ForegroundColor DarkGray
                        }
                        catch
                        {
                            $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                            Write-Host "   $text" -ForegroundColor Yellow

                            try
                            {
                                $text = if ( $L.s3 ) { $L.s3 } else { 'Переименование' }
                                Write-Host "   $text`: $BackFile -> $OrigFile" -ForegroundColor DarkGray
                                Rename-Item -Path $BackFile -NewName $OrigFile -Force -ErrorAction Stop
                            }
                            catch
                            {
                                $text = if ( $L.s2 ) { $L.s2 } else { 'Ошибка' }
                                Write-Host "   $text" -ForegroundColor Yellow
                            }

                            $NeedFix = $true
                        }
       
                        Token-Impersonate -Reset

                        Get-ChildItem -File -Path "$OrigFile`_*" -ErrorAction SilentlyContinue | ForEach-Object {
                        
                            $DeleteFile = $_.FullName
                            
                            $text = if ( $L.s6 ) { $L.s6 } else { 'Отложенное удаление' }
                            Write-Host "   $text`: $DeleteFile" -ForegroundColor DarkGray
                        
                            Set-Delayed-MoveDeletion -Targets $DeleteFile
                        }
                    }

                    Token-Impersonate -Reset
                }
                else
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { 'Файл InputSwitch.dll не найден в хранилище WinSxS' }
                    Write-Host "   $text" -ForegroundColor Yellow
                }
            }

        }
        else
        {
            $text = if ( $L.s0 ) { $L.s0 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Включить вход в загрузочное меню по клавише F8, с последней удачной конфигурацией'
    $Group = 'Spec-BootMenuF8' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Сохранять резервные копии разделов: ControlSet001, ControlSet002, ControlSet003 и т.д.
        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager\LastKnownGood" -Name 'Enabled' -Type DWord 1

        # BackupCount - Количество резервных копий разделов (если = 2, то ControlSet001 и ControlSet002) 
        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager" -Name 'BackupCount' -Type DWord 2

        if ( $Act -eq 'Set' )
        {
            try
            {
                Write-Host "`n   bcdedit.exe /set ""{default}"" BootMenuPolicy Legacy" -ForegroundColor DarkGray
                
                & bcdedit.exe /set "{default}" BootMenuPolicy Legacy > $null
                
                if ( -not $? )
                {
                    Write-Host "   bcdedit: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "Error" -ForegroundColor Yellow
                }
            }
            catch {}
        }
        else { Write-Host }

        try { $bootmenu = @(& bcdedit.exe /enum "{default}").Where({$_ -like "bootmenupolicy*"}) -replace 'bootmenupolicy\s+','' } catch { $bootmenu = $null }
            
        if ( $bootmenu -eq 'Legacy' )
        {
            Write-Host "   bootmenupolicy: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$bootmenu" -ForegroundColor Green
        }
        else
        {
            Write-Host "   bootmenupolicy: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$bootmenu" -ForegroundColor Yellow
                
            $NeedFix = $true
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager" -Name 'BackupCount'
        Set-Reg Remove-Item -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Configuration Manager\LastKnownGood"

        try
        {
            Write-Host "`n   bcdedit.exe /set ""{default}"" BootMenuPolicy Standard" -ForegroundColor DarkGray
            
            & bcdedit.exe /set "{default}" BootMenuPolicy Standard > $null
            
            if ( -not $? )
            {
                Write-Host "   bcdedit: " -ForegroundColor DarkGray -NoNewline
                Write-Host "Error" -ForegroundColor Yellow
            }
        }
        catch {}
        
        try { $bootmenu = @(& bcdedit.exe /enum "{default}").Where({$_ -like "bootmenupolicy*"}) -replace 'bootmenupolicy\s+','' } catch { $bootmenu = $null }
            
        if ( $bootmenu -eq 'Standard' )
        {
            Write-Host "   bootmenupolicy: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$bootmenu" -ForegroundColor Green
        }
        else
        {
            Write-Host "   bootmenupolicy: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$bootmenu" -ForegroundColor Yellow
                
            $NeedFix = $true
        }
    }



    $Info = 'Включить использование последней установленной версии .NET Framework для всех приложений'
    $Group = 'Spec-UseLatestNETFw' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\.NETFramework" -Name 'OnlyUseLatestCLR' -Type DWord 1

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework" -Name 'OnlyUseLatestCLR' -Type DWord 1
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\.NETFramework" -Name 'OnlyUseLatestCLR'
        Set-Reg Remove-ItemProperty -Path "HKLM:\SOFTWARE\Wow6432Node\Microsoft\.NETFramework" -Name 'OnlyUseLatestCLR'
    }



    $Info = 'Отключить Диагностические службы и логи'
    $Group = 'Spec-Diagnostics' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'dps' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'WdiServiceHost' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'WdiSystemHost' -StartupType Disabled
        Set-Svc -Do:$Act Set-Service -Name 'diagsvc' -StartupType Disabled

        Write-Host

        # часть WdiContextLog, PerfDiag Logger, BootLogger
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Diagnostics\Performance' -Name 'DisableDiagnosticTracing' -Type DWord 1

        Write-Host
        
        # Diagnostics-Performance
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnostics-Performance/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{cfc18ec0-96b1-4eba-961b-622caee05b0a}' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog\{cfc18ec0-96b1-4eba-961b-622caee05b0a}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnostics-Performance*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host

        # Diagnostics-Networking
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnostics-Networking/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{36C23E18-0E66-11D9-BBEB-505054503030}' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{36C23E18-0E66-11D9-BBEB-505054503030}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnostics-Networking*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host

        # Diagnosis-Scheduled
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scheduled/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{40ab57c2-1c53-4df9-9324-ff7cf898a02c}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnosis-Scheduled*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host

        # Diagnosis-DPS
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-DPS/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{6bba3851-2c7e-4dea-8f54-31e5afd029e3}' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog\{6bba3851-2c7e-4dea-8f54-31e5afd029e3}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnosis-DPS*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host

        # Diagnosis-PCW
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-PCW/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{aabf8b86-7936-4fa2-acb0-63127f879dbf}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnosis-PCW*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host
        
        # Diagnosis-PLA
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-PLA/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{E4D53F84-7DE3-11D8-9435-505054503030}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnosis-PLA*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
        
        Write-Host
        
        # Diagnosis-Scripted
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scripted/Admin' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scripted/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{E1DD7E52-621D-44E3-A1AD-0370C2B25946}' -Name 'Enabled' -Type DWord 0
        
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-ScriptedDiagnosticsProvider/Operational' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{9363CCD9-D429-4452-9ADB-2501E704B810}' -Name 'Enabled' -Type DWord 0

        $N = 0
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagnosis-Scripted*' } | ForEach-Object {
                
                if ( -not $N ) { Write-Host }
                $N++
                $log = $_.FullName
                
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                    try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                    catch
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { 'Отложенное удаление' }
                        Write-Host " | $text" -ForegroundColor Gray

                        Set-Delayed-MoveDeletion -Targets $log
                    }
                }
                else
                {
                    Write-Host "     Del: $log" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        # system32\WDI
        if ( $Act -ne 'Check' )
        {
            $N = 0
            Get-ChildItem -LiteralPath "$env:SystemDrive\Windows\system32\WDI\LogFiles","$env:SystemDrive\Windows\system32\WDI" -Force -ErrorAction SilentlyContinue |
                ForEach-Object {
                
                    if ( -not $N ) { Write-Host }
                    $N++
                    $log = $_.FullName

                    Write-Host "     Del: $log" -ForegroundColor DarkGray
                    
                    Remove-Item -LiteralPath "\\?\$log" -Recurse -Force -ErrorAction SilentlyContinue
                }
        }

    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'dps' -StartupType Automatic
        Set-Svc Set-Service -Name 'WdiServiceHost' -StartupType Manual
        Set-Svc Set-Service -Name 'WdiSystemHost' -StartupType Manual
        Set-Svc Set-Service -Name 'diagsvc' -StartupType Manual
        
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog' -Name 'Start' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WdiContextLog' -Name 'Start' -Type DWord 1
 
		Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Diagnostics\Performance' -Name 'DisableDiagnosticTracing' -Type DWord 0
      
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnostics-Performance/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{cfc18ec0-96b1-4eba-961b-622caee05b0a}' -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog\{cfc18ec0-96b1-4eba-961b-622caee05b0a}'

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scheduled/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{40ab57c2-1c53-4df9-9324-ff7cf898a02c}' -Name 'Enabled' -Type DWord 1
    
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-DPS/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-System\{6bba3851-2c7e-4dea-8f54-31e5afd029e3}' -Name 'Enabled' -Type DWord 1
        Set-Reg Remove-Item -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DiagLog\{6bba3851-2c7e-4dea-8f54-31e5afd029e3}'
    
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-PCW/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{aabf8b86-7936-4fa2-acb0-63127f879dbf}' -Name 'Enabled' -Type DWord 1

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-PLA/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{E4D53F84-7DE3-11D8-9435-505054503030}' -Name 'Enabled' -Type DWord 1
   
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scripted/Admin' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-Scripted/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{E1DD7E52-621D-44E3-A1AD-0370C2B25946}' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Diagnosis-ScriptedDiagnosticsProvider/Operational' -Name 'Enabled' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\EventLog-Application\{9363CCD9-D429-4452-9ADB-2501E704B810}' -Name 'Enabled' -Type DWord 1
    }



    $Info = 'Отключить Автоматические рекомендованные способы устранения неполадок (онлайн)'
    $Group = 'Spec-WindowsMitigation' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # 1 = Не запускать (дефолт на LTSC/LTSC21) (Только критические неисправности на 1909 Pro)
        # 2 = Ask me before running troubleshooters (дефолт на 1909 и выше включая W11) (значит при этом тоже лезет в сеть)
        # 3 = Run troubleshooters automatically, then notify me
        # 4 = Run troubleshooters automatically, don't notify me

        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\WindowsMitigation" -Name 'UserPreference' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\WindowsMitigation" -Name 'UserPreference'
    }



    $Info = 'Отключить помощника по совместимости программ'
    $Group = 'Spec-AppCompat' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'PcaSvc' -StartupType Disabled
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\PcaPatchDbTask'

        Set-LGP -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name 'DisablePCA' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path "HKCU:\Software\Policies\Microsoft\Windows\AppCompat" -Name 'DisablePCA' -Type DWord 1
        
        # Отключение обработчика совместимости приложений, увеличивает производительность, но не будут исправляться известные ошибки совместимости старых программ.
        Set-LGP -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name 'DisableEngine' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Возврат настроек по умолчанию
        $Info | Show-Info -Shift $L.s1 -Action Default

        try { [int] $Delayed = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\PcaSvc','DelayedAutostart',$null) }
        catch { [int] $Delayed = $null }

        if ( $Delayed )
        {
            Set-Svc Set-Service -Name 'PcaSvc' -StartupType DelayedAuto
        }
        else
        {
            Set-Svc Set-Service -Name 'PcaSvc' -StartupType Manual
        }
        
        # ее включает служба PcaSvc (Служба помощника по совместимости программ)
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\PcaPatchDbTask'

        Set-LGP Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name 'DisablePCA'
        Set-LGP Remove-ItemProperty -Path "HKCU:\Software\Policies\Microsoft\Windows\AppCompat" -Name 'DisablePCA'

        Set-LGP Remove-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat" -Name 'DisableEngine'
    }



    $Info = 'Восстановить формат txt файлов и настройки Notepad.exe (W11)'
    $Group = 'Spec-NotepadTxtFileRestor' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile' -Name '' -Type String 'Text Document'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile' -Name 'EditFlags' -Type DWord 2162688
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile' -Name 'FriendlyTypeName' -Type ExpandString '@%SystemRoot%\system32\notepad.exe,-469'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile\DefaultIcon' -Name '' -Type ExpandString '%SystemRoot%\system32\imageres.dll,-102'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile\shell\open\command' -Name '' -Type ExpandString '%SystemRoot%\system32\NOTEPAD.EXE %1'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile\shell\print\command' -Name '' -Type ExpandString '%SystemRoot%\system32\NOTEPAD.EXE /p %1'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\txtfile\shell\printto\command' -Name '' -Type ExpandString '%SystemRoot%\system32\notepad.exe /pt "%1" "%2" "%3" "%4"'
        
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.txt' -Name '' -Type String 'txtfile'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.txt\ShellNew' -Name 'ItemName' -Type ExpandString '@%SystemRoot%\system32\notepad.exe,-470'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.txt\ShellNew' -Name 'NullFile' -Type String ''
        
            Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Applications\notepad.exe' -Name 'NoOpenWith'
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Notepad' -Name 'ShowStoreBanner' -Type DWord 0
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )  # Только для W11
        {
            Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\txtfile'
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\.txt' -Name '' -Type String 'txtfilelegacy'
            Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Classes\.txt\ShellNew'
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\Applications\notepad.exe' -Name 'NoOpenWith' -Type String ''
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Notepad' -Name 'ShowStoreBanner'
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Не требуется" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }



    $Info = 'Удалить полностью и отключить OneDrive x64/x86'
    $Group = 'Spec-OneDrive-Remove' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Manage-OneDrive -Remove -Act $Act

        # ГП: Комп\Адм.Шабл\Компоненты Windows\OneDrive "Запретить OneDrive создавать сетевой трафик, пока пользователь не войдет в OneDrive" (Включено) Не удаляет параметр при "Не задано", но для Set-LGP не имеет значения с IgnoreWrongPath!
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\OneDrive' -Name 'PreventNetworkTrafficPreUserSignIn' -Type DWord 1 -IgnoreWrongPath
        # ГП: Комп\Адм.Шабл\Компоненты Windows\OneDrive "Запретить использование OneDrive для хранения файлов" (Включено)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' -Name 'DisableFileSyncNGSC' -Type DWord 1

        [string] $OneDriveSetup = ''

        if ( [System.IO.File]::Exists("$env:SystemDrive\Windows\SysWOW64\OneDriveSetup.exe") )
        {
            $OneDriveSetup = "$env:SystemDrive\Windows\SysWOW64\OneDriveSetup.exe"
        }
        elseif ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\OneDriveSetup.exe") )
        {
            $OneDriveSetup = "$env:SystemDrive\Windows\System32\OneDriveSetup.exe"
        }

        if ( $OneDriveSetup )
        {
            'Отключение установки OneDrive при первом входе в новые Аккаунты' | Show-Info -Shift $L.s2 -Action $Act

            # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
            # бэкап проверяется и создается при необходимости
            RegHives-User-LoadUnload -DefaultProfile -Load

            # Только для дефолтного профиля
            if ( -not $Global:LastExitCode )
            {
                $DefAcc = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))

                if ( $DefAcc.SID -and $DefAcc.NTUSER_Load )
                {
                    #$Path = "$Key\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"  # ошибочный параметр 21H1 Dev
                    #Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name 'OneDriveSetup'
                    $Path = "Registry::HKU\$($DefAcc.SID)\Software\Microsoft\Windows\CurrentVersion\Run"
                    Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name 'OneDriveSetup' -OnlyThisPath

                    # Удаление ярлыка из папки профиля при первом входе, который нельзя удалять из дефолтного профиля, из-за привязки к хранилищу компонентов
                    $Path = "Registry::HKU\$($DefAcc.SID)\Software\Microsoft\Windows\CurrentVersion\RunOnce"
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'RemoveOneDriveLnk' -Type ExpandString -Value 'cmd /c del /f /q /a "%UserProfile%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk"' -OnlyThisPath
                }
            }

            # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
            RegHives-User-LoadUnload -DefaultProfile -Unload
        }
    }


    # Только для текущего пользователя
    $Info = 'Установить OneDrive x64/x86, с восстановлением интеграции в Проводник'
    $Group = 'Spec-OneDrive-Install' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\OneDrive' -Name 'PreventNetworkTrafficPreUserSignIn' -IgnoreWrongPath
        Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\OneDrive' -Name 'DisableFileSyncNGSC'

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\OneDrive' -Name 'EnableDownlevelInstallOnBluePlus' -Type DWord 0 -OnlyThisPath
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\OneDrive' -Name 'EnableTHDFFeatures' -Type DWord 1 -OnlyThisPath

        Manage-OneDrive -Install -Act $Act

        [string] $OneDriveSetup = ''

        if ( [System.IO.File]::Exists("$env:SystemDrive\Windows\SysWOW64\OneDriveSetup.exe") )
        {
            $OneDriveSetup = "$env:SystemDrive\Windows\SysWOW64\OneDriveSetup.exe"
        }
        elseif ( [System.IO.File]::Exists("$env:SystemDrive\Windows\System32\OneDriveSetup.exe") )
        {
            $OneDriveSetup = "$env:SystemDrive\Windows\System32\OneDriveSetup.exe"
        }

        if ( $OneDriveSetup )
        {
            'Восстановление установки OneDrive при первом входе в новые Аккаунты' | Show-Info -Shift $L.s2 -Action $Act

            # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
            # бэкап проверяется и создается при необходимости
            RegHives-User-LoadUnload -DefaultProfile -Load

            $DefAcc = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))
            
            $RootAcc = "Registry::HKU\$($DefAcc.SID)"

            if ( $DefAcc.SID -and -not $Global:LastExitCode )
            {
                #$Path = "$Key\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run"
                #Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OneDrive' -Type Binary 0x4,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0
                $Path = "$RootAcc\Software\Microsoft\Windows\CurrentVersion\Run"
                $Value = "$OneDriveSetup /thfirstsetup"
                Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'OneDriveSetup' -Type String $Value -OnlyThisPath

                $Path = "$RootAcc\Software\Microsoft\Windows\CurrentVersion\RunOnce"
                Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name 'RemoveOneDriveLnk' -OnlyThisPath
            }

            # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
            RegHives-User-LoadUnload -DefaultProfile -Unload
        }
    }



    if (( $Groups -like 'Spec-EdgeChrom-Remove' ) -and ( $Groups -like 'Spec-EdgeWebview-Remove' ))
    {
        Manage-Edge -Remove -Act $Act -Componetns Edge,EdgeWebView
    }
    elseif ( $Groups -like 'Spec-EdgeChrom-Remove' )
    {
        Manage-Edge -Remove -Act $Act -Componetns Edge
    }
    elseif ( $Groups -like 'Spec-EdgeWebview-Remove' )
    {
        Manage-Edge -Remove -Act $Act -Componetns EdgeWebView 
    }




    if (( $Groups -like 'Spec-EdgeChrom-Install' ) -and ( $Groups -like 'Spec-EdgeWebview-Install' ))
    {
        Manage-Edge -Install -Act $Act -Componetns Edge,EdgeWebView
    }
    elseif ( $Groups -like 'Spec-EdgeChrom-Install' )
    {
        Manage-Edge -Install -Act $Act -Componetns Edge
    }
    elseif ( $Groups -like 'Spec-EdgeWebview-Install' )
    {
        Manage-Edge -Install -Act $Act -Componetns EdgeWebView
    }



    $Info = 'Отключить и заблокировать Обновление/Установку Edge Chromium (после обновления Windows нужна его очистка)'
    $Group = 'Spec-EdgeAutoUpdate' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\EdgeUpdate' -Name 'DoNotUpdateToEdgeWithChromium' -Type DWord 1

        # https://docs.microsoft.com/ru-ru/deployedge/microsoft-edge-update-policies#updatedefault
        # GET POLICY FILES: https://www.microsoft.com/en-us/edge/business/download
        "Политики для установки и обновленя Edge работают только при подключении к Microsoft® Active Directory® domain:" | Show-Info -Shift $L.s2
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\EdgeUpdate' -Name 'UpdateDefault' -Type DWord 0

        Set-Svc -Do:$Act Set-Service -Name 'edgeupdate' -StartupType Manual -Status Stopped -OrigCmdlet
        Set-Svc -Do:$Act Set-Service -Name 'edgeupdatem' -StartupType Manual -Status Stopped -OrigCmdlet
        Set-Svc -Do:$Act Set-Service -Name 'MicrosoftEdgeElevationService' -StartupType Manual -Status Stopped -OrigCmdlet

        Get-Task-FullPaths -LikeName *MicrosoftEdge* | ForEach-Object {

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $_
        }

        [string] $LockPath = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'

        [array] $FilesForLock = 'MicrosoftEdgeStandaloneInstaller.exe','MicrosoftEdgeUpdate.exe','MicrosoftEdgeUpdateCore.exe',
                                'MicrosoftEdgeUpdateOnDemand.exe','MicrosoftEdgeUpdateSetup.exe','MicrosoftEdgeUpdateBroker.exe',
                                'MicrosoftEdgeUpdateComRegisterShell64.exe','MicrosoftEdgeUpdateComRegisterShell.exe'

        if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
        {
            [string] $Value = $Matches.Debugger.Trim()
        }
        else { [string] $Value = 'dllhost.exe' }

        foreach ( $Name in $FilesForLock | Sort-Object )
        {
            $Path = "$LockPath\$Name"
            Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'Debugger' -Type String $Value
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\EdgeUpdate'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\EdgeUpdate' -Name 'UpdateDefault'

        Set-Svc Set-Service -Name 'edgeupdate' -StartupType DelayedAuto -OrigCmdlet
        Set-Svc Set-Service -Name 'edgeupdatem' -StartupType Manual -OrigCmdlet
        Set-Svc Set-Service -Name 'MicrosoftEdgeElevationService' -StartupType Manual -OrigCmdlet

        Get-Task-FullPaths -LikeName *MicrosoftEdge* | ForEach-Object {

            Set-Tsk Enable-ScheduledTask -TaskName $_
        }

        # Удаление запрета запуска всех Exe файлов установщика или Edge, если есть
        $SubKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
        if ( $OpenSubKey )
        {
            foreach ( $Name in ( $OpenSubKey.GetSubKeyNames() -like '*Edge*' ))
            {
                if ( [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey\$Name",'Debugger',$null) )
                {
                    $Path = "HKLM:\$SubKey\$Name"
                    Set-Reg Remove-ItemProperty -Path $Path -Name 'Debugger'
                }
            }

            $OpenSubkey.Close()
        }
    }



    $Info = 'Отключить Подгрузку Браузера Edge и его вкладок'
    $Group = 'Spec-EdgePreloading' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main' -Name 'AllowPrelaunch' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\TabPreloader' -Name 'AllowTabPreloading' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\Main' -Name 'AllowPrelaunch'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MicrosoftEdge\TabPreloader' -Name 'AllowTabPreloading'
    }



    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$InfoThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { "Необходимо перезагрузиться!" }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}