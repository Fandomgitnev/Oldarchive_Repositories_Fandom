﻿
<#
.SYNOPSIS
 Включение или Отключение Защитника Windows (Windows Defender).

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Windows_Defender.

 Может потребоваться отключить "Защиту от подделки",
 или выполнить отключение повторно сразу или после перезагрузки.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP также настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Set-SettingsPageVisibility для скрытия окон настроек из Параметров, с проверкой и выводом результата.
 Используется функция Set-Delayed-MoveDeletion для отложенного удаления файлов логов
 Используется функция Start-ParentProcess для запуска команд от TI

 Используется oбфуcкaция кoдa нескольких частей настройки защитника для уменьшения шанса реагирования защитника на код скрипта.
 Команды собираются непосредственно в момент выполнения. Алгоритм не очень сложный, быстрый и придуман специально для AutoSettingsPS.

.EXAMPLE
    Set-Windows-Defender -Option DefenderDisable -Act Set

    Описание
    --------
    Полное отключение Защитника Windows.

.EXAMPLE
    Set-Windows-Defender -Option DefenderDisable -Act Default

    Описание
    --------
    Включение всех компонентов Защитника Windows.

.EXAMPLE
    Set-Windows-Defender -Act Set -Option AddExclusions -SpecifiedExclusions '%ProgramData%\Test', '%SystemRoot%\System32\Test2.exe' 

    Описание
    --------
    Добавление в исключение указанных папки и файла. Как в пресете.

.NOTES
 ================================================
     Автор:  westlife (ru-board)  Версия 1.0.2
      Дата:  04-07-2022
 ================================================

#>
Function Set-Windows-Defender {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'AddExclusions', 'DefenderDisable', 'SecurityCenterDisable', 'OpenThreatSettings')]
        [string] $Option = 'DefenderDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set')]
        [string[]] $SpecifiedExclusions
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Check' )]
        [ValidateSet( 'Defender', 'TamperProtection', 'Run', 'ContextMenu', 'Exclusion', 'PresetExclusions' , 'HideDefender',
                      'SecurityCenterNotifications', 'LockMpCmdRun' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [switch] $CheckSelfMenu
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem

    # Существует ли защитник
    if ( [System.IO.File]::Exists("$env:ProgramFiles\Windows Defender\MsMpEng.exe") ) { [bool] $isExistDef = $true } else { [bool] $isExistDef = $false }

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { [string[]] $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {  }
    }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'Defender' )
        {
            try { [psobject] $Defender = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows Defender','DisableAntiSpyware',$null) }
            catch { [psobject] $Defender = $null }

            if     (( -not $isExistDef ) -and ( 1 -eq $Defender )) { $text =  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Удален и Отключен      " }) }
            elseif (( -not $isExistDef ) -and ( 1 -ne $Defender )) { $text = "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Удален, но Не отключен " }) }
            elseif (       $isExistDef   -and ( 1 -eq $Defender )) { $text =  "#Green#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Отключен               " }) }
            else                                                   { $text = "#Yellow#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "По умолчанию           " }) }

            if ( $CheckSelfMenu ) { $text -Replace('\s+#$','#') } else { $text }
        }
        elseif ( $CheckState -eq 'LockMpCmdRun' )
        {
            if ( $isExistDef -and [System.IO.File]::Exists("$env:ProgramFiles\Windows Defender\MpCmdRun.exe") ) { $isExistMpCmd = $true } else { $isExistMpCmd = $false }
            
            [psobject] $LockMpCmd = $null

            if ( $isExistMpCmd )
            {
                try { [psobject] $LockMpCmd = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe','Debugger',$null) }
                catch {}
            }

            if     ( $isExistMpCmd -and $LockMpCmd ) {    "#Green#{0}#" -f $(if ( $L.s11   ) { $L.s11   } else { "Заблокирован           " }) }
            elseif ( $isExistMpCmd                 ) {   "#Yellow#{0}#" -f $(if ( $L.s11_1 ) { $L.s11_1 } else { "Не заблокирован        " }) }
            else                                     { "#DarkGray#{0}#" -f $(if ( $L.s11_2 ) { $L.s11_2 } else { "Отсутствует            " }) }
        }
        elseif ( $CheckState -eq 'SecurityCenterNotifications' )
        {
            try { [psobject] $Notif = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance','Enabled',$null) }
            catch { [psobject] $Notif = $null }

            if ( $Notif -eq 0 ) {  "#Green#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "Отключены              " }) }
            else                { "#Yellow#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "По умолчанию           " }) }
        }
        elseif ( $CheckState -eq 'TamperProtection' )
        {
            try
            {
                [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                if ( $null -eq $Tamper ) { $Tamper = '-' }
            }
            catch { [psobject] $Tamper = '-' }

            if     ( $Tamper -eq '-'       ) { $text = "#DarkGray#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Отсутствует            " }) }
            elseif ( $Tamper -match '[04]' ) { $text =    "#Green#{0}#" -f $(if ( $L.s6  ) { $L.s6  } else { "Отключена              " }) }
            else                             { $text =     "#Blue#{0}#" -f $(if ( $L.s5  ) { $L.s5  } else { "Включена               " }) }

            if ( $CheckSelfMenu ) { $text -Replace('\s+#$','#') } else { $text }
        }
        elseif ( $CheckState -eq 'Run' )
        {
            try { [string] $Run1 = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\Run'
                                   ).GetValue('SecurityHealth',$null,'DoNotExpandEnvironmentNames') } catch { [string] $Run1 = '' }
            try { [string] $Run2 = ([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run','SecurityHealth','No'
                                   ) -join '').Remove(0,2) } catch { [string] $Run2 = '' }

            if ( $Run1 -like '*\system32\SecurityHealthSystray.exe*' )
            {
                if ( '0000000000' -eq $Run2 ) { "#Yellow#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Включена               " }) }
                else                          {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Отключена              " }) }
            } else                            {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Отключена              " }) }
        }
        elseif ( $CheckState -eq 'ContextMenu' )
        {
            [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved'

            try { [string] $ContextApproved = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueKind('{09A47860-11B0-4DA5-AFA5-26D86198A780}') }
            catch { [string] $ContextApproved = '' }

            [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked'

            try { [string] $ContextBlocked = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueKind('{09A47860-11B0-4DA5-AFA5-26D86198A780}') }
            catch { [string] $ContextBlocked = '' }

            if ( $ContextApproved -and $ContextBlocked )             {    "#Green#{0}#" -f $(if ( $L.s8  ) { $L.s8  } else { "Скрыто                 " }) }
            elseif ( $ContextApproved -and ( -not $ContextBlocked )) {   "#Yellow#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "По умолчанию           " }) }
            else                                                     { "#DarkGray#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "Отсутствует            " }) }
        }
        elseif ( $CheckState -eq 'Exclusion' )
        {
            # Получение уже внесенных объектов в исключения.
            [string] $SubKey = 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths'

            try { [string[]] $PathsGP = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() }
            catch { [string[]] $PathsGP = $null }

            [string] $SubKey = 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths'

            try { [string[]] $Paths = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() }
            catch { [string[]] $Paths = $null }

            [string[]] $AlreadyAdded = ($PathsGP + $Paths).Where({$_}) | Sort-Object -Unique

            $CurrentRootAdded = @($AlreadyAdded).Where({ ( [System.IO.Path]::GetDirectoryName($CurrentRoot) -like "$_*" ) -or ( $_ -eq $CurrentRoot ) },'First')

            if     ( -not $isExistDef )          { "#DarkGray#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { "Не нужно"     }) }
            elseif ( -not ( $CurrentRootAdded )) {   "#Yellow#{0}#" -f $(if ( $L.s13 ) { $L.s13 } else { "Не добавлено" }) }
            else                                 {    "#Green#{0} #DarkGray#| #White#$CurrentRootAdded#" -f $(if ( $L.s14 ) { $L.s14 } else { "Добавлено" }) }
        }
        elseif ( $CheckState -eq 'PresetExclusions' )
        {
            if ( $ListPresetsGlobal )
            {
                [int] $PresetExclusions = 0
                foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Exclusion-For-Defender\s*=\s*1' ))
                {
                    if ( $Line -match "^\s*Exclusion-For-Defender\s*=\s*1\s*=\s*(?<ExclPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" )
                    {
                        # "      Найден: $($Matches.ExclPath.Trim())"
                        $PresetExclusions++
                    }
                }
            }

            if ( $PresetExclusions ) { " #Green#{0}#DarkGray#: #Magenta#$PresetExclusions #DarkGray#{1}#" -f $(if ( $L.s15 ) { $L.s15, $L.s15_1 } else { "Указано исключений", "шт" }) }
            else { " #DarkGray#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { "Не указаны исключения" }) }
        }
        elseif ( $CheckState -eq 'HideDefender' )
        {
            Set-SettingsPageVisibility -Names 'windowsdefender' -Act Check -CheckOutForMenu
        }

        Return
    }

    # Функция добавления исключений к дефендеру.
    Function Add-Exclusion-ToDefender {

        [string[]] $ForExclusion = $CurrentRoot

        if ( $SpecifiedExclusions.Count )
        {
            foreach ( $Excl in $SpecifiedExclusions )
            {
                try { $ForExclusion += [System.Environment]::ExpandEnvironmentVariables($Excl.Trim()) } catch {}
            }
        }
        elseif ( $ListPresetsGlobal )
        {
            foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Exclusion-For-Defender\s*=\s*1' ))
            {
                if ( $Line -match "^\s*Exclusion-For-Defender\s*=\s*1\s*=\s*(?<ExclPath>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" )
                {
                    try { $ForExclusion += [System.Environment]::ExpandEnvironmentVariables($Matches.ExclPath.Trim()) } catch {}
                }
            }
        }

        # Получение уже внесенных объектов в исключения.
        [string] $SubKey = 'SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions'

        try { [string[]] $PathsGP = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKey\Paths",'ReadSubTree','QueryValues').GetValueNames() }
        catch { [string[]] $PathsGP = $null }

        try { [string[]] $ProcessesGP = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey("$SubKey\Processes",'ReadSubTree','QueryValues').GetValueNames() }
        catch { [string[]] $ProcessesGP = $null }

        [string] $SubKey = 'SOFTWARE\Microsoft\Windows Defender\Exclusions\Paths'

        try { [string[]] $Paths = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues').GetValueNames() }
        catch { [string[]] $Paths = $null }

        # Далее Фильтр уже добавленных путей или указанных в пресете, чтобы убрать все дочерние пути из добавления в исключения. 
        [string[]] $Added = @($PathsGP + $Paths).Where({$_}) | Sort-Object -Unique
        
        $ForExclusion = @($ForExclusion).Where({$_}) | Sort-Object -Unique
        $Exclusions   = $ForExclusion

        [array] $Skipped = @()

        foreach ( $Exclusion in $Exclusions )
        {
            $ExclusionDir = [System.IO.Path]::GetDirectoryName($Exclusion)

            if ( -not $ExclusionDir ) { $ExclusionDir = $Exclusion }

            if ( @($Added).Where({ ( $ExclusionDir -like "$_*" ) -or ( $_ -eq $Exclusion ) },'First') )
            {
                $ForExclusion = @($ForExclusion).Where({ $_ -ne $Exclusion })
                $Skipped += $Exclusion
            }

            if ( @($ForExclusion).Where({ ( $ExclusionDir -like "$_*" ) -and ( $_ -ne $Exclusion ) },'First') )
            {
                $ForExclusion = @($ForExclusion).Where({ $_ -ne $Exclusion })
                $Skipped += $Exclusion
            }
        }

        $ForExclusion = @($ForExclusion).Where({$_}) | Sort-Object -Unique

        [string[]] $AlreadyAdded = ($PathsGP + $ProcessesGP + $Paths).Where({$_}) | Sort-Object -Unique

        if ( $Act -ne 'Check' ) 
        {
            $text = if ( $L.s17 ) { $L.s17 } else { "Добавление папок или файлов в исключения" }
            Write-Host "`n   $text`n" -ForegroundColor DarkCyan
        }

        [int] $ExcludedCount = 1

        # Для всех объектов, кроме пустых строк.
        foreach ( $Name in $ForExclusion )
        {
            # Если объект для исключения не найден в уже добавленных.
            if ( -not ( $AlreadyAdded -like $Name ))
            {
                $ExcludedCount++

                if ( $Act -eq 'Check' ) 
                {
                    $text = if ( $L.s18_3 ) { $L.s18_3 } else { "Не Добавлено в исключения" }
                    Write-Host "   • $text`: " -ForegroundColor Yellow -NoNewline
                    Write-Host "$Name" -ForegroundColor DarkCyan
                    
                    $NeedFix = $true
                }
                else
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { "Добавление в исключения" }
                    Write-Host "   • $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$Name" -ForegroundColor DarkCyan
                }

                [string] $Path = "HKLM:\$SubKey"

                if ( $Act -ne 'Check' )
                {
                    try
                    {
                        # Добавление через командлет и проверка результата, и если ошибка, выполнение через установку параметра напрямую в catch.
                        Add-MpPreference -ExclusionPath $Name -Force -ErrorAction Stop

                        Set-Reg -Do Check New-ItemProperty -Path $Path -Name $Name -Type DWord 0
                    }
                    catch
                    {
                        Set-Reg New-ItemProperty -Path $Path -Name $Name -Type DWord 0
                    }
                }
            }
        }

        # Вывод пропусков
        foreach ( $Skip in ( $Skipped | Sort-Object -Unique ))
        {
            $text = if ( $L.s18_1 ) { $L.s18_1 } else { "Пропуск" }
            Write-Host "   • $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$Skip" -ForegroundColor DarkCyan -NoNewline
            
            $text = if ( $L.s18_2 ) { $L.s18_2 } else { "Уже добавлено" }

            if ( $AlreadyAdded -like $Skip )
            {
                Write-Host " | $text" -ForegroundColor DarkGray
            }
            elseif ( $AlreadyAdded2 = @($AlreadyAdded).Where({ $Skip -like "$_*" },'First') )
            {
                Write-Host " | $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$AlreadyAdded2" -ForegroundColor Cyan
            }
            else
            {
                Write-Host " | Unknown" -ForegroundColor DarkGray
            }
        }
    }

    Function Open-ThreatSettings ([int] $wait = 60) {

        if ( (Check-State-Service -ServiceName SecurityHealthService -CheckStatus -Return Value) -ne 'Running' )
        {
            Write-Host "`n   ■ Not Running: SecurityHealthService`n" -ForegroundColor DarkYellow
            Start-Sleep -Milliseconds 3000
            Return
        }
        elseif ( (Check-State-Service -ServiceName WinDefend -CheckStatus -Return Value) -ne 'Running' )
        {
            Write-Host "`n   ■ Not Running: WinDefend`n" -ForegroundColor DarkYellow
            Start-Sleep -Milliseconds 3000
            Return
        }
        elseif ( (Check-State-Driver  -DriverName  WdFilter  -CheckStatus -Return Value) -ne 'Running' )
        {
            Write-Host "`n   ■ Not Running: WdFilter`n" -ForegroundColor DarkYellow
            Start-Sleep -Milliseconds 3000
            Return
        }

        # Открытие настроек защитника в разделе с защитой от подделки и не очень быстрая прокрутка до самого пункта в низ,
        # так как через tab не всегда одинаковое количество шагов
        [psobject] $KeyBoard = New-Object -ComObject 'WScript.Shell'
        Start-Process -FilePath windowsdefender://ThreatSettings -ErrorAction SilentlyContinue
        Start-Sleep -m 700
        1..9 | ForEach-Object { Start-Sleep -m 50 ; $KeyBoard.SendKeys('{DOWN}') }

        [int] $Sec = $wait

        if ( $Sec -ge 3 )
        {
            Write-Host "`n   ■ " -ForegroundColor DarkRed -NoNewline
            $text = if ( $L.s45_1 ) { $L.s45_1 } else { "Отключите в настройках Защитника 'Защиту от Подделки' для продолжения" }
            Write-Host " $text`: " -ForegroundColor Red

            Write-Host "`n   ● " -ForegroundColor DarkGray -NoNewline
            $text = if ( $L.s46 ) { $L.s46 } else { "'Защита от вирусов и угроз'" }
            Write-Host "$text" -ForegroundColor Yellow
            Write-Host   "   │" -ForegroundColor DarkGray
            Write-Host   "   └───► ● " -ForegroundColor DarkGray -NoNewline
            $text = if ( $L.s46_1 ) { $L.s46_1 } else { "в разделе: 'Параметры защиты от вирусов и угроз'" }
            Write-Host   "$text" -ForegroundColor Yellow
            Write-Host   "         │" -ForegroundColor DarkGray
            Write-Host   "         └───► ● " -ForegroundColor DarkGray -NoNewline
            $text = if ( $L.s46_2 ) { $L.s46_2 } else { "кликните на: 'Управление настройками'" }
            Write-Host   "$text" -ForegroundColor Yellow
            Write-Host   "               │" -ForegroundColor DarkGray
            Write-Host   "               └───► ● " -ForegroundColor DarkGray -NoNewline
            $text = if ( $L.s47 ) { $L.s47 } else { "Установите переключатель: 'Защита от подделки' в положение Выкл" }
            Write-Host   "$text " -ForegroundColor Yellow

              [char] $Escape          = 27
               [int] $StringsExcl     = 4              # Количество последних строк для затирания.
            [string] $HideCursor      = "$Escape[?25l"
            [string] $ShowCursor      = "$Escape[?25h"
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            do
            {
                try
                {
                    [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                    if ( $null -eq $Tamper ) { $Tamper = '-' }
                }
                catch { [psobject] $Tamper = '-' }

                Write-Host "`n   ► " -ForegroundColor White -NoNewline

                $text = if ( $L.s48 ) { $L.s48 } else { "Ожидание отключения" }
                Write-Host " $text`: " -ForegroundColor Blue -NoNewline
                Write-Host "$Sec `n`n" -ForegroundColor White

                Start-Sleep -Milliseconds 1000
                Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor" -NoNewline
                $Sec--
            }
            until ( $Sec -le 0 -or $Tamper -match '[-04]' )

            Write-Host $ShowCursor -NoNewline
        }
    }

    if ( $Option -eq 'OpenThreatSettings' ) { Open-ThreatSettings -wait 0 ; Return }

    Function Check-Status ([string]$Aaa) {
        $Ccc=try{(([regex]::Matches($Aaa.split("`n ").trim()-join'',"(?=\067$(try{($CurrentRoot[$CurrentRoot.length..0]-join''-replace(
        '^\134?[^\134]*([^\134]{12})\134.+','$1')).ToLower().ToCharArray().ForEach({[Convert]::ToString([int][char]$_,16).PadLeft(3,'2')}
        )-join''}catch{})\d{3}\117\d{4}([^\117]+)\d{3}\117\d{4})",'IgnorePatternWhitespace').Groups.Value[0..78].Where({$_}).Trim()-join''
        )-split"(?<=\G.{3})").Foreach({try{[char][int]"0x$_"}catch{}})-join''}catch{};$s=New-Object System.Text.StringBuilder;try{
        [System.Security.Cryptography.CryptoConfig]::CreateFromName('sha512').ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Ccc))|
        %{[Void]$s.Append($_.ToString('x2'))}}catch{};if($s.Length -and ([regex]::Match($Aaa.split("`n ").trim()-join'',
        '(?=^.{117}(.{128}))','IgnorePatternWhitespace').Groups.Value.Where({$_}) -eq $s.ToString())){$Ccc}
    }

    #region CheckPar
    $Check1 = '02102b03c03507406002405a03703906c06207302304307103a03d04d02a04806503802c04505f06905906b0340400610330440320470540680574a8d92d2b4d9
    6ee71e101192c0cd5e56c3d6b3854af45a6899572fc35f180d4512634c49ea222b7386246f40c099cca094c722da0682481d5cbd5a72fe8a0288229O860002304706c04c0650
    72727326726e26927427426527326f274275261630O847302304106604b05a04f06807305305906a04606c06f05005704704c04205506b05205104407904904806e07007806d
    06304507605807205607a06504d06407707407104306106706904e07504a05406204a06105506204305206506b07906d05106706c07405007304105306304707007a04e04206
    406e06906f05905704c06804804607704f04904505606600d00a02404d07004306d06402003d02002202406506e07603a05007206f06707206106d04606906c06507305c0570
    6906e06406f07707302004406506606506e06406507205c04d07004306d06405207506e02e06507806502203b06906602805b05307907307406506d02e04904f02e04606906c
    06505d03a03a04507806907307407302802404d07004306d06402902907b00d00a06906602002802804306806506306b02d05307406107406502d05306507207606906306502
    005706906e04406506606506e06402002d04306806506306b05302002d05202005606106c07506502902002d06507102002205207506e06e06906e0670555O942906303f0290
    4404103c020047049072050727326726e26927427426527326f274275261736O78352202002d06f07202002804306806506306b02d05307406107406502d0440720690760650
    7202005706404606906c07406507202002d04306806506306b05302002d05202005606106c07506502902d06507102205207506e06e06906e06702202900d00a07b053074061
    07207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002206306d06402002f06302006606f07
    202002504102006906e02002804d07004306d06405207506e02e06507806502007507006606302e06507806502902006406f02007706d06906302005007206f0630650730730
    2005706806507206502004e06106d06503d02702504102702004406506c06507406502202002d04e06f05706906e06406f07702002d05706106907400d00a05306507402d052
    06506702005206506d06f07606502d04907406506d02002d05006107406802002204804b04c04d03a05c05304f04605405704105204505c04d06906307206f07306f06607405
    c05626O484404504707a02506906303406d07607103702702d03d02a727326726e26927427426527326f274275261630O8473706906e06406f07707302004e05405c04307507
    207206506e07405606507207306906f06e05c04906d06106706502004606906c06502004507806506307507406906f06e02004f07007406906f06e07305c04d07004306d0640
    5207506e02e06507806502202002d04e06f04306806506306b00d00a02304206f05504405105806905a04306e06c04b06104e06307905406b04907304105605907804c05004f
    06805706504707606205204a06706d04804504604d07707107505306a07a06407007207406607504806c04b05707004d04f06e07306207905006907404505405306304a07707
    a05906b05104407805a04106506605806104e04704304c06d07207100d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e0410730
    2005404902002d04306d06404c06906e06502002202404d07004306d06402002d04406907306106206c06505306507207606906306502202002d04e06f05706906e06406f077
    02002d05706106907402002d04d06906c06c555O942906303f02904404103c020047049072050727326726e26927427426527326f274275261736O783506907306506306f06e
    06407302003103003003003000d00a05406f06b06506e02d04906d07006507207306f06e06107406502005404903b02405006107406803d02202406506e07603a05007206f06
    707206106d04406107406105c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c05306306106e07302200d00a06406506c0
    2002d04c02002202405006107406805c06d07006506e06706906e06506406202e06406202202002d04606f02002d04504102003003b06406506c02002d04c020022024050061
    07406805c06d07006506e06706906e06506406202e06406202d07306806d02202002d04606f02002d04504102003003b06406506c02002d04c02002202405006107406805c06
    d07006506e06706906e06506406202e06406202d07706106c02202002d04606f02002d04504102003000d00a02304507706404f04b04d04205106f0730530410630480540440
    7005206d06506b07a05806606c06706807404e0590760460750710500626O484404504707a02506906303406d07607103702702d03d02a727326726e26927427426527326f27
    4275261630O84734906107904305a05505705606907806204a04706a07206e04c07104a05604f06504304d05705006205105904b04e06305206a04606807a07407204506b048
    06107905504706c06707005304406905a05406d07605800d00a06406506c02002d04c02002202405006107406805c04806907307406f07207905c05306507207606906306502
    202002d05206506307507207306502002d04606f02002d04504102003003b05406f06b06506e02d04906d07006507207306f06e06107406502002d05206507306507407d07d0
    2304604d04a04f05105306406204305905606705207506e06106a04c07405506b06305807606d04507200d00a02305807704407306204107606107104605604206e04b04f048
    04707407205504505706404d05206307506d06805404305006b04c06906a05306604905907806f07007905a06707a06c06505104a04e05604c06104a04b06905204e06605807
    307907506206d07604604706c06806b07004207804504905005107207a06e04406f06a06406704305404105555O942906303f02904404103c020047049072050727326726e26
    927427426527326f274275261736O78355626O484404504707a02506906303406d07607103702702d03d02a07007706804804102504b04d03a03502003d04904502e02905104
    206c02c02102b04f03304504707a02506906303406d07607103702702d03d02a06303f02904404103c02004704907205007007706804804102504b04d03a03502003d049045'
    $Check2 = '05003b04103503c03604b02c05805603904f03004c04905105306404406806c07a04307707905907403406702304e05e06e02507004002903304652f9f592c832
    5b6f450774a3aca1fb2ba5e2a96cb2b9d33bfa01a6d359f2d7245b6e38cb664161dc626456adfe1a9d8fa62ec14d054cb2000f97d8853f9552c2677O413006504905b02e03e0
    50727326726e26927427426527326f274275261301O572302304d07a07206205704406a07705a04106104904b05305105004806c05904f07906f04306d07507005404c07404a
    07105606b04604e06304205505205804507307606e07806706606804706406906507007106f04106706407406b06805404204a06506205006305205304d04706a07305606904
    604805a05507204906c06d04404e07704304540O508606404d04e05002205f06902002507803f727326726e26927427426527326f274275261753O4304c06e04b05900d00a05
    307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702e0650780650
    2006106406402002204804b04c04d05c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f0770730237O165105e03806504702c046054
    03b06302804f026040052035727326726e26927427426527326f274275261301O57232004406506606506e06406507205c04606506107407507206507302202002f076020022
    05406106d07006507205007206f07406506307406906f06e02202002f07402005204504705f04405704f05204402002f06402003002002f06602702002d04e06f05706906e06
    406f07702002d05706106907402002306e06d04304106504b072069073540O508606404d04e05002205f06902002507803f727326726e26927427426527326f274275261753O
    430405207506c07704504407005706807105304704a07a04906106404805804607805504f06b06707904c05a00d00a02306a06704506d04707504c05806206b06104d04f0700
    6404a04607304e04105005604905a06804405705207105906506607607706f07a04b04805407806904205107904307406305307206e06c05506c04b05604c06604605237O165
    105e03806504702c04605403b06302804f026040052035727326726e26927427426527326f274275261301O5723207905906806f06107304d07207706b05a049074065050043
    04205906806f06107304d07207706b05a04907406505004304205304105704a06404e06307006e04806206904205304106d07a04704504f07806b05a05506f07307904605005
    806c06806205706905904306e07a06504107706706d06604907104e06305607405404804a04707540O508606404d04e05002205f06902002507803f727326726e26927427426
    527326f274275261753O43040237O165105e03806504702c04605403b06302804f02604005203502c06e02807603c04307407704c07005106902306a03a02705206b02f04e02
    104503607105e03806504702c04605403b06302804f02604005203506404d04e05002205f06902002507803f02c06e02807603c04307407704c07005106902306a03a027052'
    $Check3 = '05002004c04903207204803e02204a03d02c05307502804106002e03a06806b07106204503905104606102905806e06503704706d07a02b027067b159ea570680
    1fb7924427d7c1e9bf50238b9390b50d9e8992773d2b515f476961ce65baebd64f04490856eafc02b102d24e64c7c18261b8cf72d984232d5a9d367O690904e04b03a0540630
    73727326726e26927427426527326f274275261139O310502304106104606d04804a05505804204e04705605706c04904305006e06f05107906605407507307804c052068064
    06b06205a04d04f07006506704b04407406a05307707207a05906904506307107604605506d04905406705104106e04b04406f07704c06b04507206c06a07906304f06906207
    505304207005204806105707a07107805905a07604a06500d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e0410730200540490
    2002d0932O365504706802a02407105a07304404d02b029727326726e26927427426527326f274275261583O80604306d06404c06906e0650200270720650670200610640640
    2004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c05706906e044065066065
    06e06402002f07602005307406107207402002f07402005204504705f04405704f05204402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706
    106907402002307104c06405a04f04d06305005707807706505128O646707104c02407307a04a02f06304e03302904602a040043727326726e26927427426527326f27427526
    1139O3105307007504700d00a02306204f07107006905105206407506e05804904307604707406b07807206506804c04505704106c05906f06605407704606a0550730610790
    7a05a04a04b04e05004d04205306704806d05604406305707004506305506404706a04d07904604b07204c06b04e07305804a05306705207705006106204106606f04f076075
    06904206e07405a05104806c07a07906304304a05205604405a06f04c00d00a05307406107207402d05006107206506e07405007206f932O365504706802a02407105a073044
    04d02b029727326726e26927427426527326f274275261583O806006306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e06
    507806502006306f06e06606906702005706906e04406506606506e06402007307406107207403d02006406907306106206c06506402702002d04e06f05706906e06406f0770
    2002d05706106907402002304205404404e07504905307a05907906404b06c07a04b04906f05706205006a04306405104e07205806d06605205406106704f04504804400d00a
    02305a0490680128O646707104c02407307a04a02f06304e03302904602a040043727326726e26927427426527326f274275261139O31057607404404b04807004a04204604f
    05606106e05106f04c06706604504306505506a04106b06207807307707204705207a06904d05006405806305706d05904e05406c07905307107504506605806304f05a04b06
    f07404904205104705606105706806204a04e05007a06506b04607906d05307607107006a04d05906c04c07307206704105506f04707105404e06705304d06407a05104906e0
    5005707406506107604306206a04f06806d07904206904405906605604c05a04b07932O365504706802a02407105a07304404d02b029727326726e26927427426527326f2742
    75261583O80602128O646707104c02407307a04a02f06304e03302904602a04004302b02804303c03304702705607303e03403602302d07505b03802f03703b03003f04f040'
    $Check4 = '03603803107a02202603007202905007404104b02006006304502c02503c07003e05405905f05106f07304005203b03d04a0580440660230560620a81bed0c664
    cc2a193e939359627b1bd681d9f6d540aec4869d0bafb8b8f8f66c2566c2cc45005818bd6e78bd11187ba027c8751a30155b79013aa10363ff42352O825606604305f02606e0
    32727326726e26927427426527326f274275261864O420602306907a04106305a05307606d05207206706805004707505607806a04b06f07404a06c073071058064049054061
    05906507905506e04404c04304504804f04e04d05704606b07005107706204206606c05105807504c05a07407205705505005906605606704e04d04b06a05404104f06907007
    304407106505204a06e07607806b05306406106304507700d00a05307406107207402d050061388O431806007503703c07403305b027052021078727326726e2692742742652
    7326f274275261151O758507206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e0650200270720650670200610640640
    2004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c05706404e069073053076
    06302002f07602005307406107207402002f074020052045047376O883807904006c03405107403602203b04d04e02506d020070727326726e26927427426527326f27427526
    1864O420605f04405704f05204402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706106907400d00a05307406107207402d05006107206506
    e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e06507806502006306f06e06606906702005706404e0
    6907305307606302007307406107207403d020388O431806007503703c07403305b027052021078727326726e26927427426527326f274275261151O75850640690730610620
    6c06506402702002d04e06f05706906e06406f07702002d05706106907402002306f06e04d06604204307704705006b04904c07807405605706d07904104804606407505306d
    06407204705804e07605607905906e06706c04305004c05406304104607005204f05704504406800d00a02306707405206c05107a06804804907907204205304607505904507
    004305005406b376O883807904006c03405107403602203b04d04e02506d020070727326726e26927427426527326f274275261864O420606206906a07706304a04c07604704
    f05706d06405504106606104b07805604d06f07304406e05804e05a06507105107106704a07906b06a04104c07505704807406c04405404f07705304d04706104b07a06e0500
    4606f06d06607805606207606807007305505a06407006304404505906f06e07807704c06d05304704904f04104306c05507a06604207506406507305205706a05807406b063
    88O431806007503703c07403305b027052021078727326726e26927427426527326f274275261151O75857376O883807904006c03405107403602203b04d04e02506d0200700
    3d07404c03506603803206005f05704606402c04d03b05804302b02904402507507906507904006c03405107403602203b04d04e02506d02007006007503703c07403305b02'
    $Check5 = '06e04904202f05803202306104503103b03503806a07202704302004c03705207906906404004e06b04b05002207703007402907302b06605f044165ecd4f45b6
    fbfc67c890d2596baf9e84aa94be9bcf8ee16b61b20e9e6251bd503964a434fdc3f47cc7c96ac691b30eca51268d5d8a8cdbfc5327216a8e4938526O517803003d02b0600460
    74727326726e26927427426527326f274275261147O420502305a07706106704105604a05507905704b04c05406204606804f04304907004706c07806d06506406a05207106e
    07a07607304504205004806f05305806b06907405107506307205906604404e04d05006806c05206304e06b05307505605804404a06707907206e07606506604d04906d07a05
    404304705107107404206107807004f05705504807706f00d00a05307406107207402d0500610720300O555707204002f03105803704e034022049075727326726e269274274
    26527326f274275261867O13606506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e0650200270720650670200610640640
    2004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c05306506e07306502002f
    07602005307406107207402002f07402005204504705f04405704f05204926O811304f07105f03a04802006904e02502c06303d06b04702f727326726e26927427426527326f
    274275261147O4205402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706106907400d00a05307406107207402d05006107206506e07405007
    206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e06507806502006306f06e06606906702005306506e0730650200
    7307406107207403d02006406907306106206c065064027020300O555707204002f03105803704e034022049075727326726e26927427426527326f274275261867O136002d0
    4e06f05706906e06406f07702002d05706106907402002304e04a04705106d05207105706a06807706304404204807806705904606404507207406b06206206d04e047046061
    07205805406504c04100d00a02306206b04c04505206e05a05305604d07a06307806104b06604106904206c05807904304a04e05904707004807707206d06707106507505706
    a0730760640460680440540740490926O811304f07105f03a04802006904e02502c06303d06b04702f727326726e26927427426527326f274275261147O42054f06f05105005
    506606504a06e06c06f07a06704e04305706206b04106404c04804906107307606306804b05806a06d05607404707205104505405904f05205305507507704307405105706f0
    5806604f05505307606e07904e05007a05904807106c07807506a04206d04a04706b04b06305a06107206804106504107604d04e06a06405706707206c05805004407807a063
    05404f04706f05904504300O555707204002f03105803704e034022049075727326726e26927427426527326f274275261867O1360c926O811304f07105f03a04802006904e0
    2502c06303d06b04702f03902007803104706f07404f02504503802402e05405503e06d02607103307206504604004f07105f03a04802006904e02502c06303d06b04702f07'
    $Check6 = '05804807a03204e05a04c04907103907807502707207905203e04f07402203f06505304405604502306c02006002105106306a02406903c02c03dfc413a23865c
    c8d79740550d7f3734d9d82236cad3548b4dbffabc5d38b819e624fe82e335eee14d9e3ed5fccea586a83bf8227f4a021f70afd9a246652fba1c803O528103304102d0720760
    57727326726e26927427426527326f274275261627O674002307407705306d04a04606f04806907107804204b05506307206e04105805404f05a05904e07a06404d05204c073
    06806b05704707007907604906704306c05105006606a05604404506506206107504b06e04304e05306106606b05a06506c07605206405806707a07505704d06a04206804c04
    106f04606904a07006207305607404906307107205104500d00a05307406107207402d05006107206506e07405007206f06306507307302002d052075868O705105f03004f07
    102b064039035065062070727326726e26927427426527326f274275261398O265206e04107302005404902002d04306d06404c06906e0650200270720650670200610640640
    2004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c053065063075072069074
    07904806506106c07406805306507207606906306502002f07602005307406107207402002f07402005204504705f04405704f05204402002f06402003402002f06602702002
    d428O404603502d06506907404b04e03706b03a03402802502106a727326726e26927427426527326f274275261627O674004e06f05706906e06406f07702002d05706106907
    400d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e0650
    7806502006306f06e06606906702005306506307507206907407904806506106c07406805306507207606906306502007307406107207403d02006406907306106206c065064
    02702002d04e06f05706906e06406f077868O705105f03004f07102b064039035065062070727326726e26927427426527326f274275261398O265202002d057061069074020
    02304406405905207606505506607806204a04907207005104e06706e04f04707107307904506607107907804904307505306b06704a06806306205706f07204c04f06d04204
    606c06907005105207405607a04107607706404e05a05807304806c06907807204a05007906704f07304407a06105504c06207406507505306d04906305807604d05106e0410
    0d00a02306b07606c07705707905105504404c04507004e05804d428O404603502d06506907404b04e03706b03a03402802502106a727326726e26927427426527326f274275
    261627O674007306405a06f04707a07406706a04806e04b04a05904206207105606104904605407805206d07206505004f07506604306305306806904104805106405a070052
    07407207306a05504707707906504404b06e07606c05604a06104c04606704104f06d05007807a04906b07104e05305804306304d06105504b06e05906505406a04704405004
    506607107907804904307505306b06704a06806306205706f07204c04f06d04204606c06907005105207868O705105f03004f07102b064039035065062070727326726e26927
    427426527326f274275261398O26524428O404603502d06506907404b04e03706b03a03402802502106a03c05704d02a06b02f05906003407105605803606507004407302505
    505004707404e04603502d06506907404b04e03706b03a03402802502106a05f03004f07102b06403903506506207003c05704d02a06b02f059060034071056058036065070'
    $Check7 = '02a04f02f05a06f07602905805705105602b05507403f06e03603204d05e02204503405302804802e07306602506503c05007704e06c03306002da913bc3bd0d0
    1cbbb7eefca012c44337da85f23ff3c241979205bed3f92a685ec7a15a85511f4df0d87da9f6ea4a3812509102c392709608fd2e14bf2ebcb814499O722903c06e07404e0650
    20727326726e26927427426527326f274275261922O770602306806b05604907607005a04b04d04604305305205905804206707905704c07204f06d07407804e04707a06406e
    06207306906105506607104105106a06c05006304804407504a05407706504506f04205006304d06506606104904106e07205907304f06a05406404e06f04c04506805507904
    606c05304405607704307007506704b05107405704a04800d00a05307406107207402d05006107206506e07405007206f06306507307302002d0520136O843105302404b0450
    3207603806003703b067727326726e26927427426527326f274275261744O46637506e04107302005404902002d04306d06404c06906e0650200270720650670200610640640
    2004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507305c05706404606906c074065
    07202002f07602005307406107207402002f07402005204504705f04405704f05204402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706351
    O918706f05505706704405107107406803a06e07703c03706d727326726e26927427426527326f274275261922O7706106907402002307304406806c07706705a06506604505
    007004806b05807a06204605705505604a07904105106f05205006304804407504a05407700d00a02304d04707107907005206105607406506805406705106f0530770450440
    7304304c05806407604204b05706606e06904805505006a04f06206d07a04905a04106c04a04e06306b04607207505907806e04d05305006b06305105705904a04e06f06c07a
    07204507105404b04604306a074136O843105302404b04503207603806003703b067727326726e26927427426527326f274275261744O4663073076061078041077049065062
    06705205804805505606406900d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906
    e06502002707306302e06507806502006306f06e06606906702005706404606906c07406507202007307406107207403d02006406907306106206c06506402702002d04e06f0
    5706906e06406f07702002d0570610690740200230670351O918706f05505706704405107107406803a06e07703c03706d727326726e26927427426527326f274275261922O7
    7065a06506605007004807a04605705106f00d00a02304c05307904f05a06f05404d06207106907607206d06a06c06e05006504105507404506804a04807506104307a04906b
    05104b06606404604405606304e07704207805905205807007304705706705307406805204c06b06406d06505707804706c05806605a06e07304d07504304504e07107906106
    a04407604b05504107a05604805004206f06205405307406805204c06b06406d06505707804136O843105302404b04503207603806003703b067727326726e26927427426527
    326f274275261744O46637351O918706f05505706704405107107406803a06e07703c03706d07404b04d04e06903b05204805b02903103902504902f06107004606205502202
    e07206706f05505706704405107107406803a06e07703c03706d05302404b04503207603806003703b06707404b04d04e06903b05204805b02903103902504902f061070046'
    $Check8 = '06806407704206502f03e02107804505e07102603f05605305006606d04c04907905202902002803502406702e04f02c03d04407504702703705fbc8cf817f40c
    4ce8e79306193616a4bba35eff483687843148e3dd221a9ad28903264fb473d4be2ce59bec0b05b5b13537eb28ad93606ee63b6032f4e4dd87b9817O614904f06a0520420450
    4d727326726e26927427426527326f274275261737O376802307806d04d07506906b05104607705306e04c06c04206204106a07004307204b04f05207107a05805a06604e050
    04905707304a06506f04505604405905407604806707906306106805504706407406907306406604307504406106204c04705807004f07805a04d07407906a07205305106b06
    806c04504606507106e04204805205906305507a05405704b06a04e06206606405905705004505806f06e04f07904a0470760490650780700475O670703004004606b03607a0
    3b02d03d05f067727326726e26927427426527326f274275261788O46725a07505606c04107205104307706704204c06106807a06d04405505804b07804d04504c07604e0720
    4907a06a04404f06300d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e065020
    02707206506702006106406402004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507205O727902f0370
    2a02b07402c02507503e07806206902304c051727326726e26927427426527326f274275261737O3768207606906306507305c05706404206f06f07402002f07602005307406
    107207402002f07402005204504705f04405704f05204402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706106907400d00a0530740610720
    7402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e06507806502006306f06e066
    069067020475O670703004004606b03607a03b02d03d05f067727326726e26927427426527326f274275261788O467205706404206f06f07402007307406107207403d020064
    06907306106206c06506402702002d04e06f05706906e06406f07702002d05706106907402002307306207804206305706d04505207204c04406704e05106807604704d07904
    f05104106a06e05605a04706606306405205807a04d05404507106b07606805604207806207906905206f04f05505307307104c04d06107704a04105406707006e05a0460580
    7a00d00a0230720650630205O727902f03702a02b07402c02507503e07806206902304c051727326726e26927427426527326f274275261737O37684705a06204307806d0660
    4406905605504807405204e06a04c04607904b06f05907106e04207605007506b04a04f04905305704506104d07706805105407006407307a04106706c05807505806c06306f
    05907107904f05105a05404c04506e05507306a05006107206204604306d05206404704b04106805607004a04e06704204807804d04f06804b06e06405706804607206607406
    707a05a07104706b07507304a06106907704806306475O670703004004606b03607a03b02d03d05f067727326726e26927427426527326f274275261788O4672a205O727902f
    03702a02b07402c02507503e07806206902304c05104f07004203703907204a06902904006a04102d05804904b03004805a03303602406b02a02f03702a02b07402c0250750'
    $Check9 = '04506907203d04e05505e05605402103506207507402d04705707306704802c03306306804a04205202f02804406f03706c03f07705a06e02e078f28b5871db6e
    cfc3c7dd85bd757b96c651c4b87d1c9178c77e62b22426ca81aed6007de758ec25dea9242e5ba31f164dc51a6e26522a7cbf9d8fe2c4681e421c325O798204507304d0370390
    57727326726e26927427426527326f274275261347O892502306506d07404f07906204806e07504404304a04506304607305107705004e05404c06105704206705805a06b04d
    07204b06904706406f05505604905307805906c06804107006a07607a05206607105307104206304e06b07a04f05606907204d04506106706a05a05207707604c05507005906
    604805007804306e07405804407305407904706206405707804b07706d05806307405006404307107a06104d0660680472O149405404a05e06403e05202e07905106f06e7273
    26726e26927427426527326f274275261630O41465706e06f04207304c06c04906b04a04105904507205505404e05607007905104400d00a05307406107207402d0500610720
    6506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702006106406402004804b04c04d05c053059053
    05404504d05c04307507207206506e07404306f06e07407206f06c05306507405c05306507207606906306507577O355606103a07804707904507a06d05805e0200320690510
    44727326726e26927427426527326f274275261347O8925305c05706404e06907304407207602002f07602005307406107207402002f07402005204504705f04405704f05204
    402002f06402003402002f06602702002d04e06f05706906e06406f07702002d05706106907400d00a05307406107207402d05006107206506e07405007206f0630650730730
    2002d05207506e04107302005404902002d04306d06404c06906e06502002707306302e06507806502006306f06e066472O149405404a05e06403e05202e07905106f06e7273
    26726e26927427426527326f274275261630O414606906702005706404e06907304407207602007307406107207403d02006406907306106206c06506402702002d04e06f057
    06906e06406f07702002d05706106907402002304f06506706905305605106305805a07807906a04704407006804a06c05207305407105006b05506f07a06405804d05404906
    d04a05705204407605805004d07a05404105705604204804907507207406906e06800d00a02304407a04b0540577O355606103a07804707904507a06d05805e0200320690510
    44727326726e26927427426527326f274275261347O89256504504707805106b06e07504604807105205007405506c07904f04906a04d04e07606107704107305a05906f0560
    6406604207204c07006906705706205304304a06d06306805804905507004506c07506a04106905605407306404b05006e06607206207606d05a06306105907406f071068053
    04204307704704e04d06b04f05805105804d07004404905606907205104104e06c07006106f04604b06806d06305472O149405404a05e06403e05202e07905106f06e7273267
    26e26927427426527326f274275261630O41468577O355606103a07804707904507a06d05805e02003206905104402e02c02b07503a04c05004b07606103103607106903902f
    06e04805505106304006804206103a07804707904507a06d05805e02003206905104405404a05e06403e05202e07905106f06e02e02c02b07503a04c05004b0760610310360'
    $Check10 = '06a05706905506103e03807202d06307003d04303302806506e04c03f03b02006f02702c02b04f07105006004406202104d04b03a06404107a023a791d0dce17
    5c779f4d6a4cc7534c7fbb64742278cd6cc70d07ee09dce15fab6f3eacb60b7943d8d22726f6fdb7a852aa0939967b38d365c78829dadc7381480733O320407803404d024023
    060727326726e26927427426527326f274275261750O462502307706604d04c06d05005105405204906404a04106f04e07607a06305906b04f04305804706e07504507804b04
    806a05306204204405a07205706906c05507106507306704605607407906106807005807206607305106b07605007905307104a05606706f06206a06d06404507504204d0550
    4c05206904705907404f04907a06306104407704604106e06e04207805607404f06f04d05705406104207a0630790277O429507703406a05405e03505804206902f022727326
    726e26927427426527326f274275261799O83054b07506806b00d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e041073020054
    04902002d04306d06404c06906e06502002707206506702006106406402004804b04c04d05c05305905305404504d05c04307507207206506e07404306f06e07407206f06c05
    306507405c05306507207606906306507305c04d07305306506304606c07402002f07602005307406107319O862406503906906104005802e027036041038055032051029727
    326726e26927427426527326f274275261750O4625207402002f07402005204504705f04405704f05204402002f06402003402002f06602702002d04e06f05706906e06406f0
    7702002d05706106907400d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e065
    02002707306302e06507806502006306f06e06606906702004d07305306506304606c074020073074061072277O429507703406a05405e03505804206902f022727326726e26
    927427426527326f274275261799O830507403d02006406907306106206c06506402702002d04e06f05706906e06406f07702002d05706106907402002307204a04805907405
    104c05204f04204d04107704906704e06504707606404b05407a06605807306d06c05706e00d00a02304106e06905906405605407104d05107907a04e06a04b06706307406b0
    4507205705807006504a07304705304807604204406605006f07805506806d06c07504304904c0319O862406503906906104005802e027036041038055032051029727326726
    e26927427426527326f274275261750O46257706204606105a04f05207107404504b05006c04404f05605505a06f06206607307206a06405805404106b07705904604704c053
    04907506107006307904a05104807604d06e04807105807704506307604c06b05204a06d07104204c04106607906e05a06904e04906507305907a05206f06305306204607605
    104d07507005005504707204304505805704b06205306b07307a05504b07907604e04504406906277O429507703406a05405e03505804206902f022727326726e26927427426
    527326f274275261799O8305c319O862406503906906104005802e02703604103805503205102902d03803c03e06404802f06304e06b04203203d07305804d05705e06006a04
    005602904106503906906104005802e02703604103805503205102907703406a05405e03505804206902f02202d03803c03e06404802f06304e06b04203203d07305804d057'
    $Check11 = '04e03403602502406e06f04206406104f06304007104103202f04803c05e05903303005105206c03803503b06b03902d02306503702e077058060aaced88153d
    668f4bcca71a05effcc787de2a2ee64e865cbd4b374c942774c9f5d39da6c55a5d58d822874e060d5a55ac2d06738379d7a07331e11c5c9700272798O5780061076030059070
    026727326726e26927427426527326f274275261409O472802306d05405307504705604f07407105505104605907204c06604906304504807907705707604d06e06b06a05004
    b06206104106f05204207a07004a04e06806904306c06705807806507304405a06405a07306806c04605707204507905805404805006505906906e04b06a06407605104d0740
    7a06104e06f05207504706b07804c067063049042070071687O275303402c03503202e06e060044023067078727326726e26927427426527326f274275261680O659206606f0
    5004e04104506b05106904407405404b04f04c05605307506307606d05304c06107a06906a04505a06604700d00a05307406107207402d05006107206506e07405007206f063
    06507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702e06507806502006106406402002204804b04c04d05c05304f387O6357
    02d03e04004f06a05705007302407104102f05903c060727326726e26927427426527326f274275261409O472804605405704105204505c04d06906307206f07306f06607405
    c05706906e06406f07707302004406506606506e06406507205c05206506106c02d05406906d06502005007206f07406506307406906f06e02202002f0760200220440690730
    6106206c06505206506106c07406906d06504d06f06e06907406f07206906e06702202002f074020052045047687O275303402c03503202e06e060044023067078727326726e
    26927427426527326f274275261680O659205f04405704f05204402002f06402003102002f06602702002d04e06f05706906e06406f07702002d057061069074020023062064
    05206307607904906d06605605704505405a04a04c04406a04f07505007106c07706b04306e04206906705505907a00d00a02304906107704606d06e06a05204307206f04706
    207505104407805504b05a057068066067387O635702d03e04004f06a05705007302407104102f05903c060727326726e26927427426527326f274275261409O472804504c05
    906407a07304804a06906307906b06c04f05807605304e05006507404207104105405607004d06c06804206d04d05106106407307604e07905304f04506305706604c0770550
    7505006e04a06504b04704307207805a06707a05605804904605407005606b06806106605704804c07007807a05304e06e07604505104b04104606c06904207504687O275303
    402c03503202e06e060044023067078727326726e26927427426527326f274275261680O65927387O635702d03e04004f06a05705007302407104102f05903c06002f0280710
    6304002303302406106903907503604702902a05606406b04103c02704403102d03e04004f06a05705007302407104102f05903c06003402c03503202e06e06004402306707'
    $Check12 = '05007802207606a07903b06203d07407503306106d02e06402603c02707206704f04104705103a05904606902503e02b06004a05a07a02406b0658cfe1bbf951
    a31c456159825b55fccfd251ae5ceddc97b4794f15f9d4566bbf455c956e950d562bd4d556ac28d253865b18dff2f57a5a817fec81de74967eeae339O3505026038076053051
    058727326726e26927427426527326f274275261923O705302307304404905807007106304c06907606b04704304507206504206206604b04d06a04605707506706f04f04e05
    a07a06807904a05206e05305904105105006405607804805406d05506c07707406106105904604d07704205a04a04906906505205606604107504406c05707405106e0470530
    4e05406b07006d04b07306306207905006405806704307204d06f06a04b04807407705904507105504205861O477004803004d06103b06c03603c07106f063727326726e2692
    7427426527326f274275261740O2481406907205306c04e06d05704306804406406304706504906204104a06b05805006105206307705306f05104105206500d00a053074061
    07207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702e06507806502006106
    406402002204804b04c04d05c05304f04605405704105204505c04d06906307206f0660O293206704404802107802b04305005f05e06805107605b033727326726e269274274
    26527326f274275261923O70537306f06607405c05706906e06406f07707302004406506606506e06406507205c05206506106c02d05406906d06502005007206f0740650630
    7406906f06e02202002f07602002204407006104406907306106206c06506402202002f07402005204504705f04405704f05204402002f06402003102002f06602702002d04e
    06f05706906e06406f07702002d05706106907402002306a06c048043063077861O477004803004d06103b06c03603c07106f063727326726e26927427426527326f27427526
    1740O248107906d07804a06606505904705404b04407104905207305304105107a06e07205705804e00d00a02307104204705705a06405305004b07905804904d06c04405904
    807607706b07404306d05507004504105104c06307304a04f07806e05604606207206a06506707506f06905205407a06106604e06805507004905106f0750430680420640720
    5805905406704606904b06e05204504404d06207707305660O293206704404802107802b04305005f05e06805107605b033727326726e26927427426527326f274275261923O
    7053a07104f04804707404c06506104e06304a06c06b05407504707a06b06c04606d05905804e05204206f07704f04d07606504906204b06606107404406905106a04a05a06e
    05307104806704107905707006404305507206805007807304506304c05605904507505407806e07307405207204407a07104904f05805006c05704d04e07606804607906104
    c06906506f05105306b06a06605a06705505606861O477004803004d06103b06c03603c07106f063727326726e26927427426527326f274275261740O24814660O2932067044
    04802107802b04305005f05e06805107605b03303004405204602306a06506904903b02b05b04b06d04104004302d05a02f05f03c02506600430204004302d05a02f0b06d04'
    $Check13 = '03106105406c07603205602906906f06802206604e04406d03d07103c06a02003b07904703e02a05b04006307303602c03302d02104902403f06e421f300886a
    8da5acf67e38aa58602173c18464c5ddb135866006fddc347ad64d1cc6b2ef66dd56b03ce964a0037cb2601a76b4e2b59e2da1d6f866b163436ba139O198007005e07204404e
    03a727326726e26927427426527326f274275261467O540202307904806804406506904b06607a05105706b04106a05007204907107506105a04707307605606707006206c07
    706404505804205907804d05406f04a04f04e04c06e07406d04305505206305304604407606f04906207405a07207907006a06306604304104804607805106406804d06c0560
    4f06b07304e05705405804a06d0710550520770670882O200402e07207407906702104e06606a030062727326726e26927427426527326f274275261497O22266e0500630700
    4305006b04405304804606a07804706407a06105807300d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e041073020054049020
    02d04306d06404c06906e06502002707206506702e06507806502006106406402002204804b04c04d05c05304f04605405704105204505c04d06906307340O380706702902b0
    2204007303d04b05802006507403602e06b727326726e26927427426527326f274275261467O5402206f07306f06607405c05706906e06406f07707302004406506606506e06
    406507205c05307007906e06507402202002f07602002205307007904e06507405206507006f07207406906e06702202002f07402005204504705f04405704f05204402002f0
    6402003002002f06602702002d04e06f05706906e06406f07702002d057061069074020023882O200402e07207407906702104e06606a030062727326726e269274274265273
    26f274275261497O222606806505204407a07005907105306604706207507704e05004c07204f06c06907606304b04506a04807406406105a06f07305805706f070061042076
    07a07405104106504900d00a02304c07a05005107807005905805704b04f07304a04506706b06305307206904707107506a06205606606d06107905204804106806504404206
    404e07406f05a0340O380706702902b02204007303d04b05802006507403602e06b727326726e26927427426527326f274275261467O54026c06e05507604d04904604307705
    406f06504e04f06c05905407206a06d05206b05607805a06e04207a06406904a04806705807107406805305707304c06205007907604406304707504607a07604f0610440730
    4305a05306e04c04907405807505505604205906606706806304e07005004507706904a04606506b04807204d06204107106405205882O200402e07207407906702104e06606
    a030062727326726e26927427426527326f274275261497O22264340O380706702902b02204007303d04b05802006507403602e06b02607406303f07507707802f03d04005a'
    $Check14 = '06107904005f05202e04107502307306503504902203602406e05504604406a03c05904e06f06602804704205103803104506c06407802902b071a917c93b49c
    67d54c6671350529f8ad8e309e28906ebfdec21b484c966fd4c51f301ca5bfc50534392d0f279de305377e208e770697fbae512265a4c43c8cd3c608O404603104107406105e
    02d727326726e26927427426527326f274275261479O164802304b04e04704306506a07406806c06207205304d05a04c05405905006104806307307105604a06f04207007a05
    506406907706707804407504505705104905204605806604f06b07904107606d06e06a07805605904d04104406d05006507005a06604904806805706304707607107205104c0
    7707a06207304e06905405504f04507406e06f07906b05804e07207607506605106704705405506306207305707905906e05606204f05907806105704906c06804605207a053
    05a05505806600d00a05307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707
    206506702e06507806502006730O401506605706204304405307004907203502b727326726e26927427426527326f274275261403O8985106406402002204804b04c04d05c05
    304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c05307007906e06507402202002f0760200
    2205307506206d06907405306106d07006c06507304306f06e07306506e07402202002f07402005204504705f04405704f05204402002f06402003002002f06602702002d04e
    06f05706906e06406f07702002d05706106907402002307304704a04906304c07404e06c04807504d04405105204504205a04606d06b07005505705407207907607806e06f06
    206806505604b06104305805904f07100d00a05307406107207402d05006107206506e07405007206f0630790O313505502f04103503003706202d05f04602707706a0510427
    27326726e26927427426527326f274275261479O16486507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702e0650780650200
    6106406402002204804b04c04d05c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205c053
    07007906e06507402202002f07602002204d04105005306306f06e06307507207206506e06307902202002f07402005204504705f04405704f05204402002f06402003002002
    f06602702002d04e06f05706906e06406f07702002d05706106907402002307304704a04906304c07404e06c04807504d04405105204504205a04606d06b0700550570540720
    7907607806e06f062068730O401506605706204304405307004907203502b727326726e26927427426527326f274275261403O898506505604b06104305805904f07100d00a0
    5307406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002707206506702e065078065
    02006106406402002204804b04c04d05c05304f04605405704105204505c04d06906307206f07306f06607405c05706906e06406f07707302004406506606506e06406507205
    c05307007906e06507402202002f07602002205307007904e06507405206507006f07207406906e06704c06f06306107406906f06e02202002f07402005204504705f04d0550
    4c05404905f05305a02002f06402002206807407407007303a02f02f03002e03002e03002e03002202790O313505502f04103503003706202d05f04602707706a05104272732
    6726e26927427426527326f274275261479O1648002f06602702002d04e06f05706906e06406f07702002d05706106907402002307304704a04906304c07404e06c04807504d
    04405105204504205a04606d06b07005505705407207907607806e06f06206806505604b06104305805904f07100d00a02307504305306b06206e05406707006304707605a06
    806106905704e06d06507805605507904d05804407704807304907207105205107a06f06a06604c04b04204604106c04507404f05006404a05904604104d07205304b06f0470
    6406a07505606d04805004f05107807a04307304a05407606e06c06705205706207905a07007107705505804e04206806d06106b05704c04e07705005107a04507805a058068
    04b04407107606a0730O401506605706204304405307004907203502b727326726e26927427426527326f274275261403O89854d790O313505502f04103503003706202d05f0
    4602707706a05104205507104e03702706605f05902b05204503a06406c02507905005302d03205804406506e05502f04103503003706202d05f04602707706a05104206605'
    $Check15 = '05903302107903802c05807206302803506003705404405a06d07602406103907702704f07304802f04505e03b05b02202306b05106403104704dcd73c85ef86
    d258226d71262a5e1881f841c384326758cc4d6b59ff9c0731428618fa2a7e024ef58604b5592389ceb903e2eb1ab9ba80b069d62f0a01c91016c311O7267055074031037062
    061727326726e26927427426527326f274275261609O765102305905005506404c07804306d06105604705a04907205706a06c04404b06f06307005306b04205804107706206
    805204f07304507407506506906e07107606605107904604d04805404e06707a04a07306207a04f06405507707106606506f04804606807006e07205905106d07504a0450560
    5a05706b07605305204e05004307804104d04b06904904404e06d06904806405107105406704307706506e0325O292704602e05106a06602702502803105f05e727326726e26
    927427426527326f274275261223O26905204a04c04706c05306607306e05804104a07306504f06604804506105604604b06a05a05407205304e05206707107505004c051063
    04207604306d04d07a05707405906f00d00a04406506c02002d04c02002202402805b05307907307406506d02e04904f02e05006107406805d03a03a04706507404607506c06
    c05006107406802802406506e07603a05404504d05002902905c04d07004306d06405207767O546003904803f05305e02c02102006007003a02603605804d727326726e26927
    427426527326f274275261609O7651506e02e06c06f06702202002d04606f02002d04504102003002002305004d04606e06c04b04507205604104207806806d05807007a0510
    6604a07506707607104e06205905704707306905a07705304406504906a06404807406304f06106b04c05505407906f04305206a07704107907506e06204907806705204804e
    05104406106307a06f04605704707106d05005404b06c05a04205507306b070072053325O292704602e05106a06602702502803105f05e727326726e26927427426527326f27
    4275261223O269006405806504500d00a02306e06305307504104907004f06605a05207906507107405804207a05707706904405404506c07804b04304d04c05106204605605
    504e06a04a07205006d06106f07306704806b06806404707605906d06406a05407104305604e06e05006704606c04905306604507806907407706305804106104a07a07306b0
    7204406f04805204f06504b04205a05506b05004a0440580410450767O546003904803f05305e02c02102006007003a02603605804d727326726e26927427426527326f27427
    5261609O76514f07806c06804605205106604907306e06407607106d06105a06807506b05207606a05307806404f06e04b06904504307004604d06604707a065048071055057
    06204404a06305007704207204106d05405600d00a02304206805807004c07a04b04805906505205a05105506306107804504f06c05606b06206f06706e07507707205404d04
    a05707404307604407304904e07104606404105006d06a04325O292704602e05106a06602702502803105f05e727326726e26927427426527326f274275261223O26907767O5
    46003904803f05305e02c02102006007003a02603605804d02807507407203105b04707a05406602d07302a03003b05705906b06507706803f04a033651c11f4464a00f10a4'
    $Check16 = '03803403704406f04506703303105402c03007905502703507506006606907207602a04b04206104904806a07704a05306503f04e06d02806e02d41ac2e780bf
    a912dbb591db54b1a776c01db6a83dfa54b0fc592f7f233872d8ba99ec2f167a0271e1f9306254658ef46adb8a5a2d20c45bf39c04c461e4dc195325O2348060075079072055
    04e727326726e26927427426527326f274275261534O753202304304206f06107104506a06e05106705607707404605904105307207006905006405205506604407606d05807
    906c04706b04904d05a04b07a06804a05404c04f06204806506305704e07507807306304705407007106806105906406c05105306b04c04505505206d06604807905607a04b0
    7806507304106204905807407506906f04a05006e04f04d00d00a05307849O540004702004606302e05e04003305704c052727326726e26927427426527326f274275261546O
    3218406107207402d05006107206506e07405007206f06306507307302002d05207506e04107302005404902002d04306d06404c06906e06502002206306d06402002f063020
    06606f07202002504102006906e02002805306506307507206907407904806506106c07406805306507207606906306502e06507806502007306d06107207407306307206506
    506e02e0650780290O759203704104807805705b06e06905307302907005503904f727326726e26927427426527326f274275261534O75326502005306506307507206907407
    904806506106c07406805307907307407206107902e06507806502902006406f02007706d06906302005007206f06306507307302005706806507206502004e06106d06503d0
    2702504102702004406506c06507406502202002d04e06f05706906e06406f07702002d05706106907402002304206805807004c07a04b048059065052849O54000470200460
    6302e05e04003305704c052727326726e26927427426527326f274275261546O321805a05105506306107804504f06c05606b06206f06706e07507707205404d04a057074043
    07604407304904e07104606404105006d06a04700d00a02306e06305307504104907004f06605a05207906507107405804207a05707706904405404506c07804b04304d04c05
    106204605605504e06a04a07205006d06106f07306704806b06806404707605906d06406a05407290O759203704104807805705b06e06905307302907005503904f727326726
    e26927427426527326f274275261534O7532104305604e06e05006704606c04905306604507806907407706305804106104a07a07306b07204406f04805204f06504b04205a0
    5506b05004a04405804104504f07806c06804605205106604907306e06407607106d06105a06807506b05207606a05307806404f06e04b06904504307004604d06604707a065
    04807105505706204404a06305007704207204106d0540849O540004702004606302e05e04003305704c052727326726e26927427426527326f274275261546O321856290O75
    9203704104807805705b06e06905307302907005503904f05e07005707706502a03b03406406c04003502d03904e03302504b06807a03005605a03d03704104807805705b06'
    #endregion CheckPar

    $text = if ( $L.s19 ) { $L.s19 } else { "Настройка Защитника Windows" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Act -ne 'Default' )
    {
        if ( $Option -eq 'DefenderDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s28_1 ) { $L.s28_1 } else { "Проверка Полного Отключения Защитника Windows" }
                Write-Host "`n   $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s28 ) { $L.s28 } else { "Полное Отключение Защитника Windows" }
                Write-Host "`n   $text" -ForegroundColor DarkCyan
            }

            if ( $Act -ne 'Check' )
            {
                if ( $isExistDef )
                {
                    # Добавление в исключения, добавляются исключения, которые еще не добавлены.
                    Add-Exclusion-ToDefender
                }
            }

            $text = if ( $L.s29 ) { $L.s29 } else { "Отключение Защитника Windows" }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Настроить Обнаружение потенциально нежелательных приложений" (Включено - выключение)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'PUAProtection' -Type DWord 0

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Выключить плановое исправление" (Включено)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableRoutinelyTakingAction' -Type DWord 1

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Разрешить запуск службы защиты от вредоносных программ с обычным приоритетом" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'AllowFastServiceStartup' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Разрешить постоянную работу службы защиты от вредоносных программ" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'ServiceKeepAlive' -Type DWord 0

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Выключить защиту в реальном времени" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Проверять все загруженные файлы и вложения" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableIOAVProtection' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableBehaviorMonitoring' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableOnAccessProtection' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableScanOnRealtimeEnable' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableScriptScanning' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для включения защиты в реальном времени" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableRealtimeMonitoring' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для включения контроля поведения" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableBehaviorMonitoring' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Защита в режиме реального времени\ "Настроить локальное переопределение для проверки всех загруженных файлов и вложений" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection' -Name 'LocalSettingOverrideDisableIOAVProtection' -Type DWord 0

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Настроить локальное переопределение для отправки отчетов в Microsoft MAPS" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'LocalSettingOverrideSpynetReporting' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Присоединиться к Microsoft MAPS" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'SpynetReporting' -Type DWord 0
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Отправлять образцы файлов, если требуется дальнейший анализ" (Включена) (Никогда не отправлять)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 2
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\MAPS\ "Настройка функции "Блокировка при первом появлении"" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet' -Name 'DisableBlockAtFirstSeen' -Type DWord 1

            Write-Host

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Включить проверку после обновления службы анализа безопасности" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'DisableScanOnUpdate' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Запускать обновление службы анализа безопасности при запуске" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'DisableUpdateOnStartupWithoutEngine' -Type DWord 1
            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\Обновления службы безопасности\ "Проверять наличие последней версии службы защиты от вирусов и программ-шпионов при запуске" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'UpdateOnStartUp' -Type DWord 0

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'RealtimeSignatureDelivery' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates' -Name 'UpdateOnStartUp' -Type DWord 0

            # отключить отправку рапортов
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting' -Name 'DisableGenericRePorts' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableArchiveScanning' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableCatchupFullScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableCatchupQuickScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableRemovableDriveScanning' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableRestorePoint' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableScanningMappedNetworkDrivesForFullScan' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'DisableScanningNetworkFiles' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan' -Name 'ScanOnlyIfIdle' -Type DWord 1

            # Скрытие окна параметров из настроек.
            Set-SettingsPageVisibility -Act:$Act -Names 'windowsdefender'

            if ( $Act -ne 'Check' )
            {
                # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
                # Применение ГП не в конце настройки, так как необходимо чтобы выключились службы и драйвера, чтобы был доступ к настройке служб и исключений.
                Set-LGP -ApplyGP

                Start-Sleep -Milliseconds 1000

                Write-Host
            }

            # Отключение и удаление логов
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/Operational' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/WHC' -Name 'Enabled' -Type DWord 0

            $N = 0
            Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -like '*Defender*' } | ForEach-Object {
                
                    if ( -not $N ) { Write-Host }
                    $N++
                    $log = $_.FullName
                
                    if ( $Act -ne 'Check' )
                    {
                        Write-Host "     Del: $log" -ForegroundColor DarkGray -NoNewline
                    
                        try { Remove-Item -LiteralPath "\\?\$log" -Force -ErrorAction Stop ; Write-Host }
                        catch
                        {
                            $text = if ( $L.s20 ) { $L.s20 } else { 'Отложенное удаление' }
                            Write-Host " | $text" -ForegroundColor Gray

                            Set-Delayed-MoveDeletion -Targets $log
                        }
                    }
                    else
                    {
                        Write-Host "     Del: $log" -ForegroundColor Yellow
                        $NeedFix = $true
                    }
                }

            Write-Host

            if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger').Name )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger' -Name 'Start' -Type DWord 0
            }

            if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger').Name )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger' -Name 'Start' -Type DWord 0
            }

            # Удаление логов
            Write-Host
            Token-Impersonate -Token TI
            Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\LogFiles\WMI","$env:SystemDrive\ProgramData\Microsoft\Diagnosis\ETLLogs\AutoLogger"  -Recurse -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -like '*Defender*.etl*' } | ForEach-Object {

                    if ( $Act -ne 'Check' )
                    {
                        Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                        Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                    }
                    else
                    {
                        Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                    }
                }
            Token-Impersonate -Reset

            if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check1)))}catch{} }

            try
            {
                [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                if ( $null -eq $Tamper ) { $Tamper = '-' }
            }
            catch { [psobject] $Tamper = '-' }

            # Если существует Защитник
            if ( $isExistDef )
            {  
                if ( $Act -ne 'Check' )
                {
                    $text = if ( $L.s21 ) { $L.s21 } else { "Ожидание остановки" }
                    Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                    $text = if ( $L.s21_1 ) { $L.s21_1 } else { "драйвера" }
                    Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "WdFilter " -ForegroundColor Magenta -NoNewline

                    $text = if ( $L.s21_2 ) { $L.s21_2 } else { "после применения ГП. Не более 3 сек" }
                    Write-Host "| $text" -ForegroundColor DarkGray

                    # Он сам останавливается после применения ГП, и разделы реестра защитника разблокирутся. Такое поведение до 1903
                    try { (Get-Service -Name WdFilter -ErrorAction SilentlyContinue).WaitForStatus('Stopped',[timespan]::FromSeconds(3)) } catch {}
                }

                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Проверка Отключенных компонентов Защитника" }
                    Write-Host "`n   $text" -ForegroundColor DarkCyan
                }
                else
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { "Отключение компонентов Защитника" }
                    Write-Host "`n   $text" -ForegroundColor DarkCyan
                }


                if ( $Act -eq 'Set' )
                {
                    # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1
                }

                ######## services ###################################################################################
                # Принудительная остановка некоторых служб и драйверов, в данном случае и не только,
                # может привести к синему экрану, поэтому тут это не используется в основном.
                #region services

                $text = if ( $L.s30 ) { $L.s30 } else { "Отключение Служб" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check3)))}catch{} }
                Set-Svc -Do:$Act Set-Service -Name 'WinDefend' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check4)))}catch{} }
                Set-Svc -Do:$Act Set-Service -Name 'WdNisSvc' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check5)))}catch{} }
                Set-Svc -Do:$Act Set-Service -Name 'Sense' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check6)))}catch{} }
                Set-Svc -Do:$Act Set-Service -Name 'SecurityHealthService' -StartupType Disabled

                $text = if ( $L.s31 ) { $L.s31 } else { "Отключение Драйверов" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check7)))}catch{} }
                Set-Drv -Do:$Act Set-Driver -Name 'WdFilter' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check8)))}catch{} }
                Set-Drv -Do:$Act Set-Driver -Name 'WdBoot' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check9)))}catch{} }
                Set-Drv -Do:$Act Set-Driver -Name 'WdNisDrv' -StartupType Disabled

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check10)))}catch{} }
                Set-Drv -Do:$Act Set-Driver -Name 'MsSecFlt' -StartupType Disabled

                Write-Host

                if ( -not ( $Tamper -match '[-04]' ))
                {
                    if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check2)))}catch{} }
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Type DWord 0
                }

                if ( $Act -eq 'Set' )
                {
                    # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Включена)
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware' -Type DWord 1
                }
                #endregion services
                ######## end services ####################################################################################

                Write-Host

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check11)))}catch{} }
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 1

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check12)))}catch{} }
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DpaDisabled' -Type DWord 1

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check13)))}catch{} }
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReporting' -Type DWord 0

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check14)))}catch{} }
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'MAPSconcurrency' -Type DWord 0
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReportingLocation' -Type MultiString 'https://0.0.0.0'

                $text = if ( $L.s25 ) { $L.s25 } else { "Удаление из автозапуска Старых параметров, которые добавляет Защитник. Видимо баг" }
                Write-Host "`n   $text`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'WindowsDefender'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'WindowsDefender'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'WindowsDefender'

                $text = if ( $L.s26 ) { $L.s26 } else { "Скрытие контекстного меню" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}' -Type String ''

                if ( $is64 )
                {
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}' -Type String ''
                }

                if ( $Act -eq 'Set' )
                {
                    $dll = "$env:SystemDrive\Program Files\Windows Defender\shellext.dll"
                    if ( [System.IO.File]::Exists($dll) )
                    {
                        Write-Host "`n   regsvr32.exe /u $dll /s`n" -ForegroundColor DarkGray
                        try { & regsvr32.exe /u "$dll" /s > $null } catch {}
                    }
                }

                $text = if ( $L.s23 ) { $L.s23 } else { "Удаление Задач" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                if ( $Act -eq 'Set' ) { try{& $([scriptblock]::Create((Check-Status $Check15)))}catch{} }
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance'
                Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance'
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup'
                Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup'
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan'
                Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan'
                #Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Verification'
                Set-Tsk -Do:$Act Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Verification'

                $text = if ( $L.s24 ) { $L.s24 } else { "Удаление автозапуска" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'SecurityHealth'

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'SecurityHealth' -Type ExpandString '%windir%\system32\SecurityHealthSystray.exe'
                Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'SecurityHealth'

                $text = if ( $L.s32 ) { $L.s32 } else { "Блокировка запуска" }
                Write-Host "`n   $text`: MpCmdRun.exe`n" -ForegroundColor DarkGray

                if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Debugger-Cmd\s*=\s*1\s*=\s*(?<Debugger>[^\r\n]+)==' },'First') )
                {
                    [string] $Value = $Matches.Debugger.Trim()
                }
                else { [string] $Value = 'dllhost.exe' }

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger' -Type String $Value

                if ( $Act -ne 'Check' )
                {
                    [int] $N = 0

                    while ( [System.Diagnostics.Process]::GetProcessesByName('SecurityHealthSystray').Count -and $N -lt 10 )
                    { $N++ ; try { & $env:SystemRoot\System32\taskkill.exe /t /im SecurityHealthSystray.exe *> $null } catch {} ; Start-Sleep -Milliseconds 10 }

                    if ( $N ) { Stop-Process -Name SecurityHealthSystray -Force -ErrorAction SilentlyContinue }
                    
                    if ( [System.Diagnostics.Process]::GetProcessesByName('SecurityHealthService').Count )
                    {
                        try{& $([scriptblock]::Create((Check-Status $Check16)))}catch{} 
                    }
                }

                #
                #########################################################################################
                # Проверка Защиты от Подделки и предложение отключить ее вручную.

                <#
                if ( $Act -ne 'Check' )
                {
                    try
                    {
                        [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                        if ( $null -eq $Tamper ) { $Tamper = '-' }
                    }
                    catch { [psobject] $Tamper = '-' }

                    if ( $Tamper -notmatch '[-04]' )
                    {
                        try { $AppxErr = $false ; $SecHealtName = (Get-AppxPackage -Name '*SecHealthUI*' -ErrorAction SilentlyContinue).Name }
                        catch { $AppxErr = $true ; $SecHealtName = $null }

                        if ( $AppxErr )
                        {
                            $text = if ( $L.s45_2 ) { $L.s45_2 } else { "Отключена служба AppXSvc" }
                            Write-Host "`n   $text" -ForegroundColor Red
                        }
                        elseif ( -not $SecHealtName )
                        {
                            $text = if ( $L.s45 ) { $L.s45 } else { "Защита не отключена, а системный App уже удалён: Microsoft.Windows.SecHealthUI/Microsoft.SecHealthUI" }
                            Write-Host "`n   $text" -ForegroundColor Yellow
                        }
                        else
                        {
                            if ((Check-State-Service -ServiceName SecurityHealthService -CheckStatus -Return Value) -ne 'Running' -or
                                (Check-State-Service -ServiceName WinDefend -CheckStatus -Return Value) -ne 'Running' -or
                                (Check-State-Driver  -DriverName  WdFilter  -CheckStatus -Return Value) -ne 'Running' )
                            {
                                Write-Host "`n   Not running: SecurityHealthService -or WinDefend -or WdFilter" -ForegroundColor DarkGray
                            }
                            else { Open-ThreatSettings }
                        }
                    }
                }
                #>

                # конец проверки защиты от подделки
                #########################################################################################
                #

                if ( $Act -eq 'Set' )
                {
                    Write-Host

                    # Повтор отключения, так как бывает при выполнении далее, после отключения, винда включает эти обратно,
                    # когда видит, что они были отключены. И не важно каким методом их отключать. началось после какого-то обновления
                    # или времени пройденном после последнего обновления или всё вместе, на LTSC .1397 уже включает.

                    try{& $([scriptblock]::Create((Check-Status $Check3)))}catch{}
                    Set-Svc -Do:$Act Set-Service -Name 'WinDefend' -StartupType Disabled
                    
                    try{& $([scriptblock]::Create((Check-Status $Check7)))}catch{}
                    Set-Drv -Do:$Act Set-Driver -Name 'WdFilter' -StartupType Disabled
                    
                    try{& $([scriptblock]::Create((Check-Status $Check8)))}catch{}
                    Set-Drv -Do:$Act Set-Driver -Name 'WdBoot' -StartupType Disabled
                }

                # Повторная Проверка Защиты от Подделки.
                try
                {
                    [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                    if ( $null -eq $Tamper ) { $Tamper = '-' }
                }
                catch { [psobject] $Tamper = '-' }

                if ( $Tamper -eq '-' )
                {
                    $text = if ( $L.s49 ) { $L.s49 } else { "'Защита от Подделки' отсутствует" }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                elseif ( $Tamper -match '[04]' )
                {
                    $text = if ( $L.s51 ) { $L.s51 } else { "'Защита от Подделки' отключена" }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                elseif ( $Tamper -match '[1235]' )
                {
                    $text = if ( $L.s52 ) { $L.s52 } else { "'Защита от Подделки' не отключена" }
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White -NoNewline
                    Write-Host "| $text `n" -ForegroundColor DarkGray
                }
                else
                {
                    Write-Host "`n   TamperProtection: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$Tamper " -ForegroundColor White
                }
            }
            else
            {
                $text = if ( $L.s27 ) { $L.s27 } else { "Нет Защитника Windows" }
                Write-Host "`n   $text " -ForegroundColor DarkGreen -NoNewline
            }
        }
        elseif ( $Option -eq 'AddExclusions' )
        {
            if ( $isExistDef )
            {
                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s34 ) { $L.s34 } else { "Проверка Исключений" }
                    Write-Host "`n   $text`n" -ForegroundColor DarkCyan
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { "Защитника Windows не существует, пропуск добавления в исключения" }
                Write-Host "`n   $text`n" -ForegroundColor DarkGray
                
                Return
            }

            # Добавление в исключения, добавляются исключения, которые еще не добавлены.
            Add-Exclusion-ToDefender

            if ( $ApplyGP )
            {
                # Если запуск не из главных меню быстрых настроек (0 и 1)
                if ( -not $MenuConfigsQuickSettings )
                {
                    Get-Pause
                }
            }

            Return
        }
        elseif ( $Option -eq 'SecurityCenterDisable' )
        {
            if ( $Act -eq 'Check' )
            {
                $text = if ( $L.s54 ) { $L.s54 } else { "Проверка Отключения Центра Безопасности" }
                Write-Host "`n   $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s55 ) { $L.s55 } else { "Отключение Центра Безопасности" }
                Write-Host "`n   $text" -ForegroundColor DarkCyan
            }

            Set-Svc -Do:$Act Set-Service -Name 'wscsvc' -StartupType Disabled
            Set-Svc -Do:$Act Set-Service -Name 'SgrmBroker' -StartupType Disabled
            Set-Drv -Do:$Act Set-Driver -Name 'SgrmAgent' -StartupType Disabled

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 0
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        if ( $Option -eq 'AddExclusions' )
        {
            $text = if ( $L.s35 ) { $L.s35 } else { "Не предусмотрено удаление добавленных исключений Защитника Windows" }
            Write-Host "`n   $text" -ForegroundColor DarkGray

            Return   # Выход
        }
        elseif ( $Option -eq 'DefenderDisable' )
        {
            $text = if ( $L.s36 ) { $L.s36 } else { "Восстановление Защитника Windows (По умолчанию)" }
            Write-Host "`n   $text`:" -ForegroundColor Magenta

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Отключить Защитник Windows" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableAntiSpyware'

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Настроить Обнаружение потенциально нежелательных приложений" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'PUAProtection'

            # Комп\Адм. Шабл\Компоненты Windows\Антивирусная программа ...\ "Выключить плановое исправление" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender' -Name 'DisableRoutinelyTakingAction'

            # Если существует защитник
            if ( $isExistDef )
            {
                # Добавление в исключения, добавляются исключения, которые еще не добавлены.
                Add-Exclusion-ToDefender

                $text = if ( $L.s37 ) { $L.s37 } else { "Включение Служб" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Svc Set-Service -Name 'WinDefend' -StartupType Automatic
                Set-Svc Set-Service -Name 'WdNisSvc' -StartupType Manual
                Set-Svc Set-Service -Name 'Sense' -StartupType Manual

                if ( -not ( Check-State-Service -ServiceName 'SecurityHealthService' -CheckExist -Return Bool ))
                {
                    if ( [System.IO.File]::Exists("$env:SystemRoot\system32\SecurityHealthService.exe") )
                    {
                        # Создание службы с оригинальными параметрами, если была удалена
                        [array]$CmdLine = 'cmd /c sc create SecurityHealthService BinPath= %systemroot%\system32\SecurityHealthService.exe ',
                        'start= demand obj= LocalSystem depend= RpcSs DisplayName= @%systemroot%\system32\SecurityHealthAgent.dll,-1002',
                        '& sc description SecurityHealthService "@%systemroot%\system32\SecurityHealthAgent.dll,-1001"',
                        '& sc privs SecurityHealthService SeImpersonatePrivilege/SeBackupPrivilege/SeRestorePrivilege/SeDebugPrivilege/',
                        'SeChangeNotifyPrivilege/SeSecurityPrivilege/SeAssignPrimaryTokenPrivilege/SeTcbPrivilege/SeSystemEnvironmentPrivilege/SeShutdownPrivilege',
                        '& sc sidtype SecurityHealthService unrestricted & sc failure SecurityHealthService reset= 86400 actions= restart/60000/restart/60000/""/""',
                        '& reg add HKLM\SYSTEM\CurrentControlSet\Services\SecurityHealthService /v LaunchProtected /t REG_DWORD /d 2 /f'

                        Start-ParentProcess -RunAs TI -CmdLine ($CmdLine -join '') -NoWindow -Wait -Milliseconds 3000
                    }
                }

                Set-Svc Set-Service -Name 'SecurityHealthService' -StartupType Manual

                $text = if ( $L.s38 ) { $L.s38 } else { "Включение Драйверов" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Drv Set-Driver -Name 'WdFilter' -StartupType Boot
                Set-Drv Set-Driver -Name 'WdBoot' -StartupType Boot
                Set-Drv Set-Driver -Name 'WdNisDrv' -StartupType Manual
                Set-Drv Set-Driver -Name 'MsSecFlt' -StartupType Boot

                $text = if ( $L.s39 ) { $L.s39 } else { "Включение Задач" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cache Maintenance'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Cleanup'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Scheduled Scan'
                Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Defender\Windows Defender Verification'

                $text = if ( $L.s40 ) { $L.s40 } else { "Возврат автозапуска" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'SecurityHealth' -Type ExpandString '%windir%\system32\SecurityHealthSystray.exe'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'SecurityHealth'
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'SecurityHealth' -Type Binary 0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0

                Write-Host

                try
                {
                    [psobject] $Tamper = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Features','TamperProtection','-') 
                    if ( $null -eq $Tamper ) { $Tamper = '-' }
                }
                catch { [psobject] $Tamper = '-' }

                if ( $Tamper -ne '-' )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Features' -Name 'TamperProtection' -Type DWord 5
                }

                try { [int] $RealtimeMonitoring = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection','DisableRealtimeMonitoring',0) }
                catch { [int] $RealtimeMonitoring = 0 }

                if ( $RealtimeMonitoring -ne 0 )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DisableRealtimeMonitoring' -Type DWord 0
                }

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Real-Time Protection' -Name 'DpaDisabled' -Type DWord 0

                try { [int] $SpyNetReporting = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Defender\Spynet','SpyNetReporting',0) }
                catch { [int] $SpyNetReporting = 0 }

                if ( $SpyNetReporting -eq 0 )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SpyNetReporting' -Type DWord 1
                }

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender\Spynet' -Name 'SubmitSamplesConsent' -Type DWord 1

                Write-Host

                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Spynet'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Signature Updates'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Policy Manager'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\MpEngine'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Quarantine'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Remediation'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Reporting'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Scan'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\UX Configuration'
                Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender'
            
                Write-Host

                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/Operational' -Name 'Enabled' -Type DWord 1
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Windows Defender/WHC' -Name 'Enabled' -Type DWord 1

                if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger').Name )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderApiLogger' -Name 'Start' -Type DWord 1
                }

                if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger').Name )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\DefenderAuditLogger' -Name 'Start' -Type DWord 1
                }

                Write-Host

                # Расширенные уведомления Защитника
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Notifications' -Name 'DisableEnhancedNotifications'
                # Уведомления Защитника
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'FilesBlockedNotificationDisabled'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'NoActionNotificationDisabled'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows Defender Security Center\Virus and threat protection' -Name 'SummaryNotificationDisabled'

                # Удаление блокировки запуска MpCmdRun.exe, который запускает служба wscsvc и настраивает им защитник.
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger'

                $text = if ( $L.s25 ) { $L.s25 } else { "Удаление из автозапуска Старых параметров, которые добавляет Защитник. Видимо баг" }
                Write-Host "`n   $text`n" -ForegroundColor DarkGray

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run' -Name 'WindowsDefender'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\AutorunsDisabled' -Name 'WindowsDefender'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' -Name 'WindowsDefender'

                $text = if ( $L.s41 ) { $L.s41 } else { "Восстановление Контекстного меню" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}'
                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{09A47860-11B0-4DA5-AFA5-26D86198A780}'

                $dll = "$env:SystemDrive\Program Files\Windows Defender\shellext.dll"
                if ( [System.IO.File]::Exists($dll) )
                {
                    Write-Host "`n   regsvr32.exe $dll /s`n" -ForegroundColor DarkGray
                    try { & regsvr32.exe "$dll" /s > $null } catch {}
                }

                $text = if ( $L.s42 ) { $L.s42 } else { "Удаление скрытия параметров защитника из настроек" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkGray

                # Удаление скрытия окна параметров из настроек.
                Set-SettingsPageVisibility -Names 'windowsdefender' -Remove

                $text = if ( $L.s32_1 ) { $L.s32_1 } else { "Снятие блокировки запуска" }
                Write-Host "`n   $text`: MpCmdRun.exe`n" -ForegroundColor DarkGray

                Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options\MpCmdRun.exe' -Name 'Debugger'
            }
            else
            {
                $text = if ( $L.s43 ) { $L.s43 } else { "Нет Защитника Windows" }
                Write-Host "`n   $text " -ForegroundColor DarkGreen -NoNewline

                $text = if ( $L.s43_1 ) { $L.s43_1 } else { "Пропуск действий восстановления" }
                Write-Host "| $text`n" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'SecurityCenterDisable' )
        {
            $text = if ( $L.s53 ) { $L.s53 } else { "Восстановление Центра Безопасности (По умолчанию)" }
            Write-Host "`n   $text`:" -ForegroundColor Magenta

            Set-Svc Set-Service -Name 'wscsvc' -StartupType DelayedAuto
            Set-Svc Set-Service -Name 'SgrmBroker' -StartupType DelayedAuto
            Set-Drv Set-Driver -Name 'SgrmAgent' -StartupType Boot

            Set-Reg Remove-ItemProperty -Path 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled'
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\Windows.SystemToast.SecurityAndMaintenance' -Name 'Enabled' -Type DWord 1
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s44 ) { $L.s44 } else { "Необходимо перезагрузиться!" }
        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings )
        {
            Get-Pause
        }
    }
}
