﻿
<#
.SYNOPSIS
 Настройка некоторых сетевых параметров системы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Network_Settings.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.


.EXAMPLE
    Set-Network-Settings -Act Set -Options DisableIPv6 -ApplyGP

    Описание
    --------
    Отключение IPv6. (значение 0xff) - То есть остается лупбэк (перенаправление через IPv4).

.EXAMPLE
    Set-Network-Settings -CheckState AutoShare

    Описание
    --------
    Проверить состояние общих административных ресурсов.
    Если служба LanmanServer отключена, то эти параметры не имеют значения.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  18-04-2019
 ===============================================

#>
Function Set-Network-Settings {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'DisableLocal', 'HideContextMenuShare', 'HideMenuGiveAccessTo', 'DisableRemote', 'DisableAdmRes', 'DisableIPv6', 'DisableDnsFunctions',
                      'EnableUnBlockSites', 'ConfigNCSI' )]
        [System.Collections.Generic.List[string]] $Options
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 2 )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'RemoteDCOM', 'AutoShare', 'IPv6', 'UnBlockAdress', 'UnBlockAdressCompare', 'ContextMenuShare', 'MenuGiveAccessTo',
                      'RemoteAssistance', 'RemoteMDM', 'NetMeeting', 'RemoteWinRM',
                      'DnsLLMNR', 'DnsResolution', 'DnsDevolution', 'DnsParallel', 'NCSI', 'PresetNCSI' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    if ( $CheckState )
    {
        if ( $CheckState -eq 'RemoteDCOM' )
        {
            try { [string] $RemoteDCOM = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Ole','EnableDCOM',$null)
            } catch { [string] $RemoteDCOM = '' }

            if     ( 'Y' -eq $RemoteDCOM ) { "#Yellow#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { 'Включён   ' }) }
            elseif ( 'N' -eq $RemoteDCOM ) {  "#Green#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { 'Отключён  ' }) }  # Дефолт
            else                           {    "#Red#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { 'Ошибка    ' }) }
        }
        elseif ( $CheckState -eq 'AutoShare' )
        {
            try { [psobject] $AutoShare1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters','AutoShareWks',$null)
            } catch { [psobject] $AutoShare1 = $null }

            try { [psobject] $AutoShare2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters','AutoShareServer',$null)
            } catch { [psobject] $AutoShare2 = $null }

            if (( 0 -eq $AutoShare1 ) -and ( 0 -eq $AutoShare2 )) {  "#Green#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { 'Отключены ' }) }
            else                                                  { "#Yellow#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { 'Включены  ' }) }
        }
        elseif ( $CheckState -eq 'ContextMenuShare' )
        {
            try { [psobject] $ContextMenu1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked','{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}',$null)
            } catch { [psobject] $ContextMenu1 = $null }

            if ( $null -ne $ContextMenu1 ) {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { 'Скрыто    ' }) }
            else                           { "#Yellow#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { 'Не скрыто ' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'MenuGiveAccessTo' )
        {
            try { [psobject] $ContextMenu2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked','{F81E9010-6EA4-11CE-A7FF-00AA003CA9F6}',$null)
            } catch { [psobject] $ContextMenu2 = $null }

            if ( $null -ne $ContextMenu2 ) {  "#Green#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { 'Скрыто    ' }) }
            else                           { "#Yellow#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { 'Не скрыто ' }) } # Дефолт
        }
        elseif ( $CheckState -eq 'IPv6' )
        {
            try { [int] $IPv6 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\services\TCPIP6\Parameters','DisabledComponents',0)
            } catch { [int] $IPv6 = 0 }

            try { [string] $isIPv6 = [convert]::ToString($IPv6,16) } catch { [string] $isIPv6 = 'Error' }

            if ( 0 -eq $IPv6 ) { "#Yellow#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { 'Включен' }) }  # Дефолт
            else
            {
                if ( 'ff' -eq $isIPv6 ) { "#Green#{0} #DarkGray#| {1}: #Green#0x$isIPv6#" -f $(if ( $L.s9  ) { $L.s9, $L.s9_1  } else { 'Отключен', 'значение' }) }
                else                    { "#Yello#{0} #DarkGray#| {1}: #Yello#0x$isIPv6#" -f $(if ( $L.s10 ) { $L.s10,$L.s10_1 } else { 'Неизвестно', 'значение' }) }
            }
        }
        elseif ( $CheckState -eq 'RemoteAssistance' )
        {
            try { [psobject] $RemoteP1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services','fAllowToGetHelp',1)
            } catch { [psobject] $RemoteP1 = 1 }

            try { [psobject] $RemoteP2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services','fAllowUnsolicited',1)
            } catch { [psobject] $RemoteP2 = 1 }

            try { [psobject] $RemoteA1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Remote Assistance','fAllowToGetHelp',1)
            } catch { [psobject] $RemoteA1 = 1 }

            try { [psobject] $RemoteA2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Remote Assistance','fAllowFullControl',1)
            } catch { [psobject] $RemoteA2 = 1 }

            try { [psobject] $RemoteP = $RemoteP1 + $RemoteP2 } catch { [int] $RemoteP = 1 }
            try { [psobject] $RemoteA = $RemoteA1 + $RemoteA2 } catch { [int] $RemoteA = 1 }

            if     ( 0 -eq $RemoteP  ) {  "#Green#{0}#"             -f $(if ( $L.s11 ) { $L.s11 }          else { 'Отключена'                    }) }
            elseif ( 0 -eq $RemoteP1 ) {  "#Green#{0} #Yellow#{1}#" -f $(if ( $L.s12 ) { $L.s12,$L.s12_1 } else { 'Отключена', '(Не всё)'        }) }
            elseif ( 0 -eq $RemoteA  ) {  "#Green#{0} #Yellow#{1}#" -f $(if ( $L.s13 ) { $L.s13,$L.s13_1 } else { 'Отключена', '(Не ГП)'         }) }
            elseif ( 0 -eq $RemoteA1 ) {  "#Green#{0} #Yellow#{1}#" -f $(if ( $L.s14 ) { $L.s14,$L.s14_1 } else { 'Отключена', '(Не всё, Не ГП)' }) }
            else                       { "#Yellow#{0}#"             -f $(if ( $L.s15 ) { $L.s15 }          else { 'Не Отключена'                 }) }
        }
        elseif ( $CheckState -eq 'RemoteMDM' )
        {
            try { [int] $RemoteMDM = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\MDM','DisableRegistration',0)
            } catch { [int] $RemoteMDM = 0 }

            if ( 1 -eq $RemoteMDM ) {  "#Green#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { 'Отключена   ' }) }
            else                    { "#Yellow#{0}#" -f $(if ( $L.s17 ) { $L.s17 } else { 'Не Отключена' }) }
        }
        elseif ( $CheckState -eq 'NetMeeting' )
        {
            try { [int] $NetMeeting = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Conferencing','NoRDS',0)
            } catch { [int] $NetMeeting = 0 }

            if ( 1 -eq $NetMeeting ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else                     { "#Yellow#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не Отключён ' }) }
        }
        elseif ( $CheckState -eq 'RemoteWinRM' )
        {
            try { [int] $NetMeeting = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS','AllowRemoteShellAccess',1)
            } catch { [int] $NetMeeting = 1 }

            if ( 0 -eq $NetMeeting ) {  "#Green#{0}#" -f $(if ( $L.s16 ) { $L.s16 } else { 'Отключена   ' }) }
            else                     { "#Yellow#{0}#" -f $(if ( $L.s17 ) { $L.s17 } else { 'Не Отключена' }) }
        }
        elseif ( $CheckState -eq 'UnBlockAdress' )
        {
            try { [string] $UnBlockAdress = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings','AutoConfigURL',$null)
            } catch { [string] $UnBlockAdress = '' }

            if ( $UnBlockAdress ) {  "#Green#{0} #DarkGray#| $UnBlockAdress#" -f $(if ( $L.s20 ) { $L.s20 } else { "Применён"   }) }
            else                  { "#Yellow#{0}#"                            -f $(if ( $L.s21 ) { $L.s21 } else { "Нет обхода" }) }
        }
        elseif ( $CheckState -eq 'UnBlockAdressCompare' )
        {
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-UnBlock-WebSites\s*=\s*1\s*=\s*(?<Adress>[^\r\n]+)==' },'First',1) )
            {
                [string] $PresetUnBlockAdress = $Matches.Adress.Trim()
            }
            else { [string] $PresetUnBlockAdress = '' }

            try { [string] $UnBlockAdress = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings','AutoConfigURL',$null)
            } catch { [string] $UnBlockAdress = '' }

            if ( $PresetUnBlockAdress )
            {
                if ( $PresetUnBlockAdress -eq $UnBlockAdress ) { "#DarkGray# | #Green#{0}#" -f $PresetUnBlockAdress.PadRight(52,' ').Substring(0,52) }
                else { "#DarkGray# | {0}#" -f $PresetUnBlockAdress.PadRight(52,' ').Substring(0,52) }
            }
            else { "#DarkGray# | {0}#" -f $(if ( $L.s22 ) { $L.s22 } else { "Нет адреса в пресетах" }).ToString().PadRight(52,' ').Substring(0,52) }
        }
        elseif ( $CheckState -eq 'DnsLLMNR' )
        {
            try { $DnsLLMNR = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','EnableMulticast',$null) }
            catch { $DnsLLMNR = $null }

            try { $DnsLLMNR2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','EnableMDNS',$null) }
            catch { $DnsLLMNR2 = $null }

            if ( 0 -eq $DnsLLMNR -and 0 -eq $DnsLLMNR2 ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else                                         { "#Yellow#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не Отключён ' }) }
        }
        elseif ( $CheckState -eq 'DnsResolution' )
        {
            try { $DnsResolution = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','DisableSmartNameResolution',$null) }
            catch { $DnsResolution = $null }

            if ( 1 -eq $DnsResolution ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else                        { "#Yellow#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не Отключён ' }) }
        }
        elseif ( $CheckState -eq 'DnsDevolution' )
        {
            try { $DnsDevolution = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient','UseDomainNameDevolution',$null) }
            catch { $DnsDevolution = $null }

            if ( 0 -eq $DnsDevolution ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else                        { "#Yellow#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не Отключён ' }) }
        }
        elseif ( $CheckState -eq 'DnsParallel' )
        {
            try { $DnsParallel = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters','DisableParallelAandAAAA',$null) }
            catch { $DnsParallel = $null }

            if ( 1 -eq $DnsParallel ) {  "#Green#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else                      { "#Yellow#{0}#" -f $(if ( $L.s19 ) { $L.s19 } else { 'Не Отключён ' }) }
        }
        elseif ( $CheckState -eq 'NCSI' )
        {
            try { [int] $Enabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet','EnableActiveProbing',$null) }
            catch { [int] $Enabled = 0 }

            try { [int] $Disabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows','NoActiveProbe',$null) }
            catch { [int] $Disabled = 0 }

            try { [string] $ProbeHost = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet','ActiveWebProbeHost',$null) }
            catch { [string] $ProbeHost = '' }

            [bool] $NCSI = $true

            if (( $Enabled -eq 0 ) -or ( $Disabled -eq 1 ) -or ( -not $ProbeHost )) { $NCSI = $false }

            if ( -not $NCSI ) {  "#White#{0}#" -f $(if ( $L.s18 ) { $L.s18 } else { 'Отключён    ' }) }
            else
            {
                if ( $ProbeHost -eq 'www.msftconnecttest.com' ) { "#Yellow#{0}#" -f $ProbeHost }
                else                                            {  "#Green#{0}#" -f $ProbeHost }
            }
        }
        elseif ( $CheckState -eq 'PresetNCSI' )
        {
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Network-Indicator\s*=\s*1\s*=\s*(?<Name>[^\r\n]+)==' },'First',1) )
            {
                [string] $NameNCSI = $Matches.Name.Trim()
            }
            else { [string] $NameNCSI = '' }

            if ( $NameNCSI -in 'Firefox NCSI','Debian NCSI' )
            {
                try { [int] $Enabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet','EnableActiveProbing',$null) }
                catch { [int] $Enabled = 0 }

                try { [int] $Disabled = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows','NoActiveProbe',$null) }
                catch { [int] $Disabled = 0 }

                try { [string] $ProbeHost = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet','ActiveWebProbeHost',$null) }
                catch { [string] $ProbeHost = '' }

                [bool] $NCSI = $true

                if (( $Enabled -eq 0 ) -or ( $Disabled -eq 1 ) -or ( -not $ProbeHost )) { $NCSI = $false }

                if ( $NameNCSI -eq 'Debian NCSI'  ) { $ActiveWebProbeHost = 'network-test.debian.org' }
                else                                { $ActiveWebProbeHost = 'detectportal.firefox.com' }

                if ( $NCSI -and $ProbeHost -eq $ActiveWebProbeHost )
                {
                    "#DarkGray# | #Green#{0}#" -f $NameNCSI.PadRight(52,' ').Substring(0,52)
                }
                else
                {
                    "#DarkGray# | {0}#" -f $NameNCSI.PadRight(52,' ').Substring(0,52)
                }
            }
            elseif ( $NameNCSI -and $NameNCSI -notin 'Firefox NCSI','Debian NCSI' )
            {
                $text = if ( $L.s51 ) { $L.s51 } else { "Пропуск настройки NCSI" }
                "#DarkGray# | {0}#" -f "$text`: $NameNCSI".PadRight(52,' ').Substring(0,52)
            }
            else
            {
                $text = if ( $L.s52 ) { $L.s52 } else { "Отключена настройка NCSI" }
                "#DarkGray# | {0}#" -f $text.PadRight(52,' ').Substring(0,52)
            }
        }

        Return
    }

    [string] $InternetSettingsRefreshAPI = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class Internet
    {
        [DllImport( "wininet.dll", SetLastError = true, CharSet = CharSet.Auto )]
        private static extern bool InternetSetOption(IntPtr hInternet, int dwOption, IntPtr lpBuffer, int dwBufferLength);

        private const int INTERNET_OPTION_SETTINGS_CHANGED = 39;
        private const int INTERNET_OPTION_REFRESH = 37;

        public static bool SettingsRefresh()
        {
            bool SettingsReturn = InternetSetOption(IntPtr.Zero, INTERNET_OPTION_SETTINGS_CHANGED, IntPtr.Zero, 0);
            bool RefreshReturn  = InternetSetOption(IntPtr.Zero, INTERNET_OPTION_REFRESH, IntPtr.Zero, 0);

            return SettingsReturn && RefreshReturn;
        }
    }
}
'@

    [bool] $is64 = [Environment]::Is64BitOperatingSystem

    $text = if ( $L.s23 ) { $L.s23 } else { 'Настройка параметров Сети' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s23_1 ) { $L.s23_1 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( -not $Options )
    {
        $Options = @()

        # Получаем список параметров в пресете
        foreach ( $Line in ( $ListPresetsGlobal -match '^\s*Set-Network-Settings\s*=\s*1\s*=' ))
        {
            # Берем заданные параметры
            if ( $Line -match "^\s*Set-Network-Settings\s*=\s*1\s*=\s*(?<Param>[a-z0-9]+)\s*=" )
            {
                $Options.Add($Matches.Param.Trim())
            }
        }

        if ( -not $Options.Count )
        {
            $text = if ( $L.s23_2 ) { $L.s23_2 } else { 'Параметры не указаны' }
            Write-Host "`n   $text`n" -ForegroundColor DarkGray

            Return
        }
    }

    if ( 'DisableLocal' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s24 ) { $L.s24 } else { 'Отключение Службы LanmanServer, Протокола DCOM,  Драйвера NetBios' }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            $text = if ( $L.s25 ) { $L.s25 } else { 'Отключение Службы LanmanServer (445 порт)' }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'LanmanServer' -StartupType Disabled

            $text = if ( $L.s26 ) { $L.s26 } else { 'Отключение счетчиков производительности сетевых служб' }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            if ( $Act -eq 'Set' )
            {
                & LODCTR.exe /D:PerfNet

                if ( [string] $PerfNet = (& LODCTR.exe /Q:PerfNet) -like "*PerfNet*(Disabled)" )
                {
                    $text = if ( $L.s27 ) { $L.s27 } else { '  Выполнено' }
                    Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                    Write-Host "  PerfNet " -ForegroundColor White -NoNewline
                    Write-Host "| $PerfNet" -ForegroundColor DarkGray
                }
            }

            $text = if ( $L.s28 ) { $L.s28 } else { 'Отключение Драйвера NetBios' }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Drv -Do:$Act Set-Driver -Name 'NetBT' -StartupType Disabled


            $text = if ( $L.s29 ) { $L.s29 } else { 'Отключение Протокола DCOM' }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Ole' -Name 'EnableDCOM' -Type String 'N'
        }
        else
        {
            # Восстановление По умолчанию.

            $text = if ( $L.s30 ) { $L.s30 } else { 'Восстановление Службы LanmanServer, Протокола DCOM, Драйвера NetBios (По умолчанию)' }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Svc Set-Service -Name 'LanmanServer' -StartupType Automatic

            & LODCTR.exe /E:PerfNet

            if ( [string] $PerfNet = (& LODCTR.exe /Q:PerfNet) -like "*PerfNet*(Enabled)" )
            {
                $text = if ( $L.s27 ) { $L.s27 } else { '  Выполнено' }
                Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                Write-Host "  PerfNet " -ForegroundColor White -NoNewline
                Write-Host "| $PerfNet" -ForegroundColor DarkGray
            }

            Set-Drv Set-Driver -Name 'NetBT' -StartupType System
            Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Ole' -Name 'EnableDCOM' -Type String 'Y'
        }
    }

    if ( 'HideContextMenuShare' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s31 ) { $L.s31 } else { "Скрытие пункта 'Отправить' (Share) из контекстного меню файлов" }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}' -Type String ''
        
            if ( $is64 )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}' -Type String ''
            }
        }
        else
        {
            # Восстановление По умолчанию.

            $text = if ( $L.s31_1 ) { $L.s31_1 } else { "Восстановление пункта 'Отправить' (Share) в контекстном меню файлов" }
            Write-Host "`n   $text`:`n" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{E2BF9676-5F8F-435C-97EB-11607A5BEDF7}'
        }
    }

    if ( 'HideMenuGiveAccessTo' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s32 ) { $L.s32 } else { "Скрытие пункта 'Предоставить доступ к' из контекстного меню папок" }
            Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{F81E9010-6EA4-11CE-A7FF-00AA003CA9F6}' -Type String ''
        
            if ( $is64 )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{F81E9010-6EA4-11CE-A7FF-00AA003CA9F6}' -Type String ''
            }
        }
        else
        {
            # Восстановление По умолчанию.

            $text = if ( $L.s32_1 ) { $L.s32_1 } else { "Восстановление пункта 'Предоставить доступ к' в контекстном меню папок" }
            Write-Host "`n   $text`:`n" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{F81E9010-6EA4-11CE-A7FF-00AA003CA9F6}'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked' -Name '{F81E9010-6EA4-11CE-A7FF-00AA003CA9F6}'
        }
    }

    if ( 'DisableRemote' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s33 ) { $L.s33 } else { "Отключение NetMeeting, Remote MDM, Remote WinRM, Удаленную Помощь" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            $text = if ( $L.s34 ) { $L.s34 } else { "Отключение NetMeeting" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            # Комп\Адм. Шабл\Компоненты Windows\NetMeeting\ "Запретить удаленное управление рабочим столом" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Conferencing' -Name 'NoRDS' -Type DWord 1

            $text = if ( $L.s35 ) { $L.s35 } else { "Отключение Remote MDM" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            # Комп\Адм. Шабл\Компоненты Windows\MDM\ "Отключить регистрацию для MDM" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\MDM' -Name 'DisableRegistration' -Type DWord 1

            $text = if ( $L.s36 ) { $L.s36 } else { "Отключение Remote WinRM" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            # Комп\Адм. Шабл\Компоненты Windows\Удаленная оболочка Windows\ "Разрешить доступ к удаленной оболочке" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS' -Name 'AllowRemoteShellAccess' -Type DWord 0

            $text = if ( $L.s37 ) { $L.s37 } else { "Отключение Удаленной Помощи" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'RemoteRegistry' -StartupType Disabled
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask'

            # Комп\Адм. Шабл\Система\Удаленный помощник\ "Настроить запрашиваемую удаленную помощь" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'fAllowToGetHelp' -Type DWord 0

            # Комп\Адм. Шабл\Система\Удаленный помощник\ "Настроить предлагаемую удаленную помощь" (Отключена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'fAllowUnsolicited' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowFullControl' -Type DWord 0

            $text = if ( $L.s38 ) { $L.s38 } else { "Установка 2 дополнительных служб в ручной режим" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'TrkWks' -StartupType Manual
            Set-Svc -Do:$Act Set-Service -Name 'IKEEXT' -StartupType Manual
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s39 ) { $L.s39 } else { "Восстановление NetMeeting, Remote MDM, Remote WinRM, Удаленной Помощи (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Conferencing' -Name 'NoRDS'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\MDM' -Name 'DisableRegistration'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WinRM\Service\WinRS' -Name 'AllowRemoteShellAccess'
            Set-Svc Set-Service -Name 'RemoteRegistry' -StartupType Disabled
            Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\RemoteAssistance\RemoteAssistanceTask'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'fAllowToGetHelp'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' -Name 'fAllowUnsolicited'
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowFullControl' -Type DWord 1
            Set-Svc Set-Service -Name 'TrkWks' -StartupType Automatic
            Set-Svc Set-Service -Name 'IKEEXT' -StartupType Automatic
        }
    }

    if ( 'DisableAdmRes' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s40 ) { $L.s40 } else { "Отключение Общих Административных Ресурсов, Кроме IPC$ и созданных вами" }
            Write-Host "`n   $text" -ForegroundColor DarkCyan

            $text = if ( $L.s41 ) { $L.s41 } else { "некоторым средствам резервного копирования необходим к ним доступ" }
            Write-Host "   $text`:`n" -ForegroundColor DarkGray

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'AutoShareWks' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'AutoShareServer' -Type DWord 0
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s42 ) { $L.s42 } else { "Восстановление Общих Административных Ресурсов (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'AutoShareWks'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' -Name 'AutoShareServer'
        }
    }

    if ( 'DisableIPv6' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s43 ) { $L.s43 } else { "Отключение IPv6. Лупбэк для программ будет работать" }
            Write-Host "`n   $text`n" -ForegroundColor DarkCyan

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\TCPIP6\Parameters' -Name 'DisabledComponents' -Type DWord 0xff
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s44 ) { $L.s44 } else { "Восстановление IPv6 (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\services\TCPIP6\Parameters' -Name 'DisabledComponents'
        }
    }

    if ( 'DisableDnsFunctions' -in $Options )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s44_1 ) { $L.s44_1 } else { "Отключение Функций DNS" }
            Write-Host "`n   $text`n" -ForegroundColor DarkCyan

            # ГП: Административные шаблоны\Компоненты Windows\Сеть\DNS-клиент "Отключить многоадресное разрешение имен и улучшенное" Отключить
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'DisableSmartNameResolution' -Type DWord 1
            # Нет в ГП. Отключение прослушки порта 5353 службой dnscache и периодические соединения к 224.0.0.251
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMDNS' -Type DWord 0

            # Сбросить настройки прокси сервера:
            if ( $Act -eq 'Set' )
            {
                Write-Host "`n   $env:SystemDrive\Windows\System32\netsh.exe winhttp reset proxy" -ForegroundColor DarkGray
                try { & "$env:SystemDrive\Windows\System32\netsh.exe" winhttp reset proxy } catch {}
            }
            # ГП: Административные шаблоны\Компоненты Windows\Сеть\DNS-клиент "Регрессирование основного DNS-суффикса" Отключить
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'UseDomainNameDevolution' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -Name 'UseDomainNameDevolution' -Type DWord 0

            # Решает проблему разделения DNS для VPN при подключенном VPN
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters' -Name 'DisableParallelAandAAAA' -Type DWord 1
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s44_2 ) { $L.s44_2 } else { "Восстановление Функций DNS (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'DisableSmartNameResolution'
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMDNS'

            # Сбросить настройки прокси сервера:
            Write-Host "`n   $env:SystemDrive\Windows\System32\netsh.exe winhttp reset proxy" -ForegroundColor DarkGray
            try { & "$env:SystemDrive\Windows\System32\netsh.exe" winhttp reset proxy } catch {}
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'UseDomainNameDevolution'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters' -Name 'UseDomainNameDevolution'

            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters' -Name 'DisableParallelAandAAAA'
        }
    }

    if ( 'EnableUnBlockSites' -in $Options )
    {
        if ( -not ( 'WinAPI.Internet' -as [type] ))
        {
            $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
            $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
            $cp.GenerateInMemory = $true
            $cp.CompilerOptions = '/platform:anycpu /nologo'

            Add-Type -TypeDefinition $InternetSettingsRefreshAPI -ErrorAction Stop -Language CSharp -CompilerParameters $cp
        }

        if ( $Act -ne 'Default' )
        {
            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-UnBlock-WebSites\s*=\s*1\s*=\s*(?<Adress>[^\r\n]+)==' },'First',1) )
            {
                [string] $PresetUnBlockAdress = $Matches.Adress.Trim()
            }
            else { [string] $PresetUnBlockAdress = '' }

            try { [string] $UnBlockAdress = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings','AutoConfigURL',$null) }
            catch { [string] $UnBlockAdress = '' }

            if ( $PresetUnBlockAdress )
            {
                if ( $PresetUnBlockAdress -eq $UnBlockAdress )
                {
                    $text = if ( $L.s45 ) { $L.s45 } else { "Обход блокировок сайтов уже включён" }
                    Write-Host "`n    $text " -ForegroundColor Green -NoNewline

                    $text = if ( $L.s45_1 ) { $L.s45_1 } else { "Адрес" }
                    Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline

                    Write-Host "$PresetUnBlockAdress" -ForegroundColor White
                }
                else
                {
                    $text = if ( $L.s46 ) { $L.s46 } else { "Включение обхода блокировок сайтов" }
                    Write-Host "`n   $text`n" -ForegroundColor DarkCyan

                    # Задаем полученный из пресетов адрес
                    [string] $Adress = $PresetUnBlockAdress

                    # Устанвливаем адрес для настроек.
                    [string] $Value = $Adress
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoConfigURL' -Type String $Value

                    # Получаем длину строки адреса (Decimal)
                    [int] $AdressLenght = $Adress.Length

                    # Переводим строку адреса в массив символов, а символы в байты (Decimal)
                    [byte[]] $AdressBytes = $Adress.ToCharArray().ForEach({ [Convert]::ToUInt32($_) })

                    # Создаем параметр для Сетевых настроек 'DefaultConnectionSettings', в правильном формате Binary [byte[]] (Decimal).
                    [byte[]] $Value = 70,0,0,0,1,0,0,0,13,0,0,0,0,0,0,0,0,0,0,0,$AdressLenght,0,0,0 + $AdressBytes + 1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

                    # Устанавливаем его.
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections' -Name 'DefaultConnectionSettings' -Type Binary $Value

                    # Изменяем 5 байт для параметра 'SavedLegacySettings', для него нужен инкремент числа (+1 от 'DefaultConnectionSettings). И Устанавливаем его.
                    $Value[4] = 2
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections' -Name 'SavedLegacySettings' -Type Binary $Value

                    # Применяем остальные параметры.
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'WarnOnIntranet' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\1' -Name 'Flags' -Type DWord 211
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\1' -Name 'CurrentLevel' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'AutoDetect' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'IntranetName' -Type DWord 1
                    Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'UNCAsIntranet' -Type DWord 1
                    Set-Reg -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'ProxyBypass'

                    if ( $Act -eq 'Set' ) { [WinAPI.Internet]::SettingsRefresh() > $null }
                }
            }
            else
            {
                $text = if ( $L.s47 ) { $L.s47 } else { "Нет адреса в пресетах для обхода блокировок сайтов" }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
            }
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s48 ) { $L.s48 } else { "Удаление обхода блокировок сайтов (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'AutoConfigURL'

            [byte[]] $Value = 70,0,0,0,1,0,0,0,9,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0

            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections' -Name 'DefaultConnectionSettings' -Type Binary $Value

            $Value[4] = 2

            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections' -Name 'SavedLegacySettings' -Type Binary $Value

            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name 'WarnOnIntranet' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\1' -Name 'Flags' -Type DWord 219
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Zones\1' -Name 'CurrentLevel' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'AutoDetect' -Type DWord 0
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'IntranetName' -Type DWord 1
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'UNCAsIntranet' -Type DWord 1
            Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap' -Name 'ProxyBypass' -Type DWord 1

            [WinAPI.Internet]::SettingsRefresh() > $null
        }
    }

    if ( 'ConfigNCSI' -in $Options )
    {
        try { [string] $NlaSvcDepend = ([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NlaSvc','DependOnService',$null) -join '').Trim() }
        catch { [string] $NlaSvcDepend = $null }

        if ( $Act -ne 'Default' )
        {
            if ( $Act -eq 'Set' )
            {
                $text = if ( $L.s49 ) { $L.s49 } else { "Настройка NCSI (Индикатор Статуса Сетевого Подключения)" }
                Write-Host "`n   $text`n" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s50 ) { $L.s50 } else { "Проверка NCSI (Индикатор Статуса Сетевого Подключения)" }
                Write-Host "`n   $text`n" -ForegroundColor Cyan
            }

            if ( $ListPresetsGlobal.Where({ $_ -match '^\s*Set-Network-Indicator\s*=\s*1\s*=\s*(?<Name>[^\r\n]+)==' },'First',1) )
            {
                [string] $NameNCSI = $Matches.Name.Trim()
            }
            else { [string] $NameNCSI = '' }

            if ( $NameNCSI -eq 'Debian NCSI' )
            {
                Write-Host "   $NameNCSI`n" -ForegroundColor DarkCyan

                if ( $NlaSvcDepend )
                {
                    Set-Svc -Do:$Act Set-Service -Name 'NlaSvc' -StartupType Automatic
                }
                else
                {
                    Set-Svc -Do:$Act Set-Service -Name 'NlaSvc' -StartupType Manual
                }

                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'NoActiveProbe'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'DisablePassivePolling'

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'EnableActiveProbing' -Type DWord 1

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContent' -Type String '208.67.222.222'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContentV6' -Type String '2620:119:35::35'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHost' -Type String 'resolver1.opendns.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHostV6' -Type String 'resolver1.opendns.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContent' -Type String "NetworkManager is online`n"
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContentV6' -Type String "NetworkManager is online`n"
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHost' -Type String 'network-test.debian.org'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHostV6' -Type String 'network-test.debian.org'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePath' -Type String 'nm'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePathV6' -Type String 'nm'
            }
            elseif ( $NameNCSI -eq 'Firefox NCSI' )
            {
                Write-Host "   $NameNCSI`n" -ForegroundColor DarkCyan

                if ( $NlaSvcDepend )
                {
                    Set-Svc -Do:$Act Set-Service -Name 'NlaSvc' -StartupType Automatic
                }
                else
                {
                    Set-Svc -Do:$Act Set-Service -Name 'NlaSvc' -StartupType Manual
                }

                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'NoActiveProbe'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'DisablePassivePolling'

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'EnableActiveProbing' -Type DWord 1

                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContent' -Type String '208.67.222.222'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContentV6' -Type String '2620:119:35::35'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHost' -Type String 'resolver1.opendns.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHostV6' -Type String 'resolver1.opendns.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContent' -Type String "success`n"
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContentV6' -Type String "success`n"
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHost' -Type String 'detectportal.firefox.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHostV6' -Type String 'detectportal.firefox.com'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePath' -Type String 'success.txt'
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePathV6' -Type String 'success.txt'
            }
            else
            {
                if ( $NameNCSI )
                {
                    $text = if ( $L.s51 ) { $L.s51 } else { "Пропуск настройки NCSI" }
                    Write-Host "`n   $text`: $NameNCSI`n" -ForegroundColor DarkGray
                }
                else
                {
                    $text = if ( $L.s52 ) { $L.s52 } else { "Отключена настройка NCSI" }
                    Write-Host "`n   $text`n" -ForegroundColor DarkGray
                }
            }
        }
        else
        {
            # Восстановления По умолчанию.

            $text = if ( $L.s53 ) { $L.s53 } else { "Восстановление NCSI (Индикатор Статуса Сетевого Подключения) | По умолчанию" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            if ( $NlaSvcDepend )
            {
                Set-Svc Set-Service -Name 'NlaSvc' -StartupType Automatic
            }
            else
            {
                Set-Svc Set-Service -Name 'NlaSvc' -StartupType Manual
            }

            # Конфигурация компьютера \ Административные шаблоны \ Система \ Управление связью через Интернет \ Параметры связи с Интернетом \ Отключение активных тестов индикатора состояния сетевого подключения Windows
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'NoActiveProbe'
            # Конфигурация компьютера \ Административные шаблоны \ Сеть \ Индикатор состояния сетевого подключения \ Укажите пассивный опрос
            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkConnectivityStatusIndicator' -Name 'DisablePassivePolling'
            
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'EnableActiveProbing' -Type DWord 1

            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContent' -Type String '131.107.255.255'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeContentV6' -Type String 'fd3e:4f5a:5b81::1'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHost' -Type String 'dns.msftncsi.com'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveDnsProbeHostV6' -Type String 'dns.msftncsi.com'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContent' -Type String 'Microsoft Connect Test'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeContentV6' -Type String 'Microsoft Connect Test'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHost' -Type String 'www.msftconnecttest.com'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbeHostV6' -Type String 'ipv6.msftconnecttest.com'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePath' -Type String 'connecttest.txt'
            Set-Reg New-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Services\NlaSvc\Parameters\Internet' -Name 'ActiveWebProbePathV6' -Type String 'connecttest.txt'
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s100 ) { $L.s100 } else { "Необходимо перезагрузиться!" }
        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
