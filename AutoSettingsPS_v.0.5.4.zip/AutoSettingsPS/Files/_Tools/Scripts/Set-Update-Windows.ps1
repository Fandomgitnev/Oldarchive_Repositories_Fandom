﻿
<#
.SYNOPSIS
 Настройка Центра Обновлений (Windows Update)
 Несколько предустановленных вариантов.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Set_Update_Windows

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-LGP для установки параметров реестра, с проверкой и выводом результата.
 Set-LGP настраивает параметры через утилиту LGPO.exe, поэтому все параметры будут отображены в оснастке ГП.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.
 Используется функция Set-SettingsPageVisibility для скрытия окон настроек из Параметров, с проверкой и выводом результата.
 Используется функция Get-Task-FullPaths для получения для отключения всех задач в разделе UpdateOrchestrator

.EXAMPLE
    Set-Update-Windows -Act Set -Option Disable -ApplyGP

    Описание
    --------
    Полное отключение обновлений.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  07-04-2019
 ===============================================

#>
Function Set-Update-Windows {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'Disable', 'Notify', 'Manual', 'ClearCache', 'ClearCacheAll', 'EnableOtherMS', 'DisableLangUpdate' )]
        [string] $Option = 'Manual'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set' )]
        [switch] $ApplyGP
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'Update', 'Delivery', 'HideUpdate', 'HideDelivery', 'OtherMS', 'StubFile' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( $CheckState -eq 'Update' )
        {
            [int] $Disable = $Disable1 = $Disable2 = $Disable3 = $Manual1 = $Manual2 = $Auto = 0

            try { [int] $Disable1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','DisableWindowsUpdateAccess',$null) } catch {}
            try { [int] $Disable2 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','SetDisableUXWUAccess',$null) } catch {}
            try { [int] $Disable3 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','DoNotConnectToWindowsUpdateInternetLocations',$null) } catch {}

            try { [int] $Manual1 = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU','NoAutoUpdate',$null) } catch {}
            try { [int] $Manual2 = [Microsoft.Win32.Registry]::GetValue('HKEY_CURRENT_USER\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer','NoAutoUpdate',$null) } catch {}

            try { [int] $Auto = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU','AUOptions',$null) } catch {}

            try { [int] $Disable = $Disable1 + $Disable2 + $Disable3 } catch { [int] $Disable = 0 }
            try { [int] $Manual  = $Manual1 + $Manual2               } catch { [int] $Manual  = 0 }

            if     ( 3 -eq $Disable )  {    "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { "Отключены все параметры             " }) }
            elseif ( $Disable       )  {   "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { "Отключены (Не все параметры)        " }) }
            elseif ( $Manual        )  {   "#Yellow#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { "Вручную                             " }) }
            else
            {
                if     ( 2 -eq $Auto ) { "#DarkCyan#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { "Уведомление о наличии               " }) }
                elseif ( 3 -eq $Auto ) {   "#Yellow#{0}#" -f $(if ( $L.s5 ) { $L.s5 } else { "Загрузка и Уведомление об установке " }) }
                elseif ( 4 -eq $Auto ) {   "#Yellow#{0}#" -f $(if ( $L.s6 ) { $L.s6 } else { "Автозагрузка и установка            " }) }
                elseif ( 5 -eq $Auto ) {      "#Red#{0}#" -f $(if ( $L.s7 ) { $L.s7 } else { "По умолчанию                        " }) }  # Не верно, поэтому дефолт
                else                   {   "#Yellow#{0}#" -f $(if ( $L.s8 ) { $L.s8 } else { "По умолчанию                        " }) }  # Дефолт
            }
        }
        elseif ( $CheckState -eq 'Delivery' )
        {
            try { $Delivery = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization','DODownLoadMode',$null)
            } catch { $Delivery = $null }

            if     (   0 -eq $Delivery ) {  "#Green#{0}#" -f $(if ( $L.s9  ) { $L.s9  } else { "HTTP, без пиринга      " }) }
            elseif (   1 -eq $Delivery ) { "#Yellow#{0}#" -f $(if ( $L.s10 ) { $L.s10 } else { "HTTP + (Локальная сеть)" }) }
            elseif (   2 -eq $Delivery ) { "#Yellow#{0}#" -f $(if ( $L.s11 ) { $L.s11 } else { "HTTP + (Частная группа)" }) }
            elseif (   3 -eq $Delivery ) { "#Yellow#{0}#" -f $(if ( $L.s12 ) { $L.s12 } else { "HTTP + Интернет пиринг " }) }
            elseif (  99 -eq $Delivery ) {  "#Green#{0}#" -f $(if ( $L.s13 ) { $L.s13 } else { "HTTP, без пиринга      " }) }
            elseif ( 100 -eq $Delivery ) {  "#Green#{0}#" -f $(if ( $L.s14 ) { $L.s14 } else { "Отключено              " }) }
            else                         { "#Yellow#{0}#" -f $(if ( $L.s15 ) { $L.s15 } else { "По умолчанию           " }) }
        }
        elseif ( $CheckState -eq 'HideUpdate' )
        {
            Set-SettingsPageVisibility -Names 'windowsupdate' -Act Check -CheckOutForMenu
        }
        elseif ( $CheckState -eq 'HideDelivery' )
        {
            Set-SettingsPageVisibility -Names 'delivery-optimization' -Act Check -CheckOutForMenu
        }
        elseif ( $CheckState -eq 'OtherMS' )
        {
            [int[]] $RegWU = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\7971F918-A847-4430-9279-4A52D1EFE18D','RegisteredWithAU',0),
                             [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\Pending\7971F918-A847-4430-9279-4A52D1EFE18D','RegisterWithAU',0)

            if ( $RegWU -like 1 )
            {
                "#Green#{0}#"  -f $(if ( $L.s15_1 ) { $L.s15_1 } else { "Включено " })
            }
            else
            {
                "#Yellow#{0}#" -f $(if ( $L.s15_2 ) { $L.s15_2 } else { "Отключено" })
            }
        }
        elseif ( $CheckState -eq 'StubFile' )
        {
            [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
           
            if ( [System.IO.File]::Exists($File) )
            {
                "#Green#{0}#"    -f $(if ( $L.s17_2 ) { $L.s17_2 } else { "Создан   " })
            }
            else
            {
                "#DarkGray#{0}#" -f $(if ( $L.s17_3 ) { $L.s17_3 } else { "Не Создан" })
            }
        }

        Return
    }


    if ( $Act -ne 'Default' )
    {
        $text = if ( $L.s16 ) { $L.s16 } else { "Настройка Центра Обновлений Windows" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Option -eq 'Disable' )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { "Отключение Обновления Полностью" }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            $text = if ( $L.s18 ) { $L.s18 } else { "Служба wuauserv, нужна для некоторых типов активаций Windows" }
            Write-Host "`n   $text`:" -ForegroundColor DarkGray

            # Проблема: Служба 'wuauserv' нужна для некоторых типов активаций Windows
            # Problem: The 'wuauserv' service is needed for some types of Windows activations
            Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Disabled -Status Stopped -OrigCmdlet

            # Проблема: Принудительная остановка службы 'UsoSvc' приводит к зависанию почти всех функций и элементов системы, тогда только ресет. Эта служба включает задачу Scheduled Start.
            # Problem: Forcing the 'UsoSvc' service to stop causes almost all functions and elements of the system to freeze, then only reset. This service includes the Scheduled Start task.
            Set-Svc -Do:$Act Set-Service -Name 'UsoSvc' -StartupType Disabled -OrigCmdlet
            Set-Svc -Do:$Act Set-Service -Name 'uhssvc' -StartupType Disabled -OrigCmdlet
            Set-Svc -Do:$Act Set-Service -Name 'WaaSMedicSvc' -StartupType Disabled -Status Stopped
            Set-Svc -Do:$Act Set-Service -Name 'DoSvc' -StartupType Disabled -Status Stopped
            Set-Svc -Do:$Act Set-Service -Name 'BITS' -StartupType Disabled -Status Stopped

            [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"

            if ( -not ( [System.IO.File]::Exists($File) ))
            {
                $text = if ( $L.s17_1 ) { $L.s17_1 } else { "Создание файла-заглушки" }
                Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$File" -ForegroundColor DarkGray

                try
                { 
                    Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
                    New-Item -ItemType File -Path $File -Force -ErrorAction SilentlyContinue > $null
                    (Get-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                }
                catch {}

                if ( [System.IO.File]::Exists($File) )
                {
                    $text = if ( $L.s17_2 ) { $L.s17_2 } else { "Создан" }
                    Write-Host "   $text`n" -ForegroundColor DarkGreen
                }
                else
                {
                    $text = if ( $L.s17_3 ) { $L.s17_3 } else { "Не Создан" }
                    Write-Host "   $text`n" -ForegroundColor Yellow
                }
            }
            else
            {
                $text = if ( $L.s17_4 ) { $L.s17_4 } else { "Файл-заглушка существует" }
                Write-Host "`n   $text`: " -ForegroundColor DarkGreen -NoNewline
                Write-Host "$File`n" -ForegroundColor DarkGray
            }

            if ( $Act -eq 'Set' )
            {
                & LODCTR.exe /D:BITS

                if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like "*BITS*(Disabled)" )
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { "  Выполнено" }
                    Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                    Write-Host "     BITS " -ForegroundColor White -NoNewline
                    Write-Host "| $BITS" -ForegroundColor DarkGray
                }
            }

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'

            # Отключение всех найденных в UpdateOrchestrator задач, так как их названия и количество все время меняется.
            Get-Task-FullPaths -LikeName \Microsoft\Windows\UpdateOrchestrator\* -CompareFullPath | ForEach-Object {

                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $_
            }

            # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить доступ ко всем компонентам Центра обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Запретить доступ для использования любых средств Центра обновления Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'SetDisableUXWUAccess' -Type DWord 1

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Отключена) (ручной режим)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не подключаться к расположениям Центра обновления Windows в Интернете" (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations' -Type DWord 1

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Уазать размещение службы обновлений Майкрософт в интрасети ..." (Включена)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUServer' -Type String '-'
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUStatusServer' -Type String '-'
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'UpdateServiceUrlAlternate' -Type String '-'

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Включена, HTTP, без пиринга)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name 'DODownLoadMode' -Type DWord 0

            Set-SettingsPageVisibility -Act:$Act -Names 'windowsupdate', 'delivery-optimization'

            if ( $Act -eq 'Set' )
            {
                Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Disabled -Status Stopped -OrigCmdlet
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
            }
        }
        elseif (( $Option -eq 'Notify' ) -or ( $Option -eq 'Manual' ))
        {
            if ( $Option -eq 'Notify' )
            {
                $text = if ( $L.s20 ) { $L.s20 } else { "Проверять и только сообщать о наличии обновлений" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s21 ) { $L.s21 } else { "Ручная Установка Обновлений" }
                Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan
            }

            # Так как состояние служб все время меняется при включенных режимах, то будет сообщаться только если отключено.
            # Иначе проверяться будет полученное состояние, чтобы выводилось, что все нормально, при любом состоянии, кроме отключено.
            if ( $Act -eq 'Check' )
            {
                [string[]] $Services = 'wuauserv', 'BITS', 'DoSvc', 'UsoSvc', 'uhssvc'

                foreach ( $Service in $Services )
                {
                    [string] $SvcState = Check-State-Service $Service -Return Value

                    [string] $Name = $Service

                    if ( 'Disabled' -eq $SvcState )
                    {
                        Set-Svc -Do:$Act Set-Service -Name $Name -StartupType Manual
                    }
                    elseif ( $SvcState )
                    {
                        [string] $StartupType = $SvcState

                        try
                        {
                            Set-Svc -Do:$Act Set-Service -Name $Name -StartupType $StartupType
                        }
                        catch {}
                    }
                }

                [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
                if ( [System.IO.File]::Exists($File) )
                {
                    $text = if ( $L.s17_4 ) { $L.s17_4 } else { "Файл-заглушка существует" }
                    Write-Host "`n   $text`: " -ForegroundColor Yellow -NoNewline
                    Write-Host "$File`n" -ForegroundColor DarkGray

                    $NeedFix
                }
            }
            else
            {
                # Иначе Set - настройка служб

                [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
                if ( [System.IO.File]::Exists($File) )
                {
                    $text = if ( $L.s17_5 ) { $L.s17_5 } else { "Удаление файла-заглушки" }
                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$File`n" -ForegroundColor DarkGray

                    Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
                }

                Set-Svc -Do:$Act Set-Service -Name 'wuauserv' -StartupType Manual -Status Running
                Set-Svc -Do:$Act Set-Service -Name 'BITS' -StartupType Manual
                Set-Svc -Do:$Act Set-Service -Name 'DoSvc' -StartupType Manual

                Set-Svc -Do:$Act Set-Service -Name 'UsoSvc' -StartupType DelayedAuto -Status Running
                Set-Svc -Do:$Act Set-Service -Name 'uhssvc' -StartupType DelayedAuto
            }

            if ( $Act -eq 'Set' )
            {
                & LODCTR.exe /E:BITS

                if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like "*BITS*(Enabled)" )
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { "  Выполнено" }
                    Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                    Write-Host "     BITS " -ForegroundColor White -NoNewline
                    Write-Host "| $BITS" -ForegroundColor DarkGray
                }
            }

            if ( $Act -eq 'Set' )
            {
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'

                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Backup Scan'
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Maintenance Install'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Download'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Install'
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Reboot'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Report policies'
                Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Work'
            }

            if ( $Act -eq 'Check' )
            {
                # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет\ "Отключить доступ ко всем компонентам Центра обновления Windows" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DisableWindowsUpdateAccess'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Запретить доступ для использования любых средств Центра обновления Windows" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'SetDisableUXWUAccess'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Не подключаться к расположениям Центра обновления Windows в Интернете" (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'DoNotConnectToWindowsUpdateInternetLocations'

                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUServer'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'WUStatusServer'
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'UpdateServiceUrlAlternate'

                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Уазать размещение службы обновлений Майкрософт в интрасети ..." (Не задано)
                Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'UseWUServer'
            }
            elseif ( $Act -eq 'Set' )
            {
                try { [int] $DriverExcl = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null) }
                catch { [int] $DriverExcl = 0 }

                try { $ManagePreviewBuilds = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ManagePreviewBuilds',$null) }
                catch { $ManagePreviewBuilds = $null }
                try { $ManagePreviewBuildsPolicy = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ManagePreviewBuildsPolicyValue',$null) }
                catch { $ManagePreviewBuildsPolicy = $null }

                # Удаление всего раздела, для очистки параметров из ГП, так как удаление параметра воспринимается в некоторых политиках как "Отключено", а не как "Не задано"!
                Set-LGP -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
                Set-LGP -Do:$Act Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'

                # Если есть политика исключения драйверов, то установка его обратно, после удаления всего раздела из политики.
                if ( $DriverExcl )
                {
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1
                }

                if ( [int32]::TryParse("$ManagePreviewBuilds",[ref]$null) -and [int32]::TryParse("$ManagePreviewBuildsPolicy",[ref]$null) )
                {
                    # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\Центр обновления Windows для бизнеса "Управлять предварительными сборками"
                    $Value = $ManagePreviewBuilds
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuilds' -Type DWord $Value
                    $Value = $ManagePreviewBuildsPolicy
                    Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ManagePreviewBuildsPolicyValue' -Type DWord $Value
                }
            }

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows"
            Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate'

            if ( $Option -eq 'Manual' )
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Отключено)
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 1
            }
            elseif ( $Option -eq 'Notify' )
            {
                # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Настройка автоматического обновления" (Включено, Уведомление о наличии)
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'NoAutoUpdate' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'AUOptions' -Type DWord 2
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallDay' -Type DWord 0
                Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'ScheduledInstallTime' -Type DWord 3
            }

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Частота поиска автоматических обновлений" (Отключено)
            # Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'DetectionFrequencyEnabled' -Type DWord 0

            # Комп\Адм. Шабл\Компоненты Windows\Центр обновления Windows\ "Включить рекомендуемые обновления через автоматическое обновление" (Не задано) Работает только при автоматическом обновлении!
            # Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU' -Name 'IncludeRecommendedUpdates'

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Включено, HTTP, без пиринга)
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' -Name 'DODownLoadMode' -Type DWord 0

            Set-SettingsPageVisibility -Act:$Act -Remove -Names 'windowsupdate', 'delivery-optimization'
        }
        elseif ( $Option -like 'ClearCache*' )
        {
            if ( $Act -eq 'Set' )
            {
                if ( $Option -eq 'ClearCacheAll' )
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { "Полная Очистка Кэша Обновлений" }
                    Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

                    [string] $DataStoreMatch  = '==========='
                }
                else
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { "Очистка Кэша Обновлений (без журнала обновлений)" }
                    Write-Host "`n   $text`:`n" -ForegroundColor DarkCyan

                    [string] $DataStoreMatch = '\\SoftwareDistribution\\DataStore$|\\USOPrivate\\UpdateStore\\'
                }

                [hashtable] $SvcDefault = @{

                    'wuauserv' = 'Manual'
                    'UsoSvc'   = 'DelayedAuto'
                    'uhssvc'   = 'DelayedAuto'
                    'BITS'     = 'Manual'
                    'CryptSvc' = 'Automatic'
                }

                # Сохранение состояния и статуса службы, чтобы воспроизвести его после выполнения
                [array] $CheckSVC = @()
                foreach ( $Name in 'wuauserv','UsoSvc','BITS','CryptSvc','uhssvc' )
                {
                    $CheckSVC += [PSCustomObject] @{ 
                        Name        = $Name
                        StartupType = (Check-State-Service $Name -Return Value)
                        Status      = (Check-State-Service $Name -Return Value -CheckStatus).Trim()
                        Default     = $SvcDefault.$Name
                    }
                }

                Set-Svc Set-Service -Name 'wuauserv' -Status Stopped
                Set-Svc Set-Service -Name 'BITS' -Status Stopped
                Set-Svc Set-Service -Name 'CryptSvc' -Status Stopped
                Set-Svc Set-Service -Name 'UsoSvc' -Status Stopped
                Set-Svc Set-Service -Name 'uhssvc' -Status Stopped

                [string[]] $Paths = "$env:SystemRoot\SoftwareDistribution\",
                                    "$env:ProgramData\USOPrivate\UpdateStore\",
                                    "$env:SystemRoot\System32\catroot2\"

                Token-Impersonate -Token SYS

                foreach ( $Path in ( $Paths -notmatch $DataStoreMatch ))
                {
                    $text = if ( $L.s24 ) { $L.s24 } else { "Удаление кэша в" }
                    Write-Host "`n   $text '$Path'" -ForegroundColor DarkCyan

                    # Отсутствие папки может приводить к большим и не явным проблемам
                    if ( -not [System.IO.Directory]::Exists($Path) )
                    {
                        try { New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop > $null }
                        catch
                        {
                            Write-Warning "New-Item Directory: Error: '$Path'`n`t$($_.exception.Message)"
                        }
                    }

                    (Get-ChildItem -LiteralPath $Path -Force -ErrorAction SilentlyContinue
                        ).FullName.Where({ $_ -notmatch $DataStoreMatch }).ForEach({

                            $text = if ( $L.s25 ) { $L.s25 } else { "      Удаление:" }
                            Write-Host "   $text '$_'" -ForegroundColor DarkGray

                            Remove-Item -LiteralPath "\\?\$_" -Recurse -Force -ErrorAction SilentlyContinue
                        })
                }

                Token-Impersonate -Reset

                Write-Host

                # Восстанавливаем состояние служб, если работала настраиваем полностью как по умолчанию и запускаем
                # Либо просто опять стопаем, чтобы показывало состояние и результат в выводе
                foreach ( $SVC in $CheckSVC )
                {
                    if ( $SVC.StartupType -and $SVC.Status -and $SVC.Default )
                    {
                        $Name = $SVC.Name

                        if ( $SVC.Status -eq 'Running' )
                        {
                            if ( $SVC.StartupType -eq 'Disabled' )
                            {
                                Set-Svc Set-Service -Name $Name -StartupType Disabled
                            }
                            else
                            {
                                $StartupType = $SVC.Default
                                
                                Set-Svc Set-Service -Name $Name -StartupType $StartupType -Status Running
                            }
                        }
                        else
                        {
                            $Name = $SVC.Name
                            #$StartupType = $SVC.StartupType

                            Set-Svc Set-Service -Name $Name -Status Stopped
                        }
                    }
                }

                if ( $CheckSVC.Where({ $_.Name -eq 'wuauserv' }).StartupType -eq 'Disabled' )
                {
                    [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"

                    if ( -not ( [System.IO.File]::Exists($File) ))
                    {
                        $text = if ( $L.s17_1 ) { $L.s17_1 } else { "Создание файла-заглушки" }
                        Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline
                        Write-Host "$File" -ForegroundColor DarkGray

                        try
                        { 
                            Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
                            New-Item -ItemType File -Path $File -Force -ErrorAction SilentlyContinue > $null
                            (Get-Item -LiteralPath $File -Force -ErrorAction SilentlyContinue).Attributes = 'ReadOnly'
                        }
                        catch {}

                        if ( [System.IO.File]::Exists($File) )
                        {
                            $text = if ( $L.s17_2 ) { $L.s17_2 } else { "Создан" }
                            Write-Host "   $text`n" -ForegroundColor DarkGreen
                        }
                        else
                        {
                            $text = if ( $L.s17_3 ) { $L.s17_3 } else { "Не Создан" }
                            Write-Host "   $text`n" -ForegroundColor Yellow
                        }
                    }
                    else
                    {
                        $text = if ( $L.s17_4 ) { $L.s17_4 } else { "Файл-заглушка существует" }
                        Write-Host "`n   $text`: " -ForegroundColor DarkGreen -NoNewline
                        Write-Host "$File`n" -ForegroundColor DarkGray
                    }
                }

                Get-Pause

                Return  # Выход из функции
            }
            else
            {
                $text = if ( $L.s26 ) { $L.s26 } else { "'Check' не предусмотрен для 'ClearCache'" }
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -like 'EnableOtherMS' )
        {
            $text = if ( $L.s27_2 ) { $L.s27_2 } else { "Включение обновления других продуктов MS" }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            try { [int] $ServWU = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                "SYSTEM\CurrentControlSet\Services\wuauserv",'ReadSubTree','QueryValues').GetValue('Start',4)
            } catch { [int] $ServWU = 4 }

            if ( $Act -eq 'Set' )
            {
                # Если служба wuauserv существует и не отключена
                if ( $ServWU -ne 4 )
                {
                    try
                    {
                        # Настройка фоновым процессом, с ограничением по времени 6 сек, и принудительным завершением процесса потом.
                        $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
                        $StartInfo.FileName = 'PowerShell.exe' ; $StartInfo.WindowStyle = 'Hidden' ; $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false
                        $StartInfo.Arguments = "-WindowStyle Hidden -NoLogo -NoProfile -Command (New-Object -ComObject 'Microsoft.Update.ServiceManager').AddService2('7971f918-a847-4430-9279-4a52d1efe18d', 7, '') > `$null"

                        $Process = [System.Diagnostics.Process]::Start($StartInfo)
                        $Process.WaitForExit(6000) > $null
                        try { $Process.Kill() } catch {}
                        $Process.Close()
                    }
                    catch {}

                    $text = if ( $L.s27_3 ) { $L.s27_3 } else { 'Завершено' }
                    
                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
                else
                {
                    $text = if ( $L.s15_4 ) { $L.s15_4 } else { "Пропущено" }
                    
                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
            }
            elseif ( $Act -eq 'Check' )
            {
                # Если служба wuauserv существует и не отключена
                if ( $ServWU -ne 4 )
                {
                    [int[]] $RegWU = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\7971F918-A847-4430-9279-4A52D1EFE18D','RegisteredWithAU',0),
                                     [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Services\Pending\7971F918-A847-4430-9279-4A52D1EFE18D','RegisterWithAU',0)

                    if ( $RegWU -like 1 )
                    {
                        $text = if ( $L.s15_1 ) { $L.s15_1 } else { "Включено " }

                        Write-Host "`n   $text" -ForegroundColor DarkCyan
                    }
                    else
                    {
                        $text = if ( $L.s15_2 ) { $L.s15_2 } else { "Отключено" }

                        Write-Host "`n   $text" -ForegroundColor Yellow

                        $NeedFix = $true
                    }
                }
                else
                {
                    $text = if ( $L.s15_4 ) { $L.s15_4 } else { "Пропущено" }
                    
                    Write-Host "`n   $text" -ForegroundColor DarkGray
                }
            }
        }
        elseif ( $Option -like 'DisableLangUpdate' )
        {
            $text = if ( $L.s28 ) { $L.s28 } else { "Отключение обновления языковых компонентов" }
            Write-Host "`n   $text`:" -ForegroundColor DarkCyan

            Set-Svc -Do:$Act Set-Service -Name 'LxpSvc' -StartupType Disabled -Status Stopped

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Installation'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources'
        }
    }
    else
    {
        # Раздел восстановления По умолчанию.

        $text = if ( $L.s16 ) { $L.s16 } else { "Настройка Центра Обновлений Windows" }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { "Функция" }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

        if ( $Option -eq 'EnableOtherMS' )
        {
            $text = if ( $L.s27_1 ) { $L.s27_1 } else { "Отключение обновления других продуктов MS (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            try { [int] $ServWU = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey(
                "SYSTEM\CurrentControlSet\Services\wuauserv",'ReadSubTree','QueryValues').GetValue('Start',4)
            } catch { [int] $ServWU = 4 }

            if ( $ServWU -ne 4 )
            {
                try
                {
                    # Настройка фоновым процессом, с ограничением по времени 6 сек, и принудительным завершением процесса потом.
                    $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
                    $StartInfo.FileName = 'PowerShell.exe' ; $StartInfo.WindowStyle = 'Hidden' ; $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false
                    $StartInfo.Arguments = "-WindowStyle Hidden -NoLogo -NoProfile -Command (New-Object -ComObject 'Microsoft.Update.ServiceManager').RemoveService('7971f918-a847-4430-9279-4a52d1efe18d') > `$null"

                    $Process = [System.Diagnostics.Process]::Start($StartInfo)
                    $Process.WaitForExit(6000) > $null
                    try { $Process.Kill() } catch {}
                    $Process.Close()
                }
                catch {}

                $text = if ( $L.s27_3 ) { $L.s27_3 } else { 'Завершено' }
                    
                Write-Host "   $text" -ForegroundColor DarkGray
            }
            else
            {
                $text = if ( $L.s15_4 ) { $L.s15_4 } else { "Пропущено" }
                    
                Write-Host "   $text" -ForegroundColor DarkGray
            }
        }
        elseif ( $Option -eq 'DisableLangUpdate' )
        {
            $text = if ( $L.s29 ) { $L.s29 } else { "Восстановление обновления языковых компонентов (По умолчанию)" }
            Write-Host "`n   $text`n" -ForegroundColor Magenta

            Set-Svc Set-Service -Name 'LxpSvc' -StartupType Manual

            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Installation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources'
        }
        else
        {
            $text = if ( $L.s27 ) { $L.s27 } else { "Восстановление обновлений (По умолчанию)" }
            Write-Host "`n   $text`:`n" -ForegroundColor Magenta

            [string] $File = "$env:SystemDrive\Windows\SoftwareDistribution\Download"
            if ( [System.IO.File]::Exists($File) )
            {
                $text = if ( $L.s17_5 ) { $L.s17_5 } else { "Удаление файла-заглушки" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                Write-Host "$File`n" -ForegroundColor DarkGray

                Remove-Item -LiteralPath \\?\$File -Recurse -Force -ErrorAction SilentlyContinue
            }

            Set-Svc Set-Service -Name 'wuauserv' -StartupType Manual -Status Running

            Set-Svc Set-Service -Name 'BITS' -StartupType Manual

            & LODCTR.exe /E:BITS

            if ( [string] $BITS = (& LODCTR.exe /Q:BITS) -like "*BITS*(Enabled)" )
            {
                $text = if ( $L.s19 ) { $L.s19 } else { "  Выполнено" }
                Write-Host "  +:   Set: $text " -ForegroundColor Green -NoNewline
                Write-Host "     BITS " -ForegroundColor White -NoNewline
                Write-Host "| $BITS" -ForegroundColor DarkGray
            }

            Set-Svc Set-Service -Name 'DoSvc' -StartupType Manual
            Set-Svc Set-Service -Name 'UsoSvc' -StartupType DelayedAuto
            Set-Svc Set-Service -Name 'uhssvc' -StartupType DelayedAuto
            # Set-Svc Set-Service -Name 'WaaSMedicSvc' -StartupType Manual

            Set-Svc Set-Service -Name 'LxpSvc' -StartupType Manual

            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\WaaSMedic\PerformRemediation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\WindowsUpdate\Scheduled Start'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Scan Static Task'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\UpdateModelTask'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\USO_UxBroker'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Retry Scan'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Backup Scan'
            Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\UpdateOrchestrator\Maintenance Install'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Download'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\AC Power Install'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Report policies'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\UpdateOrchestrator\Schedule Work'

            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Installation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\Uninstallation'
            Set-Tsk Enable-ScheduledTask  -TaskName '\Microsoft\Windows\LanguageComponentsInstaller\ReconcileLanguageResources'

            try { [int] $DriverExcl = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate','ExcludeWUDriversInQualityUpdate',$null)
            } catch { [int] $DriverExcl = 0 }

            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU'
            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'

            # Если есть политика исключения драйверов, то установка его обратно, после удаления всего раздела из политики.
            if ( $DriverExcl )
            {
                Set-LGP New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'ExcludeWUDriversInQualityUpdate' -Type DWord 1
            }

            # Пользователи\Адм. Шабл\Система\ "Автоматическое обновление Windows" (Не задано)
            Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoAutoUpdate'

            # Комп\Адм. Шабл\Компоненты Windows\Оптимизация доставки\ "Режим скачивания" (Не задано)
            Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization'

            Set-SettingsPageVisibility -Names 'windowsupdate', 'delivery-optimization' -Remove

            try
            {
                # Настройка фоновым процессом, с ограничением по времени 6 сек, и принудительным завершением процесса потом.
                $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
                $StartInfo.FileName = 'PowerShell.exe' ; $StartInfo.WindowStyle = 'Hidden' ; $StartInfo.CreateNoWindow = $true ; $StartInfo.UseShellExecute = $false
                $StartInfo.Arguments = "-WindowStyle Hidden -NoLogo -NoProfile -Command (New-Object -ComObject 'Microsoft.Update.ServiceManager').RemoveService('7971f918-a847-4430-9279-4a52d1efe18d') > `$null"

                $Process = [System.Diagnostics.Process]::Start($StartInfo)
                $Process.WaitForExit(6000) > $null
                try { $Process.Kill() } catch {}
                $Process.Close()
            }
            catch {}
        }
    }

    if ( $ApplyGP )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        if ( $Option -ne 'EnableOtherMS' )
        {
            $text = if ( $L.s30 ) { $L.s30 } else { "Необходимо перезагрузиться!" }
            Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow
        }

        Get-Pause
    }
}
