﻿
# Группы параметров, относящиеся к Телеметрии и Диагностики.
Function Set-Configs-Telemetry {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param( [Parameter( Mandatory = $true,  Position = 0 )] [ValidateSet( 'Set', 'Check', 'Default' )] [string] $Act
          ,[Parameter( Mandatory = $false, Position = 1 )] [switch] $ApplyGP )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение списка подгрупп из файла пресета, с изменением имени или исключением, в зависимости от действия
    [string[]] $Groups = Get-Configs-Groups -Actions $Act -FuncName $NameThisFunction

    [string] $Group = ''   # Для названия группы
    [string] $Info  = ''   # Для описания группы
    [string] $text  = ''   # Для любого текста
    [hashtable] $L = @{}   # Для получения перевода

    [bool] $is64 = [System.Environment]::Is64BitOperatingSystem


    # Далее сами настройки ...



    $Info = 'Отключение Телеметрии. Службы. UnifedTelemetryClient'
    $Group = 'Tel-Services' ; $L = $Lang.$Group

    # Если отключить (настроить) или выполнить проверку.
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Svc -Do:$Act Set-Service -Name 'DiagTrack' -StartupType Disabled -Status Stopped
        Set-Svc -Do:$Act Set-Service -Name 'diagnosticshub.standardcollector.service' -StartupType Disabled -Status Stopped
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        # Иначе восстановить по умолчанию.

        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Svc Set-Service -Name 'DiagTrack' -StartupType Automatic
        Set-Svc Set-Service -Name 'diagnosticshub.standardcollector.service' -StartupType Manual
    }



    $Info = 'Отключение Телеметрии. Основные параметры. UnifedTelemetryClient'
    $Group = 'Tel-Parameters-Global' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        try { [string] $WindowsEdition = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','EditionID',$null)
        } catch { [string] $WindowsEdition = $null }

        if ( $WindowsEdition -match "Enterprise|Education" )
        {
            # Этого параметра нет в ГП, но предлагается для использования самой MS в описании: Configure Windows telemetry in your organization от 04.05.2017
            # Включение режима сбора телеметрии на "Безопасность" ("Security"), если редакция Корпоративная или для Образовательных учреждений.
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry' -Type DWord 0
        }
        else
        {
            # Включение режима сбора телеметрии на "Базовый" ("Basic"), для остальных редакций.
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry' -Type DWord 1
        }

        # Комп\Адм. Шабл\Компоненты Windows\Программа по улучшению качества программного обеспечения Windows "Помечать данные программы по улучшению качества программного обеспечения Windows идентификатором исследования" (отключено)
        Set-LGP -Do:$Act Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'StudyId'

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить программу по улучшению качества программного обеспечения Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Совместимость приложений "Отключение дистанционного отслеживания приложений"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'AITEnable' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Совместимость приложений "Отключение сборщика перечней"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisableInventory' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Совместимость приложений "Отключение средства записи действий" (включено)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' -Name 'DisableUAR' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Сборки для сбора данных и предварительные сборки "Не показывать уведомления об отзывах"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -Name 'AllowDeviceNameInTelemetry' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -Name 'DoNotShowFeedbackNotifications' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -Name 'AllowTelemetry' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\DataCollection' -Name 'AllowTelemetry' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Сборки для сбора данных и предварительные сборки "Отключение средства просмотра диагностических данных"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' -Name 'DisableDiagnosticDataViewer' -Type DWord 1
        # Отключение средства просмотра диагностических данных (При включённом состоянии занимает до 1гб места на диске)
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\EventTranscriptKey' -Name 'EnableEventTranscript' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\SQMClient\Windows' -Name 'CEIPEnable' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\TelemetryController' -Name 'RunsBlocked' -Type DWord 1

        # Запретить телеметрию проверки активации Windows
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\AppID\slui.exe' -Name 'NoGenTicket' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\System' -Name 'AllowExperimentation' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\System\AllowTelemetry' -Name 'value' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Bluetooth' -Name 'AllowAdvertising' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TraceManager' -Name 'MiniTraceSlotEnabled' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\SetupPlatformTel' -Name 'Start' -Type DWord 0


        # Если раздел удалён, то не выполнять его настройку и проверку
        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\DiagTrack').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\DiagTrack' -Name 'Start' -Type DWord 4
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\AutoLogger-Diagtrack-Listener' -Name 'Start' -Type DWord 0
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Diagtrack-Listener' -Name 'Start' -Type DWord 0
        }

        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\LogFiles\WMI","$env:SystemDrive\ProgramData\Microsoft\Diagnosis\ETLLogs\AutoLogger" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -like '*Diagtrack*Listener*.etl*' } | ForEach-Object {

                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }

        Write-Host

        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack" -Name 'DiagTrackAuthorization' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack" -Name 'ConnectivityNoNetworkTime' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack" -Name 'UploadPermissionReceived' -Type DWord 0

        try
        {
            $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-ARIA'
            $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            if ( $OpenKey )
            {
                foreach ( $Name in $OpenKey.GetSubKeyNames() )
                {
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-ARIA\$Name"
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'Enabled' -Type DWord 0

                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TelemetryNamespaces"
                    Set-Reg -Do:$Act Remove-ItemProperty -Path $Path -Name $Name
                }

                $OpenKey.Close()
            }
        }
        catch {}

        try
        {
            $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\SettingsRequests'
            $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            if ( $OpenKey )
            {
                foreach ( $Name in $OpenKey.GetSubKeyNames() )
                {
                    Write-Host
                    $Path = "HKLM:\$SubKey\$Name"
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'DownloadScheduled' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ETag' -Type String ''
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'ETagQueryParameters' -Type String ''
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'RefreshInterval' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'SettingsPriority' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'SettingsRegistrationType' -Type DWord 0
                    Set-Reg -Do:$Act New-ItemProperty -Path $Path -Name 'SettingsType' -Type DWord 0
                }

                $OpenKey.Close()
            }
        }
        catch {}

        # Удаление всех файлов телеметрии .rbs, подготовленных к отправке
        $Path = "$env:ProgramData\Microsoft\Diagnosis"
        if ( [System.IO.Directory]::Exists($Path) )
        {
            Token-Impersonate -Token SYS

            try { Remove-Item -Path \\?\$Path\*.rbs -Force -ErrorAction SilentlyContinue } catch {}

            Token-Impersonate -Reset
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' -Name 'AllowTelemetry'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\DataCollection'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\EventTranscriptKey' -Name 'EnableEventTranscript'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\TelemetryController' -Name 'RunsBlocked'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Classes\AppID\slui.exe' -Name 'NoGenTicket'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\System' -Name 'AllowExperimentation'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\System\AllowTelemetry' -Name 'value'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Bluetooth' -Name 'AllowAdvertising'

        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' -Name 'TailoredExperiencesWithDiagnosticDataEnabled' -Type DWord 0

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TraceManager' -Name 'MiniTraceSlotEnabled' -Type DWord 0



        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Services\DiagTrack').Name )
        {
            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Services\DiagTrack' -Name 'Start' -Type DWord 2
        }

        try
        {
            $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-ARIA'
            $OpenKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            if ( $OpenKey )
            {
                foreach ( $Name in $OpenKey.GetSubKeyNames() )
                {
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\Tenants\P-ARIA\$Name"
                    Set-Reg New-ItemProperty -Path $Path -Name 'Enabled' -Type DWord 1
                }

                $OpenKey.Close()
            }
        }
        catch {}
    }



    $Info = 'Отключить Задачи Телеметрии и диагностики'
    $Group = 'Tel-Tasks' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Задачи 'CEIP' Программы улучшения качества программного обеспечения" | Show-Info -Shift $L.s2 -NotIndent
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver'

        "Задачи контроля и выполнения семейной безопасности" | Show-Info -Shift $L.s3
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Shell\FamilySafetyMonitor'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Shell\FamilySafetyRefreshTask'

        "Задачи сбора телеметрических данных программ" | Show-Info -Shift $L.s4
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\ProgramDataUpdater'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\StartupAppTask'

        "Задача собирает и загружает данные 'SQM' для 'CEIP'" | Show-Info -Shift $L.s5
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Autochk\Proxy'

        "Задачи SIUF (System Initiated User Feedback) Обратная связь с пользователями" | Show-Info -Shift $L.s6
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Feedback\Siuf\DmClient'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload'

        "Задача сборщика полных сведений о компьютере и сети" | Show-Info -Shift $L.s7
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\NetTrace\GatherNetworkInfo'

        "Задача для 'CEIP'" | Show-Info -Shift $L.s8
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\PI\Sqm-Tasks'

        "Задача анализа метаданных мобильной сети" | Show-Info -Shift $L.s9
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser'

        "Задача веб-сайта инфраструктуры диагностики Windows" | Show-Info -Shift $L.s10
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\WDI\ResolutionHost'

        "Задачи сбора и отправки данных об устройствах" | Show-Info -Shift $L.s11
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Device Information\Device'
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Device Information\Device User'

        "Задача DUSM (Data Usage Subscription Management) для мобильного интернета" | Show-Info -Shift $L.s12
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\DUSM\dusmtask'

        "Задача отправки отчетов об ошибках" | Show-Info -Shift $L.s13
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Error Reporting\QueueReporting'

        "Задача отправки диагностики" | Show-Info -Shift $L.s14
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Flighting\OneSettings\RefreshCache'

        "Задача телеметрии Центра обновления" | Show-Info -Shift $L.s15
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\UNP\RunUpdateNotificationMgr'

        "Задача для Поиска рекомендуемых способов устранения неполадок" | Show-Info -Shift $L.s16
        Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Diagnosis\RecommendedTroubleshootingScanner'

    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Shell\FamilySafetyMonitor'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Shell\FamilySafetyRefreshTask'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\ProgramDataUpdater'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Application Experience\StartupAppTask'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Autochk\Proxy'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Feedback\Siuf\DmClient'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\NetTrace\GatherNetworkInfo'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\PI\Sqm-Tasks'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\WDI\ResolutionHost'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Device Information\Device'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Device Information\Device User'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\DUSM\dusmtask'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Windows Error Reporting\QueueReporting'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Flighting\OneSettings\RefreshCache'

        # По умолчанию она отключена:
        Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\UNP\RunUpdateNotificationMgr'

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Diagnosis\RecommendedTroubleshootingScanner'
    }



    $Info = 'Отключение SmartScreen'
    $Group = 'Tel-SmartScreen' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure Windows Defender SmartScreen : Disable
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen' -Type DWord 0

        # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure app install control : Enable
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControlEnabled' -Type DWord 1

        # Computer Configuration > Administrative Templates > Windows Components > Windows Defender SmartScreen > Explorer > Configure app install control : Enable
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControl' -Type String 'Anywhere'

        # Отключение SmartScreen для приложений и файлов
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled' -Type String 'Off'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled' -Type String 'Anywhere'

        # Отключение SmartScreen в IE
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\PhishingFilter' -Name 'EnabledV9' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 0

        if ( Check-State-Registry -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe' -Return Bool )
        {
            # Отключение SmartScreen в Edge Классик
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride' -Type DWord 0
        }

        # Отключение SmartScreen в Edge Chromium
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenEnabled' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -Name 'EnableSmartScreen'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControlEnabled'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen' -Name 'ConfigureAppInstallControl'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'AicEnabled'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\PhishingFilter' -Name 'EnabledV9'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation'
        Set-Reg New-ItemProperty    -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost' -Name 'EnableWebContentEvaluation' -Type DWord 1

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'EnabledV9'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppContainer\Storage\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge\PhishingFilter' -Name 'PreventOverride'

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Edge' -Name 'SmartScreenEnabled'
    }



    $Info = 'Отключить Дополнительные Параметры Телеметрии и диагностики'
    $Group = 'Tel-Parameters-2' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Получение обновлений и телеметрии для средства удаления 'вирусов':" | Show-Info -Shift $L.s2 -NotIndent
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontOfferThroughWUAU' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT' -Name 'DontReportInfectionInformation' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\RemovalTools\MpGears' -Name 'HeartbeatTrackingIndex' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\RemovalTools\MpGears' -Name 'SpyNetReportingLocation' -Type MultiString 'https://0.0.0.0'

        "Дополнительный сбор телеметрии:" | Show-Info -Shift $L.s3
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Program-Compatibility-Assistant' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Program-Compatibility-Troubleshooter' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Program-Inventory' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Program-Telemetry' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\Microsoft-Windows-Application-Experience/Steps-Recorder' -Name 'Enabled' -Type DWord 0

        "Дополнительный сбор и отправку данных 'PerfTrack' и 'DiagTrack':" | Show-Info -Shift $L.s4
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\PerfTrack' -Name 'Disabled' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'Disabled' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'DisableAutomaticTelemetryKeywordReporting' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'TelemetryServiceDisabled' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TestHooks' -Name 'DisableAsimovUpLoad' -Type DWord 1

        "Cбор персональных данных:" | Show-Info -Shift $L.s5

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить совместный доступ к данным настройки рукописного ввода"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\TabletPC' -Name 'PreventHandwritingDataSharing' -Type DWord 1

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить совместный доступ к данным настройки рукописного ввода"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\TabletPC' -Name 'PreventHandwritingDataSharing' -Type DWord 1

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить отчеты об ошибках распознавания рукописного текста"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports' -Name 'PreventHandwritingErrorReports' -Type DWord 1

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить совместный доступ к данным настройки рукописного ввода"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\HandwritingErrorReports' -Name 'PreventHandwritingErrorReports' -Type DWord 1

        # Комп\Адм. Шабл\Система\Диагностика\Запланированное обслуживание "Настроить поведение при запланированном обслуживании" Отключено
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\ScheduledDiagnostics' -Name 'EnabledExecution' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\ScheduledDiagnostics' -Name 'EnabledExecution' -Type DWord 0

        "Отключение отправки телеметрии NVIDIA и Задач:" | Show-Info -Shift $L.s6
        Get-Task-FullPaths -LikeName NvTm* | ForEach-Object {

            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $_
        }

        if ( Check-State-Registry -Path 'HKCU:\Software\NVIDIA Corporation\NVControlPanel2\Client' -Return Bool )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\NVIDIA Corporation\NVControlPanel2\Client' -Name 'OptInOrOutPreference' -Type DWord 0
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\MRT'
        Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\RemovalTools\MpGears'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\PerfTrack' -Name 'Disabled'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'Disabled'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'DisableAutomaticTelemetryKeywordReporting'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack' -Name 'TelemetryServiceDisabled'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Diagnostics\DiagTrack\TestHooks' -Name 'DisableAsimovUpLoad'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\TabletPC'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\TabletPC'
        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\HandwritingErrorReports'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\HandwritingErrorReports'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\ScheduledDiagnostics' -Name 'EnabledExecution'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\ScheduledDiagnostics' -Name 'EnabledExecution' -Type DWord 1

        Get-Task-FullPaths -LikeName NvTm* | ForEach-Object {

            Set-Tsk Enable-ScheduledTask -TaskName $_
        }

        if ( Check-State-Registry -Path 'HKCU:\Software\NVIDIA Corporation\NVControlPanel2\Client' -Return Bool )
        {
            Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\NVIDIA Corporation\NVControlPanel2\Client' -Name 'OptInOrOutPreference'
        }
    }



    $Info = 'Отключить Windows Error Reporting | Отправка отчетов об ошибках и данных'
    $Group = 'Tel-ErrorReporting' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'MachineID' -Type String '{00000000-0000-0000-0000-000000000000}'
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\WMR' -Name 'Disabled' -Type DWord 1

        # 0 или 1 = Всегда запрашивать разрешение перед отправкой данных;  2 = Отправлять параметры; 3 = Отправлять параметры и безопасные дополнительные данные; 4 = Отправлять все данные (по умолчанию) 
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\Consent' -Name 'DefaultConsent' -Type DWord 1
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\Consent' -Name 'NewUserDefaultConsent' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting' -Type DWord 1


        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить отчеты об ошибках Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PCHealth\ErrorReporting' -Name 'DoReport' -Type DWord 0

        # Комп\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Отключить отчеты об ошибках Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1
        # Комп\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Не отправлять дополнительные данные"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'DontSendAdditionalData' -Type DWord 1
        # Комп\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Не регулировать отправку дополнительных данных" Отключена (регулировать отчеты)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'BypassDataThrottling' -Type DWord 0
        # Комп\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Запретить автоматическую отправку дампов и отчетов"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'AutoApproveOSDumps' -Type DWord 0


        # Пользователи\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Отключить отчеты об ошибках Windows"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled' -Type DWord 1
        # Пользователи\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Не отправлять дополнительные данные"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'DontSendAdditionalData' -Type DWord 1
        # Пользователи\Адм. Шабл\Компоненты Windows\Отчеты об ошибках Windows "Не регулировать отправку дополнительных данных" Отключена (регулировать отчеты)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Windows\Windows Error Reporting' -Name 'BypassDataThrottling' -Type DWord 0

        # Комп\Адм. Шабл\Система\Диагностика\Быстродействие Windows PerfTrack "Включить или отключить PerfTrack"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}' -Name 'ScenarioExecutionEnabled' -Type DWord 0

        # Комп\Адм. Шабл\Система\Диагностика\Средство диагностики службы технической поддержки Майкрософт "Средство диагностики службы поддержки Майкрософт, режим работы"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{C295FBBA-FD47-46ac-8BEE-B1715EC634E5}' -Name 'ScenarioExecutionEnabled' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{C295FBBA-FD47-46ac-8BEE-B1715EC634E5}' -Name 'DownloadToolsEnabled' -Type DWord 0
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy' -Name 'DisableQueryRemoteServer' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\Windows Error Reporting' -Name 'Disabled'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' -Name 'MachineID'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\WMR' -Name 'Disabled'
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\Consent' -Name 'DefaultConsent' -Type DWord 4
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting\Consent' -Name 'NewUserDefaultConsent'

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing' -Name 'DisableWerReporting'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\PCHealth\ErrorReporting'
        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Error Reporting'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Windows\Windows Error Reporting'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{9c5a40da-b965-4fc3-8781-88dd50a6299d}'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{C295FBBA-FD47-46ac-8BEE-B1715EC634E5}'
        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WDI\{C295FBBA-FD47-46ac-8BEE-B1715EC634E5}'
        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\ScriptedDiagnosticsProvider\Policy'
    }



    $Info = 'Удалить все Отчеты Windows'
    $Group = 'Tel-DeleteReports' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Sub-Group-Telemetry\s*=\s*1\s*=\s*$Group\s*=\s*(?<MB>\d+)\s*=" },'First',1) )
        {
            [string] $MB = $Matches.MB.Trim()
        }
        else { [string] $MB = 100 }

        if ( $Act -eq 'Check' )
        {
            $text = if ( $L.s2 ) { $L.s2 } else { 'Предупреждение от' }
            Write-Host "   $text`: $MB`mb`n" -ForegroundColor DarkGray
        }

        # Очистка отчётов Windows
        [string[]] $Paths = "$env:ProgramData\Microsoft\Windows\WER\ReportArchive",
                            "$env:ProgramData\Microsoft\Windows\WER\ReportQueue",
                            "$env:ProgramData\Microsoft\Windows\WER\Temp",
                            "$env:SystemDrive\Windows\LiveKernelReports"

        $Paths += "$env:USERPROFILE\AppData\Local\Microsoft\Windows\WER"

        if ( $Global:DataAllUsers.Redirects.Value )
        {
            @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                $Paths += "$($_.Profile)\AppData\Local\Microsoft\Windows\WER"
            })
        }

        CleanUp-Files-Folders -Act $Act -Paths $Paths -WarningSize $MB
    }



    $Info = 'Отключить Телеметрию Internet Explorer'
    $Group = 'Tel-IE' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Запретить участие в программе улучшения качества для IE" | Show-Info -Shift $L.s2 -NotIndent

        # Комп\Адм. Шабл\Компоненты Windows\Internet Explorer 'Запретить участие в программе улучшения качества программного обеспечения' (включена)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SQM' -Name 'DisableCustomerImprovementProgram' -Type DWord 0

        # Пользователи\Адм. Шабл\Компоненты Windows\Internet Explorer 'Запретить участие в программе улучшения качества программного обеспечения' (включена)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\SQM' -Name 'DisableCustomerImprovementProgram' -Type DWord 0

        "Отключить рекомендуемые сайты для IE" | Show-Info -Shift $L.s3

        # Комп\Адм. Шабл\Компоненты Windows\Internet Explorer 'Включить рекомендуемые сайты' (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Suggested Sites' -Name 'Enabled' -Type DWord 0

        # Пользователи\Адм. Шабл\Компоненты Windows\Internet Explorer 'Включить рекомендуемые сайты' (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Suggested Sites' -Name 'Enabled' -Type DWord 0

        "Отключить предостовление улучшеных вариантов поиска" | Show-Info -Shift $L.s4
        # Комп\Адм. Шабл\Компоненты Windows\Internet Explorer 'Разрешить службам Майкрософт предоставлять пользователю ...' (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer' -Name 'AllowServicePoweredQSA' -Type DWord 0

        # Пользователи\Адм. Шабл\Компоненты Windows\Internet Explorer 'Разрешить службам Майкрософт предоставлять пользователю ...' (отключить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer' -Name 'AllowServicePoweredQSA' -Type DWord 0

        "Запретить загружать инструменты в режиме InPrivate" | Show-Info -Shift $L.s5
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Internet Explorer\Safety\PrivacIE' -Name 'DisableToolbars' -Type DWord 1

        # Комп\Адм. Шабл\Компоненты Windows\Internet Explorer\Конфиденциальность 'Запретить компьютеру загружать панели инструментов ...' (Включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE' -Name 'DisableToolbars' -Type DWord 1

        # Пользователи\Адм. Шабл\Компоненты Windows\Internet Explorer\Конфиденциальность 'Запретить компьютеру загружать панели инструментов ...' (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Safety\PrivacIE' -Name 'DisableToolbars' -Type DWord 1

        "Всегда отправлять заголовок 'не отслеживать'" | Show-Info -Shift $L.s6

        # Комп\Адм. Шабл\Компоненты Windows\Internet Explorer\Панель управления браузером\Вкладка 'Дополнительно' 'Всегда отправлять заголовок 'Не отслеживать'' (включено)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main' -Name 'DoNotTrack' -Type DWord 1

        # Пользователи\Адм. Шабл\Компоненты Windows\Internet Explorer\Панель управления браузером\Вкладка 'Дополнительно' 'Всегда отправлять заголовок 'Не отслеживать'' (включено)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Main' -Name 'DoNotTrack' -Type DWord 1
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\SQM'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\SQM'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Suggested Sites'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Suggested Sites'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer' -Name 'AllowServicePoweredQSA'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer' -Name 'AllowServicePoweredQSA'

        Set-Reg Remove-Item -Path 'HKCU:\Software\Microsoft\Internet Explorer\Safety\PrivacIE'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Safety\PrivacIE'

        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main'
        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Internet Explorer\Main'
    }



    $Info = 'Отключить Дополнительную отправку отчетов'
    $Group = 'Tel-Reporting' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        "Запретить запуск Windows Messenger и программу улучшения" | Show-Info -Shift $L.s2 -NotIndent

        # Комп\Адм. Шабл\Компоненты Windows\Windows Messenger "Запретить запуск Windows Messenger" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Messenger\Client' -Name 'PreventRun' -Type DWord 1

        # Комп\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить программу улучшения качества программного обеспечения Windows Messenger" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Messenger\Client' -Name 'CEIP' -Type DWord 2

        # Пользователи\Адм. Шабл\Компоненты Windows\Windows Messenger "Запретить запуск Windows Messenger" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Messenger\Client' -Name 'PreventRun' -Type DWord 1

        # Пользователи\Адм. Шабл\Система\Управление связью через Интернет\Параметры связи через Интернет "Отключить программу улучшения качества программного обеспечения Windows Messenger" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Messenger\Client' -Name 'CEIP' -Type DWord 2

        "Отключение веб-проверки AVS (телеметрия активации)" | Show-Info -Shift $L.s3

        # ГП: Компоненты Windows/Платформа защиты программного обеспечения
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Software Protection Platform' -Name 'NoGenTicket' -Type DWord 1

        "Отключить сбор данных фильтрации в InPrivate" | Show-Info -Shift $L.s4
        # ГП: Компоненты Windows/Internet Explorer/Конфиденциальность
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE' -Name 'DisableLogging' -Type DWord 1

        "Отключить возможность отправки отчетов об ошибках" | Show-Info -Shift $L.s5
        # ГП: Компоненты Windows/Internet Explorer/Меню браузера
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main' -Name 'NoReportSiteProblems' -Type String 'yes'
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Messenger\Client' -Name 'PreventRun'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Messenger\Client' -Name 'CEIP'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Messenger\Client' -Name 'PreventRun'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Messenger\Client' -Name 'CEIP'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\CurrentVersion\Software Protection Platform' -Name 'NoGenTicket'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Safety\PrivacIE' -Name 'DisableLogging'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Internet Explorer\Main' -Name 'NoReportSiteProblems'
    }



    $Info = 'Отключить Правописание и исправление слов с ошибками'
    $Group = 'Tel-Spellchecking' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Пользователи\Адм. Шабл\Панель управления\Язык и региональные стандарты "Отключить автоматическое исправление слов с ошибками"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffAutocorrectMisspelledWords' -Type DWord 1

        # Пользователи\Адм. Шабл\Панель управления\Язык и региональные стандарты "Отключить выделение слов с ошибками"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffHighlightMisspelledWords' -Type DWord 1

        # Пользователи\Адм. Шабл\Панель управления\Язык и региональные стандарты "Отключить прогнозирование текста при вводе"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffOfferTextPredictions' -Type DWord 1

        "Проверка правописания, выделения ошибок и прогнозирования:" | Show-Info -Shift $L.s2
        # Комп\Адм. Шабл\Компоненты Windows\Планшет\Панель ввода "Отключить прогнозирование текста" (включить)
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\TabletTip\1.7' -Name 'DisablePrediction' -Type DWord 1
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\TabletTip\1.7' -Name 'DisablePrediction' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableAutocorrection' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableSpellchecking' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableTextPrediction' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnablePredictionSpaceInsertion' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableDoubleTapSpace' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffAutocorrectMisspelledWords'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffHighlightMisspelledWords'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Control Panel\International' -Name 'TurnOffOfferTextPredictions'

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\TabletTip\1.7' -Name 'DisablePrediction'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\TabletTip\1.7' -Name 'DisablePrediction'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableAutocorrection'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableSpellchecking'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableTextPrediction'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnablePredictionSpaceInsertion'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\TabletTip\1.7' -Name 'EnableDoubleTapSpace'
    }



    $Info = 'Отключить Улучшение распознавания ввода с клавиатуры'
    $Group = 'Tel-Linguistic' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Компоненты Windows\Ввод текста\ "Улучшение распознования ввода с клавиатуры ..."
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\TextInput' -Name 'AllowLinguisticDataCollection' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\TextInput' -Name 'AllowLinguisticDataCollection'
    }



    $Info = 'Отключить Помощь искусственного интеллекта при вводе текста'
    $Group = 'Tel-Insights' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'InsightsEnabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Settings' -Name 'InsightsEnabled' -Type DWord 0

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'HarvestContacts' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'LMDataLoggerEnabled' -Type DWord 0
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'InsightsEnabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Settings' -Name 'InsightsEnabled'

        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'HarvestContacts' -Type DWord 1
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input\Settings' -Name 'LMDataLoggerEnabled' -Type DWord 0
    }



    $Info = 'Отключить Помощь SwiftKey при вводе текста для RU и EN'
    $Group = 'Tel-SwiftKey' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # RU
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Locales\loc_0419' -Name 'UseFluency' -Type DWord 514
        # EN
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Input\Locales\loc_0409' -Name 'UseFluency' -Type DWord 514
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-Item -Path 'HKCU:\Software\Microsoft\Input\Locales\loc_0419'
        Set-Reg Remove-Item -Path 'HKCU:\Software\Microsoft\Input\Locales\loc_0409'
    }



    $Info = 'Отключить Идентификатор объявлений для профилей пользователей'
    $Group = 'Tel-AdvertisingInfo' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        # Комп\Адм. Шабл\Система\Профили пользователей "Отключить идентификатор объявлений"
        Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo' -Name 'DisabledByGroupPolicy' -Type DWord 1

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id' -Type String 'null'

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled' -Type DWord 0
        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id' -Type String 'null'

        if ( $is64 )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id' -Type String 'null'
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo' -Name 'DisabledByGroupPolicy'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled'
        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id'

        if ( $is64 )
        {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Enabled'
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\AdvertisingInfo' -Name 'Id'
        }
    }



    $Info = 'Отключить и удалить Логи: CloudExperienceHostOobe.etl, Cellcore.etl, WinPhoneCritical.etl'
    $Group = 'Tel-Autologgers' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CloudExperienceHost' -Name 'ETWLoggingEnabled' -Type DWord 0

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe' -Name 'Start' -Type DWord 0
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore' -Name 'Start' -Type DWord 0
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore').Name )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WinPhoneCritical' -Name 'Start' -Type DWord 0
        }

        Write-Host
        Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\LogFiles\WMI","$env:SystemDrive\ProgramData\Microsoft\Diagnosis\ETLLogs\AutoLogger" -Force -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match 'WinPhoneCritical.*[.]etl|Cellcore.*[.]etl|CloudExperienceHost.*[.]etl' } | ForEach-Object {
                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CloudExperienceHost' -Name 'ETWLoggingEnabled'

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe').Name )
        {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe' -Name 'Start'
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore').Name )
        {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore' -Name 'Start'
        }

        if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\Cellcore').Name )
        {
            Set-Reg Remove-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\WinPhoneCritical' -Name 'Start'
        }
    }



    $Info = 'Отключить Телеметрию Microsoft Office 2016/2019'
    $Group = 'Tel-Office2016-2019' ; $L = $Lang.$Group

    # Выполняется только если в системе установлен Офис
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string[]] $Paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}',
                            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}'
        [bool] $Office = $false
        foreach ( $Path in $Paths )
        {
            if ( (Get-ItemProperty $Path -ErrorAction SilentlyContinue).InstallSource ) { $Office = $true ; break }
        }

        if ( $Office )
        {
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentFallBack'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentLogOn'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentFallBack2016'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentLogOn2016'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Office\Office ClickToRun Service Monitor'

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\Common\ClientTelemetry' -Name 'DisableTelemetry' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\Common\ClientTelemetry' -Name 'SendTelemetry' -Type DWord 3
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\Common\ClientTelemetry' -Name 'DisableTelemetry' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\Common\ClientTelemetry' -Name 'SendTelemetry' -Type DWord 3

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'sendcustomerdata' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'qmenable' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'updatereliabilitydata' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'disableboottoofficestart' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Feedback' -Name 'enabled' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Feedback' -Name 'includescreenshot' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'disableboottoofficestart' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'disablecomingsoon' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'optindisable' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'shownfirstrunoptin' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'ShownFileFmtPrompt' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'skydrivesigninoption' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\ptwatson' -Name 'ptwoptin' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'usercontentdisabled' -Type DWord 2
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'controllerconnectedservicesenabled' -Type DWord 2
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Security\FileValidation' -Name 'disablereporting' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Firstrun' -Name 'BootedRTM' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Firstrun' -Name 'disablemovie' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Lync' -Name 'disableautomaticsendtracing' -Type DWord 1
            
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Excel\Options' -Name 'EnableLogging' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Excel\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Options\Mail' -Name 'EnableLogging' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Security' -Name 'level' -Type DWord 2
            
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\PowerPoint\Options' -Name 'EnableLogging' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\PowerPoint\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Word\Options' -Name 'EnableLogging' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Word\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableLogging' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableUpload' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableFileObfuscation' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'accesssolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'olksolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'onenotesolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'pptsolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'projectsolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'publishersolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'visiosolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'wdsolution' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'xlsolution' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'agave' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'appaddins' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'comaddins' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'documentfiles' -Type DWord 1
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'templatefiles' -Type DWord 1


            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common' -Name 'sendcustomerdata' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common' -Name 'qmenable' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common' -Name 'updatereliabilitydata' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common' -Name 'disableboottoofficestart' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Feedback' -Name 'enabled' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Feedback' -Name 'includescreenshot' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'disableboottoofficestart' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'disablecomingsoon' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'optindisable' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'shownfirstrunoptin' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'ShownFileFmtPrompt' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\General' -Name 'skydrivesigninoption' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\ptwatson' -Name 'ptwoptin' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'usercontentdisabled' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'controllerconnectedservicesenabled' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Security\FileValidation' -Name 'disablereporting' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Firstrun' -Name 'BootedRTM' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Firstrun' -Name 'disablemovie' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Lync' -Name 'disableautomaticsendtracing' -Type DWord 1
            
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Excel\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Excel\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Outlook\Options\Mail' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Outlook\Security' -Name 'level' -Type DWord 2
            
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\PowerPoint\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\PowerPoint\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Word\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Word\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableUpload' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableFileObfuscation' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'accesssolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'olksolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'onenotesolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'pptsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'projectsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'publishersolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'visiosolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'wdsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'xlsolution' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'agave' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'appaddins' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'comaddins' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'documentfiles' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'templatefiles' -Type DWord 1


            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common' -Name 'sendcustomerdata' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common' -Name 'qmenable' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common' -Name 'updatereliabilitydata' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common' -Name 'disableboottoofficestart' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Feedback' -Name 'enabled' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Feedback' -Name 'includescreenshot' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'disableboottoofficestart' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'disablecomingsoon' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'optindisable' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'shownfirstrunoptin' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'ShownFileFmtPrompt' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\General' -Name 'skydrivesigninoption' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\ptwatson' -Name 'ptwoptin' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'usercontentdisabled' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'controllerconnectedservicesenabled' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Security\FileValidation' -Name 'disablereporting' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Firstrun' -Name 'BootedRTM' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Firstrun' -Name 'disablemovie' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Lync' -Name 'disableautomaticsendtracing' -Type DWord 1
            
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Excel\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Excel\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Outlook\Options\Mail' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Outlook\Security' -Name 'level' -Type DWord 2
            
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\PowerPoint\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\PowerPoint\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Word\Options' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Word\Security' -Name 'blockcontentexecutionfrominternet' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableLogging' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableUpload' -Type DWord 0
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM' -Name 'EnableFileObfuscation' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'accesssolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'olksolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'onenotesolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'pptsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'projectsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'publishersolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'visiosolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'wdsolution' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'xlsolution' -Type DWord 1

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'agave' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'appaddins' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'comaddins' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'documentfiles' -Type DWord 1
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'templatefiles' -Type DWord 1

            if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\EventLog-AirSpaceChannel').Name )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\EventLog-AirSpaceChannel' -Name 'Start' -Type DWord 0
            }

            if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\AirSpaceChannel').Name )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WINEVT\Channels\AirSpaceChannel' -Name 'Enabled' -Type DWord 0
            }

            Write-Host
            Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\System32\Winevt\Logs" -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -like '*AirSpaceChannel*.etl*' } | ForEach-Object {
                    if ( $Act -ne 'Check' )
                    {
                        Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                        Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                    }
                    else
                    {
                        Write-Host "     Del: $($_.FullName)" -ForegroundColor Yellow
                        $NeedFix = $true
                    }
                }

            [array] $Paths = "$env:USERPROFILE\AppData\Local\Microsoft\Office\OTele"

            if ( $Global:DataAllUsers.Redirects.Value )
            {
                @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
            
                    $Paths += "$($_.Profile)\AppData\Local\Microsoft\Office\OTele"
                })
            }

            [int] $Num = 1

            Get-ChildItem -File -LiteralPath $Paths -Force -ErrorAction SilentlyContinue | ForEach-Object {
                   
                if ( $Num -eq 1 ) { Write-Host } ; $Num++

                if ( $Act -ne 'Check' )
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor DarkGray
                    Remove-Item -LiteralPath "\\?\$($_.FullName)" -Force -ErrorAction SilentlyContinue
                }
                else
                {
                    Write-Host "     Del: $($_.FullName)" -ForegroundColor Yellow
                    $NeedFix = $true
                }
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Microsoft Office не установлен" }
            Write-Host "      $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentFallBack'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentLogOn'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentFallBack2016'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Office\OfficeTelemetryAgentLogOn2016'
        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Office\Office ClickToRun Service Monitor'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\Common\ClientTelemetry' -Name 'DisableTelemetry'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\Common\ClientTelemetry' -Name 'SendTelemetry'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'sendcustomerdata'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'qmenable'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'updatereliabilitydata'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common' -Name 'disableboottoofficestart'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Feedback' -Name 'enabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Feedback' -Name 'includescreenshot'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'disableboottoofficestart'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'disablecomingsoon'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'optindisable'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'shownfirstrunoptin'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'ShownFileFmtPrompt'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\General' -Name 'skydrivesigninoption'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\ptwatson' -Name 'ptwoptin'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'usercontentdisabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'controllerconnectedservicesenabled'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Security\FileValidation' -Name 'disablereporting'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Firstrun' -Name 'BootedRTM'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Firstrun' -Name 'disablemovie'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Lync' -Name 'disableautomaticsendtracing'
            
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Excel\Options' -Name 'EnableLogging'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Excel\Security' -Name 'blockcontentexecutionfrominternet'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Options\Mail' -Name 'EnableLogging'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Outlook\Security' -Name 'level'
            
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\PowerPoint\Options' -Name 'EnableLogging'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\PowerPoint\Security' -Name 'blockcontentexecutionfrominternet'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Word\Options' -Name 'EnableLogging'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Word\Security' -Name 'blockcontentexecutionfrominternet'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableLogging'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableUpload'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM' -Name 'EnableFileObfuscation'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'accesssolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'olksolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'onenotesolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'pptsolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'projectsolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'publishersolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'visiosolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'wdsolution'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedapplications' -Name 'xlsolution'

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'agave'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'appaddins'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'comaddins'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'documentfiles'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\OSM\preventedsolutiontypes' -Name 'templatefiles'

        Set-LGP Remove-Item -Path 'HKCU:\Software\Policies\Microsoft\Office'
        Set-LGP Remove-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office'
    }
    


    $Info = 'Отключить Телеметрию Microsoft Office 2016/2019+ (Не будет работать онлайн контент, включая справку)'
    $Group = 'Tel-Office2016-2019+' ; $L = $Lang.$Group

    # Выполняется только если в системе установлен Офис
    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string[]] $Paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}',
                            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}'
        [bool] $Office = $false
        foreach ( $Path in $Paths )
        {
            if ( (Get-ItemProperty $Path -ErrorAction SilentlyContinue).InstallSource ) { $Office = $true ; break }
        }

        if ( $Office )
        {
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate' -Type DWord 2
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled' -Type DWord 2

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled' -Type DWord 2

            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate' -Type DWord 2
            Set-LGP -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled' -Type DWord 2
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Microsoft Office не установлен" }
            Write-Host "      $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate'
        Set-Reg Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled'

        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate'
        Set-LGP Remove-ItemProperty -Path 'HKCU:\Software\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled'

        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'disconnectedstate'
        Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Office\16.0\Common\Privacy' -Name 'downloadcontentdisabled'
    }
    


    $Info = 'Отключить обновление Microsoft Office'
    $Group = 'Tel-Office-Update' ; $L = $Lang.$Group

    if ( $Groups -like $Group )
    {
        $Info | Show-Info -Shift $L.s1 -Action $Act

        [string[]] $Paths = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}',
                            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*0000000FF1CE}'
        
         [bool] $Office     = $false
         [bool] $ClicktoRun = $false
        [array] $Items      = @()

        foreach ( $Path in $Paths )
        {
            $Items += Get-ItemProperty $Path -ErrorAction SilentlyContinue

            if ( $Items.InstallSource )
            {
                if ( $Items.DisplayName -like '*Click-to-Run*' ) { $ClicktoRun = $true }

                $Office = $true ; break
            }
        }

        if ( $Office )
        {
            if ( $ClicktoRun )
            {
                Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -Name 'UpdatesEnabled' -Type String 'False'
            }

            [int] $N = 0

            # Отключение всех найденных задач обновления Microsoft Office
            Get-Task-FullPaths -LikeName *Office*Update* | ForEach-Object {
            
                $N++
            
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName $_
            }

            if ( -not $N )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "Не найдены задачи обновления Microsoft Office" }
                Write-Host "      $text" -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s2 ) { $L.s2 } else { "Microsoft Office не установлен" }
            Write-Host "      $text" -ForegroundColor DarkGray
        }
    }
    elseif ( $Groups -like "$Group-Default" )
    {
        $Info | Show-Info -Shift $L.s1 -Action Default

        Set-Reg Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration' -Name 'UpdatesEnabled'

        [int] $N = 0

        # Включение всех найденных задач обновления Microsoft Office
        Get-Task-FullPaths -LikeName *Office*Update* | ForEach-Object {
            
            $N++
            
            Set-Tsk -Do:$Act Enable-ScheduledTask -TaskName $_
        }

        if ( -not $N )
        {
            $text = if ( $L.s3 ) { $L.s3 } else { "Не найдены задачи обновления Microsoft Office" }
            Write-Host "      $text" -ForegroundColor DarkGray
        }
    }
    


    # Конец настроек  #####################

    if ( $ApplyGP )
    {
        # Получение перевода
        $L = $Lang.$InfoThisFunction

        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        $text = if ( $L.s1 ) { $L.s1 } else { "Необходимо перезагрузиться!" }

        Write-Host "`n   ••••• $text •••••" -ForegroundColor Yellow

        Get-Pause
    }
}
