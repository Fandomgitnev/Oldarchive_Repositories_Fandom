﻿
<#
.SYNOPSIS
 Создание задачи по Автоматическому созданию резервных копий реестра.
 Вместо неработающей оригинальной.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Registry_BackUp.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-OwnerAndAccess, для установки параметров доступа.
 Используется функция Set-Tsk для управления задачами.

.EXAMPLE
    Set-Registry-BackUp -Options 'CreateTask','RunTask' -Act Set

    Описание
    --------
    Создать и запустить задачу на выполнение.

.EXAMPLE
    Set-Registry-BackUp -Act Default

    Описание
    --------
    Восстановить по умолчанию, удалить задачу.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  20-05-2019
 ===============================================

#>
Function Set-Registry-BackUp {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'CreateTask', 'RunTask' )]
        [string[]] $Options = 'CreateTask'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'BackUpHives', 'HivePath' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [ValidateNotNullOrEmpty()]
        [string] $HivePath = "$env:WinDir\system32\config\RegBackMy"
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( 'BackUpHives' -eq $CheckState )
        {
            [int] $HiveCount = 0

            Get-ChildItem -File -LiteralPath \\?\$HivePath -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object {
                $HiveCount++
                try {
                    Write-Host  "        $($_.Name.PadRight(8,' '))" -ForegroundColor Cyan -NoNewline
                    Write-Host  " | $($_.LastAccessTime.ToString())" -ForegroundColor DarkGray
                } catch {}
            }

            $text = if ( $L.s1 ) { $L.s1 } else { "Резервные Кусты Реестра не найдены" }
            if ( -not $HiveCount ) { Write-Host  "        $text" -ForegroundColor Yellow }
        }
        elseif ( 'HivePath' -eq $CheckState )
        {
            if ( [System.IO.Directory]::Exists($HivePath) ) { $HivePathStatus = '#Green#{0}#' -f $(if ( $L.s2 ) { $L.s2 } else { "Существует" }) }
            else { $HivePathStatus = '#Yellow#{0}#' -f $(if ( $L.s3 ) { $L.s3 } else { "Не Существует" }) }

            "#White#$HivePath #DarkGray#| $HivePathStatus"
        }

        Return
    }

    $text = if ( $L.s4 ) { $L.s4 } else { "Задача по Резервированию кустов реестра" }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s4_1 ) { $L.s4_1 } else { "Функция" }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Act -ne 'Default' )
    {
        if ( $Options -like 'CreateTask' )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Создание" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Задачи" }
            Write-Host "$text " -ForegroundColor White -NoNewline
            Write-Host "| \Microsoft\Windows\Registry\MyRegIdleBackup `n" -ForegroundColor DarkGray

            # Настройка оригинального доступа на папку с кустами реестра, папка MyRegBack унаследует эти права.
            Set-OwnerAndAccess -Path "$env:WinDir\system32\config" -RecoverySDDL "
                O:SYG:SYD:PAI(A;CI;FA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                (A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICIIO;FA;;;CO)"

            if ( -not [System.IO.Directory]::Exists($HivePath) )
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Невозможно создать папку" }
                try { New-Item -ItemType Directory -Path $HivePath -Force -ErrorAction Stop > $null }
                catch { Write-Warning "`n  $NameThisFunction`: $text`: '$HivePath'!`n`t$($_.exception.Message)" ; Return }
            }

            # Cоздаем задачу.

            [psobject] $NewTaskSettings = New-ScheduledTask
            $NewTaskSettings.Date = [datetime]::Now.ToString("yyyy-MM-dd'T'HH:mm:ss") # Register-ScheduledTask не назначит дату создания, баг, оставлено для информации.
            $NewTaskSettings.Author = [Security.Principal.WindowsIdentity]::GetCurrent().Name # Вид: "$env:COMPUTERNAME или $env:USERDOMAIN\$env:USERNAME"
            $NewTaskSettings.SecurityDescriptor = 'O:BAG:BAD:P(A;;FA;;;BA)(A;;FA;;;SY)(A;;FR;;;IU)(A;;FRFX;;;S-1-5-80-2970612574-78537857-698502321-558674196-1451644582)(A;;FRFX;;;LS)'

            $text = if ( $L.s7 ) { $L.s7 } else { "Задание по созданию резервных копий кустов реестра. Для возможности восстановить Windows при проблемах. Папка" }

            $NewTaskSettings.Description = "$text`: $HivePath"
            $NewTaskSettings.Actions   = New-ScheduledTaskAction -Execute '%windir%\system32\cmd.exe' `
                                            -Argument '/c reg save HKLM\SAM SAM /y & reg save HKLM\SECURITY SECURITY /y & reg save HKLM\SOFTWARE SOFTWARE /y & reg save HKLM\SYSTEM SYSTEM /y & reg save HKU\.DEFAULT DEFAULT /y' `
                                            -WorkingDirectory $HivePath
            $NewTaskSettings.Principal = New-ScheduledTaskPrincipal -UserID SY -RunLevel Highest -Id 'LocalSystem'
            $NewTaskSettings.Settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -Priority 5 -Compatibility Win8
            $NewTaskSettings.Triggers  = @((Get-CimClass -Namespace 'Root/Microsoft/Windows/TaskScheduler' -ClassName 'MSFT_TaskRegistrationTrigger'),
                                           (New-ScheduledTaskTrigger -WeeksInterval 1 -At 12pm -Weekly -DaysOfWeek Monday))
            $NewTaskSettings.Settings.DisallowStartIfOnBatteries = $false
            $NewTaskSettings.Settings.StopIfGoingOnBatteries = $false
            $NewTaskSettings.Settings.AllowHardTerminate = $true
            $NewTaskSettings.Settings.StartWhenAvailable = $true
            $NewTaskSettings.Settings.RunOnlyIfNetworkAvailable = $false
            $NewTaskSettings.Settings.IdleSettings.WaitTimeout = ''
            $NewTaskSettings.Settings.IdleSettings.IdleDuration = ''
            $NewTaskSettings.Settings.IdleSettings.StopOnIdleEnd = $false
            $NewTaskSettings.Settings.IdleSettings.RestartOnIdle = $false
            $NewTaskSettings.Settings.AllowDemandStart = $true
            $NewTaskSettings.Settings.RunOnlyIfIdle = $false
            $NewTaskSettings.Settings.DisallowStartOnRemoteAppSession = $false
            $NewTaskSettings.Settings.UseUnifiedSchedulingEngine = $true
            $NewTaskSettings.Settings.WakeToRun = $false
            $NewTaskSettings.Settings.ExecutionTimeLimit = 'PT1M'
            $NewTaskSettings.Settings.Enabled = $true
            $NewTaskSettings.Settings.Hidden = $true

            [Hashtable] $TaskSettings = @{
                'TaskName'      = '\Microsoft\Windows\Registry\MyRegIdleBackup'
                'InputObject' = $NewTaskSettings
            }

            Set-Tsk -Do:$Act Register-ScheduledTask @TaskSettings

            # Отключаем оригинальную задачу.
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Registry\RegIdleBackup'
        }

        if ( $Options -like 'RunTask' )
        {
            if ( $Act -eq 'Set' )
            {
                $text = if ( $L.s8 ) { $L.s8 } else { "Выполнение" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

                $text = if ( $L.s8_1 ) { $L.s8_1 } else { "Задачи" }
                Write-Host "$text " -ForegroundColor White -NoNewline
                Write-Host "| \Microsoft\Windows\Registry\MyRegIdleBackup `n" -ForegroundColor DarkGray

                Set-Tsk -Do:$Act Enable-ScheduledTask -TaskName '\Microsoft\Windows\Registry\MyRegIdleBackup'

                try
                {
                    Start-ScheduledTask -TaskName 'MyRegIdleBackup' -TaskPath '\Microsoft\Windows\Registry\' -ErrorAction Stop

                    $text = if ( $L.s9 ) { $L.s9 } else { "Задача Запущена" }
                    Write-Host "`n   $text`n" -ForegroundColor Green
                }
                catch
                {
                    $text = if ( $L.s10 ) { $L.s10 } else { "Задача не запущена, отсутствует или отключена" }
                    Write-Host "`n   $text`n" -ForegroundColor Yellow
                }
            }
            else
            {
                Set-Tsk -Do:$Act Enable-ScheduledTask -TaskName '\Microsoft\Windows\Registry\MyRegIdleBackup'
            }
        }
    }
    else
    {
        $text = if ( $L.s11 ) { $L.s11 } else { "Удаление" }
        Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

        $text = if ( $L.s11_1 ) { $L.s11_1 } else { "Задачи" }
        Write-Host "$text " -ForegroundColor White -NoNewline

        $text = if ( $L.s11_2 ) { $L.s11_2 } else { "По умолчанию" }
        Write-Host "| $text`n" -ForegroundColor DarkGray

        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\Registry\RegIdleBackup'
        Set-Tsk Unregister-ScheduledTask -TaskName '\Microsoft\Windows\Registry\MyRegIdleBackup'
    }

    $text = if ( $L.s12 ) { $L.s12 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    Get-Pause
}
