﻿
<#
.SYNOPSIS
 Функция для Установки/Перерегистрации/Удалении/Закачки Apps/Appx

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Set_Apps_Management
 Поддержка от Windows 10 17763 x64/x86 (1809)

 Используется внешняя функция Get-Pause для установки паузы
 Используется внешняя функция Token-Impersonate для Олицетворения за System
 Используется внешняя функция Write-HostColor для расскраски консоли
 Используется внешняя функция Set-Reg для настройки параметров в реестре
 Используется внешняя функция Show-Result из других функций для вывода результата
 Используется внешняя функция Set-OwnerAndAccess для управления правами доступа к файловой системе и реестру
 Используется внешняя функция Check-State-Service для проверки статуса службы
 Используется внешняя функция Test-Internet для проверки состояния интернета и доступа для скрипта (консоли PS) в интернет
 Используется внешняя функция Get-Task-FullPaths для получения полного пути к задаче по части/полному имени или по части/полному пути.
 Используется внешняя функция Set-Tsk для создания и удаления задач
 Используется внешняя функция Set-PrivacySettingsOOBE для Отключения всех настроек конфиденциальности для режима OOBE
 Используется внешняя функция RegHives-User-LoadUnload для подгрузки/выгрузки куста дефолтного профиля, если необходимо
 Используется внешняя функция Download-File для загрузки файлов по прямым линкам

 Используется 7-zip для получения имени/разрядности/версии Apps изнутри Appx из манифеста без распаковки, и распаковки zip комплектов с appx

 Все действия универсальны, ничего нигде не сохраняют (Кроме создания задачи для автоочистки),
 и не зависят от языка и разрядности Windows и не нарушают целостность.
 
 При удалении:
 Удаляет ярлыки с рабочего стола, названия ярлыков и язык Windows не имеют значения
 Открепляет ярлыки от таскбара, названия ярлыков и язык Windows не имеют значения
 Создает раздел реестра в ...\Appx\AppxAllUserStore\Deprovisioned для отключения автоустановки приложений с типом 'Store'
 Удаляет раздел в реестре в ...\Appx\AppxAllUserStore\InboxApplications системного App для отключения автоустановки приложений с типом 'System',
 если будет найден в разделе. И ставится нужный запрет на папку только для блокировки установки его накопительным обновлением, сами файлы обновляются.
 Но после кумулятивного обновления надо очищать восстановленные разделы удалённых системных Apps. Иначе будут попытки их установить обратно,
 поэтому создается задача по автоочистке этих разделов до входа пользователя, исключая эту проблему.
 Через меню можно Восстановить системные приложения обратно или очистить разделы удаленных системных Apps, на всякий случай.
 Нарушений целостности Windows не происходит!
 При удалении поиска или кортаны скрывает их панели поиска и значки с таскбара.

 При установке:
 Ищет во всех папках apps и в папке скрипта для Appx и выводе командлетов
 Подхватывает и устанавливает сертификаты (любое количество) но только на время установки Apps, потом удаляет, если он не был ранее установлен
 Включает Режим разработчика на время установки Apps, затем возвращает предыдущее состояние
 Подхватывает лицензии, если файл лицензии имеет название одинаковое с именем пакета, пример:

 Appx: Microsoft.WindowsStore_12004.1001.113.0_neutral_~_8wekyb3d8bbwe.appxbundle
  Lic: Microsoft.WindowsStore_8wekyb3d8bbwe.xml
       Microsoft.WindowsStore <-- Поиск совпадения по этой части
 или
 Appx: ffffff.appxbundle
  Lic: ffffff_License.xml
       ffffff <-- Поиск совпадения по этой части

 Ставит сначала зависимые пакеты - все Framework Appx, потом все остальные Appx/Msix, в конце все AppxBundle/MsixBundle
 Приоритет по версиям: сначала такой тип: 2016.000.000.0 или 30161.000.000.0 (4 и больше цифр в начале), у MS cо Стандартом везде проблемы
 На Windows x64 пропускает пакеты arm/arm64, на На Windows x86: пропускает пакеты arm/arm64/x64 (ориентируется по названиям файлов для быстроты)

 Восстанавливает полностью раздел в InboxApplications для приложений с типом 'System' и снимает запрет с папки и обновляет задачу автоочистки либо удаляет её, если не нужна.
 Переименованные системные папки Apps пропускаются, так как такие методы блокировки используют скрипты от других издателей, и это нарушает целостность системы!
 Добавляет ярлык на рабочий стол только для Магазина, Эджа и FSclient. На начальный экран и Таскбар MS запретили и удалили возможность автоматически устанавливать ярлыки.

 При Закачке:
 Скачивает файлы с www.microsoft.com через ссылки из store.rg-adguard.net только Appx/Msix/AppxBundle/MsixBundle кроме arm/arm64 и только последние версии каждого типа версий
 По прямым ссылкам можно указать ещё файлы сертификатов (.cer) и лицензий (.xml)
 Удаляются все файлы в подпапке перед закачкой, кроме файлов XML (лицензий)

.EXAMPLE
    Set-Apps-Management -Option RunUninstallApps

    Описание
    --------
    Удалить все приложения указанные в пресете для удаления

.EXAMPLE
    Set-Apps-Management -Option RunUninstallApps -RemoveSpecifiedPackNames Microsoft.Windows.Search, Microsoft.549981C3F5F10

    Описание
    --------
    Удалить указаные приложения, через запятую, полные имена приложений как в пресете (не полные имена пакетов с цифрами).

.EXAMPLE
    Set-Apps-Management -Option RunInstallDownloadedAppx

    Описание
    --------
    Установить Все Найденные Appx в подпапках папки для Закачки \$AppxFolder\"Подпапки"


.EXAMPLE
    Set-Apps-Management -Option RunInstallAppxFromFolder

    Описание
    --------
    Установить Все Appx файлы только из папки: \$AppxFolder\... (Пропуск подпапок)


.NOTES
 =================================================
     Автор:  westlife (ru-board)  Версия 1.0.1
      Дата:  04-07-2022
 =================================================

#>
Function Set-Apps-Management {

    [CmdletBinding( SupportsShouldProcess = $false )]
    Param(
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'RunSaveListApps', 'RunUninstallApps', 'RunInstallApps', 'RunInstallDownloadedAppx', 'RunInstallAppxFromFolder',
                      'RunDownloadAppx', 'RunCleanDownloadedFolders', 'CleanUninstalledSystemApps', 'FixInstalledApps' )]
        [string] $Option = 'RunSaveListApps'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]  # Только для CleanUninstalledSystemApps и при 'Default' будет пропуск для исключения ошибок при вызове
        [string] $Act = 'Check'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check', Position = 2 )]
        [ValidateSet( 'UninstallInstallApps', 'DownloadAppx', 'AppxFiles', 'DevMode', 'CleanSystemApps', 'InstalledAppsProblems' )]
        [string] $CheckState
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [string] $SaveListApps = $SavePathAppsGlobal
       ,
        [Parameter( Mandatory = $false )]
        [string] $AppxFolder = $AppxFolderGlobal
       ,
        [Parameter( Mandatory = $false )]
        [switch] $Select
       ,
        [Parameter( Mandatory = $false )]
        [switch] $DoNotAddFound
       ,
        [Parameter( Mandatory = $false )]
        [switch] $NoAdditionalFiles
       ,
        [Parameter( Mandatory = $false )]  # Для скрытия лишних надписей (при вызове этой функции внутри себя)
        [switch] $NoTitle
       ,
        [Parameter( Mandatory = $false )]  # Для исключения остановки (при вызове этой функции внутри себя)
        [switch] $NoPauses
       ,
        [Parameter( Mandatory = $false )]  # для RunUninstallApps
        [switch] $InstalledFromFolders
       ,
        [Parameter( Mandatory = $false )]  # для RunUninstallApps
        [string[]] $RemoveSpecifiedPackNames
       ,
        [Parameter( Mandatory = $false )]  # для RunInstallApps
        [switch] $RestoreSystemApps
       ,
        [Parameter( Mandatory = $false )]  # для RunInstallApps
        [switch] $FixInstalledAppsProblems
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( [System.Environment]::Is64BitOperatingSystem ) { $ArchOS = 'x64' } else { $ArchOS = 'x86' }

    [string] $BuildOS   = [System.Environment]::OSVersion.Version.Build
    [string] $EditionID = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','EditionID',$null)


    # Установить это значение для IsInbox
    [int] $SetIsInbox = 0

    # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
    # то будет использоваться как пресет для настроек первый из дополнительных найденных.
    try
    {
        [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
        [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
        [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

        [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
            $_.Name -like "$PresetsName`?*$PresetsExt"
        },'First',1)).FullName
    }
    catch { [string] $FoundPresetsMy = '' }

    if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

    # Если файл с пресетами существует.
    if ( [System.IO.File]::Exists($FilePresets) )
    {
        # Получение пресетов в переменную.
        try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
    }

    # Проверка и настройка важных служб
    [array] $FixSvc = @()
    foreach ( $S in 'AppXSvc','ClipSVC','StateRepository' )
    {
        if ( (Check-State-Service -ServiceName $S -Return Value) -eq 'Disabled' )
        {
            Set-Reg -NoCheck New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$S" -Name 'Start' -Type DWord -Value 3
            $FixSvc += $S
        }
    }

    if ( 1 -ne [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon','EnableSIHostIntegration',$null) )
    {
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'EnableSIHostIntegration' -Type DWord 1
    }

    if ( 'sihost.exe' -ne [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon','ShellInfrastructure',$null) )
    {
        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'ShellInfrastructure' -Type String 'sihost.exe'
    }

    if ( $FixSvc.Count )
    {
        $text = if ( $L.s97 ) { $L.s97 } else { "Включены службы" }
        Write-Host "$NameThisFunction`: $text`: $($FixSvc -join ', ')" -ForegroundColor Yellow
    }

    try { Start-Service -Name 'AppXSvc' -ErrorAction Stop }
    catch
    {
        $text = if ( $L.s97_1 ) { $L.s97_1 } else { "Необходима перезагрузка: После включения службы AppXSvc" }
        Write-Host "$NameThisFunction`: $text" -ForegroundColor Yellow
        return 
    }

    # Исключения архитектур
    if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $ExclArch = '[_.](arm|arm64)[_.]'     }
    else                                                { [string] $ExclArch = '[_.](arm|arm64|x64)[_.]' }

    # Подходящие расширения файлов Appx
    [string] $MatchesFileExtensions = '[.](Appx|Msix|AppxBundle|MsixBundle)$'

       [int] $SleepMS = 1000

    [string] $FileDataBase = "$env:ProgramData\Microsoft\Windows\AppRepository\StateRepository-Machine.srd"

    [string[]] $RemovePackNames  = $null
    [string[]] $ExcludePackNames = $null
    [string[]] $InstallPackNames = $null
    [string[]] $FrameworkNames   = $null

    [hashtable] $Global:DownloadAppx = @{}
          [int] $Number = 0

    # Получаем список файлов для удаления и исключения
    $ListPresetsGlobal.Where({

        # Наполняем переменные именами пакетов, отсеивая все непечатные (скрытые) и запрещённые символы и TAB.
        if ( $_ -match '^\s*Uninstall-Install-Apps\s*=\s*[1]\s*=(?<AppName>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*``""=#\\\/]+)=' )
        {
            $RemovePackNames += $matches.AppName.Trim(' _')
        }
        elseif ( $_ -match '^\s*Uninstall-Install-Apps\s*=\s*[*]\s*=(?<AppName>[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*``""=#\\\/]+)=' )
        {
            $ExcludePackNames += $matches.AppName.Trim()
        }
        elseif ( $_ -match '^\s*For-Download-Appx\s*=\s*[1]\s*=(?<Folder>[a-zа-я-_0-9. ]+)=(?<Note>[^=#]+)?(=(?<Vers>[0-9.<>? ]+)?)?=[ ]*(?<Ring>[a-z]+)?[ ]*=[ ]*(?<Type>[a-z]+)[ ]*=(?<URL>.+)==' )
        {
            [string] $Folder = $Matches.Folder.Trim(' _')
            [string] $Type   = $Matches.Type.Trim()
            [string] $URL    = $Matches.URL.Trim()

            if     ( $Matches.Vers -like '*>*' ) { [string] $isTime = '>' }
            elseif ( $Matches.Vers -like '*<*' ) { [string] $isTime = '<' }
            elseif ( $Matches.Vers -like '*?*' ) { [string] $isTime = '?' }
            else                                 { [string] $isTime = ''  }

            [version] $isVers = $null
            try { [version]::TryParse($Matches.Vers.Trim(' <>?'), [ref] $isVers) > $null } catch {}

            try { [string] $Ring = $Matches.Ring.Trim() } catch { [string] $Ring = '------' }
            if ( -not $Ring ) { [string] $Ring = '------' }

            if ( $Type -eq 'DirectLink' ) { [string] $Ring = '------' }

            try { [string] $Note = $Matches.Note.Trim() } catch { [string] $Note = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }
            if ( -not $Note ) { [string] $Note = '{0}' -f $(if ( $L.s1 ) { $L.s1 } else { 'Нет описания' }) }

            $Number++
            $DownloadAppx[$Number] = @{}

            if ( $DownloadAppx.Values.Folder -like $Folder )
            {
                $DownloadAppx[$Number]['Add'] = $true
            }
            else
            {
                $DownloadAppx[$Number]['Add'] = $false
            }

            $DownloadAppx[$Number]['Folder'] = $Folder
            $DownloadAppx[$Number]['Note']   = $Note
            $DownloadAppx[$Number]['Type']   = $Type
            $DownloadAppx[$Number]['URL']    = $URL
            $DownloadAppx[$Number]['Ring']   = $Ring
            $DownloadAppx[$Number]['isVers'] = $isVers # Need Version
            $DownloadAppx[$Number]['isTime'] = $isTime # Need Time Version  (older or from/newer)
        }
    })

    # Задать имена пакетов для удаления, указание напрямую командой
    if ( $RemoveSpecifiedPackNames.Count )
    {
        $RemovePackNames = $RemoveSpecifiedPackNames
    }

    # Проверка файлов во всех подпапкак в папке \Files\Appx, и если файлы есть, то добавить имена этих папок в список к Appx для Закачки
    # Отдельная функция, чтобы вызывать это действие только при необходимости, а не каждый раз при вызове этой функции, чтобы не дергать диск лишний раз
    Function Add-Found-Appx {

        [array] $FoundFolders = @()
        $FoundFolders = (Get-ChildItem -Directory -LiteralPath $AppxFolder -Force -ErrorAction SilentlyContinue).FullName.Foreach({

            (Get-ChildItem -File -LiteralPath $_ -Force -ErrorAction SilentlyContinue).Where({
                $_.Name -match $MatchesFileExtensions -and $_.Name -notmatch $ExclArch },'First',1).DirectoryName.Foreach({ $_ | Split-Path -leaf })
        }) | Sort-Object

        $FoundFolders.ForEach({
            if ( -not ($Global:DownloadAppx.Values.Folder -like $_ ))
            {
                $Global:DownloadAppx[$Global:DownloadAppx.Count + 1] = @{ Folder = $_ }
            }
        })
    }

    # Внутренняя функция для получения полной идентификации системного Apps из AppxManifest.xml и др.
    Function Get-AppxManifest-Identity ( [string] $AppxManifest ) {

        if ( -not $AppxManifest ) { Return @() }

         [array] $AppsInfo    = @()
           [xml] $AppsXml     = $null
        [string] $Name        = ''
        [string] $PublisherId = ''

        try { [xml] $AppsXml = Get-Content -LiteralPath \\?\$AppxManifest -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}

        if ( $AppsXml.Package.Identity.Name )
        {
            $Name = "$($AppsXml.Package.Identity.Name)"

            if ( $AppxManifest -like '*_*' ) { $PublisherId = "$($AppxManifest -Replace (".+_([^\\]+).+",'$1'))" }
            else { $PublisherId = 'cw5n1h2txyewy' }

            [string] $Version = "$($AppsXml.Package.Identity.Version)"
            try { ([Version] "$Version").ToString(4) > $null } catch { $Version = [System.Environment]::OSVersion.Version.ToString() }

            try { [int] $Revision = [Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion','UBR',0) }
            catch { [int] $Revision = 0 }

            # Получение реального билда. Для исключения промежуточных билдов (например в 1909 промежуточный билд 18363, а реально всё 18362)
            try { [int] $BuildOSuwp = [regex]::Match([Microsoft.Win32.Registry]::GetValue('HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion',
            'BuildLab',$null),'^\d+','IgnorePatternWhitespace').Value } catch {} ; if ( -not $BuildOSuwp ) { $BuildOSuwp = [System.Environment]::OSVersion.Version.Build }

            [string] $VersionOS = "$([System.Environment]::OSVersion.Version.ToString(2)).$BuildOSuwp.$Revision"

            # Если на конце версии билд системы, иначе если версия не стандартная
            [string] $VersionAll = ''
            if ( ([Version] "$Version").Revision -eq $BuildOSuwp ) { $Version = $VersionOS }
            elseif ( $Version -match "[0-9]+[.]$BuildOSuwp[.](?<Rev>[0-9]+)" ) { $VersionAll = "10.0.$BuildOSuwp.$($Matches.Rev)" }

            [string] $InstallLocation = $AppxManifest -Replace('AppxManifest[.]xml','')
        }

        if ( $Name -and $PublisherId )
        {
            if (( -not $VersionAll ) -and ( $Version -eq $VersionOS ))
            {
                if ( [System.IO.Directory]::Exists($InstallLocation) )
                {
                    [string] $Target = ''
                    $Target = ((Get-ChildItem -File -LiteralPath $InstallLocation -ErrorAction SilentlyContinue).Where({
                                        $_.Name -like "*.exe" },'First')).Target
                    if ( $Target -match "[0-9]+[.]$BuildOSuwp[.](?<Rev>[0-9]+)" ) { $VersionAll = "10.0.$BuildOSuwp.$($Matches.Rev)" }
                }
            }

            [string] $Arch       = 'neutral'
            [string] $ResourceId = 'neutral'
            if ( $Name -match 'Edge|SecHealthUI' ) { $ResourceId = '' }
            if ( $Name -notmatch 'Edge$|Client[.]CBS|immersivecontrolpanel|PrintDialog' ) { if ( $VersionAll ) { $Version = $VersionAll } }

            [string] $Identity = "$Name`_$Version`_$Arch`_$ResourceId`_$PublisherId"
            if ( $PublisherId.Length -ne 13 ) { $Identity = '' }

            $AppsInfo = New-Object PsObject -Property @{
                Manifest = $AppxManifest
                Name     = $Name
                Version  = [Version] "$Version"
                Identity = $Identity
                SysPath  = ($AppxManifest -Replace('(^[a-z]:\\[^\\]+\\[^\\]+).+','$1\'))
                InstallLocation = $InstallLocation
            }

            $AppsInfo
        }
        else { @() }
    }

    [string] $AutoCleanTaskFolder = '\MaintenanceSystemApps'
    [string] $AutoCleanTaskName   = 'MaintenanceUninstalledSystemApps'

    [array] $GetAppx         = @()
    [array] $GetAppxAll      = @()
    [array] $SystemIdentitys = @()
    [array] $GetSystemAppx   = @()

    if ( $RestoreSystemApps -or $Option -match 'RunUninstallApps|RunInstallApps' )
    {
        (Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\SystemApps\","$env:SystemDrive\Windows\PrintDialog\","$env:SystemDrive\Windows\ImmersiveControlPanel\" -Recurse -Depth 1 -Force -ErrorAction SilentlyContinue
        ).Where({ $_.Name -eq 'AppxManifest.xml' }).Foreach({

            $SystemIdentitys += Get-AppxManifest-Identity $_.FullName
        })
    }

    # Установка кодировки по умолчанию перед первым использованием Get-AppxPackage, 
    # чтобы все объекты для PackageManager в текущей среде имели стандартную кодировку PS
    # Так как кодировка UTF-8 влияет на объект "Windows.Management.Deployment.PackageManager", и он делает вывод названий Apps только на английском, считая винду Английской.
    # На PackageManager могут влиять и другие ComObject, созданные с кодировкой UTF-8 перед вызовом PackageManager. А так же олицетворение оболочки за другую учетную запись.
    $GetEncoding = [Console]::OutputEncoding
    [Console]::OutputEncoding = [Console]::InputEncoding  # InputEncoding ни где в скрипте не меняется, поэтому её можно считать по умолчанию.

    try
    {
        $GetAppxAll    = Get-AppxPackage -AllUsers -ErrorAction Stop
        $GetSystemAppx = $GetAppxAll.Where({ $_.SignatureKind -eq 'System' })
    }
    catch
    {
        $text = if ( $L.s97_2 ) { $L.s97_2 } else { "Ошибка выполнения Get-AppxPackage -AllUsers" }
        Write-Host "   $text" -ForegroundColor Yellow

        Return
    }
    finally
    {
        # Возврат предыдущей кодировки для вывода
        [Console]::OutputEncoding = $GetEncoding
    }

    if ( $RestoreSystemApps )
    {
        # Получение всех имен системных аппсов которые удалены

        $InstallPackNames = $SystemIdentitys.Where({ $_.Identity -and $GetSystemAppx.Name -and -not ( $GetSystemAppx.Name -like $_.Name ) }).Name | Select-Object -Unique

        $RemovePackNames = $InstallPackNames | Sort-Object
    }

    # Убираем дубликаты имён для удаления/установки
    $RemovePackNames = $RemovePackNames | Select-Object -Unique

    # Получаем все имена для отображения с исключёнными
    [string[]] $AllPackNames = $RemovePackNames

    # Удаление исключенных apps из списка приложений для удаления, если такие есть.
    if ( $ExcludePackNames )
    {
        # Убираем дубликаты имён у исключений
        $ExcludePackNames = $ExcludePackNames | Select-Object -Unique

        # Убираем имена для исключения из удаления/установки
        $RemovePackNames  = $RemovePackNames -notmatch "^$( $ExcludePackNames -join '|^' )"
    }

    # Получение Имён Framework, без системных
    $FrameworkNames = $AllPackNames | Where-Object { ($_ -match "[.](VCLibs[.]|NET[.]|Xaml|WinJS[.]|Services[.]Store[.]Engagement)") -and -not ( $GetSystemAppx.Name -like $_ ) }

    # Если есть имена Framework
    if ( $FrameworkNames )
    {
        # Перемещаем имена Framework в конец списка для отображения оставляя их порядок
        $AllPackNames = $AllPackNames -notmatch "^$( $FrameworkNames -join '|^' )"
        $AllPackNames = $AllPackNames + $FrameworkNames

        # Иключение имён Framework из установки отдельно
        $InstallPackNames = $RemovePackNames | Where-Object { $_ -notmatch "^$( $FrameworkNames -join '|^' )" }
    }
    else
    {
        # Имена для отдельной установки
        $InstallPackNames = $RemovePackNames
    }

    # Если есть имена пакетов для исключения
    if ( $ExcludePackNames )
    {
        # Изменяем сортировку пакетов для удаления/установки, чтобы пакеты Framework были в конце списка, убирая исключенные
        $RemovePackNames = ( $InstallPackNames + $FrameworkNames ) -notmatch "^$( $ExcludePackNames -join '|^' )"
    }
    else
    {
        # Изменяем сортировку пакетов для удаления/установки, чтобы пакеты Framework были в конце списка
        $RemovePackNames = $InstallPackNames + $FrameworkNames
    }


    ########  $CheckState  ##################################################################################


    if ( $CheckState )
    {
        if ( 'UninstallInstallApps' -eq $CheckState )
        {
            [array] $GetAppxAll = @()
            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

            [int] $N = 0

            $RemovePackNames = $RemovePackNames.ForEach({ "$(($_).ToString().Trim(' _'))_" })
            $AllPackNames    = $AllPackNames.ForEach({ "$(($_).ToString().Trim(' _'))_" })

            # Имена системных Apps полученных из имён их папок для быстроты для идентификции уже удаленных Apps отображения
            [System.Collections.Generic.List[string]] $SystemAppsFolderName = @('windows.PrintDialog','windows.ImmersiveControlPanel','Microsoft.Windows.ParentalControls',
            'E2A4F912-2574-4A75-9BB0-0D023378592B','F46D4000-FD22-4DB4-AC8E-4E1DDDE828FE','1527c705-839a-4832-9118-54d4Bd6a0c89','c5e2524a-ea46-4f67-841f-6a9465d9d515')
            (Get-ChildItem -Directory -LiteralPath "$env:SystemDrive\Windows\SystemApps\" -ErrorAction SilentlyContinue
            ).Foreach({ $SystemAppsFolderName.Add(($_.Name.ToString() -Replace('_.+',''))) })

            # Выводим информацию по всем Appx для Удаления/Установки
            if ( $RemovePackNames.Count )
            {
                [array] $FoundApps = @()

                $AllPackNames | ForEach-Object {

                    $Name_ = $_
                    $Name  = $_.ToString().Trim('_')
                    $FoundApps = $GetAppxAll.Where({ $_.PackageFamilyName -like "$Name_*" })

                    if ( $FoundApps )
                    {
                        if ( $FoundApps.PackageUserInformation -like "*[[]$env:USERNAME[]]: Installed*" ) { [string] $isStatus = '#Green#●#' }
                        else { [string] $isStatus = '#Yellow#○#' }
                    }
                    else { [string] $isStatus = '#Red#○#' }

                    if ( $ExcludePackNames -and $Name_ -match "^$( $ExcludePackNames -join '|^' )" )
                    {
                        $text = if ( $L.s2 ) { $L.s2 } else { "Пропуск Удаления/Установки (совпадение с исключениями)" }

                        Write-HostColor "           $isStatus #Red#$($Name.PadRight(49,' ')) #DarkRed#◄ #DarkGray#$text"

                    }
                    elseif (( $FrameworkNames ) -and ( $Name_ -match "^$( $FrameworkNames -join '|^' )" ) )
                    {
                        $N++
                        if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }

                        $text = if ( $L.s3 ) { $L.s3 } else { "Framework отдельно не будет ставиться" }

                        Write-HostColor "       #DarkGray#$Space$N. $isStatus #Blue#$($Name.PadRight(49,' ')) #DarkGray#◄ $text"
                    }
                    else
                    {
                        $N++
                        if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }

                        if ( $GetSystemAppx.Name -like $Name -or $SystemAppsFolderName -like $Name )
                        {
                            Write-HostColor "       #DarkCyan#$Space$N. $isStatus #Blue#$($Name.PadRight(49,' ')) #DarkCyan#◄ System#"
                        }
                        else
                        {
                            Write-HostColor "       #DarkGray#$Space$N. $isStatus #Blue#$($Name.PadRight(49,' '))"
                        }
                    }
                }
            }
            else
            {
                $text = if ( $L.s4 ) { $L.s4 } else { "Не указаны приложения для Удаления/Установки!" }
                Write-Host "         $text" -ForegroundColor DarkYellow
            }
        }
        elseif ( 'DownloadAppx' -eq $CheckState )
        {
            if ( -not $DoNotAddFound )
            {
                # Добавление найденных папок с Appx в $DownloadAppx
                Add-Found-Appx
            }

            # Если указано не добавлять в список дополнительные файлы для приложения, так как у них одна и таже папка, чтобы не путать при выборе
            if ( $NoAdditionalFiles )
            {
                [hashtable] $DownloadAppxTemp = @{}
                [int] $N = 1
                foreach ( $Num in $DownloadAppx.Keys | Sort-Object )
                {
                    if ( $DownloadAppx[$Num].Add -notlike $true ) { $DownloadAppxTemp[$N] = $DownloadAppx[$Num] ; $N++ }
                }
                $DownloadAppx = $DownloadAppxTemp
            }

            [array] $GetAppxAll = @()
            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

             [array] $FoundApps = @()
            [string] $FoundAppx = ''
            [string] $FoundCert = ''

            # Выводим информацию по всем Appx для Закачки
            foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
            {
                  [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']
                  [string] $AppxURL        = $DownloadAppx[$Number]['URL']
                [psobject] $Add            = $DownloadAppx[$Number]['Add']

                [string] $Vers             = $DownloadAppx[$Number]['isVers']  # Need Version
                [string] $Time             = $DownloadAppx[$Number]['isTime']  # Need Time Version  (older or from/newer)

                $FoundAppx = (Get-ChildItem -File -LiteralPath $AppxFolder\$DownloadFolder -Force -ErrorAction SilentlyContinue).Name.Where({
                    $_ -match $MatchesFileExtensions -and $_ -notmatch $ExclArch },'First',1)

                if ( $FoundAppx ) { [string] $Found = '#Green#■#' ; [string] $Color = 'Green' } else { [string] $Found = '#Red#х#' ; [string] $Color = 'DarkRed' }

                $DownloadFolder = $DownloadFolder.Trim('_')

                $FoundApps = $GetAppxAll.Where({ $_.PackageFamilyName -like "$DownloadFolder`_*" })

                if ( $FoundApps )
                {
                    if ( $FoundApps.PackageUserInformation -like "*[[]$env:USERNAME[]]: Installed*" ) { [string] $isStatus = '#Green#●#' }
                    else { [string] $isStatus = '#Yellow#○#' }
                }
                else { [string] $isStatus = '#Red#○#' }

                if ( $AppxURL )
                {
                    if ( $Add ) { [string] $MainColor = 'Magenta' } else { [string] $MainColor = 'White' }

                    if     ( $Vers -and $Time ) { $AppxURL = "$AppxURL | #Magenta#$Time $Vers#" }
                    elseif ( $Vers            ) { $AppxURL = "$AppxURL | #Magenta#$Vers#"       }

                    [string] $ResultShow = "#$MainColor#{0}#DarkGray#. $isStatus $Found #DarkGray#$($AppxFolder.Replace("$CurrentRoot\",''))\#$MainColor#{1} #$Color#◄ #DarkGray#{2} | {3} | {4} ► {5}#" -f
                        $Number.ToString().PadLeft(9,' '),
                        $(if ( $DownloadFolder.Length -gt 36 ) { "$($DownloadFolder.ToString().Substring(0,35))~" } else { $DownloadFolder.ToString().PadRight(36,' ') }),
                        $DownloadAppx[$Number]['Note'].ToString().PadRight(33,' ').Substring(0,33),
                        $DownloadAppx[$Number]['Ring'].ToString().PadRight(6,' ').Substring(0,6),
                        $DownloadAppx[$Number]['Type'].ToString().PadRight(17,' ').Substring(0,17),
                        $AppxURL
                }
                else
                {
                    $FoundCert = (Get-ChildItem -File -LiteralPath $AppxFolder\$DownloadFolder -Force -ErrorAction SilentlyContinue).Name.Where({ $_ -like '*.cer' },'First',1)

                    $text = if ( $L.s5 ) { $L.s5 } else { "Сертификат" }
                    if ( $FoundCert ) { $FoundCert = "#DarkMagenta#+ $text#" } else { $FoundCert = "#" }

                    $text = if ( $L.s5_1 ) { $L.s5_1 } else { "Подпапка с Appx файлами" }
                    [string] $ResultShow = "#DarkGray#{0}. $isStatus $Found #DarkGray#$($AppxFolder.Replace("$CurrentRoot\",''))\#White#{1} #$Color#◄ #DarkGray#$text $FoundCert" -f
                        $Number.ToString().PadLeft(9,' '),
                        $(if ( $DownloadFolder.Length -gt 36 ) { "$($DownloadFolder.ToString().Substring(0,35))~" } else { $DownloadFolder.ToString().PadRight(36,' ') })
                }

                Write-HostColor $ResultShow
            }

            if ( -not $DownloadAppx.Count )
            {
                $text = if ( $L.s6 ) { $L.s6 } else { "Не настроены Appx для Закачки" }
                Write-Host "         $text" -ForegroundColor DarkYellow
            }
        }
        elseif ( 'AppxFiles' -eq $CheckState )
        {
            [int] $FoundAppx = (Get-ChildItem -File -LiteralPath $AppxFolder -Force -ErrorAction SilentlyContinue).Name.Where({ $_ -match $MatchesFileExtensions }).Count
            if ( $FoundAppx )
            {
                "#DarkGray#{0}: #White:DarkGreen#  $FoundAppx  #" -f $(if ( $L.s7 ) { $L.s7 } else { "Найдено файлов" })
            }
            else
            {
                "#DarkYellow#{0}#" -f $(if ( $L.s7_1 ) { $L.s7_1 } else { "Файлы не найдены" })
            }
        }
        elseif ( 'DevMode' -eq $CheckState )
        {
            [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock'

            try
            {
                $TrustedApps = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'AllowAllTrustedApps',0)
                $DevLicense  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'AllowDevelopmentWithoutDevLicense',0)

            } catch {}

            if ( 1 -eq $DevLicense )
            {
                "#DarkCyan#{0}#"   -f $( if ( $L.s8   ) { $L.s8   } else { "Режим Разработчика" })
            }
            elseif ( 1 -eq $TrustedApps )
            {
                "#DarkMagenta#{0}" -f $( if ( $L.s8_1 ) { $L.s8_1 } else { "Apps из Магазина/Загруженные" })
            }
            else
            {
                "#DarkGreen#{0}"   -f $( if ( $L.s8_2 ) { $L.s8_2 } else { "По умолчанию" })
            }
        }
        elseif ( 'CleanSystemApps' -eq $CheckState )
        {
            [array] $SystemIdentitys = @()
            (Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\SystemApps\","$env:SystemDrive\Windows\PrintDialog\","$env:SystemDrive\Windows\ImmersiveControlPanel\" -Recurse -Depth 1 -Force -ErrorAction SilentlyContinue
            ).Where({ $_.Name -eq 'AppxManifest.xml' }).Foreach({

                $SystemIdentitys += Get-AppxManifest-Identity $_.FullName
            })
            try
            {
                $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications'
                $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
                $SubKeyNames = $OpenSubKey.GetSubKeyNames()
                $OpenSubKey.Close()
            }
            catch { $SubKeyNames = $null }
            
             [bool] $Err = $false
            [array] $SystemApps = @()
            [array] $RemoveNames = @()

            try
            {
                [array] $SystemApps  = (Get-AppxPackage -AllUsers -ErrorAction Stop).Where({ $_.SignatureKind -eq 'System' })
                [array] $RemoveNames = $SystemIdentitys.Where({ -not ( $SystemApps.Name -like $_.Name ) }).Name | Select-Object -Unique
            }
            catch { $Err = $true }

            [int] $N = 0
            foreach($SubKeyName in $SubKeyNames){foreach($RemoveName in $RemoveNames){if(($SubKeyName -like "$RemoveName`_*")-and(-not($SystemNames -like $RemoveName))){$N++}}}

            if     ( $Err     ) { $string = "#Red#Error"      }
            elseif ( 0 -eq $N ) { $string = "#Green#$N"       }
            else                { $string = "#White:Red# $N " }

            try
            {
                [psobject] $ScheduleService = New-Object -ComObject Schedule.Service

                $ScheduleService.Connect()
                [string] $Arguments = $ScheduleService.GetFolder($AutoCleanTaskFolder).GetTask($AutoCleanTaskName).Definition.Actions[1].Arguments
                [string[]] $AutoCleanSystemAppsNames = ($Arguments -replace('.+[""](\\\\.+)_[""][''].+','$1')).Replace('\','').Split('_').Trim()
            }
            catch { [string[]] $AutoCleanSystemAppsNames = $null }

            if ( $AutoCleanSystemAppsNames.Count )
            {
                $text = if ( $L.s9 ) { $L.s9 } else { "Автоочистка для" }
                $string = "$string #DarkGray#| $text`: #Green#$($AutoCleanSystemAppsNames.Count)"
            }
            else
            {
                $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Задачи Автоочистки нет" }
                $string = "$string #DarkGray#| $text"
            }

            $string
        }
        elseif ( 'InstalledAppsProblems' -eq $CheckState )
        {
            if ( -not $FixInstalledAppsProblems ) { Write-Host }

            $text = if ( $L.s13 ) { $L.s13 } else { "Подготовленные и не зарегистрированные Новые версии Apps" }
            Write-Host " • $text`:" -ForegroundColor DarkCyan

            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

            $Staged = @()
            
            foreach ( $Appx in $GetAppxAll )
            {
                # Если Apps загружен (Staged) и может быть установлен (Ок)
                if ( "$($Appx.PackageUserInformation.InstallState)" -eq 'Staged' -and $Appx.Status -eq 'Ok' -and $Appx.InstallLocation )
                {
                    # Если нет установленной более новой версии 
                    if ( -not ($GetAppxAll.Where({( ($_.PackageUserInformation -join '|') -like "*[[]$env:USERNAME[]]: Installed*" ) -and
                       ( $_.Status -eq 'Ok' ) -and ( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                       ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                    {
                        # Если добавленная версия для установки старее, заменить ее на подготовленную и более новую 
                        if ( -not ($Staged.Where({( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                           ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                        {
                            # Проблема | добавить в список для установки, убрав другую добавленную
                            $Staged = $Staged.Where({ $_.Name -ne $Appx.Name })
                            $Staged += $Appx
                        }
                    }
                }
            }

            [int] $N = 0

            foreach ( $Appx in ( $Staged | Sort-Object -Property Name ))
            {
                # Проблема|установить

                $N++
                if ( $N -eq 1 ) { Write-Host }

                if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }

                Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Appx.PackageUserInformation.InstallState) " -ForegroundColor DarkCyan -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Appx.Status) " -ForegroundColor White -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline

                if ( $Appx.Architecture -eq 'x64' )
                {
                    Write-Host "x64 " -ForegroundColor Green -NoNewline
                }
                elseif ( $Appx.Architecture -eq 'x86' )
                {
                    Write-Host "x86 " -ForegroundColor Yellow -NoNewline
                }
                else
                {
                    Write-Host "$($Appx.Architecture) " -ForegroundColor Gray -NoNewline
                }

                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Appx.Name) " -ForegroundColor Blue -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($Appx.Version) " -ForegroundColor Gray -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline

                if ( $Appx.IsFramework )
                {
                    Write-Host "Framework" -ForegroundColor DarkGray
                }
                elseif ( $Appx.IsResourcePackage )
                {
                    Write-Host "Resource Package" -ForegroundColor Gray
                }
                elseif ( $Appx.SignatureKind -eq 'System' )
                {
                    Write-Host "System" -ForegroundColor Magenta
                }
                else
                {
                    Write-Host "$($Appx.SignatureKind)" -ForegroundColor White
                }
            }

            if ( $N )
            {
                if ( -not $FixInstalledAppsProblems )
                {
                    # Если запуск не из главных меню быстрых настроек (0 и 1)
                    if ( -not $MenuConfigsQuickSettings )
                    {
                        $text = if ( $L.s13_1 ) { $L.s13_1 } else { "Можно попрбовать выборочно установить, с исправлением проблем | Пункт меню: [222]" }
                    }
                    else
                    {
                        $text = if ( $L.s13_2 ) { $L.s13_2 } else { "Можно попрбовать установить, с исправлением проблем" }
                    }

                    Write-Host "`n   $text" -ForegroundColor Yellow

                    $NeedFix = $true
                }
            }
            else
            {
                $text = if ( $L.s13_3 ) { $L.s13_3 } else { "Не найдено не зарегистрированных Apps" }
                Write-Host "   $text" -ForegroundColor Green
            }
        }

        Return
    }


    ########  $CheckState End ##################################################################################


    [string] $RefreshExplorer = @'
using System;
using System.Runtime.InteropServices;

namespace WinAPI
{
    public class RefreshExplorer
    {
        private static readonly IntPtr HWND_BROADCAST = new IntPtr(0xffff);
        private const int WM_SETTINGCHANGE = 0x1a;
        private const int SMTO_ABORTIFHUNG = 0x0002;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        static extern bool SendNotifyMessage(IntPtr hWnd, uint Msg, IntPtr wParam, string lParam);
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern int SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessageTimeout(IntPtr hWnd, int Msg, IntPtr wParam, string lParam, int fuFlags, int uTimeout, IntPtr lpdwResult);
        public static void Refresh()
        {
            // Update desktop icons
            SHChangeNotify(0x8000000, 0x1000, IntPtr.Zero, IntPtr.Zero);

            // Update Tray
            SendNotifyMessage(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, "TraySettings");

            // Update environment variables
            SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, IntPtr.Zero, null, SMTO_ABORTIFHUNG, 100, IntPtr.Zero);
        }

        private static readonly IntPtr hWnd = new IntPtr(65535);
        private const int Msg = 273;

        // Virtual key ID of the F5 in File Explorer
        private static readonly UIntPtr UIntPtr = new UIntPtr(41504);

        [DllImport("user32.dll", SetLastError=true)]
        public static extern int PostMessageW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam);
        public static void PressF5Key()
        {
            // F5 pressing simulation to refresh the desktop
            PostMessageW(hWnd, Msg, UIntPtr, IntPtr.Zero);
        }
    }
}
'@
    if ( -not ( 'WinAPI.RefreshExplorer' -as [type] ))
    {
        $cp = [System.CodeDom.Compiler.CompilerParameters]::new('System.dll')
        $cp.TempFiles = [System.CodeDom.Compiler.TempFileCollection]::new($DismScratchDirGlobal,$false)
        $cp.GenerateInMemory = $true
        $cp.CompilerOptions = '/platform:anycpu /nologo'

        Add-Type -TypeDefinition $RefreshExplorer -ErrorAction Stop -Language CSharp -CompilerParameters $cp
    }

    Set-Variable -Name SQLiteDll ([string] "$CurrentRoot\Files\_Tools\SQLite\$ArchOS\System.Data.SQLite.dll") -Option Constant -Force

    # Проверки существования важных файлов.
    $text = if ( $L.s15 ) { $L.s15 } else { "Не найден SQLite.dll" }
    if ( -not [System.IO.File]::Exists($SQLiteDll) )
    { Write-Warning "`n   $text`: '$SQLiteDll'`n " ; Get-Pause ; Return } # Выход

    try
    {
        Add-Type -Path $SQLiteDll -ErrorAction Stop
    }
    catch
    {
        $text = if ( $L.s15_1 ) { $L.s15_1 } else { "Ошибка подключения SQLite.dll" }

        Write-Warning "$NameThisFunction`: $text`: '$SQLiteDll'`n   $($_.CategoryInfo.Category): $($_.Exception.Message)`n"

        Get-Pause ; Return   # Выход
    }

    # Если не указано скрыть заголовки (при вызове этой функции внутри себя)
    if ( -not $NoTitle )
    {
        $text = if ( $L.s16 ) { $L.s16 } else { 'Управление Модерн Приложениями' }
        Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'Функция' }
        Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray
    }

    # Внутренняя функция для получения и сохранения дефолтных значений режима разработчика, Включение/Отключение/восстановление предыдущего состояния режима
    Function Get-Developer-Mode ( [switch] $EnableDevMode, [switch] $DisableDevMode, [switch] $RestoreDevMode ) {

        [string] $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\AppModelUnlock'

        if ( -not ( $true -like $Global:DevModeReceived ))
        {
            try
            {
                $TrustedApps = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'AllowAllTrustedApps',0)
                $DevLicense  = [Microsoft.Win32.Registry]::GetValue("HKEY_LOCAL_MACHINE\$SubKey",'AllowDevelopmentWithoutDevLicense',0)

            } catch {}

            if ( 1 -eq $TrustedApps ) { [int] $Global:TrustedAppsDef = 1 } else { [int] $Global:TrustedAppsDef = 0 }
            if ( 1 -eq $DevLicense  ) { [int] $Global:DevLicenseDef  = 1 } else { [int] $Global:DevLicenseDef  = 0 }

            [bool] $Global:DevModeReceived = $true
        }

        if ( $EnableDevMode )
        {
            # включение режима разработчика, это нужно только для этапа установки приложения, потом режим будет восстановлен в предыдущее состояние
            try
            {
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowAllTrustedApps',1,'Dword')
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowDevelopmentWithoutDevLicense',1,'Dword')

            } catch {}
        }
        elseif ( $DisableDevMode )
        {
            # Отключение режима разработчика
            try
            {
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowAllTrustedApps',0,'Dword')
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowDevelopmentWithoutDevLicense',0,'Dword')

            } catch {}
        }
        elseif ( $RestoreDevMode )
        {
            # Восстановление параметров режима разработчика, в предыдущее состояние
            try
            {
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowAllTrustedApps',$Global:TrustedAppsDef,'Dword')
                [Microsoft.Win32.Registry]::LocalMachine.CreateSubKey($SubKey).SetValue('AllowDevelopmentWithoutDevLicense',$Global:DevLicenseDef,'Dword')

            } catch {}
        }
    }

    Get-Developer-Mode

    # Внутренняя функция для получения имени, архитектуры и версии изнутри Appx из xml Манифеста, для appxbundle без архитектуры
    Function Get-AppsInfo-FromAppx ( [string] $AppxFile ) {

        if ( -not $AppxFile ) { Return @() }

        [array] $AppsInfo = @()
          [xml] $AppsXml  = $Null

        if ( [System.IO.File]::Exists($7z) )
        {
            try { [xml] $AppsXml = & $7z e $AppxFile AppxManifest.xml -so -sccUTF-8 2> $null } catch {}

            if ( $AppsXml.Package.Identity.Name )
            {
                $AppsInfo += New-Object PsObject -Property @{

                    'Name' = [string] "$($AppsXml.Package.Identity.Name)"
                    'Arch' = [string] "$($AppsXml.Package.Identity.ProcessorArchitecture)"
                    'Vers' = [string] "$($AppsXml.Package.Identity.Version)"
                }
            }

            if ( -not $AppsInfo.Count )
            {
                try { [xml] $AppsXml = & $7z e $AppxFile AppxMetadata\AppxBundleManifest.xml -so -sccUTF-8 2> $null } catch {}

                if ( $AppsXml.Bundle.Identity.Name )
                {
                    $AppsInfo += New-Object PsObject -Property @{

                        'Name' = [string] "$($AppsXml.Bundle.Identity.Name)"
                        'Vers' = [string] "$($AppsXml.Bundle.Packages.Package.Version.Where({$_},'First',1))"
                    }
                }
            }
        }

        $AppsInfo
    }

    # Внутренняя функция для создания оригинального ярлыка на рабочем столе для устновленных UWP приложений (Apps)
    Function Create-Desktop-UwpShortcut ( [string] $UwpName ) {

        if ( -not $UwpName ) { Return }

        [psobject] $GetAppData = (New-Object -ComObject Shell.Application).NameSpace('shell:AppsFolder').Items() |
                                    Where-Object { $_.Path -like "$UwpName*" } | Select-Object -First 1

        if ( $GetAppData.Path -like '*!*' )
        {
            try
            {
                [string] $UserKey = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'
                [string] $DesktopPath = [System.Environment]::ExpandEnvironmentVariables([Microsoft.Win32.Registry]::GetValue("$UserKey\User Shell Folders",'Desktop',''))

                if ( [System.IO.Directory]::Exists($DesktopPath) )
                {
                    $WScriptShell = New-Object -ComObject WScript.Shell

                    $Shortcut = $WScriptShell.CreateShortcut("$DesktopPath\$($GetAppData.Name).lnk")
                    $Shortcut.TargetPath = "shell:AppsFolder\$($GetAppData.Path)"
                    $Shortcut.Description = "$($GetAppData.Name)"
                    $Shortcut.Save()
                }
            }
            catch { Write-Host "   Create-Desktop-UwpShortcut: Error for: $UwpName" -ForegroundColor DarkGray }
        }
        else { Write-Host "   Create-Desktop-UwpShortcut: Apps not found: $UwpName" -ForegroundColor DarkGray }
    }

    # Внутренняя функция для установки всех Appx с поддержкой временной установки сертификатов сторонних приложений, иначе их не установить
    Function Install-Appx-FromFolder {

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param(
            [Parameter( Mandatory = $false, Position = 0 )]
            [string] $Folder
        )

        if ( -not [System.IO.Directory]::Exists($Folder) )
        {
            $text = if ( $L.s17 ) { $L.s17 } else { "Папка не существует" }
            Write-Host "   $text`: '$Folder'" -ForegroundColor DarkYellow

            Return
        }

        [string] $FoundAppx = ''

        $FoundAppx = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Name.Where({
                    $_ -match $MatchesFileExtensions -and $_ -notmatch $ExclArch },'First',1)

        if ( -not $FoundAppx )
        {
            $text = if ( $L.s17_1 ) { $L.s17_1 } else { "В папке нет подходящих файлов" }
            Write-Host "   $text`: '$Folder'" -ForegroundColor DarkYellow

            Return
        }


        # Временное включение режима разработчика, это нужно только для этапа установки приложения, потом режим будет восстановлен в предыдущее состояние
        Get-Developer-Mode -EnableDevMode


        [string[]] $FoundCertificates = $null
        [string[]] $FoundCertificates = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).FullName.Where({ $_ -like '*.cer' })

        [string[]] $CertNotInstalled = $null

        if ( $FoundCertificates.Count )
        {
            foreach ( $FoundCertificate in $FoundCertificates )
            {
                [psobject] $OpenCert = $null
                try { [psobject] $OpenCert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::CreateFromCertFile($FoundCertificate) } catch {}

                [string] $CertSubject = ''

                if ( $OpenCert.Subject -like 'CN=*' )
                {
                    $CertSubject = $OpenCert.Subject

                    if ( -not ((Get-ChildItem 'Cert:\LocalMachine\Root' -Force -ErrorAction SilentlyContinue).Where({ $_.Subject -like $CertSubject },'First',1)).Count )
                    {
                        $CertNotInstalled += $CertSubject
                    }
                }

                if ( -not $CertSubject )
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { "  Пропуск" }
                    Write-host "   $text`: " -ForegroundColor DarkYellow -NoNewline
                    Write-host "$($FoundCertificate.Replace("$CurrentRoot\",'')) " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s22_2 ) { $L.s22_2 } else { "Сертификат неверный" }
                    Write-host "| $text" -ForegroundColor Red

                    try { $OpenCert.Reset() ; $OpenCert.Dispose() } catch {}
                }
                else
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                    Write-host "   $text`: " -ForegroundColor DarkMagenta -NoNewline
                    Write-host "$($FoundCertificate.Replace("$CurrentRoot\",'')) " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s18_2 ) { $L.s18_2 } else { "Сертификат" }
                    Write-host "| $text`: $($CertSubject -Replace('CN=','')) " -ForegroundColor DarkGray -NoNewline

                    if ( -not ( $CertNotInstalled -like $CertSubject ))
                    {
                        $text = if ( $L.s22_1 ) { $L.s22_1 } else { "Уже установлен" }   # Установка в любом случае, так как сертификат может обновлённый скачаться
                        Write-host "($text)" -ForegroundColor DarkGreen
                    }
                    else { Write-host }

                    try { $OpenCert.Reset() ; $OpenCert.Dispose() } catch {}

                    # Установка найденного сертификата в Доверенные корневые центры сертификации
                    # Сертификат для приложений даёт возможность установки и обновления сторонних приложений. Для перерегистрации он не нужен.
                    Import-Certificate -CertStoreLocation 'Cert:\LocalMachine\Root' -FilePath $FoundCertificate -ErrorAction Continue > $null

                    Start-Sleep -Milliseconds 500
                }
            }
        }

        # 1: Установка Framework Appx
        [string] $InclFramework = '[.](VCLibs[.]|NET[.]|Xaml|WinJS[.]|Services[.]Store[.]Engagement).+[.]Appx$'

        [array] $FoundFiles = $null

        $FoundFiles = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Where({
            $_.Name -match $InclFramework -and $_.Name -notmatch $ExclArch })

        if ( $FoundFiles )
        {
            # Сортировака файлов по версии, если она есть, затем по имени файла, исключая версии начинающиеся на 4 цыфры, так как это обычно старые
            # Не исключаю старые версии, так как иногда они должны быть установлены перед новой! Без версии или с кривой версией будут ставиться первыми.
            [array] $FoundFilesSort = @()
            $FoundFiles.ForEach({
                if ( $_.Name -match '_(?<Vers>[0-9]{1,3}[.][0-9.]+[0-9])_' )
                { [version] $ParsedVers = $null
                  if ( [version]::TryParse($Matches.Vers, [ref] $ParsedVers) )
                  {      $FoundFilesSort += New-Object PsObject -Property @{ Vers = $ParsedVers ; FullName = $_.FullName } }
                  else { $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0 ; FullName = $_.FullName } }
                } else { $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0 ; FullName = $_.FullName } }
            })

            $FoundFilesSort = ($FoundFilesSort | Sort-Object -Property Vers,FullName).FullName

            [int] $N = 0

            $FoundFilesSort | ForEach-Object {

                if ( -not $N )
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                    Write-host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s18_1 ) { $L.s18_1 } else { "Всех файлов Appx Framework" }
                    Write-host "$text" -ForegroundColor White
                }

                $N++

                # Если не сохранить в переменную из $_, то ошибка у Add-AppxPackage из-за кодировки в пути с кириллицей
                [string] $File = $_
                 [array] $AppsInfo = Get-AppsInfo-FromAppx -AppxFile $File
                [string] $AppsName = $AppsInfo.Name
                [string] $AppsArch = $AppsInfo.Arch
                [string] $AppsVers = $AppsInfo.Vers

                [string] $AppFile = $File.Replace("$CurrentRoot\",'')

                $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                Write-host "   $text`: " -ForegroundColor Cyan -NoNewline
                Write-host "$AppFile " -ForegroundColor DarkGray -NoNewline

                if ( $AppsName )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsName " -ForegroundColor White -NoNewline
                }
                else { Write-host }

                if ( $AppsVers )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsVers" -ForegroundColor White
                }
                else { Write-host }

                # Получение всех установленных Framework у текущего юзера 
                [System.Collections.Generic.List[PSObject]] $FW = @()
                $SID = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value

                foreach ( $Installed in @(Get-AppxPackage -AllUsers -PackageTypeFilter Framework -ErrorAction SilentlyContinue).Where({ $_.SignatureKind -eq 'Store' }))
                {
                    foreach ( $pi in $Installed.PackageUserInformation ) 
                    {
                        if ( $pi.UserSecurityId.Sid -eq $SID -and $pi.InstallState -eq 'Installed' )
                        {
                            try
                            {
                                $FW.Add( [PSCustomObject]@{
                                    Name = $Installed.Name
                                    Arch = $Installed.Architecture
                                    Vers = [version] $Installed.Version
                                })
                            }
                            catch {}
            
                            break
                        }
                    }
                }

                [bool] $isAppxFwOld = $false
                
                foreach ( $F in $FW | Sort-Object -Property Vers -Descending )
                {
                    try
                    { 
                        if ( $F.Name -eq $AppsName -and $F.Arch -eq $AppsArch -and [version] $F.Vers -ge [version] $AppsVers )
                        {
                            $isAppxFwOld = $true
                            [string] $isVers = $F.Vers
                            break
                        }
                    }
                    catch {}
                }

                if ( $isAppxFwOld )
                {
                    $text = if ( $L.s22 ) { $L.s22 } else { "  Пропуск" }
                    Write-host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s22_3 ) { $L.s22_3 } else { "Уже установлена версия" }
                    Write-host "$text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-host "$isVers" -ForegroundColor Gray
                    
                    Return # пропустить итерацию
                }

                [int] $NotRegistr = 0

                try
                {
                    [psobject] $Info = $null

                    $Info = Add-AppxProvisionedPackage -Online -PackagePath $File -SkipLicense -ErrorAction Stop

                    if ( $Info.Online )
                    {
                        $text = if ( $L.s19 ) { $L.s19 } else { "Результат" }
                        Write-host "   $text`: " -ForegroundColor Green -NoNewline
                        Write-host "Add-AppxProvisionedPackage: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Установлен" }
                        Write-host "$text" -ForegroundColor Green
                    }
                }
                catch
                {
                    try { Add-AppxPackage -Path $File -ErrorAction Stop }
                    catch
                    {
                        $text = if ( $L.s20 ) { $L.s20 } else { "   Ошибка" }
                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                        if ( $_.Exception.Message -like '*0x800B0109*' )
                        {
                            $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                            Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red

                            $NotRegistr++
                        }
                        elseif ( $_.Exception.Message -like '*0x80073D06*' )
                        {
                            $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                            Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                        }
                        else
                        {
                            Write-Host "Add-AppxPackage: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red

                            $NotRegistr++
                        }
                    }
                }

                $ActionDone = $true

                Start-Sleep -Milliseconds $SleepMS


                # Если не было ошибки при установке, то есть установка выполнена
                if ( -not $NotRegistr )
                {
                    Get-AppxPackage -Name $AppsName -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue |
                        ForEach-Object {
                            try
                            {
                                if ( $AppsArch -and ( $AppsArch -ne $_.Architecture -or $AppsVers -ne $_.Version )) { Return }
                                elseif ( $AppsVers -and $AppsVers -ne $_.Version ) { Return }

                                Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ForceApplicationShutdown -ErrorAction Stop

                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                                $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                                Write-host "$text`: " -ForegroundColor Green -NoNewline
                                Write-host "$AppsName " -ForegroundColor White -NoNewline
                                Write-host "| $($_.Version) | $($_.Architecture)" -ForegroundColor DarkGray
                            }
                            catch
                            {
                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                if ( $_.Exception.Message -like '*0x800B0109*' )
                                {
                                    $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                                    Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red
                                }
                                elseif ( $_.Exception.Message -like '*0x80073D06*' )
                                {
                                    $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                                    Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                                }
                                else
                                {
                                    Write-host "Add-AppxPackage: $AppsName > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                                }
                            }
                        }

                    Start-Sleep -Milliseconds $SleepMS
                }
            }
        }



        # 2: Установка всех Appx и Msix не Framework

        [string] $ExclMatch = "$InclFramework|$ExclArch"

        [array] $FoundFiles = $null

        $FoundFiles = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Where({
            $_.Name -match '[.](Appx|Msix)$' -and $_.Name -notmatch $ExclMatch })

        if ( $FoundFiles )
        {
            # Сортировака файлов по версии, если она есть, затем по имени файла, исключая версии начинающиеся на 4 цыфры, так как это обычно старые
            # Не исключаю старые версии, так как иногда они должны быть установлены перед новой! Без версии или с кривой версией будут ставиться первыми.
            [array] $FoundFilesSort = @()
            $FoundFiles.ForEach({
                if ( $_.Name -match '^(?<Name>[^_]+)_(?<Vers>[0-9]{1,3}[.][0-9.]+[0-9])([_.](?<Arch>(x86|x64|neutral))[_.])?' )
                { [version] $ParsedVers = $null
                    if ( [version]::TryParse($Matches.Vers, [ref] $ParsedVers) )
                    {      $FoundFilesSort += New-Object PsObject -Property @{ Vers = $ParsedVers ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
                    else { $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0           ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
                } else {   $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0           ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
            })


            # Исключения архитектур для приоритета установки одной из разрядности, если их 2, и приоритет для разрядности Windows
            if ( [System.Environment]::Is64BitOperatingSystem ) { [int] $SkipArch = '86' }
            else                                                { [int] $SkipArch = '64' }

            $FoundFilesSort = ($FoundFilesSort | ForEach-Object {

                $FoundFile = $_

                [array] $FoundArch = $FoundFilesSort.Where({ $_.Name -eq $FoundFile.Name -and $_.Vers -eq $FoundFile.Vers }).Arch

                if ( $FoundArch -like "*86*" -and $FoundArch -like "*64*" )
                {
                    if ( -not ( $FoundFile.Arch -like "*$SkipArch*" )) { $FoundFile }
                }
                else { $FoundFile }

            } | Sort-Object -Property Vers, FullName ).FullName  # | Sort-Object -Property Vers,FullName | Sort-Object -Property Arch -Descending).FullName

            [int] $N = 0

            $FoundFilesSort | ForEach-Object {

                if ( -not $N )
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                    Write-host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s18_3 ) { $L.s18_3 } else { "Всех файлов Appx/Msix не Framework" }
                    Write-host "$text" -ForegroundColor White
                }

                $N++

                # Если не сохранить в переменную из $_, то ошибка у Add-AppxPackage из-за кодировки в пути с кириллицей
                [string] $File     = $_
                 [array] $AppsInfo = Get-AppsInfo-FromAppx -AppxFile $File
                [string] $AppsName = $AppsInfo.Name
                [string] $AppsArch = $AppsInfo.Arch
                [string] $AppsVers = $AppsInfo.Vers

                [string] $AppFile  = $File.Replace("$CurrentRoot\",'')
                [string] $Name     = $File -Replace('.+\\([^\\_]+)[_.].+','$1')

                [string] $FoundLicense = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Where({
                                            $_.Name -like "$Name*.xml" },'First',1).FullName

                $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                Write-host "   $text`: " -ForegroundColor Cyan -NoNewline
                Write-host "$AppFile " -ForegroundColor DarkGray -NoNewline

                if ( $AppsName )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsName " -ForegroundColor White -NoNewline
                }
                else { Write-host }

                if ( $AppsVers )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsVers" -ForegroundColor White
                }
                else { Write-host }

                [int] $NotRegistr = 0

                try
                {
                    [psobject] $Info = $null

                    $text = if ( $L.s21 ) { $L.s21 } else { " Лицензия" }
                    Write-host "   $text`: " -ForegroundColor Gray -NoNewline

                    if ( $FoundLicense )
                    {
                        Write-host "$($FoundLicense.Replace("$CurrentRoot\",''))" -ForegroundColor DarkGray

                        $Info = Add-AppxProvisionedPackage -Online -PackagePath $File -LicensePath $FoundLicense -ErrorAction Stop
                    }
                    else
                    {
                        $text = if ( $L.s21_1 ) { $L.s21_1 } else { "Без Лицензии" }
                        Write-host "$text" -ForegroundColor DarkGray

                        $Info = Add-AppxProvisionedPackage -Online -PackagePath $File -SkipLicense -ErrorAction Stop
                    }

                    if ( $Info.Online )
                    {
                        $text = if ( $L.s19 ) { $L.s19 } else { "Результат" }
                        Write-host "   $text`: " -ForegroundColor Green -NoNewline
                        Write-host "Add-AppxProvisionedPackage: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Установлен" }
                        Write-host "$text" -ForegroundColor Green
                    }
                }
                catch
                {
                    try { Add-AppxPackage -Path $File -ErrorAction Stop }
                    catch
                    {
                        $text = if ( $L.s20 ) { $L.s20 } else { "   Ошибка" }
                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                        if ( $_.Exception.Message -like '*0x800B0109*' )
                        {
                            $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                            Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red

                            $NotRegistr++
                        }
                        elseif ( $_.Exception.Message -like '*0x80073D06*' )
                        {
                            $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                            Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                        }
                        else
                        {
                            Write-Host "Add-AppxPackage: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red

                            $NotRegistr++
                        }
                    }
                }

                $ActionDone = $true

                Start-Sleep -Milliseconds $SleepMS


                # Если не было ошибки при установке, то есть установка выполнена
                if ( -not $NotRegistr )
                {
                    Get-AppxPackage -Name $AppsName -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue |
                        ForEach-Object {
                            try
                            {
                                if ( $AppsArch -and ( $AppsArch -ne $_.Architecture -or $AppsVers -ne $_.Version )) { Return }
                                elseif ( $AppsVers -and $AppsVers -ne $_.Version ) { Return }

                                Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ForceApplicationShutdown -ErrorAction Stop

                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                                $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                                Write-host "$text`: " -ForegroundColor Green -NoNewline
                                Write-host "$AppsName " -ForegroundColor White -NoNewline
                                Write-host "| $($_.Version) | $($_.Architecture)" -ForegroundColor DarkGray
                            }
                            catch
                            {
                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                if ( $_.Exception.Message -like '*0x800B0109*' )
                                {
                                    $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                                    Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red
                                }
                                elseif ( $_.Exception.Message -like '*0x80073D06*' )
                                {
                                    $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                                    Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                                }
                                else
                                {
                                    Write-host "Add-AppxPackage: $AppsName > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                                }
                            }
                        }

                    Start-Sleep -Milliseconds $SleepMS
                }
            }
        }


        # 3: Установка всех AppxBundle и MsixBundle не Framework
        [array] $FoundFiles = $null

        $FoundFiles = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Where({
            $_.Name -match '[.](AppxBundle|MsixBundle)$' -and $_.Name -notmatch $ExclMatch })

        if ( $FoundFiles )
        {
            # Сортировака файлов по версии, если она есть, затем по имени файла, исключая версии начинающиеся на 4 цыфры, так как это обычно старые
            # Не исключаю старые версии, так как иногда они должны быть установлены перед новой! Без версии или с кривой версией будут ставиться первыми.
            [array] $FoundFilesSort = @()
            $FoundFiles.ForEach({
                if ( $_.Name -match '^(?<Name>[^_]+)_(?<Vers>[0-9]{1,3}[.][0-9.]+[0-9])([_.](?<Arch>(x86|x64|neutral))[_.])?' )
                { [version] $ParsedVers = $null
                    if ( [version]::TryParse($Matches.Vers, [ref] $ParsedVers) )
                    {      $FoundFilesSort += New-Object PsObject -Property @{ Vers = $ParsedVers ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
                    else { $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0           ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
                } else {   $FoundFilesSort += New-Object PsObject -Property @{ Vers = 0           ; Name = $Matches.Name ; Arch = $Matches.Arch ; FullName = $_.FullName } }
            })


            # Исключения архитектур для приоритета установки одной из разрядности, если их 2, и приоритет для разрядности Windows
            if ( [System.Environment]::Is64BitOperatingSystem ) { [int] $SkipArch = '86' }
            else                                                { [int] $SkipArch = '64' }

            $FoundFilesSort = ($FoundFilesSort | ForEach-Object {

                $FoundFile = $_

                [array] $FoundArch = $FoundFilesSort.Where({ $_.Name -eq $FoundFile.Name -and $_.Vers -eq $FoundFile.Vers }).Arch

                if ( $FoundArch -like "*86*" -and $FoundArch -like "*64*" )
                {
                    if ( -not ( $FoundFile.Arch -like "*$SkipArch*" )) { $FoundFile }
                }
                else { $FoundFile }

            } | Sort-Object -Property Vers, FullName ).FullName  # | Sort-Object -Property Vers,FullName | Sort-Object -Property Arch -Descending).FullName

            [int] $N = 0

            $FoundFilesSort | ForEach-Object {

                if ( -not $N )
                {
                    $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                    Write-host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s18_4 ) { $L.s18_4 } else { "Всех файлов AppxBundle/MsixBundle" }
                    Write-host "$text" -ForegroundColor White
                }

                $N++

                # Если не сохранить в переменную из $_, то ошибка у Add-AppxPackage из-за кодировки в пути с кириллицей
                [string] $File     = $_
                 [array] $AppsInfo = Get-AppsInfo-FromAppx -AppxFile $File
                [string] $AppsName = $AppsInfo.Name
                [string] $AppsArch = $AppsInfo.Arch
                [string] $AppsVers = $AppsInfo.Vers

                [string] $AppFile  = $File.Replace("$CurrentRoot\",'')
                [string] $Name     = $File -Replace('.+\\([^\\_]+)[_.].+','$1')

                [string] $FoundLicense = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Where({
                                             $_.Name -like "$Name*.xml" },'First',1).FullName

                $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
                Write-host "   $text`: " -ForegroundColor Cyan -NoNewline
                Write-host "$AppFile " -ForegroundColor DarkGray -NoNewline

                if ( $AppsName )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsName " -ForegroundColor White -NoNewline
                }
                else { Write-host }

                if ( $AppsVers )
                {
                    Write-host "| " -ForegroundColor DarkGray -NoNewline
                    Write-host "$AppsVers" -ForegroundColor White
                }
                else { Write-host }


                [int] $NotRegistr = 0

                try
                {
                    [psobject] $Info = $null

                    $text = if ( $L.s21 ) { $L.s21 } else { " Лицензия" }
                    Write-host "   $text`: " -ForegroundColor Gray -NoNewline

                    if ( $FoundLicense )
                    {
                        Write-host "$($FoundLicense.Replace("$CurrentRoot\",''))" -ForegroundColor DarkGray

                        $Info = Add-AppxProvisionedPackage -Online -PackagePath $File -LicensePath $FoundLicense -ErrorAction Stop
                    }
                    else
                    {
                        $text = if ( $L.s21_1 ) { $L.s21_1 } else { "Без Лицензии" }
                        Write-host "$text" -ForegroundColor DarkGray

                        $Info = Add-AppxProvisionedPackage -Online -PackagePath $File -SkipLicense -ErrorAction Stop
                    }

                    if ( $Info.Online )
                    {
                        $text = if ( $L.s19 ) { $L.s19 } else { "Результат" }
                        Write-host "   $text`: " -ForegroundColor Green -NoNewline
                        Write-host "Add-AppxProvisionedPackage: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s19_1 ) { $L.s19_1 } else { "Установлен" }
                        Write-host "$text" -ForegroundColor Green
                    }
                }
                catch
                {
                    try { Add-AppxPackage -Path $File -ErrorAction Stop }
                    catch
                    {
                        $text = if ( $L.s20 ) { $L.s20 } else { "   Ошибка" }
                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                        if ( $_.Exception.Message -like '*0x800B0109*' )
                        {
                            $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                            Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red

                            $NotRegistr++
                        }
                        elseif ( $_.Exception.Message -like '*0x80073D06*' )
                        {
                            $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                            Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                        }
                        else
                        {
                            Write-Host "Add-AppxPackage: $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red

                            $NotRegistr++
                        }
                    }
                }

                $ActionDone = $true

                Start-Sleep -Milliseconds $SleepMS


                # Если не было ошибки при установке, то есть установка выполнена
                if ( -not $NotRegistr )
                {
                    Get-AppxPackage -Name $AppsName -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue |
                        ForEach-Object {
                            try
                            {
                                if ( $AppsArch -and ( $AppsArch -ne $_.Architecture -or $AppsVers -ne $_.Version )) { Return }
                                elseif ( $AppsVers -and $AppsVers -ne $_.Version ) { Return }

                                Add-AppxPackage -DisableDevelopmentMode -Register "$($_.InstallLocation)\AppXManifest.xml" -ForceApplicationShutdown -ErrorAction Stop

                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                                $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                                Write-host "$text`: " -ForegroundColor Green -NoNewline
                                Write-host "$AppsName " -ForegroundColor White -NoNewline
                                Write-host "| $($_.Version) | $($_.Architecture)" -ForegroundColor DarkGray
                            }
                            catch
                            {
                                $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                                Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                if ( $_.Exception.Message -like '*0x800B0109*' )
                                {
                                    $text = if ( $L.s20_1 ) { $L.s20_1 } else { "Нужно установить сертификат для приложения в Cert:\LocalMachine\Root" }
                                    Write-Host "Add-AppxPackage: 0x800B0109 | $text" -ForegroundColor Red
                                }
                                elseif ( $_.Exception.Message -like '*0x80073D06*' )
                                {
                                    $text = if ( $L.s20_2 ) { $L.s20_2 } else { "Более новая версия этого пакета уже установлена" }
                                    Write-Host "Add-AppxPackage: 0x80073D06 | $text" -ForegroundColor Red
                                }
                                else
                                {
                                    Write-host "Add-AppxPackage: $AppsName > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                                }
                            }
                        }

                    Start-Sleep -Milliseconds $SleepMS

                    # Создание ярлыка на рабочем столе после установки только для этих приложений: Магазин, FSClient
                    $ShortcutDesktop = 'Microsoft.WindowsStore','24831TIRRSOFT.FS'

                    $AppsMatch = "^$($ShortcutDesktop.ForEach({[regex]::Escape($_)}) -join '$|^')$"

                    if ( $AppsName -match $AppsMatch )
                    {
                        $text = if ( $L.s24_3 ) { $L.s24_3 } else { "    Ярлык" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s24_4 ) { $L.s24_4 } else { "Создание ярлыка на Рабочем столе" }
                        Write-host "$text" -ForegroundColor DarkCyan

                        Create-Desktop-UwpShortcut -UwpName $AppsName
                    }
                }
            }
        }

        # Если были сертификаты не установленные изначально, а только в этой функции, то удалить их
        if ( $CertNotInstalled.Count )
        {
            # Задержка 10 сек перед завершением с отображением отсчета секунд в обратную сторону, а затем затирание этой надписи
            if ( $ActionDone )
            {
                  [char] $Escape          = 27
                   [int] $StringsExcl     = 3              # Количество последних строк для затирания.
                [string] $HideCursor      = "$Escape[?25l"
                [string] $ShowCursor      = "$Escape[?25h"
                [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
                [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

                [int] $Sec = 10

                do
                {
                    $text = if ( $L.s23 ) { $L.s23 } else { "    Пауза"  }
                    Write-Host "   $text`: " -ForegroundColor Blue -NoNewline

                    $text = if ( $L.s23_1 ) { $L.s23_1 } else { "Ожидание перед завершением"  }
                    Write-Host "$text " -ForegroundColor Blue -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$Sec `n`n" -ForegroundColor White

                    Start-Sleep -Milliseconds 1000
                    Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor" -NoNewline
                    $Sec--
                }
                until ( $Sec -le 0 )

                Write-Host $ShowCursor -NoNewline
            }

            foreach ( $CertSubject in $CertNotInstalled )
            {
                $text = if ( $L.s24 ) { $L.s24 } else { " Удаление" }
                Write-host "   $text`: " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s24_1 ) { $L.s24_1 } else { "Сертификат" }
                Write-host "$text`: $($CertSubject -Replace('CN=','')) | " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s24_2 ) { $L.s24_2 } else { "Был установлен временно" }
                Write-host "$text" -ForegroundColor DarkMagenta

                (Get-ChildItem 'Cert:\LocalMachine\Root' -Force -ErrorAction SilentlyContinue).Where({ $_.Subject -like $CertSubject },'First',1) | Remove-Item -Force -ErrorAction SilentlyContinue
            }
        }
        else
        {
            Start-Sleep -Milliseconds 1000
        }

    } # End region Install-Appx-FromFolder

    # Внутренняя функция по созданию или удалению задачи автоочистки параметров системных Apps
    # принимает решение сама: создать/обновить, пропустить или удалить, на основании имен в аргументах существующей задачи и удалённых системных приложений, и др. детали.
    Function Change-AutoClean-Task {

        [CmdletBinding( SupportsShouldProcess = $false )]
        Param(
            [Parameter( Mandatory = $false, Position = 0 )]
            [string] $SystemTaskPath = '\'
           ,
            [Parameter( Mandatory = $false, Position = 1 )]
            [string] $SystemTaskName
        )

        if ( $SystemTaskPath -ne '\' ) { $SystemTaskPath = "\$($SystemTaskPath.Trim('\ '))" }
        $SystemTaskName = $SystemTaskName.Trim()
        if (( -not $SystemTaskName ) -or ( $SystemTaskName -like '*\*' )) { Return }

         [bool] $Err = $false
        [array] $SystemIdentitys = @()
        [array] $UninstalledAppNames = @()

        (Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\SystemApps\","$env:SystemDrive\Windows\PrintDialog\","$env:SystemDrive\Windows\ImmersiveControlPanel\" -Recurse -Depth 1 -Force -ErrorAction SilentlyContinue
            ).Where({ $_.Name -eq 'AppxManifest.xml' }).Foreach({ $SystemIdentitys += Get-AppxManifest-Identity $_.FullName })
        try
        {
            [array] $SystemApps = (Get-AppxPackage -AllUsers -ErrorAction Stop).Where({ $_.SignatureKind -eq 'System' })
            [array] $UninstalledAppNames = $SystemIdentitys.Where({ -not ( $SystemApps.Name -like $_.Name ) }).Name | Select-Object -Unique
        }
        catch { $Err = $true }
        
        if ( $Err )
        {
            $text = if ( $L.s97_2 ) { $L.s97_2 } else { "Ошибка выполнения Get-AppxPackage -AllUsers" }
            Write-Host "   $text" -ForegroundColor Yellow
        }
        elseif ( $UninstalledAppNames.Count )
        {
            try
            {
                [psobject] $ScheduleService = New-Object -ComObject Schedule.Service

                $ScheduleService.Connect()
                $Task = $ScheduleService.GetFolder($AutoCleanTaskFolder).GetTask($AutoCleanTaskName)
                [string] $Arguments = $Task.Definition.Actions[1].Arguments
                [string[]] $AutoCleanSystemAppsNames = ($Arguments -replace('.+[""](\\\\.+)_[""][''].+','$1')).Replace('\','').Split('_').Trim()
            }
            catch { [string[]] $AutoCleanSystemAppsNames = $null }

            if ( "$(($UninstalledAppNames | Sort-Object -Unique) -join ';')" -eq "$(($AutoCleanSystemAppsNames | Sort-Object -Unique) -join ';')" )
            {
                # Совпадают имена, не надо менять задачу, выход
                Return
            }

            Token-Impersonate -Token SYS
            [psobject] $NewTaskSettings = New-ScheduledTask

            [string] $SecurityDescriptor = 'O:SYG:SYD:PAI(A;;FA;;;SY)(A;;0x1200a9;;;WD)'

            $NewTaskSettings.Author = 'westlife | forum.ru-board.com'
            $NewTaskSettings.Source = 'forum.ru-board.com'
            $NewTaskSettings.SecurityDescriptor = $SecurityDescriptor
            $NewTaskSettings.Description = "{0}" -f $(if ( $L.s12 ) { $L.s12 } else { "Эта задача выполняет очистку параметров удалённых системных Apps, которые восстанавливаются Накопительными Обновлениями (CU). `nПри каждом включении компьютера. `nНе влияет на скорость загрузки Windows" })
           #$NewTaskSettings.Principal = New-ScheduledTaskPrincipal -UserId 'NT SERVICE\TrustedInstaller' -RunLevel Highest -Id 'LocalSystem'
            $NewTaskSettings.Principal = New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -RunLevel Highest -Id 'LocalSystem' -LogonType ServiceAccount
            $NewTaskSettings.Settings  = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -Priority 7 -Compatibility Win8
            $NewTaskSettings.Triggers  = New-ScheduledTaskTrigger -AtStartup
            $NewTaskSettings.Settings.DisallowStartIfOnBatteries = $false
            $NewTaskSettings.Settings.StopIfGoingOnBatteries = $false
            $NewTaskSettings.Settings.AllowHardTerminate = $true
            $NewTaskSettings.Settings.StartWhenAvailable = $true
            $NewTaskSettings.Settings.RunOnlyIfNetworkAvailable = $false
            $NewTaskSettings.Settings.IdleSettings.WaitTimeout = ''
            $NewTaskSettings.Settings.IdleSettings.IdleDuration = ''
            $NewTaskSettings.Settings.IdleSettings.StopOnIdleEnd = $false
            $NewTaskSettings.Settings.IdleSettings.RestartOnIdle = $false
            $NewTaskSettings.Settings.AllowDemandStart = $true
            $NewTaskSettings.Settings.RunOnlyIfIdle = $false
            $NewTaskSettings.Settings.DisallowStartOnRemoteAppSession = $false
            $NewTaskSettings.Settings.UseUnifiedSchedulingEngine = $true
            $NewTaskSettings.Settings.WakeToRun = $false
            $NewTaskSettings.Settings.ExecutionTimeLimit = 'PT2M' # 'PT30S'
            $NewTaskSettings.Settings.Enabled = $true
            $NewTaskSettings.Settings.Hidden = $true
            $NewTaskSettings.Settings.Priority = 4

            [string] $ArgCmd = "/q /e:on /v:on /c ""chcp 65001>nul
            &set err=0&set key=HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore
            &(for /f ""tokens=1* delims="" %I in ('^(reg.exe query !key!\InboxApplications^&reg.exe query !key!\UpdatedApplications^)^|
            findstr /ir ""$($UninstalledAppNames.ForEach({[regex]::Escape("\$_`_")}) -join ' ')""')do reg.exe delete ""%I"" /f >nul 2>&1||set err=1)
            &(exit !err!)""".Split("`r`n").Trim() -join ''

            $NewTaskSettings.Actions = New-ScheduledTaskAction -Execute '%SystemRoot%\System32\cmd.exe' -WorkingDirectory '%SystemRoot%\System32\' -Argument $ArgCmd

            [Hashtable] $SystemAppsTask = @{
                'TaskPath'    = $SystemTaskPath
                'TaskName'    = $SystemTaskName
                'InputObject' = $NewTaskSettings
            }

            if ( $AutoCleanSystemAppsNames.Count )
            {
                $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Обновление задачи Автоочистки | Найдена разница в именах Удалённых Системных Apps и имён в задаче" }
                Write-Host "   • $text" -ForegroundColor DarkCyan
            }
            else
            {
                $text = if ( $L.s12_2 ) { $L.s12_2 } else { "Создание задачи Автоочистки | Найдены удалённые Системные Apps" }
                Write-Host "   • $text" -ForegroundColor DarkCyan
            }

            Set-Tsk Register-ScheduledTask @SystemAppsTask

            if ( $SystemTaskPath -eq '\MaintenanceSystemApps' )
            {
                Set-OwnerAndAccess -Path "$env:SystemDrive\Windows\System32\Tasks\MaintenanceSystemApps" -RecoverySDDL $SecurityDescriptor
            }

            Token-Impersonate -Reset
        }
        else
        {
            if ( Get-Task-FullPaths -LikeNames "$SystemTaskPath\$SystemTaskName" -CompareFullPath )
            {
                $text = if ( $L.s12_3 ) { $L.s12_3 } else { "Удаление задачи Автоочистки | Нет удалённых Системных Apps" }
                Write-Host "   • $text" -ForegroundColor Magenta

                Set-Tsk Unregister-ScheduledTask -TaskPath $SystemTaskPath -TaskName $SystemTaskName

                if ( $SystemTaskPath -eq '\MaintenanceSystemApps' -and [System.IO.Directory]::Exists("$env:SystemDrive\Windows\System32\Tasks\MaintenanceSystemApps") )
                {
                    Set-OwnerAndAccess -Path "$env:SystemDrive\Windows\System32\Tasks\MaintenanceSystemApps" -SetFullAccess -Recurse
                    Remove-Item -LiteralPath "\\?\$env:SystemDrive\Windows\System32\Tasks\MaintenanceSystemApps" -Recurse -Force -ErrorAction SilentlyContinue
                    Set-Reg Remove-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Schedule\TaskCache\Tree\MaintenanceSystemApps' -Recurse -NoCheck
                }
            }
        }
    }


    #####  $Option  ##################################################################################################################


    # Выполнялось ли какое либо действие
    Set-Variable -Name ActionDone ( [bool] $false ) -Option AllScope -Force

    if ( $Option -eq 'RunSaveListApps' )
    {
        $text = if ( $L.s25 ) { $L.s25 } else { "Сохранение" }
        Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

        $text = if ( $L.s25_1 ) { $L.s25_1 } else { "Списка установленных приложений" }
        Write-Host "$text " -ForegroundColor Gray

        if ( -not $SaveListApps ) { Write-Warning "$NameThisFunction`: The File to save not specified: `$SaveListApps" ; Get-Pause ; Return }

        # Функция для получения с языковой локализацией имён всех установленных Apps, если таковые есть.
        Function Get-Packages-DisplayNames {
    
            # Если версия Windows 10 старше 19041 (2004), выйти, так как на этих версиях локализованные имена не выводит 
            if ( [System.Environment]::OSVersion.Version.Build -lt 19041 ) { Return }

            try
            {
                $PackDetails = [Windows.Management.Deployment.PackageManager, Windows.Web, ContentType = WindowsRuntime]::new().FindPackages() | 
                    Select-Object -Property DisplayName -ExpandProperty Id
            }
            catch {}

            $DisplayNames = @()
            foreach ( $Pack in $PackDetails )
            {
                if (( -not $Pack.DisplayName ) -or ( -not ( $Pack.DisplayName -match '^(?!@{).+' ))) { Continue }

                $Version = [version][string]::Format('{0}.{1}.{2}.{3}', $Pack.Version.Major, $Pack.Version.Minor, $Pack.Version.Build, $Pack.Version.Revision)

                if ( $DisplayNames.Where({ $_.Name -eq $Pack.Name }) )
                {
                    $DisplayNames.Where({ $_.Name -eq $Pack.Name -and $_.Version -lt $Version }) | 
                        Add-Member -MemberType NoteProperty -Name DisplayName -Value $Pack.DisplayName -Force
                }
                else
                {
                    $DisplayNames += New-Object PsObject -Property @{
                        Name = $Pack.Name
                        #PackageFullName = $Pack.PackageFullName
                        DisplayName = $Pack.DisplayName
                        Version = $Version
                    }
                }
            }
            
            Return $DisplayNames
        }

        # Олицетворение себя за System
        Token-Impersonate -Token SYS

        [array] $Appx = @()
        $Appx = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue |
                    Select-Object -Property SignatureKind, NonRemovable, Name, PublisherId, InstallLocation, IsFramework, Architecture, Version

        # Подключение к базе данных приложений
        $SqlConnection = New-Object -TypeName 'System.Data.SQLite.SQLiteConnection'
        $SqlConnection.ConnectionString = "Data Source=$FileDataBase"
        $SqlConnection.Open()
        $SqlCommand = $SqlConnection.CreateCommand()
        $DataSet = New-Object -TypeName 'System.Data.DataSet'

        $text = if ( $L.s26 ) { $L.s26 } else { "Файл" }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$([System.IO.Path]::GetFileName($SaveListApps))" -ForegroundColor White

        $SqlCommand.CommandText = 'SELECT IsInbox,PackageFullName FROM "main"."Package";
SELECT ApplicationUserModelId,Executable FROM "main"."CacheApplication"'
        $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
        $DataSet.Reset()
        [void]$SqlAdapter.Fill($DataSet)


        # вызов Get-AppxPackage или Get-AppxProvisionedPackage не даёт отключить базу,
        # так как они используют её через службу репозитария
        # Stop-Service -Name 'StateRepository' -Force -ErrorAction Continue

        [int] $N = 0
        foreach ( $App in ( $Appx | Sort-Object SignatureKind,Name ))
        {
            $N++
            $Name = "$($App.Name)_"

            $IsInbox = $DataSet.tables[0].Where({ $_.PackageFullName -like "*$Name*" },'First',1).IsInbox
            [string] $Executable = ( $DataSet.tables[1].Where({ $_.ApplicationUserModelId -like "*$Name*" }).Executable | Sort-Object -Unique ) -join ', '
            $Appx | Where-Object { $_.Name -eq $App.Name } | Add-Member -Force -NotePropertyMembers @{
                IsInbox    = $IsInbox
                Executable = $Executable
                Num        = $N
            }
        }

        try { $SqlCommand.Cancel() } catch {}
        $SqlCommand.Dispose()
        try { $SqlConnection.Close() } catch {}
        $SqlConnection.Dispose()

        # Сброс Олицетворения
        Token-Impersonate -Reset

        # Все данные по Windows в начало экспортного списка Apps
        "`n   Windows: $ArchOS | $(Get-LangOS) | $(Get-VersOS).$(Get-RevisionOS) | $(([string] (Get-NameOS)).Replace('#DarkGray#','').Trim(' #'))" |
            Out-File -Width 500 -FilePath $SaveListApps -Force -Encoding utf8

        # Полные Данные из базы по Apps
        $Appx | Sort-Object Num | Format-Table -Property Num, IsInbox, SignatureKind, NonRemovable, IsFramework, Name, Architecture, InstallLocation, Version, Executable |
            Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        $text = if ( $L.s27 ) { $L.s27 } else { "Далее идёт список установленных приложений из магазина для использования в пресете" }
        Write-Output "=========== $text`:`n" | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        # Получение локализованных имён всех установленных Apps
        [array] $DisplayNames = Get-Packages-DisplayNames

        # Список Apps из Store
        $Appx | Sort-Object Num -Unique | Where-Object { 'System' -ne $_.SignatureKind -and $false -eq $_.IsFramework } |
            ForEach-Object {
                
                $Name = $_.Name
                $DisplayName = $DisplayNames.Where({ $_.Name -eq $Name }).DisplayName
                $Executable = (( $_.Executable.ToString().Split(',').Trim().Where({$_}).Foreach({ $_ -replace ('(.+\\)([^\\]+[.]exe)','$2')}) ) -join ', ')

                if ( $DisplayName ) { if ( $Executable ) { $ShowDisplayName = "$DisplayName | " } else { $ShowDisplayName = $DisplayName } }
                else { $ShowDisplayName = '' }

                "     Uninstall-Install-Apps = 0 = {0} = Store: {1}{2}" -f ($_.Name.ToString().PadRight(43,' ')), $ShowDisplayName, $Executable

            } | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        $text = if ( $L.s28 ) { $L.s28 } else { "Далее идёт список общих компонентов для всех установленных приложений, Framework! для использования в пресете" }
        Write-Output "`n=========== $text`:`n" | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        # Список Apps Framework, без системных
        $Appx | Sort-Object Num -Unique | Where-Object { $true -eq $_.IsFramework -and 'System' -ne $_.SignatureKind } |
            ForEach-Object {

                "     Uninstall-Install-Apps = 0 = {0} = Framework" -f ($_.Name.ToString().PadRight(43,' '))

            } | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        $text = if ( $L.s29 ) { $L.s29 } else { "Далее идёт список Системных приложений, для использования в пресете" }
        Write-Output "`n=========== $text`:`n" | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        # Исключения некоторых системных приложений из добавления в список для пресета
        [string[]] $ExcludeApps =
          # 'E2A4F912-2574-4A75-9BB0-0D023378592B', # AppResolverUX Нужен для некторых Apps
          # 'Microsoft.AAD.BrokerPlugin',           # Azure Active Directory (AAD) plugin. Нужен для входа в аккаунты Work or school, возможно в аккаунт Windows Store и установки приложений некоторых приложений
          # 'Microsoft.AccountsControl',
          # 'Microsoft.LockApp',
          # 'Microsoft.Windows.AssignedAccessLockApp',     # Киоск
          # 'Microsoft.Win32WebViewHost',                  # Рендеринг внутри Win32 с помощью Эджа, вместо IE11
          # 'Microsoft.Windows.CloudExperienceHost',       # Управление аккаунтами
          # 'Microsoft.Windows.ContentDeliveryManager',
          # 'Microsoft.Windows.PinningConfirmationDialog',
          # 'Microsoft.Windows.SecureAssessmentBrowser',
          # 'MicrosoftWindows.UndockedDevKit',             # Нужна в том числе для активции Windows цифровой лицензией
          # 'NcsiUwpApp',    # Индикатор состояния сетевого подключения для UWP Apps (Network Connectivity Status Indicator Universal Windows Platform App)
          # 'Windows.PrintDialog',
            'windows.immersivecontrolpanel',               # Системные Настройки UWP (если удалить не будет Модерн Настроек)
            'Microsoft.Windows.StartMenuExperienceHost',   # Пуск 2004 (если удалить не будет пуска, нужна замена, но при попытке запуска его или ctrl+win будет ошибка)
            'Microsoft.Windows.ShellExperienceHost'        # Центр уведомлений (если удалить не будет шторки с уведомлениями)


        $AppsExclMatch = "^$($ExcludeApps.ForEach({[regex]::Escape($_)}) -join '$|^')$"

        # Список с частью систсемных Apps, без исключений
        $Appx | Sort-Object Num -Unique | Where-Object { 'System' -eq $_.SignatureKind -and -not ( $_.Name -match $AppsExclMatch ) -and -not $_.IsFramework } |
            ForEach-Object {
                
                $Name = $_.Name
                $DisplayName = $DisplayNames.Where({ $_.Name -eq $Name }).DisplayName
                $Executable = (( $_.Executable.ToString().Split(',').Trim().Where({$_}).Foreach({ $_ -replace ('(.+\\)([^\\]+[.]exe)','$2')}) ) -join ', ')

                if ( $DisplayName ) { if ( $Executable ) { $ShowDisplayName = "$DisplayName | " } else { $ShowDisplayName = $DisplayName }}
                else { $ShowDisplayName = '' }

                "     Uninstall-Install-Apps = 0 = {0} = System: {1}{2}" -f ($_.Name.ToString().PadRight(43,' ')), $ShowDisplayName, $Executable

            } | Out-File -Width 500 -FilePath $SaveListApps -Force -Append -Encoding utf8

        $text = if ( $L.s30 ) { $L.s30 } else { "Завершено" }
        Write-Host "`n   $text`n" -ForegroundColor Green

        Get-Pause

        Return
    }
    elseif ( $Option -eq 'RunUninstallApps' )
    {
        # Если нужно удалить установленые Apps, но только для которых есть Appx в папке \Files\Appx\... и подпапках (глубина рекусрии = 1) и по именам настроенных папок
        if ( $InstalledFromFolders )
        {
            # Временный показ надписи про ожидание
              [char] $Escape          = 27
               [int] $StringsExcl     = 2              # Количество последних строк для затирания.
            [string] $HideCursor      = "$Escape[?25l"
            [string] $ShowCursor      = "$Escape[?25h"
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            $text = if ( $L.s34 ) { $L.s34 } else { "Ждите"  }
            Write-Host "`n   $text`: " -ForegroundColor Blue -NoNewline

            $text = if ( $L.s34_1 ) { $L.s34_1 } else { "Идёт получение данных по всем найденным Appx в папке"  }
            Write-Host "$text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))" -ForegroundColor White


            $MatchFiles = '^(?!.*[.](VCLibs[.]|NET[.]|Xaml|WinJS[.]|Services[.]Store[.]Engagement)).*[.](Appx|Msix|AppxBundle|MsixBundle)$'

            [array] $GetAppxAll = @()
            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

            [array] $AllAppsInstalled = @()
            [array] $AllAppsNotInstalled = @()
            [array] $AppsInfo = @()

            (Get-ChildItem -File -LiteralPath $AppxFolder -Force -Recurse -Depth 1 -ErrorAction SilentlyContinue).Where({
                $_.Name -match $MatchFiles -and $_.Name -notmatch $ExclArch
            }).Foreach({

                $AppsInfo = Get-AppsInfo-FromAppx -AppxFile $_.FullName

                $AppsInfo | Add-Member -MemberType NoteProperty -name Directory ($_.DirectoryName.Replace("$CurrentRoot\",'')) -Force

                [int] $N = 0
                $GetAppxAll.Where({ $_.PackageFamilyName -like "$($AppsInfo.Name)_*" -and ( -not $_.IsFramework ) },'First',1).Foreach({ $AllAppsInstalled += $AppsInfo ; $N++ })

                if ( -not $N ) { $AllAppsNotInstalled += $AppsInfo }
            })


            # Добавляем имена папок в списки Установленных/Неустановленных для отображения и выбора установленных для удаления
            foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
            {
                [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']

                [string] $Directory = "$AppxFolder\$DownloadFolder".Replace("$CurrentRoot\",'')

                $AppsInfo = New-Object PsObject -Property @{ Name = $DownloadFolder ; Directory = $Directory }

                if ( $GetAppxAll.PackageFamilyName -like "$DownloadFolder`_*" )
                {
                    $AllAppsInstalled += $AppsInfo
                }
                else
                {
                    $AllAppsNotInstalled += $AppsInfo
                }
            }


            $AllAppsInstalled    = $AllAppsInstalled    | Sort-Object Name -Unique
            $AllAppsNotInstalled = $AllAppsNotInstalled | Sort-Object Name -Unique

            Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

            if ( -not $AllAppsInstalled.Count -and -not $AllAppsNotInstalled.Count )
            {
                $text = if ( $L.s34_2 ) { $L.s34_2 } else { "Не найдены Apps в папке и подпапках" }
                Write-Host "`n   $text`: " -ForegroundColor DarkYellow -NoNewline
                Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))" -ForegroundColor DarkGray

                Get-Pause ; Return   # Выход
            }

            $text = if ( $L.s35 ) { $L.s35 } else { "Удаление" }
            Write-Host "`n   $text " -ForegroundColor Blue -NoNewline

            if ( $Select )
            {
                $text = if ( $L.s35_1 ) { $L.s35_1 } else { "Apps найденных в папке и установленных, по выбору" }
            }
            else
            {
                $text = if ( $L.s35_2 ) { $L.s35_2 } else { "Apps найденных в папке и установленных" }
            }

            Write-Host "$text`n" -ForegroundColor Gray

            [int] $N = 0

            # Выводим информацию по всем Appx для Удаления/Установки
            if ( $AllAppsInstalled.Count -or $AllAppsNotInstalled.Count )
            {
                $AllAppsInstalled | ForEach-Object {

                    $N++
                    if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }

                    Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline

                    Write-Host "$($_.Name.ToString().PadRight(49,' '))"  -ForegroundColor White -NoNewline
                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s36 ) { $L.s36 } else { "Установлен   " }
                    Write-Host "$text " -ForegroundColor Green -NoNewline

                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($_.Directory)" -ForegroundColor DarkGray
                }

                $AllAppsNotInstalled | ForEach-Object {

                    Write-Host "       $($_.Name.ToString().PadRight(49,' '))"  -ForegroundColor DarkYellow -NoNewline
                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s37 ) { $L.s37 } else { "Не установлен" }
                    Write-Host "$text " -ForegroundColor DarkYellow -NoNewline

                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($_.Directory)" -ForegroundColor DarkGray
                }
            }

            if ( -not $AllAppsInstalled.Count )
            {
                $text = if ( $L.s37_1 ) { $L.s37_1 } else { "Нет установленных Apps из найденных в папке" }
                Write-Host "`n   $text`: " -ForegroundColor DarkYellow -NoNewline
                Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))" -ForegroundColor DarkGray

                Get-Pause ; Return   # Выход
            }

            $RemovePackNames = $AllAppsInstalled.Name.ForEach({ "$($_.Trim('_'))`_" })
        }

        # Если есть имена пакетов для удаления
        if ( $Select -and $RemovePackNames.Count )
        {
            # Если удаление установленных приложений не из папки Files\Appx
            if ( -not $InstalledFromFolders )
            {
                $text = if ( $L.s31 ) { $L.s31 } else { "Удаление" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s31_1 ) { $L.s31_1 } else { "Установленных приложений по выбору" }

                Write-Host "$text`n" -ForegroundColor Gray

                Set-Apps-Management -CheckState UninstallInstallApps
            }

            # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
              [char] $Escape          = 27
               [int] $StringsExcl     = 3              # Количество последних строк для затирания.
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline

            # Ждем ввода пользователя.
            $text = if ( $L.s32 ) { $L.s32 } else { 'Введите номера Apps через пробел и/или диапазон через дефис' }

            Write-Host "`n   $text"

            $text = if ( $L.s98 ) { $L.s98 } else { 'Номера' }

            [string] $Choice = Read-Host -Prompt "   $text"

            [array] $SelectedApps = @()
            [Uint16[]] $SelectedNumbers = $null

            # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
            # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера.
            # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedApps, с выбранными существующми намерами.
            if ( -not ( $Choice.Trim() -eq '' ))
            {
                [array] $arr = @()

                # Добавление групп указанных через дефис
                foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

                $arr | ForEach-Object {
                    
                    try
                    {
                        [Uint16] $AppNumber = $_

                        if (( $AppNumber -gt 0 ) -and ( $AppNumber -le $RemovePackNames.Count ) -and ( $SelectedApps -notcontains $AppNumber ))
                        {
                            $SelectedApps += $RemovePackNames[( $AppNumber - 1 )]
                            $SelectedNumbers += $AppNumber
                        }
                    }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Отмена' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            if ( -not $SelectedApps )
            {
                $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Неверный выбор!' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            $RemovePackNames = $SelectedApps | Sort-Object

            $text = if ( $L.s33_2 ) { $L.s33_2 } else { 'Выбранные Номера' }
            Write-HostColor "`n    $text`: #DarkGray#[ #White#$SelectedNumbers #DarkGray#]#"
        }
        else
        {
            if ( -not $InstalledFromFolders )
            {
                $text = if ( $L.s31 ) { $L.s31 } else { "Удаление" }
                Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s31_2 ) { $L.s31_2 } else { "Установленных приложений" }

                Write-Host "$text " -ForegroundColor Gray
            }
        }

        if ( $RemovePackNames.Count )
        {
            [int] $N = 0

            if ( $InstalledFromFolders )
            {
                if ( $Select ) { $text = if ( $L.s36_1 ) { $L.s36_1 } else { "Выбранные Apps из найденных в папке и установленных" } }
                else           { $text = if ( $L.s36_2 ) { $L.s36_2 } else { "Найденные Apps в папке и установленные" } }
            }
            else
            {
                if ( $Select ) { $text = if ( $L.s38   ) { $L.s38   } else { "Выбранные Apps для удаления" } }
                else           { $text = if ( $L.s38_1 ) { $L.s38_1 } else { "Указанные Apps для удаления" } }
            }

            Write-Host "`n   $text`:`n" -ForegroundColor White

            $RemovePackNames = $RemovePackNames.ForEach({ "$(($_).ToString().Trim(' _'))_" })

            $RemovePackNames | ForEach-Object {
                $N++
                if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }
                Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline
                Write-Host "$($_.Trim('_'))"  -ForegroundColor Blue
            }
        }
        else
        {
            $text = if ( $L.s38_2 ) { $L.s38_2 } else { "Не указаны Apps для удаления!" }
            Write-Host "`n   $text`n" -ForegroundColor DarkYellow

            Get-Pause ; Return   # Выход
        }


        [array] $GetSystemFullNames = (Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue).Where({ $_.SignatureKind -eq 'System' }).PackageFullName

        # Олицетворение себя за System
        Token-Impersonate -Token SYS

        $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
        Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s39_1 ) { $L.s39_1 } else { "Подключение" }
        Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$($FileDataBase | Split-Path -leaf )" -ForegroundColor DarkGray

        # Подключение к базе данных приложений
        $SqlConnection = New-Object -TypeName 'System.Data.SQLite.SQLiteConnection'
        $SqlConnection.ConnectionString = "Data Source=$FileDataBase"
        $SqlConnection.Open()
        $SqlCommand = $SqlConnection.CreateCommand()
        $DataSet = New-Object -TypeName 'System.Data.DataSet'

        $SqlCommand.CommandText = 'SELECT type,name FROM "main".sqlite_master WHERE "type" like "trigger";
SELECT IsInbox,PackageFullName FROM "main"."Package"'
        $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
        $DataSet.Reset()
        [void] $SqlAdapter.Fill($DataSet)



        [string[]] $TriggersFound = $DataSet.tables[0].Name.Where({$_ -like 'TRG_AFTER*UPDATE_Package_SRJournal'})

        if ( $TriggersFound.Count )
        {
            $TriggersFound | ForEach-Object {

                $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s40_1 ) { $L.s40_1 } else { "Найден" }
                Write-Host "$text`: " -ForegroundColor DarkGreen -NoNewline
                Write-Host "    $_"  -ForegroundColor DarkGray
            }
        }
        else
        {
            $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s40_2 ) { $L.s40_2 } else { "Не найдены блокирующие тригеры в базе данных" }
            Write-Host "$text`n" -ForegroundColor DarkYellow
        }

        # Надо Изменять базу
        [bool] $DataBaseProcessing = $true

        # Значение для IsInbox
        [int] $IsInbox = $SetIsInbox

        # Получение имен удаляемых приложений без исключенных, если такие указаны.
        [psobject[]] $PacksTable = $DataSet.tables[1] | Where-Object { $_.PackageFullName -match "^$( $RemovePackNames -join '|^' )" }

        if ( $PacksTable.Count )
        {
            $PacksTable | ForEach-Object {

                $text = if ( $L.s41 ) { $L.s41 } else { " IsInbox" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s40_1 ) { $L.s40_1 } else { "Найден" }
                Write-Host "$text`: " -ForegroundColor Green -NoNewline

                Write-Host "$($_.IsInbox) "  -ForegroundColor Cyan -NoNewline
                Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                Write-Host "$($_.PackageFullName) "  -ForegroundColor White -NoNewline

                if ( $GetSystemFullNames -like $_.PackageFullName )
                {
                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                    Write-Host "System"  -ForegroundColor DarkCyan
                }
                else { Write-Host }

                if ( $_.IsInbox ) { $IsInbox = $_.IsInbox }
            }
        }
        else
        {
            $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s42 ) { $L.s42 } else { "Не найдены в базе данных указанные приложения для удаления!" }
            Write-Host "$text" -ForegroundColor DarkYellow

            # Изменять базу не надо
            $DataBaseProcessing = $false
        }



        if ( $SetIsInbox -ne $IsInbox )
        {
            $ActionDone = $true

            $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s43 ) { $L.s43 } else { "Выполнение действий с базой данных" }
            Write-Host "$text" -ForegroundColor Magenta

            if ( $TriggerName = $DataSet.tables[0].Name.Where({$_ -like 'TRG_AFTER*UPDATE_Package_SRJournal'},'First',1) )
            {
                $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s44 ) { $L.s44 } else { " Удаление" }
                Write-Host "$text`: " -ForegroundColor DarkMagenta -NoNewline
                Write-Host "    $TriggerName" -ForegroundColor DarkGray

                $SqlCommand.CommandText = "DROP TRIGGER ""main"".""$TriggerName"""
                $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
                [void] $SqlAdapter.Fill($DataSet)
            }
            else
            {
                $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s43_1 ) { $L.s43_1 } else { "Нет блокирующих тригеров в базе данных!" }
                Write-Host "$text`n" -ForegroundColor DarkYellow
            }

            foreach ( $PackName in $RemovePackNames )
            {
                # Получение значения IsInbox у удаляемого приложения, без исключенных, если такие указаны.
                [psobject] $GetIsInBox = ($DataSet.tables[1].Where({ $_.PackageFullName -like "$PackName*" },'First',1)).IsInbox

                if (( $GetIsInBox -match "^[0-1]$" ) -and ( $SetIsInbox -ne $GetIsInBox ))
                {
                    $text = if ( $L.s41 ) { $L.s41 } else { " IsInbox" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s45 ) { $L.s45 } else { "Установка" }
                    Write-Host "$text`: " -ForegroundColor DarkCyan -NoNewline
                    Write-Host "$SetIsInbox " -ForegroundColor Green -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($PackName.Trim('_'))" -ForegroundColor Cyan

                    # SQLite не учитывает в шаблоне LIKE символы подчёркивания, поэтому их надо экранировать.
                    $SqlCommand.CommandText = "UPDATE ""main"".""Package"" SET ""IsInbox""=$SetIsInbox WHERE ""PackageFullName"" LIKE '%$($PackName.Replace('_','\_'))%' ESCAPE '\'"
                    $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
                    [void] $SqlAdapter.Fill($DataSet)
                }
            }
        }
        else
        {
            $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s46 ) { $L.s46 } else { "Разблокировка Apps не требуется" }
            Write-Host "$text" -ForegroundColor DarkGray

            # Изменять базу не надо
            $DataBaseProcessing = $false
        }



        # Если надо обрабатывать базу
        if ( $DataBaseProcessing )
        {
            $ActionDone = $true

            $SqlCommand.CommandText = 'SELECT type,name FROM "main".sqlite_master WHERE "type" like "trigger"'
            $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
            $DataSet.Reset()
            [void] $SqlAdapter.Fill($DataSet)

            if (( $TriggerName -like 'TRG_AFTER*UPDATE_Package_SRJournal' ) -and ( -not $DataSet.tables[0].Name.Where({ $_ -like $TriggerName }) ))
            {
                $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s47 ) { $L.s47 } else { "Восстановление тригера" }
                Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$TriggerName" -ForegroundColor DarkGray

                $SqlCommand.CommandText = "CREATE TRIGGER $TriggerName AFTER UPDATE ON Package FOR EACH ROW BEGIN UPDATE Sequence SET LastValue=LastValue+1 WHERE Id=2 ;
INSERT INTO SRJournal(_Revision, _WorkId, ObjectType, Action, ObjectId, PackageIdentity, WhenOccurred, SequenceId)SELECT 1, workid(), 1, 2, NEW._PackageID, pi._PackageIdentityID, now(), s.LastValue FROM Sequence AS s CROSS JOIN PackageIdentity AS pi WHERE s.Id=2 AND pi.PackageFullName=NEW.PackageFullName; END;"
                $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
                [void] $SqlAdapter.Fill($DataSet)
            }

            # Проверка блокирующих тригеров в базе данных
            $SqlCommand.CommandText = 'SELECT type,name FROM "main".sqlite_master WHERE "type" like "trigger";
SELECT IsInbox,PackageFullName FROM "main"."Package"'
            $SqlAdapter = New-Object -TypeName 'System.Data.SQLite.SQLiteDataAdapter' -ArgumentList $SqlCommand
            $DataSet.Reset()
            [void] $SqlAdapter.Fill($DataSet)

            [string[]] $TriggersFound = $DataSet.tables[0].Name.Where({$_ -like 'TRG_AFTER*UPDATE_Package_SRJournal'})

            if ( $TriggersFound.Count )
            {
                $TriggersFound | ForEach-Object {

                    $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s40_1 ) { $L.s40_1 } else { "Найден" }
                    Write-Host "$text`: " -ForegroundColor DarkGreen -NoNewline
                    Write-Host "    $_ | "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s48 ) { $L.s48 } else { "Восстановлен" }
                    Write-Host "$text" -ForegroundColor DarkGreen
                }
            }
            else
            {
                $text = if ( $L.s40 ) { $L.s40 } else { " Триггер" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s40_2 ) { $L.s40_2 } else { "Не найдены блокирующие тригеры в базе данных" }
                Write-Host "$text`n" -ForegroundColor DarkYellow
            }



            # Получение данных удаляемых приложений, без исключенных, если такие указаны.
            [psobject[]] $PacksTable = $DataSet.tables[1] | Where-Object { $_.PackageFullName -match "^$( $RemovePackNames -join '|^' )" }

            if ( $PacksTable.Count )
            {
                $PacksTable | ForEach-Object {

                    $text = if ( $L.s41 ) { $L.s41 } else { " IsInbox" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s40_1 ) { $L.s40_1 } else { "Найден" }
                    Write-Host "$text`: " -ForegroundColor Green -NoNewline

                    Write-Host "$($_.IsInbox) "  -ForegroundColor Cyan -NoNewline
                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($_.PackageFullName) "  -ForegroundColor White -NoNewline

                    if ( $GetSystemFullNames -like $_.PackageFullName )
                    {
                        Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                        Write-Host "System"  -ForegroundColor DarkCyan
                    }
                    else { Write-Host }
                }
            }
            else
            {
                $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s42 ) { $L.s42 } else { "Не найдены в базе данных указанные приложения для удаления!" }
                Write-Host "$text" -ForegroundColor DarkYellow
            }
        }

        $text = if ( $L.s39 ) { $L.s39 } else { "    База" }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

        $text = if ( $L.s49 ) { $L.s49 } else { "Отключение" }
        Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$($FileDataBase | Split-Path -leaf )`n" -ForegroundColor DarkGray

        try { $SqlCommand.Cancel() } catch {}
        $SqlCommand.Dispose()
        try { $SqlConnection.Close() } catch {}
        $SqlConnection.Dispose()

        # Служба нужна для удаления Apps
        # Start-Service -Name 'StateRepository' -ErrorAction Continue

        # Сброс Олицетворения
        Token-Impersonate -Reset


        # Восстановление доступа по умолчанию +, для перестраховки.
        Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications' -RecoverySDDL '
        O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
        G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(A;CI;KR;;;SY)(A;CIIO;KA;;;SY)
        (A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)(A;CI;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
        (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'


        if ( $Select ) { $text = if ( $L.s50 ) { $L.s50 } else { "Удаление выбранных приложений" } }
        else           { $text = if ( $L.s51 ) { $L.s51 } else { "Удаление указанных приложений" } }
        Write-Host "   $text`:" -ForegroundColor DarkGray

        # Название команды открепления от таскбара, чтобы не зависеть от языка системы и получение всех установленных Apps
        [psobject] $ShellApps = (New-Object -ComObject Shell.Application).NameSpace('shell:AppsFolder').Items()

        # Путь к рабочему столу пользователя
        [string] $UserKey = 'HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer'
        [string] $DesktopPath = [System.Environment]::ExpandEnvironmentVariables([Microsoft.Win32.Registry]::GetValue("$UserKey\User Shell Folders",'Desktop',''))

        # Раздел для занесения имен удаленных магазинных пакетов, чтобы не восстанавливались сами, но это не точно =)
        [string] $RegPath = 'Registry::HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\Deprovisioned'


        foreach ( $PackName in $RemovePackNames )
        {
            [bool] $ProcessedProvisioned = $false
            [bool] $Processed = $false

            $text = if ( $L.s52 ) { $L.s52 } else { "Удаление" }
            Write-Host "`n   $text`: " -ForegroundColor Cyan -NoNewline
            Write-Host "$($PackName.Trim('_'))"  -ForegroundColor Blue

            # Открепление приложения от Таскбара, нужно делать до начала удаления

            $ShellApps | Where-Object { $_.Path -like "$PackName*" } | ForEach-Object {

                $text = if ( $L.s56 ) { $L.s56 } else { " Таскбар" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s56_1 ) { $L.s56_1 } else { "Открепление ярлыка от Таскбара" }
                Write-Host "$text" -ForegroundColor DarkGray

                try { $_.InvokeVerb('taskbarunpin') ; Start-Sleep -Milliseconds 200  } catch {}
            }

            [string] $ProvisionedPackageFamilyName = ''

            [array] $GetAppxPackages = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue | 
                Where-Object { $_.PackageFamilyName -like "$PackName*" }

            [string] $BlockedPackage = @($GetAppxPackages).Where({ $_.NonRemovable },'First').PackageFamilyName
            [array] $Sids = $GetAppxPackages.PackageUserInformation.UserSecurityId.Sid

            if ( $BlockedPackage )
            {
                foreach ( $Sid in $Sids )
                {
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\EndOfLife\$Sid\$BlockedPackage"
                    Set-Reg New-Item -Path $Path -NoCheck
                }
            }

            Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Where-Object { $_.PackageName -like "$PackName*" } |
                ForEach-Object {

                    $text = if ( $L.s52_1 ) { $L.s52_1 } else { "   Поиск" }
                    Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                    $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                    Write-host "$text`: " -ForegroundColor Green -NoNewline
                    Write-host "Remove-AppxProvisionedPackage" -ForegroundColor DarkGray

                    $text = if ( $L.s52 ) { $L.s52 } else { "Удаление" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($_.PackageName)" -ForegroundColor White

                    try
                    {
                        $_ | Remove-AppxProvisionedPackage -Online -ErrorAction Stop > $null

                        $ActionDone = $true

                        if ( $_.PublisherId ) { $ProvisionedPackageFamilyName = "$($PackName.Trim('_'))_$($_.PublisherId)" }
                    }
                    catch
                    {
                        try { $HResult = '' ; $HResult = '0x{0}' -f [System.Convert]::ToString($_.exception.HResult, 16) } catch {}

                        $text = if ( $L.s53 ) { $L.s53 } else { "  Ошибка" }
                        
                        if ( $BlockedPackage )
                        {
                            Write-Host "   $text`: $HResult Non Removable Store App. `t$($_.exception.Message)" -ForegroundColor DarkGray
                        }
                        else
                        {
                            Write-Warning "   $text`: $HResult `t$($_.exception.Message)"
                        }

                        $text = if ( $L.s53_1 ) { $L.s53_1 } else { "Эта ошибка из-за зависимости установленных приложений от этого компонента" }
                        if ( $_.exception.Message -like '*80070002*' ) { Write-Warning "$text" }
                    }

                    $ProcessedProvisioned = $true
                }


            if ( -not $ProcessedProvisioned )
            {
                $text = if ( $L.s52_1 ) { $L.s52_1 } else { "   Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                Write-host "$text`: Get-AppxProvisionedPackage" -ForegroundColor DarkYellow
            }


            $GetAppxPackages | ForEach-Object {

                try
                {
                    $text = if ( $L.s52_1 ) { $L.s52_1 } else { "   Поиск" }
                    Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                    $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                    Write-host "$text`: " -ForegroundColor Green -NoNewline
                    Write-host "Get-AppxPackage -AllUsers" -ForegroundColor DarkGray

                    $text = if ( $L.s52 ) { $L.s52 } else { "Удаление" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$($_.PackageFullName) "  -ForegroundColor White -NoNewline

                    [string] $SignatureKind     = $_.SignatureKind
                      [bool] $IsFramework       = $_.IsFramework
                      [bool] $IsResourcePackage = $_.IsResourcePackage
                    [string] $InstallLocation   = $_.InstallLocation

                      [bool] $IsSystemUserExist = $false

                    if ( $SignatureKind -eq 'System' )
                    {
                        Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                        Write-Host "System"  -ForegroundColor DarkCyan

                        if ( $_.PackageUserInformation.UserSecurityId.Username -like 'S-1-5-18' ) { $IsSystemUserExist = $true } 
                    }
                    else { Write-Host }

                    # Закрытие всех запущенных процессов от удаляемого Apps
                    if ( [System.IO.Directory]::Exists($InstallLocation) )
                    {
                        (Get-ChildItem -File -LiteralPath $InstallLocation -Recurse -Depth 1 -ErrorAction SilentlyContinue
                        ).Where({ $_.Name -like '*.exe' }).Foreach({

                            if ( [System.Diagnostics.Process]::GetProcessesByName([System.IO.Path]::GetFileNameWithoutExtension($_.Name)).Count )
                            {
                                if ( $_.Name -eq 'SearchUI.exe' )
                                {
                                    $text = if ( $L.s52_2 ) { $L.s52_2 } else { "Закрытие" }
                                    Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                                    Write-Host "Explorer" -ForegroundColor DarkGray

                                    ReStart-Explorer -Stop
                                }

                                $text = if ( $L.s52_2 ) { $L.s52_2 } else { "Закрытие" }
                                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                                Write-Host "$($_.Name)" -ForegroundColor DarkGray

                                Stop-Process -Name ([System.IO.Path]::GetFileNameWithoutExtension($_.Name)) -Force -ErrorAction SilentlyContinue
                            }
                        })

                        if ( [System.Diagnostics.Process]::GetProcessesByName('BackgroundTaskHost').Count )
                        {
                            $text = if ( $L.s52_2 ) { $L.s52_2 } else { "Закрытие" }
                            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "BackgroundTaskHost.exe" -ForegroundColor DarkGray

                            Stop-Process -Name 'BackgroundTaskHost' -Force -ErrorAction SilentlyContinue
                        }
                    }

                    $_ | Remove-AppxPackage -AllUsers -ErrorAction Continue > $null

                    # Дополнительно удаления для системного юзера, так как нужно выполнять от имени системы с указанием юзера
                    if ( $IsSystemUserExist )
                    {
                        Token-Impersonate -Token SYS

                        # Отключение вывода прогресс бара, так как он зависает поверх консоли под Impersonate
                        $ProgressPreference = 'SilentlyContinue'
                        
                        $_ | Remove-AppxPackage -User 'S-1-5-18' -ErrorAction SilentlyContinue > $null
                        
                        $ProgressPreference = 'Continue'

                        Token-Impersonate -Reset
                    }

                    if ( $IsFramework )
                    {
                        $text = if ( $L.s55 ) { $L.s55 } else { " Пропуск" }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s55_1 ) { $L.s55_1 } else { "Cоздания раздела для Framework" }
                        Write-Host "$text" -ForegroundColor DarkGray
                    }
                    elseif ( $IsResourcePackage )
                    {
                        $text = if ( $L.s55 ) { $L.s55 } else { " Пропуск" }
                        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s55_2 ) { $L.s55_2 } else { "Cоздания раздела для ResourcePackage" }
                        Write-Host "$text" -ForegroundColor DarkGray
                    }
                    elseif (( $SignatureKind -eq 'Store' ) -or ( $SignatureKind -eq 'Developer' ))
                    {
                        $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s54_1 ) { $L.s54_1 } else { "Создание раздела реестра" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        [string] $Path = "$RegPath\$($_.PackageFamilyName)"

                        Set-Reg New-Item -Path $Path
                    }
                    elseif ( $SignatureKind -eq 'System' )
                    {
                        # Удаление разделов

                          [string] $Name        = $_.Name
                        [string[]] $SubKeyNames = $null

                        try
                        {
                                [string] $RegKey     = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications'
                            [psobject] $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                            # Поиск раздела в InboxApplications и удаление его
                            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                            {
                                if ( $SubKey -like "$Name`_*" )
                                {
                                    $SubKeyNames += $SubKey
                                }
                            }

                            $OpenRegKey.Close()
                        }
                        catch {}

                        if ( $SubKeyNames.Count )
                        {
                            $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                            $text = if ( $L.s54_3 ) { $L.s54_3 } else { "Удаление раздела реестра системного App" }
                            Write-Host "$text`:" -ForegroundColor DarkGray

                            foreach ( $SubKeyName in ($SubKeyNames.Where({$_})) )
                            {
                                $Path = "HKLM:\$RegKey\$SubKeyName"

                                Set-Reg Remove-Item -Path $Path
                            }
                        }

                        if ( [System.IO.Directory]::Exists($InstallLocation) )
                        {
                            Set-OwnerAndAccess -Path $InstallLocation -RecoverySDDL 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                            G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(D;;CCWPRCWDWO;;;SY)(A;OICIIO;FA;;;CO)
                            (A;OICIIO;FA;;;SY)(A;;0x1301bf;;;SY)(A;OICIIO;FA;;;BA)(A;;0x1301bf;;;BA)(A;OICI;0x1200a9;;;BU)
                            (A;CI;FA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)(A;OICI;0x1200a9;;;AC)(A;OICI;0x1200a9;;;S-1-15-2-2)'
                        }
                    }

                    $ActionDone = $true
                }
                catch
                {
                    try { $HResult = '' ; $HResult = '0x{0}' -f [System.Convert]::ToString($_.exception.HResult, 16) } catch {}

                    $text = if ( $L.s53 ) { $L.s53 } else { "  Ошибка" }
                    Write-Warning "$text`: $HResult `t$($_.exception.Message)"

                    $text = if ( $L.s53_1 ) { $L.s53_1 } else { "Эта ошибка из-за зависимости установленных приложений от этого компонента" }
                    if ( $_.exception.Message -like '*80070002*' ) { Write-Warning "$text" }
                }
                finally
                {
                    if ( -not [System.Diagnostics.Process]::GetProcessesByName('Explorer').Count )
                    {
                        ReStart-Explorer
                    }
                }

                $Processed = $true
            }

            if ( $BlockedPackage )
            {
                foreach ( $Sid in $Sids )
                {
                    $Path = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\EndOfLife\$Sid\$BlockedPackage"
                    Set-Reg Remove-Item -Path $Path -NoCheck
                }
            }

            if ( -not $Processed )
            {
                $text = if ( $L.s52_1 ) { $L.s52_1 } else { "   Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                Write-host "$text`: Get-AppxPackage -AllUsers" -ForegroundColor DarkYellow
            }

            # Если было удаление
            if ( $Processed -or $ProcessedProvisioned )
            {
                if ( -not $Processed -and $ProvisionedPackageFamilyName )
                {
                    if ( -not ( $ProvisionedPackageFamilyName -match 'Microsoft[.]VCLibs|Microsoft[.]NET|Microsoft[.]UI[.]Xaml|Microsoft[.]Advertising|Microsoft[.]Services[.]Store[.]Engagement' ))
                    {
                        $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s54_1 ) { $L.s54_1 } else { "Создание раздела реестра" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        [string] $Path = "$RegPath\$ProvisionedPackageFamilyName"

                        Set-Reg New-Item -Path $Path
                    }
                }
            }

            # Для выполнения когда удалялся поиск или Cortana (Системные приложения), которые запускаются по ярлыку из Win + X 
            Function Remove-Search-LNK {
            
                # Только для дефолтного профиля
                if ( -not $Global:LastExitCode )
                {
                    $DefAcc = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))

                    if ( $DefAcc.SID -and $DefAcc.NTUSER_Load )
                    {
                        $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s54_4 ) { $L.s54_4 } else { "Удалить ярлык Win + X из папки профиля при первом входе" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        # Удаление ярлыка Win + X из папки профиля при первом входе, который нельзя удалять из дефолтного профиля, из-за привязки к хранилищу компонентов
                        $Path = "Registry::HKU\$($DefAcc.SID)\Software\Microsoft\Windows\CurrentVersion\RunOnce"
                        Set-Reg New-ItemProperty -Path $Path -Name 'RemoveSearchLnk' -Type ExpandString -Value 'cmd /c del /f /q /a "%UserProfile%\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"' -OnlyThisPath
                    }
                }

                $DefProfile   = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile
                $DefSearchLnk = "$DefProfile\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                # Проверить Все включённые профили без исключения из глобальной переменной
                [array] $SearchLnks = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                # Удалить у всех, так как затрагивает всех
                @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
                    $SearchLnks += "$($_.Profile)\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"
                })

                [int] $L = 0
                foreach ( $SearchLnk in $SearchLnks )
                {
                    if ( [System.IO.File]::Exists($DefSearchLnk) -and [System.IO.File]::Exists($SearchLnk) )
                    {
                        $L++

                        if ( $L -eq 1 ) { Write-Host }
                            
                        $text = if ( $L.s14 ) { $L.s14 } else { "Удаление" }
                        Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline

                        $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Ярлык Поиска из меню Win + X" }
                        Write-Host "$text " -ForegroundColor White -NoNewline
                        Write-Host "| $SearchLnk" -ForegroundColor DarkGray

                        try { Remove-Item -LiteralPath \\?\$SearchLnk -Force -ErrorAction Continue } catch {}
                    }
                }
                
                if ( $L ) { Write-Host }
            }

            # Скрытие панели поиска и раздела поиска в параметрах если удаляется приложение поиска и винда 2004 или новее
            if ( $PackName -like 'Microsoft.Windows.Search*' -and [System.Environment]::OSVersion.Version.Build -ge 19041 )
            {
                # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                # бэкап проверяется и создается при необходимости
                RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                Remove-Search-LNK

                $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s54_2 ) { $L.s54_2 } else { "Создание параметра реестра для скрытия панели поиска с Таскбара" }
                Write-Host "$text`:" -ForegroundColor DarkGray

                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 0

                # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                RegHives-User-LoadUnload -DefaultProfile -Unload

                # Скрытие окна параметров из настроек: Поиск -> Разрешение и Журнал
                Set-SettingsPageVisibility -Names 'search-permissions'

                # Скрытие новостей с таскбара, ShellFeed работает через Microsoft.Windows.Search
                if ( [Microsoft.Win32.Registry]::GetValue('HKEY_CLASSES_ROOT\CLSID\{B6D83264-AC99-4C7B-B230-5A15CE7A1F72}','',$null) -like '*ShellFeed*' )
                {
                    #Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds' -Name 'ShellFeedsTaskbarViewMode' -Type DWord 2
                    # Конфигурация компьютера - Административные шаблоны - Компоненты Windоws - Новости и интересы "Включить новости и интересы на панели задач" - "Отключено" 
                    Set-LGP New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' -Name 'EnableFeeds' -Type DWord 0
                }
            }
            elseif ( $PackName -like 'Microsoft.549981C3F5F10*' -and [System.Environment]::OSVersion.Version.Build -ge 19041 ) # Cortana 2004
            {
                $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s54_2 ) { $L.s54_2 } else { "Создание параметра реестра для скрытия панели поиска с Таскбара" }
                Write-Host "$text`:" -ForegroundColor DarkGray

                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 0

                # Скрытие окна параметров из настроек: Поиск -> Кортана...
                Set-SettingsPageVisibility -Names 'cortana','cortana-permissions','cortana-notifications',
                                                  'cortana-moredetails','cortana-language','cortana-windowssearch'
            }
            elseif ( $PackName -like 'Microsoft.Windows.Cortana*' -and [System.Environment]::OSVersion.Version.Build -lt 19041 ) # До 2004
            {
                # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                # бэкап проверяется и создается при необходимости
                RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                Remove-Search-LNK

                $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s54_2 ) { $L.s54_2 } else { "Создание параметра реестра для скрытия панели поиска с Таскбара" }
                Write-Host "$text`:" -ForegroundColor DarkGray

                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 0

                # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                RegHives-User-LoadUnload -DefaultProfile -Unload

                # Скрытие окна параметров из настроек: Поиск -> Кортана...
                Set-SettingsPageVisibility -Names 'cortana','cortana-permissions','cortana-notifications',
                                                  'cortana-moredetails','cortana-language','cortana-windowssearch'
            }
            elseif ( $PackName -like '*CloudExperienceHost*' )
            {
                Set-PrivacySettingsOOBE

                Set-Tsk Disable-ScheduledTask -TaskName '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask'
                    
                Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CloudExperienceHost' -Name 'ETWLoggingEnabled' -Type DWord 0

                if ( [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe').Name )
                {
                    Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\Autologger\CloudExperienceHostOobe' -Name 'Start' -Type DWord 0
                }
            }
            elseif ( $PackName -like 'MicrosoftTeams*' -and [System.Environment]::OSVersion.Version.Build -ge 22000 ) # от W11
            {
                # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                # бэкап проверяется и создается при необходимости
                RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s54_5 ) { $L.s54_5 } else { 'Скрыть иконку "Чат" на панели задач (W11)' }
                Write-Host "$text`:" -ForegroundColor DarkGray

                Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarMn' -Type DWord 0

                # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                RegHives-User-LoadUnload -DefaultProfile -Unload
            }


            [array] $DesktopPaths = $DesktopPath

            if ( $Global:DataAllUsers.Redirects.Value )
            {
                @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.SID })).ForEach({
                    
                    try { $UserDesktop = [Microsoft.Win32.Registry]::GetValue("HKEY_USERS\$($_.SID)\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders",'Desktop',$null) }
                    catch { $UserDesktop = $null }
                    
                    if ( $UserDesktop )
                    {
                        $DesktopPaths += $UserDesktop
                    }
                })
            }

            foreach ( $DesktopPath in $DesktopPaths )
            {
                # Если существует папка рабочего стола
                if ( [System.IO.Directory]::Exists($DesktopPath) )
                {
                    # Поиск ярлыков по названию приложения внутри ярлыка, чтобы не зависеть от названия самого ярлыка
                    (Get-ChildItem -File -LiteralPath \\?\$DesktopPath).Where({ $_.Extension -eq '.lnk' }).Foreach({

                        if ( (Get-Content -Encoding Unicode "$($_.FullName)" -ErrorAction SilentlyContinue) -like "*$PackName*" )
                        {
                            $text = if ( $L.s56_2 ) { $L.s56_2 } else { "   Ярлык" }
                            Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                            $text = if ( $L.s56_3 ) { $L.s56_3 } else { "Удаление найденного ярлыка" }
                            Write-host "$text`: " -ForegroundColor Magenta -NoNewline

                            $text = if ( $L.s56_4 ) { $L.s56_4 } else { "Рабочий стол" }
                            Write-host "$text\" -ForegroundColor DarkGray -NoNewline
                            Write-host "$($_.Name)" -ForegroundColor White

                            Remove-Item -LiteralPath "$($_.FullName)" -Force -ErrorAction SilentlyContinue
                        }
                    })
                }
            }
        }

        $text = if ( $L.s30 ) { $L.s30 } else { "Завершено" }
        Write-Host "`n   $text`n" -ForegroundColor Green
    }
    elseif ( $Option -eq 'RunInstallApps' )
    {
        # Отключение вывода прогресс бара, так как у Add-AppxPackage он глючит и зависает поверх консоли
        $ProgressPreference = 'SilentlyContinue'

        # Если исправить проблемные Apps, зарегистрировать подготовленные новые версии
        if ( $FixInstalledAppsProblems )
        {
            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

            $Staged = @()

            foreach ( $Appx in $GetAppxAll )
            {
                # Если Apps загружен (Staged) и может быть установлен (Ок)
                if ( "$($Appx.PackageUserInformation.InstallState)" -eq 'Staged' -and $Appx.Status -eq 'Ok' -and $Appx.InstallLocation )
                {
                    # Если нет установленной более новой версии 
                    if ( -not ($GetAppxAll.Where({( ($_.PackageUserInformation -join '|') -like "*[[]$env:USERNAME[]]: Installed*" ) -and
                       ( $_.Status -eq 'Ok' ) -and ( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                       ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                    {
                        # Если добавленная версия для установки старее, заменить ее на подготовленную и более новую 
                        if ( -not ($Staged.Where({( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                           ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                        {
                            # Проблема | добавить в список для установки, убрав другую добавленную
                            $Staged = $Staged.Where({ $_.Name -ne $Appx.Name })
                            $Staged += $Appx
                        }
                    }
                }
            }
            
            [array] $InstallPackNames = $Staged.Name | Sort-Object
        }

        if ( $Select -and $InstallPackNames.Count )
        {
            if ( $FixInstalledAppsProblems )
            {
                $text = if ( $L.s57_3 ) { $L.s57_3 } else { "Исправление" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline
            }
            else
            {
                $text = if ( $L.s57 ) { $L.s57 } else { "Установка" }
                Write-Host "`n   $text " -ForegroundColor Blue -NoNewline
            }

            $text = if ( $L.s57_1 ) { $L.s57_1 } else { "приложений по выбору" }
            Write-Host "$text " -ForegroundColor Gray -NoNewline

            if ( $RestoreSystemApps )
            {
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "System `n" -ForegroundColor Magenta

                Set-Apps-Management -CheckState UninstallInstallApps -RestoreSystemApps
            }
            elseif ( $FixInstalledAppsProblems )
            {
                Write-Host "`n"

                Set-Apps-Management -CheckState InstalledAppsProblems -FixInstalledAppsProblems
            }
            else
            {
                Write-Host "`n"

                Set-Apps-Management -CheckState UninstallInstallApps
            }

            # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
              [char] $Escape          = 27
               [int] $StringsExcl     = 3              # Количество последних строк для затирания.
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline


            # Ждем ввода пользователя.
            $text = if ( $L.s32 ) { $L.s32 } else { 'Введите номера Apps через пробел и/или диапазон через дефис' }

            Write-Host "`n   $text"

            $text = if ( $L.s98 ) { $L.s98 } else { 'Номера' }

            [string] $Choice = Read-Host -Prompt "   $text"

               [array] $SelectedApps    = @()
            [Uint16[]] $SelectedNumbers = $null

            # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
            # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера.
            # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedApps, с выбранными существующми намерами.
            if ( -not ( $Choice.Trim() -eq '' ))
            {
                [array] $arr = @()
                
                # Добавление групп указанных через дефис
                foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

                $arr | ForEach-Object {
                    
                    try
                    {
                        [Uint16] $AppNumber = $_

                        if (( $AppNumber -gt 0 ) -and ( $AppNumber -le $InstallPackNames.Count ) -and ( $SelectedApps -notcontains $AppNumber ))
                        {
                            $SelectedApps += $InstallPackNames[( $AppNumber - 1 )]
                            $SelectedNumbers += $AppNumber
                        }
                    }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Отмена' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            if ( -not $SelectedApps )
            {
                $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Неверный выбор!' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            $InstallPackNames = $SelectedApps | Sort-Object

            $text = if ( $L.s33_2 ) { $L.s33_2 } else { 'Выбранные Номера' }
            Write-HostColor "`n    $text`: #DarkGray#[ #White#$SelectedNumbers #DarkGray#]#"
        }
        else
        {
            if ( $FixInstalledAppsProblems )
            {
                $text = if ( $L.s57_3 ) { $L.s57_3 } else { "Исправление" }
                Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline
            }
            else
            {
                $text = if ( $L.s57 ) { $L.s57 } else { "Установка" }
                Write-Host "`n   $text " -ForegroundColor Blue -NoNewline
            }

            $text = if ( $L.s57_2 ) { $L.s57_2 } else { "приложений" }
            Write-Host "$text " -ForegroundColor Gray -NoNewline

            if ( $RestoreSystemApps )
            {
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "System" -ForegroundColor Magenta
            }
            else { Write-Host }
        }

        if ( -not $RestoreSystemApps )
        {
            if ( $InstallPackNames.Count )
            {
                [int] $N = 0

                if ( $Select )  
                { 
                    if ( $FixInstalledAppsProblems )
                    {
                        $text = if ( $L.s58_2 ) { $L.s58_2 } else { "Выбранные приложения для исправления" }
                    }
                    else
                    {
                        $text = if ( $L.s58   ) { $L.s58   } else { "Выбранные приложения для установки"   }
                    }
                }
                else
                {
                    if ( $FixInstalledAppsProblems )
                    {
                        $text = if ( $L.s58_1 ) { $L.s58_1 } else { "Найденные приложения для исправления" }
                    }
                    else
                    {
                        $text = if ( $L.s59   ) { $L.s59   } else { "Указанные приложения для установки"   }
                    }
                }

                Write-Host "`n   $text`:`n" -ForegroundColor White

                $InstallPackNames | ForEach-Object {
                    $N++
                    if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }
                    Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$_"  -ForegroundColor Blue
                }
            }
            else
            {
                if ( $FixInstalledAppsProblems )
                {
                    $text = if ( $L.s13_3 ) { $L.s13_3 } else { "Не найдено не зарегистрированных Apps" }
                    Write-Host "`n   $text`n" -ForegroundColor Green
                }
                else
                {
                    $text = if ( $L.s60 ) { $L.s60 } else { "Не указаны приложения для установки!" }
                    Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                }

                # Если запуск не из главных меню быстрых настроек (0 и 1)
                if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
                {
                    Get-Pause
                }

                Return   # Выход
            }
        }

        # Восстановление доступа по умолчанию +, для перестраховки.
        Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications' -RecoverySDDL '
        O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
        G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(A;CI;KR;;;SY)(A;CIIO;KA;;;SY)
        (A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)(A;CI;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
        (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'


        # Временное включение режима разработчика, это нужно только для этапа установки приложения, потом режим будет отключен
        Get-Developer-Mode -EnableDevMode

        $GetAppx    = @()
        $GetAppxAll = @()

        $InstallPackNames = $InstallPackNames.ForEach({ "$(($_).ToString().Trim(' _'))_" })

        foreach ( $PackName in $InstallPackNames )
        {
            Start-Sleep -Milliseconds 500

            $GetAppx    = Get-AppxPackage -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue
            $GetAppxAll = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction SilentlyContinue

            $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($PackName.Trim('_'))"  -ForegroundColor Blue

            if ( $GetAppx.PackageFamilyName -like "$PackName*" )
            {
                $text = if ( $L.s61 ) { $L.s61 } else { "Состояние" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                if ( $FixInstalledAppsProblems )
                {
                    $text = if ( $L.s61_3 ) { $L.s61_3 } else { "Не установлен | Ригистрация" }
                    Write-Host "$text"  -ForegroundColor DarkGreen
                }
                else
                {
                    $text = if ( $L.s61_1 ) { $L.s61_1 } else { "Уже установлен | Переригистрация" }
                    Write-Host "$text"  -ForegroundColor DarkGreen
                }
            }

            [int] $N = 0

            if ( $GetAppxAll.PackageFamilyName -like "$PackName*" )
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor Green -NoNewline

                $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                Write-host "$text`: " -ForegroundColor Green -NoNewline
                Write-host "Get-AppxPackage -AllUsers" -ForegroundColor DarkGray

                $(if ( $FixInstalledAppsProblems )
                {
                    $Staged = @()
                    
                    foreach ( $Appx in ( $GetAppxAll.Where({ $_.PackageFamilyName -like "$PackName*" }) ))
                    {
                        # Если Apps загружен (Staged) и может быть установлен (Ок)
                        if ( "$($Appx.PackageUserInformation.InstallState)" -eq 'Staged' -and $Appx.Status -eq 'Ok' -and $Appx.InstallLocation )
                        {
                            # Если нет установленной более новой версии 
                            if ( -not ($GetAppxAll.Where({( ($_.PackageUserInformation -join '|') -like "*[[]$env:USERNAME[]]: Installed*" ) -and
                               ( $_.Status -eq 'Ok' ) -and ( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                               ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                            {
                                # Если добавленная версия для установки старее, заменить ее на подготовленную и более новую 
                                if ( -not ($Staged.Where({( $_.Name -eq $Appx.Name ) -and ( $_.Architecture -eq $Appx.Architecture ) -and
                                   ( [version] $_.Version -ge [version] $Appx.Version ) },'First') ))
                                {
                                    # Проблема | добавить в список для установки, убрав другую добавленную
                                    $Staged = $Staged.Where({ $_.Name -ne $Appx.Name })
                                    $Staged += $Appx
                                }
                            }
                        }
                    }
                    
                    $Staged | Sort-Object -Property Name
                }
                else { $GetAppxAll | Where-Object { $_.PackageFamilyName -like "$PackName*" } }) | ForEach-Object {

                    # Если не сохранить в переменную из $_, то ошибка у Add-AppxPackage из-за кодировки в пути с кириллицей
                    [string] $Manifest    = "$($_.InstallLocation)\AppxManifest.xml"
                    [string] $Package     = $_.PackageFullName
                    [string] $PackageName = $_.Name

                    # Пропуск при отсутствии манифеста, или исключить регистрацию пакета с другой разрядностью,
                    # так как установлено может быть обе разрядности через AppxProvisionedPackage, а зарегистрировать можно только одну из них,
                    # пропуск для исключения лишних выводов об ошибках
                    if ( -not (Test-Path -LiteralPath $Manifest -PathType Leaf -ErrorAction SilentlyContinue) ) { Return }  # пропуск итерации
                    elseif ( $N -ge 1 ) { Return }  # пропуск повторной регистрации (итерации)

                    [string] $SignatureKind = $_.SignatureKind

                    if ( $SignatureKind -eq 'System' )
                    {
                        # Восстановление параметра или раздела реестра системного App, если отсутствует или не верный

                          [string] $Name        = $_.Name
                        [string[]] $SubKeyNames = $null
                          [string] $Path        = ''
                          [string] $Value       = ''

                        try
                        {
                              [string] $RegKey     = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications'
                            [psobject] $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                            # Поиск разделов в InboxApplications
                            foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                            {
                                if ( $SubKey -like "$Name`_*" )
                                {
                                    $SubKeyNames += $SubKey
                                }
                            }

                            $OpenRegKey.Close()
                        }
                        catch {}


                        [array] $Identity = Get-AppxManifest-Identity -AppxManifest $Manifest

                        if ( $Identity.Identity )
                        {
                            $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                            $text = if ( $L.s24_6 ) { $L.s24_6 } else { "Восстановление раздела реестра для системного App" }
                            Write-Host "$text`:" -ForegroundColor DarkGray

                            if ( $SubKeyNames.Count )
                            {
                                if ( "$SubKeyNames" -ne "$($Identity.Identity)" )
                                {
                                    foreach ( $SubKeyName in ($SubKeyNames.Where({$_})) )
                                    {
                                        $Path = "HKLM:\$RegKey\$SubKeyName"

                                        Set-Reg Remove-Item -Path $Path
                                    }
                                }
                            }

                            $Path  = "HKLM:\$RegKey\$($Identity.Identity)"
                            $Value = $Manifest

                            Set-Reg New-ItemProperty -Path $Path -Name 'Path' -Type String $Value

                            Set-OwnerAndAccess -Path $Path -RecoverySDDL 'O:BAG:SYD:PAI(A;OICI;KA;;;SY)(A;OICI;KA;;;BA)(A;OICI;KR;;;BU)'
                        }
                        else
                        {
                            $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                            Write-Host "   $text`: "  -ForegroundColor DarkYellow -NoNewline

                            $text = if ( $L.s24_7 ) { $L.s24_7 } else { "Раздел реестра для системного App не восстановлен" }
                            Write-host "$text" -ForegroundColor Red
                        }
                    }

                    # Убрать проблему Windows: блокировку установки пакета, если есть.
                    if ( $FixInstalledAppsProblems )
                    {
                        [string[]] $Keys = 'HKEY_CLASSES_ROOT\Local Settings\Software\Microsoft\Windows\CurrentVersion\AppModel\Repository\Packages',
                            'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\AppModel\StateChange\PackageList'

                        foreach ( $Key in $Keys )
                        {
                            try
                            {
                                if ( $Key -like 'HKEY_CLASSES_ROOT\*' ) { $OpenSubKey = [Microsoft.Win32.Registry]::ClassesRoot.OpenSubKey($Key.Replace('HKEY_CLASSES_ROOT\',''),'ReadSubTree','QueryValues,EnumerateSubKeys') }
                                else { $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($Key.Replace('HKEY_LOCAL_MACHINE\',''),'ReadSubTree','QueryValues,EnumerateSubKeys') }
                            }
                            catch {}

                            if ( $OpenSubKey )
                            {
                                foreach ( $KeyName in ( $OpenSubKey.GetSubKeyNames() -like "$PackageName`_*" ))
                                {
                                    if ( [Microsoft.Win32.Registry]::GetValue("$Key\$KeyName",'PackageStatus',$null) )
                                    {
                                        $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                                        $text = if ( $L.s24_9 ) { $L.s24_9 } else { "Удаление проблемного параметра" }
                                        Write-Host "$text`:" -ForegroundColor DarkGray

                                        $Path = "Registry::$Key\$KeyName"
                                        Set-Reg Remove-ItemProperty -Path $Path -Name 'PackageStatus'
                                    }
                                }

                                $OpenSubKey.Close()
                            }
                        }
                    }

                    try
                    {
                        Add-AppxPackage -DisableDevelopmentMode -Register $Manifest -ForceApplicationShutdown -ErrorAction Stop

                        $N++

                        $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                        Write-host "$text`: $Package " -ForegroundColor Green -NoNewline

                        if ( $_.SignatureKind -eq 'System' )
                        {
                            Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                            Write-Host "System"  -ForegroundColor DarkCyan
                        }
                        else { Write-Host }

                        $ActionDone = $true
                    }
                    catch
                    {
                        $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                        Write-Host "   $text`: "  -ForegroundColor Red -NoNewline

                        Write-host "Add-AppxPackage: $Package > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                    }

                    Start-Sleep -Milliseconds $SleepMS
                }

                # Если зарегистрирован
                if ( $N -and ( -not $FixInstalledAppsProblems ))
                {
                    # Создание ярлыка на рабочем столе после установки только для этих приложений: Магазин, FSClient
                    [string[]] $ShortcutDesktop = 'Microsoft.WindowsStore','24831TIRRSOFT.FS'

                    [string] $AppsMatch = "^$($ShortcutDesktop.ForEach({[regex]::Escape($_)}) -join '_?$|^')_?$"

                    if ( $PackName -match $AppsMatch )
                    {
                        $text = if ( $L.s24_3 ) { $L.s24_3 } else { "    Ярлык" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s24_4 ) { $L.s24_4 } else { "Создание ярлыка на Рабочем столе" }
                        Write-host "$text" -ForegroundColor DarkCyan

                        Create-Desktop-UwpShortcut -UwpName $PackName
                    }

                    Continue   # перейти к следующему приложению.
                }
            }
            else
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                Write-host "$text`: Get-AppxPackage -AllUsers" -ForegroundColor DarkYellow
            }

            # Если испрваление подготовленных не установленных Apps, то перейти к следующему приложению
            if ( $FixInstalledAppsProblems )
            {
                Continue
            }


            [string[]] $FoundManifests = $null
            [string] $Path = "$env:ProgramFiles\WindowsApps\"

            $FoundManifests = (Get-ChildItem -Directory $Path -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like "$($PackName.Trim('_'))*" }).Foreach({
                (Get-ChildItem -File -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue).FullName.Where({ ( $_ -notlike '*_split.*' ) -and ( $_ -like '*AppxManifest.xml' ) })
            })

            [int] $N = 0

            if ( $FoundManifests )
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor Green -NoNewline

                $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                Write-host "$text`: " -ForegroundColor Green -NoNewline
                Write-host "$Path" -ForegroundColor DarkGray

                $FoundManifests | ForEach-Object {

                    # Если не сохранить в переменную из $_, то ошибка у Add-AppxPackage из-за кодировки в пути с кириллицей
                    [string] $Manifest = $_
                    [string] $FullName = $Manifest -Replace ('.+\\([^\s\\]+)\\.+','$1')

                    try
                    {
                        Add-AppxPackage -DisableDevelopmentMode -Register $Manifest -ForceApplicationShutdown -ErrorAction Stop

                        $N++

                        $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                        Write-host "$text`: $FullName" -ForegroundColor Green

                        $ActionDone = $true
                    }
                    catch
                    {
                        $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                        Write-Host "   $text`: "  -ForegroundColor Red -NoNewline

                        Write-host "Add-AppxPackage: $FullName > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                    }

                    Start-Sleep -Milliseconds $SleepMS
                }

                # Если зарегистрирован
                if ( $N )
                {
                    # Создание ярлыка на рабочем столе после установки только для этих приложений: Магазин, FSClient
                    [string[]] $ShortcutDesktop = 'Microsoft.WindowsStore','24831TIRRSOFT.FS'

                    [string] $AppsMatch = "^$($ShortcutDesktop.ForEach({[regex]::Escape($_)}) -join '_?$|^')_?$"

                    if ( $PackName -match $AppsMatch )
                    {
                        $text = if ( $L.s24_3 ) { $L.s24_3 } else { "    Ярлык" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s24_4 ) { $L.s24_4 } else { "Создание ярлыка на Рабочем столе" }
                        Write-host "$text" -ForegroundColor DarkCyan

                        Create-Desktop-UwpShortcut -UwpName $PackName
                    }

                    Continue   # перейти к следующему приложению.
                }
            }
            else
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                Write-host "$text`: $Path" -ForegroundColor DarkYellow
            }



            # System

            [array] $Identity = @()

            $Identity = $SystemIdentitys.Where({ $_.Name -eq "$($PackName.Trim('_'))" },'First',1)

            [string] $SysPathsShow = "$env:SystemDrive\Windows\(SystemApps/PrintDialog/ImmersiveControlPanel)"

            if ( $Identity.SysPath ) { $SysPathsShow = $Identity.SysPath }

            [bool] $SystemNotFound = $false
             [int] $N = 0

            if ( $Identity.Identity )
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor Green -NoNewline

                $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                Write-host "$text`: " -ForegroundColor Green -NoNewline
                Write-host "$SysPathsShow" -ForegroundColor DarkGray


                [string] $Manifest = $Identity.Manifest

                  [string] $Name        = $Identity.Name
                [string[]] $SubKeyNames = $null
                  [string] $Path        = ''
                  [string] $Value       = ''

                try
                {
                      [string] $RegKey     = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications'
                    [psobject] $OpenRegKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey,'ReadSubTree','QueryValues,EnumerateSubKeys')

                    # Поиск разделов в InboxApplications
                    foreach ( $SubKey in $OpenRegKey.GetSubKeyNames() )
                    {
                        if ( $SubKey -like "$Name`_*" )
                        {
                            $SubKeyNames += $SubKey
                        }
                    }

                    $OpenRegKey.Close()
                }
                catch {}


                $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                $text = if ( $L.s24_6 ) { $L.s24_6 } else { "Восстановление раздела реестра для системного App" }
                Write-Host "$text`:" -ForegroundColor DarkGray

                if ( $SubKeyNames.Count )
                {
                    if ( "$SubKeyNames" -ne "$($Identity.Identity)" )
                    {
                        foreach ( $SubKeyName in ($SubKeyNames.Where({$_})) )
                        {
                            $Path = "HKLM:\$RegKey\$SubKeyName"

                            Set-Reg Remove-Item -Path $Path
                        }
                    }
                }

                $Path  = "HKLM:\$RegKey\$($Identity.Identity)"
                $Value = $Manifest

                Set-Reg New-ItemProperty -Path $Path -Name 'Path' -Type String $Value

                Set-OwnerAndAccess -Path $Path -RecoverySDDL 'O:BAG:SYD:PAI(A;OICI;KA;;;SY)(A;OICI;KA;;;BA)(A;OICI;KR;;;BU)'

                [string] $InstallLocation = $Identity.InstallLocation
                if ( [System.IO.Directory]::Exists($InstallLocation) )
                {
                    Set-OwnerAndAccess -Path $InstallLocation -RecoverySDDL 'O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
                    G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(A;OICIIO;GA;;;CO)(A;OICIIO;GA;;;SY)(A;;0x1301bf;;;SY)(A;OICIIO;GA;;;BA)
                    (A;;0x1301bf;;;BA)(A;OICIIO;GXGR;;;BU)(A;;0x1200a9;;;BU)(A;CIIO;GA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
                    (A;;FA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)(A;;0x1200a9;;;AC)(A;OICIIO;GXGR;;;AC)(A;;0x1200a9;;;S-1-15-2-2)
                    (A;OICIIO;GXGR;;;S-1-15-2-2)'
                }

                try
                {
                    Add-AppxPackage -DisableDevelopmentMode -Register $Manifest -ForceApplicationShutdown -ErrorAction Stop

                    $N++

                    $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                    Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s61_2 ) { $L.s61_2 } else { "Зарегистрирован" }
                    Write-host "$text`: $($Identity.Identity) " -ForegroundColor Green -NoNewline
                    Write-Host "| "  -ForegroundColor DarkGray -NoNewline
                    Write-Host "System"  -ForegroundColor DarkCyan

                    $ActionDone = $true
                }
                catch
                {
                    $text = if ( $L.s19_2 ) { $L.s19_2 } else { " Register" }
                    Write-Host "   $text`: "  -ForegroundColor Red -NoNewline

                    Write-host "Add-AppxPackage: $($Identity.Identity) > $($_.CategoryInfo.Category): $($_.Exception.Message)" -ForegroundColor Red
                }

                Start-Sleep -Milliseconds $SleepMS

                # Если зарегистрирован
                if ( $N )
                {
                    # Создание ярлыка на рабочем столе после установки только для этих приложений: Магазин, FSClient
                    [string[]] $ShortcutDesktop = 'Microsoft.WindowsStore','24831TIRRSOFT.FS'

                    [string] $AppsMatch = "^$($ShortcutDesktop.ForEach({[regex]::Escape($_)}) -join '_?$|^')_?$"

                    if ( $PackName -match $AppsMatch )
                    {
                        $text = if ( $L.s24_3 ) { $L.s24_3 } else { "    Ярлык" }
                        Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                        $text = if ( $L.s24_4 ) { $L.s24_4 } else { "Создание ярлыка на Рабочем столе" }
                        Write-host "$text" -ForegroundColor DarkCyan

                        Create-Desktop-UwpShortcut -UwpName $PackName
                    }

                    # Для выполнения когда устанавливался поиск, который запускается по ярлыку из Win + X
                    Function Restore-Search-LNK {
            
                        # Только для дефолтного профиля
                        if ( -not $Global:LastExitCode )
                        {
                            $DefAcc = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First'))

                            if ( $DefAcc.SID -and $DefAcc.NTUSER_Load )
                            {
                                $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                                Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                                $text = if ( $L.s24_10 ) { $L.s24_10 } else { "Убрать Удаление ярлыка Win + X из папки профиля при первом входе" }
                                Write-Host "$text`:" -ForegroundColor DarkGray

                                # Убрать Удаление ярлыка Win + X из папки профиля при первом входе, который нельзя удалять из дефолтного профиля, из-за привязки к хранилищу компонентов
                                $Path = "Registry::HKU\$($DefAcc.SID)\Software\Microsoft\Windows\CurrentVersion\RunOnce"
                                Set-Reg Remove-ItemProperty -Path $Path -Name 'RemoveSearchLnk' -OnlyThisPath
                            }
                        }

                        $DefProfile   = @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'DefaultAccount' },'First')).Profile
                        $DefSearchLnk = "$DefProfile\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                        # Проверить Все включённые профили без исключения из глобальной переменной
                        [array] $SearchLnks = "$env:USERPROFILE\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"

                        # Восстановить у всех, так как затрагивает всех
                        @($Global:DataAllUsers.Where({ $_.ProfileType -eq 'User' -and $_.Profile })).ForEach({
                            $SearchLnks += "$($_.Profile)\AppData\Local\Microsoft\Windows\WinX\Group2\2 - Search.lnk"
                        })

                        [int] $L = 0
                        foreach ( $SearchLnk in $SearchLnks )
                        {
                            if ( [System.IO.File]::Exists($DefSearchLnk) -and ( -not [System.IO.File]::Exists($SearchLnk) ) )
                            {
                                $L++

                                if ( $L -eq 1 ) { Write-Host }
                            
                                $text = if ( $L.s14_2 ) { $L.s14_2 } else { "Восстановление" }
                                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline

                                $text = if ( $L.s14_1 ) { $L.s14_1 } else { "Ярлык Поиска из меню Win + X" }
                                Write-Host "$text" -ForegroundColor White -NoNewline
                                Write-Host "| $SearchLnk" -ForegroundColor DarkGray

                                try { Copy-Item -Path $DefSearchLnk -Destination $SearchLnk -Force -ErrorAction Continue } catch {}
                            }
                        }
                
                        if ( $L ) { Write-Host }
                    }

                    # Возврат панели поиска и раздела поиска в параметрах если устанавливается приложение поиска и винда 2004 или новее
                    if ( $PackName -like 'Microsoft.Windows.Search*' -and [System.Environment]::OSVersion.Version.Build -ge 19041 )
                    {
                        # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                        # бэкап проверяется и создается при необходимости
                        RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                        Restore-Search-LNK

                        $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s24_8 ) { $L.s24_8 } else { "Изменение параметра реестра для отображения панели поиска на Таскбаре" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 2

                        # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                        RegHives-User-LoadUnload -DefaultProfile -Unload

                        # Возврат окна параметров в настройки: Поиск -> Разрешение и Журнал
                        Set-SettingsPageVisibility -Names 'search-permissions' -Remove

                        # Возврат новостей с таскбара, ShellFeed работает через Microsoft.Windows.Search
                        if ( [Microsoft.Win32.Registry]::GetValue('HKEY_CLASSES_ROOT\CLSID\{B6D83264-AC99-4C7B-B230-5A15CE7A1F72}','',$null) -like '*ShellFeed*' )
                        {
                            #Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds' -Name 'ShellFeedsTaskbarViewMode' -Type DWord 0
                            Set-LGP Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' -Name 'EnableFeeds'
                        }
                    }
                    elseif ( $PackName -like 'Microsoft.549981C3F5F10*' -and [System.Environment]::OSVersion.Version.Build -ge 19041 ) # Cortana 2004
                    {
                        $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s24_8 ) { $L.s24_8 } else { "Изменение параметра реестра для отображения панели поиска на Таскбаре" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'ShowCortanaButton' -Type DWord 1 -OnlyThisPath

                        # Возврат окна параметров в настройки: Поиск -> Кортана...
                        Set-SettingsPageVisibility -Names 'cortana' -Remove
                    }
                    elseif ( $PackName -like 'Microsoft.Windows.Cortana*' -and [System.Environment]::OSVersion.Version.Build -lt 19041 ) # До 2004
                    {
                        # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                        # бэкап проверяется и создается при необходимости
                        RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                        Restore-Search-LNK

                        $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s24_8 ) { $L.s24_8 } else { "Изменение параметра реестра для отображения панели поиска на Таскбаре" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' -Name 'SearchboxTaskbarMode' -Type DWord 1

                        # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                        RegHives-User-LoadUnload -DefaultProfile -Unload

                        # Возврат окна параметров в настройки: Поиск -> Кортана...
                        Set-SettingsPageVisibility -Names 'cortana' -Remove
                    }
                    elseif ( $PackName -like '*CloudExperienceHost*' )
                    {
                        Set-Tsk Enable-ScheduledTask -TaskName '\Microsoft\Windows\CloudExperienceHost\CreateObjectTask'
                    }
                    elseif (($PackName -like 'InputApp*'                    -and [System.Environment]::OSVersion.Version.Build -lt 19041 ) -or # До 2004
                           ( $PackName -like 'MicrosoftWindows.Client.CBS*' -and [System.Environment]::OSVersion.Version.Build -ge 19041 ))    # От 2004
                    {
                        $text = if ( $L.s24_5 ) { $L.s24_5 } else { "   Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s24_11 ) { $L.s24_11 } else { "Включить доступ к набору текста для всех UWP" }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabled' -Type DWord 1
                        Set-Reg New-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Input' -Name 'InputServiceEnabledForCCI' -Type DWord 1
                    }
                    elseif ( $PackName -like 'MicrosoftTeams*' -and [System.Environment]::OSVersion.Version.Build -ge 22000 ) # от W11
                    {
                        # Если не было задано настраивать полностью дефолтный профиль, подгрузить временно его куст для текущей настройки, с отображением в консоли
                        # бэкап проверяется и создается при необходимости
                        RegHives-User-LoadUnload -DefaultProfile -Load -IndentBefore

                        $text = if ( $L.s54 ) { $L.s54 } else { "  Реестр" }
                        Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline

                        $text = if ( $L.s54_6 ) { $L.s54_6 } else { 'Показать иконку "Чат" на панели задач (W11)' }
                        Write-Host "$text`:" -ForegroundColor DarkGray

                        Set-Reg New-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' -Name 'TaskbarMn' -Type DWord 1

                        # Если не задано было настраивать полностью дефолтный профиль, выгрузить его куст, с отображением в консоли
                        RegHives-User-LoadUnload -DefaultProfile -Unload
                    }

                    Continue   # перейти к следующему приложению.
                }
            }
            else
            {
                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                if ( -not $Identity.InstallLocation )
                {
                    $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                    Write-host "$text`: $SysPathsShow" -ForegroundColor DarkYellow

                    $SystemNotFound = $true
                }
                else
                {
                    $text = if ( $L.s62_4 ) { $L.s62_4 } else { "Проблема с системной папкой" }
                    Write-host "$text`: $($Identity.InstallLocation)" -ForegroundColor Red

                    $text = if ( $L.s19 ) { $L.s19 } else { "Результат" }
                    Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s62_2 ) { $L.s62_2 } else { "Приложение не установлено" }
                    Write-host "$text" -ForegroundColor Red

                    Continue    # Перейти к следующему приложению
                }
            }

            # Если восстановление системных Appx, то перейти к следующей итерации (имени)
            if ( $RestoreSystemApps ) { Continue }


            ######### Appx Folder  ##################################################################################


            # Если не указана папка для своих Appx, то пропустить дальнейшие проверки и действия, перейти к следующей итерации (имени)
            if ( -not $AppxFolder ) { Continue }

            if ( -not $ActionDone -or $SystemNotFound )
            {
                [string] $FoundFolder = ''
                $FoundFolder = (Get-ChildItem -File -LiteralPath $AppxFolder -Recurse -Force -ErrorAction SilentlyContinue).Where({
                    $_.Name -match "^$PackName.+$MatchesFileExtensions" -and $_.Name -notmatch $ExclArch },'First',1).DirectoryName

                if ( -not $FoundFolder )
                {
                    $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                    Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s62_1 ) { $L.s62_1 } else { "Приложение не найдено в" }
                    Write-host "$text`: $AppxFolder" -ForegroundColor DarkYellow

                    $text = if ( $L.s19 ) { $L.s19 } else { "Результат" }
                    Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                    $text = if ( $L.s62_2 ) { $L.s62_2 } else { "Приложение не установлено" }
                    Write-host "$text" -ForegroundColor Red

                    Continue    # Перейти к следующему приложению
                }


                $text = if ( $L.s62 ) { $L.s62 } else { "    Поиск" }
                Write-Host "   $text`: "  -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s62_3 ) { $L.s62_3 } else { "Приложение найдено в" }
                Write-host "$text`: " -ForegroundColor Green -NoNewline
                Write-host "$($FoundFolder.Replace("$CurrentRoot\",''))" -ForegroundColor White

                Install-Appx-FromFolder -Folder $FoundFolder
            }
        }

        # Возврат показа прогресс бара
        $ProgressPreference = 'Continue'

        $text = if ( $L.s30 ) { $L.s30 } else { "Завершено" }
        Write-Host "`n   $text`n" -ForegroundColor Green
    }
    elseif ( $Option -eq 'RunDownloadAppx' )
    {
        $text = if ( $L.s64 ) { $L.s64 } else { "Закачка Appx" }
        Write-Host "`n   $text`: " -ForegroundColor White -NoNewline

        $text = if ( $L.s64_1 ) { $L.s64_1 } else { "с microsoft.com | Получение ссылок через store.rg-adguard.net" }
        Write-Host "$text" -ForegroundColor DarkGray

        if ( -not $DownloadAppx.Count )
        {
            $text = if ( $L.s65 ) { $L.s65 } else { "Не Настроены Appx для Закачки" }
            Write-Host "`n   $text" -ForegroundColor DarkYellow

            Get-Pause ; Return    # Выход
        }
        elseif ( -not ( Test-Internet -Bool -Access ))
        {
            $text = if ( $L.s65_1 ) { $L.s65_1 } else { "Нет доступа в Интернет для PS" }
            Write-Host "`n   $text" -ForegroundColor DarkYellow

            Get-Pause ; Return    # Выход
        }


        if ( $Select )
        {
            Write-Host

            Set-Apps-Management -CheckState DownloadAppx -DoNotAddFound


            # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
              [char] $Escape          = 27
               [int] $StringsExcl     = 3              # Количество последних строк для затирания.
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline


            # Ждем ввода пользователя.
            $text = if ( $L.s32 ) { $L.s32 } else { "Введите номера Apps через пробел и/или диапазон через дефис" }

            Write-Host "`n   $text"

            $text = if ( $L.s98 ) { $L.s98 } else { 'Номера' }

            [string] $Choice = Read-Host -Prompt "   $text"

            [Uint16[]] $SelectedNumbers = $null

            # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
            # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера.
            # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedAppx, с выбранными существующми намерами.
            if ( -not ( $Choice.Trim() -eq '' ))
            {
                [array] $arr = @()

                # Добавление групп указанных через дефис
                foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

                $arr | ForEach-Object {
                    
                    try
                    {
                        [Uint16] $AppNumber = $_

                        if (( $AppNumber -gt 0 ) -and ( $AppNumber -le $DownloadAppx.Count ) -and ( $SelectedNumbers -notcontains $AppNumber ))
                        {
                            $SelectedNumbers += $AppNumber
                        }
                    }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Отмена' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            if ( -not $SelectedNumbers )
            {
                $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Неверный выбор!' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            [Uint16[]] $AddNumbers = $null

            # Добавление номеров пакетов с дополнительными файлами в список выбранных для Закачки,
            # если выбран Appx у которого в списке всех пакетов для Закачки есть пакет с такой же папкой, но с дополнительными файлами и не был выбран для Закачки
            # Так как при Закачке не дополнительных файлов удаляются все файлы из папки, кроме .xml (лицензии),
            # чтобы после Закачки в папке иметь только новые файлы и необходимые на данный момент, так как названия, количество и версии файлов изменяются со временем
            foreach ( $Number in $SelectedNumbers )
            {
                # Если этот выбранный номер пакета для Закачки не является дополнительными файлами
                if ( -not ( $DownloadAppx[$Number].Add -like $true ))
                {
                    # Если у выбранного пакета в списке Закачек есть еще пакеты с такой же папкой для Закачки
                    if (( $DownloadAppx.Values.Folder -like $DownloadAppx[$Number].Folder ).Count -ge 2 )
                    {
                        # Для каждого списка Закачек
                        foreach ( $Num in $DownloadAppx.Keys )
                        {
                            # Если номер из списка не выбран, и это дополнительные файлы, и имя папки для этих файлов совпадает с именем папки выбранного для Закачки основного приложения
                            if (( -not ( $SelectedNumbers -like $Num )) -and ( $DownloadAppx[$Num].Add -like $true ) -and $DownloadAppx[$Num].Folder -eq $DownloadAppx[$Number].Folder)
                            {
                                # Добавляем номер в список для Закачки
                                $SelectedNumbers += $Num
                                $AddNumbers += $Num
                            }
                        }
                    }
                }
            }

            $SelectedNumbers = $SelectedNumbers | Sort-Object -Unique

            $text = if ( $L.s33_2 ) { $L.s33_2 } else { 'Выбранные Номера' }

            if ( $AddNumbers )
            {
                [string] $ShowNambers = ($SelectedNumbers.ForEach({ if ( $AddNumbers -like $_ ) { "#Magenta#$_" } else { "#White#$_" } })) -join ' '
            }
            else
            {
                [string] $ShowNambers = "#White#$($SelectedNumbers -join ' ')"
            }

            Write-HostColor "`n    $text`: #DarkGray#[ $ShowNambers #DarkGray#]#"
        }

        [int] $LinksReceived = 0

        # Для каждого настроенного Appx для Закачки
        foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
        {
            if (( $Select ) -and -not ( $SelectedNumbers -like $Number )) { Continue }  # Пропуск Appx, если не выбран его номер

            [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']
            [string] $Type           = $DownloadAppx[$Number]['Type']
                     $Type           = $( if ( $Type -eq 'url' ) { $Type.ToLower() } else { $Type } )
            [string] $UrlApp         = $DownloadAppx[$Number]['URL']
            [string] $Ring           = $DownloadAppx[$Number]['Ring']

              [bool] $Add            = $DownloadAppx[$Number]['Add']

            [version] $isVers = $null
            [version]::TryParse($DownloadAppx[$Number]['isVers'], [ref] $isVers) > $null  # Need Version
            [string] $isTime  = $DownloadAppx[$Number]['isTime']                          # Need Time Version  (older or from/newer)

            $text = if ( $L.s67 ) { $L.s67 } else { "  Закачка" }
            Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline

            if ( $Add )
            {
                Write-Host "$DownloadFolder " -ForegroundColor Magenta -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline

                $text = if ( $L.s67_1 ) { $L.s67_1 } else { "Дополнительные файлы для Apps" }
                Write-Host "$text" -ForegroundColor DarkCyan
            }
            else
            {
                Write-Host "$DownloadFolder " -ForegroundColor White -NoNewline

                if ( $isTime -and $isVers )
                {
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$isTime $isVers" -ForegroundColor Magenta
                }
                elseif ( $isVers )
                {
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$isVers" -ForegroundColor Magenta
                }
                else { Write-Host }
            }

            $text = if ( $L.s68 ) { $L.s68 } else { " Описание" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($DownloadAppx[$Number]['Note']) " -ForegroundColor DarkGray

            $text = if ( $L.s69 ) { $L.s69 } else { "    Папка" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))\" -ForegroundColor DarkGray -NoNewline
            Write-Host "$DownloadFolder" -ForegroundColor White

            if ( -not ( 'ProductId', 'CategoryID', 'PackageFamilyName', 'URL', 'DirectLink' -like $Type ))
            {
                $text = if ( $L.s70 ) { $L.s70 } else { "      Тип" }
                Write-Host "   $text`: " -ForegroundColor DarkYellow -NoNewline

                $text = if ( $L.s70_1 ) { $L.s70_1 } else { "Неверный" }
                Write-Host "$Type | $text" -ForegroundColor Red

                Continue   # Пропуск Appx, если неверный тип
            }
            else
            {
                $text = if ( $L.s70 ) { $L.s70 } else { "      Тип" }
                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "$Type" -ForegroundColor DarkGray
            }

            $text = if ( $L.s71 ) { $L.s71 } else { "      Url" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$UrlApp" -ForegroundColor DarkGray


            if     ( $Ring -eq 'Retail' ) { $RingNote = 'Default OS'           }
            elseif ( $Ring -eq 'RP'     ) { $RingNote = 'Release Preview'      }
            elseif ( $Ring -eq 'WIS'    ) { $RingNote = 'Windows Insider Slow' }
            elseif ( $Ring -eq 'WIF'    ) { $RingNote = 'Windows Insider Fast' }
            elseif ( $Ring -eq '------' ) { $RingNote = '---'                  }
            else
            {
                $text = if ( $L.s72 ) { $L.s72 } else { "     Ring" }
                Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                $text = if ( $L.s70_1 ) { $L.s70_1 } else { "Неверный" }
                Write-Host "$Ring | $text" -ForegroundColor Red

                Continue   # Пропуск скачки этого файла
            }

            $text = if ( $L.s72 ) { $L.s72 } else { "     Ring" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$Ring | $RingNote`n" -ForegroundColor DarkGray


            # Если не DirectLink
            if ( $Type -ne 'DirectLink' )
            {
                  [string] $Http    = "https://store.rg-adguard.net/api/GetFiles"
                [psobject] $Session = New-Object Microsoft.PowerShell.Commands.WebRequestSession

                if ( -not $WebRequestAdguard.Headers.Values.Count )
                {
                    # Должен решать проблему первого доступа из-за проверки cloudflare
                    [psobject] $WebRequestAdguard = Invoke-WebRequest -Uri "https://store.rg-adguard.net/" -DisableKeepAlive -UseBasicParsing -WebSession $Session -ErrorAction SilentlyContinue
                    $Session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
                }

                $Body = @{
                    type = $Type
                     url = $UrlApp
                    ring = $Ring
                    lang = 'en'
                }

                # Временный показ надписи про ожидание
                  [char] $Escape          = 27
                   [int] $StringsExcl     = 1              # Количество последних строк для затирания.
                [string] $HideCursor      = "$Escape[?25l"
                [string] $ShowCursor      = "$Escape[?25h"
                [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
                [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

                [psobject] $GetRequest = $null
                if ( $LinksReceived ) { [int] $TryCount = 7 } else { [int] $TryCount = 2 }
                [int] $Try = 0

                do
                {
                    $Try++
    
                    if     ( $Try -ge 4 ) { Start-Sleep -Milliseconds 10000 }
                    elseif ( $Try -ge 3 ) { Start-Sleep -Milliseconds 4000  }
                    elseif ( $Try -ge 2 ) { Start-Sleep -Milliseconds 3000  }

                    if ( $Try -lt $TryCount ) { $Color1 = 'DarkYellow' ; $Color2 = 'DarkGray' } else { $Color1 = 'Yellow' ; $Color2 = 'White' }

                    $text = if ( $L.s63 ) { $L.s63 } else { "    Ждите"  }
                    Write-Host "   $text`: " -ForegroundColor Blue -NoNewline

                    $text = if ( $L.s63_1 ) { $L.s63_1 } else { "Идёт получение ссылок ..."  }
                    Write-Host "$text " -ForegroundColor DarkCyan

                    $GetRequest = $null
                    try { $GetRequest = Invoke-WebRequest -Uri $Http -WebSession $Session -Method Post -Body $Body -DisableKeepAlive -UseBasicParsing -ErrorAction SilentlyContinue }
                    catch { $GetRequest = $null }
    
                    Write-Host "$PreviousLineCur$ClearAfterCur$HideCursor$ShowCursor" -NoNewline

                    $text = if ( $L.s73_3 ) { $L.s73_3 } else { "   Доступ" }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                    if ( $GetRequest -like $null )
                    {
                        $text = if ( $L.s65_2 ) { $L.s65_2 } else { "Нет доступа к вэбсайту" }
                        Write-Host "$text`: " -ForegroundColor $Color1 -NoNewline
                        Write-Host "store.rg-adguard.net" -ForegroundColor $Color2 -NoNewline
        
                        if ( $Try -lt $TryCount )
                        {
                            $text = if ( $L.s73_4 ) { $L.s73_4 } else { "Повтор" }
                            Write-Host " | $text $Try" -ForegroundColor DarkGray
                        }
                        else
                        {
                            $text = if ( $L.s73_5 ) { $L.s73_5 } else { "Пропуск" }
                            Write-Host " | " -ForegroundColor DarkGray -NoNewline
                            Write-Host "$text" -ForegroundColor Red
            
                            Get-Pause ; Return    # Выход
                        }
                    }
                    elseif ( -not $GetRequest.Links )
                    {
                        $text = if ( $L.s72_1 ) { $L.s72_1 } else { "Ccылки на файлы не получены" }
                        Write-Host "$text`: " -ForegroundColor $Color1 -NoNewline
                        Write-Host "store.rg-adguard.net" -ForegroundColor $Color2 -NoNewline
        
                        if ( $Try -lt $TryCount )
                        {
                            $text = if ( $L.s73_4 ) { $L.s73_4 } else { "Повтор" }
                            Write-Host " | $text $Try" -ForegroundColor DarkGray
                        }
                        else
                        {
                            $text = if ( $L.s73_5 ) { $L.s73_5 } else { "Пропуск" }
                            Write-Host " | " -ForegroundColor DarkGray -NoNewline
                            Write-Host "$text" -ForegroundColor Red
            
                            Continue
                        }
                    }
    
                    if ( $GetRequest.Links.Count )
                    {
                        $text = if ( $L.s73_6 ) { $L.s73_6 } else { "Ссылки получены" }
                        Write-Host "$text" -ForegroundColor DarkGreen
                    }
                }
                until ( $GetRequest.Links.Count -or $Try -ge $TryCount )

                $LinksReceived++

                [array] $Appx  = @()

                $GetRequest.Content -split('\n') | Where-Object { $_ -match '[.](Appx|Msix|AppxBundle|MsixBundle)<.+GMT<' -and $_ -notmatch '_(arm|arm64)_' } |
                ForEach-Object {

                    if ( $_ -match 'href=["](?<href>[^"]+)[^>]+[>](?<FullName>[^<]+).+[>](?<SHA1>[^>]+)[<][\/]td[>][<]td.+[>](?<Size>[^<]+)[<][\/]td[>][<][\/]tr[>]' )
                    {
                        $FullName = $Matches.FullName
                        $Href     = $Matches.href
                        $SHA1     = $Matches.SHA1.ToUpper()
                        $Size     = $Matches.Size

                        if ( $FullName -match '^(?<Name>[^_]+)_(?<Vers>[^_]+)_(?<Arch>[^_]+)' )
                        {
                            $Name = $Matches.Name
                            $Arch = $Matches.Arch

                            [version] $ParsedVers = $null

                            if ( [version]::TryParse($Matches.Vers, [ref] $ParsedVers) ) { [version] $Vers = $ParsedVers } else { [version] $Vers = [version]::Parse('0.0') }

                            # Если существуют эти переменные то добавляем пакет в таблицу
                            if ( $Href -and $SHA1 -and $Name -and $Vers )
                            {
                                $Appx += New-Object PsObject -Property @{
                                    'Name'  = $Name
                                    'Arch'  = $Arch
                                    'Vers'  = $Vers
                                    'L'     = $( if ( $Vers.Major ) { $Vers.Major.ToString().Length } else { 0 } ) # количество цифр в Major
                                    'FullName' = $FullName
                                    'href'  = $Href
                                    'SHA1'  = $SHA1
                                    'Size'  = $Size
                                    'Names' = $null
                                }
                            }
                        }
                    }
                }

                # Отобрать файлы для Закачки только с самыми новыми версиями у групп файлов с одинаковыми типами версий, тип определяет по количеству цифр в Major у версии.
                # Чтобы не качать кучу старых ненужных файлов | 5.1811.20017.0 и 2020.420.2001.0 - Разные типы; 2015.706.229.5806 - 2020.3.250.0 - Одинаковые типы
                if ( $Appx.Count )
                {
                    [array] $UniqueApps = @()
                    [array] $AppxSort = @()

                    foreach ( $App in $Appx | Sort-Object -Property Name, Arch, Vers )
                    {
                        if ( $UniqueApps -like "$($App.Name)_$($App.Arch)_$($App.L)" ) { Continue }
                        else { $UniqueApps += "$($App.Name)_$($App.Arch)_$($App.L)" }

                        # Если имя совпадает с целевым Appx, то отобрать только нужные версии, в зависимости от указаной версии в пресете и его параметра времени выпуска
                        if ( $App.Name -eq $DownloadFolder )
                        {
                            if ( $isVers )   # Если указана версия
                            {
                                if ( $isTime -eq '?' )   # Если не известно какую версию качать
                                {
                                    if ( [System.Environment]::OSVersion.Version.Build -ge 22000 )    # Если W11 и новее скачать эту или более новую версию
                                    {
                                        $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L -and $_.Vers -ge $isVers },'Last')
                                    }
                                    else    # Иначе скачать более старую версию
                                    {
                                        $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L -and $_.Vers -lt $isVers },'Last')
                                    }
                                }
                                elseif ( $isTime -eq '<' )    # Если указано скачать более старую версию
                                {
                                    $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L -and $_.Vers -lt $isVers },'Last')
                                }
                                elseif ( $isTime -eq '>' )    # Если указано скачать более новую версию
                                {
                                    $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L -and $_.Vers -gt $isVers },'Last')
                                }
                                else   # Иначе скачать указанную версию
                                {
                                    $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L -and $_.Vers -eq $isVers },'Last')
                                }
                            }
                            else   # Иначе скачать последнюю версию
                            {
                                $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L },'Last')
                            }
                        }
                        else   # Иначе скачать последнюю версию
                        {
                            $AppxSort += ([array] ( $Appx | Sort-Object -Property Vers )).Where({ $_.Name -eq $App.Name -and $_.Arch -eq $App.Arch -and $_.L -eq $App.L },'Last')
                        }
                    }

                    $Appx = $AppxSort
                }
            }
            else
            {
                 [array] $Appx = @()
                [string] $File_Url_Matches = '^\s*(?<FileName>[a-z0-9._-]+[.](Xml|Cer|Appx|Msix|AppxBundle|MsixBundle|zip|7z|Rar))\s*[|]\s*(?<URL>(http[s]*|ftp)[:]\/\/.+)$'

                if ( $UrlApp -match $File_Url_Matches )
                {
                    # Получаем из DirectLink имя файла для Закачки и ссылку на него, отдельно имя для поддержки ссылок без имени файла
                    [string] $FullName = $Matches.FileName
                    [string] $UrlAppx  = $Matches.URL
                }
                else
                {
                    # Иначе это файл txt с ссылками для Apps
                    [string] $FullName = $UrlApp | Split-Path -leaf
                    [string] $UrlAppx  = ''
                }

                if ( $FullName -match '[.](zip|7z|Rar)$' ) { [bool] $Archive = $true } else { [bool] $Archive = $false }

                if ((( $FullName -match $MatchesFileExtensions ) -or $Archive ) -and $UrlAppx )
                {
                    # Если существуют эти переменные то добавляем пакет в таблицу
                    if ( $UrlApp -and $FullName )
                    {
                        if ( $Archive ) { $AppxName = $DownloadFolder } else { $AppxName = '---' }

                        $Appx += New-Object PsObject -Property @{
                            'Name'  = $AppxName
                            'Arch'  = '---'
                            'Vers'  = '---'
                            'FullName' = $FullName
                            'href'  = $UrlAppx
                            'SHA1'  = ''
                            'Size'  = '---'
                            'Names' = $null
                        }
                    }
                }
                elseif ( $FullName -like "*.txt" )
                {
                    [string] $LinksFile = $CurrentRoot | Join-Path -ChildPath $UrlApp -ErrorAction SilentlyContinue

                    if ( [System.IO.File]::Exists($LinksFile) )
                    {
                        [array] $Content = Get-Content -LiteralPath $LinksFile -Force -Encoding UTF8 -ErrorAction SilentlyContinue
                    }
                    else
                    {
                        $text = if ( $L.s73 ) { $L.s73 } else { "    Links" }
                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                        $text = if ( $L.s73_1 ) { $L.s73_1 } else { "Файл не найден" }
                        Write-Host "$text | $LinksFile" -ForegroundColor Red

                        Continue   # Пропуск скачки этого файла
                    }

                    [array] $Names = @()

                    $Content.ForEach({

                        if ( $_ -match $File_Url_Matches )
                        {
                            $Names += New-Object PsObject -Property @{

                                'FullName' = $Matches.FileName.Trim()
                                'href'     = $Matches.URL.Trim()
                            }
                        }
                    })

                    if ( -not $Names.Count )
                    {
                        $text = if ( $L.s73 ) { $L.s73 } else { "    Links" }
                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                        $text = if ( $L.s73_2 ) { $L.s73_2 } else { "Нет подходящих ссылок в файле" }
                        Write-Host "$text | $LinksFile" -ForegroundColor Red

                        Continue   # Пропуск скачки этого файла
                    }

                    # Добавляем пакет в таблицу с отдельными ссылками и именами полученными из файла с ссылками для пакета
                    $Appx += New-Object PsObject -Property @{
                        'Name'  = '---'
                        'Arch'  = '---'
                        'Vers'  = '---'
                        'FullName' = ''
                        'href'  = ''
                        'SHA1'  = ''
                        'Size'  = '---'
                        'Names' = $Names
                    }
                }
                else
                {
                    $text = if ( $L.s74 ) { $L.s74 } else { "  Пропуск" }
                    Write-Host "   $text`: " -ForegroundColor Red -NoNewline
                    Write-Host "$FullName " -ForegroundColor Yellow -NoNewline

                    $text = if ( $L.s74_1 ) { $L.s74_1 } else { "Расширения файлов или ссылки не подходят" }
                    Write-Host "| $text" -ForegroundColor DarkGray
                }
            }

            # Если данные из Links получены
            if ( $Appx.Count )
            {
                if ( -not ( $Appx.Name -like $DownloadFolder ))
                {
                    $text = if ( $L.s75_1 ) { $L.s75_1 } else { "Не найден" }
                    Write-Host "   $text`: " -ForegroundColor DarkYellow -NoNewline
                    Write-Host "$DownloadFolder " -ForegroundColor Yellow -NoNewline

                    $text = if ( $L.s75_2 ) { $L.s75_2 } else { "Основоной Appx файл" }
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$text " -ForegroundColor Magenta -NoNewline

                    if ( $isTime -and $isVers )
                    {
                        $text = if ( $L.s75_3 ) { $L.s75_3 } else { "Указанные параметры версии" }
                        Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$isTime $isVers" -ForegroundColor Magenta
                    }
                    elseif ( $isVers )
                    {
                        $text = if ( $L.s75_3 ) { $L.s75_3 } else { "Указанные параметры версии" }
                        Write-Host "| $text`: " -ForegroundColor DarkGray -NoNewline
                        Write-Host "$isVers" -ForegroundColor Magenta
                    }
                    else { Write-Host }

                    Continue  # Пропуск закачки всех Appx для текущего основного Appx
                }

                [string] $Folder    = "$AppxFolder\$DownloadFolder"
                [string] $NameOld   = "$DownloadFolder`_Old"
                [string] $FolderOld = "$AppxFolder\$NameOld"


                # Сохраняем папку, чтобы если не будет ничего скачано, существующая папка с файлами осталась не тронута

                # Если есть папка для Закачки, переименовываем её
                if ( Test-Path -LiteralPath \\?\$Folder -PathType Container -ErrorAction SilentlyContinue )
                {
                    Rename-Item -LiteralPath \\?\$Folder -NewName $NameOld -Force -ErrorAction SilentlyContinue
                }

                Start-Sleep -Milliseconds 200

                # Создаем новую папку для Закачки, а если она не переименовалась удаляем в ней все файлы кроме xml
                if ( Test-Path -LiteralPath \\?\$Folder -PathType Container -ErrorAction SilentlyContinue )
                { Remove-Item -Path \\?\$Folder\* -Recurse -Exclude "*.xml" -Force -ErrorAction SilentlyContinue }
                else { New-Item -ItemType Directory -Path $Folder -Force -ErrorAction SilentlyContinue > $null }


                # Если есть папка начинаем качать в неё
                if ( Test-Path -LiteralPath $Folder -PathType Container -ErrorAction SilentlyContinue )
                {
                    foreach ( $App in $Appx )
                    {
                        if ( $App.SHA1 )
                        {
                            [string] $OutFile = "$Folder\$($App.FullName)"
                            [string] $GetSize = $App.Size

                            $text = if ( $L.s75 ) { $L.s75 } else { "Скачиваем" }
                            Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline
                            Write-Host "$($App.FullName)" -ForegroundColor White

                            $text = if ( $L.s76 ) { $L.s76 } else { "   Ссылка" }
                            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                            Write-Host "$($App.href.PadRight(280,' ').Substring(0,280))" -ForegroundColor DarkGray  # Обрезка по длине до 280 символов

                            # Закачка файла
                            $ResultDownload = Download-File -FileUrl $App.href -DestFile $OutFile

                            # Просто быстрая скачка файла
                            # $Webclient = New-Object Net.Webclient
                            # $Webclient.Downloadfile($App.href, $OutFile)

                            Start-Sleep -Milliseconds 1000

                            [string] $GetSHA1 = ''
                            $GetSHA1 = (Get-FileHash -Algorithm SHA1 -Path $OutFile -ErrorAction SilentlyContinue).Hash

                            if ( $GetSHA1 -eq $App.SHA1 )
                            {
                                $text = if ( $L.s77 ) { $L.s77 } else { "   Скачан" }
                                Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                                $text = if ( $L.s77_1 ) { $L.s77_1 } else { "Контрольные суммы совпали" }
                                Write-Host "$GetSize | $text | SHA-1: $($App.SHA1)" -ForegroundColor DarkGray
                            }
                            else
                            {
                                if ( [System.IO.File]::Exists($OutFile) )
                                {
                                    $text = if ( $L.s78 ) { $L.s78 } else { "  Удаляем" }
                                    Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                    $text = if ( $L.s78_1 ) { $L.s78_1 } else { "Контрольные суммы не совпали" }
                                    Write-Host "$GetSize | $text | SHA-1: $($App.SHA1) | " -ForegroundColor Gray -NoNewline
                                    Write-Host "$GetSHA1" -ForegroundColor Red

                                    Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                }

                                [bool] $Internet = Test-Internet -Bool -Access

                                if ( -not $Internet )
                                {
                                    $text = if ( $L.s79 ) { $L.s79 } else { " Internet" }
                                    Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                    $text = if ( $L.s65_1 ) { $L.s65_1 } else { "Нет доступа в Интернет для PS" }
                                    Write-Host "$text" -ForegroundColor Red

                                    break  # Прервать перебор
                                }

                                $text = if ( $L.s80 ) { $L.s80 } else { "   Повтор" }
                                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                                Write-Host "$($App.FullName)" -ForegroundColor White

                                Start-Sleep -Milliseconds 3000

                                # Закачка файла
                                $ResultDownload = Download-File -FileUrl $App.href -DestFile $OutFile

                                Start-Sleep -Milliseconds 1000

                                $GetSHA1 = ''
                                $GetSHA1 = (Get-FileHash -Algorithm SHA1 -Path $OutFile -ErrorAction SilentlyContinue).Hash

                                if ( $GetSHA1 -eq $App.SHA1 )
                                {
                                    $text = if ( $L.s77 ) { $L.s77 } else { "   Скачан" }
                                    Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                                    $text = if ( $L.s77_1 ) { $L.s77_1 } else { "Констрольные суммы совпали" }
                                    Write-Host "$GetSize | $text | SHA-1: $($App.SHA1)" -ForegroundColor DarkGray
                                }
                                else
                                {
                                    if ( [System.IO.File]::Exists($OutFile) )
                                    {
                                        $text = if ( $L.s78 ) { $L.s78 } else { "  Удаляем" }
                                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                        $text = if ( $L.s78_1 ) { $L.s78_1 } else { "Констрольные суммы не совпали" }
                                        Write-Host "$GetSize | $text | SHA-1: $($App.SHA1) | " -ForegroundColor Gray -NoNewline
                                        Write-Host "$GetSHA1" -ForegroundColor Red

                                        Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                    }

                                    $text = if ( $L.s81 ) { $L.s81 } else { "Результат" }
                                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                                    $text = if ( $L.s81_1 ) { $L.s81_1 } else { "Не скачан" }
                                    Write-Host "$text" -ForegroundColor Red
                                }
                            }
                        }
                        else
                        {
                            # Закачка всех ссылок из файла txt или одной прямой ссылки на один файл
                            if ( $App.Names.Count ) { [array] $Names = $App.Names }
                            else                    { [array] $Names = $App       ; [string] $LinksFile = $App.href }

                            if ( $LinksFile -like '*.txt' )
                            {
                                $text = if ( $L.s73 ) { $L.s73 } else { "    Links" }
                            }
                            else
                            {
                                $text = if ( $L.s76 ) { $L.s76 } else { "   Ссылка" }
                            }

                            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
                            Write-Host "$($LinksFile.PadRight(280,' ').Substring(0,280))" -ForegroundColor DarkGray  # Обрезка по длине до 280 символов


                            foreach ( $Name in $Names )
                            {
                                [string] $OutFile = "$Folder\$($Name.FullName)"

                                $text = if ( $L.s75 ) { $L.s75 } else { "Скачиваем" }
                                Write-Host "   $text`: " -ForegroundColor Cyan -NoNewline
                                Write-Host "$($OutFile.Replace("$CurrentRoot\",''))" -ForegroundColor White

                                $text = if ( $L.s76 ) { $L.s76 } else { "   Ссылка" }
                                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                                Write-Host "$($Name.href)" -ForegroundColor DarkGray

                                # Закачка файла
                                $ResultDownload = Download-File -FileUrl $Name.href -DestFile $OutFile


                                # Просто быстрая скачка файла
                                # $Webclient = New-Object Net.Webclient
                                # $Webclient.Downloadfile($App.href, $OutFile)

                                Start-Sleep -Milliseconds 1000

                                try { [psobject] $GetFile = Get-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
                                catch { [psobject] $GetFile = '' }

                                if ( $GetFile.Length -and $GetFile.Length -eq $Global:TotalBytesSize )
                                {
                                    $text = if ( $L.s77 ) { $L.s77 } else { "   Скачан" }
                                    Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                                    $text = if ( $L.s77_2 ) { $L.s77_2 } else { "Размер файла совпал" }
                                    Write-Host "$Global:FileSizeNote | $text" -ForegroundColor DarkGray

                                    if ( $OutFile -match '[.](zip|7z|Rar)$' )
                                    {
                                        try
                                        {
                                            & $7z e "$OutFile" -o"$Folder" -aoa -bso0 -bse0 -bsp0
                                            Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                        }
                                        catch {}
                                    }
                                }
                                else
                                {
                                    if ( [System.IO.File]::Exists($OutFile) )
                                    {
                                        $text = if ( $L.s78 ) { $L.s78 } else { "  Удаляем" }
                                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                        $text = if ( $L.s78_2 ) { $L.s78_2 } else { "Размер файла не совпал" }

                                        if ( -not $Global:FileSizeNote )
                                        {
                                            $Global:FileSizeNote = '0 kb'
                                            $text = if ( $L.s78_3 ) { $L.s78_3 } else { "Нулевой размер файла" }
                                        }

                                        Write-Host "$Global:FileSizeNote | $text | $Global:TotalBytesSize | " -ForegroundColor Gray -NoNewline
                                        Write-Host "$($GetFile.Length)" -ForegroundColor Red

                                        Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                    }

                                    [bool] $Internet = Test-Internet -Bool -Access

                                    if ( -not $Internet )
                                    {
                                        $text = if ( $L.s79 ) { $L.s79 } else { " Internet" }
                                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                        $text = if ( $L.s65_1 ) { $L.s65_1 } else { "Нет доступа в Интернет для PS" }
                                        Write-Host "$text" -ForegroundColor Red

                                        break  # Прервать перебор
                                    }

                                    $text = if ( $L.s80 ) { $L.s80 } else { "   Повтор" }
                                    Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                                    Write-Host "$($Name.FullName)" -ForegroundColor White

                                    Start-Sleep -Milliseconds 3000

                                    # Закачка файла
                                    $ResultDownload = Download-File -FileUrl $Name.href -DestFile $OutFile

                                    Start-Sleep -Milliseconds 1000

                                    try { [psobject] $GetFile = Get-Item -LiteralPath $OutFile -Force -ErrorAction SilentlyContinue }
                                    catch { [psobject] $GetFile = '' }

                                    if ( $GetFile.Length -and $GetFile.Length -eq $Global:TotalBytesSize )
                                    {
                                        $text = if ( $L.s77 ) { $L.s77 } else { "   Скачан" }
                                        Write-Host "   $text`: " -ForegroundColor Green -NoNewline

                                        $text = if ( $L.s77_2 ) { $L.s77_2 } else { "Размер файла совпал" }
                                        Write-Host "$Global:FileSizeNote | $text" -ForegroundColor DarkGray

                                        if ( $OutFile -match '[.](zip|7z|Rar)$' )
                                        {
                                            try
                                            {
                                                & $7z e "$OutFile" -o"$Folder" -aoa -bso0 -bse0 -bsp0
                                                Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                            }
                                            catch {}
                                        }
                                    }

                                    if ( [System.IO.File]::Exists($OutFile) )
                                    {
                                        $text = if ( $L.s78 ) { $L.s78 } else { "  Удаляем" }
                                        Write-Host "   $text`: " -ForegroundColor Red -NoNewline

                                        $text = if ( $L.s78_2 ) { $L.s78_2 } else { "Размер файла не совпал" }

                                        if ( -not $Global:FileSizeNote )
                                        {
                                            $Global:FileSizeNote = '0 kb'
                                            $text = if ( $L.s78_3 ) { $L.s78_3 } else { "Нулевой размер файла" }
                                        }

                                        Write-Host "$Global:FileSizeNote | $text | $Global:TotalBytesSize | " -ForegroundColor Gray -NoNewline
                                        Write-Host "$($GetFile.Length)" -ForegroundColor Red

                                        Remove-Item -LiteralPath \\?\$OutFile -Force -ErrorAction SilentlyContinue
                                    }

                                    $text = if ( $L.s81 ) { $L.s81 } else { "Результат" }
                                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

                                    $text = if ( $L.s81_1 ) { $L.s81_1 } else { "Не скачан" }
                                    Write-Host "$text " -ForegroundColor Red -NoNewline

                                    if ( '0 kb' -eq $Global:FileSizeNote )
                                    {
                                        Write-Host "| " -ForegroundColor DarkGray -NoNewline

                                        $text = if ( $L.s81_2 ) { $L.s81_2 } else { "Нет доступа к вэбсайту" }
                                        Write-Host "$text " -ForegroundColor Red
                                    }
                                    else { Write-Host }
                                }
                            }
                        }
                    }

                    # Если не скачивание дополнительных файлов
                    if ( -not $Add )
                    {
                        [int] $FoundAppx = (Get-ChildItem -File -LiteralPath $Folder -Force -ErrorAction SilentlyContinue).Name.Where({ $_ -match $MatchesFileExtensions },'First',1).Count

                        # Если найдены скаченные файлы
                        if ( $FoundAppx )
                        {
                            # Копируем xml файлы из старой переименованной папки в папку для Закачки
                            (Get-ChildItem -File -LiteralPath \\?\$FolderOld -Force -ErrorAction SilentlyContinue).Where({ $_.Name -like '*.xml' }).Foreach({

                                Copy-Item $_.FullName -Destination $Folder -Force -ErrorAction SilentlyContinue
                            })

                            # Удаляем переименованную папку
                            Remove-Item -LiteralPath \\?\$FolderOld -Recurse -Force -ErrorAction SilentlyContinue
                        }
                        else
                        {
                            # Иначе удаляем пустую папку для Закачки
                            Remove-Item -LiteralPath \\?\$Folder -Recurse -Force -ErrorAction SilentlyContinue

                            # Если есть старая переименованная папка, то переименовываем её обратно в имя папки для Закачки
                            if ( Test-Path -LiteralPath \\?\$FolderOld -PathType Container -ErrorAction SilentlyContinue )
                            {
                                Rename-Item -LiteralPath \\?\$FolderOld -NewName $DownloadFolder -Force -ErrorAction SilentlyContinue
                            }
                        }
                    }
                    else
                    {
                        # Если есть старая переименованная папка
                        if ( Test-Path -LiteralPath \\?\$FolderOld -PathType Container -ErrorAction SilentlyContinue )
                        {
                            # Копируем в нее скачанные новые файлы из папки для Закачки в переименованную папку с файлами
                            foreach ( $App in $Appx )
                            {
                                [string] $OutFile = "$Folder\$($App.FullName)"

                                Copy-Item $OutFile -Destination $FolderOld -Force -ErrorAction SilentlyContinue
                            }

                            # Удаляем папку для Закачки
                            Remove-Item -LiteralPath \\?\$Folder -Recurse -Force -ErrorAction SilentlyContinue

                            # Переименовываем обратно папку с файлами
                            Rename-Item -LiteralPath \\?\$FolderOld -NewName $DownloadFolder -Force -ErrorAction SilentlyContinue
                        }
                    }
                }
                else
                {
                    $text = if ( $L.s66 ) { $L.s66 } else { "Папка не может быть создана в" }
                    Write-Host "   $text " -ForegroundColor Red -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline
                    Write-Host $Folder -ForegroundColor Gray
                }
            }
        }

        $text = if ( $L.s30 ) { $L.s30 } else { "Завершено" }
        Write-Host "`n   $text" -ForegroundColor DarkGreen
    }
    elseif ( $Option -eq 'RunInstallDownloadedAppx' )
    {
        # Добавление найденных папок с Appx в $DownloadAppx
        Add-Found-Appx

        if ( [System.Environment]::Is64BitOperatingSystem )
        {
            [string] $FileMatches = 'Cer/Appx/Msix/AppxBundle/MsixBundle x64/x86'
        }
        else
        {
            [string] $FileMatches = 'Cer/Appx/Msix/AppxBundle/MsixBundle x86'
        }

        $text = if ( $L.s82 ) { $L.s82 } else { "Установка Найденных Appx в подпаках" }
        Write-Host "`n   $text`: " -ForegroundColor White -NoNewline
        Write-Host "$FileMatches" -ForegroundColor Gray

        if ( -not $DownloadAppx.Count )
        {
            $text = if ( $L.s82_1 ) { $L.s82_1 } else { "Не Найдены Appx в подпапках" }
            Write-Host "`n   $text" -ForegroundColor DarkYellow

            # Если запуск не из главных меню быстрых настроек (0 и 1)
            if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
            {
                Get-Pause
            }

            Return    # Выход
        }

        Write-Host

        Set-Apps-Management -CheckState DownloadAppx -NoAdditionalFiles

        # Убрать дполонительные файлы из списка в этой сессии
        [hashtable] $DownloadAppxTemp = @{}
        [int] $N = 1
        foreach ( $Num in $DownloadAppx.Keys | Sort-Object )
        {
            if ( $DownloadAppx[$Num].Add -notlike $true ) { $DownloadAppxTemp[$N] = $DownloadAppx[$Num] ; $N++ }
        }
        $Global:DownloadAppx = $DownloadAppxTemp

        if ( $Select )
        {
            # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
              [char] $Escape          = 27
               [int] $StringsExcl     = 3              # Количество последних строк для затирания.
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline


            # Ждем ввода пользователя.
            $text = if ( $L.s32 ) { $L.s32 } else { "Введите номера Apps через пробел и/или диапазон через дефис" }

            Write-Host "`n   $text"

            $text = if ( $L.s98 ) { $L.s98 } else { 'Номера' }

            [string] $Choice = Read-Host -Prompt "   $text"

            [Uint16[]] $SelectedNumbers = $null

            # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
            # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера.
            # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedAppx, с выбранными существующми намерами.
            if ( -not ( $Choice.Trim() -eq '' ))
            {
                [array] $arr = @()
                
                # Добавление групп указанных через дефис
                foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

                $arr | ForEach-Object {
                    
                    try
                    {
                        [Uint16] $AppNumber = $_

                        if (( $AppNumber -gt 0 ) -and ( $AppNumber -le $DownloadAppx.Count ) -and ( $SelectedNumbers -notcontains $AppNumber ))
                        {
                            $SelectedNumbers += $AppNumber
                        }
                    }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Отмена' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            if ( -not $SelectedNumbers )
            {
                $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Неверный выбор!' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            $SelectedNumbers = $SelectedNumbers | Sort-Object

            $text = if ( $L.s33_2 ) { $L.s33_2 } else { 'Выбранные Номера' }
            Write-HostColor "`n    $text`: #DarkGray#[ #White#$SelectedNumbers #DarkGray#]#"
        }
        else { Write-Host }


        # Восстановление доступа по умолчанию +, для перестраховки.
        Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications' -RecoverySDDL '
        O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
        G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(A;CI;KR;;;SY)(A;CIIO;KA;;;SY)
        (A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)(A;CI;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
        (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'


        # Отключение вывода прогресс бара, так как у Add-AppxPackage он глючит и зависает поверх консоли
        $ProgressPreference = 'SilentlyContinue'

        [string] $FoundAppx  = ''

        # Для каждого настроенного Appx для Закачки
        foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
        {
            if (( $Select ) -and -not ( $SelectedNumbers -like $Number )) { Continue }  # Пропуск Appx, если не выбран его номер

            [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']

            $text = if ( $L.s18 ) { $L.s18 } else { "Установка" }
            Write-Host "`n   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))\" -ForegroundColor DarkGray -NoNewline
            Write-Host "$DownloadFolder" -ForegroundColor White

            if ( [System.IO.Directory]::Exists("$AppxFolder\$DownloadFolder") )
            {
                $FoundAppx = (Get-ChildItem -File -LiteralPath $AppxFolder\$DownloadFolder -Force -ErrorAction SilentlyContinue).Name.Where({
                    $_ -match $MatchesFileExtensions -and $_ -notmatch $ExclArch },'First',1)

                if ( $FoundAppx )
                {
                    Install-Appx-FromFolder -Folder $AppxFolder\$DownloadFolder
                }
                else
                {
                    $text = if ( $L.s83 ) { $L.s83 } else { "Нет подходящих файлов в папке" }
                    Write-Host "   $text" -ForegroundColor DarkYellow
                }
            }
            else
            {
                $text = if ( $L.s83_1 ) { $L.s83_1 } else { "Нет папки" }
                Write-Host "   $text" -ForegroundColor DarkYellow
            }
        }

        # Возврат показа прогресс бара
        $ProgressPreference = 'Continue'

    }
    elseif ( $Option -eq 'RunInstallAppxFromFolder' )
    {
        if ( -not $AppxFolder )
        {
            $text = if ( $L.s84 ) { $L.s84 } else { "Папка не указана для функции в" }
            Write-Host "`n   $text`: `$AppxFolder" -ForegroundColor Green

            # Если запуск не из главных меню быстрых настроек (0 и 1)
            if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
            {
                Get-Pause
            }

            Return    # Выход
        }

        if ( [System.Environment]::Is64BitOperatingSystem ) { [string] $FileMatches = 'Cer/Appx/Msix/AppxBundle/MsixBundle x64/x86' }
        else { [string] $FileMatches = 'Cer/Appx/Msix/AppxBundle/MsixBundle x86' }

        $text = if ( $L.s85 ) { $L.s85 } else { "Установка файлов" }
        Write-Host "`n   $text`: " -ForegroundColor Cyan -NoNewline
        Write-Host "$FileMatches" -ForegroundColor White

        $text = if ( $L.s86 ) { $L.s86 } else { "        Из папки" }
        Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
        Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))`n" -ForegroundColor DarkGray


        # Восстановление доступа по умолчанию +, для перестраховки.
        Set-OwnerAndAccess -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications' -RecoverySDDL '
        O:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464
        G:S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464D:PAI(A;CI;KR;;;SY)(A;CIIO;KA;;;SY)
        (A;CI;KR;;;BA)(A;CI;KR;;;BU)(A;CI;KR;;;AC)(A;CI;KA;;;S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464)
        (A;CI;KR;;;S-1-15-3-1024-1065365936-1281604716-3511738428-1654721687-432734479-3232135806-4053264122-3456934681)'


        # Отключение вывода прогресс бара, так как у Add-AppxPackage он глючит и зависает поверх консоли
        $ProgressPreference = 'SilentlyContinue'

        Install-Appx-FromFolder -Folder $AppxFolder

        # Возврат показа прогресс бара
        $ProgressPreference = 'Continue'

        if ( -not $ActionDone )
        {
            $text = if ( $L.s86_1 ) { $L.s86_1 } else { "Поиск только в этой папке, подпапки пропускаются!" }
            Write-Host "   $text" -ForegroundColor White
        }
    }
    elseif ( $Option -eq 'RunCleanDownloadedFolders' )
    {
        # Убираем исключения архитектур для Add-Found-Appx
        [string] $ExclArch = '------------------------'

        # Обнуляем полученные данные для Закачек и найденые папки
        [hashtable] $Global:DownloadAppx = @{}

        # Добавление найденных папок с Appx файлами в переменную $Global:DownloadAppx
        Add-Found-Appx

        if ( -not $DownloadAppx.Count )
        {
            $text = if ( $L.s87 ) { $L.s87 } else { "Нет подпапок с Appx в" }
            Write-Host "`n   $text`: " -ForegroundColor DarkYellow -NoNewline
            Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))" -ForegroundColor DarkGray

            # Если запуск не из главных меню быстрых настроек (0 и 1)
            if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
            {
                Get-Pause
            }

            return
        }
        else
        {
            $text = if ( $L.s87_1 ) { $L.s87_1 } else { "Найденные папки с файлами Appx" }
            Write-Host "`n   $text`: `n" -ForegroundColor White

            # Выводим информацию по всем Appx для Закачки
            foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
            {
                [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']

                [string] $ResultShow = "#DarkGray#{0}. #Green#■ #DarkGray#$($AppxFolder.Replace("$CurrentRoot\",''))\#White#{1}#" -f
                    $Number.ToString().PadLeft(5,' '),
                    $DownloadFolder.ToString().PadRight(36,' ')

                Write-HostColor $ResultShow
            }
        }


        if ( $Select )
        {
            # Провернуть консоль на одну строку в низ, чтобы вывод запроса был не у самого низа
              [char] $Escape          = 27
               [int] $StringsExcl     = 3              # Количество последних строк для затирания.
            [string] $ClearAfterCur   = "$Escape[0J"   # Очистка за курсором всех строк буфера.
            [string] $PreviousLineCur = "$Escape[$StringsExcl`F"  # Перевод курсора на предыдущие строки.

            Write-Host "`n`n`n$PreviousLineCur$ClearAfterCur" -NoNewline


            # Ждем ввода пользователя.
            $text = if ( $L.s88 ) { $L.s88 } else { "Введите номера папок через пробел и/или диапазон через дефис" }

            Write-Host "`n   $text"

            $text = if ( $L.s98 ) { $L.s98 } else { 'Номера' }

            [string] $Choice = Read-Host -Prompt "   $text"

            [Uint16[]] $SelectedNumbers = $null

            # Фильтр введеных пользователем данных. Убираются все группы символов, разделенные через пробел,
            # которые не являются положительным числом, число ноль, превышают количество или повторно введенные номера.
            # Если пустая строка, вернуться в меню. В результате создается массив из чисел $SelectedAppx, с выбранными существующми намерами.
            if ( -not ( $Choice.Trim() -eq '' ))
            {
                [array] $arr = @()

                # Добавление групп указанных через дефис
                foreach ( $i in $Choice.Split() ) { if ( $i -match '^\d+-\d+$' ) { $arr += & ([scriptblock]::Create($i.Replace('-','..'))) } else { $arr += $i } }

                $arr | ForEach-Object {
                    
                    try
                    {
                        [Uint16] $AppNumber = $_

                        if (( $AppNumber -gt 0 ) -and ( $AppNumber -le $DownloadAppx.Count ) -and ( $SelectedNumbers -notcontains $AppNumber ))
                        {
                            $SelectedNumbers += $AppNumber
                        }
                    }
                    catch {}
                }
            }
            else
            {
                $text = if ( $L.s33 ) { $L.s33 } else { 'Отмена' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            if ( -not $SelectedNumbers )
            {
                $text = if ( $L.s33_1 ) { $L.s33_1 } else { 'Неверный выбор!' }
                Write-Host "`n   $text`n" -ForegroundColor DarkYellow
                Start-Sleep -Milliseconds 1000
                Return
            }

            $SelectedNumbers = $SelectedNumbers | Sort-Object

            $text = if ( $L.s33_2 ) { $L.s33_2 } else { 'Выбранные Номера' }
            Write-HostColor "`n    $text`: #DarkGray#[ #White#$SelectedNumbers #DarkGray#]#"
        }

        Write-Host

        # Для каждого настроенного Appx для Закачки
        foreach ( $Number in $DownloadAppx.Keys | Sort-Object )
        {
            if (( $Select ) -and -not ( $SelectedNumbers -like $Number )) { Continue }  # Пропуск папки, если не выбран её номер

            [string] $DownloadFolder = $DownloadAppx[$Number]['Folder']

            [string] $Folder = "$AppxFolder\$DownloadFolder"

            $text = if ( $L.s89 ) { $L.s89 } else { " Удаление" }
            Write-Host "   $text`: " -ForegroundColor DarkCyan -NoNewline
            Write-Host "$($AppxFolder.Replace("$CurrentRoot\",''))\" -ForegroundColor DarkGray -NoNewline
            Write-Host "$DownloadFolder" -ForegroundColor White

            $text = if ( $L.s90 ) { $L.s90 } else { "Результат" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            if ( [System.IO.Directory]::Exists($Folder) )
            {
                # Удаляем папку
                Remove-Item -LiteralPath \\?\$Folder -Recurse -Force -ErrorAction SilentlyContinue

                if ( Test-Path -LiteralPath \\?\$Folder -PathType Container -ErrorAction SilentlyContinue )
                {
                    $text = if ( $L.s90_1 ) { $L.s90_1 } else { "Не удалена" }
                    Write-Host "$text" -ForegroundColor Red
                }
                else
                {
                    $text = if ( $L.s90_2 ) { $L.s90_2 } else { "Удалена" }
                    Write-Host "$text" -ForegroundColor Green
                }
            }
            else
            {
                $text = if ( $L.s90_3 ) { $L.s90_3 } else { "Нет папки" }
                Write-Host "$text" -ForegroundColor DarkYellow
            }
        }

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
        {
            Get-Pause
        }

        Return
    }
    elseif ( $Option -eq 'CleanUninstalledSystemApps' )
    {
        if ( $Act -eq 'Default')
        {
            $text = if ( $L.s91 ) { $L.s91 } else { "Пропуск Очистки/Проверки параметров удалённых системных Apps" }
            Write-Host "`n   $text " -ForegroundColor DarkGray
            Return
        }

        if ( $Act -eq 'Check' )
        {
            $text = if ( $L.s92 ) { $L.s92 } else { "Проверка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline
        }
        else
        {
            $text = if ( $L.s92_1 ) { $L.s92_1 } else { "Очистка" }
            Write-Host "`n   $text " -ForegroundColor DarkCyan -NoNewline
        }

        $text = if ( $L.s92_2 ) { $L.s92_2 } else { "параметров удалённых системных Apps" }
        Write-Host "$text `n" -ForegroundColor Gray

        [array] $SystemIdentitys = @()

        (Get-ChildItem -File -LiteralPath "$env:SystemDrive\Windows\SystemApps\","$env:SystemDrive\Windows\PrintDialog\","$env:SystemDrive\Windows\ImmersiveControlPanel\" -Recurse -Depth 1 -Force -ErrorAction SilentlyContinue
        ).Where({ $_.Name -eq 'AppxManifest.xml' }).Foreach({

            $SystemIdentitys += Get-AppxManifest-Identity $_.FullName
        })

        try
        {
            $SubKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\InboxApplications'
            $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey,'ReadSubTree','QueryValues,EnumerateSubKeys')
            $SubKeyNames = $OpenSubKey.GetSubKeyNames()
            $OpenSubKey.Close()
        }
        catch { $SubKeyNames = $null }

        [bool] $Err = $false
        try
        {
            $GetAppxAll  = Get-AppxPackage -AllUsers -PackageTypeFilter Main, Framework, Optional -ErrorAction Stop
            $SystemApps  = $GetAppxAll.Where({ $_.SignatureKind -eq 'System' })
            $RemoveNames = $SystemIdentitys.Where({ -not ( $SystemApps.Name -like $_.Name ) }).Name | Select-Object -Unique
        }
        catch { $Err = $true }

        if ( -not $Err )
        {
            [int] $N = 0

            foreach($SubKeyName in $SubKeyNames){foreach($RemoveName in $RemoveNames){if(($SubKeyName -like "$RemoveName`_*")-and(-not($SystemNames-like $RemoveName)))
            {
                if ( $Act -eq 'Check' )
                {
                    $text = if ( $L.s93 ) { $L.s93 } else { "Очистить" }
                    Write-Host "   $text`: " -ForegroundColor Yellow -NoNewline
                    Write-Host "$SubKeyName" -ForegroundColor Gray

                    $NeedFix = $true
                    $N++
                }
                else
                {
                    $text = if ( $L.s93_1 ) { $L.s93_1 } else { "Очистка для удалённого Apps" }
                    Write-Host "   • $text  | " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$RemoveName" -ForegroundColor DarkCyan

                    $Path = "HKLM:\$SubKey\$SubKeyName"
                    Set-Reg Remove-Item -Path $Path

                    try
                    {
                        $SubKey2 = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Appx\AppxAllUserStore\UpdatedApplications'
                        $OpenSubKey = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($SubKey2,'ReadSubTree','QueryValues,EnumerateSubKeys')
                        $SubKeyNames2 = $OpenSubKey.GetSubKeyNames() -like "$RemoveName`_*"
                        $OpenSubKey.Close()
                    }
                    catch { $SubKeyNames2 = $null }

                    if ( $SubKeyNames2 )
                    {
                        foreach( $SubKeyName2 in $SubKeyNames2 )
                        {
                            $Path = "HKLM:\$SubKey2\$SubKeyName2"
                            Set-Reg Remove-Item -Path $Path
                        }
                    }

                    $N++
                }
            }}}

            if ( $N -eq 0 )
            {
                $text = if ( $L.s94 ) { $L.s94 } else { "Завершено" }
                Write-Host "   $text " -ForegroundColor Green -NoNewline

                $text = if ( $L.s94_1 ) { $L.s94_1 } else { "Очистка не требуется" }
                Write-Host "| $text" -ForegroundColor DarkGray
            }
            else
            {
                $text = if ( $L.s94 ) { $L.s94 } else { "Завершено" }
                Write-Host "`n   $text " -ForegroundColor Green
            }
        }
        else
        {
            $text = if ( $L.s97_2 ) { $L.s97_2 } else { "Ошибка выполнения Get-AppxPackage -AllUsers" }
            Write-Host "   $text" -ForegroundColor Yellow
        }

        try
        {
            [psobject] $ScheduleService = New-Object -ComObject Schedule.Service

            $ScheduleService.Connect()
            $Task = $ScheduleService.GetFolder($AutoCleanTaskFolder).GetTask($AutoCleanTaskName)
            [string] $Arguments = $Task.Definition.Actions[1].Arguments
            [string[]] $AutoCleanSystemAppsNames = ($Arguments -replace('.+[""](\\\\.+)_[""][''].+','$1')).Replace('\','').Split('_').Trim()
        }
        catch { [string[]] $AutoCleanSystemAppsNames = $null }

        if ( $AutoCleanSystemAppsNames.Count )
        {
            [bool] $isProblem = $false

            $text = if ( $L.s9_2 ) { $L.s9_2 } else { "Состояние Автоочистки" }
            Write-Host "`n • $text`: " -ForegroundColor DarkCyan

            $text = if ( $L.s9_3 ) { $L.s9_3 } else { "Задача" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($AutoCleanTaskFolder.TrimEnd('\'))\$AutoCleanTaskName" -ForegroundColor White

            $text = if ( $L.s9_4 ) { $L.s9_4 } else { "Состояние задачи" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline

            if ( $Task.Enabled )
            {
                $text = if ( $L.s9_5 ) { $L.s9_5 } else { "Включена" }
                Write-Host "$text" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s9_6 ) { $L.s9_6 } else { "Отключена" }
                Write-Host "$text" -ForegroundColor Red

                $isProblem = $true
            }

            $text = if ( $L.s9_7 ) { $L.s9_7 } else { "Последний запуск" }
            Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$($Task.LastRunTime.ToString()) " -ForegroundColor Gray -NoNewline

            $text = if ( $L.s9_8 ) { $L.s9_8 } else { "Результат" }
            Write-Host "| " -ForegroundColor DarkGray -NoNewline
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline

            try { $LastTaskResult = "0x$([System.Convert]::ToString($Task.LastTaskResult, 16))" }
            catch { $LastTaskResult = $Task.LastTaskResult }

            if ( $Task.LastTaskResult -eq 0 )
            {
                $text = if ( $L.s9_10 ) { $L.s9_10 } else { "Успешный" }
                Write-Host "$text " -ForegroundColor Green -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$LastTaskResult" -ForegroundColor DarkGray
            }
            elseif ( $Task.LastTaskResult -eq 267011 )
            {
                $text = if ( $L.s9_15 ) { $L.s9_15 } else { "Ещё не выполнялась" }
                Write-Host "$text " -ForegroundColor Gray -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$LastTaskResult" -ForegroundColor DarkGray
            }
            elseif ( $Task.LastTaskResult -eq 267014 )
            {
                $text = if ( $L.s9_11 ) { $L.s9_11 } else { "Не успела выполниться" }
                Write-Host "$text " -ForegroundColor Yellow -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$LastTaskResult" -ForegroundColor DarkYellow
            }
            else
            {
                $text = if ( $L.s9_9 ) { $L.s9_9 } else { "Ошибка" }
                Write-Host "$text " -ForegroundColor Red -NoNewline
                Write-Host "| " -ForegroundColor DarkGray -NoNewline
                Write-Host "$LastTaskResult" -ForegroundColor Red

                $isProblem = $true
            }

            $text = if ( $L.s9_12 ) { $L.s9_12 } else { "Имена Удалённых Системных Apps и Имена Указанные в Задаче" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline

            if ( "$(($RemoveNames | Sort-Object -Unique) -join ';')" -eq "$(($AutoCleanSystemAppsNames | Sort-Object -Unique) -join ';')" )
            {
                $text = if ( $L.s9_13 ) { $L.s9_13 } else { "Совпадают" }
                Write-Host "$text" -ForegroundColor Green
            }
            else
            {
                $text = if ( $L.s9_14 ) { $L.s9_14 } else { "Не Совпадают" }
                Write-Host " $text " -ForegroundColor White -BackgroundColor Red

                $isProblem = $true
            }

            Write-Host

            [bool] $IsInstall = $false
            [bool] $IsClean   = $false

            [int] $N = 0

            foreach ( $SystemName in ( $SystemIdentitys.Name | Sort-Object ))
            {
                $N++

                if ( 10 -gt $N ) { $Space = ' ' } else { $Space = '' }

                if ( $SystemApps.Name -like $SystemName )
                {
                    if ( $Space ) { $Space = "$Space  " } else { $Space = "$Space   " }

                    $text = if ( $L.s10 ) { $L.s10 } else { "Установлен" }
                    Write-Host "   $Space " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    $IsInstall = $true

                    $N--
                }
                else
                {
                    $text = if ( $L.s11 ) { $L.s11 } else { "Удалён    " }
                    Write-Host "   $Space$N. " -ForegroundColor DarkGray -NoNewline
                    Write-Host "$text " -ForegroundColor Green -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    $IsInstall = $false
                }

                if ( $AutoCleanSystemAppsNames -like $SystemName )
                {
                    $text = if ( $L.s10_1 ) { $L.s10_1 } else { "Есть Автоочистка" }
                    Write-Host "$text " -ForegroundColor Magenta -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    $IsClean = $true
                }
                else
                {
                    $text = if ( $L.s11_1 ) { $L.s11_1 } else { "Нет Автоочистки " }
                    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    $IsClean = $false
                }

                if (( $IsInstall -and $IsClean ) -or ( -not $IsInstall -and -not $IsClean ))
                {
                    $text = if ( $L.s10_2 ) { $L.s10_2 } else { "Проблема   " }
                    Write-Host "$text " -ForegroundColor Red -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    Write-Host "$SystemName" -ForegroundColor Red

                    $isProblem = $true
                }
                else
                {
                    $text = if ( $L.s11_2 ) { $L.s11_2 } else { "Нет Проблем" }
                    Write-Host "$text " -ForegroundColor DarkGray -NoNewline
                    Write-Host "| " -ForegroundColor DarkGray -NoNewline

                    if ( $IsInstall )
                    {
                        Write-Host "$SystemName" -ForegroundColor DarkGray
                    }
                    else
                    {
                        Write-Host "$SystemName" -ForegroundColor Blue
                    }
                }
            }

            if ( $isProblem )
            {
                $text = if ( $L.s10_3 ) { $L.s10_3 } else { "Найдены Проблемы Автоочистки" }
                Write-Host "`n   $text" -ForegroundColor Red
            }
            else
            {
                $text = if ( $L.s11_3 ) { $L.s11_3 } else { "Нет Проблем Автоочистки" }
                Write-Host "`n   $text" -ForegroundColor Green
            }
        }
        else
        {
            $text = if ( $L.s9_1 ) { $L.s9_1 } else { "Задачи Автоочистки нет" }
            Write-Host "`n   $text" -ForegroundColor DarkGray
        }

        Write-Host

        # Если выполнение очистки, а не проверки, под конец создать задачу, если есть несоответствия
        if ( $Act -eq 'Set' )
        {
            Change-AutoClean-Task -SystemTaskPath $AutoCleanTaskFolder -SystemTaskName $AutoCleanTaskName
        }

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
        {
            Get-Pause
        }

        Return
    }
    elseif ( $Option -eq 'FixInstalledApps' )
    {
        if ( $Act -eq 'Default')
        {
            $text = if ( $L.s95 ) { $L.s95 } else { "Пропуск Исправления установленных Apps" }
            Write-Host "`n   $text " -ForegroundColor DarkGray
            Return
        }

        if ( $Act -eq 'Set' )
        {
            if ( $Select )
            {
                Set-Apps-Management -Option RunInstallApps -FixInstalledAppsProblems -NoTitle -NoPauses -Select
            }
            else
            {
                Set-Apps-Management -Option RunInstallApps -FixInstalledAppsProblems -NoTitle -NoPauses
            }
        }
        else
        {
            $text = if ( $L.s96 ) { $L.s96 } else { "Проверка" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s96_1 ) { $L.s96_1 } else { "установленных Apps" }
            Write-Host "$text" -ForegroundColor Gray

            Set-Apps-Management -CheckState InstalledAppsProblems
        }

        # Если запуск не из главных меню быстрых настроек (0 и 1)
        if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
        {
            Get-Pause
        }

        Return
    }

    # Если выполнялось какое либо действие для Установки/Удаления Apps | RunInstall*/RunUninstallApps
    if ( $ActionDone -and $Option -match 'RunInstall|RunUninstallApps' )
    {
        Start-Sleep -Milliseconds 500

        # Перезапуск Меню Пуск 1809-2004
        Stop-Process -Name 'StartMenuExperienceHost', 'ShellExperienceHost' -Force -ErrorAction SilentlyContinue

        Start-Sleep -Milliseconds 500

        # Если запуск не из меню быстрых настроек
        if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
        {
            # Обновление проводника
            [WinAPI.RefreshExplorer]::Refresh()

            Start-Sleep -Milliseconds 500
            [WinAPI.RefreshExplorer]::PressF5Key()
        }

        if ( $Option -match 'RunInstallApps|RunUninstallApps' )
        {
            Change-AutoClean-Task -SystemTaskPath $AutoCleanTaskFolder -SystemTaskName $AutoCleanTaskName
        }

        $text = if ( $L.s150 ) { $L.s150 } else { "Желательно перезагрузиться" }
        Write-Host "`n • $text •" -ForegroundColor DarkYellow
    }
    elseif ( $Option -match 'RunInstallApps|RunUninstallApps' )
    {
        Change-AutoClean-Task -SystemTaskPath $AutoCleanTaskFolder -SystemTaskName $AutoCleanTaskName
    }


    # Отключение режима разработчика
    Get-Developer-Mode -DisableDevMode

    # Если запуск не из главных меню быстрых настроек (0 и 1)
    if ( -not $MenuConfigsQuickSettings -and -not $NoPauses )
    {
        # Если есть подготовленные параметры Групповых политик для LGPO.exe в глобальной переменной $Global:SettingsGP, то выполнится применение ГП.
        Set-LGP -ApplyGP

        Get-Pause
    }
}