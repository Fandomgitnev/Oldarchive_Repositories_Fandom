﻿
<#
.SYNOPSIS
 Изменение расположения или восстановление папок Temp пользователя и системы.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS
 Сделано для меню $Menu_Move_Temp_User и $Menu_Move_Temp_System.

 Используется функция Set-OwnerAndAccess для настройки параметров безопасности через SDDL.
 Используется функция ReStart-Explorer для корректного завершения процесса проводника.
 Используется функция Get-Pause для установки паузы.
 Используется утилита MS Handle.exe для получения блокирующих папку процессов,
 необходимо для завершения этих процессов, чтобы была возможность удалить заблокированную папку.
 Для выполнения всех действий нужны эти функции и утилита и права администратора.

 Получает из файла пресетов 'Presets.txt' заданные пути для папок,
 получает из реестра текущее местоположение, и если путь получен и папка есть.

 Задает в реестре необходимые параметры.
 Создает папку, если нету.
 Настраивает при необходимости параметры безопасности,
 чтобы не было проблем при работе в программах с ограниченными правами.

 С помощью этой функции можно восстановить все эти папки и их параметры,
 даже если нет ни папок ни параметров в реестре.

 Для каждой папки в файле пресетов 'Presets.txt' можно указать свой путь.

.PARAMETER Target
 Папка Temp для пользователя или системы: 'User' или 'System'.

.PARAMETER Path
 Свой путь для расположения папки.

.PARAMETER SymLink
 Указывает создание символической ссылки по пути по умолчанию, для совместимости.

.PARAMETER Default
 Указывает восстановить расположение по умолчанию.

.PARAMETER CheckPreset
 Указывает вывести путь из пресета для указанной только одной папки.

.PARAMETER CheckState
 Указывает вывести текущее состояние для указанной только одной папки.

.PARAMETER CheckSymLink
 Указывает проверить наличие символической ссылки по пути по умолчанию.

.EXAMPLE
    Move-Temp-Folders -Target System

    Описание
    --------
    Изменение расположение системной папки Temp, путь возьмется из пресета.
    Без создания символической ссылки.

.EXAMPLE
    Move-Temp-Folders -Target System -Path 'D:\MyTemp' -SymLink

    Описание
    --------
    Изменение расположение системной папки Temp, путь указан в 'D:\MyTemp'.
    И создания символической ссылки в пути по умолчанию, указывающей на 'D:\MyTemp',
    для совместимости.

.EXAMPLE
    Move-Temp-Folders -Target User -SymLink

    Описание
    --------
    Изменение расположение папки Temp для пользователя, путь возьмется из пресета.
    И создания символической ссылки в пути по умолчанию, указывающей на путь из пресета,
    для совместимости.

.EXAMPLE
    Move-Temp-Folders -Target System -Default

    Описание
    --------
    Восстановление расположения системной папки Temp по умолчанию.

.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  19.11.2018
 ===============================================

#>
Function Move-Temp-Folders {

    [CmdletBinding( SupportsShouldProcess = $false, DefaultParameterSetName = 'All' )]
    Param(
        [Parameter( Mandatory = $true, Position = 0 )]
        [ValidateSet( 'User', 'System' )]
        [string] $Target
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Path', Position = 1 )]
        [ValidateNotNullOrEmpty()]
        [string] $Path
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Path' )]
        [switch] $SymLink
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Def' )]
        [switch] $Default
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'Preset' )]
        [switch] $CheckPreset
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'State' )]
        [switch] $CheckState
       ,
        [Parameter( Mandatory = $true,  ParameterSetName = 'SymLink' )]
        [switch] $CheckSymLink
       ,
        [Parameter( Mandatory = $false )]
        [string] $FilePresets = $FilePresetsGlobal
    )

    # Получение имени этой функции.
    [string] $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    # Если путь не передан.
    if ( -not $Path )
    {
        # Если будут найдены другие файлы для настроек, состоящих из имени и расширения заданного оригинала,
        # то будет использоваться как пресет для настроек первый из дополнительных найденных.
        try
        {
            [string] $PresetsPath = [System.IO.Path]::GetDirectoryName($FilePresets)
            [string] $PresetsName = [System.IO.Path]::GetFileNameWithoutExtension($FilePresets)
            [string] $PresetsExt  = [System.IO.Path]::GetExtension($FilePresets)

            [string] $FoundPresetsMy = ((Get-ChildItem -File -LiteralPath $PresetsPath -ErrorAction Stop).Where({
                $_.Name -like "$PresetsName`?*$PresetsExt"
            },'First',1)).FullName
        }
        catch { [string] $FoundPresetsMy = '' }

        if ( $FoundPresetsMy ) { $FilePresets = $FoundPresetsMy }

        # Если файл с пресетами существует.
        if ( [System.IO.File]::Exists($FilePresets) )
        {
            # Получение пресетов в переменную.
            try { $ListPresetsGlobal = Get-Content -LiteralPath \\?\$FilePresets -Encoding UTF8 -ErrorAction SilentlyContinue } catch {}
        }
    }

    # Если указано проверить пути в пресете.
    if ( $CheckPreset )
    {
        if ( $Target.Count -ne 1 )
        {
            $text = if ( $L.s1 ) { $L.s1 } else { "Для проверки пресета можно указать только одну цель!" }
            Write-Warning "`n  $NameThisFunction`: $text"

            Get-Pause ; Return      # Выход из функции.
        }

        # Берем заданный путь в пресете для указанной папки, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
        if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Temp-Folder-$Target\s*=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" },'First',1) )
        {
            [string] $PathFolder = $Matches.Path.Trim()
        }
        else { [string] $PathFolder = '' }

        # Проверка и исправление указанного в пресете пути, на всякий случай, если ошибка, то обнуление пути.
        # Задаем результат расположения, с параметрами цвета.
        if ( $PathFolder )
        {
            try
            {
                # Раскрываем системные переменные, могут быть указаны в пути в пресете и получаем чистый полный путь с правильными разделителями.
                $PathFolder = ([System.IO.Path]::GetFullPath([System.Environment]::ExpandEnvironmentVariables($PathFolder))).Trim()
            }
            catch { $PathFolder = '' }

            # Если путь начинается на букву и двоеточие, и указанный локальный диск существует в системе.
            if (( $PathFolder -match '^[a-z]:\\.+' ) -and ( [System.IO.DriveInfo]::GetDrives().Where({ $_.DriveType -eq 'Fixed' }).Name -like "$([System.IO.Path]::GetPathRoot($PathFolder).Trim(' \'))\" ))
            {
                [string] $isPath = '#White#{0}#' -f $PathFolder
            }
            else { [string] $isPath = "#Red#{0}#" -f $( if ( $L.s3 ) { $L.s3 } else { 'Путь неверный или не подходит!' }) }
        }
        else { [string] $isPath = "#Red#{0}#" -f $( if ( $L.s4 ) { $L.s4 } else { 'Путь неверный или не указан!'}) }

        Return $isPath  # Выход из функции с выводом результата.
    }

    # Если указано проверить состояние цели в данный момент.
    if ( $CheckState )
    {
        if ( $Target.Count -ne 1 )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Для проверки состояния можно указать только одну цель!" }
            Write-Warning "`n  $NameThisFunction`: $text"

            Return    # Выход из функции.
        }

        # Получаем из реестра установленное в данный момент расположение для указанной цели, не раскрывая системные переменные.
        # И задаем путь по умолчанию.
        if ( $Target -eq 'User' )
        {
            $DefaultPath = "$env:USERPROFILE\AppData\Local\Temp"
            $RegKey      = 'Environment'
            $FindPath    = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey).GetValue('Temp',$null,'DoNotExpandEnvironmentNames')
        }
        else
        {
            $DefaultPath = "$env:SystemRoot\Temp"
            $RegKey      = 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
            $FindPath    = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey).GetValue('Temp',$null,'DoNotExpandEnvironmentNames')
        }

        # Создаем строку с цветовыми параметрами для вывода через функцию Write-HostColor, в зависимости от результата.
        if ( $FindPath )
        {
            # Раскрываем системные переменные, могут быть в пути.
            $isFindPath = [System.Environment]::ExpandEnvironmentVariables($FindPath)

            if ( $isFindPath -eq $DefaultPath )
            {      $isPath = "#Yellow#{0} #DarkGray#| #Yellow#$FindPath#" -f $( if ( $L.s6   ) { $L.s6   } else { 'По умолчанию' }) }
            else { $isPath =  "#Green#{0} #DarkGray#| #Yellow#$FindPath#" -f $( if ( $L.s6_1 ) { $L.s6_1 } else { 'Изменена'     }) }

            # Проверка существования папки по найденому пути в реестре.

            # Получения данных объекта.
            [psobject] $isFindPathItem = Get-Item -LiteralPath FileSystem::$isFindPath -Force -ErrorAction SilentlyContinue

            # Если исходная папка существует.
            if ( $isFindPathItem.PSIsContainer -and ( -not $isFindPathItem.LinkType ))
            {      $isFolder = '#DarkGray#| #Green#{0}#' -f $( if ( $L.s7   ) { $L.s7   } else { 'Папка существует'    }) }
            else { $isFolder = '#DarkGray#| #Red#{0}#'   -f $( if ( $L.s7_1 ) { $L.s7_1 } else { 'Папка не существует' }) }
        }
        else
        {
            $isPath = "#Red#{0}" -f $( if ( $L.s8 ) { $L.s8 } else { 'Путь не найден в реестре!' })
        }

        Return "$isPath $isFolder"  # Выход из функции с выводом результата.
    }

    # Если указано проверить наличие символической ссылки по пути по умолчанию.
    if ( $CheckSymLink )
    {
        if ( $Target.Count -ne 1 )
        {
            $text = if ( $L.s5 ) { $L.s5 } else { "Для проверки состояния можно указать только одну цель!" }
            Write-Warning "`n  $NameThisFunction`: $text"

            Return      # Выход из функции.
        }

        # Получаем из реестра установленное в данный момент расположение для указанной цели, раскрывая системные переменные.
        # И задаем путь по умолчанию.
        if ( $Target -eq 'User' )
        {
            $DefaultPath = "$env:USERPROFILE\AppData\Local\Temp"
            $RegKey      = 'Environment'
            $FindPath    = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($RegKey).GetValue('Temp',$null)
        }
        else
        {
            $DefaultPath = "$env:SystemRoot\Temp"
            $RegKey      = 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment'
            $FindPath    = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($RegKey).GetValue('Temp',$null)
        }

        # Создаем строку с цветовыми параметрами для вывода через функцию Write-HostColor, в зависимости от результата.
        if ( $FindPath )
        {
            if ( $FindPath -ne $DefaultPath )
            {
                if ( [System.IO.Directory]::Exists($DefaultPath) )
                {
                    $isFolder = [System.IO.DirectoryInfo]::new($DefaultPath)

                    if ( $isFolder.LinkType -eq 'SymbolicLink' )
                    {
                        $isTarget = $isFolder.Target

                        $isSymLink = "#Green#{0} #DarkGray#| #Yellow#$isTarget#" -f $( if ( $L.s9 ) { $L.s9 } else { 'Создана' })
                    }
                    else { $isSymLink = "#Yellow#{0}#" -f $( if ( $L.s9_1 ) { $L.s9_1 } else { 'Не cоздана' }) }
                }
                else { $isSymLink = "#Yellow#{0}#" -f $( if ( $L.s9_1 ) { $L.s9_1 } else { 'Не cоздана' }) }
            }
            else { $isSymLink = '#DarkGray#{0}#' -f $( if ( $L.s9_2 ) { $L.s9_2 } else { 'Не нужна' }) }
        }
        else { $isSymLink = "#Red#{0}" -f $( if ( $L.s8 ) { $L.s8 } else { 'Путь не найден в реестре!' }) }

        Return $isSymLink  # Выход из функции с выводом результата.
    }

    # Далее проверки и изменение расположения папки Temp ...

    $text = if ( $L.s33 ) { $L.s33 } else { "Функция 'Set-OwnerAndAccess' не подгружена!" }
    # Проверка наличия функции Set-OwnerAndAccess, используется для настройки параметров безопасности через SDDL.
    if ( -not ( Get-Command -CommandType Function -Name 'Set-OwnerAndAccess' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.

    $text = if ( $L.s34 ) { $L.s34 } else { "Функция 'ReStart-Explorer' не подгружена!" }
    # Проверка наличия функции ReStart-Explorer, используется для корректной остановки и затем запуска проводника.
    if ( -not ( Get-Command -CommandType Function -Name 'ReStart-Explorer' -ErrorAction SilentlyContinue ))
    { Write-Warning "`n  $NameThisFunction`: $text" ; Get-Pause ; Return } # Выход из функции.

    $text = if ( $L.s35 ) { $L.s35 } else { "Не найден или не указан файл Handle.exe" }
    # Проверка существования утилиты MS Handle.exe для получения блокирующих объект процессов,
    # необходимо для завершения этих процессов, чтобы была возможность удалить заблокированную папку.
    if ( -not [System.IO.File]::Exists($HandleExe) )
    { Write-Warning "`n  $NameThisFunction`: $text`: '$HandleExe'!" ; Get-Pause ; Return } # Выход из функции.

    [string] $PathFolder = ''

    $text = if ( $L.s10 ) { $L.s10 } else { "Настраиваем расположение папки Temp для" }
    Write-Host "`n $text '$Target'`n" -ForegroundColor Cyan

    # Если не указано вернуть по умолчанию, то проверяем пути.
    if ( -not $Default )
    {
        $text = if ( $L.s11 ) { $L.s11 } else { "Изменяем расположение папки" }
        Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
        Write-Host "Temp" -ForegroundColor White

        # Если не передан путь, получаем его в пресете.
        if ( -not $Path )
        {
            $text = if ( $L.s12 ) { $L.s12 } else { "Проверка заданного пути в пресете" }
            Write-Host "   $text" -ForegroundColor DarkGray

            # Берем заданный путь в пресете для указанной папки, отсеивая все непечатные (скрытые) и запрещённые символы, включая TAB.
            if ( $ListPresetsGlobal.Where({ $_ -match "^\s*Temp-Folder-$Target\s*=\s*(?<Path>([a-z]:)?[^\r\n\t\x02\x1c\x1d\x1e\x1f<>|:?*""\/=]+)\s*==" },'First',1) )
            {
                [string] $PathFolder = $Matches.Path.Trim()
            }
            else { [string] $PathFolder = '' }
        }
        else
        {
            $text = if ( $L.s13 ) { $L.s13 } else { "Проверка пути" }
            Write-Host "   $text" -ForegroundColor DarkGray

            $PathFolder = $Path
        }

        # Проверка переданного или указанного в пресете пути.
        if ( $PathFolder )
        {
            try
            {
                [string] $PathFolderForError = $PathFolder

                # Раскрываем системные переменные, могут быть указаны в пути в пресете и получаем чистый полный путь.
                $PathFolder = ([System.IO.Path]::GetFullPath([System.Environment]::ExpandEnvironmentVariables($PathFolder))).Trim()
            }
            catch { $PathFolder = '' }

            # Если путь начинается на букву и двоеточие, и указанный локальный диск существует в системе.
            if ( -not ( ( $PathFolder -match '^[a-z]:\\.+' ) -and ( [System.IO.DriveInfo]::GetDrives().Where({ $_.DriveType -eq 'Fixed' }).Name -like "$([System.IO.Path]::GetPathRoot($PathFolder).Trim(' \'))\" ) ) )
            {
                $text = if ( $L.s3 ) { $L.s3 } else { "Путь неверный или не подходит" }
                Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolderForError'!"

                Get-Pause ; Return    # Выход из функции.
            }
        }
        else
        {
            $text = if ( $L.s4 ) { $L.s4 } else { "Путь неверный или не указан!" }
            Write-Warning "`n  $NameThisFunction`: $text"

            Get-Pause ; Return     # Выход из функции.
        }

        $text = if ( $L.s14 ) { $L.s14 } else { "Путь корректный" }
        Write-Host "   $text" -ForegroundColor Green
    }
    else
    {
        $text = if ( $L.s15 ) { $L.s15 } else { "Восстанавливаем расположение" }
        Write-Host "   $text`: " -ForegroundColor Green -NoNewline

        $text = if ( $L.s15_1 ) { $L.s15_1 } else { "По умолчанию" }
        Write-Host "$text" -ForegroundColor White
    }

    # SDDL Права доступа на обе папки Temp, чтобы можно было перенести в одну папку для пользователей и системы,
    # и не было проблем при работе с программами с ограниченными правами.
    # Владелец: Администраторы
    # Полный доступ на саму папку Temp только у Системы и Администраторов, для пользователей только чтение.
    # На подпапки и файлы полный доступ у всех.
    $SDDL_All = "O:BAG:BAD:PAI(A;OICIIO;FA;;;CO)(A;OICI;FA;;;SY)(A;OICIIO;FA;;;BA)(A;;0x1e01ff;;;BA)(A;OICIIO;FA;;;BU)(A;;0x1e01ff;;;BU)"

    # Профили
    $SID = [System.Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if ( $SID -in $Global:LocalUserSids ) { $Source = 'Local' } else { $Source = 'Domain' }

    [array] $Accs = [PSCustomObject] @{ 
        Name     = $env:USERNAME
        FullName = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        Root     = 'HKCU:'
        Profile  = $env:USERPROFILE
        SID      = $SID
        Source   = $Source
    }

    if ( $Global:DataAllUsers.Redirects.Value )
    {
        @($Global:DataAllUsers.Where({ $_.Use -and $_.ProfileType -eq 'User' -and $_.Profile -and $_.SID -and $_.NTUSER_Load })).ForEach({
            
            $Accs += [PSCustomObject] @{
                Name     = $_.Name
                FullName = $_.FullName
                Root     = $_.SID
                Profile  = $_.Profile
                SID      = $_.SID
                Source   = $_.Source
            }
        })
    }

    if ( $Target -eq 'System' ) { [array] $Accs = [PSCustomObject] @{ Name = 'System' }}

    foreach ( $Acc in $Accs )
    {
        # Выполянем действия в зависимости от цели.
        if ( $Target -eq 'User' )
        {
            $UserName    = $Acc.Name
            $UserProfile = $Acc.Profile

            if ( $Acc.Root -eq 'HKCU:' )
            {
                $RootKey = [Microsoft.Win32.Registry]::CurrentUser
                $SubKey  = 'Environment'
            }
            else
            {
                $RootKey = [Microsoft.Win32.Registry]::Users
                $SubKey  = "$($Acc.Root)\Environment"
            }

            $DefaultPathOrig = '%USERPROFILE%\AppData\Local\Temp'

            if ( $Default ) { $PathFolder = "$UserProfile\AppData\Local\Temp" }
            elseif ( $PathFolder -eq "$UserProfile\AppData\Local\Temp" ) { $Default = $true }

            $text = if ( $L.s16_2 ) { $L.s16_2 } else { "Профиль" }
            Write-Host "`n   $text`: " -ForegroundColor DarkGray -NoNewline
            Write-Host "$UserName " -ForegroundColor White -NoNewline
            Write-Host "| $UserProfile | $($Acc.Source): $($Acc.FullName) ($($Acc.SID))" -ForegroundColor DarkGray

            $FolderFoundItem = Get-Item -LiteralPath FileSystem::$PathFolder -Force -ErrorAction SilentlyContinue

            # Если папка существует, и она не символическая ссылка.
            if (( $FolderFoundItem.PSIsContainer ) -and ( -not $FolderFoundItem.LinkType ))
            {
                $text = if ( $L.s16 ) { $L.s16 } else { "Устанавливаем права доступа" }
                Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s16_1 ) { $L.s16_1 } else { "на папку" }
                Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "'$PathFolder'" -ForegroundColor White

                # Восстанавливаем оригинальные правильные права доступа на существующую папку.
                if ( $Default )
                {
                    # Установлиаем владельцем текущего Пользователя и полное наследование прав, удалив все явные права.
                    Set-OwnerAndAccess -Path $PathFolder -User $UserName -RecoverySDDL 'D:AI'
                }
                else
                {
                    # Установлиаем владельцем группу Администраторы и права на папку из подготовленного SDDL для обоих папок.
                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL_All
                }
            }
            else
            {
                if ( $FolderFoundItem.Exists )
                {
                    # Иначе это файл или символическая ссылка, удаляем ее.
                    try { $FolderFoundItem.Attributes = 'Normal' ; $FolderFoundItem.Delete() }
                    catch
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { 'Не удалось удалить файл или символичесскую ссылку' }
                        Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                        Get-Pause ; Return    # Выход из функции.
                    }
                }

                $text = if ( $L.s18 ) { $L.s18 } else { 'Создаем папку' }
                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                Write-Host "'$PathFolder'" -ForegroundColor White

                try { New-Item -ItemType Directory -Path $PathFolder -Force -ErrorAction Stop > $null }
                catch
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { 'Папку создать не получилось' }
                    Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                    Get-Pause ; Return    # Выход из функции.
                }

                if ( -not $Default )
                {
                    $text = if ( $L.s16 ) { $L.s16 } else { 'Устанавливаем права доступа' }
                    Write-Host "   $text" -ForegroundColor Magenta

                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL_All
                }
            }
        }
        else
        {
            # Если указано восстановить по умолчанию.
            if ( $Default ) { $PathFolder = "$env:SystemRoot\Temp" }
            elseif ( $PathFolder -eq "$env:SystemRoot\Temp" ) { $Default = $true }

            $DefaultPathOrig = '%SystemRoot%\Temp'
            $RootKey         = [Microsoft.Win32.Registry]::LocalMachine
            $SubKey          = 'SYSTEM\CurrentControlSet\Control\Session Manager\Environment'

            # Параметры безопасности для настройки системной папки Temp по стандарту, после восстановления расположения по умолчанию.
            $SDDL = "O:SYG:SYD:PAI(A;OICIIO;FA;;;CO)(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;CI;DCLCWP;;;BU)"

            $FolderFoundItem = Get-Item -LiteralPath FileSystem::$PathFolder -Force -ErrorAction SilentlyContinue

            # Если папка существует, и она не символическая ссылка.
            if (( $FolderFoundItem.PSIsContainer ) -and ( -not $FolderFoundItem.LinkType ))
            {
                $text = if ( $L.s16 ) { $L.s16 } else { 'Устанавливаем права доступа' }
                Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s16_1 ) { $L.s16_1 } else { 'на папку' }
                Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "'$PathFolder'" -ForegroundColor White

                # Усли указано восстановить по умолчанию, восстанавливаем оригинальные правильные права доступа на существующую папку.
                if ( $Default )
                {
                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL
                }
                else
                {
                    # Установлиаем правильные права доступа из подготовленного SDDL,
                    # чтобы можно было задать одну папку для обоих папок Temp.
                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL_All
                }
            }
            else
            {
                if ( $FolderFoundItem.Exists )
                {
                    # Иначе это файл или символическая ссылка, удаляем ее.
                    try { $FolderFoundItem.Attributes = 'Normal' ; $FolderFoundItem.Delete() }
                    catch
                    {
                        $text = if ( $L.s17 ) { $L.s17 } else { 'Не удалось удалить файл или символичесскую ссылку' }
                        Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                        Get-Pause ; Return    # Выход из функции.
                    }
                }

                $text = if ( $L.s20 ) { $L.s20 } else { 'Создаем папку' }
                Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s20_1 ) { $L.s20_1 } else { 'с правами доступа' }
                Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "'$PathFolder'" -ForegroundColor White

                try { New-Item -ItemType Directory -Path $PathFolder -Force -ErrorAction Stop > $null }
                catch
                {
                    $text = if ( $L.s19 ) { $L.s19 } else { 'Папку создать не получилось' }
                    Write-Warning "`n  $NameThisFunction`: $text`: '$PathFolder'`n`t$($_.exception.Message)`n`t$($_.ScriptStackTrace.Split("`n") | Select-Object -First 1)"
                    Get-Pause ; Return   # Выход из функции.
                }

                if ( $Default )
                {
                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL
                }
                else
                {
                    Set-OwnerAndAccess -Path $PathFolder -RecoverySDDL $SDDL_All
                }
            }
        }

        $text = if ( $L.s21 ) { $L.s21 } else { 'Настраиваем параметры в реестре' }
        Write-Host "   $text" -ForegroundColor Magenta

        # Устанавливаем значения в реестре, и если раздела не существует, будет создан.
        # [System.Environment]::SetEnvironmentVariable после настройки сообщает процессам об изменении переменных окружения через SendMessage() WM_SETTINGCHANGE
        if ( $Default )
        {
            # после SetEnvironmentVariable с переменными в пути, PS не понимает путь до перезагрузки
            # и создает папку temp в текущей дирректории начиная с папки с именем переменной
            $ExpandPathDefault = [System.Environment]::ExpandEnvironmentVariables($DefaultPathOrig)

            if ( $Target -eq 'User' )
            {
                if ( $Acc.Root -eq 'HKCU:' )
                {
                    [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPathDefault, [System.EnvironmentVariableTarget]::User )
                    [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPathDefault, [System.EnvironmentVariableTarget]::User )
			        [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPathDefault, [System.EnvironmentVariableTarget]::Process )
                    [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPathDefault, [System.EnvironmentVariableTarget]::Process )
                }
            }
            else
            {
                [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPathDefault, [System.EnvironmentVariableTarget]::Machine )
                [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPathDefault, [System.EnvironmentVariableTarget]::Machine )
            }

            try
            {
                # Просто замена типа строки на ExpandString и параметра с переменной, как должно быть, так как SetEnv делает просто стринг и тупит с переменными.

                [psobject] $OpenSubKey = $null

                $OpenSubKey = $RootKey.CreateSubKey($SubKey)
                
                if ( $OpenSubKey )
                {
                    $OpenSubKey.SetValue('TEMP',$DefaultPathOrig,'ExpandString')
                    $OpenSubKey.SetValue('TMP', $DefaultPathOrig,'ExpandString')
                    $OpenSubKey.Close()
                }
            }
            catch { $OpenSubKey = $null }
        }
        else
        {
            # после SetEnvironmentVariable с переменными в пути PS не понимает путь до перезагрузки
            # и создает папку temp в текущей дирректории начиная с папки с именем переменной
            $ExpandPath = [System.Environment]::ExpandEnvironmentVariables($PathFolder)

            if ( $Target -eq 'User' )
            {
                if ( $Acc.Root -eq 'HKCU:' )
                {
                    [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPath, [System.EnvironmentVariableTarget]::User )
                    [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPath, [System.EnvironmentVariableTarget]::User )
			        [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPath, [System.EnvironmentVariableTarget]::Process )
                    [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPath, [System.EnvironmentVariableTarget]::Process )
                }
            }
            else
            {
                [System.Environment]::SetEnvironmentVariable( 'TEMP', $ExpandPath, [System.EnvironmentVariableTarget]::Machine )
                [System.Environment]::SetEnvironmentVariable( 'TMP',  $ExpandPath, [System.EnvironmentVariableTarget]::Machine )
            }

            try
            {
                # Замена типа строки на ExpandString и параметра в нужном виде, так как SetEnv делает просто стринг и тупит с переменными.

                [psobject] $OpenSubKey = $null

                $OpenSubKey = $RootKey.CreateSubKey($SubKey)
                
                if ( $OpenSubKey )
                {
                    $OpenSubKey.SetValue('TEMP',$PathFolder,'ExpandString')
                    $OpenSubKey.SetValue('TMP', $PathFolder,'ExpandString')
                    $OpenSubKey.Close()
                }
            }
            catch { $OpenSubKey = $null }
        }

        # Далее создание или удаление символической ссылки по дефолтному пути, указывающей на новое расположение, для совместимости, для некоторых программ необходимо.

        # Задаем расположение по умолчанию.
        if ( $Target -eq 'User' ) { $DefaultPath = "$UserProfile\AppData\Local\Temp" }
        else { $DefaultPath = "$env:SystemRoot\Temp" }

        # Если указано добавить символическую сслыку и путь не по умолчанию.
        if ( $SymLink -and ( -not $Default ))
        {
            $text = if ( $L.s22 ) { $L.s22 } else { 'Создание символической ссылки' }
            Write-Host "   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s22_1 ) { $L.s22_1 } else { 'в расположении' }
            Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline

            $text = if ( $L.s22_2 ) { $L.s22_2 } else { 'По умолчанию' }
            Write-Host "$text" -ForegroundColor White

            # Получаем параметры объекта, папки, файла или ссылки.
            $FolderFoundItem = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

            # Если объект существует.
            if ( $FolderFoundItem )
            {
                # Получаем полный доступ на папку со всеми файлами и папками.
                Set-OwnerAndAccess -Path $DefaultPath -SetFullAccess -Recurse

                $text = if ( $L.s23 ) { $L.s23 } else { 'Удаляем папку' }
                Write-Host "   $text`: " -ForegroundColor Magenta -NoNewline
                Write-Host "'$DefaultPath'" -ForegroundColor White

                # Удаляет файл, символическую сслыку или папку с файлами.
                try { $FolderFoundItem.Attributes = 'Normal' ; $FolderFoundItem.Delete() } catch {}

                # Поиск удаление всех ссылок в папке, так как Remove-Item их не может удалить, а $_.Delete($true) не может при атрибуте "Только чтение"
    
                # удаление всех символических ссылок на папки, чтобы внутрь не заходило
                Get-ChildItem -LiteralPath \\?\$DefaultPath -Recurse -Force -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                    if ( $_.LinkType -eq 'SymbolicLink' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} }
                }

                # Получить все объекты
                $Items = Get-ChildItem -LiteralPath \\?\$DefaultPath -Recurse -Force -ErrorAction SilentlyContinue
                
                # удаление всех файлов любых, включая NTFS Reparse points (Точки повторной обработки)
                $Items | ForEach-Object { if ( $_.Attributes -notlike '*Directory*' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }
                
                # удаление всех папок, включая NTFS Reparse points (Точки повторной обработки)
                $Items | ForEach-Object { if ( $_.Attributes -like '*Directory*'    ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }
                
                # удаление последней папки с рекурсией
                try { Remove-Item -LiteralPath \\?\$DefaultPath -Recurse -Force -ErrorAction SilentlyContinue } catch {}
                
                # ещё попытка удаления последней папки, так как Remove-Item не может удалять ReparsePoint
                $Item = Get-Item \\?\$DefaultPath -ErrorAction SilentlyContinue
                if ( $Item.Exists ) { try { $Item.Attributes = 'Normal' ; $Item.Delete() } catch {} }

                Start-Sleep -Milliseconds 500

                $FolderFoundItem.Refresh()

                # Если папка осталась.
                if ( $FolderFoundItem.Exists )
                {
                    $text = if ( $L.s24 ) { $L.s24 } else { 'Папка заблокирована, закрываем блокирующие процессы' }
                    Write-Host "   $text`:" -ForegroundColor DarkCyan

                    $text = if ( $L.s25 ) { $L.s25 } else { 'Завершаем корректно процесс' }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "Explorer.exe" -ForegroundColor White

                    ReStart-Explorer -Stop -AllSessions

                    [int] $N = 0

                    do
                    {
                        $N++

                        # Получаем список процессов, которые используют данную папку.
                        $FolderHandles = $null
                        try { $FolderHandles = (& $HandleExe -AcceptEula $DefaultPath).Where({ $_ -match "[.]exe" }) } catch { $FolderHandles = $null }

                        if ( $FolderHandles )
                        {
                            [hashtable] $FoundPocess = @{}

                            # Добавляем все процессы в таблицу, перезаписывая повторные ID.
                            foreach ( $Handle in $FolderHandles )
                            {
                                if ( $Handle -match "(^.+[.]exe)\s+pid:\s+([\d]+)" ) { $FoundPocess[$Matches[2]] = $Matches[1] }
                            }

                            # Для всех уникальных ID выполнение принудительного завершения работы.
                            foreach ( $ProcessPID in $FoundPocess.Keys )
                            {
                                $text = if ( $L.s26 ) { $L.s26 } else { 'Завершаем процесс' }
                                Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                                Write-Host "$($FoundPocess[$ProcessPID])" -ForegroundColor White -NoNewline
                                Write-Host "; PID: " -ForegroundColor DarkGray -NoNewline
                                Write-Host "$ProcessPID" -ForegroundColor Magenta

                                try { (Get-Process -Id $ProcessPID -ErrorAction SilentlyContinue).Kill() } catch {}
                            }
                        }
                    }
                    until (( -not $FolderHandles ) -or ( $N -ge 10 ))

                    # Повторное получение доступа ко всем папкам и файлам, на всякий случай.
                    Set-OwnerAndAccess -Path $DefaultPath -SetFullAccess -Recurse

                    # Поиск удаление всех ссылок в папке, так как Remove-Item их не может удалить, а $_.Delete($true) не может при атрибуте "Только чтение"
    
                    # удаление всех символических ссылок на папки, чтобы внутрь не заходило
                    Get-ChildItem -LiteralPath \\?\$DefaultPath -Recurse -Force -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                        if ( $_.LinkType -eq 'SymbolicLink' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} }
                    }

                    # Получить все объекты
                    $Items = Get-ChildItem -LiteralPath \\?\$DefaultPath -Recurse -Force -ErrorAction SilentlyContinue
                
                    # удаление всех файлов любых, включая NTFS Reparse points (Точки повторной обработки)
                    $Items | ForEach-Object { if ( $_.Attributes -notlike '*Directory*' ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }
                
                    # удаление всех папок, включая NTFS Reparse points (Точки повторной обработки)
                    $Items | ForEach-Object { if ( $_.Attributes -like '*Directory*'    ) { try { $_.Attributes = 'Normal' ; $_.Delete() } catch {} } }
                
                    # удаление последней папки с рекурсией
                    try { Remove-Item -LiteralPath \\?\$DefaultPath -Recurse -Force -ErrorAction SilentlyContinue } catch {}
                
                    # ещё попытка удаления последней папки, так как Remove-Item не может удалять ReparsePoint
                    $Item = Get-Item \\?\$DefaultPath -ErrorAction SilentlyContinue
                    if ( $Item.Exists ) { try { $Item.Attributes = 'Normal' ; $Item.Delete() } catch {} }

                    $text = if ( $L.s27 ) { $L.s27 } else { 'Запускаем процесс' }
                    Write-Host "   $text`: " -ForegroundColor DarkGray -NoNewline
                    Write-Host "Explorer.exe" -ForegroundColor White

                    ReStart-Explorer
                }

                # Обновляем данные по объекту.
                $FolderFoundItem.Refresh()

                # Если папка все еще существует.
                if ( $FolderFoundItem.Exists )
                {
                    $text = if ( $L.s28 ) { $L.s28 } else { 'Папка заблокирована, удалить не удалось!' }
                    Write-Host "   $text" -ForegroundColor Red

                    $text = if ( $L.s28_1 ) { $L.s28_1 } else { 'Символическая ссылка создана не будет!' }
                    Write-Host "   $text" -ForegroundColor Yellow
                }
                else { $FolderFoundItem = $null }
            }

            # Если папка не существует.
            if ( -not $FolderFoundItem )
            {
                $text = if ( $L.s29 ) { $L.s29 } else { 'Создание символической ссылки' }
                Write-Host "   $text " -ForegroundColor Magenta -NoNewline

                $text = if ( $L.s29_1 ) { $L.s29_1 } else { 'вместо' }
                Write-Host "$text`: " -ForegroundColor DarkGray -NoNewline
                Write-Host "'$DefaultPath'" -ForegroundColor White

                New-Item -ItemType SymbolicLink -Path $DefaultPath -Value $PathFolder -Force > $null
            }
        }
        else
        {
            if ( -not $Default )
            {
                $text = if ( $L.s30 ) { $L.s30 } else { 'Создание символической ссылки не указано' }
                Write-Host "   $text" -ForegroundColor DarkGray

                # Получаем параметры объекта, папки, файла или ссылки.
                $FolderFoundItem = Get-Item -LiteralPath FileSystem::$DefaultPath -Force -ErrorAction SilentlyContinue

                # Если объект существует, и он символическая ссылка
                if ( $FolderFoundItem.LinkType )
                {
                    # Получаем полный доступ на папку со всеми файлами и папками.
                    Set-OwnerAndAccess -Path $DefaultPath -SetFullAccess -Recurse

                    # Удаляет символическую сслыку.
                    try { $FolderFoundItem.Attributes = 'Normal' ; $FolderFoundItem.Delete() } catch {}

                    # Обновляем данные по объекту.
                    $FolderFoundItem.Refresh()

                    # Если объект всё еще существует.
                    if ( $FolderFoundItem.Exists )
                    {
                        $text = if ( $L.s31 ) { $L.s31 } else { 'Символическую ссылку удалить не удалось!' }
                        Write-Host "   $text" -ForegroundColor Red
                    }
                    else
                    {
                        $text = if ( $L.s31_1 ) { $L.s31_1 } else { 'Символическая ссылка удалена!' }
                        Write-Host "   $text" -ForegroundColor Green
                    }
                }
            }
        }
    }

    $text = if ( $L.s32 ) { $L.s32 } else { 'Выполнено' }
    Write-Host "`n   $text" -ForegroundColor Green

    $text = if ( $L.s32_1 ) { $L.s32_1 } else { 'Необходима перезагрузка!' }
    Write-Host "   $text" -ForegroundColor Blue

    Get-Pause
}
