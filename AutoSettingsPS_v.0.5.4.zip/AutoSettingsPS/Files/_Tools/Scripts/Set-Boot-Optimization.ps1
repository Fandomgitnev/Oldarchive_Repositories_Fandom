﻿
<#
.SYNOPSIS
 Настройка оптимизации загрузки Windows.

.DESCRIPTION
 Функция написана для скрипта AutoSettingsPS.
 Сделано для меню $Menu_Set_Boot_Optimization.

 Используется функция Get-Pause для установки паузы.
 Используется функция Set-Reg для установки параметров реестра, с проверкой и выводом результата.
 Используется функция Set-Svc для настройки служб, с проверкой и выводом результата.
 Используется функция Set-Tsk для настройки задач, с проверкой и выводом результата.

.EXAMPLE
    Set-Boot-Optimization -Options OptimizationDisable -Act Set

    Описание
    --------
    Отключить Оптимизацию загрузки.

.EXAMPLE
    Set-Boot-Optimization -Options OptimizationDisable -Act Default

    Описание
    --------
    Включить Оптимизацию загрузки.


.NOTES
 ===============================================
     Автор:  westlife (ru-board)  Версия 1.0
      Дата:  26-04-2019
 ===============================================

#>
Function Set-Boot-Optimization {

    [CmdletBinding( SupportsShouldProcess = $false )]
    [OutputType([string])]
    Param(
        [Parameter( Mandatory = $true,  ParameterSetName = 'Set', Position = 0 )]
        [ValidateSet( 'Set', 'Check', 'Default' )]
        [string] $Act
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Set', Position = 1 )]
        [ValidateSet( 'PrefetchDisable', 'OptimizationDisable', 'HibernateDisable', 'FastBootDisable' )]
        [string[]] $Options = 'FastBootDisable'
       ,
        [Parameter( Mandatory = $false, ParameterSetName = 'Check' )]
        [ValidateSet( 'ReadyBoot', 'Superfetch', 'Prefetcher', 'Hibernate', 'FastBoot' )]
        [string] $CheckState
    )

    # Получение имени этой функции.
    $NameThisFunction = $MyInvocation.MyCommand.Name

    # Получение перевода
    [hashtable] $L = $Lang.$NameThisFunction
    [string] $text = ''

    if ( $CheckState )
    {
        if ( 'ReadyBoot' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\ReadyBoot'
            try { [psobject] $ReadyBoot = [Microsoft.Win32.Registry]::GetValue($Key,'Start',$null)
            } catch { [psobject] $ReadyBoot = $null }

            if ( 0 -eq $ReadyBoot ) {  "#Green#{0} #" -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключен' }) }
            else                    { "#Yellow#{0} #" -f $(if ( $L.s2 ) { $L.s2 } else { 'Включен ' }) }
        }
        elseif ( 'Superfetch' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
            try { [psobject] $Superfetch = [Microsoft.Win32.Registry]::GetValue($Key,'EnableSuperfetch',$null)
            } catch { [psobject] $Superfetch = $null }

            if ( 0 -eq $Superfetch ) {  "#Green#{0} #" -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключен' }) }
            else                     { "#Yellow#{0} #" -f $(if ( $L.s2 ) { $L.s2 } else { 'Включен ' }) }
        }
        elseif ( 'Prefetcher' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'
            try { [psobject] $Prefetcher = [Microsoft.Win32.Registry]::GetValue($Key,'EnablePrefetcher',$null)
            } catch { [psobject] $Prefetcher = $null }

            if ( 0 -eq $Prefetcher ) {  "#Green#{0} #" -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключен' }) }
            else                     { "#Yellow#{0} #" -f $(if ( $L.s2 ) { $L.s2 } else { 'Включен ' }) }
        }
        elseif ( 'Hibernate' -eq $CheckState )
        {
            # if ( [System.IO.File]::Exists("$env:SystemDrive\hiberfil.sys") )
            # { [bool] $FileExist = $true } else { [bool] $FileExist = $false }

            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power'
            try { [psobject] $HibernateEnabled = [Microsoft.Win32.Registry]::GetValue($Key,'HibernateEnabled',$null)
            } catch { [psobject] $HibernateEnabled = $null }

            if ( 0 -eq $HibernateEnabled ) {  "#Green#{0}#" -f $(if ( $L.s3 ) { $L.s3 } else { 'Отключена' }) }
            else                           { "#Yellow#{0}#" -f $(if ( $L.s4 ) { $L.s4 } else { 'Включена ' }) }
        }
        elseif ( 'FastBoot' -eq $CheckState )
        {
            [string] $Key = 'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Power'
            try { [psobject] $HiberbootEnabled = [Microsoft.Win32.Registry]::GetValue($Key,'HiberbootEnabled',$null)
            } catch { [psobject] $HiberbootEnabled = $null }

            if ( 0 -eq $HiberbootEnabled ) {  "#Green#{0}#" -f $(if ( $L.s1 ) { $L.s1 } else { 'Отключен' }) }
            else                           { "#Yellow#{0}#" -f $(if ( $L.s2 ) { $L.s2 } else { 'Включен ' }) }
        }

        Return
    }

    $text = if ( $L.s5 ) { $L.s5 } else { 'Настройка Оптимизации Памяти/Записи/Запуска Windows и Программ' }
    Write-Host "`n██ $text " -ForegroundColor Cyan -NoNewline

    $text = if ( $L.s6 ) { $L.s6 } else { 'Функция' }
    Write-Host "| $text`: $NameThisFunction" -ForegroundColor DarkGray

    if ( $Options -like 'OptimizationDisable' -or $Options -like 'PrefetchDisable' )
    {
        if ( $Act -ne 'Default' )
        {
            $text = if ( $L.s7 ) { $L.s7 } else { 'Отключение' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline
            
            if ( $Options -like 'OptimizationDisable' )
            {
                $text = if ( $L.s7_1 ) { $L.s7_1 } else { 'Оптимизации Памяти/Записи/Запуска' }
                Write-Host "$text `n" -ForegroundColor White

                Set-Svc -Do:$Act Set-Service -Name 'SysMain' -StartupType Disabled -Status Stopped

                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\ResPriStaticDbSync'
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\WsSwapAssessmentTask'
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate'
                Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\HybridDriveCacheRebalance'
            }
            else
            {
                $text = if ( $L.s7_2 ) { $L.s7_2 } else { 'Оптимизации Запуска' }
                Write-Host "$text `n" -ForegroundColor White
            }

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\ReadyBoot' -Name 'Start' -Type DWord 0

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnableSuperfetch' -Type DWord 0
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Type DWord 0
        }
        else
        {
            # Всключает всё обратно для обоих вариантов, так как Prefetch зависит от SysMain

            $Act = 'set'

            $text = if ( $L.s8 ) { $L.s8 } else { 'Включение' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s8_1 ) { $L.s8_1 } else { 'Оптимизации Памяти/Записи/Запуска' }
            Write-Host "$text " -ForegroundColor White -NoNewline

            $text = if ( $L.s8_2 ) { $L.s8_2 } else { '(По умолчанию)' }
            Write-Host "$text`n" -ForegroundColor DarkGray

            Set-Svc -Do:$Act Set-Service -Name 'SysMain' -StartupType Automatic -Status Running

            Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\Sysmain\ResPriStaticDbSync'
            Set-Tsk -Do:$Act Enable-ScheduledTask  -TaskName '\Microsoft\Windows\Sysmain\WsSwapAssessmentTask'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\HybridDriveCachePrepopulate'
            Set-Tsk -Do:$Act Disable-ScheduledTask -TaskName '\Microsoft\Windows\Sysmain\HybridDriveCacheRebalance'
            
            try { Enable-MMagent -PageCombining -MemoryCompression -ApplicationPreLaunch -ErrorAction SilentlyContinue } catch {}

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\WMI\AutoLogger\ReadyBoot' -Name 'Start' -Type DWord 1

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnableSuperfetch' -Type DWord 3
            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters' -Name 'EnablePrefetcher' -Type DWord 3

            $Act = 'Default'
        }
    }

    if ( $Options -like 'HibernateDisable' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s9 ) { $L.s9 } else { 'Отключение' }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s9_1 ) { $L.s9_1 } else { 'Гибернации' }
            Write-Host "$text`n" -ForegroundColor White

            Write-Host "   PowerCfg /Hibernate Off `n" -ForegroundColor DarkGray

            & PowerCfg.exe /Hibernate Off
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s10 ) { $L.s10 } else { 'Включение' }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s10_1 ) { $L.s10_1 } else { 'Гибернации' }
            Write-Host "$text`n" -ForegroundColor White

            Write-Host "   PowerCfg /Hibernate On `n" -ForegroundColor DarkGray

            & PowerCfg.exe /Hibernate On
        }
        else
        {
            $text = if ( $L.s11 ) { $L.s11 } else { "'Check' не предусмотрен для 'HibernateDisable'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }

    if ( $Options -like 'FastBootDisable' )
    {
        if ( $Act -eq 'Set' )
        {
            $text = if ( $L.s12 ) { $L.s12 } else { "Отключение" }
            Write-Host "`n   $text " -ForegroundColor Cyan -NoNewline

            $text = if ( $L.s12_1 ) { $L.s12_1 } else { "Быстрого запуска" }
            Write-Host "$text`n" -ForegroundColor White

            Set-Reg -Do:$Act New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Type DWord 0
        }
        elseif ( $Act -eq 'Default' )
        {
            $text = if ( $L.s13 ) { $L.s13 } else { "Включение" }
            Write-Host "`n   $text " -ForegroundColor Magenta -NoNewline

            $text = if ( $L.s13_1 ) { $L.s13_1 } else { "Быстрого запуска" }
            Write-Host "$text `n" -ForegroundColor White

            Set-Reg New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'HiberbootEnabled' -Type DWord 1
        }
        else
        {
            $text = if ( $L.s14 ) { $L.s14 } else { "'Check' не предусмотрен для 'FastBootDisable'" }
            Write-Host "   $text" -ForegroundColor DarkGray
        }
    }
    $text = if ( $L.s15 ) { $L.s15 } else { "Выполнено" }
    Write-Host "`n   $text" -ForegroundColor Green

    Get-Pause
}
