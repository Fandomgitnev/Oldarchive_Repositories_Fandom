@echo off
title FastWin10_11
goto main
:cheackworktweak
for %%g in (Hibernate1 Smartscreen2 Numloock1 ShowSeconds1 Wdarknoactive1 Greenbox1 Highlightss1 Stickykeyss1 Updrivers1 Edgeup1 Backapplication1 Setimap1) do (set "%%g=[32mON[0m")
(
powercfg /a | findstr /C:"Hibernation has not been enabled" || set "Hibernate1=[31mOFF[0m"
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen | find "0" || set "Smartscreen2=[31mOFF[0m"
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v ConfigureAppInstallControlEnabled | find "0" || set "Smartscreen2=[31mOFF[0m"
reg query "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set Numloock1=[31mOFF[0m
reg query "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators | find "2" || set Numloock1=[31mOFF[0m
reg query "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowSecondsInSystemClock | find "0x1" || set ShowSeconds1=[31mOFF[0m
reg query "HKCU\Software\Microsoft\Windows\DWM" /v AccentColorInactive | find "0" || set Wdarknoactive1=[31mOFF[0m
reg query "HKCU\Control Panel\Colors" /v Hilight | find "15 252 3" || set Greenbox1=[31mOFF[0m
reg query "HKCU\Control Panel\Colors" /v HotTrackingColor | find "15 252 3" || set Greenbox1=[31mOFF[0m
Reg.exe query "HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer" /v NoSearchEverywhereLinkInStartMenu | find "1" || set Highlightss1=[31mOFF[0m
Reg.exe query "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v DisableSearchBoxSuggestions | find "1" || set Highlightss1=[31mOFF[0m
Reg.exe query "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v IsDynamicSearchBoxEnabled | find "0" || set Highlightss1=[31mOFF[0m
Reg.exe query "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BingSearchEnabled | find "0" || set Highlightss1=[31mOFF[0m
reg query "HKCU\Control Panel\Accessibility\StickyKeys" /v Flags | find "506" || set Stickykeyss1=[31mOFF[0m
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate | find "0x1" || set Updrivers1=[31mOFF[0m
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v SearchOrderConfig | find "0x0" || set Updrivers1=[31mOFF[0m
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdate" /v Start | find "0x4" || set Edgeup1=[31mOFF[0m
reg query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdatem" /v Start | find "0x4" || set Edgeup1=[31mOFF[0m
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled | find "0x1" || set Backapplication1=[31mOFF[0m
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle | find "0x0" || set Backapplication1=[31mOFF[0m
REG query "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MapsBroker" /v Start | find "0x4" || set Setimap1=[31mOFF[0m
) >nul 
exit /b
:main
cls
echo back to main menu use 99 prees
echo.
echo                                            ================================
echo                                                 FastWin10_11
echo                                         ================================
echo.
echo                                         [1] Auto
echo                                         [2] only 11 auto
echo                                         [4] Drivers / Programs
echo                                         [6] Del Mic EdgeX2 + webvie/Officialway
echo                                         [7] cheack enable or off tweak info
echo.
set /p ttt=".                             >>"
if "%ttt%" == "1" goto auto
if "%ttt%" == "2" goto asetwin11
if "%ttt%" == "4" goto drivers
if "%ttt%" == "6" goto delmicrosoftof
if "%ttt%" == "7" goto cheacktweakonoff
) else (
goto main
)
:auto
cls
echo Hybernation off
powercfg.exe /h off
echo.
echo off2 smartscreen
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\System" /v EnableSmartScreen /t REG_DWORD /d 0 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\SmartScreen" /v ConfigureAppInstallControlEnabled /t REG_DWORD /d 0 /f
echo.
echo.
echo enable2 numloock
reg add "HKCU\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
reg add "HKU\.DEFAULT\Control Panel\Keyboard" /v InitialKeyboardIndicators /t REG_SZ /d 2 /f
echo.
echo.
echo enable2 bar secons time
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowSecondsInSystemClock /t REG_DWORD /d 1 /f
echo.
echo.
echo dark no active
reg add "HKCU\Software\Microsoft\Windows\DWM" /v AccentColorInactive /t REG_DWORD /d 0xFF000000 /f
echo.
echo.
echo enable2 green box
reg add "HKCU\Control Panel\Colors" /v Hilight /t REG_SZ /d "15 252 3" /f
reg add "HKCU\Control Panel\Colors" /v HotTrackingColor /t REG_SZ /d "15 252 3" /f
echo.
echo.
echo Off2 Bing Search Highlights
Reg.exe add "HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer" /v NoSearchEverywhereLinkInStartMenu /t REG_DWORD /d 1 /f
Reg.exe add "HKCU\SOFTWARE\Policies\Microsoft\Windows\Explorer" /v "DisableSearchBoxSuggestions" /t REG_DWORD /d "1" /f
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\SearchSettings" /v "IsDynamicSearchBoxEnabled" /t REG_DWORD /d "0" /f 
Reg.exe add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v "BingSearchEnabled" /t REG_DWORD /d "0" /f 
echo.
echo.
echo Disable Sticky Keys
reg add "HKCU\Control Panel\Accessibility\StickyKeys" /v "Flags" /t REG_SZ /d "506" /f
echo.
echo.
echo off2 auto update drivers
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v ExcludeWUDriversInQualityUpdate /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching" /v SearchOrderConfig /t REG_DWORD /d 0 /f
echo.
echo.
echo off service edge
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdate" /v Start /t REG_DWORD /d 4 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\edgeupdatem" /v Start /t REG_DWORD /d 4 /f
echo.
echo.
echo.
echo.
echo            next auto set in win 11
echo            1 yes
echo            2 no (back main page)
echo            3 no exit
set /p Ar5=".>>"
if "%Ar5%"=="1" goto asetwin11 
if "%Ar5%"=="2" goto main
if "%Ar5%"=="3" exit
) else (
goto main
)
:asetwin11
cls
echo.
echo.
echo off2 win11 background application
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v BackgroundAppGlobalToggle /t REG_DWORD /d 0 /f
echo.
echo.
echo off2 win11 setting Map
REG ADD "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MapsBroker" /v Start /t REG_DWORD /d 4 /f
echo.
echo.
echo END
pause
goto main
:drivers
cls
echo.
echo.
echo.
echo.
echo                                               [1] Link DirectX
echo                                               [2] Link VCRedist
echo                                               [3] Intel
echo                                               [4] NVIDIA
echo                                               [5] AMD
echo                                               [6] Radeon Software Slimmer
echo                                               [7] NVCleanstal
echo                                               [8] Display Driver Uninstaller (ddu)
echo                                               [9] Driver Store Explorer
echo                                               [10] Device Clean UP
echo                                               [11] Snappy Driver Installer
echo                                               [12] open menu programs
set /p P1=".                >>"
if "%P1%"=="1" start https://www.techpowerup.com/download/directx-redistributable-runtime/
if "%P1%"=="2" start https://www.techpowerup.com/download/visual-c-redistributable-runtime-package-all-in-one/
if "%P1%"=="3" start https://www.intel.com/content/www/us/en/download-center/home.html
if "%P1%"=="4" start https://www.nvidia.com/en-us/geforce/drivers/
if "%P1%"=="5" start https://www.amd.com/en/support/download/drivers.html
if "%P1%"=="6" start https://github.com/GSDragoon/RadeonSoftwareSlimmer
if "%P1%"=="7" start https://www.techpowerup.com/download/techpowerup-nvcleanstall/
if "%P1%"=="8" start https://www.wagnardsoft.com/
if "%P1%"=="9" start https://github.com/lostindark/DriverStoreExplorer
if "%P1%"=="10" start https://www.uwe-sieber.de/misc_tools_e.html
if "%P1%"=="11" start https://www.glenn.delahoy.com/snappy-driver-installer-origin/
if "%P1%"=="12" goto programs
if "%P1%"=="97" start https://www.nvidia.com/en-us/geforce/drivers/results/237786/
if "%P1%"=="98" start https://www.nvidia.com/en-us/drivers/details/237786/
if "%P1%"=="99" goto main
) else (
goto drivers
)
:programs
cls
echo all others in wtool
echo.
echo                    [1] 7zip
echo                   [2] context menu
echo                   [3] mpc-hc
echo                   [4] notepad++
echo                    [5] systeminformer
echo.
set /p P2P=".        >>"
if "%P2P%"=="1" start https://7-zip.org/download.html
if "%P2P%"=="2" start https://www.sordum.org/7615/easy-context-menu-v1-6/
if "%P2P%"=="3" start https://github.com/clsid2/mpc-hc/releases
if "%P2P%"=="4" start https://github.com/notepad-plus-plus/notepad-plus-plus/releases?page=3
if "%P2P%"=="5" start https://systeminformer.sourceforge.io/
if "%P2P%"=="99" goto drivers 
) else (
goto programs
)
:delmicrosoftof
cls 
taskkill /f /im MicrosoftEdge.exe
taskkill /f /im MicrosoftEdgeUpdate.exe
echo Please go to the Edge or EdgeWebView version folder, open the "Installer" folder, Shift + right-click on "setup.exe", select "Copy as path", and paste the full path here.
start "" "C:\Program Files (x86)\Microsoft\Edge\Application"
set /p Delete=
start "" "C:\Program Files (x86)\Microsoft\EdgeWebView\Application"
set /p deleteW=
start "" %Delete% --uninstall --system-level --force-uninstall --msedge
start "" %deleteW% --uninstall --system-level --force-uninstall --msedgewebview
pause >nul 
goto main

:cheacktweakonoff
call :cheackworktweak
echo.
cls
echo          [WinTweak10]
echo.
echo      Hibernation Tweak %Hibernate1%
echo      Smartscreen Tweak %Smartscreen2%
echo      Numloock Tweak %Numloock1%
echo      Show secons time Tweak %ShowSeconds1%
echo      No Acrive Window Dark mode Tweak %Wdarknoactive1%
echo      Greenbox text Tweak %Greenbox1%
echo      Bing Search Tweak %Highlightss1%
echo      Sticky Keys Tweak %Stickykeyss1%
echo      Auto UP Driver Tweak %Updrivers1%
echo      Service edge Tweak %Edgeup1%
echo.
echo          [WinTweak11]
echo.
echo      Background app Tweek %Backapplication1%
echo      Service Tweak %Setimap1%
echo.
pause >nul
goto main